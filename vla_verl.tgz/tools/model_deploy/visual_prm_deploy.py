from fastapi import FastAPI, UploadFile, File, Form
from PIL import Image
import io
import torch
import json
import torchvision.transforms as T

from typing import Union 
from transformers import AutoModel, AutoTokenizer
from torchvision.transforms.functional import InterpolationMode

import cv2
from niofs.read_cache_op_py import read_cache_op_py
import numpy as np
import os

import base64

IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)

def build_transform(input_size):
    MEAN, STD = IMAGENET_MEAN, IMAGENET_STD
    transform = T.Compose([
        T.Lambda(lambda img: img.convert('RGB') if img.mode != 'RGB' else img),
        T.Resize((input_size, input_size), interpolation=InterpolationMode.BICUBIC),
        T.ToTensor(),
        T.Normalize(mean=MEAN, std=STD)
    ])
    return transform

def find_closest_aspect_ratio(aspect_ratio, target_ratios, width, height, image_size):
    best_ratio_diff = float('inf')
    best_ratio = (1, 1)
    area = width * height
    for ratio in target_ratios:
        target_aspect_ratio = ratio[0] / ratio[1]
        ratio_diff = abs(aspect_ratio - target_aspect_ratio)
        if ratio_diff < best_ratio_diff:
            best_ratio_diff = ratio_diff
            best_ratio = ratio
        elif ratio_diff == best_ratio_diff:
            if area > 0.5 * image_size * image_size * ratio[0] * ratio[1]:
                best_ratio = ratio
    return best_ratio

def dynamic_preprocess(image, min_num=1, max_num=12, image_size=448, use_thumbnail=False):
    orig_width, orig_height = image.size
    aspect_ratio = orig_width / orig_height

    # calculate the existing image aspect ratio
    target_ratios = set(
        (i, j) for n in range(min_num, max_num + 1) for i in range(1, n + 1) for j in range(1, n + 1) if
        i * j <= max_num and i * j >= min_num)
    target_ratios = sorted(target_ratios, key=lambda x: x[0] * x[1])

    # find the closest aspect ratio to the target
    target_aspect_ratio = find_closest_aspect_ratio(
        aspect_ratio, target_ratios, orig_width, orig_height, image_size)

    # calculate the target width and height
    target_width = image_size * target_aspect_ratio[0]
    target_height = image_size * target_aspect_ratio[1]
    blocks = target_aspect_ratio[0] * target_aspect_ratio[1]

    # resize the image
    resized_img = image.resize((target_width, target_height))
    processed_images = []
    for i in range(blocks):
        box = (
            (i % (target_width // image_size)) * image_size,
            (i // (target_width // image_size)) * image_size,
            ((i % (target_width // image_size)) + 1) * image_size,
            ((i // (target_width // image_size)) + 1) * image_size
        )
        # split the image
        split_img = resized_img.crop(box)
        processed_images.append(split_img)
    assert len(processed_images) == blocks
    if use_thumbnail and len(processed_images) != 1:
        thumbnail_img = image.resize((image_size, image_size))
        processed_images.append(thumbnail_img)
    return processed_images


def loadload_image(image_path, root=None, tar_saved=False):
    ON_TXSH = 1
    mount_point = (
        "/lustre" if os.path.exists("/lustre") else "/perception-hl/MLM_evaluator"
    )
    if ":" in image_path:
        read_ceph_kwargs = {}
        if ON_TXSH:
            read_ceph_kwargs["mnt_point"] = mount_point
        if tar_saved:
            tar_path, tar_size, img_offset, img_size = image_path.split(" ")
            tar_path = f"{tar_path} {tar_size}"
            ceph_path = "/" + tar_path.split(":")[1]
            raw_bytes = read_cache_op_py([ceph_path], **read_ceph_kwargs)
            image_bytes = raw_bytes[0][int(img_offset) : int(img_offset) + int(img_size)]
        else:
            if not ON_TXSH:
                if ":" in image_path:
                    ceph_path = "/" + image_path.split(":")[1]
                else:
                    ceph_path = image_path
            else:
                if image_path.startswith("/"):
                    ceph_path = image_path.split(" ")[0]
                else:
                    ceph_path = "/" + image_path.split(" ")[0].split(":")[1]
                
                print(ceph_path)
                print(read_ceph_kwargs)

            raw_bytes = read_cache_op_py([ceph_path], **read_ceph_kwargs)
            image_bytes = raw_bytes[0]

        decoded = cv2.imdecode(np.frombuffer(image_bytes, np.uint8), -1)  # BGR
        if decoded.ndim == 2:
            decoded = np.tile(decoded[..., np.newaxis], (1, 1, 3))
        image = Image.fromarray(decoded[:, :, ::-1], "RGB")
    else:
        if "/" in image_path:
            image = Image.open(image_path).convert('RGB')
        else:
            image_path = os.path.join(root, image_path)
            image = Image.open(image_path).convert('RGB')

    return image

def base64_str_to_image(base64_str: str) -> Image.Image:
    """
    将Base64字符串转换为PIL的Image对象
    
    :param base64_str: Base64编码的字符串
    :return: 转换后的PIL Image对象
    """
    # 将Base64字符串解码为字节数据
    image_bytes = base64.b64decode(base64_str)
    
    # 创建字节流缓冲区并写入字节数据
    buffer = io.BytesIO(image_bytes)
    
    # 从缓冲区读取图像数据
    image = Image.open(buffer)
    
    return image


def load_image(image, input_size=448, max_num=12):


    if isinstance(image, str):
        # 如果传入的是字符串，则需要读取，否则本身传入的就是Image
        image = loadload_image(image)

    # 如果传入的是Image
    transform = build_transform(input_size=input_size)
    images = dynamic_preprocess(image, image_size=input_size, use_thumbnail=True, max_num=max_num)
    pixel_values = [transform(image) for image in images]
    pixel_values = torch.stack(pixel_values)
        
    return pixel_values
    

# 初始化 FastAPI 应用
app = FastAPI(title="VisualPRM-8B Inference Service")

# init model
model_name = "./weights/VisualPRM"

tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True, use_fast=False)
model = AutoModel.from_pretrained(
    model_name,
    trust_remote_code=True,
    low_cpu_mem_usage=True,
    torch_dtype=torch.bfloat16,
    device_map="auto"  # 自动分配设备（优先使用GPU）
).eval().cuda()

# 定义推理接口：接收图像和问题，返回模型回答
@app.post("/infer")
async def infer(
    image: str = Form(None),  # 直接传str路径，后面load_image得修改
    image_bytes: str = Form(None),
    question: str = Form(...), 
    response_list_str: str = Form(...)  # 接收JSON字符串
):
    # 读取图像
    # try:
    response_list = json.loads(response_list_str)
    if image is not None:
        image = load_image(image)
    
    elif image_bytes is not None:
        image = base64_str_to_image(image_bytes)
        image = load_image(image)
    else:
        pass

        
    if image is not None:
        pixel_values = image.to(torch.bfloat16).cuda()

        # 预处理输入（图像+问题）
        outputs = model.select_best_response(
            tokenizer=tokenizer,
            question=question,
            response_list=response_list,
            pixel_values=pixel_values,
            return_scores=True,
        )
    else:
        outputs = model.select_best_response(
            tokenizer=tokenizer,
            question=question,
            response_list=response_list,
            return_scores=True,
        )

    # except:
    #     return {"answer": f"Error"}
        
    return {"answer": outputs}

# 启动服务（在命令行运行时使用 uvicorn 启动）
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8081)  # 允许外部访问，端口8000
