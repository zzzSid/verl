#!/bin/bash
source .venv/bin/activate

# 定义vllm部署命令，根据实际情况修改参数
VLLM_CMD="vllm serve internlm/POLAR-7B --task=reward --trust-remote-code --tensor-parallel-size=2 --port 30000"

# 输出脚本信息
echo "开始运行vllm部署死循环脚本"
echo "使用的命令: $VLLM_CMD"
echo "按Ctrl+C停止脚本"

# 死循环运行vllm命令
while true; do
    echo "[$(date)] 启动vllm服务..."
    export CUDA_VISIBLE_DEVICES=3,4
    # 执行vllm命令
    python tools/model_deploy/qwen3_embedding_deploy.py
    
    # 如果命令退出，输出信息并等待几秒后重新启动
    echo "[$(date)] vllm服务已退出，状态码: $?"
    echo "[$(date)] 5秒后将重新启动vllm服务..."
    sleep 5
done
