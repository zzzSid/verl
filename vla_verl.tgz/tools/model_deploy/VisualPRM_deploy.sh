#!/bin/bash
source .venv/bin/activate


# 输出脚本信息
echo "开始运行vllm部署死循环脚本"
echo "使用的命令: $VLLM_CMD"
echo "按Ctrl+C停止脚本"

# 死循环运行vllm命令
while true; do
    echo "[$(date)] 启动vllm服务..."
    # 执行vllm命令
    CUDA_VISIBLE_DEVICES=5 python /home/neos.yan/ws/code/dots.ocr/tools/deploy/visual_prm_deploy.py
    
    # 如果命令退出，输出信息并等待几秒后重新启动
    echo "[$(date)] vllm服务已退出，状态码: $?"
    echo "[$(date)] 5秒后将重新启动vllm服务..."
    sleep 5
done
