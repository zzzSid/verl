# GTVisualize 集成到 RLHFDataset 的分析文档

## 1. 代码结构分析

### 1.1 GTVisualize 类 (`tools/visualize/gt_visualize.py`)

**功能**: 对数据集进行可视化，生成包含以下内容的可视化图像：
- `pixel_values`: 图像像素值（右侧网格显示）
- `input_ids`: 输入token IDs（左侧可视化）
- `labels`: 标签（左侧可视化）
- `attention_mask`: 注意力掩码（左侧可视化）
- `image_flags`: 图像标志
- `conversations_debug`: 对话调试信息（右侧）
- `conversations_origin_debug`: 原始对话调试信息（右侧）
- `dataset_name_debug`: 数据集名称

**期望的数据格式**:
```python
data_dict = {
    'pixel_values': torch.Tensor,  # shape: [num_images, C, H, W] 或 [C, H, W]
    'input_ids': torch.Tensor,
    'labels': torch.Tensor,  # 可选
    'attention_mask': torch.Tensor,
    'image_flags': torch.Tensor,  # 可选
    'conversations_debug': List[str],  # 可选
    'conversations_origin_debug': List[dict],  # 可选
    'dataset_name_debug': str,  # 可选
}
```

**初始化行为**: 
- 在 `__init__` 中自动调用 `visualize_samples()`
- 完成后自动调用 `sys.exit(0)` 退出程序

### 1.2 RLHFDataset 类 (`verl/utils/dataset/rl_dataset.py`)

**功能**: PyTorch Dataset，用于加载和预处理RLHF数据

**`__getitem__` 返回的数据格式**:
```python
row_dict = {
    'input_ids': torch.Tensor,
    'attention_mask': torch.Tensor,
    'position_ids': torch.Tensor,
    'multi_modal_inputs': {  # 如果 processor 不为 None
        'pixel_values': torch.Tensor,  # 存储在 multi_modal_inputs 中
        'image_grid_thw': ...,
        'video_grid_thw': ...,
        # 其他多模态输入
    },
    'multi_modal_data': {
        'image': List[PIL.Image],
        'video': ...,
    },
    'raw_prompt_ids': List[int],
    'raw_prompt': str,  # 如果 return_raw_chat=True
    'full_prompts': str,  # 如果 return_full_prompt=True
    'index': int,
    'tools_kwargs': dict,
    # 其他字段...
}
```

## 2. 数据格式差异分析

### 2.1 主要差异

| GTVisualize 期望 | RLHFDataset 提供 | 转换方法 |
|-----------------|-----------------|---------|
| `pixel_values` (顶层) | `multi_modal_inputs['pixel_values']` | 需要提取 |
| `input_ids` | `input_ids` | ✅ 直接可用 |
| `attention_mask` | `attention_mask` | ✅ 直接可用 |
| `labels` | ❌ 不存在 | 需要从配置或数据中获取 |
| `image_flags` | ❌ 不存在 | 可能需要从 `multi_modal_inputs` 中提取或生成 |
| `conversations_debug` | ❌ 不存在 | 可以从 `raw_prompt` 或 `full_prompts` 生成 |
| `conversations_origin_debug` | `raw_prompt` (如果 return_raw_chat=True) | 需要格式化 |
| `dataset_name_debug` | ❌ 不存在 | 可以从数据源信息中提取 |

### 2.2 关键转换点

1. **pixel_values**: 需要从 `row_dict['multi_modal_inputs']['pixel_values']` 提取
2. **labels**: RLHFDataset 不提供 labels，可能需要：
   - 从配置中启用 labels 生成
   - 或者可视化时跳过 labels
3. **conversations_debug**: 可以从 `full_prompts` 或 `raw_prompt` 生成
4. **conversations_origin_debug**: 可以从 `raw_prompt` 或 messages 生成

## 3. 集成方案

### 方案 1: 在 RLHFDataset 中添加可视化方法（推荐）

**优点**:
- 保持代码组织清晰
- 可以复用数据集配置
- 不改变现有代码结构

**实现步骤**:

1. **修改 GTVisualize 类**:
   - 移除自动退出逻辑（`sys.exit(0)`），改为可选
   - 添加一个方法用于适配数据格式

2. **在 RLHFDataset 中添加方法**:
```python
def visualize_dataset(
    self,
    output_dir: str = None,
    num_vis: int = 200,
    random_seed: int = 42,
    max_total_width: Optional[int] = 6000,
    auto_exit: bool = False,
):
    """可视化数据集样本.
    
    Args:
        output_dir: 输出目录
        num_vis: 可视化的样本数量
        random_seed: 随机种子
        max_total_width: 最大总宽度
        auto_exit: 是否在完成后自动退出程序
    """
    from tools.visualize.gt_visualize import GTVisualize
    
    # 创建适配器数据集
    adapter_dataset = RLHFDatasetAdapter(self)
    
    # 创建可视化对象
    visualizer = GTVisualize(
        dataset=adapter_dataset,
        output_dir=output_dir,
        num_vis=num_vis,
        random_seed=random_seed,
        max_total_width=max_total_width,
        auto_exit=auto_exit,
    )
    
    return visualizer
```

3. **创建适配器类**:
```python
class RLHFDatasetAdapter:
    """适配器类，将 RLHFDataset 的输出转换为 GTVisualize 期望的格式."""
    
    def __init__(self, rlhf_dataset: RLHFDataset):
        self.rlhf_dataset = rlhf_dataset
    
    def __len__(self):
        return len(self.rlhf_dataset)
    
    def __getitem__(self, idx):
        row_dict = self.rlhf_dataset[idx]
        
        # 转换数据格式
        data_dict = {}
        
        # 提取 pixel_values
        if 'multi_modal_inputs' in row_dict and 'pixel_values' in row_dict['multi_modal_inputs']:
            data_dict['pixel_values'] = row_dict['multi_modal_inputs']['pixel_values']
        
        # 直接映射的字段
        data_dict['input_ids'] = row_dict.get('input_ids')
        data_dict['attention_mask'] = row_dict.get('attention_mask')
        
        # 提取 image_flags（如果存在）
        if 'multi_modal_inputs' in row_dict:
            data_dict['image_flags'] = row_dict['multi_modal_inputs'].get('image_flags')
        
        # 生成 conversations_debug
        if 'full_prompts' in row_dict:
            # 将 full_prompts 转换为列表格式
            data_dict['conversations_debug'] = [row_dict['full_prompts']]
        elif 'raw_prompt' in row_dict:
            data_dict['conversations_debug'] = [row_dict['raw_prompt']]
        
        # 生成 conversations_origin_debug
        if 'raw_prompt' in row_dict:
            # 尝试解析为对话格式
            data_dict['conversations_origin_debug'] = self._parse_conversations(row_dict.get('raw_prompt'))
        
        # 生成 dataset_name_debug
        if 'data_source' in row_dict:
            data_dict['dataset_name_debug'] = str(row_dict.get('data_source', ''))
        
        return data_dict
    
    def _parse_conversations(self, raw_prompt: str):
        """解析原始提示为对话格式."""
        # 这里可以根据实际格式进行解析
        # 例如，如果包含 <|im_start|> 等标记
        return [{'from': 'user', 'value': raw_prompt}]
```

### 方案 2: 修改 GTVisualize 支持直接使用 RLHFDataset

**优点**:
- 不需要适配器
- 更直接

**缺点**:
- 需要修改 GTVisualize 的内部逻辑
- 耦合度更高

### 方案 3: 创建独立的集成脚本

**优点**:
- 不修改现有代码
- 可以灵活配置

**缺点**:
- 需要额外的脚本文件
- 可能重复代码

## 4. 推荐实现步骤

### 步骤 1: 修改 GTVisualize 类

1. 移除自动退出逻辑，改为可选参数
2. 添加 `auto_exit` 参数控制是否自动退出

### 步骤 2: 创建适配器类

在 `rl_dataset.py` 或新文件中创建 `RLHFDatasetAdapter` 类

### 步骤 3: 在 RLHFDataset 中添加可视化方法

添加 `visualize_dataset` 方法，调用 GTVisualize

### 步骤 4: 使用示例

```python
# 创建数据集
dataset = RLHFDataset(
    data_files=['path/to/data.parquet'],
    tokenizer=tokenizer,
    processor=processor,
    config=config,
)

# 启用可视化
dataset.visualize_dataset(
    output_dir='/path/to/output',
    num_vis=100,
    random_seed=42,
)
```

## 5. 注意事项

1. **labels 字段**: RLHFDataset 不提供 labels，可视化时可能需要跳过或从其他地方获取
2. **conversations 格式**: 需要根据实际的数据格式进行解析
3. **性能**: 可视化会遍历数据集，对于大型数据集可能需要较长时间
4. **依赖**: 确保 `tools/visualize` 模块可以被正确导入
5. **路径**: 注意相对导入路径，可能需要调整 `sys.path` 或使用绝对导入

## 6. 代码修改清单

- [ ] 修改 `GTVisualize.__init__` 添加 `auto_exit` 参数
- [ ] 创建 `RLHFDatasetAdapter` 类
- [ ] 在 `RLHFDataset` 中添加 `visualize_dataset` 方法
- [ ] 添加必要的导入语句
- [ ] 测试集成功能
- [ ] 更新文档

