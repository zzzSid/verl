# -*- coding: utf-8 -*-
"""数据集统计分析工具."""

from __future__ import annotations

import datetime
import getpass

import logging
import os
import random
import re
import math
from glob import glob
from collections import Counter
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import matplotlib.pyplot as plt
import numpy as np
import torch
from matplotlib import font_manager as fm
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.figure import Figure
from tqdm import tqdm
import sys

USER = getpass.getuser()


def get_ymd_hm() -> str:
    now = datetime.datetime.now()
    now_time = now + datetime.timedelta(hours=8)
    daytime = now_time.strftime("%Y%m%d-%H%M")
    return daytime[2:]


@dataclass
class DataStatsAccumulator:
    dataset_counter: Counter[str] = field(default_factory=Counter)
    processed_samples: int = 0
    failed_samples: int = 0

    image_tile_counts: List[int] = field(default_factory=list)
    image_heights: List[int] = field(default_factory=list)
    image_widths: List[int] = field(default_factory=list)
    image_areas: List[int] = field(default_factory=list)
    image_aspect_ratios: List[float] = field(default_factory=list)

    conversation_turns: List[int] = field(default_factory=list)
    message_counts: List[int] = field(default_factory=list)
    question_lengths: List[int] = field(default_factory=list)
    answer_lengths: List[int] = field(default_factory=list)
    system_prompt_lengths: List[int] = field(default_factory=list)
    question_total_chars_per_sample: List[int] = field(default_factory=list)
    answer_total_chars_per_sample: List[int] = field(default_factory=list)
    question_count_per_sample: List[int] = field(default_factory=list)
    answer_count_per_sample: List[int] = field(default_factory=list)

    input_token_lengths: List[int] = field(default_factory=list)
    label_non_ignore_counts: List[int] = field(default_factory=list)
    attention_non_zero_counts: List[int] = field(default_factory=list)
    attention_ratios: List[float] = field(default_factory=list)
    question_chinese_ratio_per_sample: List[float] = field(default_factory=list)
    answer_chinese_ratio_per_sample: List[float] = field(default_factory=list)

    question_chinese_char_total: int = 0
    question_total_char_total: int = 0
    answer_chinese_char_total: int = 0
    answer_total_char_total: int = 0

    multi_image_samples: int = 0
    system_prompt_samples: int = 0
    samples_with_box: int = 0

    special_token_sample_counts: Counter[str] = field(default_factory=Counter)
    special_token_total_counts: Counter[str] = field(default_factory=Counter)


class DataAnalyzer:
    """对 `NIOADOpenShuffleIndexDataset` 进行统计分析."""

    METRIC_LABELS: Dict[str, str] = {
        "image_tile_count": "图像 Tile 数量分布",
        "image_height": "图像高度分布",
        "image_width": "图像宽度分布",
        "image_area": "图像面积分布",
        "image_aspect_ratio": "图像宽高比分布",
        "conversation_turns": "对话轮数分布",
        "messages_per_sample": "每样本消息数分布",
        "question_char_length": "单轮问题字符数分布",
        "answer_char_length": "单轮回答字符数分布",
        "question_chars": "单轮问题字符数分布",
        "answer_chars": "单轮回答字符数分布",
        "question_char_length": "单轮问题字符数分布",
        "answer_char_length": "单轮回答字符数分布",
        "system_prompt_chars": "系统提示字符数分布",
        "question_chars_per_sample": "每样本问题字符数分布",
        "answer_chars_per_sample": "每样本回答字符数分布",
        "question_chinese_ratio_per_sample": "问题中文占比分布",
        "answer_chinese_ratio_per_sample": "回答中文占比分布",
        "question_count_per_sample": "每样本问题轮数分布",
        "answer_count_per_sample": "每样本回答轮数分布",
        "input_ids_length": "input_ids 数量分布",
        "input_token_length": "input_ids 数量分布",
        "label_non_ignore_count": "labels 非 -100 数量分布",
        "attention_non_zero_count": "attention_mask 非 0 数量分布",
        "attention_non_zero_ratio": "attention_mask 非 0 比例分布",
    }

    SPECIAL_TOKEN_PATTERNS: Dict[str, re.Pattern[str]] = {
        "ref": re.compile(r"(?:<ref>.*?</ref>)", re.IGNORECASE | re.DOTALL),
        "coord": re.compile(r"(?:<coord>.*?</coord>|\[UNUSED_TOKEN_4\].*?\[UNUSED_TOKEN_5\])", re.IGNORECASE | re.DOTALL),
        "bbox3d": re.compile(r"(?:<bbox>.*?</bbox>|\[UNUSED_TOKEN_12\].*?\[UNUSED_TOKEN_13\])", re.IGNORECASE | re.DOTALL),
        "speed": re.compile(r"(?:<speed>.*?</speed>|\[UNUSED_TOKEN_14\].*?\[UNUSED_TOKEN_15\])", re.IGNORECASE | re.DOTALL),
        "velocity": re.compile(r"(?:<velocity>.*?</velocity>|\[UNUSED_TOKEN_22\].*?\[UNUSED_TOKEN_23\])", re.IGNORECASE | re.DOTALL),
        "type": re.compile(r"(?:<type>.*?</type>|\[UNUSED_TOKEN_24\].*?\[UNUSED_TOKEN_25\])", re.IGNORECASE | re.DOTALL),
        "bev_coord": re.compile(r"(?:<bev_coord>.*?</bev_coord>|\[UNUSED_TOKEN_34\].*?\[UNUSED_TOKEN_35\])", re.IGNORECASE | re.DOTALL),
    }

    SPECIAL_TOKEN_LABELS: Dict[str, str] = {
        "ref": "引用标记 <ref>",
        "coord": "2D 坐标标记 <coord>",
        "bbox3d": "3D 框标记 <bbox>",
        "speed": "速度标记 <speed>",
        "velocity": "速度向量标记 <velocity>",
        "type": "类别标记 <type>",
        "bev_coord": "BEV 坐标标记 <bev_coord>",
    }

    def __init__(
        self,
        dataset: Any,
        max_samples: Optional[int] = None,
        random_seed: int = 42,
        logger_instance: Optional[logging.Logger] = None,
    ) -> None:
        self.dataset = dataset
        self.logger = logger_instance or logging.getLogger(__name__)
        self.random_seed = random_seed

        dataset_length = len(dataset)
        if max_samples is None or max_samples <= 0:
            self.max_samples = dataset_length
        else:
            self.max_samples = min(max_samples, dataset_length)

        self.box_pattern = re.compile(r"<box>.*?</box>", flags=re.IGNORECASE | re.DOTALL)
        self.save_dir = self._prepare_output_dir()
        print(self.save_dir)
        self._configure_matplotlib_font()

        if dataset_length == 0:
            self.logger.warning("数据集为空，跳过统计分析")
            self.summary: Dict[str, Any] = {}
            self._export_empty_report()
            self.logger.info("数据集统计完成，程序即将退出")
            sys.exit(0)

        self.summary = self._run()
        self._log_summary(self.summary)
        self._export_results(self.summary)
        self.logger.info("数据集统计完成，程序即将退出")

    def _prepare_output_dir(self, output_dir: Optional[str] = None) -> str:
        if output_dir:
            save_dir = output_dir
        else:
            env_dir = os.environ.get("MLM_DATA_ANALYSIS_DIR")
            if env_dir:
                save_dir = env_dir
            else:
                base_dir = f"/home/{USER}/vis"
                os.makedirs(base_dir, exist_ok=True)
                save_dir = os.path.join(base_dir, f"mlm_data_analysis_{get_ymd_hm()}")
        os.makedirs(save_dir, exist_ok=True)
        return save_dir

    def _run(self) -> Dict[str, Any]:
        indices = self._select_indices()
        acc = DataStatsAccumulator()

        iterator = tqdm(indices, desc="data_analysis", leave=False, total=len(indices))
        for idx in iterator:
            sample = self._fetch_sample(idx, acc)
            if sample is None:
                continue

            dataset_name = self._get_dataset_name(idx)
            acc.dataset_counter[dataset_name] += 1

            self._collect_image_stats(sample, acc)
            self._collect_attention_and_token_stats(sample, acc)

            conv_info = self._extract_conversation_info(
                sample.get("conversations_origin_debug"),
                sample.get("conversations_debug"),
            )
            self._collect_conversation_stats(conv_info, acc)

        return self._build_summary(acc)

    def _select_indices(self) -> List[int]:
        total = len(self.dataset)
        indices = list(range(total))
        if self.max_samples < total:
            rng = random.Random(self.random_seed)
            rng.shuffle(indices)
            return indices[: self.max_samples]
        return indices[: self.max_samples]

    def _fetch_sample(self, idx: int, acc: DataStatsAccumulator) -> Optional[Dict[str, Any]]:
        try:
            sample = self.dataset[idx]
        except Exception as exc:  # pylint: disable=broad-except
            acc.failed_samples += 1
            self.logger.warning("数据分析时读取样本 %s 失败: %s", idx, exc)
            return None
        acc.processed_samples += 1
        return sample

    def _get_dataset_name(self, idx: int) -> str:
        raw_data = getattr(self.dataset, "raw_data", None)
        if not raw_data or idx >= len(raw_data):
            return "unknown"
        sample_meta = raw_data[idx]
        if isinstance(sample_meta, (list, tuple)) and len(sample_meta) >= 4:
            return str(sample_meta[3])
        if isinstance(sample_meta, dict):
            return str(sample_meta.get("dataset_name", "unknown"))
        return "unknown"

    def _collect_image_stats(self, sample: Dict[str, Any], acc: DataStatsAccumulator) -> None:
        tile_count, height, width = self._extract_image_dimensions(sample.get("pixel_values"))
        if tile_count:
            acc.image_tile_counts.append(tile_count)
            if tile_count > 1:
                acc.multi_image_samples += 1
        if height and width:
            acc.image_heights.append(height)
            acc.image_widths.append(width)
            acc.image_areas.append(height * width)
            acc.image_aspect_ratios.append(width / float(height))

    @staticmethod
    def _extract_image_dimensions(pixel_values: Any) -> Tuple[int, int, int]:
        if isinstance(pixel_values, torch.Tensor):
            dims = pixel_values.dim()
            if dims == 4:
                return int(pixel_values.shape[0]), int(pixel_values.shape[-2]), int(pixel_values.shape[-1])
            if dims == 3:
                return 1, int(pixel_values.shape[-2]), int(pixel_values.shape[-1])
        elif isinstance(pixel_values, np.ndarray):
            if pixel_values.ndim == 4:
                return int(pixel_values.shape[0]), int(pixel_values.shape[-2]), int(pixel_values.shape[-1])
            if pixel_values.ndim == 3:
                return 1, int(pixel_values.shape[-2]), int(pixel_values.shape[-1])
        return 0, 0, 0

    def _collect_attention_and_token_stats(self, sample: Dict[str, Any], acc: DataStatsAccumulator) -> None:
        attention_mask = sample.get("attention_mask")
        if isinstance(attention_mask, torch.Tensor):
            mask_cpu = attention_mask.to(dtype=torch.float32, device="cpu")
            non_zero = float((mask_cpu != 0).sum().item())
            total_elems = mask_cpu.numel()
            ratio = float(mask_cpu.mean().item()) if total_elems else 0.0
        elif isinstance(attention_mask, np.ndarray):
            mask_np = np.asarray(attention_mask != 0, dtype=np.float32)
            non_zero = float(mask_np.sum())
            total_elems = mask_np.size
            ratio = float(mask_np.mean()) if total_elems else 0.0
        else:
            non_zero = 0
            total_elems = 0
            ratio = 0.0

        if total_elems:
            acc.attention_non_zero_counts.append(non_zero)
            acc.attention_ratios.append(ratio)

        input_ids = sample.get("input_ids")
        if isinstance(input_ids, torch.Tensor):
            acc.input_token_lengths.append(int(input_ids.numel()))
        elif isinstance(input_ids, np.ndarray):
            acc.input_token_lengths.append(int(input_ids.size))

        labels = sample.get("labels")
        if isinstance(labels, torch.Tensor):
            acc.label_non_ignore_counts.append(int((labels != -100).sum().item()))
        elif isinstance(labels, np.ndarray):
            acc.label_non_ignore_counts.append(int(np.count_nonzero(labels != -100)))

    def _collect_conversation_stats(self, conv_info: Dict[str, Any], acc: DataStatsAccumulator) -> None:
        question_texts = conv_info["question_texts"]
        answer_texts = conv_info["answer_texts"]
        system_texts = conv_info["system_texts"]

        acc.conversation_turns.append(conv_info["turns"])
        acc.message_counts.append(conv_info["message_count"])
        acc.question_count_per_sample.append(len(question_texts))
        acc.answer_count_per_sample.append(len(answer_texts))
        acc.question_total_chars_per_sample.append(sum(len(text) for text in question_texts))
        acc.answer_total_chars_per_sample.append(sum(len(text) for text in answer_texts))

        if system_texts:
            acc.system_prompt_samples += 1

        acc.question_lengths.extend(len(text) for text in question_texts)
        acc.answer_lengths.extend(len(text) for text in answer_texts)
        acc.system_prompt_lengths.extend(len(text) for text in system_texts)

        q_char_total = sum(len(text) for text in question_texts)
        if q_char_total > 0:
            q_chinese = sum(self._count_chinese_characters(text) for text in question_texts)
            acc.question_chinese_char_total += q_chinese
            acc.question_total_char_total += q_char_total
            acc.question_chinese_ratio_per_sample.append(q_chinese / q_char_total)

        a_char_total = sum(len(text) for text in answer_texts)
        if a_char_total > 0:
            a_chinese = sum(self._count_chinese_characters(text) for text in answer_texts)
            acc.answer_chinese_char_total += a_chinese
            acc.answer_total_char_total += a_char_total
            acc.answer_chinese_ratio_per_sample.append(a_chinese / a_char_total)

        if conv_info["has_box"]:
            acc.samples_with_box += 1

        special_usage = self._analyze_special_tokens(conv_info)
        for token_key, count in special_usage.items():
            acc.special_token_total_counts[token_key] += count
            acc.special_token_sample_counts[token_key] += 1

    def _build_summary(self, acc: DataStatsAccumulator) -> Dict[str, Any]:
        summary: Dict[str, Any] = {
            "samples_processed": acc.processed_samples,
            "samples_failed": acc.failed_samples,
            "limit": self.max_samples,
            "dataset_distribution": acc.dataset_counter.most_common(),
            "dataset_unique_count": len(acc.dataset_counter),
        }

        numeric_sources: Dict[str, List[Any]] = {
            "image_tile_count": acc.image_tile_counts,
            "image_height": acc.image_heights,
            "image_width": acc.image_widths,
            "image_area": acc.image_areas,
            "image_aspect_ratio": acc.image_aspect_ratios,
            "conversation_turns": acc.conversation_turns,
            "messages_per_sample": acc.message_counts,
            "question_chars": acc.question_lengths,
            "answer_chars": acc.answer_lengths,
            "system_prompt_chars": acc.system_prompt_lengths,
            "question_chars_per_sample": acc.question_total_chars_per_sample,
            "answer_chars_per_sample": acc.answer_total_chars_per_sample,
            "question_count_per_sample": acc.question_count_per_sample,
            "answer_count_per_sample": acc.answer_count_per_sample,
            "question_chinese_ratio_per_sample": acc.question_chinese_ratio_per_sample,
            "answer_chinese_ratio_per_sample": acc.answer_chinese_ratio_per_sample,
            "input_token_length": acc.input_token_lengths,
            "label_non_ignore_count": acc.label_non_ignore_counts,
            "attention_non_zero_count": acc.attention_non_zero_counts,
            "attention_non_zero_ratio": acc.attention_ratios,
        }
        summary["numeric_summaries"] = {
            key: self._numeric_summary(values) for key, values in numeric_sources.items()
        }

        summary["raw_metrics"] = {
            "image_tile_count": acc.image_tile_counts,
            "image_height": acc.image_heights,
            "image_width": acc.image_widths,
            "conversation_turns": acc.conversation_turns,
            "question_char_length": acc.question_lengths,
            "answer_char_length": acc.answer_lengths,
            "input_ids_length": acc.input_token_lengths,
            "label_non_ignore_count": acc.label_non_ignore_counts,
            "attention_non_zero_count": acc.attention_non_zero_counts,
            "attention_non_zero_ratio": acc.attention_ratios,
            "question_count_per_sample": acc.question_count_per_sample,
            "answer_count_per_sample": acc.answer_count_per_sample,
            "messages_per_sample": acc.message_counts,
            "image_aspect_ratio": acc.image_aspect_ratios,
            "question_chinese_ratio_per_sample": acc.question_chinese_ratio_per_sample,
            "answer_chinese_ratio_per_sample": acc.answer_chinese_ratio_per_sample,
        }

        summary["box_dialog_samples"] = acc.samples_with_box
        summary["box_dialog_ratio"] = self._safe_ratio(acc.samples_with_box, acc.processed_samples)
        summary["multi_image_samples"] = acc.multi_image_samples
        summary["multi_image_ratio"] = self._safe_ratio(
            acc.multi_image_samples, acc.processed_samples)
        summary["system_prompt_samples"] = acc.system_prompt_samples
        summary["system_prompt_ratio"] = self._safe_ratio(
            acc.system_prompt_samples, acc.processed_samples)

        summary["question_chinese_ratio_overall"] = self._safe_ratio(
            acc.question_chinese_char_total, acc.question_total_char_total
        )
        summary["answer_chinese_ratio_overall"] = self._safe_ratio(
            acc.answer_chinese_char_total, acc.answer_total_char_total
        )

        special_usage_summary: Dict[str, Dict[str, Any]] = {}
        if acc.processed_samples:
            for key, total in acc.special_token_total_counts.items():
                label = self.SPECIAL_TOKEN_LABELS.get(key, key)
                sample_count = acc.special_token_sample_counts.get(key, 0)
                special_usage_summary[key] = {
                    "label": label,
                    "sample_count": sample_count,
                    "sample_ratio": self._safe_ratio(sample_count, acc.processed_samples),
                    "total_occurrences": total,
                }
        summary["special_token_usage"] = special_usage_summary

        return summary

    @staticmethod
    def _safe_ratio(numerator: float, denominator: float) -> float:
        return (numerator / denominator) if denominator else 0.0

    def _export_empty_report(self) -> None:
        pdf_path = os.path.join(self.save_dir, "数据分析报告.pdf")
        with PdfPages(pdf_path) as pdf:
            fig, ax = plt.subplots(figsize=(8, 4))
            ax.axis("off")
            ax.text(0.5, 0.5, "数据集为空，未生成统计结果", ha="center", va="center", fontsize=14)
            fig.tight_layout()
            pdf.savefig(fig)
            plt.close(fig)

    def _export_results(self, summary: Dict[str, Any]) -> None:
        if not summary:
            return

        figures: List[Figure] = []
        pdf_path = os.path.join(self.save_dir, "数据分析报告.pdf")
        dataset_distribution = summary.get("dataset_distribution", [])
        numeric_summaries = summary.get("numeric_summaries", {})
        raw_metrics = summary.get("raw_metrics", {})

        with PdfPages(pdf_path) as pdf:
            if dataset_distribution:
                fig_dist = self._plot_dataset_distribution(dataset_distribution)
                figures.append(fig_dist)
                dist_path = os.path.join(self.save_dir, "数据集分布.png")
                fig_dist.savefig(dist_path, dpi=200)
                self.logger.info("保存图表: %s", dist_path)
                pdf.savefig(fig_dist)

            special_usage = summary.get("special_token_usage", {})

            if numeric_summaries or special_usage:
                fig_numeric = self._plot_numeric_summary_table(
                    summary, numeric_summaries, special_usage)
                if fig_numeric is not None:
                    figures.append(fig_numeric)
                    numeric_path = os.path.join(self.save_dir, "数值指标统计表.png")
                    fig_numeric.savefig(numeric_path, dpi=200)
                    self.logger.info("保存图表: %s", numeric_path)
                    pdf.savefig(fig_numeric)

            fig_hist_all = self._plot_all_histograms(raw_metrics, special_usage)
            if fig_hist_all is not None:
                figures.append(fig_hist_all)
                hist_all_path = os.path.join(self.save_dir, "所有指标直方图.png")
                fig_hist_all.savefig(hist_all_path, dpi=200)
                self.logger.info("保存图表: %s", hist_all_path)
                pdf.savefig(fig_hist_all)

            fig_text = self._create_text_summary_figure(summary)
            figures.append(fig_text)
            pdf.savefig(fig_text)
            self.logger.info("保存PDF报告: %s", pdf_path)
            self._save_markdown_summary(summary)

        for fig in figures:
            plt.close(fig)

    def _plot_dataset_distribution(self, distribution: List[Tuple[str, int]]) -> Figure:
        names, counts = zip(*distribution)
        fig_height = max(4, len(names) * 0.45)
        fig, ax = plt.subplots(figsize=(10, fig_height))
        ax.barh(range(len(names)), counts, color="#4c72b0")
        ax.set_yticks(range(len(names)))
        ax.set_yticklabels(names)
        ax.set_xlabel("样本数量")
        ax.set_title("数据集样本分布")
        for i, count in enumerate(counts):
            ax.text(count, i, f" {count}", va="center", ha="left", fontsize=9)
        fig.tight_layout()
        return fig

    def _plot_numeric_summary_table(
        self,
        summary: Dict[str, Any],
        numeric_summaries: Dict[str, Dict[str, float]],
        special_usage: Dict[str, Dict[str, Any]],
    ) -> Optional[Figure]:
        rows: List[List[str]] = []
        for key, stats in numeric_summaries.items():
            if not stats:
                continue
            rows.append(
                [
                    self._get_metric_label(key, include_suffix=False),
                    f"{stats['count']:.0f}",
                    self._format_number(stats["min"]),
                    self._format_number(stats["max"]),
                    self._format_number(stats["mean"]),
                    self._format_number(stats["median"]),
                    self._format_number(stats["std"]),
                    self._format_number(stats["p90"]),
                ]
            )

        if not rows:
            return None

        col_labels = ["指标", "数量", "最小值", "最大值", "均值", "中位数", "标准差", "P90"]
        fig_height = max(4, len(rows) * 0.4)
        fig, ax = plt.subplots(figsize=(12, fig_height))
        ax.axis("off")
        table = ax.table(cellText=rows, colLabels=col_labels, loc="center", cellLoc="center")
        table.auto_set_font_size(False)
        table.set_fontsize(9)
        table.scale(1.1, 1.4)

        header_color = "#1f77b4"
        header_text_color = "white"
        row_colors = ("#f2f5fa", "white")

        for col_idx in range(len(col_labels)):
            cell = table[0, col_idx]
            cell.set_facecolor(header_color)
            cell.set_text_props(color=header_text_color, weight="bold")

        for row_idx in range(1, len(rows) + 1):
            face_color = row_colors[(row_idx - 1) % len(row_colors)]
            for col_idx in range(len(col_labels)):
                table[row_idx, col_idx].set_facecolor(face_color)

        if special_usage:
            rows.append(
                [
                    "特殊标记",
                    "样本数",
                    "样本占比",
                    "总出现次数",
                    "",
                    "",
                    "",
                    "",
                ]
            )
            for entry in sorted(
                special_usage.values(),
                key=lambda item: item.get("sample_count", 0),
                reverse=True,
            ):
                rows.append(
                    [
                        f"  {entry['label']}",
                        str(entry["sample_count"]),
                        f"{self._format_number((entry.get('sample_ratio', 0.0) or 0.0) * 100.0)}%",
                        f"{entry['total_occurrences']}",
                        "",
                        "",
                        "",
                        "",
                    ]
                )

        ax.set_title("数值指标统计", pad=20)
        fig.tight_layout()
        return fig

    def _plot_all_histograms(
        self,
        raw_metrics: Dict[str, List[Any]],
        special_usage: Dict[str, Dict[str, Any]],
    ) -> Optional[Figure]:
        metric_items = [(key, values) for key, values in raw_metrics.items() if values]
        has_special_plot = bool(special_usage)
        if not metric_items and not has_special_plot:
            return None

        total_plots = len(metric_items) + (1 if has_special_plot else 0)
        cols = min(3, total_plots) if total_plots else 1
        rows = math.ceil(total_plots / cols) if cols else 1
        fig, axes = plt.subplots(rows, cols, figsize=(cols * 5, rows * 3.5))

        if isinstance(axes, np.ndarray):
            axes_flat = axes.flatten()
        else:
            axes_flat = [axes]

        color_palette = [
            "#1f77b4",
            "#ff7f0e",
            "#2ca02c",
            "#d62728",
            "#9467bd",
            "#8c564b",
            "#e377c2",
            "#7f7f7f",
            "#bcbd22",
            "#17becf",
        ]

        current_idx = 0
        for key, values in metric_items:
            ax = axes_flat[current_idx]
            arr = np.asarray(values, dtype=np.float64)
            bins = 30 if arr.size > 30 else max(10, arr.size)
            ax.set_title(self._get_metric_label(key))
            ax.set_xlabel("取值")
            ax.set_ylabel("频数")
            color = color_palette[current_idx % len(color_palette)]
            ax.hist(arr, bins=bins, color=color, edgecolor="black", alpha=0.75)
            ax.grid(axis="y", linestyle="--", alpha=0.3)
            current_idx += 1

        if has_special_plot and current_idx < len(axes_flat):
            ax = axes_flat[current_idx]
            sorted_entries = sorted(
                special_usage.values(),
                key=lambda item: item.get("sample_count", 0),
                reverse=True,
            )
            tokens = [entry["label"] for entry in sorted_entries]
            sample_counts = [entry["sample_count"] for entry in sorted_entries]
            ratios = [entry["sample_ratio"] * 100.0 for entry in sorted_entries]
            totals = [entry["total_occurrences"] for entry in sorted_entries]
            indices = np.arange(len(sorted_entries))
            width = 0.4

            ax.bar(indices - width / 2, sample_counts, width=width, color="#1f77b4", label="样本数")
            ax.bar(indices + width / 2, totals, width=width, color="#ff7f0e", label="总次数")
            for idx_bar, ratio in enumerate(ratios):
                ax.text(
                    indices[idx_bar],
                    max(sample_counts[idx_bar], totals[idx_bar]) *
                    1.02 if sample_counts[idx_bar] or totals[idx_bar] else 0.5,
                    f"{ratio:.1f}%",
                    ha="center",
                    va="bottom",
                    fontsize=9,
                )
            ax.set_xticks(indices)
            ax.set_xticklabels(tokens, rotation=20, ha="right")
            ax.set_ylabel("数量")
            ax.set_title("特殊标记使用情况")
            ax.legend()
            ax.grid(axis="y", linestyle="--", alpha=0.3)
            current_idx += 1

        for idx in range(current_idx, len(axes_flat)):
            fig.delaxes(axes_flat[idx])

        fig.tight_layout()
        return fig

    def _create_text_summary_figure(self, summary: Dict[str, Any]) -> Figure:
        lines = [
            "数据分析概要",
            f"样本总数: {summary.get('samples_processed', 0)} (失败 {summary.get('samples_failed', 0)})",
            f"采样上限: {summary.get('limit', 0)}",
            f"含 <box> 对话样本: {summary.get('box_dialog_samples', 0)} (比例 {self._format_number((summary.get('box_dialog_ratio', 0.0) or 0.0) * 100.0)}%)",
            "",
        ]
        dataset_distribution = summary.get("dataset_distribution", [])
        if dataset_distribution:
            lines.append("数据集分布:")
            for name, count in dataset_distribution:
                lines.append(f"  - {name}: {count}")
            lines.append("")

        lines.append(
            f"包含多图样本: {summary.get('multi_image_samples', 0)} "
            f"(比例 {self._format_number((summary.get('multi_image_ratio', 0.0) or 0.0) * 100.0)}%)"
        )
        lines.append(
            f"包含系统提示样本: {summary.get('system_prompt_samples', 0)} "
            f"(比例 {self._format_number((summary.get('system_prompt_ratio', 0.0) or 0.0) * 100.0)}%)"
        )
        lines.append(
            f"问题文本中文占比(总体): {self._format_number((summary.get('question_chinese_ratio_overall', 0.0) or 0.0) * 100.0)}%"
        )
        lines.append(
            f"回答文本中文占比(总体): {self._format_number((summary.get('answer_chinese_ratio_overall', 0.0) or 0.0) * 100.0)}%"
        )
        lines.append("")

        special_usage = summary.get("special_token_usage", {})
        if special_usage:
            lines.append("特殊标记使用情况:")
            for entry in sorted(
                special_usage.values(),
                key=lambda item: item.get("sample_count", 0),
                reverse=True,
            ):
                lines.append(
                    f"  - {entry['label']}: 样本 {entry['sample_count']} "
                    f"({self._format_number((entry.get('sample_ratio', 0.0) or 0.0) * 100.0)}%), "
                    f"总次数 {entry['total_occurrences']}"
                )
            lines.append("")

        fig, ax = plt.subplots(figsize=(10, max(4, len(lines) * 0.4)))
        ax.axis("off")
        y = 0.95
        for line in lines:
            ax.text(0.01, y, line, fontsize=12, ha="left", va="top")
            y -= 0.05
        fig.tight_layout()
        return fig

    def _save_markdown_summary(self, summary: Dict[str, Any]) -> None:
        if not summary:
            return

        md_path = os.path.join(self.save_dir, "数据分析概览.md")
        lines: List[str] = [
            "# 数据分析报告",
            "",
            f"- 样本总数: {summary.get('samples_processed', 0)}",
            f"- 采样上限: {summary.get('limit', 0)}",
            f"- 失败样本: {summary.get('samples_failed', 0)}",
            f"- 含 `<box>` 对话样本: {summary.get('box_dialog_samples', 0)} "
            f"({self._format_number((summary.get('box_dialog_ratio', 0.0) or 0.0) * 100.0)}%)",
            f"- 包含多图样本: {summary.get('multi_image_samples', 0)} "
            f"({self._format_number((summary.get('multi_image_ratio', 0.0) or 0.0) * 100.0)}%)",
            f"- 包含系统提示样本: {summary.get('system_prompt_samples', 0)} "
            f"({self._format_number((summary.get('system_prompt_ratio', 0.0) or 0.0) * 100.0)}%)",
            f"- 问题文本中文占比(总体): "
            f"{self._format_number((summary.get('question_chinese_ratio_overall', 0.0) or 0.0) * 100.0)}%",
            f"- 回答文本中文占比(总体): "
            f"{self._format_number((summary.get('answer_chinese_ratio_overall', 0.0) or 0.0) * 100.0)}%",
            "",
        ]

        dataset_distribution = summary.get("dataset_distribution", [])
        if dataset_distribution:
            lines.extend(
                [
                    "## 数据集分布",
                    "",
                    "| 数据集名称 | 样本数 |",
                    "|:---|---:|",
                ]
            )
            for name, count in dataset_distribution:
                lines.append(f"| {name} | {count} |")
            lines.append("")

        numeric_summaries = summary.get("numeric_summaries", {})
        if numeric_summaries:
            lines.extend(
                [
                    "## 数值指标统计",
                    "",
                    "| 指标 | 样本数 | 最小值 | 最大值 | 均值 | 中位数 | 标准差 | P90 |",
                    "|:---|---:|---:|---:|---:|---:|---:|---:|",
                ]
            )
            for key, stats in numeric_summaries.items():
                if not stats:
                    continue
                name = self._get_metric_label(key, include_suffix=False)
                line = (
                    f"| {name} | {stats['count']:.0f} | "
                    f"{self._format_number(stats['min'])} | {self._format_number(stats['max'])} | "
                    f"{self._format_number(stats['mean'])} | {self._format_number(stats['median'])} | "
                    f"{self._format_number(stats['std'])} | {self._format_number(stats['p90'])} |"
                )
                lines.append(line)
            lines.append("")

        special_usage = summary.get("special_token_usage", {})
        if special_usage:
            lines.extend(
                [
                    "## 特殊标记使用情况",
                    "",
                    "| 标记 | 样本数 | 样本占比 | 总出现次数 | 备注 |",
                    "|:---|---:|---:|---:|:---|",
                ]
            )
            for entry in sorted(
                special_usage.values(),
                key=lambda item: item.get("sample_count", 0),
                reverse=True,
            ):
                lines.append(
                    f"| {entry['label']} | {entry['sample_count']} | "
                    f"{self._format_number((entry.get('sample_ratio', 0.0) or 0.0) * 100.0)}% | "
                    f"{entry['total_occurrences']} | - |"
                )
            lines.append("")

        with open(md_path, "w", encoding="utf-8") as md_file:
            md_file.write("\n".join(lines))
        self.logger.info("保存Markdown统计: %s", md_path)

    def _analyze_special_tokens(self, conv_info: Dict[str, Any]) -> Dict[str, int]:
        texts = (
            conv_info.get("question_texts", [])
            + conv_info.get("answer_texts", [])
            + conv_info.get("system_texts", [])
        )
        combined = "\n".join(text for text in texts if text)
        if not combined:
            return {}

        usage: Dict[str, int] = {}
        for key, pattern in self.SPECIAL_TOKEN_PATTERNS.items():
            matches = pattern.findall(combined)
            if matches:
                usage[key] = len(matches)
        return usage

    @staticmethod
    def _count_chinese_characters(text: str) -> int:
        if not text:
            return 0
        return len(re.findall(r"[\u4e00-\u9fff]", text))

    def _configure_matplotlib_font(self) -> None:
        plt.rcParams["axes.unicode_minus"] = False

        env_font_path = os.environ.get("MLM_DATA_ANALYSIS_FONT_PATH")
        env_font_name = os.environ.get("MLM_DATA_ANALYSIS_FONT_NAME")

        candidate_font_names = [
            "WenQuanYi Micro Hei",
            "SimHei",
            "Noto Sans CJK SC",
            "Noto Sans SC",
            "Noto Sans CJK",
            "Microsoft YaHei",
            "PingFang SC",
            "Arial Unicode MS",
        ]
        candidate_font_paths = [
            "/lustre/neos.yan/wqy-microhei.ttc",
            "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
            "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
            "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
            "/usr/share/fonts/opentype/noto/NotoSansCJKsc-Regular.otf",
            "/usr/share/fonts/truetype/noto/NotoSansCJKsc-Regular.otf",
            "/usr/share/fonts/truetype/arphic/uming.ttc",
            "/System/Library/Fonts/PingFang.ttc",
            "/System/Library/Fonts/STHeiti Medium.ttc",
            "/Library/Fonts/Songti.ttc",
            "/Windows/Fonts/simhei.ttf",
            "/Windows/Fonts/msyh.ttc",
        ]

        project_font_dir = os.path.join(os.path.dirname(__file__), "fonts")
        if os.path.isdir(project_font_dir):
            for font_file in os.listdir(project_font_dir):
                if font_file.lower().endswith((".ttf", ".ttc", ".otf")):
                    candidate_font_paths.append(os.path.join(project_font_dir, font_file))

        search_dirs = [
            "/usr/share/fonts",
            "/usr/local/share/fonts",
            os.path.expanduser("~/.fonts"),
            os.path.expanduser("~/.local/share/fonts"),
        ]
        for directory in search_dirs:
            if not directory or not os.path.isdir(directory):
                continue
            candidate_font_paths.extend(
                glob(os.path.join(directory, "**", "NotoSansCJK*.tt[cf]"), recursive=True)
            )
            candidate_font_paths.extend(
                glob(os.path.join(directory, "**", "SourceHanSansSC*.otf"), recursive=True)
            )
            candidate_font_paths.extend(
                glob(os.path.join(directory, "**", "SimHei*.ttf"), recursive=True)
            )

        if env_font_path:
            candidate_font_paths.insert(0, env_font_path)
        if env_font_name:
            candidate_font_names.insert(0, env_font_name)

        chosen_font: Optional[str] = None

        for name in candidate_font_names:
            if not name:
                continue
            try:
                font_path = fm.findfont(name, fallback_to_default=False)
                if font_path and os.path.exists(font_path):
                    chosen_font = name
                    break
            except Exception:  # pylint: disable=broad-except
                continue

        if chosen_font is None:
            for path in candidate_font_paths:
                if not os.path.exists(path):
                    continue
                try:
                    fm.fontManager.addfont(path)
                    font_prop = fm.FontProperties(fname=path)
                    chosen_font = font_prop.get_name()
                    break
                except Exception as exc:  # pylint: disable=broad-except
                    self.logger.debug("加载字体失败 %s: %s", path, exc)

        if chosen_font is None:
            if candidate_font_paths:
                self.logger.warning(
                    "未找到合适中文字体，请检查路径: %s 或设置环境变量 MLM_DATA_ANALYSIS_FONT_PATH",
                    candidate_font_paths,
                )
            chosen_font = "DejaVu Sans"
            self.logger.warning("未找到中文字体，回退使用 %s", chosen_font)
        else:
            self.logger.info("使用字体渲染图表: %s", chosen_font)

        plt.rcParams["font.family"] = "sans-serif"
        plt.rcParams["font.sans-serif"] = [chosen_font, "DejaVu Sans", "Arial", "Liberation Sans"]

    def _extract_conversation_info(
        self,
        conversations_origin: Optional[List[Any]],
        conversations_debug: Optional[List[Any]],
    ) -> Dict[str, Any]:
        segments: List[Tuple[str, str]] = []
        if conversations_origin:
            for item in conversations_origin:
                if isinstance(item, dict):
                    role = str(item.get("from", "unknown")).lower()
                    value = item.get("value", "")
                    segments.append((role, value if isinstance(value, str) else str(value)))
                else:
                    segments.append(("unknown", str(item)))
        elif conversations_debug:
            for segment in conversations_debug:
                text_segment = segment if isinstance(segment, str) else str(segment)
                role = self._infer_role_from_segment(text_segment)
                content = self._extract_segment_content(text_segment)
                segments.append((role, content))

        question_texts = [text for role, text in segments if role in ("human", "user")]
        answer_texts = [text for role, text in segments if role in ("gpt", "assistant")]
        system_texts = [text for role, text in segments if role == "system"]

        has_box = any(self.box_pattern.search(text) for text in question_texts + answer_texts)
        turns = max(len(question_texts), len(answer_texts))

        return {
            "question_texts": question_texts,
            "answer_texts": answer_texts,
            "system_texts": system_texts,
            "has_box": has_box,
            "turns": turns,
            "message_count": len(segments),
        }

    @staticmethod
    def _infer_role_from_segment(segment: str) -> str:
        lowered = segment.lower()
        if "<|im_start|>assistant" in lowered:
            return "assistant"
        if "<|im_start|>gpt" in lowered:
            return "gpt"
        if "<|im_start|>user" in lowered:
            return "human"
        if "<|im_start|>human" in lowered:
            return "human"
        if "<|im_start|>system" in lowered:
            return "system"
        return "unknown"

    @staticmethod
    def _extract_segment_content(segment: str) -> str:
        if not segment:
            return ""
        start_idx = segment.find("\n")
        if start_idx == -1:
            start_idx = 0
        else:
            start_idx += 1
        end_marker = segment.lower().rfind("<|im_end|>")
        end_idx = end_marker if end_marker != -1 else len(segment)
        content = segment[start_idx:end_idx]
        return content.strip()

    @staticmethod
    def _numeric_summary(values: List[Any]) -> Dict[str, float]:
        if not values:
            return {}
        arr = np.asarray(values, dtype=np.float64)
        if arr.size == 0:
            return {}
        return {
            "count": float(arr.size),
            "min": float(np.min(arr)),
            "max": float(np.max(arr)),
            "mean": float(np.mean(arr)),
            "median": float(np.median(arr)),
            "std": float(np.std(arr)),
            "p90": float(np.percentile(arr, 90)),
        }

    @staticmethod
    def _format_number(value: Optional[float], decimal_places: int = 1) -> str:
        if value is None:
            return "-"
        try:
            numeric = float(value)
        except (TypeError, ValueError):
            return "-"
        if math.isnan(numeric) or math.isinf(numeric):
            return "-"
        rounded = round(numeric, decimal_places)
        int_candidate = round(rounded)
        tolerance = 10 ** (-(decimal_places + 2))
        if math.isclose(rounded, int_candidate, abs_tol=tolerance):
            return str(int(int_candidate))
        formatted = f"{rounded:.{decimal_places}f}".rstrip("0").rstrip(".")
        return formatted if formatted else "0"

    def _get_metric_label(self, key: str, include_suffix: bool = True) -> str:
        label = self.METRIC_LABELS.get(key)
        if label:
            return label if include_suffix else label.replace("分布", "")
        # fallback: replace underscores with spaces and translate columns minimally
        readable = key.replace("_", " ")
        return readable if include_suffix else readable

    def _log_summary(self, summary: Dict[str, Any]) -> None:
        if not summary:
            return
        self.logger.info(
            "[数据统计] 样本量: %s/%s (失败 %s)",
            summary.get("samples_processed"),
            summary.get("limit"),
            summary.get("samples_failed"),
        )
        dataset_distribution = summary.get("dataset_distribution", [])
        if dataset_distribution:
            self.logger.info("[数据统计] 数据集分布: %s", dataset_distribution)
        box_ratio = summary.get("box_dialog_ratio", 0.0) or 0.0
        box_ratio_str = self._format_number(box_ratio * 100.0)
        self.logger.info(
            "[数据统计] 含 <box> 对话样本: %s (比例 %s%%)",
            summary.get("box_dialog_samples"),
            box_ratio_str,
        )
        multi_ratio = summary.get("multi_image_ratio", 0.0) or 0.0
        system_ratio = summary.get("system_prompt_ratio", 0.0) or 0.0
        self.logger.info(
            "[数据统计] 多图样本: %s (比例 %s%%)",
            summary.get("multi_image_samples"),
            self._format_number(multi_ratio * 100.0),
        )
        self.logger.info(
            "[数据统计] 系统提示样本: %s (比例 %s%%)",
            summary.get("system_prompt_samples"),
            self._format_number(system_ratio * 100.0),
        )
        self.logger.info(
            "[数据统计] 问题中文占比(总体): %s%%",
            self._format_number(
                (summary.get("question_chinese_ratio_overall", 0.0) or 0.0) * 100.0),
        )
        self.logger.info(
            "[数据统计] 回答中文占比(总体): %s%%",
            self._format_number((summary.get("answer_chinese_ratio_overall", 0.0) or 0.0) * 100.0),
        )

        numeric_summaries = summary.get("numeric_summaries", {})
        for key, stats in numeric_summaries.items():
            if not stats:
                continue
            formatted = (
                f"count={stats['count']:.0f}, "
                f"min={self._format_number(stats['min'])}, "
                f"max={self._format_number(stats['max'])}, "
                f"mean={self._format_number(stats['mean'])}, "
                f"median={self._format_number(stats['median'])}, "
                f"std={self._format_number(stats['std'])}, "
                f"p90={self._format_number(stats['p90'])}"
            )
            label = self._get_metric_label(key)
            self.logger.info("[数据统计] %s: %s", label, formatted)

        special_usage = summary.get("special_token_usage", {})
        for entry in sorted(
            special_usage.values(),
            key=lambda item: item.get("sample_count", 0),
            reverse=True,
        ):
            self.logger.info(
                "[数据统计] %s: 样本 %s (比例 %s%%), 总次数 %s",
                entry["label"],
                entry["sample_count"],
                self._format_number((entry.get("sample_ratio", 0.0) or 0.0) * 100.0),
                entry["total_occurrences"],
            )


__all__ = ["DataAnalyzer"]
