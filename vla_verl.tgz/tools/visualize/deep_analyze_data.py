# -*- coding: utf-8 -*-
"""通用深度数据结构分析工具。"""

import numpy as np
from typing import Any, List
import torch


def _format_numeric_values(values: List[Any]) -> List[str]:
    """格式化数值列表，浮点数保留3位有效数字."""
    formatted = []
    for v in values:
        if isinstance(v, (float, np.floating)):
            formatted.append(f"{float(v):.3g}")
        else:
            formatted.append(str(v))
    return formatted


def deep_analyze_data(data: Any, max_depth: int = 5, current_depth: int = 0, max_items: int = 10,
                      show_values: bool = True, max_display_values: int = 3) -> str:
    """深度递归分析任何数据结构，返回详细的字符串描述."""
    if current_depth >= max_depth:
        return f"{'  ' * current_depth}... (达到最大深度 {max_depth})"

    indent = "  " * current_depth

    if data is None:
        return f"{indent}None"

    if isinstance(data, (int, float, str, bool)):
        if isinstance(data, float):
            formatted_value = f"{data:.3g}"
            return f"{indent}{type(data).__name__}: {formatted_value}"
        else:
            return f"{indent}{type(data).__name__}: {data}"

    if isinstance(data, torch.Tensor):
        shape_str = f"shape{list(data.shape)}" if hasattr(data, 'shape') else "no_shape"
        dtype_str = f"dtype={data.dtype}" if hasattr(data, 'dtype') else "no_dtype"
        device_str = f"device={data.device}" if hasattr(data, 'device') else "no_device"
        requires_grad = f"requires_grad={data.requires_grad}" if hasattr(
            data, 'requires_grad') else "no_requires_grad"

        if show_values and hasattr(data, 'numel') and data.numel() > 0:
            try:
                if data.numel() <= max_display_values:
                    values = data.flatten().tolist()
                    formatted_values = _format_numeric_values(values)
                    sample_values = f"values={formatted_values}"
                else:
                    values = data.flatten()[:max_display_values].tolist()
                    formatted_values = _format_numeric_values(values)
                    sample_values = f"sample_values={formatted_values}... (共{data.numel()}个)"
                return f"{indent}torch.Tensor: {shape_str}, {dtype_str}, {device_str}, {requires_grad}, {sample_values}"
            except Exception as e:
                sample_values = f"sample_values_error={str(e)}"
                return f"{indent}torch.Tensor: {shape_str}, {dtype_str}, {device_str}, {requires_grad}, {sample_values}"
        else:
            return f"{indent}torch.Tensor: {shape_str}, {dtype_str}, {device_str}, {requires_grad}"

    if isinstance(data, np.ndarray):
        shape_str = f"shape{list(data.shape)}" if hasattr(data, 'shape') else "no_shape"
        dtype_str = f"dtype={data.dtype}" if hasattr(data, 'dtype') else "no_dtype"
        if show_values and hasattr(data, 'size') and data.size > 0:
            try:
                if data.size <= max_display_values:
                    values = data.flatten()[:data.size].tolist()
                    formatted_values = _format_numeric_values(values)
                    sample_values = f"values={formatted_values}"
                else:
                    values = data.flatten()[:max_display_values].tolist()
                    formatted_values = _format_numeric_values(values)
                    sample_values = f"sample_values={formatted_values}... (共{data.size}个)"
                return f"{indent}np.ndarray: {shape_str}, {dtype_str}, {sample_values}"
            except Exception as e:
                sample_values = f"sample_values_error={str(e)}"
                return f"{indent}np.ndarray: {shape_str}, {dtype_str}, {sample_values}"
        else:
            return f"{indent}np.ndarray: {shape_str}, {dtype_str}"

    if isinstance(data, dict):
        if not data:
            return f"{indent}dict: {{}} (空字典)"
        result = [f"{indent}dict: {{"]
        items = list(data.items())[:max_items]
        for key, value in items:
            key_str = str(key)
            value_str = deep_analyze_data(value, max_depth, current_depth + 1, max_items,
                                          show_values=show_values, max_display_values=max_display_values)
            result.append(f"{indent}  {key_str}: {value_str}")
        if len(data) > max_items:
            result.append(f"{indent}  ... (还有 {len(data) - max_items} 个项目)")
        result.append(f"{indent}}}")
        return "\n".join(result)

    if isinstance(data, list):
        if not data:
            return f"{indent}list: [] (空列表)"
        result = [f"{indent}list: ["]
        items = data[:max_items]
        for i, item in enumerate(items):
            item_str = deep_analyze_data(item, max_depth, current_depth + 1, max_items,
                                         show_values=show_values, max_display_values=max_display_values)
            result.append(f"{indent}  [{i}]: {item_str}")
        if len(data) > max_items:
            result.append(f"{indent}  ... (还有 {len(data) - max_items} 个项目)")
        result.append(f"{indent}]")
        return "\n".join(result)

    if isinstance(data, tuple):
        if not data:
            return f"{indent}tuple: () (空元组)"
        result = [f"{indent}tuple: ("]
        items = data[:max_items]
        for i, item in enumerate(items):
            item_str = deep_analyze_data(item, max_depth, current_depth + 1, max_items,
                                         show_values=show_values, max_display_values=max_display_values)
            result.append(f"{indent}  ({i}): {item_str}")
        if len(data) > max_items:
            result.append(f"{indent}  ... (还有 {len(data) - max_items} 个项目)")
        result.append(f"{indent})")
        return "\n".join(result)

    if isinstance(data, set):
        if not data:
            return f"{indent}set: set() (空集合)"
        result = [f"{indent}set: {{"]
        items = list(data)[:max_items]
        for item in items:
            item_str = deep_analyze_data(item, max_depth, current_depth + 1, max_items,
                                         show_values=show_values, max_display_values=max_display_values)
            result.append(f"{indent}  {item_str}")
        if len(data) > max_items:
            result.append(f"{indent}  ... (还有 {len(data) - max_items} 个项目)")
        result.append(f"{indent}}}")
        return "\n".join(result)

    if hasattr(data, '__dict__') or hasattr(data, '__slots__'):
        class_name = data.__class__.__name__
        attrs = {}
        try:
            if hasattr(data, '__dict__'):
                attrs.update(data.__dict__)
            if hasattr(data, '__slots__'):
                for slot in data.__slots__:
                    if hasattr(data, slot):
                        attrs[slot] = getattr(data, slot)
        except Exception as e:
            attrs = {"error": f"无法获取属性: {str(e)}"}
        if not attrs:
            return f"{indent}{class_name}: 无属性"
        result = [f"{indent}{class_name}: {{"]
        items = list(attrs.items())[:max_items]
        for attr_name, attr_value in items:
            attr_str = deep_analyze_data(attr_value, max_depth, current_depth + 1, max_items,
                                         show_values=show_values, max_display_values=max_display_values)
            result.append(f"{indent}  {attr_name}: {attr_str}")
        if len(attrs) > max_items:
            result.append(f"{indent}  ... (还有 {len(attrs) - max_items} 个属性)")
        result.append(f"{indent}}}")
        return "\n".join(result)

    try:
        if hasattr(data, '__len__'):
            length = len(data)
            return f"{indent}{type(data).__name__}: 长度={length}, 内容={str(data)[:100]}..."
        else:
            return f"{indent}{type(data).__name__}: {str(data)[:100]}..."
    except Exception as e:
        return f"{indent}{type(data).__name__}: 无法获取详细信息 (错误: {str(e)})"


def analyze_data_structure_public(data: Any, max_depth: int = 5, max_items: int = 10) -> str:
    """公共的数据结构分析函数，可以分析任何类型的数据."""
    result = []
    result.append("=" * 100)
    result.append("深度数据结构分析")
    result.append("=" * 100)
    result.append(f"数据类型: {type(data)}")
    result.append(f"数据ID: {id(data)}")
    analysis = deep_analyze_data(data, max_depth, 0, max_items)
    result.append(analysis)
    result.append("=" * 100)
    result.append("分析完成")
    result.append("=" * 100)
    return "\n".join(result)


def quick_analyze_data(data: Any, max_depth: int = 3, max_items: int = 5) -> str:
    """快速分析数据结构，不显示数值内容，输出更简洁."""
    return deep_analyze_data(data, max_depth=max_depth, current_depth=0, max_items=max_items,
                             show_values=False, max_display_values=3)
