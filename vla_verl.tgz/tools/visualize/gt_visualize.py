# -*- coding: utf-8 -*-
"""GT Visualization Tool for MLM Dataset."""

import datetime
import getpass
import logging
import math
import os
import re
import cv2
import numpy as np
import torch
from collections import Counter
from typing import Dict, Any, List, Tuple, Optional
from PIL import Image, ImageDraw, ImageFont

USER = getpass.getuser()
logger = logging.getLogger(__name__)


def get_ymd_hm():
    """Get time."""
    now = datetime.datetime.now()
    now_time = now + datetime.timedelta(hours=8)
    daytime = now_time.strftime("%Y%m%d-%H%M")
    return daytime[2:]


def denormalize_image(img_np: np.ndarray, mean: Tuple[float, float, float] = None,
                      std: Tuple[float, float, float] = None) -> np.ndarray:
    """反归一化图像，将归一化后的图像转换回0-255范围.

    Args:
        img_np: 归一化后的图像数组，shape为(C, H, W)或(H, W, C)
        mean: 归一化时使用的均值，默认为ImageNet的均值
        std: 归一化时使用的标准差，默认为ImageNet的标准差

    Returns:
        反归一化后的图像数组，uint8类型，范围0-255
    """
    if mean is None:
        mean = (0.485, 0.456, 0.406)  # ImageNet mean
    if std is None:
        std = (0.229, 0.224, 0.225)  # ImageNet std

    mean = np.array(mean).reshape(-1, 1,
                                  1) if img_np.ndim == 3 and img_np.shape[0] == 3 else np.array(mean)
    std = np.array(std).reshape(-1, 1,
                                1) if img_np.ndim == 3 and img_np.shape[0] == 3 else np.array(std)

    # 反归一化: img = (img_norm * std) + mean
    img = img_np * std + mean

    # 裁剪到0-1范围
    img = np.clip(img, 0.0, 1.0)

    # 转换为0-255范围
    img = (img * 255.0).astype(np.uint8)

    return img


def convert_tensor_to_image(pixel_values: torch.Tensor, denorm: bool = True) -> np.ndarray:
    """将pixel_values张量转换为numpy图像数组.

    Args:
        pixel_values: 图像张量，shape为(C, H, W)或(B, C, H, W)
        denorm: 是否进行反归一化

    Returns:
        转换后的图像数组，shape为(H, W, C)或(B, H, W, C)，uint8类型
    """
    if isinstance(pixel_values, torch.Tensor):
        img_np = pixel_values.detach().cpu().numpy()
    else:
        img_np = np.array(pixel_values)

    # 如果是(B, C, H, W)格式，转换为(B, H, W, C)
    if img_np.ndim == 4:
        img_np = np.transpose(img_np, (0, 2, 3, 1))  # (B, H, W, C)
    elif img_np.ndim == 3:
        img_np = np.transpose(img_np, (1, 2, 0))  # (H, W, C)

    # 如果值在-2到2之间，可能是归一化后的，需要反归一化
    if denorm and img_np.dtype in [np.float32, np.float64]:
        if img_np.min() < -1.0 or img_np.max() > 2.0:
            # 可能是已经归一化的，需要反归一化
            img_np = denormalize_image(img_np)
        elif img_np.max() <= 1.0:
            # 在0-1范围，直接转换为0-255
            img_np = (img_np * 255.0).astype(np.uint8)
        else:
            # 已经在0-255范围，直接转换类型
            img_np = np.clip(img_np, 0, 255).astype(np.uint8)

    return img_np


class GTVisualize:
    """GT Visualization Class for MLM Dataset."""

    def __init__(
        self,
        dataset,
        output_dir: str = None,
        num_vis: int = 200,
        random_seed: int = 42,
        max_total_width: Optional[int] = 6000,
    ):
        """Initialize visualization class.

        Args:
            dataset: 数据集对象
            output_dir: 输出目录，如果为None则使用默认目录
            num_vis: 可视化的样本数量
            random_seed: 随机种子
        """
        self.dataset = dataset

        if output_dir is None:
            self.save_dir = f"/home/{USER}/vis/mlm_gt_{get_ymd_hm()}"
        else:
            self.save_dir = output_dir
        
        print(self.save_dir)

        os.makedirs(self.save_dir, exist_ok=True)
        logger.info(f"Maked dir: {self.save_dir} num_vis={num_vis}")

        self.num_vis = num_vis
        self.random_seed = int(random_seed)
        self.frame_count = 0

        self.max_total_width = max_total_width

        self._set_config()

        # 开始可视化
        self.visualize_samples()

        # 初始化完成后退出程序
        logger.info("数据集可视化完成，程序即将退出")

    def _set_config(self) -> None:
        """初始化可视化过程中使用的超参数配置."""
        # 网格显示尺寸及标题设置
        self.GRID_DISPLAY_SIZE = 448
        self.TITLE_HEIGHT = 20
        self.TITLE_FONT_SCALE = 0.6
        self.TITLE_FONT_THICKNESS = 2
        self.TITLE_TEXT_OFFSET = (5, 15)

        # 信息图字体配置
        self.INFO_FONT_SCALE = 1.0
        self.INFO_FONT_THICKNESS = 2
        self.INFO_LINE_HEIGHT = 40
        self.INFO_TEXT_X = 20

        # 左侧布局与间距
        self.LEFT_COLUMN_TOP_PADDING = 30
        self.LEFT_COLUMN_HEADER_HEIGHT = 30
        self.CONCAT_SPACING = 20
        self.CONCAT_PADDING = 10
        self.CONCAT_TITLE_HEIGHT = 50
        self.CONCAT_TITLE_BASELINE = 30
        self.CONVERSATION_SPACING = 10
        self.RIGHT_COLUMN_SPACING = 10
        self.MIN_AVAILABLE_WIDTH = 500
        self.CONCAT_TITLE_FONT_SCALE = 1.0
        self.CONCAT_TITLE_FONT_THICKNESS = 2

        # image_flags 文本绘制配置
        self.IMAGE_FLAGS_TEXT_MARGIN = 20
        self.IMAGE_FLAGS_FONT_SCALE = 0.6
        self.IMAGE_FLAGS_FONT_THICKNESS = 2
        self.IMAGE_FLAGS_TEXT_POSITION = (10, 30)

        # 文字图像相关配置
        self.TEXT_IMAGE_CONFIG = {
            "max_width": 800,
            "font_size": 16,
            "line_spacing": 5,
            "padding": 10,
            "max_chars_per_line": 75,
        }
        self.COLORED_TEXT_MAX_WIDTH = 800
        self.CONVERSATIONS_TEXT_MAX_WIDTH = 1000
        self.TEXT_NON_CHINESE_SCALE = 1.5

    def visualize_samples(self) -> None:
        """按固定随机采样索引批量生成与保存可视化图."""
        total = len(self.dataset)
        if total <= 0:
            logger.warning("Dataset is empty")
            return

        sample_num = min(self.num_vis, total)
        rng = np.random.RandomState(self.random_seed)
        sample_indices = rng.choice(total, size=sample_num, replace=False)
        sample_indices = np.sort(sample_indices)

        for idx in sample_indices:
            idx = int(idx)
            data_dict = self.dataset[idx]
            # 创建可视化图像
            vis_image = self.create_visualization(data_dict, idx)

            # 保存图像
            if vis_image is not None and self.save_dir:
                frame_name = f"sample_{idx:06d}"
                dataset_component = self._sanitize_filename_component(
                    data_dict.get('dataset_name_debug'))
                if dataset_component:
                    frame_name = f"{frame_name}_{dataset_component}"
                frame_save_path = os.path.join(self.save_dir, frame_name + ".jpg")
                self.frame_count += 1
                logger.info("Save %d img: %s", self.frame_count, frame_save_path)
                cv2.imwrite(frame_save_path, vis_image)

    def create_visualization(self, data_dict: Dict[str, Any], idx: int) -> np.ndarray:
        """创建可视化图像.

        Args:
            data_dict: 数据字典，包含pixel_values等字段
            idx: 样本索引

        Returns:
            可视化图像数组，BGR格式，uint8类型
        """

        # 1. 可视化pixel_values（右侧，包含信息图）
        pixel_values = data_dict.get('pixel_values', None)
        image_flags = data_dict.get('image_flags', None)
        pixel_vis_result = None
        info_image_params: Optional[Tuple[int, int, int]] = None
        if pixel_values is not None:
            pv_result = self._visualize_pixel_values(pixel_values, idx, image_flags)
            if pv_result is not None:
                num_images, grid_img, (first_h, first_w) = pv_result
                pixel_vis_result = (num_images, grid_img)
                info_image_params = (num_images, first_h, first_w)

        # 2-4. 可视化其他GT内容（左侧）
        other_visualizations = []

        # 2. 可视化input_ids
        input_ids = data_dict.get('input_ids', None)
        if input_ids is not None:
            input_ids_vis = self._visualize_input_ids(input_ids, 151643)  # [NOTE] neos.yan: pad_token_ids=161643
            if input_ids_vis is not None:
                other_visualizations.append(('input_ids', input_ids_vis))

        # 3. 可视化labels
        labels = data_dict.get('labels', None)
        if labels is not None:
            labels_vis = self._visualize_labels(labels)
            if labels_vis is not None:
                other_visualizations.append(('labels', labels_vis))

        # 4. 可视化attention_mask
        attention_mask = data_dict.get('attention_mask', None)
        if attention_mask is not None:
            mask_vis = self._visualize_attention_mask(attention_mask)
            if mask_vis is not None:
                other_visualizations.append(('attention_mask', mask_vis))

        if info_image_params is not None:
            num_images_info, first_h, first_w = info_image_params
            if first_h > 0 and first_w > 0:
                info_img = self._create_info_image(
                    num_images_info, first_h, first_w, idx, image_flags)
                if info_img is not None:
                    other_visualizations.append(('info', info_img))

        # 5. 可视化对话内容（右侧下方）
        conversations_debug = data_dict.get('conversations_debug', None)
        conversations_origin_debug = data_dict.get('conversations_origin_debug', None)
        dataset_name_debug = data_dict.get('dataset_name_debug', None)

        # Debug: 打印对话内容
        # if conversations_debug is not None:
        #     logger.info(f"Sample {idx} conversations_debug: {conversations_debug}")
        # if conversations_origin_debug is not None:
        #     logger.info(f"Sample {idx} conversations_origin_debug: {conversations_origin_debug}")

        if pixel_vis_result is None and not other_visualizations:
            logger.warning(f"Sample {idx} has no visualizable data")
            return None

        # 将左侧和右侧拼接成一张图
        vis_image = self._concat_left_right_layout(
            other_visualizations, pixel_vis_result, idx,
            conversations_debug, conversations_origin_debug,
            dataset_name_debug
        )

        return vis_image

    def _visualize_pixel_values(self, pixel_values: Any, idx: int, image_flags: Any = None) -> Tuple[int, np.ndarray, Tuple[int, int]] | None:
        """可视化pixel_values，按照正方形Grid方式排列，保持原分辨率.

        Args:
            pixel_values: 像素值张量
            idx: 样本索引
            image_flags: 图像标志，可选

        Returns:
            (num_images, grid_image): 图像数量和grid图像
        """
        if isinstance(pixel_values, torch.Tensor):
            shape = pixel_values.shape
            pixel_np = pixel_values.detach().cpu().numpy()
        else:
            shape = np.array(pixel_values).shape
            pixel_np = np.array(pixel_values)

        # pixel_values shape: [num_images, C, H, W] 或 [C, H, W]
        if len(shape) == 4:
            # [num_images, C, H, W]
            num_images = shape[0]
            images = []
            for i in range(num_images):
                img = convert_tensor_to_image(pixel_values[i] if isinstance(
                    pixel_values, torch.Tensor) else pixel_np[i], denorm=True)
                images.append(img)
            first_h, first_w = images[0].shape[:2] if images else (0, 0)
        elif len(shape) == 3:
            # [C, H, W]
            img = convert_tensor_to_image(pixel_values, denorm=True)
            images = [img]
            num_images = 1
            first_h, first_w = img.shape[:2]
        else:
            logger.warning(f"Unexpected pixel_values shape: {shape}")
            return None

        # 按照正方形Grid方式排列，保持原分辨率（包括信息图）
        total_images = len(images)
        grid_columns = self._determine_grid_columns(num_images)
        grid_img = self._arrange_images_in_grid(images, total_images, columns=grid_columns)

        return num_images, grid_img, (first_h, first_w)

    def _determine_grid_columns(self, num_images: int) -> int:
        """根据图像数量确定列数."""
        return 3 if num_images <= 18 else 6

    def _arrange_images_in_grid(self, images: List[np.ndarray], num_images: int, columns: Optional[int] = None) -> np.ndarray:
        """将图像按照正方形Grid方式排列，保持原分辨率.

        Args:
            images: 图像列表，每个元素是(H, W, C)格式的numpy数组（包括信息图）
            num_images: 总图像数量（包括信息图）

        Returns:
            grid图像，BGR格式
        """
        if not images:
            return None

        # 计算列数和行数（固定列数，自动计算行数）
        if columns is None or columns <= 0:
            columns = int(np.ceil(np.sqrt(num_images)))
        effective_columns = max(1, min(columns, num_images))
        rows = int(np.ceil(num_images / float(effective_columns)))

        # 获取第一张图像的尺寸作为基准（假设所有图像尺寸相同）
        h, w = images[0].shape[:2]

        # 计算间距（1个pixel）
        spacing = 1

        # 计算grid画布尺寸（正方形）
        grid_h = rows * h + (rows - 1) * spacing if rows > 0 else h
        grid_w = effective_columns * w + (effective_columns - 1) * \
            spacing if effective_columns > 0 else w

        # 创建grid画布
        grid_img = np.ones((grid_h, grid_w, 3), dtype=np.uint8) * 255

        # 放置图像
        for i, img in enumerate(images):
            row = i // effective_columns
            col = i % effective_columns

            # 计算位置
            y_start = row * (h + spacing)
            x_start = col * (w + spacing)

            # 确保图像是BGR格式
            if img.shape[2] == 3:
                # 假设是RGB，转换为BGR
                img_bgr = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
            else:
                img_bgr = img

            # 在图像的右上角添加索引（只写num）
            img_with_index = img_bgr.copy()
            text = str(i)
            text_size = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.8, 2)[0]
            text_x = w - text_size[0] - 5
            text_y = text_size[1] + 5
            cv2.putText(img_with_index, text, (text_x, text_y), cv2.FONT_HERSHEY_SIMPLEX,
                        0.8, (0, 0, 255), 2)  # 红色文字

            # 放置图像
            grid_img[y_start:y_start+h, x_start:x_start+w] = img_with_index

        return grid_img

    def _format_image_flags(self, image_flags: Any) -> str:
        """格式化image_flags: 从索引0开始，依次遍历，连续相同的值合并为"数值*次数".

        Args:
            image_flags: 图像标志

        Returns:
            格式化后的字符串，例如 "1*2 2*3 3 1*3"
        """
        if isinstance(image_flags, torch.Tensor):
            flags_np = image_flags.detach().cpu().numpy().flatten()
        else:
            flags_np = np.array(image_flags).flatten()

        # 从索引0开始，依次遍历，统计连续相同值的长度
        parts = []
        if len(flags_np) > 0:
            current_val = flags_np[0]
            count = 1

            for i in range(1, len(flags_np)):
                if flags_np[i] == current_val:
                    # 连续相同，计数+1
                    count += 1
                else:
                    # 遇到不同的值，输出当前连续段
                    if count == 1:
                        parts.append(str(current_val))
                    else:
                        parts.append(f"{current_val}*{count}")
                    # 开始新的连续段
                    current_val = flags_np[i]
                    count = 1

            # 处理最后一个连续段
            if count == 1:
                parts.append(str(current_val))
            else:
                parts.append(f"{current_val}*{count}")

        # 用空格连接
        return ' '.join(parts)

    def _create_info_image(self, num_images: int, height: int, width: int, idx: int, image_flags: Any = None) -> np.ndarray:
        """创建信息图，显示图像数量和分辨率.

        Args:
            num_images: 图像数量
            height: 图像高度
            width: 图像宽度
            idx: 样本索引
            image_flags: 图像标志，可选

        Returns:
            信息图像，BGR格式
        """
        # 创建空白图像（和原始图像一样大）
        info_img = np.ones((height, width, 3), dtype=np.uint8) * 255

        # 准备文本内容
        lines = [
            f"Sample: {idx}",
            f"Images: {num_images}",
            f"Resolution: {width}x{height}"
        ]

        # 添加image_flags信息
        if image_flags is not None:
            flags_str = self._format_image_flags(image_flags)
            lines.append(f"Flags: {flags_str}")

        # 计算文本位置（左对齐）
        font = cv2.FONT_HERSHEY_SIMPLEX
        font_scale = self.INFO_FONT_SCALE
        font_thickness = self.INFO_FONT_THICKNESS
        line_height = self.INFO_LINE_HEIGHT
        start_y = height // 2 - (len(lines) - 1) * line_height // 2
        text_x = self.INFO_TEXT_X  # 左对齐，左边距

        for i, line in enumerate(lines):
            text_y = start_y + i * line_height
            cv2.putText(info_img, line, (text_x, text_y), font,
                        font_scale, (0, 0, 0), font_thickness)

        return info_img

    def _visualize_input_ids(self, input_ids: Any, pad_token_id: int | None = 0) -> np.ndarray:
        """可视化input_ids: 使用RGB三个通道表示每个值.
        B通道 = value % 255
        G通道 = (value // 255) % 255
        R通道 = value // (255 * 255)
        """
        if isinstance(input_ids, torch.Tensor):
            ids_np = input_ids.detach().cpu().numpy().flatten()
        else:
            ids_np = np.array(input_ids).flatten()

        if pad_token_id is not None:
            non_pad_idx = np.where(ids_np != pad_token_id)[0]
            if non_pad_idx.size > 0:
                ids_np = ids_np[non_pad_idx[0]:]
            else:
                ids_np = np.array([], dtype=ids_np.dtype)

        length = len(ids_np)
        grid_size = int(np.ceil(np.sqrt(length)))
        grid_img = np.zeros((grid_size, grid_size, 3), dtype=np.uint8)

        # 填充grid
        for i, val in enumerate(ids_np):
            row = i // grid_size
            col = i % grid_size

            # 计算RGB三个通道的值
            val_int = int(val)
            # B通道 = value % 255
            b_val = val_int % 255
            # G通道 = (value // 255) % 255
            g_val = (val_int // 255) % 255
            # R通道 = value // (255 * 255)
            r_val = val_int // (255 * 255)

            # BGR格式（OpenCV使用）
            grid_img[row, col] = [b_val, g_val, r_val]

        # 放大图像以便查看
        grid_img = cv2.resize(grid_img, (self.GRID_DISPLAY_SIZE,
                              self.GRID_DISPLAY_SIZE), interpolation=cv2.INTER_NEAREST)

        # 添加标题（包含长度）
        grid_img = self._add_title(grid_img, f"input_ids: {length}")

        return grid_img

    def _visualize_labels(self, labels: Any) -> np.ndarray:
        """可视化labels: 使用RGB三个通道表示每个值，但-100的情况画绿色.
        B通道 = value % 255
        G通道 = (value // 255) % 255
        R通道 = value // (255 * 255)
        """
        if isinstance(labels, torch.Tensor):
            labels_np = labels.detach().cpu().numpy().flatten()
        else:
            labels_np = np.array(labels).flatten()

        length = len(labels_np)
        grid_size = int(np.ceil(np.sqrt(length)))
        grid_img = np.zeros((grid_size, grid_size, 3), dtype=np.uint8)

        # 填充grid
        for i, val in enumerate(labels_np):
            row = i // grid_size
            col = i % grid_size

            if val == -100:
                # -100的情况画绿色
                grid_img[row, col] = [0, 255, 0]  # BGR: 绿色
            else:
                # 计算RGB三个通道的值
                val_int = int(val)
                # B通道 = value % 255
                b_val = val_int % 255
                # G通道 = (value // 255) % 255
                g_val = (val_int // 255) % 255
                # R通道 = value // (255 * 255)
                r_val = val_int // (255 * 255)

                # BGR格式（OpenCV使用）
                grid_img[row, col] = [b_val, g_val, r_val]

        # 放大图像以便查看
        grid_img = cv2.resize(grid_img, (self.GRID_DISPLAY_SIZE,
                              self.GRID_DISPLAY_SIZE), interpolation=cv2.INTER_NEAREST)

        # 添加标题（包含长度）
        grid_img = self._add_title(grid_img, f"labels: {length}")

        return grid_img

    def _visualize_attention_mask(self, attention_mask: Any) -> np.ndarray:
        """可视化attention_mask: bool类型，画黑白."""
        if isinstance(attention_mask, torch.Tensor):
            mask_np = attention_mask.detach().cpu().numpy().flatten().astype(bool)
        else:
            mask_np = np.array(attention_mask).flatten().astype(bool)

        length = len(mask_np)

        # 转换为grid图像
        grid_img = self._tensor_to_grid_image(mask_np.astype(float), title=f"attention_mask: {length}",
                                              colormap='binary')

        return grid_img

    def _visualize_image_flags(self, image_flags: Any) -> np.ndarray:
        """可视化image_flags: 从索引0开始，依次遍历，连续相同的值合并为"数值*次数"."""
        flags_str = self._format_image_flags(image_flags)

        # 计算文本宽度，动态调整图像宽度（使用和_add_title相同的字体大小）
        text_size = cv2.getTextSize(flags_str, cv2.FONT_HERSHEY_SIMPLEX,
                                    self.IMAGE_FLAGS_FONT_SCALE, self.IMAGE_FLAGS_FONT_THICKNESS)[0]
        text_width = max(self.GRID_DISPLAY_SIZE, text_size[0] + self.IMAGE_FLAGS_TEXT_MARGIN)

        # 创建白色背景（减少高度，和input_ids等保持一致）
        img = np.ones((self.GRID_DISPLAY_SIZE, text_width, 3), dtype=np.uint8) * 255

        # 添加文本（使用和_add_title相同的字体大小和位置）
        cv2.putText(img, flags_str, self.IMAGE_FLAGS_TEXT_POSITION, cv2.FONT_HERSHEY_SIMPLEX,
                    self.IMAGE_FLAGS_FONT_SCALE, (0, 0, 0), self.IMAGE_FLAGS_FONT_THICKNESS)

        # 添加标题（使用_add_title方法，确保字体一致）
        img = self._add_title(img, "image_flags")

        return img

    def _tensor_to_grid_image(self, tensor: np.ndarray, title: str = "",
                              colormap: str = 'rgb') -> np.ndarray:
        """将1D张量转换为grid图像（正方形排列）.

        Args:
            tensor: 1D数组
            title: 标题
            colormap: 颜色映射方式，'rgb'表示RGB颜色，'binary'表示黑白

        Returns:
            grid图像，BGR格式
        """
        length = len(tensor)
        grid_size = int(np.ceil(np.sqrt(length)))  # 向上取整

        if colormap == 'rgb':
            # RGB颜色映射
            grid_img = np.zeros((grid_size, grid_size, 3), dtype=np.uint8)
            for i, val in enumerate(tensor):
                row = i // grid_size
                col = i % grid_size
                rgb_val = int(np.clip(val, 0.0, 1.0) * 255)
                grid_img[row, col] = [rgb_val, rgb_val, rgb_val]  # BGR: 灰度
        else:  # binary
            # 黑白映射（1用黄色表示）
            grid_img = np.zeros((grid_size, grid_size, 3), dtype=np.uint8)
            for i, val in enumerate(tensor):
                row = i // grid_size
                col = i % grid_size
                if val > 0.5:
                    grid_img[row, col] = [0, 255, 255]  # BGR: 黄色
                else:
                    grid_img[row, col] = [0, 0, 0]  # BGR: 黑色

        # 放大图像以便查看
        grid_img = cv2.resize(grid_img, (self.GRID_DISPLAY_SIZE,
                              self.GRID_DISPLAY_SIZE), interpolation=cv2.INTER_NEAREST)

        # 添加标题
        if title:
            grid_img = self._add_title(grid_img, title)

        return grid_img

    def _concat_images(self, images: List[np.ndarray], title_prefix: str = "") -> np.ndarray:
        """将多张图像拼接成一张可视化图.

        Args:
            images: 图像列表，每个元素是(H, W, C)格式的numpy数组
            title_prefix: 标题前缀

        Returns:
            拼接后的图像，BGR格式
        """
        if not images:
            return None

        # 确保所有图像都是RGB格式（PIL/cv2使用）
        processed_images = []
        for i, img in enumerate(images):
            # 如果是RGB格式，转换为BGR（cv2使用）
            if img.shape[2] == 3:
                # 假设是RGB，转换为BGR
                img_bgr = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
            else:
                img_bgr = img

            # 添加标题
            img_with_title = self._add_title(img_bgr, f"{title_prefix} Image {i+1}")
            processed_images.append(img_with_title)

        # 计算拼接后的尺寸
        max_h = max(img.shape[0] for img in processed_images)
        spacing = self.CONCAT_SPACING
        padding = self.CONCAT_PADDING

        # 计算总宽度：所有图像宽度 + 间隔 + 左右padding
        total_w = sum(img.shape[1] for img in processed_images) + \
            spacing * (len(processed_images) - 1) + 2 * padding

        # 创建画布（包含标题空间）
        canvas = np.ones((max_h + self.CONCAT_TITLE_HEIGHT, total_w, 3), dtype=np.uint8) * 255

        # 拼接图像
        x_offset = padding
        for img in processed_images:
            h, w = img.shape[:2]
            # 确保不超出画布边界
            if x_offset + w > total_w:
                w = total_w - x_offset
            if w > 0 and h > 0:
                canvas[self.CONCAT_TITLE_HEIGHT:self.CONCAT_TITLE_HEIGHT +
                       h, x_offset:x_offset+w] = img[:h, :w]
            x_offset += w + spacing

        # 添加总标题
        title = f"{title_prefix} - {len(images)} images"
        canvas = cv2.putText(canvas, title, (padding, self.CONCAT_TITLE_BASELINE), cv2.FONT_HERSHEY_SIMPLEX,
                             self.CONCAT_TITLE_FONT_SCALE, (0, 0, 0), self.CONCAT_TITLE_FONT_THICKNESS)

        return canvas

    def _concat_left_right_layout(self, left_visualizations: List[Tuple[str, np.ndarray]],
                                  pixel_vis_result: Tuple[int, np.ndarray] | None, idx: int,
                                  conversations_debug: Any = None, conversations_origin_debug: Any = None,
                                  dataset_name_debug: Optional[str] = None) -> np.ndarray:
        """将左侧GT内容和右侧pixel_values拼接成一张图.

        Args:
            left_visualizations: 左侧可视化列表，每个元素是(name, image)元组
            pixel_vis_result: pixel_values可视化结果，为(num_images, grid_image)或None
            idx: 样本索引

        Returns:
            拼接后的图像，BGR格式
        """
        # 处理左侧内容（垂直排列）
        left_height = 0
        left_width = 0
        left_images = []

        if left_visualizations:
            target_h = self.GRID_DISPLAY_SIZE + self.TITLE_HEIGHT  # 图像高度 + 标题高度
            processed = []
            for name, img in left_visualizations:
                h, w = img.shape[:2]
                if h != target_h:
                    # 缩放图像到目标高度，保持宽高比
                    scale = target_h / float(h)
                    new_w = int(w * scale)
                    img_resized = cv2.resize(img, (new_w, target_h))
                else:
                    img_resized = img
                processed.append((name, img_resized))

            left_height = sum(img.shape[0] for _, img in processed) + self.LEFT_COLUMN_HEADER_HEIGHT
            left_width = max(img.shape[1] for _, img in processed) if processed else 0

            # 创建左侧画布
            left_canvas = np.ones((left_height, left_width, 3), dtype=np.uint8) * 255

            # 不再单独显示sample id，已在信息图中显示

            # 垂直拼接所有可视化（减少起始偏移）
            y_offset = self.LEFT_COLUMN_TOP_PADDING
            for name, img in processed:
                h, w = img.shape[:2]
                if y_offset + h > left_height:
                    h = left_height - y_offset
                if h > 0:
                    x_offset = max(0, (left_width - w) // 2)
                    if x_offset + w > left_width:
                        w = left_width - x_offset
                    if w > 0:
                        left_canvas[y_offset:y_offset+h, x_offset:x_offset+w] = img[:h, :w]
                y_offset += h

            left_images.append(left_canvas)

        # 处理右侧pixel_values
        right_image = None
        if pixel_vis_result is not None:
            num_images, grid_img = pixel_vis_result
            right_image = grid_img

        # 处理对话内容（右侧，水平排列）
        conversation_images = []
        if dataset_name_debug:
            dataset_title_img = self._create_dataset_name_image(str(dataset_name_debug))
            if dataset_title_img is not None:
                conversation_images.append(dataset_title_img)
        # 先处理 conversations_origin_debug
        if conversations_origin_debug is not None:
            formatted_text = self._format_conversations_origin_debug(conversations_origin_debug)
            if formatted_text:
                text_img = self._create_colored_text_image(
                    formatted_text, max_width=self.CONVERSATIONS_TEXT_MAX_WIDTH)
                text_img = self._add_title(text_img, "conversations_origin_debug")
                conversation_images.append(text_img)

        # 再处理 conversations_debug
        if conversations_debug is not None:
            formatted_text = self._format_conversations_debug(conversations_debug)
            if formatted_text:
                text_img = self._create_conversations_debug_text_image(
                    formatted_text, max_width=self.CONVERSATIONS_TEXT_MAX_WIDTH)
                text_img = self._add_title(text_img, "conversations_debug")
                conversation_images.append(text_img)

        # 计算对话内容宽度
        conversation_width = 0
        conversation_total_height = 0
        if conversation_images:
            conversation_width = max(img.shape[1] for img in conversation_images)  # 对话内容的最大宽度
            # 对话内容垂直排列的总高度（所有图像高度之和 + 间距）
            conversation_total_height = sum(
                img.shape[0] for img in conversation_images) + self.CONVERSATION_SPACING * (len(conversation_images) - 1)

        # 如果图像网格太大，需要缩放以适配画布（保持对话内容可见）
        # 设置最大总宽度限制：考虑左侧内容宽度、间距和对话内容宽度
        max_total_width = self.max_total_width
        spacing = self.RIGHT_COLUMN_SPACING  # 左右间距

        # 计算左侧宽度
        left_w = left_width if left_images else 0

        if right_image is not None:
            original_h, original_w = right_image.shape[:2]
            if max_total_width is not None:
                # 计算可用宽度：最大总宽度 - 左侧宽度 - 间距 - 对话内容宽度
                # 如果对话内容存在，需要预留空间；否则使用最大宽度限制
                if conversation_width > 0:
                    available_width = max_total_width - left_w - spacing - conversation_width - spacing
                else:
                    available_width = max_total_width - left_w - spacing

                # 确保可用宽度至少为最小合理值
                available_width = max(available_width, self.MIN_AVAILABLE_WIDTH)

                # 如果原始宽度超过可用宽度，进行缩放
                if original_w > available_width:
                    scale = available_width / float(original_w)
                    new_w = int(original_w * scale)
                    new_h = int(original_h * scale)
                    right_image = cv2.resize(right_image, (new_w, new_h),
                                             interpolation=cv2.INTER_AREA)

        # 计算最终画布尺寸
        left_h = left_height if left_images else 0
        # left_w 已在上面计算（第722行）

        right_h = right_image.shape[0] if right_image is not None else 0
        right_w = right_image.shape[1] if right_image is not None else 0

        # 计算右侧总宽度和高度（水平排列：grid在左，对话在右）
        right_total_w = right_w + \
            (spacing if (right_w > 0 and conversation_width > 0) else 0) + conversation_width
        # 右侧总高度：grid高度和对话内容总高度的最大值
        right_total_h = max(right_h, conversation_total_height)

        # 计算总高度和总宽度
        total_h = max(left_h, right_total_h)
        total_w = left_w + spacing + \
            right_total_w if (left_w > 0 and right_total_w > 0) else (left_w + right_total_w)

        # 创建最终画布
        canvas = np.ones((total_h, total_w, 3), dtype=np.uint8) * 255

        # 放置左侧内容
        if left_images:
            left_canvas = left_images[0]
            l_h, l_w = left_canvas.shape[:2]
            canvas[:l_h, :l_w] = left_canvas

        # 放置右侧内容（pixel_values grid在左，对话内容在右）
        x_start = left_w + spacing if left_w > 0 else 0
        y_start = 0

        # 放置pixel_values grid
        if right_image is not None:
            r_h, r_w = right_image.shape[:2]
            canvas[y_start:y_start+r_h, x_start:x_start+r_w] = right_image
            x_start += r_w + (self.CONVERSATION_SPACING if conversation_width > 0 else 0)

        # 放置对话内容（垂直排列）
        if conversation_images:
            y_offset = 0
            for img in conversation_images:
                h, w = img.shape[:2]
                # 确保不超出画布边界
                if y_offset + h > total_h:
                    h = total_h - y_offset
                if h > 0 and x_start + w <= total_w:
                    canvas[y_offset:y_offset+h, x_start:x_start+w] = img[:h, :w]
                y_offset += h + self.CONVERSATION_SPACING

        return canvas

    def _add_title(self, img: np.ndarray, title: str) -> np.ndarray:
        """在图像上方添加标题.

        Args:
            img: 输入图像，BGR格式
            title: 标题文本

        Returns:
            添加标题后的图像
        """
        h, w = img.shape[:2]
        # 创建带标题的图像
        title_height = self.TITLE_HEIGHT
        img_with_title = np.ones((h + title_height, w, 3), dtype=np.uint8) * 255
        img_with_title[title_height:, :] = img

        # 添加标题文字
        text_x, text_y = self.TITLE_TEXT_OFFSET
        img_with_title = cv2.putText(img_with_title, title, (text_x, text_y),
                                     cv2.FONT_HERSHEY_SIMPLEX, self.TITLE_FONT_SCALE, (0, 0, 0), self.TITLE_FONT_THICKNESS)

        return img_with_title

    def _sanitize_filename_component(self, value: Any) -> str:
        if value is None:
            return ""
        text = str(value).strip()
        if not text:
            return ""
        return re.sub(r"[\\/:*?\"<>|]", "_", text)

    def _create_dataset_name_image(self, dataset_name: str) -> np.ndarray | None:
        """创建数据集名称图像，使用黑色加粗字体."""
        text = dataset_name.strip()
        if not text:
            return None

        font_face = cv2.FONT_HERSHEY_SIMPLEX
        font_scale = 0.9
        thickness = 3
        padding_x = 20
        padding_y = 15

        text_size, baseline = cv2.getTextSize(text, font_face, font_scale, thickness)
        text_w, text_h = text_size
        width = text_w + padding_x * 2
        height = text_h + baseline + padding_y * 2

        img = np.ones((height, width, 3), dtype=np.uint8) * 255
        text_x = padding_x
        text_y = padding_y + text_h

        cv2.putText(img, text, (text_x, text_y), font_face,
                    font_scale, (0, 0, 0), thickness, cv2.LINE_AA)

        return img

    def _abbreviate_tokens(self, text: str) -> str:
        """缩写token名称: [UNUSED_TOKEN_XX] -> [UT_XX].

        Args:
            text: 原始文本

        Returns:
            缩写后的文本
        """
        # 匹配 [UNUSED_TOKEN_XX] 或 [UNUSED_TOKEN_XXX] 等模式
        pattern = r'\[UNUSED_TOKEN_(\d+)\]'
        text = re.sub(pattern, r'[UT_\1]', text)
        return text

    def _format_conversations_debug(self, conversations_debug: Any) -> str:
        """格式化conversations_debug: 压缩连续的<IMG_CONTEXT>，处理换行.

        Args:
            conversations_debug: 对话调试信息，字符串列表

        Returns:
            格式化后的字符串
        """
        if not conversations_debug:
            return ""

        lines = []
        for item in conversations_debug:
            if isinstance(item, str):
                # 压缩连续的<IMG_CONTEXT>
                text = item
                # 使用正则表达式匹配连续的<IMG_CONTEXT>
                pattern = r'(<IMG_CONTEXT>)+'

                def replace_func(match):
                    count = len(match.group(0)) // len('<IMG_CONTEXT>')
                    return f'<IMG_CONTEXT>*{count}'
                text = re.sub(pattern, replace_func, text)
                # 缩写token名称
                text = self._abbreviate_tokens(text)
                lines.append(text)
            else:
                text = self._abbreviate_tokens(str(item))
                lines.append(text)

        # 合并所有行，\n 会被保留作为换行
        return '\n'.join(lines)

    def _format_conversations_origin_debug(self, conversations_origin_debug: Any) -> str:
        """格式化conversations_origin_debug: {from: human, value:xxx} -> human:xxx.

        Args:
            conversations_origin_debug: 原始对话调试信息，字典列表

        Returns:
            格式化后的字符串
        """
        if not conversations_origin_debug:
            return ""

        lines = []
        for item in conversations_origin_debug:
            if isinstance(item, dict):
                from_val = item.get('from', 'unknown')
                value = item.get('value', '')
                # 缩写token名称
                value = self._abbreviate_tokens(value)
                lines.append(f"{from_val}: {value}")
            else:
                text = self._abbreviate_tokens(str(item))
                lines.append(text)

        # 合并所有行，\n 会被保留作为换行
        return '\n'.join(lines)

    def _find_chinese_font(self, font_size: int = 16) -> ImageFont.FreeTypeFont:
        """查找并加载中文字体.

        Args:
            font_size: 字体大小

        Returns:
            PIL字体对象
        """
        # 尝试常见的中文字体路径（优先级从高到低）
        font_paths = [
            # 项目依赖中的中文字体
            '/perception-hl/MLM_evaluator/dependency/SimHei.ttf',
            # Linux系统中文字体
            '/lustre/neos.yan/wqy-microhei.ttc',
            '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc',
            '/usr/share/fonts/truetype/arphic/uming.ttc',
            '/usr/share/fonts/truetype/arphic/ukai.ttc',
            '/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc',
            '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.otf',
            # macOS系统中文字体
            '/System/Library/Fonts/PingFang.ttc',
            '/System/Library/Fonts/STHeiti Light.ttc',
            '/System/Library/Fonts/STHeiti Medium.ttc',
            # Windows系统中文字体
            '/Windows/Fonts/simsun.ttc',
            '/Windows/Fonts/simhei.ttf',
            '/Windows/Fonts/msyh.ttc',
            '/Windows/Fonts/msyhbd.ttc',
            # 备用字体
            '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
            '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf',
        ]

        # 首先尝试直接路径
        for path in font_paths:
            if os.path.exists(path):
                try:
                    font = ImageFont.truetype(path, font_size)
                    logger.debug(f"Loaded font from: {path}")
                    return font
                except Exception as e:
                    logger.debug(f"Failed to load font from {path}: {e}")
                    continue

        # 如果直接路径都失败，尝试使用fc-list查找
        try:
            import subprocess
            result = subprocess.run(['fc-list', ':lang=zh'],
                                    capture_output=True, text=True, timeout=2)
            if result.returncode == 0 and result.stdout:
                # 解析fc-list输出，获取第一个中文字体路径
                for line in result.stdout.split('\n'):
                    if ':' in line:
                        font_path = line.split(':')[0].strip()
                        if os.path.exists(font_path):
                            try:
                                font = ImageFont.truetype(font_path, font_size)
                                logger.debug(f"Loaded font from fc-list: {font_path}")
                                return font
                            except:
                                continue
        except Exception as e:
            logger.debug(f"fc-list failed: {e}")

        # 如果都失败，使用默认字体
        logger.warning("No Chinese font found, using default font (may not support Chinese)")
        return ImageFont.load_default()

    def _create_text_image(self, text: str, max_width: Optional[int] = None, font_size: Optional[int] = None,
                           line_spacing: Optional[int] = None, padding: Optional[int] = None,
                           max_chars_per_line: Optional[int] = None) -> np.ndarray:
        """创建文本图像，支持中文.

        Args:
            text: 文本内容，支持换行符\n
            max_width: 最大宽度
            font_size: 字体大小
            line_spacing: 行间距
            padding: 内边距
            max_chars_per_line: 每行最大字符数，超过后自动换行

        Returns:
            文本图像，BGR格式
        """
        # 使用配置中的默认值
        config = self.TEXT_IMAGE_CONFIG
        max_width = config["max_width"] if max_width is None else max_width
        if not text:
            return np.ones((50, max_width, 3), dtype=np.uint8) * 255

        font_size = config["font_size"] if font_size is None else font_size
        line_spacing = config["line_spacing"] if line_spacing is None else line_spacing
        padding = config["padding"] if padding is None else padding
        max_chars_per_line = config["max_chars_per_line"] if max_chars_per_line is None else max_chars_per_line

        # 加载中文字体
        font = self._find_chinese_font(font_size)

        # 分割文本为行（只在\n处分割）
        lines = text.split('\n')

        # 处理每行：如果超过最大字符数，按字符数截断并换行
        processed_lines = []
        line_colors = []
        current_color = (0, 0, 0)
        for line in lines:
            if not line:
                processed_lines.append(" ")  # 空行用空格代替
                line_colors.append(current_color)
            else:
                stripped_lower = line.strip().lower()
                if stripped_lower.startswith('human:') or stripped_lower.startswith('human：'):
                    current_color = (255, 0, 0)
                elif stripped_lower.startswith('gpt:') or stripped_lower.startswith('gpt：'):
                    current_color = (0, 0, 255)

                # 根据是否包含中文动态调整截断长度
                line_max_chars = max_chars_per_line
                if not re.search(r"[\u4e00-\u9fff]", line):
                    line_max_chars = max(
                        1, int(math.ceil(max_chars_per_line * self.TEXT_NON_CHINESE_SCALE)))

                # 如果行超过最大字符数，按字符数分割
                remaining = line
                while len(remaining) > line_max_chars:
                    processed_lines.append(remaining[:line_max_chars])
                    line_colors.append(current_color)
                    remaining = remaining[line_max_chars:]
                if remaining:  # 剩余部分
                    processed_lines.append(remaining)
                    line_colors.append(current_color)

        # 使用PIL创建临时图像来测量文本尺寸
        temp_img = Image.new('RGB', (100, 100), (255, 255, 255))
        draw = ImageDraw.Draw(temp_img)

        # 计算每行的宽度和高度
        line_heights = []
        line_widths = []
        for line in processed_lines:
            bbox = draw.textbbox((0, 0), line, font=font)
            line_widths.append(bbox[2] - bbox[0])
            line_heights.append(bbox[3] - bbox[1])

        # 如果没有计算到任何行，至少有一行
        if not line_widths:
            bbox = draw.textbbox((0, 0), " ", font=font)
            line_widths.append(bbox[2] - bbox[0])
            line_heights.append(bbox[3] - bbox[1])

        # 计算总宽度和总高度（使用实际最大宽度，确保能显示完整内容）
        actual_max_width = max(line_widths) + 2 * padding if line_widths else max_width
        # 确保画布宽度足够显示所有内容，不限制在max_width内
        total_width = max(actual_max_width, max_width)
        total_height = sum(line_heights) + (len(line_heights) - 1) * line_spacing + 2 * padding

        # 使用PIL创建图像
        img_pil = Image.new('RGB', (total_width, total_height), (255, 255, 255))
        draw = ImageDraw.Draw(img_pil)

        # 绘制文本
        y = padding
        for i, line in enumerate(processed_lines):
            x = padding
            draw.text((x, y), line, fill=(0, 0, 0), font=font)
            if i < len(line_heights):
                y += line_heights[i] + line_spacing

        # 转换为numpy数组并转换为BGR格式
        img = np.array(img_pil)
        img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)

        return img

    def _create_colored_text_image(self, text: str, max_width: Optional[int] = None, font_size: Optional[int] = None,
                                   line_spacing: Optional[int] = None, padding: Optional[int] = None,
                                   max_chars_per_line: Optional[int] = None) -> np.ndarray:
        """创建带颜色的文本图像，支持中文.
        对于 conversations_origin_debug: human: 用红色，gpt: 用蓝色.

        Args:
            text: 文本内容，支持换行符\n
            max_width: 最大宽度
            font_size: 字体大小
            line_spacing: 行间距
            padding: 内边距
            max_chars_per_line: 每行最大字符数，超过后自动换行

        Returns:
            文本图像，BGR格式
        """
        # 使用配置中的默认值
        config = self.TEXT_IMAGE_CONFIG
        max_width = (self.COLORED_TEXT_MAX_WIDTH if max_width is None else max_width)
        if not text:
            return np.ones((50, max_width, 3), dtype=np.uint8) * 255

        font_size = config["font_size"] if font_size is None else font_size
        line_spacing = config["line_spacing"] if line_spacing is None else line_spacing
        padding = config["padding"] if padding is None else padding
        max_chars_per_line = config["max_chars_per_line"] if max_chars_per_line is None else max_chars_per_line

        # 加载中文字体
        font = self._find_chinese_font(font_size)

        # 分割文本为行（只在\n处分割）
        lines = text.split('\n')

        # 处理每行：如果超过最大字符数，按字符数截断并换行
        processed_lines = []
        line_colors = []
        current_color = (0, 0, 0)
        for line in lines:
            if not line:
                processed_lines.append(" ")  # 空行用空格代替
                line_colors.append(current_color)
            else:
                stripped_lower = line.strip().lower()
                if stripped_lower.startswith('human:') or stripped_lower.startswith('human：'):
                    current_color = (255, 0, 0)  # 红色
                elif stripped_lower.startswith('gpt:') or stripped_lower.startswith('gpt：'):
                    current_color = (0, 0, 255)  # 蓝色

                line_lower = line.lower()
                if '<|im_start|>' in line_lower:
                    if '<|im_start|>system' in line_lower or ('<|im_start|>' in line_lower and 'system' in line_lower):
                        current_color = (255, 0, 255)  # 洋红色
                    elif '<|im_start|>user' in line_lower or ('<|im_start|>' in line_lower and 'user' in line_lower and 'assistant' not in line_lower):
                        current_color = (255, 0, 0)  # 红色
                    elif '<|im_start|>assistant' in line_lower or ('<|im_start|>' in line_lower and 'assistant' in line_lower):
                        current_color = (0, 0, 255)  # 蓝色

                # 根据是否包含中文动态调整截断长度
                line_max_chars = max_chars_per_line
                if not re.search(r"[\u4e00-\u9fff]", line):
                    line_max_chars = max(
                        1, int(math.ceil(max_chars_per_line * self.TEXT_NON_CHINESE_SCALE)))

                # 如果行超过最大字符数，按字符数分割
                remaining = line
                while len(remaining) > line_max_chars:
                    processed_lines.append(remaining[:line_max_chars])
                    line_colors.append(current_color)
                    remaining = remaining[line_max_chars:]
                if remaining:  # 剩余部分
                    processed_lines.append(remaining)
                    line_colors.append(current_color)

        # 使用PIL创建临时图像来测量文本尺寸
        temp_img = Image.new('RGB', (100, 100), (255, 255, 255))
        draw = ImageDraw.Draw(temp_img)

        # 计算每行的宽度和高度
        line_heights = []
        line_widths = []
        for line in processed_lines:
            bbox = draw.textbbox((0, 0), line, font=font)
            line_widths.append(bbox[2] - bbox[0])
            line_heights.append(bbox[3] - bbox[1])

        # 如果没有计算到任何行，至少有一行
        if not line_widths:
            bbox = draw.textbbox((0, 0), " ", font=font)
            line_widths.append(bbox[2] - bbox[0])
            line_heights.append(bbox[3] - bbox[1])

        # 计算总宽度和总高度（使用实际最大宽度，确保能显示完整内容）
        actual_max_width = max(line_widths) + 2 * padding if line_widths else max_width
        # 确保画布宽度足够显示所有内容，不限制在max_width内
        total_width = max(actual_max_width, max_width)
        total_height = sum(line_heights) + (len(line_heights) - 1) * line_spacing + 2 * padding

        # 使用PIL创建图像
        img_pil = Image.new('RGB', (total_width, total_height), (255, 255, 255))
        draw = ImageDraw.Draw(img_pil)

        # 绘制文本（带颜色）
        y = padding
        for i, line in enumerate(processed_lines):
            x = padding
            color = line_colors[i] if i < len(line_colors) else (0, 0, 0)
            draw.text((x, y), line, fill=color, font=font)
            if i < len(line_heights):
                y += line_heights[i] + line_spacing

        # 转换为numpy数组并转换为BGR格式
        img = np.array(img_pil)
        img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)

        return img

    def _create_conversations_debug_text_image(self, text: str, max_width: Optional[int] = None,
                                               font_size: Optional[int] = None, line_spacing: Optional[int] = None,
                                               padding: Optional[int] = None, max_chars_per_line: Optional[int] = None) -> np.ndarray:
        """创建conversations_debug文本图像，支持颜色.
        <|im_start|>system及后面的内容用洋红色，user及后面的内容用红色，assistant及后面的内容用蓝色.

        Args:
            text: 文本内容，支持换行符\n
            max_width: 最大宽度
            font_size: 字体大小
            line_spacing: 行间距
            padding: 内边距
            max_chars_per_line: 每行最大字符数，超过后自动换行

        Returns:
            文本图像，BGR格式
        """
        # 使用配置中的默认值
        config = self.TEXT_IMAGE_CONFIG
        max_width = (self.CONVERSATIONS_TEXT_MAX_WIDTH if max_width is None else max_width)
        if not text:
            return np.ones((50, max_width, 3), dtype=np.uint8) * 255

        font_size = config["font_size"] if font_size is None else font_size
        line_spacing = config["line_spacing"] if line_spacing is None else line_spacing
        padding = config["padding"] if padding is None else padding
        max_chars_per_line = config["max_chars_per_line"] if max_chars_per_line is None else max_chars_per_line

        # 加载中文字体
        font = self._find_chinese_font(font_size)

        # 分割文本为行（只在\n处分割）
        lines = text.split('\n')

        # 处理每行：如果超过最大字符数，按字符数截断并换行
        processed_lines = []
        line_colors = []
        current_color = (0, 0, 0)
        for line in lines:
            if not line:
                processed_lines.append(" ")  # 空行用空格代替
                line_colors.append(current_color)
            else:
                line_lower = line.lower()
                stripped_lower = line.strip().lower()

                if stripped_lower.startswith('human:') or stripped_lower.startswith('human：'):
                    current_color = (255, 0, 0)  # 红色
                elif stripped_lower.startswith('gpt:') or stripped_lower.startswith('gpt：'):
                    current_color = (0, 0, 255)  # 蓝色

                if '<|im_start|>' in line_lower:
                    if '<|im_start|>system' in line_lower or ('<|im_start|>' in line_lower and 'system' in line_lower):
                        current_color = (255, 0, 255)  # 洋红色
                    elif '<|im_start|>user' in line_lower or ('<|im_start|>' in line_lower and 'user' in line_lower and 'assistant' not in line_lower):
                        current_color = (255, 0, 0)  # 红色
                    elif '<|im_start|>assistant' in line_lower or ('<|im_start|>' in line_lower and 'assistant' in line_lower):
                        current_color = (0, 0, 255)  # 蓝色

                # 根据是否包含中文动态调整截断长度
                line_max_chars = max_chars_per_line
                if not re.search(r"[\u4e00-\u9fff]", line):
                    line_max_chars = max(
                        1, int(math.ceil(max_chars_per_line * self.TEXT_NON_CHINESE_SCALE)))

                # 如果行超过最大字符数，按字符数分割
                remaining = line
                while len(remaining) > line_max_chars:
                    processed_lines.append(remaining[:line_max_chars])
                    line_colors.append(current_color)
                    remaining = remaining[line_max_chars:]
                if remaining:  # 剩余部分
                    processed_lines.append(remaining)
                    line_colors.append(current_color)

        # 使用PIL创建临时图像来测量文本尺寸
        temp_img = Image.new('RGB', (100, 100), (255, 255, 255))
        draw = ImageDraw.Draw(temp_img)

        # 计算每行的宽度和高度
        line_heights = []
        line_widths = []
        for line in processed_lines:
            bbox = draw.textbbox((0, 0), line, font=font)
            line_widths.append(bbox[2] - bbox[0])
            line_heights.append(bbox[3] - bbox[1])

        # 如果没有计算到任何行，至少有一行
        if not line_widths:
            bbox = draw.textbbox((0, 0), " ", font=font)
            line_widths.append(bbox[2] - bbox[0])
            line_heights.append(bbox[3] - bbox[1])

        # 计算总宽度和总高度（使用实际最大宽度，而不是限制在max_width）
        actual_max_width = max(line_widths) + 2 * padding if line_widths else max_width
        total_width = min(actual_max_width, max_width)
        total_height = sum(line_heights) + (len(line_heights) - 1) * line_spacing + 2 * padding

        # 使用PIL创建图像
        img_pil = Image.new('RGB', (total_width, total_height), (255, 255, 255))
        draw = ImageDraw.Draw(img_pil)

        # 绘制文本（带颜色）
        y = padding
        for i, line in enumerate(processed_lines):
            x = padding
            color = line_colors[i] if i < len(line_colors) else (0, 0, 0)
            draw.text((x, y), line, fill=color, font=font)
            if i < len(line_heights):
                y += line_heights[i] + line_spacing

        # 转换为numpy数组并转换为BGR格式
        img = np.array(img_pil)
        img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)

        return img