import os

import json
import re
import copy
import argparse
import datasets
from datasets import Features, Value, Sequence, Dataset
from io import BytesIO
from PIL import Image
import numpy as np
from tqdm import tqdm
import concurrent.futures
import pandas as pd
import random


FILE_DICT = {
    # "thinklite_normal": "/lustre/MLM_evaluator/data/open_data/ivl3_thinklite_normal_data.jsonl",
    # "thinklite_hard": "/lustre/MLM_evaluator/data/open_data/ivl3_thinklite_hard_data.jsonl",
    # "thinker_puzzle": "/lustre/MLM_evaluator/data/open_data/ivl3_openvl_thinker_Puzzle-Name_data.jsonl",
    # "thinker_mmiq": "/lustre/MLM_evaluator/data/open_data/ivl3_openvl_thinker_MMIQ_data.jsonl",
    # "mm_eureka_k12": "/lustre/MLM_evaluator/data/open_data/ivl3_open_data_mm_eureka_k12.jsonl",
    
    # "DocVQA": "/lustre/MLM_evaluator/data/open_data/badcase/DocVqa_hardcase.jsonl",
    # "InfoVQA": "/lustre/MLM_evaluator/data/open_data/badcase/InfoVQA_hardcase.jsonl",
    # "TextVQA": "/lustre/MLM_evaluator/data/open_data/badcase/TextVQA_hardcase.jsonl",
    # "Refcoco": "/lustre/MLM_evaluator/data/open_data/badcase/Refcoco_hardcase.jsonl",
    # "Refcoco+": "/lustre/MLM_evaluator/data/open_data/badcase/Refcoco+_hardcase.jsonl",
    # "Refcocog": "/lustre/MLM_evaluator/data/open_data/badcase/Refcocog_hardcase.jsonl",
    # "ChartQA": "/lustre/MLM_evaluator/data/open_data/badcase/ChartQA_fixed_hardcase.jsonl",

    "chartqapro": "/lustre/fangdong.wang/verl_0.7.0/data_process/score_5/orsta/train_chart_chartqapro_364.jsonl",
    "chartx": "/lustre/fangdong.wang/verl_0.7.0/data_process/score_5/orsta/train_chart_chartx_2039.jsonl",
    "tablevqa": "/lustre/fangdong.wang/verl_0.7.0/data_process/score_5/orsta/train_chart_tablevqa_273.jsonl",
    "chart_virl39k": "/lustre/fangdong.wang/verl_0.7.0/data_process/score_5/orsta/train_chart_virl39k_1370.jsonl",
    "clevr": "/lustre/fangdong.wang/verl_0.7.0/data_process/score_5/orsta/train_counting_1479.jsonl",
    "object365": "/lustre/fangdong.wang/verl_0.7.0/data_process/score_5/orsta/train_detection_object365_9521_double_fixed.jsonl",
    "v3det": "/lustre/fangdong.wang/verl_0.7.0/data_process/score_5/orsta/train_detection_v3det_5858_double_fixed.jsonl",
    "dcube": "/lustre/fangdong.wang/verl_0.7.0/data_process/score_5/orsta/train_grounding_dcube_7807_double_fixed.jsonl",
    "geo3k": "/lustre/fangdong.wang/verl_0.7.0/data_process/score_5/orsta/train_math_geo3k_2137.jsonl",
    "mmk12": "/lustre/fangdong.wang/verl_0.7.0/data_process/score_5/orsta/train_math_mmk12_5048.jsonl",
    "mmmath": "/lustre/fangdong.wang/verl_0.7.0/data_process/score_5/orsta/train_math_mmmath_2488.jsonl",
    "estvqa": "/lustre/fangdong.wang/verl_0.7.0/data_process/score_5/orsta/train_ocr_estvqa_2464.jsonl",
    "llavaov": "/lustre/fangdong.wang/verl_0.7.0/data_process/score_5/orsta/train_ocr_llavaov_2013.jsonl",
    "puzzlevqa": "/lustre/fangdong.wang/verl_0.7.0/data_process/score_5/orsta/train_puzzle_puzzlevqa_4818.jsonl",
    "visualpuzzle": "/lustre/fangdong.wang/verl_0.7.0/data_process/score_5/orsta/train_puzzle_visualpuzzle_586.jsonl",
    "scienceqa": "/lustre/fangdong.wang/verl_0.7.0/data_process/score_5/orsta/train_science_scienceqa_416.jsonl",
    "scivqa": "/lustre/fangdong.wang/verl_0.7.0/data_process/score_5/orsta/train_science_scivqa_1119.jsonl",
    "science_virl39k": "/lustre/fangdong.wang/verl_0.7.0/data_process/score_5/orsta/train_science_virl39k_2158.jsonl",

    "vision-sr1-math": "/lustre/neos.yan/open_data/1112/vision_sr1_math_7686.jsonl",
    "vision-sr1-mcq": "/lustre/neos.yan/open_data/1112/vision_sr1_mcq_20602.jsonl",

    "srpo-math": "/lustre/neos.yan/open_data/1112/srpo_math_23457.jsonl",
    "srpo-mcq": "/lustre/neos.yan/open_data/1112/srpo_mcq_12668.jsonl",

}

DATA_DICT = {
    "thinklite_normal": "GeneralVQA",
    "thinklite_hard": "GeneralVQA",
    "thinker_puzzle": "GeneralVQA",
    "thinker_mmiq": "MCQ",
    "mm_eureka_k12": "MATH",
    
    "DocVQA": "GeneralVQA",
    "InfoVQA": "GeneralVQA",
    "TextVQA": "GeneralVQA",
    "Refcoco": "Grounding",
    "Refcoco+": "Grounding",
    "Refcocog": "Grounding",
    "ChartQA": "GeneralVQA",

    # 去除bboxed格式
    "chartqapro": "GeneralVQA",
    "chartx": "GeneralVQA",
    "tablevqa": "GeneralVQA",
    "chart_virl39k": "GeneralVQA",
    "clevr": "GeneralVQA",
    # Grounding
    "object365": "Grounding",
    "v3det": "Grounding",
    "dcube": "Grounding",
    # Math
    "geo3k": "MATH",
    "mmk12": "MATH",
    "mmmath": "MATH",
    "estvqa": "GeneralVQA",
    "llavaov": "GeneralVQA",
    "puzzlevqa": "GeneralVQA",
    "visualpuzzle": "GeneralVQA",
    "scienceqa": "GeneralVQA",
    "scivqa": "GeneralVQA",
    "science_virl39k": "GeneralVQA",

    "vision-sr1-math": "MATH",
    "vision-sr1-mcq": "MCQ",
    "srpo-math": "MATH",
    "srpo-mcq": "MCQ",
}

output_folder = "/lustre/neos.yan/vlm-data/high_1114"
os.makedirs(output_folder, exist_ok=True)


feature = Features({
    "data_source": Value(dtype="string"),
    "image": [Value(dtype="string")],
    "prompt": [{
        "content": Value(dtype="string"),
        "role": Value(dtype="string"),
    }],
    "reward_model": {
        "ground_truth": {
            "accuracy_ratio": Value(dtype="float32"),
            "format_ratio": Value(dtype="float32"),
            "think_ratio": Value(dtype="float32"),
            "question": Value(dtype="string"),
            "ground_truth": Value(dtype="string"),
            "verifier": Value(dtype="string"),
            "image_path": Value(dtype="string"),
            "id": Value(dtype="int64")
        },
    },
    "image_num_tiles": [Value(dtype="int64")],
    "extra_info": {
        "image": Value(dtype="string"),
        "content": Value(dtype="string"),
    }
})


all_id = 0
result = []
for key, file_path in FILE_DICT.items():

    with open(file_path, "r", encoding="utf-8") as f:
        lines = f.readlines()
        datas = [json.loads(line.strip()) for line in lines]

    for data in tqdm(datas, total=len(datas)):
        if data.get('image', None) is None:
            continue 

        for idx in range(0, len(data['conversations']), 2):
            tdata = copy.deepcopy(data)

            image_path = []
            if isinstance(tdata['image'], list):
                tdata['image'] = tdata['image']
                image_path = tdata['image']
            elif isinstance(tdata['image'], str):
                tdata['image'] = [tdata['image']]
                image_path = [tdata['image']]
            else:

                if key in ['train_wo_ocr_processed', 'ocrvqa_train_v1.0_processed', "textvqa_train_v1.0_processed", "train_processed_bbox_normalize_0-1000", "train_full_labels_processed_bbox_normalize_0-1000", "train_label_processed_bbox_normalize_0-1000", "train_task_3_processed"]:
                    root = os.path.dirname(file_path) #"/lustre/yexun.zhang/datasets_external/OCR/InfoVQA/"
                elif key == "TextVQA":
                    root = "/lustre/yexun.zhang/datasets_external/OCR/textvqa/"
                else:
                    root = ""
                for _ in tdata['camera_key_frame_id']:
                    image_path.append(os.path.join(root, tdata['image'][_[0]][_[1]]))
                tdata['image'] = image_path

            image_diff = data['conversations'][idx]['value'].count('<image>') - len(image_path)
            if image_diff < 0:
                for _ in range(-image_diff):
                    data['conversations'][idx]['value'] = "<image>\n" + data['conversations'][idx]['value']
            elif image_diff > 0:
                continue


            if "<think>" in data['conversations'][idx]['value']:
                if key in ["thinker_puzzle"]:
                    data['conversations'][idx]['value'] =  data['conversations'][idx]['value'].split('\n')[0] + "\n" +  data['conversations'][idx]['value'].split('\n')[1]
                elif key in ['thinker_mmiq']:
                    data['conversations'][idx]['value'] =  (data['conversations'][idx]['value'].split('First output the thinking process')[0]).strip()
                elif key in ['mm_eureka_k12']:
                    data['conversations'][idx]['value'] =  data['conversations'][idx]['value'].split('Question:\n')[-1]
                elif key in ['multimodal_math_80k-80000']:
                    data['conversations'][idx]['value'] =  data['conversations'][idx]['value'].split('\n')[0]
                else:
                    print(key)

            
            # if "<think>" not in data['conversations'][idx]['value']:
            #     data['conversations'][idx]['value'] += "\nOutput the thinking process in <think> </think> and final answer in <answer> </answer> tags."

            answer = data['conversations'][idx + 1]['value']
            if "\\boxed" in answer:
                answer = re.findall(r'\\boxed\{(.*?)\}', answer)[0]

            answer = answer.strip()
            if DATA_DICT[key] == 'Grounding' and len(answer.split('\n')) > 1:
                continue

            all_id += 1
            tdata['data_source'] = f'{key}'
            tdata['prompt'] = [
                {
                    "role": "user",
                    "content": data['conversations'][idx]['value']
                }
            ]
            ground_truth = {
                "accuracy_ratio": 1.0,
                "format_ratio": 1.0,
                "think_ratio": 1.0,
                "image_path": tdata['image'],
                "question": data['conversations'][idx]['value'],
                "ground_truth": answer,
                'verifier': DATA_DICT[key],
                "id": all_id,
            }
            tdata['reward_model'] = {
                "ground_truth": ground_truth,
            }
            tdata['extra_info'] = {
                "image": tdata['image'],
                "content": data['conversations'][idx]['value']
            }
            tdata["image_num_tiles"] = [0]

            tdata_keys = list(tdata.keys())
            for k in tdata_keys:
                if str(k) not in ['data_source', 'image', 'prompt', 'reward_model', 'extra_info', "image_num_tiles"]:
                    tdata.pop(k)

            result.append(tdata)
    
print(len(result))
random.shuffle(result)
_ = 0
while True:
    st = _ * 5000
    if st >= len(result):
        break

    ed = min((_ + 1) * 5000, len(result))
    dataset = Dataset.from_list(result[st:ed], features=feature)
    dataset = dataset.cast(features=feature)
    output_path = os.path.join(output_folder, f"random_shard_{_}.parquet")
    dataset.to_parquet(output_path)
    _ += 1


file_list = os.listdir(output_folder)
output = "["
for file in file_list:
    output += os.path.join(output_folder, file) + ","

output += "]"
print(output)