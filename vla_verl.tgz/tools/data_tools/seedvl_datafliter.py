import os
import io
import json
import pdb
import cv2
import base64
import niofs
import sys
from pathlib import Path
import numpy as np
from niofs.conf import Cloud
from niofs.read_cache_op_py import read_cache_op_py
from glob import glob
from tqdm import tqdm
from PIL import Image
from pprint import pprint
from openai import OpenAI
from typing import Union,List,Dict,Optional
from concurrent.futures import ThreadPoolExecutor, as_completed

sys.path.append(str(Path(__file__).parent.parent))
# ------- Prompt ---------
PROMPT = """
You are a professional QA (Question-Answering) quality evaluator. Based on the provided question (Q) and answer (A) below, conduct a comprehensive and objective evaluation of their overall quality across multiple dimensions.

---

### 1. QA Pair to Evaluate

*   **Question (Q):** {question}
*   **Answer (A):** {answer}

---

### 2. Scoring Criteria (Total Score: 5 Points; 1 Point = Worst, 5 Points = Best)

Evaluate across the following 5 dimensions, with 1 point being the maximum score for each dimension:

*   **Dimension 1: Question Quality (Q - Quality)**
    *   **5 Points:** The question is very clear, specific, unambiguous, and answerable.
    *   **4 Points:** The question is clear with minor ambiguity that does not affect understanding or answering.
    *   **3 Points:** The question is basically clear but has certain ambiguity or is overly broad, which may lead to an imprecise answer.
    *   **2 Points:** The question is poorly expressed, ambiguous, or contains irrelevant information that hinders understanding.
    *   **1 Point:** The question is unintelligible, incomplete, or contrary to facts.

*   **Dimension 2: Answer Accuracy (A - Accuracy)**
    *   **5 Points:** The answer is completely correct, factually accurate, and logically rigorous.
    *   **4 Points:** The answer is basically correct with minor flaws that do not affect the core meaning.
    *   **3 Points:** The answer is partially correct but contains some incorrect or outdated information.
    *   **2 Points:** The answer is related to the question but has incorrect core content.
    *   **1 Point:** The answer is completely incorrect or irrelevant to the question.

*   **Dimension 3: Answer Completeness (A - Completeness)**
    *   **5 Points:** The answer is comprehensive and detailed, fully covering all aspects of the question.
    *   **4 Points:** The answer is complete, meets the core needs of the question, with only minor details missing.
    *   **3 Points:** The answer is partially complete, addressing only part of the question with key information missing.
    *   **2 Points:** The answer is overly brief, providing only very basic information.
    *   **1 Point:** The answer provides almost no valuable information.

*   **Dimension 4: Answer Precision (A - Precision)**
    *   **5 Points:** The answer is concise and to the point, without any redundant or irrelevant information.
    *   **4 Points:** The answer is generally concise with occasional minor redundant information that does not affect understanding.
    *   **3 Points:** The answer contains some unnecessary information but the core content remains clear.
    *   **2 Points:** The answer is lengthy, filled with content loosely related to the question, which affects readability.
    *   **1 Point:** The answer is disorganized, making it impossible to extract valid information.

*   **Dimension 5: Relevance and Consistency (Q-A Alignment)**
    *   **5 Points:** The answer is highly relevant to the question, fully addresses it, and is logically consistent.
    *   **4 Points:** The answer is relevant to the question, addresses it effectively, with occasional minor digressions.
    *   **3 Points:** The answer has some relevance to the question but contains partially off-topic content or minor logical inconsistencies.
    *   **2 Points:** The answer has weak relevance to the question, with most content being irrelevant.
    *   **1 Point:** The answer is completely irrelevant to the question.

---

### 3. Output Format

Directly output the total score without providing additional explanations.
Example: 5.0
"""

# --------utils ----------


# -------------------
vision_sr1 = [
    "/lustre/MLM_evaluator/data/open_data/vision-sr1/vision-sr1_math-17927.jsonl",
    "/lustre/MLM_evaluator/data/open_data/vision-sr1/vision-sr1_mcq-29701.jsonl"
]

orsta = [
    # "/lustre/MLM_evaluator/data/open_data/orsta/train_chart_chartqapro_498.jsonl",
    # "/lustre/MLM_evaluator/data/open_data/orsta/train_chart_chartx_2353.jsonl",
    # "/lustre/MLM_evaluator/data/open_data/orsta/train_chart_tablevqa_496.jsonl",
    # "/lustre/MLM_evaluator/data/open_data/orsta/train_chart_virl39k_1657.jsonl",
    # "/lustre/MLM_evaluator/data/open_data/orsta/train_counting_clevr-1725.jsonl",
    # "/lustre/MLM_evaluator/data/open_data/orsta/train_detection_object365_4000_fixed.jsonl",
    # "/lustre/MLM_evaluator/data/open_data/orsta/train_detection_v3det_4000_fixed.jsonl",
    # "/lustre/MLM_evaluator/data/open_data/orsta/train_grounding_dcube_4870_fixed.jsonl",
    # "/lustre/MLM_evaluator/data/open_data/orsta/train_math_geo3k_2983.jsonl",
    # "/lustre/MLM_evaluator/data/open_data/orsta/train_math_mmk12_5732.jsonl",
    # "/lustre/MLM_evaluator/data/open_data/orsta/train_math_mmmath_3539.jsonl",
    # "/lustre/MLM_evaluator/data/open_data/orsta/train_ocr_estvqa_2946.jsonl",
    # "/lustre/MLM_evaluator/data/open_data/orsta/train_ocr_llavaov_3092.jsonl",
    # "/lustre/MLM_evaluator/data/open_data/orsta/train_puzzle_puzzlevqa_2648_x2.jsonl",
    # "/lustre/MLM_evaluator/data/open_data/orsta/train_puzzle_visualpuzzle_342_x2.jsonl",
    # "/lustre/MLM_evaluator/data/open_data/orsta/train_science_scienceqa_536.jsonl",
    # "/lustre/MLM_evaluator/data/open_data/orsta/train_science_scivqa_1264.jsonl",
    "/lustre/MLM_evaluator/data/open_data/orsta/train_science_virl39k_2539.jsonl",
]

srpo = [
    "/lustre/neos.yan/open_data/SRPO_RL_datasets/data/quick_47Krelease.jsonl"
]

PATH_DICT = {
    "orsta":orsta,
    "vision_sr1":vision_sr1,
    "srpo":srpo
}

def write_list_to_jsonl(data_list: List, file_path: str) -> None:
    with open(file_path, 'w', encoding='utf-8') as f:
        for item in data_list:
            try:
                json_str = json.dumps(item, ensure_ascii=False)
                f.write(json_str + '\n')
            except json.JSONEncodeError as e:
                print(f"{e}")


def loadload_image(image_path, root=None, tar_saved=False):
    ON_TXSH = 1
    mount_point = (
        "/lustre" if os.path.exists("/lustre") else "/perception-hl/MLM_evaluator"
    )
    if ":" in image_path:
        read_ceph_kwargs = {}
        if ON_TXSH:
            read_ceph_kwargs["mnt_point"] = mount_point
        if tar_saved:
            tar_path, tar_size, img_offset, img_size = image_path.split(" ")
            tar_path = f"{tar_path} {tar_size}"
            ceph_path = "/" + tar_path.split(":")[1]
            raw_bytes = read_cache_op_py([ceph_path], **read_ceph_kwargs)
            image_bytes = raw_bytes[0][int(img_offset) : int(img_offset) + int(img_size)]
        else:
            if not ON_TXSH:
                if ":" in image_path:
                    ceph_path = "/" + image_path.split(":")[1]
                else:
                    ceph_path = image_path
            else:
                if image_path.startswith("/"):
                    ceph_path = image_path.split(" ")[0]
                else:
                    ceph_path = "/" + image_path.split(" ")[0].split(":")[1]

            raw_bytes = read_cache_op_py([ceph_path], **read_ceph_kwargs)
            image_bytes = raw_bytes[0]

        decoded = cv2.imdecode(np.frombuffer(image_bytes, np.uint8), -1)  # BGR
        if decoded.ndim == 2:
            decoded = np.tile(decoded[..., np.newaxis], (1, 1, 3))
        image = Image.fromarray(decoded[:, :, ::-1], "RGB")
    else:
        if "/" in image_path:
            image = Image.open(image_path).convert('RGB')
        else:
            image_path = os.path.join(root, image_path)
            image = Image.open(image_path).convert('RGB')

    return image


def image_to_base64_str(image: Image.Image, format: str = 'PNG') -> str:
    """
    将PIL的Image对象转换为Base64字符串

    :param image: PIL的Image对象
    :param format: 图像格式，如'PNG'、'JPEG'等
    :return: 转换后的Base64字符串
    """
    buffer = io.BytesIO()
    image.save(buffer, format=format)
    image_bytes = buffer.getvalue()
    buffer.close()
    base64_str = base64.b64encode(image_bytes).decode('utf-8')

    return base64_str


def file_to_base64(image_path):
    import base64
    with open(image_path, "rb") as f:
        return "data:image/jpeg;base64," + base64.b64encode(f.read()).decode()


def read_jsonl(path):
    with open(path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    datas = [json.loads(line.strip()) for line in lines]
    return datas


def save_jsonl(data_list,save_path):
    with open(save_path,'w',encoding = 'utf-8') as f:
        for item in data_list:
            try:
                json_str = json.dumps(item, ensure_ascii=False)
                f.write(json_str + '\n')
            except (json.JSONEncodeError,json.JSONDecodeError) as e:
                print(f"{e}")


def seed_inference_one_sample(image_path,question):

    base_url = "https://ark.cn-beijing.volces.com/api/v3"
    api_key = "88b97866-80d6-49bf-976b-51caac340461"
    model_name = "doubao-1-5-thinking-vision-pro-250428"

    client = OpenAI(
        base_url=base_url,
        api_key=api_key,
    )
    image_base64 = None
    if "huailai" in image_path:    
        image = loadload_image(image_path) 
        image_base64 = "data:image/jpeg;base64,"+ str(image_to_base64_str(image, (image_path.split(' ')[0]).split('.')[-1]))
    else:
        image_base64 = file_to_base64(image_path)

    response = client.chat.completions.create(
        extra_body={"thinking": {"type": "disabled"}},
        model=model_name,
        messages=[
            {
                "role": "user",
                "content": [
                    {"type": "image_url", "image_url": {"url": image_base64}},
                    {"type": "text", "text": question},
                ],
            }
        ],
        temperature=0.8,
    )
    return response.choices[0].message.content.strip()


def process_single_item(item: Dict) -> Dict:
    """
    单条数据的处理函数（线程执行单元）
    输入：原始数据项（含 question, answer, image_path）
    输出：添加 score 后的新数据项（含异常信息，可选）
    """
    try:
        question = item["conversations"][0]["value"]
        answer = item["conversations"][1]["value"]
        import pdb
        pdb.set_trace()
        image_path = item["image"]

        if isinstance(image_path, list):
            image_path = image_path[0]

        prompt = PROMPT.format(question=question, answer=answer)

        if not image_path:
            raise ValueError(f"图像路径为空（item: {item.get('id', '未知')}）")

        quality_score = seed_inference_one_sample(image_path, prompt)
        item["score"] = quality_score
        item["process_status"] = "success"  

    except Exception as e:
        print(f"处理数据失败（item: {item.get('id', '未知')}）：{str(e)}")
        item["score"] = 0.0
        item["process_status"] = f"failed: {str(e)}"  

    return item


def score(path: str, save_path: Optional[str] = None):
    data = read_jsonl(path)
    output_datas = []
    total_tasks = len(data)
    max_workers = 8  
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_item = {executor.submit(process_single_item, item): item for item in data}

        with tqdm(total=total_tasks, desc="scoring (multi-thread)") as pbar:
            for future in as_completed(future_to_item):
              
                processed_item = future.result()
                output_datas.append(processed_item)
            
                pbar.update(1)

    with open(save_path, "w", encoding="utf-8") as out_f:  
        for item in output_datas:
            out_f.write(json.dumps(item, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    root = "/lustre/fangdong.wang/verl_0.7.0/data_process/score"
    for k,v in PATH_DICT.items():
        folder = os.path.join(root,k)
        if not os.path.exists(folder):
            os.makedirs(folder)
        for f in v:
            print(f'Processing {f}')
            save_path = os.path.join(folder,os.path.basename(f))
            score(f,save_path)
    