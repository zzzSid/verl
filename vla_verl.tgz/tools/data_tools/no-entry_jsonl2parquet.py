import re
import datasets
import json
import numpy as np
from datasets import Features, Value
from pathlib import Path

def map_func(split, rw_version):
    
    def process_fn(sample, idx):
        image = sample.pop('image')
        camera_key_frame_id = sample.pop('camera_key_frame_id')
        image_list = list()
        for cam_key in camera_key_frame_id:
            _cam = cam_key[0]
            _idx = int(cam_key[1])
            image_list.append(image[_cam][_idx])
        conversations = sample.pop('conversations')
        extra_dict = sample.pop('extra')
        clip_id = extra_dict['clip_id']

        prompt = sample.pop("prompt")
        
        parts = prompt.split("<image>")
        keep_images = 13
        cut = keep_images + 1  # split 后要保留的段数

        if len(parts) > cut:
            # 前 cut 段之间保留 <image>，后面的段直接拼接（等价于删掉多余的 <image>）
            prompt = "<image>".join(parts[:cut]) + "".join(parts[cut:])
        else:
            prompt = "<image>".join(parts)  # 原样（或者直接 prompt 不变也行）


        question = prompt + conversations[0]['value']
        answer_raw = conversations[1]['value']
        all_cand_gts = extra_dict['all_cand_gts']
        
        if "<think>" in answer_raw:
            cot_text = re.search(r'<think>(.*?)</think>', answer_raw, re.DOTALL).group(0)
            ans_text = re.search(r'<answer>(.*?)</answer>', answer_raw, re.DOTALL).group(0)
        else:
            cot_text = None
            ans_text = answer_raw
        data_source = f"no-entry_{rw_version}"
        data = {
            "clip_id": clip_id,
            "uuid": clip_id,
            "type": "no-entry",
            "data_source": data_source,
            "prompt": [
                {
                    "role": "user",
                    "content": question,
                }
            ],
            "image": image_list,
            "image_num_tiles": np.array(sample.pop("image_num_tiles")),
            "reward_model": {"style": "rule", "ground_truth": all_cand_gts},
            "extra_info": {
                "split": split,
                "index": idx,
                "clip_id":clip_id,
                "answer": ans_text,
                "question": question,
                "need_tools_kwargs": True,
                "tools_kwargs": {
                    "calc_no-entry_reward": {
                        "create_kwargs": {"ground_truth": all_cand_gts},
                        # "execute_kwargs": {},
                        "calc_reward_kwargs":{"cot": cot_text,
                                              "ground_truth": all_cand_gts},
                        # "release_kwargs": {},
                    },
                },
            }
        }
        return data
    return process_fn

def process_jsonl_streaming(data_file):
    temp_datasets = []
    with open(data_file, 'r', encoding='utf-8') as f:
        examples = []
        for line in f:
            data = json.loads(line)
            if 'camera_key_frame_id' in data:
                data['camera_key_frame_id'] = [[str(x[0]), str(x[1])] for x in data['camera_key_frame_id']]
            examples.append(data)
    dataset = datasets.Dataset.from_list(examples)
    temp_datasets.append(dataset)
    return datasets.concatenate_datasets(temp_datasets)

def main(config):
    in_train_ds = process_jsonl_streaming(config['train'])
    in_test_ds = process_jsonl_streaming(config['test'])
    rw_tag = config['tag']
    train_dataset = in_train_ds.map(function=map_func('train', rw_tag), with_indices=True)
    test_dataset = in_test_ds.map(function=map_func('test', rw_tag), with_indices=True)
    train_save_path = config['train'].replace('.jsonl', '_new.parquet')
    test_save_path = config['test'].replace('jsonl', 'parquet')
    train_dataset.to_parquet(train_save_path); print(f"train_save_path: {train_save_path}")
    test_dataset.to_parquet(test_save_path); print(f"test_save_path: {test_save_path}")

if __name__ == "__main__":
    config = {
        'train': '/lustre/joeden.zhuang/projects/vlm_no_entry/output_prod/no_entry_road_train_1116-2-rl.jsonl',
        # "train":"/lustre/joeden.zhuang/projects/vlm_no_entry/output_prod/no_entry_road_train_1116-2-rl_filter_5k.jsonl",
        'test': '/lustre/joeden.zhuang/projects/vlm_no_entry/output_prod/no_entry_road_test_1110-1.jsonl',
        'tag': 'simple-cot-postpos',
    }
    main(config)