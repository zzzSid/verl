import os

import json
import re
import copy
import argparse
import datasets
from datasets import Features, Value, Sequence, Dataset
from io import BytesIO
from PIL import Image
import numpy as np
from tqdm import tqdm
import concurrent.futures


output_folder = "/perception-hl/ad-cn-hlidc-multimodal/inner_datasets/rl_data"
output_folder = "/lustre/neos.yan/open_data/rl_data"


def is_number(s):
    pattern = r'^\s*[+-]?(\d+(\.\d*)?|\.\d+)(%?)\s*$'
    if re.match(pattern, s):
        return True
    else:
        return False

def is_short(s, data_name=None):
    s_words = s.split(' ')
    if len(s_words) > 3:
        return False
    elif data_name is not None and len(s) > 20:
        return False
    else:
        return True

def extract_label(s):
    if '请找出关于' in s:
        pattern = r"请找出关于(.*?)的位置"
        match = re.search(pattern, s)
        if match:
            return match.group(1)
        else:
            return None
    elif 'Please find the ' in s:
        pattern = r"Please find the (.*?) in the picture."
        match = re.search(pattern, s)
        if match:
            return match.group(1)
        else:
            return None
    else:
        return None


FILE_DICT = {
    # "chartqapro": "/perception-hl/ad-cn-hlidc-multimodal/open_datasets/ChartQAPro/chartqapro_1948.jsonl",
    # "chartx": '/perception-hl/ad-cn-hlidc-multimodal/open_datasets/ChartX/ChartX.jsonl',
    # "deepform": '/perception-hl/ad-cn-hlidc-multimodal/open_datasets/ollama/deepform_5800.jsonl',
    # "robut": '/perception-hl/ad-cn-hlidc-multimodal/open_datasets/ollama/robut-sqa-cauldron(llavaov)_8509.jsonl',
    # "tatdqa": '/perception-hl/ad-cn-hlidc-multimodal/open_datasets/ollama/tatdqa_2207.jsonl',
    # "graphics-counting": '/perception-hl/ad-cn-hlidc-multimodal/open_datasets/chinese_ocr_ours/generate_img_5000.jsonl',
    # "refcoco": '/lustre/MLM_evaluator/data/RefCOCO/jsonls_normalize_0-1000/refcocog_train.jsonl',
    # "pr1": '/perception-hl/ad-cn-hlidc-multimodal/open_datasets/pr1/iv3-pr1_fixed_short.jsonl',
    # "geo3k": '/lustre/MLM_evaluator/data/InternVL2_5_SFT/image_data/geometry3k/geometry3k_cot_gpt4o_en.jsonl',
    # "mavis-math": '/perception-hl/ad-cn-hlidc-multimodal/open_datasets/ollama/mavis-math-metagen(llavaov)_87348.jsonl',
    # "mmk12":  '/perception-hl/ad-cn-hlidc-multimodal/open_datasets/MMK12/MMK12.jsonl',
    # "mmmath": '/perception-hl/ad-cn-hlidc-multimodal/open_datasets/MM_Math/MM_Math.jsonl',
    # "chinese-ocr": '/perception-hl/ad-cn-hlidc-multimodal/open_datasets/ch_ocr_bench/ch_ocr_bench.jsonl',
    # "textvqa": '/lustre/yexun.zhang/datasets_external/OCR/textvqa/textvqa_train_v1.0_processed.jsonl',
    # "columbus": '/perception-hl/ad-cn-hlidc-multimodal/open_datasets/COLUMBUS/COLUMBUS.jsonl',
    # "hyperphantasia": '/perception-hl/ad-cn-hlidc-multimodal/open_datasets/Hyperphantasia/Hyperphantasia.jsonl',
    # "puzzlevqa": '/perception-hl/ad-cn-hlidc-multimodal/open_datasets/PuzzleVQA/PuzzleVQA.jsonl',
    # "visualpuzzle": '/perception-hl/ad-cn-hlidc-multimodal/open_datasets/VisualPuzzles/VisualPuzzles.jsonl',
    # "visualsphinx": '/perception-hl/ad-cn-hlidc-multimodal/open_datasets/VisualSphinx-V1-Raw/VisualSphinx-V1-Raw.jsonl',
    # "scienceqa": '/lustre/MLM_evaluator/data/InternVL2_5_SFT/image_data/scienceqa/scienceqa_choice_aug_en.jsonl',
    # "scienceqa_aug": '/lustre/MLM_evaluator/data/InternVL2_5_SFT/image_data/scienceqa/scienceqa_multi_choice_en.jsonl',
    # "scivqa": '/perception-hl/ad-cn-hlidc-multimodal/open_datasets/SciVQA/SciVQA.jsonl'
}

feature = Features({
    "data_source": Value(dtype="string"),
    "images": Sequence(datasets.Image(decode=True)),
    "prompt": [{
        "content": Value(dtype="string"),
        "role": Value(dtype="string"),
    }],
    "ability": Value(dtype="string"),
    "reward_model": {
        "accuracy_ratio": Value(dtype="float32"),
        "answer": Value(dtype="string"),
        "format_ratio": Value(dtype="float32"),
        "ground_truth": {
            "accuracy_ratio": Value(dtype="float32"),
            "format_ratio": Value(dtype="float32"),
            "ground_truth": Value(dtype="string"),
            "verifier": Value(dtype="string"),
        },
        "verifier": Value(dtype="string"),
        "verifier_parm": {
            "det_reward_ratio": {
                "iou_completeness": Value(dtype="float32"),
                "iou_max_iou_first": Value(dtype="float32"),
                "iou_max_label_first": Value(dtype="float32"),
                "map": Value(dtype="float32"),
                "map50": Value(dtype="float32"),
                "map75": Value(dtype="float32"),
            },
            "det_verifier_normalized": Value(dtype="bool"),
        },
    },
    "extra_info": {
        "id": Value(dtype="string"),
        "image_path": Value(dtype="string"),
    },
})


def process_chart_dataset(data_name, data_path):

    def read_datas(data_name, data_path):
        data_qa = []

        with open(data_path, 'r') as file:
            datas = file.readlines()

        # [NOTE]neos.yan: 最多80000条
        datas = datas[:80000]
        if data_name == "visualsphinx":
            datas = datas[:30000]

        for d in datas:
            d = json.loads(d.strip())
            if data_name == "chartqapro":
                answer = d['conversations'][1]['value']
                if answer != 'Unanswerable':
                    data_qa.append(d)
            elif data_name in ["chartx", "robut", "tatdqa"]:
                conv = d['conversations']

                if len(conv) % 2 != 0:
                    continue
                qa_count = len(conv) // 2
                for i in range(qa_count):
                    if is_short(d['conversations'][i*2+1]['value'], data_name):
                        d_temp = copy.deepcopy(d)
                        d_temp['conversations'] = [
                            {
                                'from': 'human',
                                'value': d['conversations'][i*2]['value']
                            },
                            {
                                'from': 'gpt',
                                'value': d['conversations'][i*2+1]['value']
                            }
                        ]
                        data_qa.append(d_temp)
            elif data_name in ['refcoco']:
                if d['conversations'][1]['value'].count('<ref>') == 1 and d['conversations'][1]['value'].count('<box>') == 1:
                    data_qa.append(d)
            elif data_name in ['pr1']:
                if '<box>' in d['conversations'][1]['value']:
                    prompt = d['conversations'][0]['value']
                    label = extract_label(prompt)
                    if label == None:
                        continue
                    if label.count(' ') > 3:
                        continue
                    d['label'] = label
                    data_qa.append(d)
            elif data_name in ['geo3k']:
                if d['conversations'][1]['value'].count('ANSWER: ') == 1:
                    data_qa.append(d)
            elif data_name in ['mavis-math']:
                if d['conversations'][1]['value'].count('Answer: ') == 1:
                    data_qa.append(d)
            elif data_name in ['mmmath']:
                if d['conversations'][1]['value'].count('boxed{') == 1:
                    data_qa.append(d)
            elif data_name in ["scienceqa"]:
                if 'image' in d.keys():
                    data_qa.append(d)
            elif data_name in ["scienceqa_aug"]:
                if '. ' in d['conversations'][1]['value']:
                    data_qa.append(d)
            elif data_name in ["scivqa"]:
                if 'It is not possible to answer this' not in d['conversations'][1]['value']:
                    data_qa.append(d)
            else:
                data_qa.append(d)


        return data_qa
        
    data_qa = read_datas(data_name, data_path)

    def process_item(data_name, d, data_type='math'):
        data_source = 'ostra_' + data_name

        if data_name == 'chartx':
            img_path = '/perception-hl/ad-cn-hlidc-multimodal/open_datasets/ChartX/ChartX_png' +  d['image'][1:] 
        elif data_name in ['refcoco']:
            img_path = d['image']['UNKNOWN'][0]
        elif data_name in ['geo3k']:
            img_path = '/lustre/MLM_evaluator/data/InternVL2_5_SFT/image_data/geometry3k/' + d['image']
        elif data_name == "textvqa":
            img_path = '/lustre/yexun.zhang/datasets_external/OCR/textvqa/' + d['image']['UNKNOWN'][0]
        elif data_name == "scienceqa":
            img_path = '/lustre/MLM_evaluator/data/InternVL2_5_SFT/image_data/scienceqa/' + d['image']
        elif data_name == "scienceqa_aug":
            img_path = '/lustre/MLM_evaluator/data/InternVL2_5_SFT/image_data/scienceqa/' + d['image']
        else:
            img_path = d['image']

        pil_image = Image.open(img_path).convert("RGB")
        with BytesIO() as buffer:
            pil_image.save(buffer, format="PNG")  # 保存为 PNG 格式到内存缓冲区
            png_binary = buffer.getvalue()  # 获取二进制数据

        images = [{
            'bytes': png_binary,
            'path': "",
        }]

        p = d['conversations'][0]['value']
        if data_name in ['robut', 'tatdqa']:
            if '<image>' in p:
                p = p.split('\n')[1]
            p = "<image>\n" + p
        elif data_name in ['refcoco']:
            p += "Begin by clearly explaining tour thought process enclosed within <think> and </think> tags.Afterward, present your final detection result enclosed within <answer> and </answer> tags.\nFor example:\n<think>\nYour detailed reasoning process here.\n</think>\n<answer>\n[{'bbox_2d': <box>x1,y1,x2,y2</box>, 'label': label_name}]\n</answer>\n"
            p = "<image>\n" + p
        elif data_name in ['pr1']:
            label = d['label']
            p = f"Please provide the bounding box coordinate of the region this sentence describes:<ref>{label}</ref>\n" + "Begin by clearly explaining tour thought process enclosed within  <think> and </think> tags.Afterward, present your final detection result enclosed within <answer> and </answer> tags.\nFor example:\n<think>\nYour detailed reasoning process here.\n</think>\n<answer>\n[{'bbox_2d': <box>x1,y1,x2,y2</box>, 'label': label_name}]\n</answer>"
            p = "<image>\n" + p
        elif data_name in ['mmmath', "textvqa", "columbus", "hyperphantasia", "puzzlevqa", "visualpuzzle", "scivqa"]:
            p = "<image>\n" + p

        prompt = [{
            'content': f"{p}",
            'role': 'user'
        }]

        ability = data_type

        answer = d['conversations'][1]['value']
        ground_truth =f"\\boxed{{{answer}}}"
        if data_name in ['refcoco']:
            raw_answer = answer

            label_pattern = r"<ref>(.*?)</ref>"
            label = re.findall(label_pattern, raw_answer, re.DOTALL)[0]

            box_pattern = r"<box>(.*?)</box>"
            box = re.findall(box_pattern, raw_answer, re.DOTALL)[0]
            box = f"<box>{box}</box>"

            answer = f"[{{'bbox_2d': {box}, 'label': '{label}'}}]"
            ground_truth = f"<answer>\n[{{'bbox_2d': {box}, 'label': '{label}'}}]\n</answer>"
        elif data_name in ['geo3k']:
            answer = d['conversations'][1]['value'].split('ANSWER: ')[1].strip()
            ground_truth =f"\\boxed{{{answer}}}"
        elif data_name in ['mavis-math']:
            answer = d['conversations'][1]['value'].split('Answer: ')[1]
            ground_truth =f"\\boxed{{{answer}}}"
        elif data_name in ['pr1']:
            raw_answer = answer
            box_pattern = r"<box>(.*?)</box>"
            box = re.findall(box_pattern, raw_answer, re.DOTALL)[0]
            box = f"<box>{box}</box>"
            answer = f"[{{'bbox_2d': {box}, 'label': '{label}'}}]"
            ground_truth = f"<answer>\n[{{'bbox_2d': {box}, 'label': '{label}'}}]\n</answer>"

        reward_model = {
            'answer':answer,
            'ground_truth': {
                'ground_truth': ground_truth,
                'accuracy_ratio': np.float32(1.0),
                'format_ratio': np.float32(0.0),
                'verifier': 'mathverify',
            },
            'accuracy_ratio': np.float32(1.0),
            'format_ratio': np.float32(0.0),
            'verifier': 'mathverify',
            'verifier_parm': {
                'det_verifier_normalized': None,
                'det_reward_ratio': {
                    'iou_max_label_first': None,
                    'iou_max_iou_first': None,
                    'iou_completeness': None,
                    'map': None,
                    'map50': None,
                    'map75': None,
                }
            }
        }

        if data_name in ['refcoco', 'pr1']:
            reward_model['ground_truth']['format_ratio'] = np.float32(0.10000000149011612)
            reward_model['ground_truth']['verifier'] = 'detection'
            reward_model['format_ratio'] = np.float32(0.10000000149011612)
            reward_model['verifier'] = 'detection'
            reward_model['verifier_parm']['det_verifier_normalized'] = True
            reward_model['verifier_parm']['det_reward_ratio']['iou_max_label_first'] = np.float32(1.0)
            reward_model['verifier_parm']['det_reward_ratio']['iou_max_iou_first'] = np.float32(0.0)
            reward_model['verifier_parm']['det_reward_ratio']['iou_completeness'] = np.float32(0.30000001192092896)
            reward_model['verifier_parm']['det_reward_ratio']['map'] = np.float32(0.0)
            reward_model['verifier_parm']['det_reward_ratio']['map50'] = np.float32(0.0)
            reward_model['verifier_parm']['det_reward_ratio']['map75'] = np.float32(0.0)


        extra_info = {
            'id': '',
            'image_path': '',
        }

        final_temp = {
            'data_source': data_source,
            'images': images,
            'prompt': prompt,
            'ability': ability,
            'reward_model': reward_model,
            'extra_info': extra_info,
        }
        return final_temp

    if data_name in ["chartqapro", "chartx", "deepform", "robut", "tatdqa"]:
        data_type = "chart"
    elif data_name in ["graphics-counting", "refcoco", "pr1"]:
        data_type = "detection"
    elif data_name in ["geo3k", "mavis-math", "mmk12", "mmmath"]:
        data_type = "math"
    elif data_name in ["chinese-ocr", "textvqa"]:
        data_type = "ocr"
    elif data_name in ['columbus', 'hyperphantasia', 'puzzlevqa', 'visualpuzzle', 'visualsphinx']:
        data_type = "puzzle"
    else:
        data_type = "science"

    result = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=100) as executor:
        futures = [executor.submit(process_item, data_name, d, data_type) for d in data_qa]
        for future in concurrent.futures.as_completed(futures):
            result.append(future.result())


    _ = 0
    while True:
        st = _ * 2500
        if st >= len(result):
            break

        ed = min((_ + 1) * 2500, len(result))
        dataset = Dataset.from_list(result[st:ed], features=feature)
        dataset = dataset.cast(features=feature)
        output_path = os.path.join(output_folder, f"{data_name}-{len(data_qa)}_shard_{_}.parquet")
        dataset.to_parquet(output_path)
        _ += 1


for data_name, data_path in FILE_DICT.items():
    print(data_name, data_path)
    process_chart_dataset(data_name, data_path)

file_list = os.listdir(output_folder)
output = "["
for file in file_list:
    output += os.path.join(output_folder, file) + ","

output += "]"
print(output)
