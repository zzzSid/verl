import os
import pandas as pd
import pyarrow.parquet as pq
import pyarrow as pa
from tqdm import tqdm
import copy
from datasets import load_dataset
import numpy as np


def convert_bboxes_to_boxes(idx, input_str):
    if idx % 2 != 0:
        result = input_str.replace("[x1,y1,x2,y2]", "<box>x1,y1,x2,y2</box>")
        return result
    
    import re
    # 使用正则表达式匹配所有bbox_2d的列表值
    pattern = r"'bbox_2d':\s*(\[[^\]]*\])"
    
    # 查找所有匹配的bbox_2d列表
    bbox_matches = re.findall(pattern, input_str)
    
    # 为每个匹配创建替换内容
    replacements = {}
    for match in bbox_matches:
        # 移除非数字字符并保留逗号
        clean_coords = re.sub(r'[^\d,]', '', match)
        replacements[match] = f"<box>{clean_coords}</box>"
    
    # 执行替换
    for orig, new in replacements.items():
        input_str = input_str.replace(orig, new)


    result = input_str.replace('<box>', "'<box>")  # 在<box>前加单引号
    result = result.replace('</box>', "</box>'")  # 在</box>后加单引号
    result = result.replace('\'<box>x1,y1,x2,y2</box>\'', "<box>x1,y1,x2,y2</box>'")  # 在</box>后加单引号
    
    return input_str

def fix_and_change(row):
    cnt = 0
    row['reward_model']['accuracy_ratio'] = np.float32(row['reward_model']['accuracy_ratio'])
    row['reward_model']['format_ratio'] = np.float32(row['reward_model']['format_ratio'])
    if row['reward_model'].get('det_reward_ratio', None) is not None:
        row['reward_model']['det_reward_ratio']['iou_max_label_firt'] = np.float32(row['reward_model']['det_reward_ratio']['iou_max_label_firt'])
        row['reward_model']['det_reward_ratio']['iou_max_iou_first'] = np.float32(row['reward_model']['det_reward_ratio']['iou_max_iou_first'])
        row['reward_model']['det_reward_ratio']['iou_completeness'] = np.float32(row['reward_model']['det_reward_ratio']['iou_completeness'])
        row['reward_model']['det_reward_ratio']['map'] = np.float32(row['reward_model']['det_reward_ratio']['map'])
        row['reward_model']['det_reward_ratio']['map50'] = np.float32(row['reward_model']['det_reward_ratio']['map50'])
        row['reward_model']['det_reward_ratio']['map75'] = np.float32(row['reward_model']['det_reward_ratio']['map75'])
    row['data_source'] = "orsta_" + row['data_source']
    for content in row['prompt']:
        cnt += 1
        content['content'] = convert_bboxes_to_boxes(cnt, content['content'])
    row['reward_model']['answer'] = convert_bboxes_to_boxes(0, row['reward_model']['answer'])
    # temp_dict = {
    #     "format_ratio": copy.deepcopy(row['reward_model']['format_ratio']),
    #     "verifier": copy.deepcopy(row['reward_model']['verifier']),
    #     "accuracy_ratio": copy.deepcopy(row['reward_model']['accuracy_ratio']),
    #     "ground_truth": copy.deepcopy(row['reward_model']['ground_truth']),
    # }
    # row['reward_model']['ground_truth'] = copy.deepcopy(temp_dict)
    return row

input_folder = "/lustre/neos.yan/open_data/Orsta-Data-47k/train/"

file_list = os.listdir(input_folder)
for file in file_list:
    if file.endswith("_newbox.parquet") or not file.endswith(".parquet"):
        continue
    
    file_path = os.path.join(input_folder, file)
    output_file = os.path.join(input_folder, file.split('.')[0] + "_newbox.parquet")

    df = pd.read_parquet(file_path)

    dataset = load_dataset('parquet', data_files={'train': file_path})
    dataset = dataset.map(fix_and_change)
    dataset['train'].to_parquet(output_file)


    df = pd.read_parquet(output_file)

    for index, row in df.iterrows():
        print(row)
        break

# for index, row in tqdm(df.iterrows(), total=len(df)):
#     if index == 0:
#         print(row.keys())
#         print(row['reward_model'])
#     cnt = 0
#     row['data_source'] = "orsta_" + row['data_source']
#     for content in row['prompt']:
#         cnt += 1
#         content['content'] = convert_bboxes_to_boxes(cnt, content['content'])
#     row['reward_model']['answer'] = convert_bboxes_to_boxes(0, row['reward_model']['answer'])
#     temp_dict = {
#         "format_ratio": row['reward_model']['format_ratio'],
#         "verifier": row['reward_model']['verifier'],
#         "accuracy_ratio": row['reward_model']['accuracy_ratio'],
#         "grounground_truthd": row['reward_model']['ground_truth'],
#     }
#     row['reward_model']['ground_truth'] = copy.deepcopy(temp_dict)
#     if index == 0:
#         print(row['reward_model'])

# df.to_parquet(output_file, engine='pyarrow')