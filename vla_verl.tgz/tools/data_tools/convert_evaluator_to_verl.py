import os
import json
import re
import copy
import argparse
import datasets
from datasets import Features, Value, Sequence, Dataset
from io import BytesIO
from PIL import Image
import numpy as np
from tqdm import tqdm
import concurrent.futures
import pandas as pd
import random


def parse_args():
    parser = argparse.ArgumentParser(description="Convert evaluator jsonl to verl jsonl")
    parser.add_argument(
        "--input_path",
        type=str,
        required=True,
        help="Path to the input evaluator jsonl file",
    )
    parser.add_argument(
        "--output_path",
        type=str,
        required=True,
        help="Path to the output verl jsonl file",
    )
    return parser.parse_args()


feature = Features({
    "data_source": Value(dtype="string"),
    "image": [Value(dtype="string")],
    "prompt": [{
        "content": Value(dtype="string"),
        "role": Value(dtype="string"),
    }],
    "reward_model": {
        "ground_truth": {
            "accuracy_ratio": Value(dtype="float32"),
            "format_ratio": Value(dtype="float32"),
            "think_ratio": Value(dtype="float32"),
            "question": Value(dtype="string"),
            "ground_truth": Value(dtype="string"),
            "verifier": Value(dtype="string"),
            "image_path": Value(dtype="string"),
            "id": Value(dtype="int64")
        },
    },
    "image_num_tiles": [Value(dtype="int64")],
    "extra_info": {
        "image": Value(dtype="string"),
        "content": Value(dtype="string"),
    }
})


def main():
    args = parse_args()
    with open(args.input_path, "r", encoding="utf-8") as f:
        d = json.load(f)
    
    all_id = 0
    result = []
    for key, value in d.items():
        file_path = value['question']
        root = value['root']
        # value['mode'] must in ['Grounding', 'MCQ', 'MATH', 'GeneralVQA']

        with open(file_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
            datas = [json.loads(line.strip()) for line in lines]

        for data in tqdm(datas, total=len(datas)):
            if data.get('image', None) is None:
                continue 

            for idx in range(0, len(data['conversations']), 2):
                tdata = copy.deepcopy(data)

                image_path = []
                if isinstance(tdata['image'], list):
                    tdata['image'] = tdata['image']
                    for _ in tdata['image']:
                        image_path.append(os.path.join(root, _))
                elif isinstance(tdata['image'], str):
                    image_path = [os.path.join(root, tdata['image'])]
                else:
                    for _ in tdata['camera_key_frame_id']:
                        image_path.append(os.path.join(root, tdata['image'][_[0]][_[1]]))

                if value['think'] is True:
                    data['conversations'][idx]['value'] += "\nOutput the thinking process in <think> </think> and final answer in <answer> </answer> tags."

                image_diff = data['conversations'][idx]['value'].count("<image>")
                if image_diff > 0:
                    continue
                elif image_diff < 0:
                    for _ in range(-image_diff):
                        data['conversations'][idx]['value'] = "<image>\n" + data['conversations'][idx]['value']

                answer = data['conversations'][idx + 1]['value']
                if "\\boxed" in answer:
                    answer = re.findall(r'\\boxed\{(.*?)\}', answer)[0]

                answer = answer.strip()
                if value['mode'] == 'Grounding' and len(answer.split('\n')) > 1:
                    continue

                all_id += 1
                tdata['data_source'] = f'{key}'
                tdata['prompt'] = [
                    {
                        "role": "user",
                        "content": data['conversations'][idx]['value']
                    }
                ]
                ground_truth = {
                    "accuracy_ratio": 1.0,
                    "format_ratio": 1.0,
                    "think_ratio": 1.0,
                    "image_path": tdata['image'],
                    "question": data['conversations'][idx]['value'],
                    "ground_truth": answer,
                    'verifier': value['mode'],
                    "id": all_id,
                }
                tdata['reward_model'] = {
                    "ground_truth": ground_truth,
                }
                tdata['extra_info'] = {
                    "image": tdata['image'],
                    "content": data['conversations'][idx]['value']
                }
                tdata["image_num_tiles"] = [0]

                tdata_keys = list(tdata.keys())
                for k in tdata_keys:
                    if str(k) not in ['data_source', 'image', 'prompt', 'reward_model', 'extra_info', "image_num_tiles"]:
                        tdata.pop(k)

                result.append(tdata)

    output_folder = args.output_path
    os.makedirs(output_folder, exist_ok=True)
    
    random.shuffle(result)
    _ = 0
    while True:
        st = _ * 5000
        if st >= len(result):
            break

        ed = min((_ + 1) * 5000, len(result))
        dataset = Dataset.from_list(result[st:ed], features=feature)
        dataset = dataset.cast(features=feature)
        output_path = os.path.join(output_folder, f"random_shard_{_}.parquet")
        dataset.to_parquet(output_path)
        _ += 1


    file_list = os.listdir(output_folder)
    output = "["
    for file in file_list:
        output += os.path.join(output_folder, file) + ","

    output += "]"
    print(output)

if __name__ == "__main__":
    main()