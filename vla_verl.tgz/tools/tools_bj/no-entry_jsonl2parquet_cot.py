import re
import sys
import os
import datasets
import json
import numpy as np
from datasets import Features, Value
from pathlib import Path
import pickle
from multiprocessing import Pool
import tqdm

# Ensure project root is on sys.path for direct script execution
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

# NIOFS imports (same as process_trajectory_vocab.py)
import niofs
from read_cache_op_py import read_cache_op_py

# Intersection filter module
from tools.tools_bj.intersection_filter import filter_examples

NIOFS_AK = "aed7ef63fcad0706"
NIOFS_SK = "aa7100f53b0c4f4d8d2d849d7730f7ef"

# ---------------------------------------------------------------------------
# NIOFS client
# ---------------------------------------------------------------------------
_niofs_client = None

def get_niofs_client():
    global _niofs_client
    if _niofs_client is None:
        _niofs_client = niofs.Client(NIOFS_AK, NIOFS_SK, max_pool_connections=2000)
    return _niofs_client

# ---------------------------------------------------------------------------
# NIOFS path utilities (from process_trajectory_vocab.py)
# ---------------------------------------------------------------------------

def is_niofs_path(path: str) -> bool:
    if not path:
        return False
    if path.startswith("s3:") or path.startswith("s3://") or path.startswith("huailai_cos:"):
        return True
    if path.startswith("/s3:") or path.startswith("/ad"):
        return True
    if ":" in path and not path.startswith("/"):
        return True
    return False

def parse_niofs_path(path: str):
    if path.startswith("/"):
        path_without_leading = path[1:]
        bucket = path_without_leading.split("/")[0]
        key = "/".join(path_without_leading.split("/")[1:])
    elif ":" in path:
        path_part = path.split(":", 1)[1] if path.startswith("s3:") else path.split(":", 1)[1]
        bucket = path_part.split("/")[0]
        key = "/".join(path_part.split("/")[1:])
    else:
        raise ValueError(f"Cannot parse niofs path: {path}")
    return bucket, key

def load_pickle_from_niofs(path: str, file_size: int = None):  # noqa: ARG001
    """Load a pickle file from NIOFS, with cache_op fallback."""
    try:
        raw_bytes = read_cache_op_py([path])
        return pickle.loads(raw_bytes)
    except Exception:
        pass
    client = get_niofs_client()
    bucket, key = parse_niofs_path(path)
    resp = client.get_object(bucket, key, Retry=True)
    raw_bytes = resp["Body"].read()
    return pickle.loads(raw_bytes)

def load_pickle_from_path(path: str, file_size: int = None):
    """Load a pickle file from either NIOFS or local path."""
    if is_niofs_path(path):
        return load_pickle_from_niofs(path, file_size)
    else:
        with open(path, 'rb') as f:
            return pickle.load(f)

def read_manifest_lines(anno_root: str):
    """Read lines from a manifest txt file (local or NIOFS)."""
    if is_niofs_path(anno_root):
        client = get_niofs_client()
        bucket, key = parse_niofs_path(anno_root)
        resp = client.get_object(bucket, key, Retry=True)
        text = resp["Body"].read().decode("utf-8")
        return text.splitlines()
    else:
        with open(anno_root, "r", encoding="utf-8") as f:
            return f.readlines()

def parse_bucket_pkl_info_line(line: str):
    """Parse a manifest line: '<pkl_path> [file_size]'."""
    line = line.strip()
    if not line:
        return None, None
    parts = line.rsplit(maxsplit=1)
    pkl_path = parts[0]
    file_size = None
    if len(parts) == 2:
        try:
            file_size = int(parts[1])
        except ValueError:
            file_size = None
    return pkl_path, file_size

# ---------------------------------------------------------------------------
# Exit sign detection helper
# ---------------------------------------------------------------------------

# Lazy imports from reward module — loaded on first use to avoid import-time
# side effects and to work in multiprocessing subprocesses.
_FORBIDDEN_ROAD_CLASSES = {'noEntryRoad', 'noEntryRoadBarrier', 'ArriveDeadEndRoad', 'onlyRetrograde'}

def _get_forbidden_road_ids(select_road_ids, select_road_cls):
    """Return the set of road IDs whose class is a forbidden (no-entry) type."""
    forbidden = set()
    for rid, cls in zip(select_road_ids, select_road_cls):
        if cls in _FORBIDDEN_ROAD_CLASSES:
            forbidden.add(rid)
    return forbidden


def _compute_has_exit_sign(extra_dict: dict) -> bool:
    """Determine whether an exit sign is visible in the current frame.

    Uses scene_info.vln_ocr_info: checks for "出口" in poi_indication_info.

    Additionally, if the vla_goal_point binds to a forbidden (no-entry) road,
    has_exit_sign is forced to False — the goal targets a no-entry road,
    so it does not represent a valid exit direction.
    """
    vln_ocr_info = extra_dict.get("scene_info", {}).get("vln_ocr_info", [])
    if not isinstance(vln_ocr_info, list):
        return False

    has_exit_in_ocr = False
    for ocr in vln_ocr_info:
        box = ocr.get("box", [])
        if not (isinstance(box, list) and len(box) == 4):
            continue
        for poi in ocr.get("poi_ocr_info", []):
            if "出口" in str(poi.get("poi_indication_info", "")):
                has_exit_in_ocr = True
                break
        if has_exit_in_ocr:
            break

    if not has_exit_in_ocr:
        return False

    # ── If exit sign is present, check whether the goal_point binds to a
    #    forbidden road.  If it does, the "exit" sign is pointing into a
    #    no-entry road → not a valid exit → return False.
    vla_goal_point = extra_dict.get("vla_goal_point", {})
    if vla_goal_point and vla_goal_point.get("point_x") is not None and vla_goal_point.get("yaw") is not None:
        road_graphs = extra_dict.get("road_graphs", {})
        select_road_ids = extra_dict.get("select_road_ids", [])
        select_road_cls = extra_dict.get("select_road_cls", [])

        if road_graphs and select_road_ids:
            # Import here so the module is importable even when the reward
            # package isn't on sys.path (e.g. during ad-hoc scripting).
            from verl.utils.reward_score.vla_no_entry_v4 import (
                find_best_lane_for_goal,
                get_all_road_geometries,
            )

            all_road_geoms = get_all_road_geometries(road_graphs)
            forbidden_ids = _get_forbidden_road_ids(select_road_ids, select_road_cls)

            if all_road_geoms and forbidden_ids:
                goal_road_id, _, _, _ = find_best_lane_for_goal(vla_goal_point, all_road_geoms)
                if goal_road_id is not None and goal_road_id in forbidden_ids:
                    return False

    return True


# ---------------------------------------------------------------------------
# Exit path road IDs helper (ds_type="exit" only)
# ---------------------------------------------------------------------------

def _build_road_geoms_from_vla_construction(vla_road_construction_info: dict):
    """Build ``all_road_geoms`` dict from ``vla_road_construction_info``.

    Returns dict: ``{road_id: np.array([[x,y], ...]), ...}``.
    """
    all_road_geoms = {}
    vla_road_info = vla_road_construction_info.get("vla_road_info", [])
    if isinstance(vla_road_info, list):
        for road in vla_road_info:
            road_id = road.get("road_link_id", "")
            way_points = road.get("road_way_point", [])
            if len(way_points) > 1:
                geo = np.array([[wp["point_x"], wp["point_y"]] for wp in way_points])
                all_road_geoms[road_id] = geo
    return all_road_geoms


def _compute_exit_path_road_ids(answer_raw: str,
                                vla_road_construction_info: dict,
                                multi_groups: list):
    """Compute the set of road IDs that form the exit path.

    1. Parse GT answer to extract action trajectory
    2. Build road geometries from vla_road_construction_info
    3. Bind GT trajectory segments to roads
    4. Remove the road closest to origin (0,0)
    5. Add multi_groups road IDs
    """
    from verl.utils.reward_score.vla_no_entry_v1 import (
        parse_action_traj,
        action_traj_to_abs,
        bind_segment_to_road,
        _min_distance_point_to_polyline,
    )
    from verl.utils.reward_score.vla_no_entry_v4 import (
        find_nearest_road_to_point,
    )

    # 1. Parse action trajectory from GT answer
    action_traj = parse_action_traj(answer_raw)
    if action_traj is None:
        return set()

    abs_traj = action_traj_to_abs(action_traj)
    if abs_traj is None or len(abs_traj) < 2:
        return set()

    # 2. Build road geometries from vla_road_construction_info
    all_road_geoms = _build_road_geoms_from_vla_construction(vla_road_construction_info)
    if not all_road_geoms:
        return set()

    # 3. Bind trajectory segments to roads (prepend origin as first point)
    origin = np.array([0.0, 0.0])
    full_traj = np.vstack([origin, abs_traj])

    bound_road_ids = set()
    for i in range(len(full_traj) - 2):
        segment = full_traj[i:i + 3]
        road_id, _ = bind_segment_to_road(segment, all_road_geoms)
        if road_id is not None:
            bound_road_ids.add(road_id)

    # 4. Remove the road closest to origin (0,0)
    origin_road_id, _, _ = find_nearest_road_to_point(origin, all_road_geoms)
    if origin_road_id is not None:
        bound_road_ids.discard(origin_road_id)

    # 5. Add multi_groups road IDs
    for item in multi_groups:
        rid = item.get("road_id")
        if rid:
            bound_road_ids.add(rid)

    return bound_road_ids


# ---------------------------------------------------------------------------
# map_func
# ---------------------------------------------------------------------------

def map_func(split, rw_version, ds_type="no_entry"):

    def process_fn(sample, idx):
        image = sample.pop('image')
        camera_key_frame_id = sample.pop('camera_key_frame_id')
        image_list = list()
        for cam_key in camera_key_frame_id:
            _cam = cam_key[0]
            _idx = int(cam_key[1])
            image_list.append(image[_cam][_idx])
        conversations = sample.pop('conversations')
        extra_dict = sample.pop('extra', {}) if isinstance(sample.get('extra'), dict) else {}
        # clip_id 可能在 extra 中，也可能在主字段中
        clip_id = extra_dict.get('clip_id') or sample.get('clip_id', f'unknown_{idx}')

        prompt = sample.pop("prompt")

        # 去除自车历史轨迹位置信息，与 merged_sorted.jsonl 的 prompt 格式保持一致
        # Pattern: ；距当前<seconds>秒，在自车[UNUSED_TOKEN_34]<x>,<y>[UNUSED_TOKEN_35]处
        EGO_POSITION_RE = re.compile(
            r"[；;]距当前[\d.]+秒，在自车\[UNUSED_TOKEN_34\][^]]+\[UNUSED_TOKEN_35\]处"
        )
        prompt = EGO_POSITION_RE.sub("", prompt)

        # parts = prompt.split("<image>")
        # keep_images = 13
        # cut = keep_images + 1  # split 后要保留的段数

        # if len(parts) > cut:
        #     # 前 cut 段之间保留 <image>，后面的段直接拼接（等价于删掉多余的 <image>）
        #     prompt = "<image>".join(parts[:cut]) + "".join(parts[cut:])
        # else:
        #     prompt = "<image>".join(parts)  # 原样（或者直接 prompt 不变也行）

        ## WARNING: 这里写死了prompt
        HUMAN_PROMPT_COT = (
            "中心点格式为[UNUSED_TOKEN_73]x,y[UNUSED_TOKEN_74]，x为宽度，y为高度，归一化成0~999的整数。"
            "当前目的地：出口，请给出禁行逆行相关标志的方向、关键视角和中心点；"
            "如果没有线索，则输出无。"
            "最后给出自车预计转向，转向信息有5种[0.左转，1.直行，2.右转，3.掉头，4.未知]。"
            "请预测未来25米轨迹，未来轨迹的格式为<action><action_1><action_2>...<action_5></action>。<COT>"
        )
        conversations[0]['value'] = HUMAN_PROMPT_COT
        # conversations[0]['value'] = "中心点格式为[UNUSED_TOKEN_73]x,y[UNUSED_TOKEN_74]，x为宽度，y为高度，归一化成0~999的整数。当前目的地：出口，请给出目的地或线索的关键视角和中心点，目的地优先；如果没有线索，则输出无。最后给出自车预计转向，转向信息有5种[0.左转，1.直行，2.右转，3.掉头，4.未知]。请预测未来25米轨迹，未来轨迹的格式为<action><action_1><action_2>...<action_5></action>。<NO_COT>"

        question = prompt + conversations[0]['value']
        answer_raw = conversations[1]['value']
        all_cand_gts = extra_dict.get('all_cand_gts', [])

        # if "<think>" in answer_raw:
        #     cot_text = re.search(r'<think>(.*?)</think>', answer_raw, re.DOTALL).group(0)
        #     ans_text = re.search(r'<answer>(.*?)</answer>', answer_raw, re.DOTALL).group(0)
        # else:
        #     cot_text = None
        #     ans_text = answer_raw
        data_source = f"{rw_version}"
        data = {
            "clip_id": clip_id,
            "uuid": clip_id,
            "type": f"{ds_type}-vla",
            "data_source": data_source,
            "prompt": [
                {
                    "role": "user",
                    "content": question,
                }
            ],
            "image": image_list,
            "image_num_tiles": np.array(sample.pop("image_num_tiles")),
            "reward_model": {"style": "rule", "ground_truth": answer_raw},
            "extra_info": {
                "split": split,
                "index": idx,
                "ds_type": ds_type,
                "clip_id": clip_id,
                "answer": answer_raw,
                "question": question,
                "gt_ego_fut_trajs": sample.get("gt_ego_fut_trajs"),
                "need_tools_kwargs": True,
                "tools_kwargs": {
                    "calc_no-entry_reward": {
                        "create_kwargs": {"ground_truth": all_cand_gts},
                        # "execute_kwargs": {},
                        "calc_reward_kwargs": {
                            "cot": "",
                            "ground_truth": all_cand_gts,
                            # Fields for GDRPO reward — serialized as JSON strings
                            # to keep a consistent Arrow schema across shards.
                            "freespace_info": json.dumps(sample.get("freespace_info", {})),
                            # v3/v4 reward fields
                            "vla_goal_point": json.dumps(extra_dict.get("vla_goal_point", {})),
                            "vln_ocr_info": json.dumps(extra_dict.get("scene_info", {}).get("vln_ocr_info", [])),
                            "has_exit_sign": json.dumps(_compute_has_exit_sign(extra_dict)),
                            # ds_type-specific road info
                            **({
                                "road_graphs": json.dumps(extra_dict.get("road_graphs", {})),
                                "select_road_ids": json.dumps(extra_dict.get("select_road_ids", [])),
                                "select_road_cls": json.dumps(extra_dict.get("select_road_cls", [])),
                            } if ds_type == "no_entry" else {
                                "vla_road_construction_info": json.dumps(extra_dict.get("vla_road_construction_info", {})),
                                "multi_groups": json.dumps(extra_dict.get("multi_groups", [])),
                                "exit_path_road_ids": json.dumps(sorted(
                                    _compute_exit_path_road_ids(
                                        answer_raw,
                                        extra_dict.get("vla_road_construction_info", {}),
                                        extra_dict.get("multi_groups", []),
                                    )
                                )),
                            }),
                        },
                        # "release_kwargs": {},
                    },
                },
            }
        }
        return data
    return process_fn

# ---------------------------------------------------------------------------
# Data loading: JSONL format
# ---------------------------------------------------------------------------

def iter_jsonl_chunks(data_file, chunk_size=6000, max_samples=None):
    """Generator that yields lists of examples from a JSONL file, chunk_size at a time.

    If chunk_size is None, yields everything as a single chunk.
    """
    total_yielded = 0
    with open(data_file, 'r', encoding='utf-8') as f:
        examples = []
        for line in f:
            data = json.loads(line)
            if 'camera_key_frame_id' in data:
                data['camera_key_frame_id'] = [[str(x[0]), str(x[1])] for x in data['camera_key_frame_id']]
            data = _sanitize_for_arrow(data)
            examples.append(data)
            if chunk_size and len(examples) >= chunk_size:
                yield examples
                total_yielded += len(examples)
                examples = []
                if max_samples and total_yielded >= max_samples:
                    return
            if max_samples and total_yielded + len(examples) >= max_samples:
                break
        if examples:
            yield examples


def process_jsonl_streaming(data_file, max_samples=None):
    """Read entire JSONL file into a single Dataset (used for .jsonl that aren't chunked, or small files)."""
    all_examples = []
    for chunk in iter_jsonl_chunks(data_file, chunk_size=None, max_samples=max_samples):
        all_examples.extend(chunk)
    return datasets.Dataset.from_list(all_examples)

# ---------------------------------------------------------------------------
# Data loading: .json meta config format (new)
# ---------------------------------------------------------------------------

# Arrow int64 can only hold up to 2^63-1. Sentinel values like
# UINT64_MAX (18446744073709551615) in road_graphs junction IDs
# cause "Python int too large to convert to C long".
_INT64_MAX = 2**63 - 1

def _sanitize_for_arrow(obj):
    """Recursively convert numpy scalars and out-of-range ints for Arrow compatibility."""
    if isinstance(obj, np.generic):
        obj = obj.item()  # numpy scalar → Python scalar
    if isinstance(obj, int):
        if obj > _INT64_MAX:
            return -1  # cap UINT64_MAX sentinel to fit in Arrow int64
        return obj
    elif isinstance(obj, dict):
        return {k: _sanitize_for_arrow(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return [_sanitize_for_arrow(v) for v in obj]
    return obj

def load_single_pkl(line):
    """Load a single PKL file from a manifest line (used in multiprocessing pool)."""
    pkl_path, file_size = parse_bucket_pkl_info_line(line)
    if pkl_path is None:
        return None
    try:
        data = load_pickle_from_path(pkl_path, file_size=file_size)
        # Convert numpy scalars to Python native types for Arrow compatibility
        data = _sanitize_for_arrow(data)
        # Same preprocessing as JSONL mode
        if 'camera_key_frame_id' in data:
            data['camera_key_frame_id'] = [[str(x[0]), str(x[1])] for x in data['camera_key_frame_id']]
        return data
    except Exception as e:
        print(f"Failed to load {pkl_path}: {e}")
        return None

def process_one_manifest(anno_root, pool_size=32, max_samples=None):
    """Read a txt manifest file, load all PKLs, return list of examples.

    When pool_size=0, runs serially for easier debugging.
    """
    lines = read_manifest_lines(anno_root)
    if max_samples:
        lines = lines[:max_samples]
    print(f"  Loading {len(lines)} PKL files from: {anno_root}")

    if pool_size == 0:
        results = [load_single_pkl(line) for line in tqdm.tqdm(lines)]
    else:
        with Pool(pool_size) as pool:
            results = list(tqdm.tqdm(pool.imap(load_single_pkl, lines), total=len(lines)))

    examples = [r for r in results if r is not None]
    print(f"  Loaded {len(examples)}/{len(lines)} examples")
    return examples

def process_json_meta(json_path, pool_size=32, max_samples=None):
    """Read a .json meta config, load all PKLs from all anno_root txts, return combined Dataset.

    The .json file format is like config/all_data_0611.json:
        {"ds_name": {"anno_root": "path/to/bucket_pkl_files_info.txt", ...}, ...}

    Each anno_root txt contains lines of "<pkl_path> <file_size>".
    """
    with open(json_path, 'r', encoding='utf-8') as f:
        meta = json.load(f)

    all_examples = []
    for ds_name, ds_meta in meta.items():
        if max_samples and len(all_examples) >= max_samples:
            break

        anno_root = ds_meta.get('anno_root', '')
        if not isinstance(anno_root, str) or not anno_root.endswith('.txt'):
            print(f"Skip '{ds_name}': anno_root must be .txt, got {anno_root!r}")
            continue

        remaining = max_samples - len(all_examples) if max_samples else None
        print(f"\nDataset: {ds_name}")
        examples = process_one_manifest(anno_root, pool_size=pool_size, max_samples=remaining)
        all_examples.extend(examples)

    if not all_examples:
        raise ValueError(f"No valid data found in {json_path}")

    if max_samples:
        all_examples = all_examples[:max_samples]

    print(f"\nTotal examples loaded: {len(all_examples)}")
    dataset = datasets.Dataset.from_list(all_examples)
    return dataset

# ---------------------------------------------------------------------------
# Unified data loading: auto-detect .jsonl vs .json
# ---------------------------------------------------------------------------

def load_dataset(data_file, pool_size=32, max_samples=None):
    """Load dataset from either .jsonl or .json file, auto-detected by extension."""
    if data_file.endswith('.jsonl'):
        return process_jsonl_streaming(data_file, max_samples=max_samples)
    elif data_file.endswith('.json'):
        return process_json_meta(data_file, pool_size=pool_size, max_samples=max_samples)
    else:
        raise ValueError(f"Unsupported file format: {data_file}. Expected .jsonl or .json")

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main(config):
    rw_tag = config['tag']
    ds_type = config.get('ds_type', 'no_entry')
    pool_size = config.get('pool_size', 32)
    num_proc = config.get('num_proc', 1)
    debug = config.get('debug', False)
    debug_limit = config.get('debug_limit', 5)
    limit = debug_limit if debug else None

    # ── Intersection filter config ──
    filter_config = config.get('filter_intersection', None)  # None 表示不启用筛选
    if filter_config:
        print(f"\nIntersection filter ENABLED: near=[{filter_config.get('near_min', 0)}, "
              f"{filter_config.get('near_max', 15)}]m, ds_type={ds_type}")

    idx_dir = Path('config/idx')
    idx_dir.mkdir(parents=True, exist_ok=True)

    for split_name, data_file in [('train', config['train']), ('test', config['test'])]:
        if not data_file or not data_file.strip():
            print(f"  [{split_name}] data_file is empty, skipping.")
            continue
        if data_file.endswith('.json'):
            # .json meta: 每个 anno_root txt → 一个 parquet，全部放到一个文件夹
            output_dir = config.get('output_dir', None)
            path_map = _process_split_meta(data_file, rw_tag, split_name, ds_type, pool_size, num_proc, debug, limit, output_dir, filter_config)
        else:
            # .jsonl: 每 6000 条数据保存一个 parquet
            path_map = _process_split_jsonl(data_file, rw_tag, split_name, ds_type, pool_size, num_proc, debug, limit, filter_config)

        # Wrap into extensible format: {"key": {"parquet_root": "path"}}
        index_data = {key: {"parquet_root": path} for key, path in path_map.items()}

        out_json = idx_dir / f"{rw_tag}_{split_name}.json"
        with open(out_json, 'w', encoding='utf-8') as f:
            json.dump(index_data, f, indent=4, ensure_ascii=False)
        print(f"\n  Saved index: {out_json} ({len(index_data)} entries)")


def _process_split_meta(json_path, rw_tag, split_name, ds_type, pool_size, num_proc, debug, limit, output_dir=None, filter_config=None):
    """Process a .json meta config: each dataset → one parquet in output folder.

    Returns a dict of {ds_name: parquet_path} for writing to the index JSON.
    """
    with open(json_path, 'r', encoding='utf-8') as f:
        meta = json.load(f)

    if output_dir:
        output_dir = Path(output_dir)
    else:
        output_dir = Path(json_path).parent / f"{Path(json_path).stem}_parquet"
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"\nOutput dir: {output_dir}")

    path_map = {}
    for ds_name, ds_meta in meta.items():
        anno_root = ds_meta.get('anno_root', '')
        if not isinstance(anno_root, str) or not anno_root.endswith('.txt'):
            print(f"Skip '{ds_name}': anno_root must be .txt")
            continue

        print(f"\n{'='*60}")
        print(f"[{split_name}] Dataset: {ds_name}")

        examples = process_one_manifest(anno_root, pool_size=pool_size, max_samples=limit)
        if not examples:
            print(f"  No valid examples, skipping")
            continue

        # ── Intersection filter ──
        if filter_config:
            print(f"  Applying intersection filter (ds_type={ds_type})...")
            examples, filt_stats = filter_examples(
                examples,
                ds_type=ds_type,
                near_threshold=(filter_config.get('near_min', 0.0),
                                filter_config.get('near_max', 15.0)),
                endpoint_dist_threshold=filter_config.get('endpoint_dist', 2.0),
                min_connected_roads=filter_config.get('min_connected', 2),
                verbose=True,
            )
            if not examples:
                print(f"  All examples filtered out, skipping")
                continue

        if debug:
            process_fn = map_func(split_name, rw_tag, ds_type)
            results = []
            for idx, sample in enumerate(tqdm.tqdm(examples)):
                results.append(process_fn(sample, idx))
                if limit and idx + 1 >= limit:
                    break
            dataset = datasets.Dataset.from_list(results)
            print(f"  [debug] processed {len(results)}/{len(examples)} samples")
        else:
            dataset = datasets.Dataset.from_list(examples)
            dataset = dataset.map(function=map_func(split_name, rw_tag, ds_type), with_indices=True, num_proc=num_proc)

        save_path = str(output_dir / f"{ds_name}.parquet")
        dataset.to_parquet(save_path)
        path_map[ds_name] = save_path
        print(f"  Saved: {save_path} ({len(dataset)} examples)")

    return path_map


def _process_split_jsonl(data_file, rw_tag, split_name, ds_type, pool_size, num_proc, debug, limit, filter_config=None):
    """Process a .jsonl file in chunks of 6000 → multiple .parquet files to avoid OOM.

    Returns a dict of {key: parquet_path} for writing to the index JSON.
    """
    print(f"\n{'='*60}")
    print(f"[{split_name}] Processing: {data_file}")

    chunk_size = 1000
    path_map = {}
    process_fn = map_func(split_name, rw_tag, ds_type)

    base_stem = Path(data_file).stem  # e.g. "vla_train_out_no_entry_260526_test__df5f809__20260527082619"

    for chunk_idx, examples in enumerate(iter_jsonl_chunks(data_file, chunk_size=chunk_size, max_samples=limit)):
        # ── Intersection filter ──
        if filter_config:
            print(f"  Applying intersection filter (ds_type={ds_type})...")
            examples, filt_stats = filter_examples(
                examples,
                ds_type=ds_type,
                near_threshold=(filter_config.get('near_min', 0.0),
                                filter_config.get('near_max', 15.0)),
                endpoint_dist_threshold=filter_config.get('endpoint_dist', 2.0),
                min_connected_roads=filter_config.get('min_connected', 2),
                verbose=True,
            )
            if not examples:
                print(f"  All examples in chunk {chunk_idx} filtered out, skipping")
                continue

        chunk_dataset = datasets.Dataset.from_list(examples)
        print(f"  Chunk {chunk_idx}: {len(chunk_dataset)} examples")

        if debug:
            results = []
            for idx, sample in enumerate(tqdm.tqdm(chunk_dataset)):
                results.append(process_fn(sample, idx))
                if limit and idx + 1 >= limit:
                    break
            chunk_dataset = datasets.Dataset.from_list(results)
            print(f"  [debug] processed {len(results)}/{len(examples)} samples")
        else:
            chunk_dataset = chunk_dataset.map(function=process_fn, with_indices=True, num_proc=num_proc)

        save_path = data_file.replace('.jsonl', f'_chunk_{chunk_idx:04d}.parquet')
        chunk_dataset.to_parquet(save_path)
        key = f"{base_stem}_chunk_{chunk_idx:04d}"
        path_map[key] = save_path
        print(f"  Saved: {save_path} ({len(chunk_dataset)} examples)")

    total_examples = 0
    for p in path_map.values():
        total_examples += datasets.Dataset.from_parquet(p).num_rows
    print(f"\n  [{split_name}] total chunks: {len(path_map)}, total examples: {total_examples}")
    return path_map

if __name__ == "__main__":
    config = {
        'train': 'config/no_entry_rl_0612.json',
        # 'train': 'config/no_entry_rl_exit_0701.json',
        # "train":"/lustre/joeden.zhuang/projects/vlm_no_entry/output_prod/no_entry_road_train_1116-2-rl_filter_5k.jsonl",
        # "train": "config/all_data_0611.json",  # 也支持 .json meta 文件
        'test': '/perception-hl/beijin.zhou/projects/vlm_no_entry/dataset/replaced_prompt_output/dual_cot/vla_train_out_no_entry_260526_test__df5f809__20260527082619_reduce_v5.jsonl',
        # 'test': '',
        # "test": "config/all_data_0611.json",  # 也支持 .json meta 文件
        'tag': '260706-no_entry-cot',
        'ds_type': 'no_entry',   # 'no_entry' | 'exit'
        'pool_size': 32,   # 0 = serial, easy for debugging; >0 = multiprocessing
        'num_proc': 32,    # map 并行进程数
        # 'debug': True,    # True = directly call process_fn in for-loop, breakpoints guaranteed
        # 'debug_limit': 3,
        'output_dir': '/perception-hl/beijin.zhou/deeprl/260706_rl_data/',
        # ── Intersection filter config ──
        # 设置为 None 或注释掉以禁用筛选
        # 'filter_intersection': {
        #     'near_min': 0.0,            # 到交叉口的最小距离 (m)
        #     'near_max': 15.0,           # 到交叉口的最大距离 (m)
        #     'endpoint_dist': 2.0,       # 端点连接判断的距离阈值 (m)
        #     'min_connected': 2,         # 构成交叉路口的最小连接路数
        # },
    }
    main(config)
