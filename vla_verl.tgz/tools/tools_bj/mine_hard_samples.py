#!/usr/bin/env python3
"""
Mine hard (low-score) samples from VLA inference results and mix with easy samples.

Supports two modes:
  single  — original: score single prediction, hard = score < 2.0
  pass@k  — N16 multi-prediction: score all K predictions,
            hard = not all K pass (num_pass < K), easy = all K pass (num_pass == K)

Supports local and S3 paths for inference data:
  python tools/tools_bj/mine_hard_samples.py
  python tools/tools_bj/mine_hard_samples.py s3://bucket/path --mode pass@k --easy-ratio 0.2
  python tools/tools_bj/mine_hard_samples.py --dry-run --mode pass@k -d 0256_part0000
"""

import argparse
import json
import os
import random
import re
import sys
import time
from collections import Counter

import numpy as np
import pandas as pd

# ── Add project root ──
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, _PROJECT_ROOT)

from verl.utils.reward_score.vla_no_entry_v3_2 import TaskVLANoEntryRewardV32

# ── Default paths ──
CONFIG_PATH = os.path.join(_PROJECT_ROOT, "config", "idx", "260701-no_entry-exit_train.json")
INFERENCE_BASE = "/perception-hl/beijin.zhou/action_model_output/0612_17w_1Wpseudo_cot_multi-20260612-215425"
PARQUET_BASE = "/perception-hl/beijin.zhou/deeprl/260701_rl_exit_data"
OUTPUT_BASE = "/home/beijin.zhou/deeprl/260701_rl"

# ── NIOFS client (lazy init, for S3 mode) ──
_niofs_client = None


def _get_niofs():
    global _niofs_client
    if _niofs_client is None:
        import niofs
        ak = os.environ.get('LUSTRE_ACCESS_KEY', 'b89e365554ef75f8')
        sk = os.environ.get('LUSTRE_SECRET_KEY', '0910180b207f4edd9baaa030cf4a2902')
        _niofs_client = niofs.Client(ak, sk, max_pool_connections=32)
    return _niofs_client


def _parse_s3(s3_path):
    """s3://bucket/key → (bucket, key)."""
    p = s3_path.strip()
    for pre in ('s3://', 's3:'):
        if p.startswith(pre):
            p = p[len(pre):]
            break
    p = p.lstrip('/')
    parts = p.split('/', 1)
    if len(parts) != 2:
        raise ValueError(f"Invalid S3 path: {s3_path}")
    return parts[0], parts[1]


def is_s3_path(path):
    return path.startswith('s3://') or path.startswith('s3:')


# ═══════════════════════════════════════════════════════════════════════════════
#  Directory listing & JSONL reading — local or S3
# ═══════════════════════════════════════════════════════════════════════════════

def list_dataset_dirs(inference_base):
    """List dataset subdirectories (local or S3)."""
    if is_s3_path(inference_base):
        bucket, prefix = _parse_s3(inference_base)
        prefix = prefix.rstrip('/') + '/'
        resp = _get_niofs().list_objects_v2(Bucket=bucket, Prefix=prefix, Delimiter='/')
        return sorted(p['Prefix'].rstrip('/').split('/')[-1]
                      for p in resp.get('CommonPrefixes', []))
    else:
        base = os.path.abspath(inference_base)
        if not os.path.isdir(base):
            return []
        return sorted(d for d in os.listdir(base)
                      if os.path.isdir(os.path.join(base, d)))


def find_jsonl(inference_base, ds_name, jsonl_name=None):
    """Find JSONL file in a dataset directory (local or S3).
    Returns (jsonl_name, is_s3) tuple.
    """
    if is_s3_path(inference_base):
        bucket, prefix = _parse_s3(inference_base)
        ds_prefix = prefix.rstrip('/') + '/' + ds_name + '/'
        resp = _get_niofs().list_objects_v2(Bucket=bucket, Prefix=ds_prefix)
        for obj in resp.get('Contents', []):
            fname = obj['Key'].rstrip('/').split('/')[-1]
            if jsonl_name and fname == jsonl_name:
                return fname, True
            if not jsonl_name and fname.startswith('inference_result') and fname.endswith('.jsonl'):
                return fname, True
        return None, True
    else:
        ds_dir = os.path.join(os.path.abspath(inference_base), ds_name)
        if not os.path.isdir(ds_dir):
            return None, False
        if jsonl_name:
            p = os.path.join(ds_dir, jsonl_name)
            return (jsonl_name, False) if os.path.exists(p) else (None, False)
        for name in ["inference_result.jsonl", 'inference_result_"".jsonl']:
            p = os.path.join(ds_dir, name)
            if os.path.exists(p):
                return name, False
        for f in sorted(os.listdir(ds_dir)):
            if f.startswith("inference_result") and f.endswith(".jsonl"):
                return f, False
        return None, False


def read_jsonl_lines(inference_base, ds_name, jsonl_name):
    """Read all JSONL lines for a dataset. Returns list of dicts."""
    if is_s3_path(inference_base):
        bucket, prefix = _parse_s3(inference_base)
        key = prefix.rstrip('/') + '/' + ds_name + '/' + jsonl_name
        resp = _get_niofs().get_object(Bucket=bucket, Key=key)
        text = resp['Body'].read().decode('utf-8')
        return [json.loads(l) for l in text.strip().split('\n') if l.strip()]
    else:
        p = os.path.join(os.path.abspath(inference_base), ds_name, jsonl_name)
        with open(p) as fh:
            return [json.loads(l) for l in fh if l.strip()]


# ═══════════════════════════════════════════════════════════════════════════════
#  Parquet ↔ JSONL matching
# ═══════════════════════════════════════════════════════════════════════════════

def build_parquet_index_map(parquet_path):
    """Build (clip_id, fw_ts) → parquet row index map."""
    df = pd.read_parquet(parquet_path)
    idx_map = {}
    for row_idx, (_, row) in enumerate(df.iterrows()):
        ei = row["extra_info"]
        cid = ei["clip_id"]
        images = row.get("image", [])
        if hasattr(images, "tolist"):
            images = images.tolist()
        fw_ts = None
        for img in images:
            s = str(img)
            if "/FW/" in s:
                m = re.search(r"/(\d{10}\.\d+)\.jpg", s)
                if m:
                    fw_ts = m.group(1)
                    break
        idx_map[(cid, fw_ts)] = row_idx
    return df, idx_map


def match_parquet_row(clip_id, frame_id, idx_map):
    """Match a JSONL row (clip_id, frame_id) to a parquet row index."""
    key = (clip_id, str(frame_id))
    if key in idx_map:
        return idx_map[key]
    if frame_id:
        try:
            fval = float(frame_id)
            for (cid2, fw_ts2), row_idx in idx_map.items():
                if cid2 == clip_id and fw_ts2:
                    try:
                        if abs(float(fw_ts2) - fval) < 1e-5:
                            return row_idx
                    except ValueError:
                        pass
        except ValueError:
            pass
    return None


# ═══════════════════════════════════════════════════════════════════════════════
#  Core: mine one dataset
# ═══════════════════════════════════════════════════════════════════════════════

def mine_dataset(ds_name, inference_base, parquet_base, output_base,
                  easy_ratio=0.3, seed=42, dry_run=False,
                  mode="single", k=None, jsonl_name=None):
    """Mine hard samples from one dataset.

    Args:
        mode: "single" (original: score<2.0=hard) or "pass@k" (num_pass<k=hard)
        k: number of predictions per sample (auto-detect for pass@k mode)
        jsonl_name: specific JSONL filename (auto-detect if None)
    """
    rng = random.Random(seed)

    # ── Locate JSONL ──
    found_name, is_s3 = find_jsonl(inference_base, ds_name, jsonl_name)
    if not found_name:
        return {"dataset": ds_name, "error": "no_jsonl"}
    jsonl_name = found_name

    # ── Locate parquet ──
    parquet_path = os.path.join(parquet_base, f"{ds_name}.parquet")
    if not os.path.exists(parquet_path):
        return {"dataset": ds_name, "error": "no_parquet"}

    print(f"  JSONL: {jsonl_name}  {'[S3]' if is_s3 else '[local]'}", flush=True)
    print(f"  Parquet: {parquet_path}", flush=True)
    df, idx_map = build_parquet_index_map(parquet_path)
    print(f"    {len(df)} rows, {len(idx_map)} unique (clip_id, fw_ts) keys", flush=True)

    scorer = TaskVLANoEntryRewardV32(debug=False)

    # ── Read JSONL ──
    lines = read_jsonl_lines(inference_base, ds_name, jsonl_name)

    # ── Auto-detect k for pass@k mode ──
    if mode == "pass@k" and k is None:
        for d in lines:
            extra = d.get("extra", {})
            preds = extra.get("predictions", [])
            if preds:
                k = len(preds)
                break
        if k is None:
            return {"dataset": ds_name, "error": "no_extra.predictions"}
        print(f"    Auto-detected K={k}", flush=True)

    # ── Score predictions ──
    # For pass@k: track per-sample num_pass. Hard = row_idx where num_pass < k
    # For single: track per-line score. Hard = row_idx where score < 2.0
    hard_indices = set()
    easy_indices = set()
    score_dist = Counter()
    reason_dist = Counter()
    pass_count_dist = Counter()  # for pass@k: num_pass distribution
    n_matched = 0
    n_unmatched = 0
    n_skipped_non_exit = 0
    # Track row_idx → (num_pass, all_reasons) for pass@k dedup
    row_pass_info = {}  # row_idx → {"num_pass": int, "scores": list, "reasons": list}

    for d in lines:
        clip_id = d["clip_id"]
        frame_id = d.get("frame_id", "")

        row_idx = match_parquet_row(clip_id, frame_id, idx_map)
        if row_idx is None:
            n_unmatched += 1
            continue

        ei = df.iloc[row_idx]["extra_info"]
        ds_type = ei.get("ds_type", "exit")

        if ds_type != "exit":
            n_skipped_non_exit += 1
            continue

        if mode == "pass@k":
            # Score all K predictions
            extra = d.get("extra", {})
            predictions = extra.get("predictions", [])
            if not predictions:
                continue

            num_pass = 0
            scores = []
            reasons = []
            for pred in predictions[:k]:
                result = scorer(ds_name, pred, [], ei)
                s = result["score"]
                r = result.get("reason", "unknown")
                scores.append(s)
                reasons.append(r)
                score_dist[s] += 1
                reason_dist[r] += 1
                if s == 2.0:
                    num_pass += 1

            n_matched += 1
            pass_count_dist[num_pass] += 1

            # If this row_idx was already seen, keep the worst (minimum num_pass)
            if row_idx in row_pass_info:
                prev = row_pass_info[row_idx]
                if num_pass < prev["num_pass"]:
                    row_pass_info[row_idx] = {"num_pass": num_pass, "scores": scores, "reasons": reasons}
            else:
                row_pass_info[row_idx] = {"num_pass": num_pass, "scores": scores, "reasons": reasons}
        else:
            # Original single mode
            pred = d.get("prediction", "")
            result = scorer(ds_name, pred, [], ei)
            score = result["score"]
            reason = result.get("reason", "unknown")

            score_dist[score] += 1
            reason_dist[reason] += 1
            n_matched += 1

            if score < 2.0:
                hard_indices.add(row_idx)
            else:
                easy_indices.add(row_idx)

    # ── For pass@k: classify rows ──
    if mode == "pass@k":
        for row_idx, info in row_pass_info.items():
            if info["num_pass"] < k:
                hard_indices.add(row_idx)
            else:
                easy_indices.add(row_idx)

    if n_matched == 0:
        return {"dataset": ds_name, "error": "all_unmatched",
                "n_jsonl": n_unmatched + n_skipped_non_exit, "mode": mode}

    # ── Sample from easy ──
    easy_list = sorted(easy_indices)
    n_easy_sample = int(len(easy_list) * easy_ratio) if easy_list else 0
    if easy_ratio > 0 and n_easy_sample == 0 and easy_list:
        n_easy_sample = 1  # ensure at least 1 easy when ratio > 0
    if n_easy_sample > 0:
        sampled_easy = sorted(rng.sample(easy_list, n_easy_sample))
    else:
        sampled_easy = []

    # ── Merge: all hard + sampled easy ──
    merged_indices = sorted(set(hard_indices) | set(sampled_easy))

    # ── Stats ──
    stats = {
        "dataset": ds_name,
        "mode": mode,
        "jsonl_name": jsonl_name,
        "n_parquet_total": len(df),
        "n_jsonl": n_matched + n_unmatched + n_skipped_non_exit,
        "n_matched": n_matched,
        "n_unmatched": n_unmatched,
        "n_hard": len(hard_indices),
        "n_easy_original": len(easy_indices),
        "n_easy_sampled": len(sampled_easy),
        "n_total_output": len(merged_indices),
        "easy_ratio": easy_ratio,
        "score_distribution": {str(kk): v for kk, v in sorted(score_dist.items())},
        "reason_distribution": dict(reason_dist.most_common()),
    }
    if mode == "pass@k":
        stats["k"] = k
        stats["pass_count_distribution"] = {str(kk): v for kk, v in sorted(pass_count_dist.items())}

    # ── Save ──
    if not dry_run:
        df_out = df.iloc[merged_indices].reset_index(drop=True)
        os.makedirs(output_base, exist_ok=True)
        output_name = f"{ds_name}_mined.parquet"
        output_path = os.path.join(output_base, output_name)
        df_out.to_parquet(output_path, index=False)
        stats["output_path"] = output_path
        print(f"    Saved: {output_path}  ({len(merged_indices)} rows)", flush=True)
    else:
        stats["output_path"] = "(dry-run)"

    return stats


# ═══════════════════════════════════════════════════════════════════════════════
#  Config JSON generation
# ═══════════════════════════════════════════════════════════════════════════════

def generate_config_json(output_base, valid_stats):
    """Generate a config JSON file pointing to mined parquet files."""
    config = {}
    for s in valid_stats:
        ds_name = s["dataset"]
        key = f"{ds_name}_mined"
        config[key] = {
            "parquet_root": os.path.join(output_base, f"{ds_name}_mined.parquet")
        }
    return config


# ═══════════════════════════════════════════════════════════════════════════════
#  Main
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="Mine hard samples from VLA exit inference results (local or S3)")
    parser.add_argument(
        "inference_dir", nargs="?",
        default=None,
        help="Inference directory (local path or s3://bucket/path). "
             "Default uses INFERENCE_BASE")
    parser.add_argument(
        "--inference-dir", type=str, default=None,
        help=argparse.SUPPRESS)  # legacy flag, use positional instead
    parser.add_argument(
        "--parquet-dir", type=str, default=PARQUET_BASE,
        help="Directory containing source .parquet files")
    parser.add_argument(
        "--output-dir", type=str, default=OUTPUT_BASE,
        help="Output directory for mined .parquet files")
    parser.add_argument(
        "--config", type=str, default=CONFIG_PATH,
        help="JSON config mapping dataset names to parquet paths")
    parser.add_argument(
        "--easy-ratio", type=float, default=0.2,
        help="Fraction of easy samples to keep (default: 0.2)")
    parser.add_argument(
        "--seed", type=int, default=42,
        help="Random seed for reproducibility (default: 42)")
    parser.add_argument(
        "--dataset", "-d", type=str, default=None,
        help="Only process a specific dataset (substring match)")
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Compute stats only, do not write output files")
    parser.add_argument(
        "--mode", type=str, default="single", choices=["single", "pass@k"],
        help="Mining mode: 'single' (original, score<2.0=hard) or "
             "'pass@k' (num_pass<k=hard). Default: single")
    parser.add_argument(
        "-k", type=int, default=None,
        help="Number of predictions per sample for pass@k mode "
             "(auto-detect from extra.predictions if not set)")
    parser.add_argument(
        "--jsonl-name", type=str, default=None,
        help="JSONL filename (e.g. inference_result_T1.0_N16.jsonl). "
             "Auto-detect if not set.")
    args = parser.parse_args()

    # ── Determine paths ──
    inference_base = args.inference_dir or INFERENCE_BASE
    if not is_s3_path(inference_base):
        inference_base = os.path.abspath(inference_base)
    parquet_base = os.path.abspath(args.parquet_dir)
    output_base = os.path.abspath(args.output_dir)
    mode = args.mode
    k = args.k
    s3_mode = is_s3_path(inference_base)

    # ── Load config ──
    if not os.path.exists(args.config):
        print(f"ERROR: config not found: {args.config}")
        sys.exit(1)
    with open(args.config) as f:
        config = json.load(f)

    # ── Filter datasets ──
    if args.dataset:
        datasets = [k for k in config if args.dataset in k]
        if not datasets:
            print(f"No dataset matching '{args.dataset}' in config")
            sys.exit(1)
    else:
        datasets = sorted(config.keys())

    print("=" * 100)
    print(f"Mine Hard Samples — vla_no_entry_v3_2  "
          f"[{'S3' if s3_mode else 'local'}]  mode={mode}")
    print(f"Inference dir:  {inference_base}")
    print(f"Parquet dir:    {parquet_base}")
    print(f"Output dir:     {output_base}{' (dry-run)' if args.dry_run else ''}")
    print(f"JSONL name:     {args.jsonl_name or 'auto-detect'}")
    print(f"Easy ratio:     {args.easy_ratio}")
    print(f"Random seed:    {args.seed}")
    print(f"Datasets:       {len(datasets)}")
    if mode == "pass@k":
        print(f"K:              {k if k else 'auto-detect'}")
        print(f"Hard threshold: num_pass < K  (not all {k} predictions pass)")
    else:
        print(f"Hard threshold: score < 2.0  (NOT exit_path_matched)")
    print("=" * 100)

    all_stats = []
    t_start = time.time()

    for ds_name in datasets:
        print(f"\n── {ds_name} ──", flush=True)
        stats = mine_dataset(
            ds_name, inference_base, parquet_base, output_base,
            easy_ratio=args.easy_ratio, seed=args.seed,
            dry_run=args.dry_run, mode=mode, k=k,
            jsonl_name=args.jsonl_name)
        all_stats.append(stats)

        if "error" in stats:
            print(f"  SKIP: {stats['error']}", flush=True)
            continue

        if mode == "pass@k":
            k_val = stats.get("k", "?")
            print(f"  K={k_val}  Matched: {stats['n_matched']}/{stats['n_jsonl']}  "
                  f"Hard: {stats['n_hard']}  "
                  f"Easy: {stats['n_easy_original']}→{stats['n_easy_sampled']}  "
                  f"Output: {stats['n_total_output']} rows", flush=True)
            if "pass_count_distribution" in stats:
                print(f"  Pass dist: {dict(stats['pass_count_distribution'])}", flush=True)
        else:
            print(f"  Matched: {stats['n_matched']}/{stats['n_jsonl']}  "
                  f"Hard: {stats['n_hard']}  "
                  f"Easy: {stats['n_easy_original']}→{stats['n_easy_sampled']}  "
                  f"Output: {stats['n_total_output']} rows", flush=True)
        print(f"  Scores: {dict(stats['score_distribution'])}", flush=True)
        print(f"  Reasons: {dict(stats['reason_distribution'])}", flush=True)

    elapsed = time.time() - t_start

    # ── Overall summary ──
    valid = [s for s in all_stats if "error" not in s]
    errors = [s for s in all_stats if "error" in s]

    total_parquet = sum(s["n_parquet_total"] for s in valid)
    total_matched = sum(s["n_matched"] for s in valid)
    total_hard = sum(s["n_hard"] for s in valid)
    total_easy_orig = sum(s["n_easy_original"] for s in valid)
    total_easy_sampled = sum(s["n_easy_sampled"] for s in valid)
    total_output = sum(s["n_total_output"] for s in valid)

    # Aggregate reason distribution
    total_reasons = Counter()
    for s in valid:
        for reason, cnt in s["reason_distribution"].items():
            total_reasons[reason] += cnt

    print()
    print("=" * 100)
    print("PER-DATASET TABLE")
    print("=" * 100)
    hdr = f"{'Dataset':<55} {'Parquet':>7} {'Matched':>7} {'Hard':>6} {'Easy':>6} {'ESamp':>6} {'Out':>6}"
    print(hdr)
    print("-" * 100)
    for s in valid:
        print(f"{s['dataset']:<55} {s['n_parquet_total']:>7} {s['n_matched']:>7} "
              f"{s['n_hard']:>6} {s['n_easy_original']:>6} {s['n_easy_sampled']:>6} "
              f"{s['n_total_output']:>6}")

    print()
    print("=" * 100)
    print("OVERALL SUMMARY")
    print("=" * 100)
    print(f"  Mode:                {mode}")
    print(f"  Datasets processed:  {len(valid)} ok, {len(errors)} skipped")
    print(f"  Parquet rows total:  {total_parquet}")
    print(f"  Matched & scored:    {total_matched} ({100*total_matched/total_parquet:.1f}%)" if total_parquet else "")
    print(f"  Hard samples:        {total_hard} ({100*total_hard/total_matched:.1f}%)" if total_matched else "")
    print(f"  Easy (original):     {total_easy_orig} ({100*total_easy_orig/total_matched:.1f}%)" if total_matched else "")
    print(f"  Easy (sampled {args.easy_ratio*100:.0f}%):   {total_easy_sampled}")
    print(f"  Total output:        {total_output}")
    print(f"  Time elapsed:        {elapsed:.1f}s")
    print()
    print(f"  Overall reason distribution:")
    for reason, cnt in total_reasons.most_common():
        bar = "█" * int(50 * cnt / total_matched) if total_matched else ""
        print(f"    {reason:<30s} {cnt:>6d} ({100*cnt/total_matched:5.1f}%) {bar}" if total_matched else f"    {reason:<30s} {cnt:>6d}")

    # ── Save summary JSON ──
    summary = {
        "inference_dir": inference_base,
        "parquet_dir": parquet_base,
        "output_dir": output_base,
        "mode": mode,
        "easy_ratio": args.easy_ratio,
        "seed": args.seed,
        "hard_threshold": "num_pass < K" if mode == "pass@k" else "score < 2.0",
        "n_datasets_ok": len(valid),
        "n_datasets_skipped": len(errors),
        "total_parquet_rows": total_parquet,
        "total_matched": total_matched,
        "total_hard": total_hard,
        "total_easy_original": total_easy_orig,
        "total_easy_sampled": total_easy_sampled,
        "total_output": total_output,
        "overall_reasons": {k: v for k, v in total_reasons.most_common()},
        "per_dataset": all_stats,
        "elapsed_s": round(elapsed, 1),
    }
    if mode == "pass@k" and k:
        summary["k"] = k
    elif mode == "pass@k":
        # Collect k from valid stats
        k_set = {s.get("k") for s in valid if s.get("k")}
        summary["k"] = max(k_set) if k_set else None

    # ── Generate config JSON ──
    if not args.dry_run and valid:
        config_out = generate_config_json(output_base, valid)
        config_summary_path = os.path.join(output_base, "mining_summary.json")
        with open(config_summary_path, "w") as f:
            json.dump(summary, f, indent=2, ensure_ascii=False, default=str)
        print(f"\nSummary saved to: {config_summary_path}")

        # Save config JSON for training
        config_json_path = os.path.join(
            _PROJECT_ROOT, "config", "idx",
            f"260715-no_entry-exit_mined_pass16.json")
        with open(config_json_path, "w") as f:
            json.dump(config_out, f, indent=4, ensure_ascii=False)
        print(f"Config JSON saved to: {config_json_path}")
    elif args.dry_run:
        dry_path = os.path.join(os.getcwd(), "mining_summary_dryrun.json")
        with open(dry_path, "w") as f:
            json.dump(summary, f, indent=2, ensure_ascii=False, default=str)
        print(f"\nSummary saved to: {dry_path}")


if __name__ == "__main__":
    main()
