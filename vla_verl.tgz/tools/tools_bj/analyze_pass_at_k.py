#!/usr/bin/env python3
"""
Pass@K 分析：统计 inference_result_T*.jsonl 中每条数据的 pass@K 比率。

对每条数据，有 K 次推理结果（extra.predictions），统计至少有一条轨迹
能拿到满分（score == 2.0, exit_path_matched）的样本比例。
K 自动从 extra.predictions 的数量推断。

支持本地路径和 S3/niofs 路径（自动检测）：
  python tools/tools_bj/analyze_pass_at_k.py
  python tools/tools_bj/analyze_pass_at_k.py s3://bucket/path/to/inference_dir
  python tools/tools_bj/analyze_pass_at_k.py /local/path -d 0635_part0005
  python tools/tools_bj/analyze_pass_at_k.py s3://bucket/path -o result.json
"""

import argparse
import json
import os
import re
import sys
import time
from collections import Counter, defaultdict

import numpy as np
import pandas as pd

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, _PROJECT_ROOT)

from verl.utils.reward_score.vla_no_entry_v3_2 import TaskVLANoEntryRewardV32

CONFIG_PATH = os.path.join(_PROJECT_ROOT, "config", "idx", "260701-no_entry-exit_train.json")
INFERENCE_BASE = "/perception-hl/beijin.zhou/action_model_output/0612_17w_1Wpseudo_cot_multi-20260612-215425"
PARQUET_BASE = "/perception-hl/beijin.zhou/deeprl/260701_rl_exit_data"
JSONL_NAME = "inference_result_T0.7_N8.jsonl"

# ── NIOFS client (lazy init, for S3 mode) ──
_niofs_client = None


def _get_niofs():
    global _niofs_client
    if _niofs_client is None:
        import niofs
        ak = os.environ.get('LUSTRE_ACCESS_KEY', 'b89e365554ef75f8')
        sk = os.environ.get('LUSTRE_SECRET_KEY', '0910180b207f4edd9baaa030cf4a2902')
        _niofs_client = niofs.Client(ak, sk, max_pool_connections=32)
    return _niofs_client


def _parse_s3(s3_path):
    """s3://bucket/key → (bucket, key)."""
    p = s3_path.strip()
    for pre in ('s3://', 's3:'):
        if p.startswith(pre):
            p = p[len(pre):]
            break
    p = p.lstrip('/')
    parts = p.split('/', 1)
    if len(parts) != 2:
        raise ValueError(f"Invalid S3 path: {s3_path}")
    return parts[0], parts[1]


def is_s3_path(path):
    return path.startswith('s3://') or path.startswith('s3:')


# ═══════════════════════════════════════════════════════════════════════════════
#  Directory listing & JSONL reading — local or S3
# ═══════════════════════════════════════════════════════════════════════════════

def list_dataset_dirs(inference_base):
    """List dataset subdirectories (local or S3)."""
    if is_s3_path(inference_base):
        bucket, prefix = _parse_s3(inference_base)
        prefix = prefix.rstrip('/') + '/'
        resp = _get_niofs().list_objects_v2(Bucket=bucket, Prefix=prefix, Delimiter='/')
        return sorted(p['Prefix'].rstrip('/').split('/')[-1]
                      for p in resp.get('CommonPrefixes', []))
    else:
        base = os.path.abspath(inference_base)
        if not os.path.isdir(base):
            return []
        return sorted(d for d in os.listdir(base)
                      if os.path.isdir(os.path.join(base, d)))


def find_jsonl_name(inference_base, ds_name):
    """Find the JSONL file name in a dataset directory (local or S3).
    Returns the file name (e.g. 'inference_result_T1.0_N16.jsonl').
    """
    if is_s3_path(inference_base):
        bucket, prefix = _parse_s3(inference_base)
        ds_prefix = prefix.rstrip('/') + '/' + ds_name + '/'
        resp = _get_niofs().list_objects_v2(Bucket=bucket, Prefix=ds_prefix, Delimiter='/')
        # Look for inference_result*.jsonl files
        for obj in resp.get('Contents', []):
            fname = obj['Key'].rstrip('/').split('/')[-1]
            if fname.startswith('inference_result') and fname.endswith('.jsonl'):
                return fname
        # Also check CommonPrefixes for any .jsonl objects
        for obj in resp.get('Contents', []):
            fname = obj['Key'].rstrip('/').split('/')[-1]
            if fname.endswith('.jsonl'):
                return fname
        return None
    else:
        ds_dir = os.path.join(os.path.abspath(inference_base), ds_name)
        if not os.path.isdir(ds_dir):
            return None
        for f in sorted(os.listdir(ds_dir)):
            if f.startswith("inference_result") and f.endswith(".jsonl"):
                return f
        return None


def read_jsonl_lines(inference_base, ds_name, jsonl_name=None):
    """Read all JSONL lines for a dataset. Returns list of dicts.
    If jsonl_name is None, auto-detects the JSONL file name.
    """
    if is_s3_path(inference_base):
        bucket, prefix = _parse_s3(inference_base)
        if jsonl_name is None:
            jsonl_name = find_jsonl_name(inference_base, ds_name)
        if jsonl_name is None:
            raise FileNotFoundError(f"No inference_result*.jsonl found in "
                                    f"{inference_base}/{ds_name}/")
        key = prefix.rstrip('/') + '/' + ds_name + '/' + jsonl_name
        resp = _get_niofs().get_object(Bucket=bucket, Key=key)
        text = resp['Body'].read().decode('utf-8')
        return [json.loads(l) for l in text.strip().split('\n') if l.strip()]
    else:
        ds_dir = os.path.join(os.path.abspath(inference_base), ds_name)
        if jsonl_name is not None:
            p = os.path.join(ds_dir, jsonl_name)
            if not os.path.exists(p):
                raise FileNotFoundError(f"JSONL not found: {p}")
        else:
            p = None
            for name in ["inference_result.jsonl", "inference_result_T0.7_N8.jsonl"]:
                candidate = os.path.join(ds_dir, name)
                if os.path.exists(candidate):
                    p = candidate
                    break
            if p is None:
                for f in sorted(os.listdir(ds_dir)):
                    if f.startswith("inference_result") and f.endswith(".jsonl"):
                        p = os.path.join(ds_dir, f)
                        break
            if p is None:
                raise FileNotFoundError(f"No inference_result*.jsonl in {ds_dir}")
        with open(p) as fh:
            return [json.loads(l) for l in fh if l.strip()]


# ═══════════════════════════════════════════════════════════════════════════════
#  Parquet matching
# ═══════════════════════════════════════════════════════════════════════════════

def build_parquet_index_map(parquet_path):
    """Build (clip_id, fw_ts) → (row_idx, extra_info) map."""
    df = pd.read_parquet(parquet_path)
    idx_map = {}
    for row_idx, (_, row) in enumerate(df.iterrows()):
        ei = row["extra_info"]
        cid = ei["clip_id"]
        images = row.get("image", [])
        if hasattr(images, "tolist"):
            images = images.tolist()
        fw_ts = None
        for img in images:
            s = str(img)
            if "/FW/" in s:
                m = re.search(r"/(\d{10}\.\d+)\.jpg", s)
                if m:
                    fw_ts = m.group(1)
                    break
        idx_map[(cid, fw_ts)] = ei
    return idx_map


def match_extra_info(clip_id, frame_id, idx_map):
    """Match JSONL (clip_id, frame_id) to parquet extra_info."""
    key = (clip_id, str(frame_id))
    if key in idx_map:
        return idx_map[key]
    if frame_id:
        try:
            fval = float(frame_id)
            for (cid2, fw_ts2), ei in idx_map.items():
                if cid2 == clip_id and fw_ts2:
                    try:
                        if abs(float(fw_ts2) - fval) < 1e-5:
                            return ei
                    except ValueError:
                        pass
        except ValueError:
            pass
    return None


def analyze_one_dataset(ds_name, inference_base, parquet_base, jsonl_name=None, k=None):
    """统计一个数据集 pass@K。返回 stats dict。

    Args:
        ds_name: dataset name
        inference_base: local or S3 path
        parquet_base: local parquet base path
        jsonl_name: JSONL file name (auto-detect if None)
        k: number of predictions per sample (auto-detect from data if None)
    """
    try:
        lines = read_jsonl_lines(inference_base, ds_name, jsonl_name)
    except Exception as e:
        return {"dataset": ds_name, "error": f"read_failed: {e}"}

    if not lines:
        return {"dataset": ds_name, "error": "empty_jsonl"}

    parquet_path = os.path.join(parquet_base, f"{ds_name}.parquet")
    if not os.path.exists(parquet_path):
        return {"dataset": ds_name, "error": "no_parquet"}

    idx_map = build_parquet_index_map(parquet_path)
    scorer = TaskVLANoEntryRewardV32(debug=False)

    # Auto-detect k from first line's extra.predictions
    if k is None:
        first_extra = lines[0].get("extra", {})
        first_preds = first_extra.get("predictions", [])
        k = len(first_preds) if first_preds else 0
    if k == 0:
        return {"dataset": ds_name, "error": "no_predictions_field"}

    # Counters
    n_total = 0           # total JSONL lines processed
    n_matched = 0         # successfully matched to parquet
    n_pass = 0            # at least 1 of K gets score == 2.0
    n_all_pass = 0        # all K get score == 2.0
    n_none_pass = 0       # 0 of K get score == 2.0
    pass_count_dist = Counter()  # how many pass out of K

    for d in lines:
        clip_id = d["clip_id"]
        frame_id = d.get("frame_id", "")
        extra = d.get("extra", {})
        predictions = extra.get("predictions", [])

        if not predictions:
            continue

        n_total += 1

        ei = match_extra_info(clip_id, frame_id, idx_map)
        if ei is None:
            continue

        n_matched += 1

        # Score all K predictions
        num_pass = 0
        for pred in predictions[:k]:
            result = scorer(ds_name, pred, [], ei)
            if result["score"] == 2.0:
                num_pass += 1

        pass_count_dist[num_pass] += 1
        if num_pass > 0:
            n_pass += 1
        if num_pass == k:
            n_all_pass += 1
        if num_pass == 0:
            n_none_pass += 1

    if n_matched == 0:
        return {"dataset": ds_name, "error": "no_matches", "n_total": n_total, "k": k}

    return {
        "dataset": ds_name,
        "k": k,
        "jsonl_name": jsonl_name or "auto-detected",
        "n_total": n_total,
        "n_matched": n_matched,
        "n_pass": n_pass,
        "pass_rate": round(100 * n_pass / n_matched, 2),
        "n_all_k_pass": n_all_pass,
        "n_none_pass": n_none_pass,
        "avg_pass_per_sample": round(sum(kk * v for kk, v in pass_count_dist.items()) / n_matched, 2),
        "pass_count_distribution": {str(kk): v for kk, v in sorted(pass_count_dist.items())},
    }


def main():
    parser = argparse.ArgumentParser(
        description="统计 T*_N* 推理结果的 pass@K 比率（支持本地和 S3）")
    parser.add_argument(
        "inference_dir", nargs="?",
        default=None,
        help="推理结果目录（本地路径 或 s3://bucket/path）。"
             "默认使用 INFERENCE_BASE")
    parser.add_argument("--dataset", "-d", type=str, default=None,
                       help="只统计特定数据集")
    parser.add_argument("--parquet-dir", type=str, default=PARQUET_BASE)
    parser.add_argument("--config", type=str, default=CONFIG_PATH)
    parser.add_argument("--jsonl-name", type=str, default=None,
                       help="JSONL 文件名（如 inference_result_T1.0_N16.jsonl）。"
                            "默认自动检测目录下第一个 inference_result*.jsonl")
    parser.add_argument("-k", type=int, default=None,
                       help="每条数据的推理次数（默认从 extra.predictions 长度自动推断）")
    parser.add_argument("--output", "-o", type=str, default=None,
                       help="保存 JSON 结果到文件")
    args = parser.parse_args()

    # Determine inference base
    inference_base = args.inference_dir or INFERENCE_BASE
    inference_base = os.path.abspath(inference_base) if not is_s3_path(inference_base) else inference_base

    parquet_base = os.path.abspath(args.parquet_dir)
    mode = "S3" if is_s3_path(inference_base) else "local"

    with open(args.config) as f:
        config = json.load(f)

    if args.dataset:
        datasets = [k for k in config if args.dataset in k]
        if not datasets:
            print(f"No dataset matching '{args.dataset}'")
            sys.exit(1)
    else:
        datasets = sorted(config.keys())

    print("=" * 110)
    print(f"Pass@K Analysis — vla_no_entry_v3_2  [{mode}]")
    print(f"Inference dir: {inference_base}")
    print(f"Parquet dir:   {parquet_base}")
    print(f"Datasets:      {len(datasets)}")
    if args.jsonl_name:
        print(f"JSONL name:    {args.jsonl_name}")
    else:
        print(f"JSONL name:    auto-detect")
    if args.k:
        print(f"K:             {args.k}")
    else:
        print(f"K:             auto-detect from data")
    print(f"Criterion:     at least 1 of K predictions gets score == 2.0")
    print("=" * 110)

    all_stats = []
    t_start = time.time()

    for ds_name in datasets:
        print(f"  {ds_name}...", end=" ", flush=True)
        stats = analyze_one_dataset(
            ds_name, inference_base, parquet_base,
            jsonl_name=args.jsonl_name, k=args.k)
        all_stats.append(stats)

        if "error" in stats:
            print(f"SKIP: {stats['error']}")
        else:
            k_val = stats.get("k", "?")
            print(f"K={k_val}  matched={stats['n_matched']}/{stats['n_total']}  "
                  f"pass@{k_val}={stats['pass_rate']:.1f}%  "
                  f"({stats['n_pass']}/{stats['n_matched']})  "
                  f"avg_pass={stats['avg_pass_per_sample']:.2f}/{k_val}  "
                  f"dist={dict(stats['pass_count_distribution'])}",
                  flush=True)

    elapsed = time.time() - t_start
    valid = [s for s in all_stats if "error" not in s]

    # Overall
    total_matched = sum(s["n_matched"] for s in valid)
    total_pass = sum(s["n_pass"] for s in valid)
    total_all_k = sum(s.get("n_all_k_pass", 0) for s in valid)
    total_none = sum(s["n_none_pass"] for s in valid)

    # Get k from valid results (should be consistent)
    k_vals = set(s.get("k", 0) for s in valid)
    k_overall = max(k_vals) if k_vals else 0

    # Aggregate distribution
    overall_dist = Counter()
    for s in valid:
        for kk, v in s["pass_count_distribution"].items():
            overall_dist[int(kk)] += v

    print()
    print("=" * 110)
    print("PER-DATASET TABLE")
    print("=" * 110)
    print(f"{'Dataset':<55} {'K':>3} {'Total':>6} {'Matched':>7} "
          f"{'Pass@K%':>8} {'Pass':>6} {'Avg/K':>6} {'AllK':>5} {'None':>5}")
    print("-" * 110)
    for s in valid:
        k_val = s.get("k", "?")
        print(f"{s['dataset']:<55} {str(k_val):>3} {s['n_total']:>6} {s['n_matched']:>7} "
              f"{s['pass_rate']:>7.1f}% {s['n_pass']:>6} {s['avg_pass_per_sample']:>5.2f} "
              f"{s.get('n_all_k_pass', 0):>5} {s['n_none_pass']:>5}")

    print()
    print("=" * 110)
    print("OVERALL")
    print("=" * 110)
    print(f"  Mode:              {mode}")
    print(f"  K:                 {k_overall}")
    print(f"  Datasets:          {len(valid)}")
    print(f"  Total samples:     {total_matched}")
    print(f"  Pass@{k_overall} (≥1/{k_overall}): {100*total_pass/total_matched:.2f}%  "
          f"({total_pass}/{total_matched})")
    print(f"  All {k_overall} pass:     {total_all_k} "
          f"({100*total_all_k/total_matched:.2f}%)")
    print(f"  None pass:         {total_none} ({100*total_none/total_matched:.2f}%)")
    print(f"  Avg pass/sample:   "
          f"{sum(int(kk)*v for kk,v in overall_dist.items())/total_matched:.2f} / {k_overall}")
    print(f"  Time elapsed:      {elapsed:.1f}s")
    print()
    print(f"  Pass count distribution (how many of {k_overall} succeed):")
    for kk in sorted(overall_dist.keys()):
        cnt = overall_dist[kk]
        bar = "█" * int(40 * cnt / total_matched)
        print(f"    {kk}/{k_overall}: {cnt:>6} ({100*cnt/total_matched:5.1f}%) {bar}")

    # ── Save JSON if requested ──
    if args.output:
        name = os.path.basename(inference_base.rstrip('/'))
        if is_s3_path(inference_base):
            name = name or "s3_output"
        output_path = args.output or os.path.join(os.getcwd(), f"pass_at_{k_overall}_{name}.json")
        output = {
            "inference_dir": inference_base,
            "mode": mode,
            "k": k_overall,
            "total_datasets": len(valid),
            "total_matched": total_matched,
            "total_pass": total_pass,
            "pass_rate_pct": round(100 * total_pass / total_matched, 2),
            "total_all_k_pass": total_all_k,
            "total_none_pass": total_none,
            "avg_pass_per_sample": round(
                sum(int(kk)*v for kk, v in overall_dist.items()) / total_matched, 2),
            "overall_pass_distribution": {
                str(kk): v for kk, v in sorted(overall_dist.items())},
            "per_dataset": all_stats,
            "elapsed_s": round(elapsed, 1),
        }
        with open(output_path, "w") as f:
            json.dump(output, f, indent=2, ensure_ascii=False, default=str)
        print(f"\nSaved to: {output_path}")


if __name__ == "__main__":
    main()
