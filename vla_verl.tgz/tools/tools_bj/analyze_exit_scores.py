#!/usr/bin/env python3
"""
Analyze exit reward scores for VLA inference results (local or S3).

Matches JSONL predictions to local parquet data by (clip_id, frame_id),
scores with vla_no_entry_v3_2, and reports per-dataset + overall statistics.

Supports both local paths and S3/niofs paths (auto-detected):
  python tools/tools_bj/analyze_exit_scores.py /path/to/inference_dir
  python tools/tools_bj/analyze_exit_scores.py s3://bucket/path/to/inference_dir
  python tools/tools_bj/analyze_exit_scores.py /path/to/inference_dir -d 0635_part0005 -n 100
  python tools/tools_bj/analyze_exit_scores.py /path/to/inference_dir -o result.json
"""

import argparse
import json
import os
import re
import sys
import time
from collections import Counter

import numpy as np
import pandas as pd

# ── Add project root ──
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, _PROJECT_ROOT)

from verl.utils.reward_score.vla_no_entry_v3_2 import TaskVLANoEntryRewardV32

# Paths
CONFIG_PATH = os.path.join(_PROJECT_ROOT, "config", "idx", "260701-no_entry-exit_train.json")
PARQUET_BASE = "/perception-hl/beijin.zhou/deeprl/260701_rl_exit_data"

# ── NIOFS client (lazy init, for S3 mode) ──
_niofs_client = None


def _get_niofs():
    global _niofs_client
    if _niofs_client is None:
        import niofs
        ak = os.environ.get('LUSTRE_ACCESS_KEY', 'b89e365554ef75f8')
        sk = os.environ.get('LUSTRE_SECRET_KEY', '0910180b207f4edd9baaa030cf4a2902')
        _niofs_client = niofs.Client(ak, sk, max_pool_connections=32)
    return _niofs_client


def _parse_s3(s3_path):
    """s3://bucket/key → (bucket, key)."""
    p = s3_path.strip()
    for pre in ('s3://', 's3:'):
        if p.startswith(pre):
            p = p[len(pre):]
            break
    p = p.lstrip('/')
    parts = p.split('/', 1)
    if len(parts) != 2:
        raise ValueError(f"Invalid S3 path: {s3_path}")
    return parts[0], parts[1]


def is_s3_path(path):
    return path.startswith('s3://') or path.startswith('s3:')


# ═══════════════════════════════════════════════════════════════════════════════
#  JSONL reading — local or S3
# ═══════════════════════════════════════════════════════════════════════════════

def list_dataset_dirs(inference_base):
    """List dataset subdirectories (local or S3)."""
    if is_s3_path(inference_base):
        bucket, prefix = _parse_s3(inference_base)
        prefix = prefix.rstrip('/') + '/'
        resp = _get_niofs().list_objects_v2(Bucket=bucket, Prefix=prefix, Delimiter='/')
        return sorted(p['Prefix'].rstrip('/').split('/')[-1]
                      for p in resp.get('CommonPrefixes', []))
    else:
        base = os.path.abspath(inference_base)
        if not os.path.isdir(base):
            return []
        return sorted(d for d in os.listdir(base)
                      if os.path.isdir(os.path.join(base, d)))


def read_jsonl_lines(inference_base, ds_name):
    """Read all JSONL lines for a dataset. Returns list of dicts."""
    if is_s3_path(inference_base):
        bucket, prefix = _parse_s3(inference_base)
        key = prefix.rstrip('/') + '/' + ds_name + '/inference_result.jsonl'
        resp = _get_niofs().get_object(Bucket=bucket, Key=key)
        text = resp['Body'].read().decode('utf-8')
        return [json.loads(l) for l in text.strip().split('\n') if l.strip()]
    else:
        ds_dir = os.path.join(os.path.abspath(inference_base), ds_name)
        for name in ["inference_result.jsonl", 'inference_result_"".jsonl']:
            p = os.path.join(ds_dir, name)
            if os.path.exists(p):
                break
        else:
            for f in os.listdir(ds_dir):
                if f.startswith("inference_result") and f.endswith(".jsonl"):
                    p = os.path.join(ds_dir, f)
                    break
            else:
                raise FileNotFoundError(f"No inference_result.jsonl in {ds_dir}")
        with open(p) as fh:
            return [json.loads(l) for l in fh if l.strip()]


# ═══════════════════════════════════════════════════════════════════════════════
#  Parquet matching
# ═══════════════════════════════════════════════════════════════════════════════

def build_parquet_map(parquet_path):
    """Build (clip_id, fw_ts) → extra_info map from local parquet."""
    df = pd.read_parquet(parquet_path)
    pmap = {}
    for _, row in df.iterrows():
        ei = row["extra_info"]
        cid = ei["clip_id"]
        images = row.get("image", [])
        if hasattr(images, "tolist"):
            images = images.tolist()
        fw_ts = None
        for img in images:
            s = str(img)
            if "/FW/" in s:
                m = re.search(r"/(\d{10}\.\d+)\.jpg", s)
                if m:
                    fw_ts = m.group(1)
                    break
        pmap[(cid, fw_ts)] = ei
    return pmap


def match_parquet(clip_id, frame_id, pmap):
    """Match (clip_id, frame_id) to parquet extra_info.
    Falls back to float comparison for precision diffs
    (e.g. "1774795426.53925" vs "1774795426.539250").
    """
    key = (clip_id, str(frame_id))
    if key in pmap:
        return pmap[key]
    if frame_id:
        try:
            fval = float(frame_id)
            for (cid2, fw_ts2), ei in pmap.items():
                if cid2 == clip_id and fw_ts2:
                    try:
                        if abs(float(fw_ts2) - fval) < 1e-5:
                            return ei
                    except ValueError:
                        pass
        except ValueError:
            pass
    return None


# ═══════════════════════════════════════════════════════════════════════════════
#  Scoring
# ═══════════════════════════════════════════════════════════════════════════════

def analyze_one_dataset(ds_name, inference_base, max_frames=None):
    """Analyze a single dataset. Returns stats dict."""
    parquet_path = os.path.join(PARQUET_BASE, f"{ds_name}.parquet")
    if not os.path.exists(parquet_path):
        return {"dataset": ds_name, "error": "no_parquet"}

    try:
        jsonl_lines = read_jsonl_lines(inference_base, ds_name)
    except Exception as e:
        return {"dataset": ds_name, "error": f"read_failed: {e}"}

    pmap = build_parquet_map(parquet_path)
    scorer = TaskVLANoEntryRewardV32(debug=False)

    scores = []
    reason_counts = Counter()
    n_matched = 0
    n_unmatched = 0

    for d in jsonl_lines:
        pred = d.get("prediction", "")
        ei = match_parquet(d["clip_id"], d.get("frame_id", ""), pmap)
        if ei is None:
            n_unmatched += 1
            continue

        result = scorer(ds_name, pred, [], ei)
        scores.append(result["score"])
        reason_counts[result.get("reason", "unknown")] += 1
        n_matched += 1

        if max_frames and n_matched >= max_frames:
            break

    if not scores:
        return {"dataset": ds_name, "error": "all_unmatched",
                "n_jsonl": len(jsonl_lines)}

    arr = np.array(scores)
    n = len(scores)
    return {
        "dataset": ds_name,
        "n_parquet_rows": len(pmap),
        "n_jsonl": len(jsonl_lines),
        "n_matched": n_matched,
        "n_unmatched": n_unmatched,
        "mean": round(float(np.mean(arr)), 4),
        "std": round(float(np.std(arr)), 4),
        "median": round(float(np.median(arr)), 4),
        "min": round(float(np.min(arr)), 4),
        "max": round(float(np.max(arr)), 4),
        "exit_match_pct": round(100 * reason_counts.get("exit_path_matched", 0) / n, 1),
        "crash_pct": round(100 * reason_counts.get("crash_into_wall", 0) / n, 1),
        "no_match_pct": round(100 * reason_counts.get("no_exit_path_match", 0) / n, 1),
        "no_ids_pct": round(100 * reason_counts.get("no_exit_path_road_ids", 0) / n, 1),
        "reason_counts": {k: v for k, v in reason_counts.most_common()},
    }


# ═══════════════════════════════════════════════════════════════════════════════
#  Main
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="Analyze exit reward scores for VLA inference results (local or S3)")
    parser.add_argument(
        "inference_dir",
        help="Base directory (local path or s3://bucket/path) containing "
             "per-dataset inference_result.jsonl subdirectories")
    parser.add_argument("--output", "-o", type=str, default=None)
    parser.add_argument("--max-frames", "-n", type=int, default=None,
                        help="Max predictions to score per dataset")
    parser.add_argument("--dataset", "-d", type=str, default=None,
                        help="Only analyze a specific dataset (e.g. 0635_part0005)")
    args = parser.parse_args()

    inference_base = args.inference_dir

    # Load config
    if not os.path.exists(CONFIG_PATH):
        print(f"ERROR: config not found: {CONFIG_PATH}")
        sys.exit(1)
    with open(CONFIG_PATH) as f:
        config = json.load(f)
    config_ds = set(config.keys())

    # List available dataset dirs
    mode = "S3" if is_s3_path(inference_base) else "local"
    print(f"Listing {mode} directories...", flush=True)
    available = set(list_dataset_dirs(inference_base))
    datasets = sorted(available & config_ds)

    if args.dataset:
        datasets = [d for d in datasets if args.dataset in d]
    if not datasets:
        print(f"No matching exit datasets found! (available in dir: {len(available)}, "
              f"in config: {len(config_ds)}, intersection: {len(available & config_ds)})")
        sys.exit(1)

    print("=" * 90)
    print(f"Exit Score Analysis — vla_no_entry_v3_2  [{mode}]")
    print(f"Dir:  {inference_base}")
    print(f"Sets: {len(datasets)}")
    print("=" * 90)

    all_stats = []
    t_start = time.time()

    for ds_name in datasets:
        stats = analyze_one_dataset(ds_name, inference_base, args.max_frames)
        all_stats.append(stats)
        if "error" in stats:
            print(f"  SKIP {ds_name}: {stats['error']}")
            continue
        print(f"  {ds_name:<55} matched={stats['n_matched']:>4}/{stats['n_jsonl']:<4}  "
              f"mean={stats['mean']:>7.3f}  +2.0:{stats['exit_match_pct']:>5.1f}%  "
              f"wall:{stats['crash_pct']:>5.1f}%  "
              f"0mat:{stats['no_match_pct']:>4.1f}%  0ids:{stats['no_ids_pct']:>4.1f}%",
              flush=True)

    elapsed = time.time() - t_start
    valid = [s for s in all_stats if "error" not in s]
    if not valid:
        print("\nNo valid results!"); sys.exit(1)

    total_matched = sum(s["n_matched"] for s in valid)
    total_jsonl = sum(s["n_jsonl"] for s in valid)
    total_parquet = sum(s["n_parquet_rows"] for s in valid)

    # ── Per-dataset table ──
    print()
    print("=" * 90)
    print("PER-DATASET TABLE")
    print("=" * 90)
    print(f"{'Dataset':<55} {'Matched':>7} {'Mean':>8} {'+2.0%':>7} {'Wall%':>7} {'0mat%':>7} {'0ids%':>7}")
    print("-" * 105)
    for s in valid:
        print(f"{s['dataset']:<55} {s['n_matched']:>4}/{s['n_jsonl']:<4}  "
              f"{s['mean']:>8.3f} {s['exit_match_pct']:>6.1f}% {s['crash_pct']:>6.1f}% "
              f"{s['no_match_pct']:>6.1f}% {s['no_ids_pct']:>6.1f}%")

    # ── Overall ──
    total_reasons = Counter()
    all_scores = []
    for s in valid:
        total_reasons.update(s["reason_counts"])
        for reason, cnt in s["reason_counts"].items():
            if reason == "exit_path_matched":
                all_scores.extend([2.0] * cnt)
            elif reason in ("no_exit_path_match", "no_exit_path_road_ids", "no_road_geometries"):
                all_scores.extend([0.0] * cnt)
            elif reason == "crash_into_wall":
                all_scores.extend([-1.0] * cnt)
            elif reason == "trajectory_too_short":
                all_scores.extend([-3.0] * cnt)
            elif reason == "no_trajectory_parsed":
                all_scores.extend([-4.0] * cnt)

    print()
    print("=" * 90)
    print("OVERALL")
    print("=" * 90)
    print(f"  Mode:               {mode}")
    print(f"  Datasets:           {len(valid)}")
    print(f"  Parquet rows:       {total_parquet}")
    print(f"  JSONL predictions:  {total_jsonl}")
    print(f"  Matched & scored:   {total_matched} ({100*total_matched/total_jsonl:.1f}%)")
    print(f"  Time:               {elapsed:.1f}s")
    print()
    print(f"  Mean score:         {np.mean(all_scores):.4f}")
    print(f"  Median:             {np.median(all_scores):.4f}")
    print(f"  Std:                {np.std(all_scores):.4f}")
    print()
    print(f"  Reason distribution:")
    for reason, cnt in total_reasons.most_common():
        bar = "█" * int(50 * cnt / total_matched)
        print(f"    {reason:<30s} {cnt:>6d} ({100*cnt/total_matched:5.1f}%) {bar}")

    # ── Save ──
    output = {
        "inference_dir": inference_base,
        "mode": mode,
        "total_datasets": len(valid),
        "total_matched": total_matched,
        "total_jsonl": total_jsonl,
        "mean_score": round(float(np.mean(all_scores)), 4),
        "median_score": round(float(np.median(all_scores)), 4),
        "overall_reasons": {k: v for k, v in total_reasons.most_common()},
        "per_dataset": all_stats,
        "elapsed_s": round(elapsed, 1),
    }

    name = os.path.basename(inference_base.rstrip('/'))
    if is_s3_path(inference_base):
        name = name or "s3_output"
    output_path = args.output or os.path.join(os.getcwd(), f"exit_score_{name}.json")
    with open(output_path, "w") as f:
        json.dump(output, f, indent=2, ensure_ascii=False, default=str)
    print(f"\nSaved to: {output_path}")


if __name__ == "__main__":
    main()
