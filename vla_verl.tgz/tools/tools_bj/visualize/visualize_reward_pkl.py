"""
Interactive web-based visualization for VLA No-Entry Reward debug pkl files.

Reads all .pkl files from a directory and launches a Panel web app showing:
  - BEV view: road network (colored by class), freespace polygons, model trajectory
  - Segment-binding violation details
  - Model output text
  - Score, reason, and statistics

Usage:
  python tools/tools_bj/visualize/visualize_reward_pkl.py /path/to/pkl_dir
  python tools/tools_bj/visualize/visualize_reward_pkl.py /path/to/pkl_dir --port 5006

Reference: tools/tools_bj/ref/visualize_no_entry_v2.py (Panel/Bokeh patterns)
"""

import argparse
import glob
import os
import pickle
import re
import sys
from collections import defaultdict
from io import BytesIO
from base64 import b64encode

import numpy as np
import panel as pn
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ═══════════════════════════════════════════════════════════════════════════════
#  Constants
# ═══════════════════════════════════════════════════════════════════════════════

FORBIDDEN_ROAD_CLASSES = {'noEntryRoad', 'noEntryRoadBarrier', 'ArriveDeadEndRoad', 'onlyRetrograde'}

ROAD_CLS_COLORS = {
    'normalRoad':              '#4caf50',
    'entryRoad':               '#81c784',
    'noEntryRoad':             '#e53935',
    'noEntryRoadBarrier':      '#b71c1c',
    'onlyRetrograde':          '#ff9800',
    'ArriveDeadEndRoad':       '#795548',
    'twoWayRoadNoEntry':       '#9c27b0',
    'twoWayRoadNoEntryBarrier': '#6a1b9a',
    'unknown':                 '#9e9e9e',
}
DEFAULT_ROAD_COLOR = '#9e9e9e'

FREESPACE_COLORS = {
    'safe':      ('#4caf50', 0.12),
    'unsafe':    ('#e53935', 0.22),
    'uncertain': ('#ff9800', 0.12),
}

SEGMENT_COLORS = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A']
BEV_SIZE_M = 60.0
ROT_BEV = np.array([[0, -1], [1, 0]])


# ═══════════════════════════════════════════════════════════════════════════════
#  RLE / Freespace decoding
# ═══════════════════════════════════════════════════════════════════════════════

def decode_freespace_rle(rle):
    """Decode COCO RLE mask → polygon contours in BEV display coords."""
    if not rle or 'counts' not in rle or 'size' not in rle:
        return []
    try:
        from pycocotools import mask as coco_mask
    except ImportError:
        return []
    counts = rle['counts']
    if isinstance(counts, str):
        counts = counts.encode('utf-8')
    try:
        m = coco_mask.decode({'size': rle['size'], 'counts': counts})
    except Exception:
        return []
    if not np.any(m):
        return []
    try:
        import cv2
        contours, _ = cv2.findContours(m.astype(np.uint8), cv2.RETR_EXTERNAL,
                                       cv2.CHAIN_APPROX_SIMPLE)
    except ImportError:
        return []
    polygons = []
    h, w = rle['size']
    scale = BEV_SIZE_M / w
    offset = BEV_SIZE_M / 2.0
    for c in contours:
        if len(c) < 3:
            continue
        xs = c[:, 0, 0].astype(float) * scale - offset
        ys = offset - c[:, 0, 1].astype(float) * scale
        polygons.append((xs, ys))
    return polygons


def rot_to_bev(points):
    """Rotate ego coords (x=fwd, y=left) → BEV display (x=right, y=fwd)."""
    if points is None or len(points) == 0:
        return None
    arr = np.asarray(points, dtype=float)
    return arr @ ROT_BEV.T


# ═══════════════════════════════════════════════════════════════════════════════
#  BEV matplotlib figure builder
# ═══════════════════════════════════════════════════════════════════════════════

def build_bev_figure(pkl_data):
    """Build a matplotlib figure for the BEV view from pkl debug data.

    Returns a matplotlib Figure ready for embedding in Panel.
    """
    clip_id = pkl_data.get('clip_id', '?')
    result = pkl_data.get('result', {})
    score = result.get('score', 0)
    reason = result.get('reason', '?')
    details = result.get('details', {})
    forbidden_ids = pkl_data.get('forbidden_ids', set())

    fig, ax = plt.subplots(1, 1, figsize=(8, 8))

    # ── Layer 1: Freespace ────────────────────────────────────────────────
    freespace_info = pkl_data.get('freespace_info', {})
    for key, (color, alpha) in FREESPACE_COLORS.items():
        rle = freespace_info.get(key) if freespace_info else None
        if not rle:
            continue
        for xs, ys in decode_freespace_rle(rle):
            ax.fill(xs, ys, facecolor=color, edgecolor=color,
                    alpha=alpha, linewidth=0.5, zorder=0)

    # ── Layer 2: Road geometries ──────────────────────────────────────────
    all_road_geoms = pkl_data.get('all_road_geoms', {})
    road_id_to_cls = pkl_data.get('road_id_to_cls', {})

    for road_id, geom in all_road_geoms.items():
        if len(geom) < 2:
            continue
        pts_bev = rot_to_bev(np.array(geom))
        road_cls = road_id_to_cls.get(road_id, 'unknown')
        color = ROAD_CLS_COLORS.get(road_cls, DEFAULT_ROAD_COLOR)
        is_forbidden = road_id in forbidden_ids
        lw = 3.5 if is_forbidden else 1.8
        style = '--' if is_forbidden else '-'
        alpha_val = 0.9 if is_forbidden else 0.6
        ax.plot(pts_bev[:, 0], pts_bev[:, 1], color=color, linewidth=lw,
                linestyle=style, alpha=alpha_val, zorder=1,
                label=f"{'✗' if is_forbidden else ' '} {road_id} ({road_cls})"
                if is_forbidden else None)

    # ── Layer 3: Ego marker ───────────────────────────────────────────────
    ax.plot(0, 0, marker='o', color='yellow', markersize=12,
            markeredgecolor='black', markeredgewidth=2.0, zorder=5, label='Ego')

    # ── Layer 4: Model trajectory ─────────────────────────────────────────
    abs_traj = pkl_data.get('abs_traj')
    if abs_traj is not None and len(abs_traj) > 0:
        traj = np.array(abs_traj)
        traj_bev = rot_to_bev(traj)
        origin_bev = np.array([[0, 0]])
        full_bev = np.vstack([origin_bev, traj_bev])

        # Line with arrows every few points
        ax.plot(full_bev[:, 0], full_bev[:, 1], 'r-', linewidth=2.5,
                alpha=0.85, zorder=4, label='Pred traj')
        ax.scatter(full_bev[:, 0], full_bev[:, 1], c='red', s=35,
                   zorder=5, edgecolors='darkred', linewidths=0.5)
        # Start / End markers
        ax.scatter(full_bev[0, 0], full_bev[0, 1], c='white', s=200,
                   marker='o', zorder=6, edgecolors='black', linewidths=2)
        ax.scatter(full_bev[-1, 0], full_bev[-1, 1], c='red', s=200,
                   marker='X', zorder=6, edgecolors='black', linewidths=2)

        # Draw segments (3 consecutive points each) after prepending origin
        min_pts = 5
        if len(traj) >= min_pts:
            seg_traj = np.vstack([np.array([[0.0, 0.0]]), traj[:min_pts]])
            for seg_idx in range(len(seg_traj) - 2):
                segment = seg_traj[seg_idx:seg_idx + 3]
                seg_bev = rot_to_bev(segment)
                center_bev = rot_to_bev(np.mean(segment, axis=0).reshape(1, -1))
                color = SEGMENT_COLORS[seg_idx % len(SEGMENT_COLORS)]
                ax.plot(seg_bev[:, 0], seg_bev[:, 1], '-', color=color,
                        linewidth=3, alpha=0.7, zorder=3)
                ax.scatter(center_bev[0, 0], center_bev[0, 1], c=color,
                           s=80, marker='*', zorder=7, edgecolors='black',
                           linewidths=0.8)

    # ── Layer 5: Violation markers ────────────────────────────────────────
    if reason == 'segment_binds_to_forbidden_road':
        binding_info = details.get('binding_info', {})
        if binding_info and binding_info.get('closest_pt'):
            cp = np.array(binding_info['closest_pt'])
            cp_bev = rot_to_bev(cp.reshape(1, -1))
            ax.plot(cp_bev[0, 0], cp_bev[0, 1], marker='*', color='magenta',
                    markersize=20, markeredgecolor='black', markeredgewidth=1.5,
                    zorder=8)

        viol_road = details.get('road_id', '?')
        viol_cls = details.get('road_cls', '?')
        seg_idx = details.get('segment_idx', '?')
        bind_dist = binding_info.get('dist', float('nan'))
        bind_angle = binding_info.get('angle_deg', float('nan'))

        info_text = (
            f"VIOLATION: segment #{seg_idx} → {viol_road} ({viol_cls})\n"
            f"dist={bind_dist:.2f}m  angle={bind_angle:.1f}°"
        )
        ax.text(0.02, 0.98, info_text, transform=ax.transAxes,
                fontsize=9, verticalalignment='top', fontfamily='monospace',
                bbox=dict(boxstyle='round,pad=0.4', facecolor='mistyrose',
                          edgecolor='red', alpha=0.92),
                zorder=9)

    elif reason == 'crash_into_wall':
        unsafe_pts = details.get('unsafe_points', [])
        num_unsafe = details.get('num_unsafe', 0)
        if unsafe_pts and abs_traj:
            traj = np.array(abs_traj)
            for idx in unsafe_pts:
                if idx < len(traj):
                    pt_bev = rot_to_bev(traj[idx].reshape(1, -1))
                    ax.plot(pt_bev[0, 0], pt_bev[0, 1], marker='x', color='red',
                            markersize=16, markeredgewidth=3.0, zorder=7)
        ax.text(0.02, 0.98, f'CRASH: {num_unsafe} unsafe points',
                transform=ax.transAxes, fontsize=9,
                verticalalignment='top', fontfamily='monospace',
                bbox=dict(boxstyle='round,pad=0.4', facecolor='mistyrose',
                          edgecolor='red', alpha=0.92),
                zorder=9)

    # ── Axes setup ────────────────────────────────────────────────────────
    half = BEV_SIZE_M / 2.0
    ax.set_xlim(-half, half)
    ax.set_ylim(-half, half)
    ax.set_xlabel('x (m) → right', fontsize=10)
    ax.set_ylabel('y (m) → forward', fontsize=10)
    ax.set_aspect('equal')
    ax.grid(True, alpha=0.25, linestyle=':')
    ax.axhline(y=0, color='gray', alpha=0.2, linewidth=0.5)
    ax.axvline(x=0, color='gray', alpha=0.2, linewidth=0.5)
    ax.legend(loc='upper right', fontsize=7, ncol=2, framealpha=0.8)

    title_color = 'darkred' if score < 0 else 'darkgreen'
    ax.set_title(f"{clip_id}  |  score={score}  reason={reason}",
                 fontsize=10, fontfamily='monospace', color=title_color,
                 fontweight='bold')

    fig.tight_layout()
    return fig


# ═══════════════════════════════════════════════════════════════════════════════
#  Data loader
# ═══════════════════════════════════════════════════════════════════════════════

def load_pkl_files(pkl_dir, max_frames=500):
    """Load all pkl files from a directory, return list of dicts."""
    pkl_paths = sorted(glob.glob(os.path.join(pkl_dir, '*.pkl')))
    if not pkl_paths:
        return []
    if len(pkl_paths) > max_frames:
        print(f"  Limiting to {max_frames} files (found {len(pkl_paths)})")
        pkl_paths = pkl_paths[:max_frames]

    data_list = []
    for p in pkl_paths:
        try:
            with open(p, 'rb') as f:
                data_list.append(pickle.load(f))
        except Exception as e:
            print(f"  ERROR loading {os.path.basename(p)}: {e}")
    return data_list


# ═══════════════════════════════════════════════════════════════════════════════
#  Panel UI class
# ═══════════════════════════════════════════════════════════════════════════════

class PklRewardViewer:
    """Interactive Panel web app for browsing VLA reward debug pkl files."""

    def __init__(self, pkl_dir, max_frames=500):
        self.pkl_dir = pkl_dir
        self.data_list = load_pkl_files(pkl_dir, max_frames=max_frames)
        self.current_index = 0

        if not self.data_list:
            print("ERROR: No pkl files loaded!")
            return

        # Pre-compute statistics
        self._compute_stats()
        self._setup_widgets()
        self.update_display()

    def _compute_stats(self):
        """Compute summary statistics across all pkl files."""
        self.stats = defaultdict(lambda: {'count': 0, 'scores': []})
        for d in self.data_list:
            reason = d.get('result', {}).get('reason', 'unknown')
            score = d.get('result', {}).get('score', 0)
            self.stats[reason]['count'] += 1
            self.stats[reason]['scores'].append(score)

    def _setup_widgets(self):
        max_idx = max(0, len(self.data_list) - 1)

        # Navigation
        self.slider = pn.widgets.IntSlider(
            name='Frame', start=0, end=max_idx, value=0, width=500)
        self.slider.param.watch(self._on_slider_change, 'value')

        self.prev_btn = pn.widgets.Button(name='◀ Prev', button_type='primary', width=90)
        self.next_btn = pn.widgets.Button(name='Next ▶', button_type='primary', width=90)
        self.prev_btn.on_click(self._prev_frame)
        self.next_btn.on_click(self._next_frame)

        self.jump_input = pn.widgets.IntInput(
            name='Jump to', value=1, start=1, end=len(self.data_list), width=100)
        self.jump_btn = pn.widgets.Button(name='Go', button_type='primary', width=50)
        self.jump_btn.on_click(self._jump_to_frame)

        # Filters
        self.filter_reason = pn.widgets.MultiChoice(
            name='Filter by reason',
            options=sorted(self.stats.keys()),
            value=sorted(self.stats.keys()),
            width=400)
        self.filter_reason.param.watch(lambda e: self._apply_filters(), 'value')

        self.filter_score_min = pn.widgets.FloatInput(
            name='Score ≥', value=-10.0, step=0.5, width=100)
        self.filter_score_max = pn.widgets.FloatInput(
            name='Score ≤', value=10.0, step=0.5, width=100)
        self.filter_score_min.param.watch(lambda e: self._apply_filters(), 'value')
        self.filter_score_max.param.watch(lambda e: self._apply_filters(), 'value')

        # Info panes
        self.info_pane = pn.pane.Markdown("", sizing_mode='stretch_width')
        self.stats_pane = pn.pane.Markdown("", sizing_mode='stretch_width')
        self.bev_pane = pn.pane.Matplotlib(None, width=660, height=660, tight=True)
        self.solution_pane = pn.pane.Markdown("", sizing_mode='stretch_width')

        # Build visible index list
        self._apply_filters()

    def _apply_filters(self):
        """Rebuild filtered visible indices."""
        reasons = set(self.filter_reason.value)
        score_min = self.filter_score_min.value
        score_max = self.filter_score_max.value
        self.visible_indices = [
            i for i, d in enumerate(self.data_list)
            if d.get('result', {}).get('reason', 'unknown') in reasons
            and score_min <= d.get('result', {}).get('score', 0) <= score_max
        ]
        if self.visible_indices:
            if self.current_index not in self.visible_indices:
                self.current_index = self.visible_indices[0]
            self.slider.end = max(self.visible_indices)
            self.slider.value = self.current_index
            self.jump_input.end = len(self.visible_indices)
        self.update_display()

    def _on_slider_change(self, event):
        self.current_index = event.new
        self.update_display()

    def _prev_frame(self, event):
        if not self.visible_indices:
            return
        before = [v for v in self.visible_indices if v < self.current_index]
        if before:
            self.current_index = before[-1]
            self.slider.value = self.current_index

    def _next_frame(self, event):
        if not self.visible_indices:
            return
        after = [v for v in self.visible_indices if v > self.current_index]
        if after:
            self.current_index = after[0]
            self.slider.value = self.current_index

    def _jump_to_frame(self, event):
        target = self.jump_input.value - 1
        if 0 <= target < len(self.visible_indices):
            self.current_index = self.visible_indices[target]
            self.slider.value = self.current_index

    def _build_info_md(self, data):
        """Build info markdown for a single pkl data entry."""
        clip_id = data.get('clip_id', '?')
        data_source = data.get('data_source', '?')
        step = data.get('step', '?')
        result = data.get('result', {})
        score = result.get('score', '?')
        reason = result.get('reason', '?')
        details = result.get('details', {})
        forbidden_ids = data.get('forbidden_ids', set())
        abs_traj = data.get('abs_traj')
        num_pts = len(abs_traj) if abs_traj else 0

        # Road info
        road_id_to_cls = data.get('road_id_to_cls', {})
        forbidden_roads_str = ", ".join(
            f"{rid}({road_id_to_cls.get(rid, '?')})"
            for rid in sorted(forbidden_ids)
        ) if forbidden_ids else "(none)"

        # Binding details
        binding_str = ""
        if reason == 'segment_binds_to_forbidden_road':
            bi = details.get('binding_info', {})
            binding_str = (
                f"\n- **Violation road:** {details.get('road_id', '?')} "
                f"({details.get('road_cls', '?')})\n"
                f"- **Segment index:** {details.get('segment_idx', '?')}\n"
                f"- **Binding dist:** {bi.get('dist', '?'):.2f}m  "
                f"**angle:** {bi.get('angle_deg', '?'):.1f}°"
                if isinstance(bi.get('dist'), float) else ""
            )
        elif reason == 'crash_into_wall':
            binding_str = (
                f"\n- **Unsafe points:** {details.get('num_unsafe', '?')}\n"
                f"- **Unsafe indices:** {details.get('unsafe_points', '?')}"
            )
        elif reason == 'trajectory_too_short':
            binding_str = (
                f"\n- **Num points:** {details.get('num_points', '?')} "
                f"(need ≥ {details.get('required', 5)})"
            )

        # Freespace info
        unsafe_info = data.get('unsafe_info', {})
        freespace_str = ""
        if unsafe_info:
            freespace_str = (
                f"- **Unsafe mask:** {unsafe_info.get('mask_shape', '?')} "
                f"(RLE {unsafe_info.get('rle_counts_len', 0)} bytes)"
            )

        total = len(self.data_list)
        visible_pos = (self.visible_indices.index(self.current_index) + 1
                       if self.current_index in self.visible_indices else "?")

        score_color = 'red' if score < 0 else 'green'
        return f"""
# Frame {self.current_index + 1} / {total}  (filtered #{visible_pos} / {len(self.visible_indices)})

| Field | Value |
|-------|-------|
| **Clip ID** | `{clip_id}` |
| **Data Source** | `{data_source}` |
| **Step** | {step} |
| **Score** | <span style="color:{score_color};font-weight:bold;font-size:1.2em">{score}</span> |
| **Reason** | **{reason}** |
| **Trajectory points** | {num_pts} |
| **Forbidden roads** | {forbidden_roads_str} |
| **Freespace** | {freespace_str} |

### Violation Details
{binding_str if binding_str else '*No violation*'}
"""

    def _build_stats_md(self):
        """Build statistics summary markdown."""
        total = len(self.data_list)
        visible = len(self.visible_indices)
        lines = [f"## Statistics  (total={total}, visible={visible})\n"]
        lines.append("| Reason | Count | Avg Score |")
        lines.append("|--------|-------|-----------|")
        for reason in sorted(self.stats.keys(), key=lambda r: -self.stats[r]['count']):
            info = self.stats[reason]
            avg = np.mean(info['scores']) if info['scores'] else 0
            lines.append(f"| {reason} | {info['count']} | {avg:.3f} |")
        return "\n".join(lines)

    def _build_solution_md(self, data):
        """Build solution_str display markdown."""
        sol = data.get('solution_str', '')
        if not sol:
            return "*No solution_str*"
        # Truncate for display but keep full in details
        preview = sol[:800]
        full = sol
        return f"""
### Model Output ({len(sol)} chars)

<details open>
<summary>Preview (first 800 chars)</summary>

```text
{preview}
```
</details>

<details>
<summary>Full output</summary>

```text
{full}
```
</details>
"""

    def update_display(self):
        """Refresh all display panes for the current frame."""
        if not self.data_list or not self.visible_indices:
            self.info_pane.object = "**No data or all filtered out**"
            self.bev_pane.object = None
            self.solution_pane.object = ""
            self.stats_pane.object = self._build_stats_md()
            return

        data = self.data_list[self.current_index]

        # Info pane
        self.info_pane.object = self._build_info_md(data)

        # BEV figure
        try:
            fig = build_bev_figure(data)
            self.bev_pane.object = fig
            plt.close(fig)
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.bev_pane.object = None

        # Solution pane
        self.solution_pane.object = self._build_solution_md(data)

        # Stats
        self.stats_pane.object = self._build_stats_md()

    def create_layout(self):
        """Build and return the full Panel layout."""
        # Navigation bar
        nav_bar = pn.Row(
            self.prev_btn,
            self.slider,
            self.next_btn,
            pn.Spacer(width=15),
            self.jump_input,
            self.jump_btn,
            styles={'background': '#ecf0f1', 'padding': '10px',
                    'border-radius': '5px', 'margin-bottom': '8px'}
        )

        # Filter bar
        filter_bar = pn.Row(
            pn.pane.Markdown("**Filters:**", width=60),
            self.filter_reason,
            pn.Spacer(width=20),
            pn.pane.Markdown("Score:", width=45),
            self.filter_score_min,
            pn.pane.Markdown("–", width=15),
            self.filter_score_max,
            styles={'background': '#fff3e0', 'padding': '6px 10px',
                    'border-radius': '5px', 'margin-bottom': '8px'}
        )

        # Left column: info + stats
        left_col = pn.Column(
            self.info_pane,
            self.solution_pane,
            self.stats_pane,
            width=500,
            sizing_mode='stretch_height',
        )

        # Right column: BEV
        right_col = pn.Column(
            pn.pane.Markdown("### BEV View"),
            self.bev_pane,
            width=700,
        )

        content = pn.Row(left_col, right_col, align='start')

        return pn.Column(
            nav_bar,
            filter_bar,
            pn.layout.Divider(),
            content,
            sizing_mode='stretch_width',
        )


# ═══════════════════════════════════════════════════════════════════════════════
#  Main
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description='Interactive visualization for VLA No-Entry Reward debug pkl files')
    parser.add_argument('--input_dir', type=str,default="/tmp/vla_reward_debug",
                        help='Directory containing .pkl debug files')
    parser.add_argument('--port', '-p', type=int, default=5005,
                        help='Port for the web server (default: 5006)')
    parser.add_argument('--max-frames', '-n', type=int, default=500,
                        help='Max pkl files to load (default: 500)')
    args = parser.parse_args()

    if not os.path.isdir(args.input_dir):
        print(f"ERROR: Directory not found: {args.input_dir}")
        sys.exit(1)

    print(f"Loading pkl files from: {args.input_dir}")
    viewer = PklRewardViewer(args.input_dir, max_frames=args.max_frames)

    if not viewer.data_list:
        print("ERROR: No valid pkl files found!")
        sys.exit(1)

    print(f"Loaded {len(viewer.data_list)} frames")
    print(f"Statistics: {dict(viewer.stats)}")

    # Launch Panel web app
    pn.extension()
    template = pn.template.FastListTemplate(
        title="VLA No-Entry Reward Debug Viewer",
        main=[viewer.create_layout()],
        accent_base_color="#e53935",
        header_background="#c62828",
    )
    print(f"\nStarting web server at http://0.0.0.0:{args.port}")
    template.show(port=args.port)


if __name__ == '__main__':
    main()
