"""
Interactive visualization for VLA exit/no-entry evaluation results (JSONL + optional parquet).

Reads an inference_result.jsonl (optionally with a corresponding parquet file).
When parquet is provided: matches by clip_id, scores with vla_no_entry_v3_2,
and shows full BEV with freespace + reward info.
When parquet is omitted: visualizes predictions without scoring, using only
fields available in the JSONL (images, road network, trajectory, goal point).

Shows:
  - Camera images (FRONT, FRONT_NARROW, FRONT_LEFT, FRONT_RIGHT)
  - BEV view: road network, freespace (safe/unsafe/uncertain, with parquet),
    ego position, **predicted trajectory**, goal point, exit path roads
  - Reward info: score, reason, diff_score (with parquet)
  - Prediction text (action tokens)
  - Prompt and GT answer text

Usage:
  # With parquet (full scoring + freespace):
  python tools/tools_bj/visualize/visualize_eval_reward.py \
      /path/to/inference_result.jsonl \
      --parquet /path/to/corresponding.parquet

  # Without parquet (visualization only):
  python tools/tools_bj/visualize/visualize_eval_reward.py \
      /path/to/inference_result.jsonl

  # With defaults and custom port:
  python tools/tools_bj/visualize/visualize_eval_reward.py --port 5008 -n 300
"""

import argparse
import json
import os
import sys
from collections import Counter, defaultdict
from io import BytesIO
from base64 import b64encode

import concurrent.futures
from threading import Lock
from typing import Tuple, Optional
import numpy as np
import pandas as pd
import panel as pn

# ── Bokeh BEV ──
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..'))
from bokeh_wrapper.bokeh_fig import GenTopViewFigsGroup
from bokeh_wrapper.bokeh_base import (
    ArrowLayer, MultiLinesWithColorLayer, MultiPolygonLayer,
    PointsWithColorLayer, PointsLayer,
)

# ── Patch asyncio ──
try:
    import nest_asyncio
    nest_asyncio.apply()
except ImportError:
    pass

import cv2
from PIL import Image
from loguru import logger

if int(os.getenv("ON_TXSH", "0")):
    from niofs.read_cache_op_py import read_cache_op_py
    ON_TXSH = True
else:
    from read_cache_op_py import read_cache_op_py
    ON_TXSH = False

CACHE_AVAILABLE = True

_IMAGE_READ_EXECUTOR = concurrent.futures.ThreadPoolExecutor(max_workers=8)
_niofs_client = None
_size_cache = {}
_size_cache_lock = Lock()


# ═══════════════════════════════════════════════════════════════════════════════
#  Image reading utilities (same as visualize_parquet_reward.py)
# ═══════════════════════════════════════════════════════════════════════════════

def _get_niofs_client():
    global _niofs_client
    if _niofs_client is None:
        try:
            import niofs
        except ImportError:
            return None
        access_key = os.environ.get('LUSTRE_ACCESS_KEY', 'b89e365554ef75f8')
        secret_key = os.environ.get('LUSTRE_SECRET_KEY', '0910180b207f4edd9baaa030cf4a2902')
        try:
            _niofs_client = niofs.Client(access_key, secret_key, max_pool_connections=32)
        except Exception:
            return None
    return _niofs_client


def parse_niofs_path(path: str) -> Tuple[str, str]:
    path = path.strip()
    if not path:
        raise ValueError("Empty path")
    if path.startswith("s3://"):
        path = path[5:]
    elif path.startswith("s3:"):
        path = path[3:]
    elif path.startswith("huailai_cos:"):
        path = path[12:]
    path = path.lstrip("/")
    if "://" in path:
        parts = path.split("://", 1)
    elif ":" in path:
        parts = path.split(":", 1)
    elif "/" in path:
        parts = path.split("/", 1)
    else:
        raise ValueError(f"Invalid path format: {path}")
    return parts[0].strip(), parts[1].strip().lstrip("/")


def get_file_size(bucket: str, key: str, max_retries: int = 3) -> Optional[int]:
    cache_key = f"{bucket}/{key}"
    with _size_cache_lock:
        if cache_key in _size_cache:
            return _size_cache[cache_key]
    client = _get_niofs_client()
    if client is None:
        return None
    for attempt in range(max_retries):
        try:
            resp = client.head_object(Bucket=bucket, Key=key)
            size = resp.get("ContentLength", 0)
            if size > 0:
                with _size_cache_lock:
                    _size_cache[cache_key] = size
                return size
        except Exception:
            if attempt < max_retries - 1:
                import time
                time.sleep(0.1 * (attempt + 1))
    return None


def resolve_image_path_with_size(image_path: str) -> str:
    image_path = image_path.strip()
    clean_path = image_path
    for prefix in ('huailai_cos:', 's3://'):
        if clean_path.startswith(prefix):
            clean_path = clean_path[len(prefix):]
            break
    clean_path = '/' + clean_path.lstrip('/')
    parts = clean_path.rsplit(' ', 1)
    if len(parts) == 2 and parts[1].isdigit():
        return clean_path
    try:
        bucket, key = parse_niofs_path(image_path)
        size = get_file_size(bucket, key)
        if size is not None:
            return f"{clean_path} {size}"
    except Exception:
        pass
    return clean_path


def _cv2_to_data_url(cv2_image: np.ndarray) -> str:
    rgb = cv2.cvtColor(cv2_image, cv2.COLOR_BGR2RGB)
    image = Image.fromarray(rgb)
    output = BytesIO()
    image.save(output, format="WEBP", quality=80, method=0, optimize=True)
    b64_image = b64encode(output.getvalue()).decode("utf-8")
    return f"data:image/webp;base64,{b64_image}"


def _read_image_sync_raw(clean_url: str, read_ceph_kwargs: dict):
    raw_bytes_list = read_cache_op_py([clean_url], **read_ceph_kwargs)
    if raw_bytes_list and raw_bytes_list[0]:
        return raw_bytes_list[0]
    return None


def read_image_to_data_url(img_url: str, timeout: float = 30.0, vln_ocr_info=None, sensor_id=None) -> str:
    if not img_url or not CACHE_AVAILABLE:
        return ""
    clean_url = img_url.replace("huailai_cos:ad-cn-hlidc-multimodal", "/ad-cn-hlidc-multimodal")
    clean_url = resolve_image_path_with_size(clean_url)
    read_ceph_kwargs = {}
    if ON_TXSH:
        read_ceph_kwargs["mnt_point"] = "/lustre"
    try:
        future = _IMAGE_READ_EXECUTOR.submit(_read_image_sync_raw, clean_url, read_ceph_kwargs)
        raw_bytes = future.result(timeout=timeout)
    except Exception as e:
        logger.warning(f"Failed to read image {clean_url}: {e}")
        return ""
    if raw_bytes is None:
        return ""
    img_bgr = cv2.imdecode(np.frombuffer(raw_bytes, np.uint8), -1)
    if img_bgr is None:
        return ""
    if vln_ocr_info and sensor_id is not None:
        img_bgr = _draw_exit_ocr_boxes(img_bgr, vln_ocr_info, sensor_id)
    return _cv2_to_data_url(img_bgr)


def _draw_exit_ocr_boxes(img_bgr, vln_ocr_info, sensor_id):
    """Draw exit-sign OCR 2D boxes on image."""
    h, w = img_bgr.shape[:2]
    scale_x = w / 99.0
    scale_y = h / 99.0
    for ocr in vln_ocr_info:
        if ocr.get("sensor_id") != sensor_id:
            continue
        box = ocr.get("box", [])
        if not (isinstance(box, list) and len(box) == 4):
            continue
        has_exit = any("出口" in str(poi.get("poi_indication_info", ""))
                       for poi in ocr.get("poi_ocr_info", []))
        if not has_exit:
            continue
        x1 = int(box[0] * scale_x)
        y1 = int(box[1] * scale_y)
        x2 = int(box[2] * scale_x)
        y2 = int(box[3] * scale_y)
        cv2.rectangle(img_bgr, (x1, y1), (x2, y2), (0, 255, 0), thickness=4)
    return img_bgr


# ═══════════════════════════════════════════════════════════════════════════════
#  Reward / BEV helpers
# ═══════════════════════════════════════════════════════════════════════════════

ROT_BEV = np.array([[0, -1], [1, 0]])
BEV_SIZE_M = 60.0

ROAD_CLS_COLORS = {
    "normalRoad":              "#4caf50",
    "entryRoad":               "#81c784",
    "noEntryRoad":             "#e53935",
    "noEntryRoadBarrier":      "#b71c1c",
    "onlyRetrograde":          "#ff9800",
    "ArriveDeadEndRoad":       "#795548",
    "twoWayRoadNoEntry":       "#9c27b0",
    "twoWayRoadNoEntryBarrier":"#6a1b9a",
    "unknown":                 "#9e9e9e",
}
DEFAULT_ROAD_COLOR = "#9e9e9e"
EXIT_ROAD_COLOR = "#00e5ff"
FORBIDDEN_ROAD_CLASSES = {
    "noEntryRoad", "noEntryRoadBarrier", "ArriveDeadEndRoad", "onlyRetrograde",
}

# Trajectory colors for prediction (by reward outcome)
TRAJ_COLORS = {
    "exit_path_matched":       "#00e676",  # green — success
    "crash_into_wall":         "#ff1744",  # red — crash
    "no_exit_path_match":      "#ffab00",  # amber — no match
    "no_exit_path_road_ids":   "#9e9e9e",  # grey — no road ids
    "trajectory_too_short":    "#ff9100",  # orange
    "no_trajectory_parsed":    "#d50000",  # dark red
    "no_road_geometries":      "#78909c",  # blue-grey
}
DEFAULT_TRAJ_COLOR = "#ffffff"


def rot_to_bev(points):
    if points is None or len(points) == 0:
        return None
    return np.asarray(points, dtype=float) @ ROT_BEV.T


def decode_freespace_rle(rle):
    """Decode freespace RLE mask → polygon contours in BEV meter coords."""
    if not rle or "counts" not in rle or "size" not in rle:
        return [], []
    try:
        from pycocotools import mask as coco_mask
    except ImportError:
        return [], []
    counts = rle["counts"]
    if isinstance(counts, str):
        counts = counts.encode("utf-8")
    try:
        m = coco_mask.decode({"size": rle["size"], "counts": counts})
    except Exception:
        return [], []
    if not np.any(m):
        return [], []
    try:
        contours, _ = cv2.findContours(
            m.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    except Exception:
        return [], []
    h, w = rle["size"]
    scale = BEV_SIZE_M / w
    offset = BEV_SIZE_M / 2.0
    poly_xs, poly_ys = [], []
    for c in contours:
        if len(c) < 3:
            continue
        xs = c[:, 0, 0].astype(float) * scale - offset
        ys = offset - c[:, 0, 1].astype(float) * scale
        xs = np.append(xs, xs[0])
        ys = np.append(ys, ys[0])
        poly_xs.append(xs)
        poly_ys.append(ys)
    return poly_xs, poly_ys


def build_road_geoms_from_vla_construction(vla_road_construction_info):
    """vla_road_construction_info → {road_id: np.array([[x,y],...])}."""
    geoms = {}
    vla_road_info = vla_road_construction_info.get("vla_road_info", [])
    if isinstance(vla_road_info, list):
        for road in vla_road_info:
            road_id = road.get("road_link_id", "")
            way_points = road.get("road_way_point", [])
            if len(way_points) > 1:
                geo = np.array([[wp["point_x"], wp["point_y"]] for wp in way_points], dtype=float)
                geoms[road_id] = geo
    return geoms


def get_all_road_geometries(road_graphs):
    geoms = {}
    for rid, info in road_graphs.items():
        if info and "geometry" in info:
            g = np.array(info["geometry"], dtype=float)
            if len(g) >= 2:
                geoms[rid] = g
    return geoms


# ═══════════════════════════════════════════════════════════════════════════════
#  Data loader — JSONL + parquet matched by clip_id
# ═══════════════════════════════════════════════════════════════════════════════

def _load_jsonl_only(jsonl_path, max_frames=500):
    """Load JSONL predictions without parquet — visualization only, no scoring."""
    from verl.utils.reward_score.vla_no_entry_v3 import (
        parse_action_traj, action_traj_to_abs,
    )

    with open(jsonl_path) as f:
        jsonl_lines = [json.loads(line) for line in f]
    if max_frames and len(jsonl_lines) > max_frames:
        jsonl_lines = jsonl_lines[:max_frames]

    print(f"Loaded {len(jsonl_lines)} JSONL predictions (no parquet — scoring disabled)")

    rows = []
    for idx, d in enumerate(jsonl_lines):
        clip_id = d["clip_id"]
        pred = d.get("prediction", "")

        # Parse trajectory
        action_traj = parse_action_traj(pred)
        abs_traj = action_traj_to_abs(action_traj) if action_traj is not None else None

        # Extract what we can from JSONL
        images = d.get("image", {})
        if isinstance(images, dict):
            # JSONL image is dict like {'FRONT': [...], 'FRONT_NARROW': [...], ...}
            # Flatten to list for compatibility with parquet-based code
            img_list = []
            for cam in ["FRONT", "FRONT_NARROW", "FRONT_LEFT", "FRONT_RIGHT"]:
                cam_imgs = images.get(cam, [])
                if isinstance(cam_imgs, list):
                    img_list.extend(cam_imgs)
                elif cam_imgs:
                    img_list.append(cam_imgs)
            images = img_list
        elif not isinstance(images, list):
            images = []

        prompt_text = d.get("question", "")
        answer = d.get("answer", "")

        # JSONL fields (already dicts, not JSON strings)
        vla_road_construction_info = d.get("vla_road_construction_info", {})
        if isinstance(vla_road_construction_info, str):
            vla_road_construction_info = json.loads(vla_road_construction_info)
        vla_goal_point = d.get("vla_goal_point", {})
        if isinstance(vla_goal_point, str):
            vla_goal_point = json.loads(vla_goal_point)
        vln_ocr_info = d.get("vla_ocr_info", [])
        if isinstance(vln_ocr_info, str):
            vln_ocr_info = json.loads(vln_ocr_info)
        road_graphs = d.get("road_graphs", {})
        if isinstance(road_graphs, str):
            road_graphs = json.loads(road_graphs)
        select_road_ids = d.get("select_road_ids", [])
        if isinstance(select_road_ids, str):
            select_road_ids = json.loads(select_road_ids)
        select_road_cls = d.get("select_road_cls", [])
        if isinstance(select_road_cls, str):
            select_road_cls = json.loads(select_road_cls)
        ds_type = d.get("ds_type", "?")
        scene_info = d.get("scene_info", {})
        if isinstance(scene_info, dict):
            vln_ocr_info = scene_info.get("vln_ocr_info", vln_ocr_info)

        # Road geometries
        all_road_geoms = {}
        if vla_road_construction_info:
            all_road_geoms = build_road_geoms_from_vla_construction(vla_road_construction_info)
        if not all_road_geoms and road_graphs:
            all_road_geoms = get_all_road_geometries(road_graphs)

        road_id_to_cls = dict(zip(select_road_ids, select_road_cls)) if select_road_ids else {}
        forbidden_ids = {rid for rid, cls in zip(select_road_ids, select_road_cls)
                         if cls in FORBIDDEN_ROAD_CLASSES} if select_road_ids else set()

        # Parse all trajectories from extra.predictions
        extra = d.get("extra", {})
        predictions = extra.get("predictions", [])
        all_pred_trajs = []
        if predictions:
            for pred_text in predictions:
                traj = parse_action_traj(pred_text)
                abs_t = action_traj_to_abs(traj) if traj is not None else None
                if abs_t is not None and len(abs_t) > 0:
                    all_pred_trajs.append(abs_t)

        rows.append({
            "index": idx,
            "clip_id": clip_id,
            "frame_id": str(d.get("frame_id", "")),
            "prediction": pred,
            "action_traj": action_traj,
            "abs_traj": abs_traj,
            # No scoring
            "score": None,
            "reason": "no_parquet",
            "diff_score": [],
            "details": {},
            # From JSONL
            "images": images,
            "prompt_text": prompt_text,
            "answer": answer,
            "question": prompt_text,
            "extra_info": {},
            "ds_type": ds_type,
            "freespace_info": {},
            "vla_goal_point": vla_goal_point,
            "has_exit_sign": False,
            "vla_road_construction_info": vla_road_construction_info,
            "exit_path_road_ids": set(),
            "road_graphs": road_graphs,
            "select_road_ids": select_road_ids,
            "select_road_cls": select_road_cls,
            "road_id_to_cls": road_id_to_cls,
            "forbidden_ids": forbidden_ids,
            "all_road_geoms": all_road_geoms,
            "vln_ocr_info": vln_ocr_info,
            "all_pred_trajs": all_pred_trajs,
        })

    return rows


def load_eval_data(jsonl_path, parquet_path=None, max_frames=500):
    """Load JSONL predictions, optionally match with parquet extra_info and score.

    Args:
        jsonl_path: path to inference_result.jsonl
        parquet_path: path to corresponding parquet (optional).
                      If None, loads JSONL-only without scoring.
        max_frames: max predictions to load

    Returns list of row dicts, each representing one prediction.
    """
    if parquet_path is None or not os.path.exists(parquet_path):
        if parquet_path is not None:
            print(f"Parquet not found: {parquet_path}, falling back to JSONL-only mode")
        return _load_jsonl_only(jsonl_path, max_frames)

    from verl.utils.reward_score.vla_no_entry_v3_2 import TaskVLANoEntryRewardV32
    from verl.utils.reward_score.vla_no_entry_v3 import (
        parse_action_traj, action_traj_to_abs, BINDING_MIN_POINTS,
    )

    # Load parquet → (clip_id, frame_ts) → extra_info + images/prompt
    import re
    df = pd.read_parquet(parquet_path)
    clip_info = {}
    for i in range(len(df)):
        row = df.iloc[i]
        ei = row["extra_info"]
        cid = ei["clip_id"]
        images = row.get("image", [])
        if hasattr(images, "tolist"):
            images = images.tolist()
        # Extract first FW image timestamp as frame identifier
        fw_ts = None
        for img in images:
            s = str(img)
            if '/FW/' in s:
                m = re.search(r'/(\d{10}\.\d+)\.jpg', s)
                if m:
                    fw_ts = m.group(1)
                    break
        key = (cid, fw_ts)
        prompt_list = row.get("prompt", [])
        if hasattr(prompt_list, "tolist"):
            prompt_list = prompt_list.tolist()
        prompt_text = ""
        if isinstance(prompt_list, list) and len(prompt_list) > 0:
            prompt_text = prompt_list[0].get("content", "") if isinstance(
                prompt_list[0], dict) else str(prompt_list)
        clip_info[key] = {
            "extra_info": ei,
            "images": images,
            "prompt_text": prompt_text,
            "answer": ei.get("answer", ""),
            "question": ei.get("question", ""),
        }

    # Load JSONL
    with open(jsonl_path) as f:
        jsonl_lines = [json.loads(line) for line in f]

    if max_frames and len(jsonl_lines) > max_frames:
        jsonl_lines = jsonl_lines[:max_frames]

    print(f"Loaded {len(df)} parquet rows, {len(jsonl_lines)} JSONL predictions")

    # Score and build rows
    scorer = TaskVLANoEntryRewardV32(debug=False)
    rows = []
    missing = 0

    for idx, d in enumerate(jsonl_lines):
        clip_id = d["clip_id"]
        frame_id = str(d.get("frame_id", ""))
        pred = d.get("prediction", "")
        # Match by (clip_id, frame_id).  The JSONL frame_id is a timestamp
        # that should match the first FW image timestamp in the parquet.
        # Try exact string match first; handle floating-point precision diff
        # (e.g. JSONL "1774795426.53925" vs parquet "1774795426.539250").
        key = (clip_id, frame_id)
        info = clip_info.get(key)
        if info is None and frame_id:
            # Fallback: normalize to 6 decimal places
            import re as _re
            try:
                fval = float(frame_id)
                normalized = f"{fval:.6f}"
                for (cid2, fw_ts2), info2 in clip_info.items():
                    if cid2 == clip_id and fw_ts2:
                        try:
                            if abs(float(fw_ts2) - fval) < 1e-5:
                                info = info2
                                break
                        except ValueError:
                            pass
            except ValueError:
                pass
        if info is None:
            missing += 1
            continue

        ei = info["extra_info"]
        result = scorer(clip_id, pred, [], ei)

        # Parse trajectory
        from verl.utils.reward_score.vla_no_entry_v3 import (
            parse_action_traj, action_traj_to_abs,
        )
        action_traj = parse_action_traj(pred)
        abs_traj = action_traj_to_abs(action_traj) if action_traj is not None else None

        # Extract reward kwargs for visualization
        kwargs = (ei.get("tools_kwargs", {})
                   .get("calc_no-entry_reward", {})
                   .get("calc_reward_kwargs", {}))

        freespace_info = json.loads(kwargs.get("freespace_info", "{}") or "{}")
        vla_goal_point = json.loads(kwargs.get("vla_goal_point", "{}") or "{}")
        has_exit_sign = json.loads(kwargs.get("has_exit_sign", "false") or "false")
        vla_road_construction_info = json.loads(kwargs.get("vla_road_construction_info", "{}") or "{}")
        exit_path_road_ids = set(json.loads(kwargs.get("exit_path_road_ids", "[]") or "[]"))
        road_graphs = json.loads(kwargs.get("road_graphs", "{}") or "{}")
        select_road_ids = json.loads(kwargs.get("select_road_ids", "[]") or "[]")
        select_road_cls = json.loads(kwargs.get("select_road_cls", "[]") or "[]")
        vln_ocr_info = json.loads(kwargs.get("vln_ocr_info", "[]") or "[]")
        ds_type = ei.get("ds_type", "no_entry")

        # Road geometries (prefer vla_road_construction_info for exit, road_graphs for no_entry)
        all_road_geoms = {}
        if vla_road_construction_info:
            all_road_geoms = build_road_geoms_from_vla_construction(vla_road_construction_info)
        if not all_road_geoms and road_graphs:
            all_road_geoms = get_all_road_geometries(road_graphs)

        road_id_to_cls = dict(zip(select_road_ids, select_road_cls))
        forbidden_ids = {rid for rid, cls in zip(select_road_ids, select_road_cls)
                         if cls in FORBIDDEN_ROAD_CLASSES}

        # Parse all trajectories from extra.predictions (from JSONL line)
        extra = d.get("extra", {})
        predictions = extra.get("predictions", [])
        all_pred_trajs = []
        if predictions:
            for pred_text in predictions:
                traj = parse_action_traj(pred_text)
                abs_t = action_traj_to_abs(traj) if traj is not None else None
                if abs_t is not None and len(abs_t) > 0:
                    all_pred_trajs.append(abs_t)

        rows.append({
            "index": idx,
            "clip_id": clip_id,
            "frame_id": str(d.get("frame_id", "")),
            "prediction": pred,
            "action_traj": action_traj,
            "abs_traj": abs_traj,
            "score": result["score"],
            "reason": result.get("reason", "unknown"),
            "diff_score": result.get("diff_score", []),
            "details": result.get("details", {}),
            # Visual info from parquet
            "images": info["images"],
            "prompt_text": info["prompt_text"],
            "answer": info["answer"],
            "question": info["question"],
            "extra_info": ei,
            "ds_type": ds_type,
            # Reward kwargs
            "freespace_info": freespace_info,
            "vla_goal_point": vla_goal_point,
            "has_exit_sign": has_exit_sign,
            "vla_road_construction_info": vla_road_construction_info,
            "exit_path_road_ids": exit_path_road_ids,
            "road_graphs": road_graphs,
            "select_road_ids": select_road_ids,
            "select_road_cls": select_road_cls,
            "road_id_to_cls": road_id_to_cls,
            "forbidden_ids": forbidden_ids,
            "all_road_geoms": all_road_geoms,
            "vln_ocr_info": vln_ocr_info,
            "all_pred_trajs": all_pred_trajs,
        })

    print(f"Matched: {len(rows)} scored, missing clip_id: {missing}")
    return rows


# ═══════════════════════════════════════════════════════════════════════════════
#  Panel UI
# ═══════════════════════════════════════════════════════════════════════════════

class EvalRewardViewer:
    """Interactive Panel app for browsing evaluation results with reward scores."""

    def __init__(self, jsonl_path, parquet_path=None, max_frames=500):
        self.has_parquet = parquet_path is not None and os.path.exists(parquet_path)
        self.all_rows = load_eval_data(jsonl_path, parquet_path, max_frames=max_frames)
        self.rows = list(self.all_rows)  # filtered subset, initially all
        self.current_index = 0
        if not self.all_rows:
            print("ERROR: No rows loaded!")
            return

        self._image_cache = {}
        self._setup_bokeh_bev()
        self._compute_stats()
        self._setup_widgets()

    def _setup_bokeh_bev(self):
        """Create bokeh BEV figure and overlay layers."""
        self.bev_fig = GenTopViewFigsGroup({
            "BEV": {'size': [600, 600], 'x_label': 'x (m)', 'y_label': 'y (m)'},
        })
        self.bev_fig.legend.click_policy = "hide"

        # Freespace layers
        self.bev_safe_lyr = MultiPolygonLayer(
            self.bev_fig, {'legend_label': 'safe', 'line_color': 'green',
                           'fill_color': 'green', 'line_width': 1, 'alpha': 0.5, 'fill_alpha': 0.10})
        self.bev_unsafe_lyr = MultiPolygonLayer(
            self.bev_fig, {'legend_label': 'unsafe', 'line_color': 'red',
                           'fill_color': 'red', 'line_width': 1, 'alpha': 0.6, 'fill_alpha': 0.18})
        self.bev_uncertain_lyr = MultiPolygonLayer(
            self.bev_fig, {'legend_label': 'uncertain', 'line_color': 'orange',
                           'fill_color': 'orange', 'line_width': 1, 'alpha': 0.6, 'fill_alpha': 0.10})

        # Road layers
        self.bev_road_lyr = MultiLinesWithColorLayer(
            self.bev_fig, {'legend_label': 'roads', 'line_width': 2, 'alpha': 0.8})
        self.bev_exit_road_lyr = MultiLinesWithColorLayer(
            self.bev_fig, {'legend_label': 'exit roads', 'line_width': 5, 'alpha': 0.95})

        # Markers
        self.bev_ego_lyr = PointsLayer(
            self.bev_fig, {'legend_label': 'ego', 'size': 12, 'marker': 'circle',
                           'color': 'yellow', 'alpha': 1.0})
        self.bev_goal_lyr = PointsLayer(
            self.bev_fig, {'legend_label': 'goal point', 'size': 16, 'marker': 'star',
                           'color': 'lime', 'alpha': 1.0})
        self.bev_goal_arrow = ArrowLayer(self.bev_fig, {})

        # ── Predicted trajectory (key addition) ──
        self.bev_pred_line_lyr = MultiLinesWithColorLayer(
            self.bev_fig, {'legend_label': 'pred traj', 'line_width': 3, 'alpha': 0.95})
        self.bev_pred_pts_lyr = PointsWithColorLayer(
            self.bev_fig, {'legend_label': 'pred pts', 'size': 8, 'marker': 'circle', 'alpha': 0.9})

        # GT trajectory
        self.bev_gt_line_lyr = MultiLinesWithColorLayer(
            self.bev_fig, {'legend_label': 'GT traj', 'line_width': 2, 'alpha': 0.7})
        self.bev_gt_pts_lyr = PointsWithColorLayer(
            self.bev_fig, {'legend_label': 'GT pts', 'size': 5, 'marker': 'circle', 'alpha': 0.7})

        # All prediction trajectories (from extra.predictions)
        self.bev_all_pred_lines_lyr = MultiLinesWithColorLayer(
            self.bev_fig, {'legend_label': 'all preds', 'line_width': 2, 'alpha': 0.7})
        self.bev_all_pred_pts_lyr = PointsWithColorLayer(
            self.bev_fig, {'legend_label': 'all pred pts', 'size': 5, 'marker': 'circle', 'alpha': 0.6})

    def _build_bev_display(self, r):
        """Update all BEV layers from a row dict."""
        all_road_geoms = r.get("all_road_geoms", {})
        road_id_to_cls = r.get("road_id_to_cls", {})
        forbidden_ids = r.get("forbidden_ids", set())
        freespace_info = r.get("freespace_info", {})
        vla_goal_point = r.get("vla_goal_point", {})
        exit_path_road_ids = r.get("exit_path_road_ids", set())
        vla_road_construction_info = r.get("vla_road_construction_info", {})
        abs_traj = r.get("abs_traj")
        reason = r.get("reason", "unknown")

        # ── Freespace ──
        for key, layer in [('safe', self.bev_safe_lyr),
                           ('unsafe', self.bev_unsafe_lyr),
                           ('uncertain', self.bev_uncertain_lyr)]:
            rle = freespace_info.get(key) if freespace_info else None
            poly_xs, poly_ys = decode_freespace_rle(rle)
            if poly_xs:
                layer.update([[poly_xs]], [[poly_ys]])
            else:
                layer.update([], [])

        # ── Road geometries ──
        road_xs, road_ys, road_colors, road_types = [], [], [], []
        exit_xs, exit_ys = [], []

        if isinstance(vla_road_construction_info, dict) and vla_road_construction_info:
            # Exit data: use vla_road_construction_info
            vla_road_info = vla_road_construction_info.get("vla_road_info", [])
            if isinstance(vla_road_info, list):
                for road in vla_road_info:
                    road_id = road.get("road_link_id", "")
                    way_points = road.get("road_way_point", [])
                    if len(way_points) > 1:
                        geo = np.array([[wp["point_x"], wp["point_y"]] for wp in way_points])
                        pts_bev = rot_to_bev(geo)
                        xl, yl = pts_bev[:, 0].tolist(), pts_bev[:, 1].tolist()
                        if road_id in exit_path_road_ids:
                            exit_xs.append(xl); exit_ys.append(yl)
                        else:
                            cls = road_id_to_cls.get(road_id, "unknown")
                            road_xs.append(xl); road_ys.append(yl)
                            road_colors.append(ROAD_CLS_COLORS.get(cls, DEFAULT_ROAD_COLOR))
                            road_types.append("dashed" if road_id in forbidden_ids else "solid")
        elif all_road_geoms:
            # No-entry data: use road_graphs
            for road_id, geom in all_road_geoms.items():
                if len(geom) < 2:
                    continue
                pts_bev = rot_to_bev(np.array(geom))
                xl, yl = pts_bev[:, 0].tolist(), pts_bev[:, 1].tolist()
                cls = road_id_to_cls.get(road_id, "unknown")
                road_xs.append(xl); road_ys.append(yl)
                road_colors.append(ROAD_CLS_COLORS.get(cls, DEFAULT_ROAD_COLOR))
                road_types.append("dashed" if road_id in forbidden_ids else "solid")

        self.bev_road_lyr.update(road_xs, road_ys, road_colors, road_types)
        self.bev_exit_road_lyr.update(exit_xs, exit_ys,
                                       [EXIT_ROAD_COLOR] * len(exit_xs),
                                       ["solid"] * len(exit_xs))

        # ── Ego ──
        self.bev_ego_lyr.update([0.0], [0.0])

        # ── Goal point + arrow ──
        if vla_goal_point and vla_goal_point.get("point_x") is not None:
            gx, gy, gyaw = (vla_goal_point["point_x"],
                           vla_goal_point["point_y"],
                           vla_goal_point.get("yaw", 0))
            g_bev = rot_to_bev(np.array([[gx, gy]]))
            self.bev_goal_lyr.update([float(g_bev[0, 0])], [float(g_bev[0, 1])])
            arrow_len = 3.0
            gx_end = gx + arrow_len * np.cos(gyaw)
            gy_end = gy + arrow_len * np.sin(gyaw)
            arrow_bev = rot_to_bev(np.array([[gx, gy], [gx_end, gy_end]]))
            self.bev_goal_arrow.update(
                float(arrow_bev[0, 0]), float(arrow_bev[0, 1]),
                float(arrow_bev[1, 0]), float(arrow_bev[1, 1]))
        else:
            self.bev_goal_lyr.update([], [])
            self.bev_goal_arrow.update(0, 0, 0, 0)

        # ── Predicted trajectory (color-coded by reward reason) ──
        if abs_traj is not None and len(abs_traj) > 0:
            origin = np.array([[0.0, 0.0]])
            full_traj = np.vstack([origin, abs_traj[:20]])
            traj_bev = rot_to_bev(full_traj)
            traj_color = TRAJ_COLORS.get(reason, DEFAULT_TRAJ_COLOR)
            self.bev_pred_line_lyr.update(
                [traj_bev[:, 0].tolist()], [traj_bev[:, 1].tolist()],
                [traj_color], ["solid"])
            n_pts = len(traj_bev)
            pt_colors = [traj_color] * n_pts
            pt_colors[0] = "#ffff00"  # origin in yellow
            self.bev_pred_pts_lyr.update(
                traj_bev[:, 0].tolist(), traj_bev[:, 1].tolist(), pt_colors)
        else:
            self.bev_pred_line_lyr.update([], [], [], [])
            self.bev_pred_pts_lyr.update([], [], [])

        # ── All prediction trajectories (from extra.predictions) ──
        all_pred_trajs = r.get("all_pred_trajs", [])
        if all_pred_trajs:
            # High-contrast palette for distinguishing multiple trajectories
            ALL_PRED_COLORS = [
                "#00e5ff",  # cyan
                "#ff4081",  # pink
                "#ff9100",  # orange
                "#c6ff00",  # lime
                "#e040fb",  # magenta
                "#40c4ff",  # light blue
                "#ff6e40",  # deep orange
                "#69f0ae",  # mint
            ]
            all_xs, all_ys, all_colors = [], [], []
            all_pt_xs, all_pt_ys, all_pt_colors = [], [], []
            for i, pred_traj in enumerate(all_pred_trajs):
                origin = np.array([[0.0, 0.0]])
                full_traj = np.vstack([origin, pred_traj[:20]])
                traj_bev = rot_to_bev(full_traj)
                traj_color = ALL_PRED_COLORS[i % len(ALL_PRED_COLORS)]
                all_xs.append(traj_bev[:, 0].tolist())
                all_ys.append(traj_bev[:, 1].tolist())
                all_colors.append(traj_color)
                n_pts = len(traj_bev)
                all_pt_xs.extend(traj_bev[:, 0].tolist())
                all_pt_ys.extend(traj_bev[:, 1].tolist())
                all_pt_colors.extend([traj_color] * n_pts)
            self.bev_all_pred_lines_lyr.update(all_xs, all_ys, all_colors,
                                                ["dashed"] * len(all_xs))
            self.bev_all_pred_pts_lyr.update(all_pt_xs, all_pt_ys, all_pt_colors)
        else:
            self.bev_all_pred_lines_lyr.update([], [], [], [])
            self.bev_all_pred_pts_lyr.update([], [], [])

        # ── GT trajectory (if available) ──
        gt_trajs = r["extra_info"].get("gt_ego_fut_trajs")
        if gt_trajs is not None and hasattr(gt_trajs, "__len__") and len(gt_trajs) > 0:
            if hasattr(gt_trajs, "tolist"):
                gt_trajs = gt_trajs.tolist()
            traj = np.cumsum(np.array(gt_trajs, dtype=float), axis=0)
            traj_bev = rot_to_bev(traj)
            self.bev_gt_line_lyr.update(
                [traj_bev[:, 0].tolist()], [traj_bev[:, 1].tolist()],
                ['#ffffff'], ['dotted'])
            self.bev_gt_pts_lyr.update(
                traj_bev[:, 0].tolist(), traj_bev[:, 1].tolist(),
                ['#ffffff'] * len(traj_bev))
        else:
            self.bev_gt_line_lyr.update([], [], [], [])
            self.bev_gt_pts_lyr.update([], [], [])

    def _compute_stats(self):
        """Compute score distribution statistics (over all data, not filtered)."""
        self.stats = {
            "total": len(self.all_rows),
            "score_dist": Counter(),
            "reason_dist": Counter(),
            "crash_breakdown": Counter(),
            "ds_type_dist": Counter(),
        }
        scores = []
        for r in self.all_rows:
            self.stats["score_dist"][r["score"]] += 1
            self.stats["reason_dist"][r["reason"]] += 1
            self.stats["ds_type_dist"][r.get("ds_type", "?")] += 1
            scores.append(r["score"])
            if r["reason"] == "crash_into_wall":
                n_unsafe = r["details"].get("num_unsafe", 0)
                self.stats["crash_breakdown"][f"{n_unsafe} unsafe pts"] += 1
        if scores:
            self.stats["mean"] = np.mean(scores)
            self.stats["median"] = np.median(scores)
            self.stats["std"] = np.std(scores)

    def _setup_widgets(self):
        max_idx = max(0, len(self.rows) - 1)

        # Group by clip_id across ALL data (for "pred X of Y in this clip" display)
        self.clip_groups = defaultdict(list)
        for i, r in enumerate(self.all_rows):
            self.clip_groups[r["clip_id"]].append(r["index"])

        self.slider = pn.widgets.IntSlider(
            name="Prediction", start=0, end=max_idx, value=0, width=500)
        self.slider.param.watch(self._on_slider_change, "value")

        self.prev_btn = pn.widgets.Button(name="◀ Prev", button_type="primary", width=80)
        self.next_btn = pn.widgets.Button(name="Next ▶", button_type="primary", width=80)
        self.prev_btn.on_click(self._prev)
        self.next_btn.on_click(self._next)

        self.jump_input = pn.widgets.IntInput(
            name="Jump", value=1, start=1, end=max(1, len(self.rows)), width=80)
        self.jump_btn = pn.widgets.Button(name="Go", button_type="primary", width=45)
        self.jump_btn.on_click(self._jump)

        # Filter by reason
        reasons = sorted(self.stats["reason_dist"].keys())
        self.filter_reason = pn.widgets.MultiChoice(
            name="Filter by reason", options=reasons, value=reasons, width=400)
        self.filter_reason.param.watch(lambda e: self._apply_filters(), "value")

        # Filter by score
        self.filter_score_min = pn.widgets.FloatInput(name="Score ≥", value=-10.0, width=80)
        self.filter_score_max = pn.widgets.FloatInput(name="Score ≤", value=10.0, width=80)
        self.filter_score_min.param.watch(lambda e: self._apply_filters(), "value")
        self.filter_score_max.param.watch(lambda e: self._apply_filters(), "value")

        # Image panes
        self.img_fw = pn.pane.HTML("", width=481, height=271)
        self.img_fn = pn.pane.HTML("", width=481, height=271)
        self.img_fl = pn.pane.HTML("", width=481, height=271)
        self.img_fr = pn.pane.HTML("", width=481, height=271)

        # Info panes
        self.info_pane = pn.pane.Markdown("", sizing_mode="stretch_width")
        self.stats_pane = pn.pane.Markdown("", sizing_mode="stretch_width")
        self.bev_pane = pn.pane.Bokeh(self.bev_fig, width=620, height=620)
        self.prompt_pane = pn.pane.Markdown("", sizing_mode="stretch_width")

        self._apply_filters()

    def _apply_filters(self):
        reasons = set(self.filter_reason.value)
        smin = self.filter_score_min.value
        smax = self.filter_score_max.value
        self.rows = [
            r for r in self.all_rows
            if r["reason"] in reasons and smin <= r["score"] <= smax
        ]
        # Reset slider range
        new_max = max(0, len(self.rows) - 1)
        self.slider.end = new_max
        self.jump_input.end = max(1, len(self.rows))
        # Clamp current index
        if self.rows:
            self.current_index = min(self.current_index, new_max)
            self.slider.value = self.current_index
        self.update_display()

    def _on_slider_change(self, event):
        self.current_index = event.new
        self.update_display()

    def _prev(self, event):
        if not self.rows:
            return
        self.current_index = max(0, self.current_index - 1)
        self.slider.value = self.current_index

    def _next(self, event):
        if not self.rows:
            return
        self.current_index = min(len(self.rows) - 1, self.current_index + 1)
        self.slider.value = self.current_index

    def _jump(self, event):
        if not self.rows:
            return
        t = self.jump_input.value - 1
        self.current_index = max(0, min(len(self.rows) - 1, t))
        self.slider.value = self.current_index

    def _load_images(self, r):
        # Cache by clip_id since all predictions for the same clip share images
        cache_key = r["clip_id"]
        if cache_key in self._image_cache:
            return self._image_cache[cache_key]

        images = r.get("images", [])
        vln_ocr_info = r.get("vln_ocr_info", [])
        cam_tokens = ["/FW/", "/FN/", "/FL/", "/FR/"]
        cam_names = ["FRONT", "FRONT_NARROW", "FRONT_LEFT", "FRONT_RIGHT"]
        sensor_ids = [0, 1, 2, 3]
        urls = {}
        for cam, token, sid in zip(cam_names, cam_tokens, sensor_ids):
            found = ""
            for img in images:
                if token in str(img):
                    found = str(img)
                    break
            if found:
                urls[cam] = read_image_to_data_url(found, vln_ocr_info=vln_ocr_info, sensor_id=sid)
            else:
                urls[cam] = ""
        self._image_cache[cache_key] = urls
        return urls

    def _build_info_md(self, r):
        score = r["score"]
        reason = r["reason"]
        diff = r.get("diff_score", [])
        details = r.get("details", {})
        clip_id = r["clip_id"]
        ds_type = r.get("ds_type", "?")
        has_exit = "✓" if r["has_exit_sign"] else "✗"
        vgp = r["vla_goal_point"]
        exit_ids = r["exit_path_road_ids"]
        forbidden_ids = r["forbidden_ids"]
        road_id_to_cls = r["road_id_to_cls"]
        all_road_geoms = r.get("all_road_geoms", {})

        # Score badge color
        if score is None:
            score_color = "#9e9e9e"
            score_str = "N/A"
            reason_display = "(no parquet — scoring disabled)"
            traj_color = "#ffffff"
        else:
            if score > 0:
                score_color = "#00e676"
            elif score == 0:
                score_color = "#ffab00"
            else:
                score_color = "#ff1744"
            score_str = f"{score:+.1f}"
            reason_display = reason
            traj_color = TRAJ_COLORS.get(reason, DEFAULT_TRAJ_COLOR)

        vgp_str = (f"({vgp.get('point_x', 0):.1f}, {vgp.get('point_y', 0):.1f}) "
                   f"yaw={np.degrees(vgp.get('yaw', 0)):.1f}°") if vgp and vgp.get("point_x") else "N/A"

        exit_ids_str = ", ".join(sorted(exit_ids)) if exit_ids else "(none)"
        fb_str = ", ".join(
            f"{rid}({road_id_to_cls.get(rid, '?')})" for rid in sorted(forbidden_ids)
        ) if forbidden_ids else "(none)"

        # Pred trajectory preview
        pred_text = r["prediction"]
        pred_preview = pred_text[:200] if len(pred_text) > 200 else pred_text

        # Details sub-table
        detail_lines = []
        for k, v in details.items():
            if isinstance(v, (str, int, float, bool)):
                detail_lines.append(f"| {k} | {v} |")
        detail_md = "\n".join(detail_lines) if detail_lines else "*(none)*"

        total = len(self.all_rows)
        # Count predictions for this clip_id (across all data)
        same_clip = self.clip_groups.get(clip_id, [])
        clip_pos = same_clip.index(r["index"]) + 1 if r["index"] in same_clip else "?"

        # Mode badge
        mode_badge = "🟢 Full (parquet)" if self.has_parquet else "🟡 Viz-only (no parquet)"

        return f"""
# Pred #{r['index'] + 1} / {total}  |  Clip: `{clip_id}`  frame=`{r.get('frame_id', '?')[:14]}`  (pred {clip_pos}/{len(same_clip)})

**Mode**: {mode_badge}

| Field | Value |
|-------|-------|
| **Score** | <span style="color:{score_color};font-size:1.4em;font-weight:bold">{score_str}</span> |
| **Reason** | <span style="color:{traj_color};font-weight:bold">{reason_display}</span> |
| **Diff Score** | `{diff}` |
| **DS Type** | `{ds_type}` |
| **Has Exit Sign** | {has_exit} |
| **Exit Path Road IDs** | {exit_ids_str} |
| **Forbidden Roads** | {fb_str} |
| **Goal Point** | {vgp_str} |
| **Road Geoms** | {len(all_road_geoms)} roads |
| **Extra Preds** | {len(r.get('all_pred_trajs', []))} trajectories |

### Details

{detail_md}

### Predicted Trajectory

```text
{pred_preview}
```
"""

    def _build_stats_md(self):
        s = self.stats
        total = s["total"]
        vis = len(self.rows)
        mode_label = "📊 Full (parquet)" if self.has_parquet else "📋 Viz-only (no parquet)"
        lines = [
            f"## Score Distribution  — {mode_label}\n",
            f"**Total**: {total}  |  **Visible**: {vis}\n",
        ]

        if self.has_parquet:
            lines.append(f"**Mean**: {s.get('mean', 0):.3f}  |  **Median**: {s.get('median', 0):.3f}  |  **Std**: {s.get('std', 0):.3f}\n")

        # Score histogram
        if s["score_dist"]:
            lines.append("### Score Values\n")
            lines.append("| Score | Count | % |")
            lines.append("|-------|-------|---|")
            for score_val in sorted(s["score_dist"].keys()):
                cnt = s["score_dist"][score_val]
                if score_val is None:
                    lines.append(f"| N/A | {cnt} | {100*cnt/total:.1f}% |")
                else:
                    lines.append(f"| {score_val:>+.1f} | {cnt} | {100*cnt/total:.1f}% |")

        # Reason distribution
        if s["reason_dist"]:
            lines.append("\n### Reason Distribution\n")
            lines.append("| Reason | Count | % |")
            lines.append("|--------|-------|---|")
            for reason, cnt in s["reason_dist"].most_common():
                lines.append(f"| {reason} | {cnt} | {100*cnt/total:.1f}% |")

        # Crash breakdown
        if s["crash_breakdown"]:
            lines.append("\n### Wall Crash Breakdown\n")
            lines.append("| Unsafe Points | Count |")
            lines.append("|---------------|-------|")
            for k, cnt in sorted(s["crash_breakdown"].items()):
                lines.append(f"| {k} | {cnt} |")

        if not self.has_parquet:
            lines.append("\n> ⚠️ No parquet provided — scoring and freespace display are disabled.")
            lines.append("> Add `--parquet <path>` for full reward scoring + BEV freespace.")

        return "\n".join(lines)

    def _build_prompt_md(self, r):
        prompt = r.get("prompt_text", "")
        answer = r.get("answer", "")
        preview_p = prompt[:1200] if prompt else "(empty)"
        preview_a = answer[:600] if answer else "(empty)"
        return f"""
### Prompt ({len(prompt)} chars)

<details open>
<summary>Preview</summary>

```text
{preview_p}
```
</details>

---

### GT Answer ({len(answer)} chars)

```text
{preview_a}
```
"""

    def update_display(self):
        if not self.rows:
            self.info_pane.object = "**No data**"
            self.stats_pane.object = self._build_stats_md()
            return

        r = self.rows[self.current_index]

        # Images
        img_urls = self._load_images(r)
        cam_panes = {
            "FRONT": self.img_fw, "FRONT_NARROW": self.img_fn,
            "FRONT_LEFT": self.img_fl, "FRONT_RIGHT": self.img_fr,
        }
        for cam, pane in cam_panes.items():
            url = img_urls.get(cam, "")
            if url:
                pane.object = (
                    f'<div style="text-align:center;font-size:11px;font-weight:bold;'
                    f'margin-bottom:2px">{cam}</div>'
                    f'<img src="{url}" style="width:100%;border:1px solid #ccc;'
                    f'border-radius:4px" />'
                )
            else:
                pane.object = (
                    f'<div style="text-align:center;font-size:11px;font-weight:bold;'
                    f'margin-bottom:2px">{cam}</div>'
                    f'<div style="width:481px;height:271px;background:#eee;'
                    f'text-align:center;line-height:271px;color:#999">no image</div>'
                )

        # Info
        self.info_pane.object = self._build_info_md(r)

        # BEV
        try:
            self._build_bev_display(r)
        except Exception as e:
            import traceback
            traceback.print_exc()

        # Prompt/Answer
        self.prompt_pane.object = self._build_prompt_md(r)

        # Stats
        self.stats_pane.object = self._build_stats_md()

    def layout(self):
        nav = pn.Row(
            self.prev_btn, self.slider, self.next_btn,
            pn.Spacer(width=10), self.jump_input, self.jump_btn,
            styles={"background": "#ecf0f1", "padding": "10px",
                    "border-radius": "5px", "margin-bottom": "6px"},
        )
        filt = pn.Row(
            pn.pane.Markdown("**Filter:**", width=55),
            self.filter_reason,
            pn.Spacer(width=20),
            pn.pane.Markdown("Score:", width=45),
            self.filter_score_min, self.filter_score_max,
            styles={"background": "#fff3e0", "padding": "6px 10px",
                    "border-radius": "5px", "margin-bottom": "8px"},
        )

        img_grid = pn.Column(
            pn.Row(self.img_fw, self.img_fn),
            pn.Row(self.img_fl, self.img_fr),
        )

        left = pn.Column(
            img_grid, self.prompt_pane,
            width=1000, sizing_mode="stretch_height",
        )
        middle = pn.Column(
            self.info_pane,
            self.stats_pane,
            width=480,
        )
        right = pn.Column(
            pn.pane.Markdown("### BEV View"),
            self.bev_pane,
            width=660,
        )

        return pn.Column(
            nav, filt, pn.layout.Divider(),
            pn.Row(left, middle, right, align="start"),
            sizing_mode="stretch_width",
        )


# ═══════════════════════════════════════════════════════════════════════════════
#  Main
# ═══════════════════════════════════════════════════════════════════════════════

INFERENCE_BASE = "/perception-hl/beijin.zhou/action_model_output/0612_17w_1Wpseudo_cot_multi-20260612-215425"
PARQUET_BASE = "/perception-hl/beijin.zhou/deeprl/260701_rl_exit_data"
DEFAULT_DATASET = "vln2_cotv3_UG_PARKING_EXIT_20260701_0534_part0000"


def _auto_parquet_path(jsonl_path):
    """Try to infer parquet path from JSONL path by matching dataset name."""
    jsonl_dir = os.path.dirname(jsonl_path)
    ds_name = os.path.basename(jsonl_dir)
    candidate = os.path.join(PARQUET_BASE, f"{ds_name}.parquet")
    if os.path.exists(candidate):
        return candidate
    # Try without part suffix
    import re
    m = re.match(r"(.+_part\d+)", ds_name)
    if m:
        candidate = os.path.join(PARQUET_BASE, f"{m.group(1)}.parquet")
        if os.path.exists(candidate):
            return candidate
    return None


def main():
    parser = argparse.ArgumentParser(
        description="Visualize VLA exit/no-entry evaluation results (JSONL + optional parquet)")
    parser.add_argument(
        "jsonl_path", nargs="?",
        default=os.path.join(INFERENCE_BASE, DEFAULT_DATASET, "inference_result_T0.7_N8.jsonl"),
        help=f"Path to inference_result.jsonl (default: .../{DEFAULT_DATASET}/inference_result.jsonl)")
    parser.add_argument(
        "--parquet", "-q", type=str, default=None,
        help="Path to corresponding parquet file. Auto-detected from JSONL path if omitted.")
    parser.add_argument("--port", "-p", type=int, default=5008)
    parser.add_argument("--max-frames", "-n", type=int, default=500,
                        help="Max predictions to load (default 500)")
    args = parser.parse_args()

    # Resolve JSONL path
    jsonl_path = args.jsonl_path
    if not os.path.exists(jsonl_path):
        # Try finding in INFERENCE_BASE
        alt = os.path.join(INFERENCE_BASE, args.jsonl_path, "inference_result.jsonl")
        if os.path.exists(alt):
            
            jsonl_path = alt
        else:
            print(f"ERROR: JSONL not found: {args.jsonl_path}")
            sys.exit(1)

    # Resolve parquet path
    parquet_path = args.parquet
    if parquet_path is None:
        parquet_path = _auto_parquet_path(jsonl_path)
        if parquet_path:
            print(f"Auto-detected parquet: {parquet_path}")
        else:
            print("No parquet found — running in viz-only mode (no scoring, no freespace).")
            print("Use --parquet to specify manually.")

    if parquet_path and not os.path.exists(parquet_path):
        print(f"WARNING: Parquet not found: {parquet_path}, falling back to viz-only mode")
        parquet_path = None

    viewer = EvalRewardViewer(jsonl_path, parquet_path, max_frames=args.max_frames)
    if not viewer.rows:
        print("ERROR: no rows loaded!")
        sys.exit(1)

    print(f"Loaded {len(viewer.rows)} predictions "
          f"({'with' if viewer.has_parquet else 'without'} scoring)")
    if viewer.has_parquet:
        for reason, cnt in viewer.stats["reason_dist"].most_common():
            print(f"  {reason}: {cnt} ({100*cnt/viewer.stats['total']:.1f}%)")
        print(f"  Mean score: {viewer.stats.get('mean', 0):.3f}")

    os.environ.setdefault("BOKEH_ALLOW_WS_ORIGIN", "*")
    pn.extension()
    template = pn.template.FastListTemplate(
        title="VLA Eval Reward Visualizer",
        main=[viewer.layout()],
        accent_base_color="#1565c0",
        header_background="#0d47a1",
    )
    print(f"\nStarting at http://0.0.0.0:{args.port}")
    template.show(port=args.port, address="0.0.0.0")


if __name__ == "__main__":
    main()
