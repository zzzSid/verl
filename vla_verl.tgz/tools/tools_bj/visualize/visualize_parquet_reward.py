"""
Interactive visualization for VLA No-Entry RL parquet data.

Reads a parquet file produced by no-entry_jsonl2parquet.py and launches a Panel
web app showing:
  - Camera images (FRONT, FRONT_NARROW, FRONT_LEFT, FRONT_RIGHT)
  - BEV view: road network (colored by class), goal point (vla_goal_point),
    GT trajectory (gt_ego_fut_trajs), intersection point & distance
  - Reward-computation info: forbidden roads, intersection distance/penalty,
    has_exit_sign, vla_goal_point
  - Prompt and GT answer text

Usage:
  python tools/tools_bj/visualize/visualize_parquet_reward.py \\
      /path/to/file.parquet
  python tools/tools_bj/visualize/visualize_parquet_reward.py \\
      /path/to/file.parquet --port 5007 --max-frames 200
"""

import argparse
import json
import os
import pickle
import sys
from collections import defaultdict
from io import BytesIO
from base64 import b64encode

import concurrent.futures
from threading import Lock
from typing import Tuple, Optional
import numpy as np
import pandas as pd
import panel as pn
# ── Bokeh BEV ──
from bokeh_wrapper.bokeh_fig import GenTopViewFigsGroup
from bokeh_wrapper.bokeh_base import (
    ArrowLayer, MultiLinesWithColorLayer, MultiPolygonLayer,
    PointsWithColorLayer, PointsLayer,
)

# ── Patch asyncio to allow nested event loops ──
# read_cache_op_py (hack_lustre / gpfs_sdk) internally calls asyncio.run(),
# which would fail when called from Panel/Bokeh's running Tornado event loop.
# nest_asyncio patches the loop so nested asyncio.run() works transparently.
try:
    import nest_asyncio
    nest_asyncio.apply()
    print("nest_asyncio enabled")
except ImportError:
    print("Tip: install nest_asyncio (pip install nest_asyncio)")

# ── Image reading ──
import cv2
from PIL import Image
from loguru import logger

if int(os.getenv("ON_TXSH", "0")):
    from niofs.read_cache_op_py import read_cache_op_py
    ON_TXSH = True
else:
    from read_cache_op_py import read_cache_op_py
    ON_TXSH = False

CACHE_AVAILABLE = True

# ── Thread pool for image reading (defense-in-depth) ──
_IMAGE_READ_EXECUTOR = concurrent.futures.ThreadPoolExecutor(max_workers=8)

# ── NIOFS client + size cache for image path resolution ──
_niofs_client = None
_size_cache = {}
_size_cache_lock = Lock()


def _get_niofs_client():
    """Singleton niofs client for head_object (Content-Length lookups)."""
    global _niofs_client
    if _niofs_client is None:
        try:
            import niofs
        except ImportError:
            print("Warning: niofs not installed, cannot get image size via head_object")
            return None
        access_key = os.environ.get('LUSTRE_ACCESS_KEY', 'b89e365554ef75f8')
        secret_key = os.environ.get('LUSTRE_SECRET_KEY', '0910180b207f4edd9baaa030cf4a2902')
        try:
            _niofs_client = niofs.Client(access_key, secret_key, max_pool_connections=32)
        except Exception as e:
            print(f"NIOFS client init failed: {e}")
            return None
    return _niofs_client


def parse_niofs_path(path: str) -> Tuple[str, str]:
    """Extract (bucket, key) from an S3/niofs path."""
    path = path.strip()
    if not path:
        raise ValueError("Empty path")
    if path.startswith("s3://"):
        path = path[5:]
    elif path.startswith("s3:"):
        path = path[3:]
    elif path.startswith("huailai_cos:"):
        path = path[12:]
    path = path.lstrip("/")
    if "://" in path:
        parts = path.split("://", 1)
    elif ":" in path:
        parts = path.split(":", 1)
    elif "/" in path:
        parts = path.split("/", 1)
    else:
        raise ValueError(f"Invalid path format: {path}")
    bucket = parts[0].strip()
    key = parts[1].strip().lstrip("/")
    return bucket, key


def get_file_size(bucket: str, key: str, max_retries: int = 3) -> Optional[int]:
    """Look up Content-Length for a remote file via niofs head_object."""
    cache_key = f"{bucket}/{key}"
    with _size_cache_lock:
        if cache_key in _size_cache:
            return _size_cache[cache_key]
    client = _get_niofs_client()
    if client is None:
        return None
    for attempt in range(max_retries):
        try:
            resp = client.head_object(Bucket=bucket, Key=key)
            size = resp.get("ContentLength", 0)
            if size > 0:
                with _size_cache_lock:
                    _size_cache[cache_key] = size
                return size
        except Exception:
            if attempt < max_retries - 1:
                import time
                time.sleep(0.1 * (attempt + 1))
    return None


def resolve_image_path_with_size(image_path: str) -> str:
    """Ensure image path has '{path} {file_size}' format for read_cache_op_py."""
    image_path = image_path.strip()
    clean_path = image_path
    for prefix in ('huailai_cos:', 's3://'):
        if clean_path.startswith(prefix):
            clean_path = clean_path[len(prefix):]
            break
    clean_path = '/' + clean_path.lstrip('/')
    # Already has size suffix?
    parts = clean_path.rsplit(' ', 1)
    if len(parts) == 2 and parts[1].isdigit():
        return clean_path
    # Look up size via niofs
    try:
        bucket, key = parse_niofs_path(image_path)
        size = get_file_size(bucket, key)
        if size is not None:
            return f"{clean_path} {size}"
    except Exception:
        pass
    return clean_path


def _cv2_to_data_url(cv2_image: np.ndarray) -> str:
    """Convert a BGR cv2 image array to a base64 data URL."""
    rgb = cv2.cvtColor(cv2_image, cv2.COLOR_BGR2RGB)
    image = Image.fromarray(rgb)
    output = BytesIO()
    image.save(output, format="WEBP", quality=80, method=0, optimize=True)
    b64_image = b64encode(output.getvalue()).decode("utf-8")
    return f"data:image/webp;base64,{b64_image}"


def _read_image_sync(clean_url: str, read_ceph_kwargs: dict) -> str:
    """Synchronous image read — runs in a worker thread."""
    raw_bytes = _read_image_sync_raw(clean_url, read_ceph_kwargs)
    if raw_bytes is not None:
        img = cv2.imdecode(np.frombuffer(raw_bytes, np.uint8), -1)
        if img is not None:
            return _cv2_to_data_url(img)
    return ""


def _read_image_sync_raw(clean_url: str, read_ceph_kwargs: dict):
    """Synchronous image read returning raw bytes (no decoding)."""
    raw_bytes_list = read_cache_op_py([clean_url], **read_ceph_kwargs)
    if raw_bytes_list and raw_bytes_list[0]:
        return raw_bytes_list[0]
    return None


def read_image_to_data_url(img_url: str, timeout: float = 30.0) -> str:
    """Read a single image to data URL via read_cache_op_py.

    Uses nest_asyncio to allow asyncio.run() inside read_cache_op_py
    even when called from Panel/Bokeh's running event loop.  Falls back
    to a thread-pool worker as defense-in-depth.
    """
    if not img_url or not CACHE_AVAILABLE:
        return ""

    # Resolve path with file size (required by read_cache_op_py on some backends)
    clean_url = img_url.replace("huailai_cos:ad-cn-hlidc-multimodal", "/ad-cn-hlidc-multimodal")
    clean_url = resolve_image_path_with_size(clean_url)

    read_ceph_kwargs = {}
    if ON_TXSH:
        read_ceph_kwargs["mnt_point"] = "/lustre"

    try:
        future = _IMAGE_READ_EXECUTOR.submit(
            _read_image_sync, clean_url, read_ceph_kwargs,
        )
        return future.result(timeout=timeout)
    except Exception as e:
        logger.warning(f"Failed to read image {clean_url}: {e}")
    return ""


# ═══════════════════════════════════════════════════════════════════════════════
#  Reward helpers (inline copies from vla_no_entry_v4 to avoid import issues)
# ═══════════════════════════════════════════════════════════════════════════════

FORBIDDEN_ROAD_CLASSES = {
    "noEntryRoad", "noEntryRoadBarrier", "ArriveDeadEndRoad", "onlyRetrograde",
}

ROAD_CLS_COLORS = {
    "normalRoad":              "#4caf50",
    "entryRoad":               "#81c784",
    "noEntryRoad":             "#e53935",
    "noEntryRoadBarrier":      "#b71c1c",
    "onlyRetrograde":          "#ff9800",
    "ArriveDeadEndRoad":       "#795548",
    "twoWayRoadNoEntry":       "#9c27b0",
    "twoWayRoadNoEntryBarrier":"#6a1b9a",
    "unknown":                 "#9e9e9e",
}
DEFAULT_ROAD_COLOR = "#9e9e9e"

FREESPACE_COLORS = {
    "safe":      ("#4caf50", 0.10),
    "unsafe":    ("#e53935", 0.18),
    "uncertain": ("#ff9800", 0.10),
}

ROT_BEV = np.array([[0, -1], [1, 0]])
BEV_SIZE_M = 60.0


def _min_distance_point_to_polyline(point, polyline):
    point = np.asarray(point, dtype=float)
    min_dist, closest_pt = float("inf"), None
    for i in range(len(polyline) - 1):
        a, b = polyline[i], polyline[i + 1]
        ab = b - a
        ab_len_sq = np.dot(ab, ab)
        if ab_len_sq < 1e-12:
            dist = np.linalg.norm(point - a)
            if dist < min_dist:
                min_dist, closest_pt = dist, a.copy()
            continue
        t = max(0.0, min(1.0, np.dot(point - a, ab) / ab_len_sq))
        closest = a + t * ab
        dist = np.linalg.norm(point - closest)
        if dist < min_dist:
            min_dist, closest_pt = dist, closest.copy()
    return min_dist, closest_pt


def get_all_road_geometries(road_graphs):
    geoms = {}
    for rid, info in road_graphs.items():
        if info and "geometry" in info:
            g = np.array(info["geometry"], dtype=float)
            if len(g) >= 2:
                geoms[rid] = g
    return geoms


def find_nearest_road_to_point(point, all_road_geoms):
    best_id, best_dist, best_pt = None, float("inf"), None
    for rid, geom in all_road_geoms.items():
        d, pt = _min_distance_point_to_polyline(np.asarray(point, dtype=float), geom)
        if d < best_dist:
            best_dist, best_pt, best_id = d, pt, rid
    return best_id, best_dist, best_pt


def detect_intersection_distance(all_road_geoms, endpoint_thresh=2.0, min_conn=2):
    result = {
        "is_intersection": False, "distance": None,
        "num_connected_roads": 0, "origin_road_id": None,
        "intersection_point": None, "forward_endpoint": None,
        "closest_pt": None, "connected_road_ids": set(),
    }
    if len(all_road_geoms) < 2:
        return result
    origin = np.array([0.0, 0.0])
    origin_rid, _, closest_pt = find_nearest_road_to_point(origin, all_road_geoms)
    if origin_rid is None:
        return result
    result["origin_road_id"] = origin_rid
    result["closest_pt"] = closest_pt
    geom = all_road_geoms[origin_rid]
    car_hdg = np.array([1.0, 0.0])
    fwd_ep = None
    for ep in [geom[0], geom[-1]]:
        dvec = ep - closest_pt
        dn = np.linalg.norm(dvec)
        if dn < 1e-6:
            continue
        if np.dot(dvec / dn, car_hdg) > 0:
            fwd_ep = ep
            break
    if fwd_ep is None:
        fwd_ep = geom[0] if geom[0][0] > geom[-1][0] else geom[-1]
    conn = set()
    for rid, g in all_road_geoms.items():
        if rid == origin_rid:
            continue
        for ep in [g[0], g[-1]]:
            if np.linalg.norm(ep - fwd_ep) <= endpoint_thresh:
                conn.add(rid)
                break
    result["num_connected_roads"] = len(conn)
    result["forward_endpoint"] = fwd_ep
    result["connected_road_ids"] = conn
    if len(conn) < min_conn:
        return result
    result["is_intersection"] = True
    result["intersection_point"] = fwd_ep
    result["distance"] = float(np.linalg.norm(fwd_ep - origin))
    return result


def get_intersection_penalty(dist):
    if dist is None:
        return 2.0
    if dist < 6.0:
        return 4.0
    if dist < 12.0:
        return 3.0
    return 2.0


def rot_to_bev(points):
    if points is None or len(points) == 0:
        return None
    return np.asarray(points, dtype=float) @ ROT_BEV.T


# ═══════════════════════════════════════════════════════════════════════════════
#  Road-binding helpers (inline copies from vla_no_entry_v4.py)
# ═══════════════════════════════════════════════════════════════════════════════

BINDING_W_DIST   = 0.5
BINDING_W_ANGLE  = 0.5
BINDING_MAX_DIST = 5.0
BINDING_MIN_POINTS = 5

GOAL_LANE_W_DIST  = 0.3
GOAL_LANE_W_ANGLE = 0.7

EXIT_ROAD_COLOR   = "#2e7d32"       # deep green — exit road highlight
EXIT_ROAD_ALPHA   = 0.95
EXIT_ROAD_LW      = 5.0


def _road_direction_at_point(polyline, closest_point):
    """Return unit direction vector of the polyline segment nearest to a point."""
    min_seg_dist = float("inf")
    best_dir = None
    for i in range(len(polyline) - 1):
        a, b = polyline[i], polyline[i + 1]
        mid = (a + b) / 2.0
        d = np.linalg.norm(closest_point - mid)
        if d < min_seg_dist:
            min_seg_dist = d
            seg_dir = b - a
            seg_len = np.linalg.norm(seg_dir)
            if seg_len > 1e-8:
                best_dir = seg_dir / seg_len
    return best_dir


def compute_segment_binding_score(segment, geom):
    """Score a 3-point trajectory segment against a road geometry.

    Returns dict with score/dist/angle/closest_pt, or None if rejected.
    """
    center = np.mean(segment, axis=0)
    min_dist, closest_pt = _min_distance_point_to_polyline(center, geom)
    if min_dist > BINDING_MAX_DIST:
        return None
    seg_vec = segment[-1] - segment[0]
    seg_len = np.linalg.norm(seg_vec)
    if seg_len < 1e-6:
        return None
    seg_heading = np.arctan2(seg_vec[1], seg_vec[0])
    road_dir = _road_direction_at_point(geom, closest_pt)
    if road_dir is None:
        return None
    road_heading = np.arctan2(road_dir[1], road_dir[0])
    angle_diff = seg_heading - road_heading
    angle_diff = np.degrees(np.arctan2(np.sin(angle_diff), np.cos(angle_diff)))
    abs_angle = abs(angle_diff)
    if 60.0 < abs_angle < 120.0:
        return None
    has_both_sides = (np.any(geom[:, 1] > 0) and np.any(geom[:, 1] < 0))
    if not has_both_sides and abs_angle > 90.0:
        return None
    if len(geom) >= 2:
        global_vec = geom[-1] - geom[0]
        global_heading = np.arctan2(global_vec[1], global_vec[0])
        global_diff = seg_heading - global_heading
        global_diff = np.degrees(np.arctan2(np.sin(global_diff), np.cos(global_diff)))
        if 60.0 < abs(global_diff) < 120.0:
            return None
    norm_dist = min(min_dist / BINDING_MAX_DIST, 1.0)
    norm_angle = abs_angle / 90.0
    score = BINDING_W_DIST * norm_dist + BINDING_W_ANGLE * norm_angle
    return {
        "score": score, "dist": float(min_dist),
        "angle_deg": float(angle_diff), "closest_pt": closest_pt,
    }


def bind_segment_to_road(segment, all_road_geoms):
    """Find the best-matching road for a 3-point trajectory segment."""
    best_road_id = None
    best_score = float("inf")
    best_info = None
    for road_id, geom in all_road_geoms.items():
        result = compute_segment_binding_score(segment, geom)
        if result is None:
            continue
        if result["score"] < best_score:
            best_score = result["score"]
            best_road_id = road_id
            best_info = result
    return best_road_id, best_info


def find_best_lane_for_goal(goal_point, all_road_geoms):
    """Bind vla_goal_point to the best-matching road (exit road).

    Mirrors vla_no_entry_v4.find_best_lane_for_goal exactly.

    Returns (best_road_id, best_geometry, best_score, best_debug)
    or (None, None, -1.0, {}).
    """
    if not goal_point or not all_road_geoms:
        return None, None, -1.0, {}

    px = goal_point.get("point_x", 0)
    py = goal_point.get("point_y", 0)
    yaw = goal_point.get("yaw", 0)
    goal_pos = np.array([px, py])
    goal_dir = np.array([np.cos(yaw), np.sin(yaw)])

    w_d = GOAL_LANE_W_DIST
    w_a = GOAL_LANE_W_ANGLE

    best_score = -1.0
    best_road_id = None
    best_geometry = None
    best_debug = {}

    for road_id, geometry in all_road_geoms.items():
        if len(geometry) < 2:
            continue

        road_best_score = -1.0
        road_best_debug = {}
        for i in range(len(geometry) - 1):
            p1 = geometry[i]
            p2 = geometry[i + 1]

            d1 = np.linalg.norm(p1)
            d2 = np.linalg.norm(p2)
            lane_dir = (p2 - p1) if d1 <= d2 else (p1 - p2)
            lane_dir_norm = np.linalg.norm(lane_dir)
            if lane_dir_norm < 1e-6:
                continue
            lane_dir = lane_dir / lane_dir_norm

            v = p2 - p1
            w = goal_pos - p1
            v_dot_v = np.dot(v, v)
            if v_dot_v < 1e-6:
                dist = np.linalg.norm(goal_pos - p1)
            else:
                t = np.clip(np.dot(w, v) / v_dot_v, 0.0, 1.0)
                projection = p1 + t * v
                dist = np.linalg.norm(goal_pos - projection)

            cos_angle = np.dot(goal_dir, lane_dir)
            angle_deg = np.degrees(np.arccos(np.clip(cos_angle, -1.0, 1.0)))
            if cos_angle < 0.2588:  # cos(75°) ≈ 0.2588
                continue

            dist_score = 1.0 / (1.0 + dist)
            angle_score = max(0.0, cos_angle)
            score = w_d * dist_score + w_a * angle_score

            if score > road_best_score:
                road_best_score = score
                road_best_debug = {
                    "seg_idx": i,
                    "dist": round(dist, 2),
                    "angle_deg": round(angle_deg, 1),
                    "dist_score": round(dist_score, 3),
                    "angle_score": round(angle_score, 3),
                    "score": round(score, 3),
                }

        if road_best_score > best_score:
            best_score = road_best_score
            best_road_id = road_id
            best_geometry = geometry
            best_debug = road_best_debug

    return best_road_id, best_geometry, best_score, best_debug


def bind_gt_trajectory_to_roads(gt_trajs, all_road_geoms):
    """Bind GT ego-future trajectory segments to roads.

    Returns list of dicts: {seg_idx, bound_road_id, binding_info, is_exit_road}.
    """
    if gt_trajs is None or len(gt_trajs) < 2 or not all_road_geoms:
        return []

    abs_traj = np.cumsum(np.array(gt_trajs, dtype=float), axis=0)
    origin = np.array([[0.0, 0.0]])
    full_traj = np.vstack([origin, abs_traj[:BINDING_MIN_POINTS]])

    bindings = []
    for i in range(len(full_traj) - 2):
        segment = full_traj[i:i + 3]
        road_id, info = bind_segment_to_road(segment, all_road_geoms)
        bindings.append({
            "segment_idx": i,
            "segment_mid": np.mean(segment, axis=0),
            "bound_road_id": road_id,
            "binding_info": info,
        })
    return bindings


# ═══════════════════════════════════════════════════════════════════════════════
#  Freespace RLE decoder
# ═══════════════════════════════════════════════════════════════════════════════

def decode_freespace_rle(rle):
    """Decode freespace RLE mask and return polygon contours in BEV meter coords.

    Returns (poly_xs, poly_ys): two lists of numpy arrays, one per contour.
    Each polygon is closed (first point repeated at end).
    """
    if not rle or "counts" not in rle or "size" not in rle:
        return [], []
    try:
        from pycocotools import mask as coco_mask
    except ImportError:
        return [], []
    counts = rle["counts"]
    if isinstance(counts, str):
        counts = counts.encode("utf-8")
    try:
        m = coco_mask.decode({"size": rle["size"], "counts": counts})
    except Exception:
        return [], []
    if not np.any(m):
        return [], []
    try:
        contours, _ = cv2.findContours(
            m.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )
    except Exception:
        return [], []
    h, w = rle["size"]
    scale = BEV_SIZE_M / w
    offset = BEV_SIZE_M / 2.0
    poly_xs, poly_ys = [], []
    for c in contours:
        if len(c) < 3:
            continue
        xs = c[:, 0, 0].astype(float) * scale - offset
        ys = offset - c[:, 0, 1].astype(float) * scale
        # Close polygon
        xs = np.append(xs, xs[0])
        ys = np.append(ys, ys[0])
        poly_xs.append(xs)
        poly_ys.append(ys)
    return poly_xs, poly_ys




# ═══════════════════════════════════════════════════════════════════════════════
#  Data loader
# ═══════════════════════════════════════════════════════════════════════════════

def load_parquet(parquet_path, max_frames=500):
    """Load a parquet file, extract and decode all reward-relevant fields."""
    df = pd.read_parquet(parquet_path)
    if max_frames and len(df) > max_frames:
        df = df.iloc[:max_frames]
    print(f"Loaded {len(df)} rows from {parquet_path}")

    rows = []
    for i in range(len(df)):
        row = df.iloc[i]
        ei = row["extra_info"]
        kwargs = (ei.get("tools_kwargs", {})
                   .get("calc_no-entry_reward", {})
                   .get("calc_reward_kwargs", {}))

        # Decode JSON fields (gracefully handle missing new fields from old parquets)
        road_graphs = json.loads(kwargs.get("road_graphs", "{}"))
        select_road_ids = json.loads(kwargs.get("select_road_ids", "[]"))
        select_road_cls = json.loads(kwargs.get("select_road_cls", "[]"))
        freespace_info = json.loads(kwargs.get("freespace_info", "{}"))
        vla_goal_point = json.loads(kwargs.get("vla_goal_point", "{}") or "{}")
        has_exit_sign = json.loads(kwargs.get("has_exit_sign", "false") or "false")
        vln_ocr_info = json.loads(kwargs.get("vln_ocr_info", "[]") or "[]")  # scene_info.vln_ocr_info
        vla_road_construction_info = json.loads(kwargs.get("vla_road_construction_info", "{}") or "{}")
        exit_path_road_ids = set(json.loads(kwargs.get("exit_path_road_ids", "[]") or "[]"))

        all_road_geoms = get_all_road_geometries(road_graphs)
        road_id_to_cls = dict(zip(select_road_ids, select_road_cls))
        forbidden_ids = {
            rid for rid, cls in zip(select_road_ids, select_road_cls)
            if cls in FORBIDDEN_ROAD_CLASSES
        }
        inter_info = detect_intersection_distance(all_road_geoms)
        inter_dist = inter_info.get("distance")
        penalty = get_intersection_penalty(inter_dist)

        # Images: stored as list of S3/local paths
        images = row.get("image", [])
        if hasattr(images, "tolist"):
            images = images.tolist()

        # GT trajectory
        gt_trajs = ei.get("gt_ego_fut_trajs")
        if gt_trajs is not None and hasattr(gt_trajs, "tolist"):
            gt_trajs = gt_trajs.tolist()

        # Prompt
        prompt_list = row.get("prompt", [])
        if hasattr(prompt_list, "tolist"):
            prompt_list = prompt_list.tolist()
        prompt_text = ""
        if isinstance(prompt_list, list) and len(prompt_list) > 0:
            prompt_text = prompt_list[0].get("content", "") if isinstance(
                prompt_list[0], dict) else str(prompt_list)

        # ── v4: Goal → exit-road binding ──
        exit_road_id, _, exit_road_score, exit_road_debug = (
            find_best_lane_for_goal(vla_goal_point, all_road_geoms)
        )

        # ── v4: GT trajectory → road bindings ──
        gt_road_bindings = bind_gt_trajectory_to_roads(gt_trajs, all_road_geoms)
        gt_binds_to_exit = any(
            b["bound_road_id"] == exit_road_id for b in gt_road_bindings
            if b["bound_road_id"] is not None
        )

        rows.append({
            "index": i,
            "clip_id": ei.get("clip_id", f"row_{i}"),
            "images": images,
            "prompt_text": prompt_text,
            "answer": ei.get("answer", ""),
            "question": ei.get("question", ""),
            "gt_ego_fut_trajs": gt_trajs,
            "road_graphs": road_graphs,
            "all_road_geoms": all_road_geoms,
            "select_road_ids": select_road_ids,
            "select_road_cls": select_road_cls,
            "road_id_to_cls": road_id_to_cls,
            "forbidden_ids": forbidden_ids,
            "freespace_info": freespace_info,
            "vla_goal_point": vla_goal_point,
            "has_exit_sign": has_exit_sign,
            "vln_ocr_info": vln_ocr_info,
            "vla_road_construction_info": vla_road_construction_info,
            "exit_path_road_ids": exit_path_road_ids,
            "intersection_info": inter_info,
            "intersection_distance": inter_dist,
            "forbidden_penalty": penalty,
            # v4 road-binding fields
            "exit_road_id": exit_road_id,
            "exit_road_score": exit_road_score,
            "exit_road_debug": exit_road_debug,
            "gt_road_bindings": gt_road_bindings,
            "gt_binds_to_exit": gt_binds_to_exit,
        })
    return rows


# ═══════════════════════════════════════════════════════════════════════════════
#  Panel UI
# ═══════════════════════════════════════════════════════════════════════════════

# ── Global filter: when True, frames without exit sign are hidden ──
FILTER_HAS_EXIT_SIGN = True

class ParquetRewardViewer:
    """Interactive Panel app for browsing VLA No-Entry parquet data."""

    def __init__(self, parquet_path, max_frames=500):
        all_rows = load_parquet(parquet_path, max_frames=max_frames)
        self.rows = all_rows
        self.current_index = 0
        if not self.rows:
            print("ERROR: No rows loaded!")
            return

        self._image_cache = {}
        self._setup_bokeh_bev()
        self._compute_stats()
        self._setup_widgets()

    def _setup_bokeh_bev(self):
        """Create bokeh BEV figure and all overlay layers (mirrors matplotlib layers)."""
        self.bev_fig = GenTopViewFigsGroup({
            "BEV": {'size': [600, 600], 'x_label': 'x (m)', 'y_label': 'y (m)'},
        })
        self.bev_fig.legend.click_policy = "hide"

        # Freespace layers
        self.bev_safe_lyr = MultiPolygonLayer(
            self.bev_fig, {'legend_label': 'safe', 'line_color': 'green',
                           'fill_color': 'green', 'line_width': 1, 'alpha': 0.5, 'fill_alpha': 0.10})
        self.bev_unsafe_lyr = MultiPolygonLayer(
            self.bev_fig, {'legend_label': 'unsafe', 'line_color': 'red',
                           'fill_color': 'red', 'line_width': 1, 'alpha': 0.6, 'fill_alpha': 0.18})
        self.bev_uncertain_lyr = MultiPolygonLayer(
            self.bev_fig, {'legend_label': 'uncertain', 'line_color': 'orange',
                           'fill_color': 'orange', 'line_width': 1, 'alpha': 0.6, 'fill_alpha': 0.10})

        # Road layers
        self.bev_road_lyr = MultiLinesWithColorLayer(
            self.bev_fig, {'legend_label': 'roads', 'line_width': 3, 'alpha': 0.9})
        self.bev_exit_road_lyr = MultiLinesWithColorLayer(
            self.bev_fig, {'legend_label': 'exit road', 'line_width': 5, 'alpha': 0.95})

        # Markers
        self.bev_ego_lyr = PointsLayer(
            self.bev_fig, {'legend_label': 'ego', 'size': 12, 'marker': 'circle',
                           'color': 'yellow', 'alpha': 1.0})
        self.bev_inter_lyr = PointsLayer(
            self.bev_fig, {'legend_label': 'intersection', 'size': 14, 'marker': 'diamond',
                           'color': 'cyan', 'alpha': 1.0})
        self.bev_goal_lyr = PointsLayer(
            self.bev_fig, {'legend_label': 'goal point', 'size': 16, 'marker': 'star',
                           'color': 'lime', 'alpha': 1.0})
        self.bev_goal_arrow = ArrowLayer(self.bev_fig, {})

        # GT trajectory
        self.bev_gt_line_lyr = MultiLinesWithColorLayer(
            self.bev_fig, {'legend_label': 'GT traj', 'line_width': 2, 'alpha': 0.9})
        self.bev_gt_pts_lyr = PointsWithColorLayer(
            self.bev_fig, {'legend_label': 'GT pts', 'size': 6, 'marker': 'circle', 'alpha': 0.8})

        # Binding markers
        self.bev_bind_lyr = PointsWithColorLayer(
            self.bev_fig, {'legend_label': 'GT bindings', 'size': 12, 'marker': 'diamond',
                           'alpha': 0.9})

    def _build_bev_display(self, r):
        """Update all bokeh BEV layers from a row_data dict."""
        all_road_geoms = r.get("all_road_geoms", {})
        road_id_to_cls = r.get("road_id_to_cls", {})
        forbidden_ids = r.get("forbidden_ids", set())
        freespace_info = r.get("freespace_info", {})
        vla_goal_point = r.get("vla_goal_point", {})
        gt_trajs = r.get("gt_ego_fut_trajs")
        inter_info = r.get("intersection_info", {})
        exit_road_id = r.get("exit_road_id")
        gt_road_bindings = r.get("gt_road_bindings", [])

        # ── Freespace ──
        for key, layer in [('safe', self.bev_safe_lyr),
                           ('unsafe', self.bev_unsafe_lyr),
                           ('uncertain', self.bev_uncertain_lyr)]:
            rle = freespace_info.get(key) if freespace_info else None
            poly_xs, poly_ys = decode_freespace_rle(rle)
            if poly_xs:
                layer.update([[poly_xs]], [[poly_ys]])
            else:
                layer.update([], [])

        vla_road_construction_info = r.get("vla_road_construction_info", {})
        exit_path_road_ids = r.get("exit_path_road_ids", set())

        # ── Road geometries ──
        road_xs, road_ys, road_colors, road_types = [], [], [], []
        exit_xs, exit_ys, exit_colors, exit_types = [], [], [], []
        if all_road_geoms:
            for road_id, geom in all_road_geoms.items():
                if len(geom) < 2:
                    continue
                pts_bev = rot_to_bev(np.array(geom))
                xl, yl = pts_bev[:, 0].tolist(), pts_bev[:, 1].tolist()
                cls = road_id_to_cls.get(road_id, "unknown")
                color = ROAD_CLS_COLORS.get(cls, DEFAULT_ROAD_COLOR)
                is_fb = road_id in forbidden_ids
                ltype = "dashed" if is_fb else "solid"

                if road_id == exit_road_id:
                    exit_xs.append(xl); exit_ys.append(yl)
                    exit_colors.append(EXIT_ROAD_COLOR); exit_types.append("solid")
                else:
                    road_xs.append(xl); road_ys.append(yl)
                    road_colors.append(color); road_types.append(ltype)
        elif isinstance(vla_road_construction_info, dict):
            vla_road_info = vla_road_construction_info.get("vla_road_info", [])
            if isinstance(vla_road_info, list):
                for road in vla_road_info:
                    road_id = road.get("road_link_id", "")
                    way_points = road.get("road_way_point", [])
                    if len(way_points) > 1:
                        geo = np.array([[wp["point_x"], wp["point_y"]] for wp in way_points])
                        pts_bev = rot_to_bev(geo)
                        xl, yl = pts_bev[:, 0].tolist(), pts_bev[:, 1].tolist()
                        if road_id in exit_path_road_ids:
                            road_colors.append("blue")
                            road_types.append("solid")
                        else:
                            cls = road_id_to_cls.get(road_id, "unknown")
                            road_colors.append(ROAD_CLS_COLORS.get(cls, DEFAULT_ROAD_COLOR))
                            road_types.append("solid")
                        road_xs.append(xl)
                        road_ys.append(yl)

        self.bev_road_lyr.update(road_xs, road_ys, road_colors, road_types)
        self.bev_exit_road_lyr.update(exit_xs, exit_ys, exit_colors, exit_types)

        # ── Intersection point ──
        if inter_info.get("is_intersection"):
            fwd_ep = inter_info.get("forward_endpoint")
            if fwd_ep is not None:
                fb = rot_to_bev(np.array([fwd_ep]))
                self.bev_inter_lyr.update([float(fb[0, 0])], [float(fb[0, 1])])
            else:
                self.bev_inter_lyr.update([], [])
        else:
            self.bev_inter_lyr.update([], [])

        # ── Goal point + arrow ──
        if vla_goal_point and vla_goal_point.get("point_x") is not None:
            gx, gy, gyaw = (vla_goal_point["point_x"],
                           vla_goal_point["point_y"],
                           vla_goal_point["yaw"])
            g_bev = rot_to_bev(np.array([[gx, gy]]))
            self.bev_goal_lyr.update([float(g_bev[0, 0])], [float(g_bev[0, 1])])
            arrow_len = 3.0
            gx_end = gx + arrow_len * np.cos(gyaw)
            gy_end = gy + arrow_len * np.sin(gyaw)
            arrow_bev = rot_to_bev(np.array([[gx, gy], [gx_end, gy_end]]))
            self.bev_goal_arrow.update(
                float(arrow_bev[0, 0]), float(arrow_bev[0, 1]),
                float(arrow_bev[1, 0]), float(arrow_bev[1, 1]))
        else:
            self.bev_goal_lyr.update([], [])
            self.bev_goal_arrow.update(0, 0, 0, 0)

        # ── Ego ──
        self.bev_ego_lyr.update([0.0], [0.0])

        # ── GT trajectory ──
        if gt_trajs is not None and len(gt_trajs) > 0:
            traj = np.cumsum(np.array(gt_trajs, dtype=float), axis=0)
            traj_bev = rot_to_bev(traj)
            self.bev_gt_line_lyr.update(
                [traj_bev[:, 0].tolist()], [traj_bev[:, 1].tolist()],
                ['cyan'], ['solid'])
            n_pts = len(traj_bev)
            gt_colors = [
                f"#{int(255*i/max(n_pts-1,1)):02x}{int(255*(1-i/max(n_pts-1,1))):02x}00"
                for i in range(n_pts)
            ]
            self.bev_gt_pts_lyr.update(
                traj_bev[:, 0].tolist(), traj_bev[:, 1].tolist(), gt_colors)
        else:
            self.bev_gt_line_lyr.update([], [], [], [])
            self.bev_gt_pts_lyr.update([], [], [])

        # ── GT segment→road binding markers ──
        bind_xs, bind_ys, bind_colors = [], [], []
        for b in gt_road_bindings:
            bound_rid = b.get("bound_road_id")
            if bound_rid is None or b.get("binding_info") is None:
                continue
            mid_pt = np.array(b.get("segment_mid", [0, 0]))
            mid_bev = rot_to_bev(np.array([mid_pt]))[0]
            bind_xs.append(float(mid_bev[0]))
            bind_ys.append(float(mid_bev[1]))
            bind_colors.append(EXIT_ROAD_COLOR if bound_rid == exit_road_id else "#ffffff")
        self.bev_bind_lyr.update(bind_xs, bind_ys, bind_colors)

    def _compute_stats(self):
        self.stats = defaultdict(lambda: {"count": 0, "has_exit": 0,
                                          "has_exit_road": 0, "gt_binds_exit": 0,
                                          "dists": []})
        for r in self.rows:
            fb = "has_forbidden" if r["forbidden_ids"] else "no_forbidden"
            self.stats[fb]["count"] += 1
            if r["has_exit_sign"]:
                self.stats[fb]["has_exit"] += 1
            if r["intersection_distance"] is not None:
                self.stats[fb]["dists"].append(r["intersection_distance"])
            if r.get("exit_road_id") is not None:
                self.stats[fb]["has_exit_road"] += 1
            if r.get("gt_binds_to_exit"):
                self.stats[fb]["gt_binds_exit"] += 1

    def _setup_widgets(self):
        max_idx = max(0, len(self.rows) - 1)

        self.slider = pn.widgets.IntSlider(
            name="Frame", start=0, end=max_idx, value=0, width=500)
        self.slider.param.watch(self._on_slider_change, "value")

        self.prev_btn = pn.widgets.Button(name="◀ Prev", button_type="primary", width=80)
        self.next_btn = pn.widgets.Button(name="Next ▶", button_type="primary", width=80)
        self.prev_btn.on_click(self._prev)
        self.next_btn.on_click(self._next)

        self.jump_input = pn.widgets.IntInput(
            name="Jump", value=1, start=1, end=len(self.rows), width=80)
        self.jump_btn = pn.widgets.Button(name="Go", button_type="primary", width=45)
        self.jump_btn.on_click(self._jump)

        # Filters
        reasons = sorted(self.stats.keys())
        self.filter_key = pn.widgets.MultiChoice(
            name="Filter by forbidden", options=reasons, value=reasons, width=350)
        self.filter_key.param.watch(lambda e: self._apply_filters(), "value")

        self.filter_exit_only = pn.widgets.Checkbox(
            name="Only show frames with exit sign (has_exit_sign=True)", value=False)
        self.filter_exit_only.param.watch(lambda e: self._apply_filters(), "value")

        # Image panes (must be created before _apply_filters → update_display)
        self.img_fw = pn.pane.HTML("", width=481, height=271)
        self.img_fn = pn.pane.HTML("", width=481, height=271)
        self.img_fl = pn.pane.HTML("", width=481, height=271)
        self.img_fr = pn.pane.HTML("", width=481, height=271)

        # Info / BEV panes
        self.info_pane = pn.pane.Markdown("", sizing_mode="stretch_width")
        self.stats_pane = pn.pane.Markdown("", sizing_mode="stretch_width")
        self.bev_pane = pn.pane.Bokeh(self.bev_fig, width=620, height=620)
        self.prompt_pane = pn.pane.Markdown("", sizing_mode="stretch_width")

        self._apply_filters()

    def _apply_filters(self):
        keys = set(self.filter_key.value)
        exit_only = self.filter_exit_only.value
        require_exit = FILTER_HAS_EXIT_SIGN or exit_only
        self.visible = [
            i for i, r in enumerate(self.rows)
            if ("has_forbidden" if r["forbidden_ids"] else "no_forbidden") in keys
            and (not require_exit or r["has_exit_sign"])
        ]
        if self.visible:
            if self.current_index not in self.visible:
                self.current_index = self.visible[0]
            self.slider.value = self.current_index
            self.jump_input.end = len(self.visible)
        self.update_display()

    def _on_slider_change(self, event):
        self.current_index = event.new
        self.update_display()

    def _prev(self, event):
        if not self.visible:
            return
        before = [v for v in self.visible if v < self.current_index]
        if before:
            self.current_index = before[-1]
            self.slider.value = self.current_index

    def _next(self, event):
        if not self.visible:
            return
        after = [v for v in self.visible if v > self.current_index]
        if after:
            self.current_index = after[0]
            self.slider.value = self.current_index

    def _jump(self, event):
        t = self.jump_input.value - 1
        if 0 <= t < len(self.visible):
            self.current_index = self.visible[t]
            self.slider.value = self.current_index

    def _load_images(self, row_data):
        """Load the first image of each camera view as data URLs, with OCR boxes drawn.

        The parquet ``image`` field is a flat list::

            [FW₀, FN₀, FL₀, FR₀, FW₁, FN₁, ...]

        We take the *first* occurrence of each camera (FW, FN, FL, FR)
        so the four views always belong to the same (earliest) key frame.

        OCR 2D bounding boxes from ``vln_ocr_info`` (scene_info.vln_ocr_info) are drawn directly on
        the image before encoding to data URL, so the exit-sign location
        is visible on each camera view.
        """
        idx = row_data["index"]
        if idx in self._image_cache:
            return self._image_cache[idx]

        images = row_data.get("images", [])
        vln_ocr_info = row_data.get("vln_ocr_info", [])
        cam_names = ["FRONT", "FRONT_NARROW", "FRONT_LEFT", "FRONT_RIGHT"]
        cam_tokens = ["/FW/", "/FN/", "/FL/", "/FR/"]
        sensor_ids = [0, 1, 2, 3]   # 0=FW, 1=FN, 2=FL, 3=FR
        urls = {}

        for cam, token, sid in zip(cam_names, cam_tokens, sensor_ids):
            found = ""
            for img in images:
                s = str(img)
                if token in s:
                    found = s
                    break
            if found:
                urls[cam] = self._read_image_with_ocr(found, vln_ocr_info, sid)
            else:
                urls[cam] = ""

        self._image_cache[idx] = urls
        return urls

    @staticmethod
    def _read_image_with_ocr(img_url, vln_ocr_info, sensor_id):
        """Read image, draw exit-sign OCR 2D boxes for *sensor_id*, return data URL.

        Uses ``find_exit_ocr`` pattern on ``vln_ocr_info`` (from
        ``scene_info.vln_ocr_info``).  Only boxes whose label contains
        "出口" are drawn.
        """
        if not img_url or not CACHE_AVAILABLE:
            return ""

        clean_url = img_url.replace(
            "huailai_cos:ad-cn-hlidc-multimodal", "/ad-cn-hlidc-multimodal")
        clean_url = resolve_image_path_with_size(clean_url)

        read_ceph_kwargs = {}
        if ON_TXSH:
            read_ceph_kwargs["mnt_point"] = "/lustre"

        try:
            future = _IMAGE_READ_EXECUTOR.submit(
                _read_image_sync_raw, clean_url, read_ceph_kwargs,
            )
            raw_bytes = future.result(timeout=30)
        except Exception as e:
            logger.warning(f"Failed to read image {clean_url}: {e}")
            return ""

        if raw_bytes is None:
            return ""

        img_bgr = cv2.imdecode(np.frombuffer(raw_bytes, np.uint8), -1)
        if img_bgr is None:
            return ""

        if vln_ocr_info:
            img_bgr = ParquetRewardViewer._draw_exit_ocr_boxes(img_bgr, vln_ocr_info, sensor_id)

        return _cv2_to_data_url(img_bgr)

    @staticmethod
    def _draw_exit_ocr_boxes(img_bgr, vln_ocr_info, sensor_id):
        """Draw exit-sign OCR 2D boxes using ``find_exit_ocr`` pattern.

        ``vln_ocr_info`` is the flat list from ``scene_info.vln_ocr_info``.
        Each entry: ``{sensor_id, box: [nx1,ny1,nx2,ny2], poi_ocr_info}``.
        Box coords are 0~99 normalised → scaled to image pixels.
        """
        h, w = img_bgr.shape[:2]
        scale_x = w / 99.0
        scale_y = h / 99.0

        for ocr in vln_ocr_info:
            if ocr.get("sensor_id") != sensor_id:
                continue
            box = ocr.get("box", [])
            if not (isinstance(box, list) and len(box) == 4):
                continue
            label = ""
            has_exit = False
            for poi in ocr.get("poi_ocr_info", []):
                text = str(poi.get("poi_indication_info", ""))
                if "出口" in text:
                    has_exit = True
                if text:
                    label = text
            if not has_exit:
                continue

            x1 = int(box[0] * scale_x)
            y1 = int(box[1] * scale_y)
            x2 = int(box[2] * scale_x)
            y2 = int(box[3] * scale_y)
            if not hasattr(ParquetRewardViewer, "_ocr_debug_done"):
                ParquetRewardViewer._ocr_debug_done = True
                logger.info(
                    f"OCR box debug: img={w}x{h} sensor={sensor_id} "
                    f"box_raw={box} → pixel=({x1},{y1})-({x2},{y2}) "
                    f"size={x2-x1}x{y2-y1}px label={label}"
                )
            color = (0, 255, 0)  # BGR green
            cv2.rectangle(img_bgr, (x1, y1), (x2, y2), color, thickness=4)
            if label:
                cv2.putText(img_bgr, label, (x1, max(y1 - 10, 25)),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, thickness=2)
        return img_bgr

    def _build_info_md(self, r):
        clip_id = r["clip_id"]
        inter_dist = r["intersection_distance"]
        inter_info = r["intersection_info"]
        penalty = r["forbidden_penalty"]
        has_exit = r["has_exit_sign"]
        vgp = r["vla_goal_point"]
        forbidden_ids = r["forbidden_ids"]
        road_id_to_cls = r["road_id_to_cls"]
        gt_trajs = r.get("gt_ego_fut_trajs")

        # v4 binding fields
        exit_road_id = r.get("exit_road_id")
        exit_road_score = r.get("exit_road_score", -1.0)
        exit_road_debug = r.get("exit_road_debug", {})
        gt_road_bindings = r.get("gt_road_bindings", [])
        gt_binds_to_exit = r.get("gt_binds_to_exit", False)

        fb_str = ", ".join(
            f"{rid}({road_id_to_cls.get(rid, '?')})"
            for rid in sorted(forbidden_ids)
        ) if forbidden_ids else "(none)"

        inter_str = (
            f"**{inter_dist:.1f}m** (is_intersection={inter_info.get('is_intersection')}, "
            f"connected={inter_info.get('num_connected_roads', 0)}, "
            f"origin_road={inter_info.get('origin_road_id', '?')})"
            if inter_dist is not None else "N/A"
        )

        vgp_str = (
            f"({vgp.get('point_x', 0):.1f}, {vgp.get('point_y', 0):.1f}) "
            f"yaw={np.degrees(vgp.get('yaw', 0)):.1f}°"
            if vgp and vgp.get("point_x") is not None else "N/A"
        )

        gt_str = f"{len(gt_trajs)} pts" if gt_trajs else "N/A"

        # ── Exit road binding info ──
        if exit_road_id is not None:
            ed = exit_road_debug
            exit_cls = road_id_to_cls.get(exit_road_id, "?")
            exit_road_str = (
                f"**{exit_road_id}** ({exit_cls})  "
                f"score={exit_road_score:.3f}  "
                f"dist={ed.get('dist', '?')}m  "
                f"angle={ed.get('angle_deg', '?')}°"
            )
            # GT binds to exit road?
            gt_bind_icon = "✓ GT follows exit" if gt_binds_to_exit else "✗ GT does NOT follow exit"
        else:
            exit_road_str = "*(none)*"
            gt_bind_icon = "—"

        # ── GT segment binding list ──
        gt_bind_lines = []
        for b in gt_road_bindings:
            seg_idx = b["segment_idx"]
            rid = b.get("bound_road_id")
            info = b.get("binding_info")
            if rid is None:
                gt_bind_lines.append(f"  - seg#{seg_idx}: *unbound*")
            else:
                is_exit = " ★EXIT" if rid == exit_road_id else ""
                gt_bind_lines.append(
                    f"  - seg#{seg_idx} → **{rid}**"
                    f" (score={info['score']:.2f}, dist={info['dist']:.1f}m, "
                    f"angle={info['angle_deg']:.0f}°){is_exit}"
                )
        gt_bind_md = "\n".join(gt_bind_lines) if gt_bind_lines else "*(no bindings)*"

        total = len(self.rows)
        vis_pos = (self.visible.index(self.current_index) + 1
                   if self.current_index in self.visible else "?")

        exit_icon = "✓" if has_exit else "✗"

        return f"""
# Frame {self.current_index + 1} / {total}  (filtered #{vis_pos} / {len(self.visible)})

| Field | Value |
|-------|-------|
| **Clip ID** | `{clip_id}` |
| **Intersection distance** | {inter_str} |
| **Forbidden penalty** | **{penalty}** |
| **Has exit sign** | {exit_icon} |
| **Forbidden roads** | {fb_str} |
| **Goal point** | {vgp_str} |
| **GT trajectories** | {gt_str} |
| **Road classes** | `{r['select_road_cls']}` |

### 🏁 Exit Road (v4 goal→lane binding)

{exit_road_str}

{gt_bind_icon}

### 🔗 GT Trajectory → Road Bindings

{gt_bind_md}
"""

    def _build_stats_md(self):
        total = len(self.rows)
        vis = len(self.visible)
        lines = [f"## Statistics  (total={total}, visible={vis})\n"]
        lines.append("| Category | Count | w/ Exit Sign | w/ Exit Road | GT→Exit | Avg Inter Dist |")
        lines.append("|----------|-------|--------------|--------------|---------|----------------|")
        for key in sorted(self.stats.keys(), key=lambda k: -self.stats[k]["count"]):
            s = self.stats[key]
            avg_d = f"{np.mean(s['dists']):.1f}m" if s["dists"] else "N/A"
            lines.append(
                f"| {key} | {s['count']} | {s['has_exit']} | "
                f"{s['has_exit_road']} | {s['gt_binds_exit']} | {avg_d} |"
            )
        return "\n".join(lines)

    def _build_prompt_md(self, r):
        prompt = r.get("prompt_text", "")
        answer = r.get("answer", "")
        preview_p = prompt[:1200]
        preview_a = answer[:600]
        return f"""
### Prompt ({len(prompt)} chars)

<details open>
<summary>Preview</summary>

```text
{preview_p}
```
</details>

---

### GT Answer ({len(answer)} chars)

```text
{preview_a}
```
"""

    def update_display(self):
        if not self.rows or not self.visible:
            self.info_pane.object = "**No data**"
            self.bev_pane.object = None
            self.stats_pane.object = self._build_stats_md()
            return

        r = self.rows[self.current_index]

        # Images
        img_urls = self._load_images(r)
        cam_panes = {
            "FRONT": self.img_fw, "FRONT_NARROW": self.img_fn,
            "FRONT_LEFT": self.img_fl, "FRONT_RIGHT": self.img_fr,
        }
        for cam, pane in cam_panes.items():
            url = img_urls.get(cam, "")
            if url:
                pane.object = (
                    f'<div style="text-align:center;font-size:11px;font-weight:bold;'
                    f'margin-bottom:2px">{cam}</div>'
                    f'<img src="{url}" style="width:100%;border:1px solid #ccc;'
                    f'border-radius:4px" />'
                )
            else:
                pane.object = (
                    f'<div style="text-align:center;font-size:11px;font-weight:bold;'
                    f'margin-bottom:2px">{cam}</div>'
                    f'<div style="width:481px;height:271px;background:#eee;'
                    f'text-align:center;line-height:271px;color:#999">no image</div>'
                )

        # Info
        self.info_pane.object = self._build_info_md(r)

        # BEV
        try:
            self._build_bev_display(r)
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.bev_safe_lyr.update([], [])

        # Prompt/Answer
        self.prompt_pane.object = self._build_prompt_md(r)

        # Stats
        self.stats_pane.object = self._build_stats_md()

    def layout(self):
        nav = pn.Row(
            self.prev_btn, self.slider, self.next_btn,
            pn.Spacer(width=10), self.jump_input, self.jump_btn,
            styles={"background": "#ecf0f1", "padding": "10px",
                    "border-radius": "5px", "margin-bottom": "6px"},
        )
        filt = pn.Row(
            pn.pane.Markdown("**Filter:**", width=55),
            self.filter_key,
            pn.Spacer(width=20),
            self.filter_exit_only,
            styles={"background": "#fff3e0", "padding": "6px 10px",
                    "border-radius": "5px", "margin-bottom": "8px"},
        )

        # Image grid: 2×2
        img_grid = pn.Column(
            pn.Row(self.img_fw, self.img_fn),
            pn.Row(self.img_fl, self.img_fr),
        )

        left = pn.Column(
            img_grid,
            self.prompt_pane,
            width=1000,
            sizing_mode="stretch_height",
        )
        right = pn.Column(
            self.info_pane,
            pn.pane.Markdown("### BEV View"),
            self.bev_pane,
            self.stats_pane,
            width=700,
        )

        return pn.Column(
            nav, filt, pn.layout.Divider(),
            pn.Row(left, right, align="start"),
            sizing_mode="stretch_width",
        )


# ═══════════════════════════════════════════════════════════════════════════════
#  Main
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="Visualize VLA No-Entry parquet data with reward computation info")
    parser.add_argument(
        "parquet_path", nargs="?",
        default="/perception-hl/beijin.zhou/deeprl/260701_rl_exit_data_mined/vln2_cotv3_UG_PARKING_EXIT_20260701_0256_part0001_mined.parquet",
        help="Path to parquet file")
    parser.add_argument("--port", "-p", type=int, default=5007)
    parser.add_argument("--max-frames", "-n", type=int, default=500)
    args = parser.parse_args()

    if not os.path.exists(args.parquet_path):
        print(f"ERROR: file not found: {args.parquet_path}")
        sys.exit(1)

    viewer = ParquetRewardViewer(args.parquet_path, max_frames=args.max_frames)
    if not viewer.rows:
        print("ERROR: no rows loaded!")
        sys.exit(1)

    print(f"Loaded {len(viewer.rows)} rows")
    for k, v in viewer.stats.items():
        print(f"  {k}: {v['count']} frames, {v['has_exit']} w/ exit sign")

    # Allow cross-origin WebSocket connections (needed for remote access / port forwarding)
    os.environ.setdefault("BOKEH_ALLOW_WS_ORIGIN", "*")
    pn.extension()
    template = pn.template.FastListTemplate(
        title="VLA No-Entry Parquet Reward Visualizer",
        main=[viewer.layout()],
        accent_base_color="#1565c0",
        header_background="#0d47a1",
    )
    print(f"\nStarting at http://0.0.0.0:{args.port}")
    template.show(port=args.port, address="0.0.0.0")


if __name__ == "__main__":
    main()
