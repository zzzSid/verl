#!/usr/bin/env python3
"""
NIOVL 模型 vLLM 推理脚本 — 仅推理，不更新模型，不做 reward。

数据经过 verl/utils/dataset/rl_dataset.py (RLHFDataset) 处理后，
直接通过 vLLM 的 LLM.generate() 进行推理，输出模型的原始文本结果，
用于检查模型输出是否正确。

模式:
    - 标准模式 (默认): 使用 RLHFDataset 处理数据（和训练一致）
    - 简化模式 (--skip-dataset): 直接从 parquet 读取，用 vLLM 原生处理

用法:
    # 标准模式
    python tools/tools_bj/niovl_vllm_inference.py \
        --model-path /path/to/model \
        --data-path /path/to/data.parquet \
        --num-samples 3

    # 简化模式
    python tools/tools_bj/niovl_vllm_inference.py --skip-dataset --num-samples 3

也可以通过 shell 包装脚本运行:
    bash tools/tools_bj/niovl_vllm_inference.sh
"""

import argparse

# ═══════════════════════════════════════════════════════════════════════════════
# 强制使用 V0 引擎 + external_launcher，确保整个 vLLM 在当前进程运行，
# 避免 multiprocessing fork+CUDA 问题，同时也方便直接访问 model 做权重同步。
# 这与训练 pipeline (SPMD rollout) 的配置一致。
# external_launcher 需要 RANK / LOCAL_RANK / WORLD_SIZE 等分布式环境变量。
# ═══════════════════════════════════════════════════════════════════════════════
import os as _os
_os.environ.setdefault('VLLM_USE_V1', '0')
_os.environ.setdefault('RANK', '0')
_os.environ.setdefault('LOCAL_RANK', '0')
_os.environ.setdefault('WORLD_SIZE', '1')
_os.environ.setdefault('MASTER_ADDR', '127.0.0.1')
_os.environ.setdefault('MASTER_PORT', '29500')
import json
import os
import sys
import time
from typing import List

import numpy as np

# ═══════════════════════════════════════════════════════════════════════════════
# 将项目根目录加入 sys.path，确保 verl、tools 等模块可被 import
# ═══════════════════════════════════════════════════════════════════════════════
_PROJECT_ROOT = os.path.dirname(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
)
for _p in (
    _PROJECT_ROOT,                    # 项目根目录
    os.getcwd(),                      # 当前工作目录
    os.path.join(_PROJECT_ROOT, "tools"),   # tools 目录
):
    _rp = os.path.realpath(_p)
    if _rp not in sys.path:
        sys.path.insert(0, _rp)

# 这行 import 会触发模型注册:
#   1. AutoConfig.register("niovl", NIOVLConfig)
#   2. ModelRegistry.register_model("NIOVLModel", InternVLChatModel)
from verl.utils.tokenizer import hf_tokenizer, hf_processor  # noqa: E402

from omegaconf import DictConfig
from vllm import LLM, SamplingParams

from verl.utils.dataset.rl_dataset import RLHFDataset  # noqa: E402

# ═══════════════════════════════════════════════════════════════════════════════
# 默认路径
# ═══════════════════════════════════════════════════════════════════════════════

DEFAULT_MODEL_PATH = (
    "/perception-hl/beijin.zhou/ali_data/vla-work-dirs/"
    "l2_models/260606_no_entry_repeat_no_cot_pos-20260606-003727"
)
DEFAULT_DATA_PATH = (
    "/perception-hl/beijin.zhou/deeprl/v1_data/"
    "vla_train_out_no_entry_260526_train__df5f809__20260528070111_"
    "part2_part0000_severe_error.parquet"
)

# ═══════════════════════════════════════════════════════════════════════════════
# 参数解析
# ═══════════════════════════════════════════════════════════════════════════════


def parse_args():
    parser = argparse.ArgumentParser(
        description="NIOVL vLLM 推理 — 查看模型输出是否正确",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--model-path", type=str, default=DEFAULT_MODEL_PATH)
    parser.add_argument("--data-path", type=str, default=DEFAULT_DATA_PATH)
    parser.add_argument("--num-samples", type=int, default=3000)
    parser.add_argument("--start-index", type=int, default=0)
    parser.add_argument("--max-response-length", type=int, default=64)
    parser.add_argument("--max-prompt-length", type=int, default=4096)
    parser.add_argument("--gpu-memory-utilization", type=float, default=0.3)
    parser.add_argument("--tensor-parallel-size", type=int, default=1)
    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--top-p", type=float, default=1.0)
    parser.add_argument("--output-dir", type=str, default="/tmp/niovl_inference")
    parser.add_argument("--enforce-eager", action="store_true", default=False)
    parser.add_argument(
        "--skip-dataset",
        action="store_true",
        default=False,
        help="跳过 RLHFDataset，直接从 parquet 读取用 vLLM 原生处理",
    )
    return parser.parse_args()


# ═══════════════════════════════════════════════════════════════════════════════
# 配置 & 加载
# ═══════════════════════════════════════════════════════════════════════════════


def resolve_data_paths(data_path: str) -> List[str]:
    """解析数据路径，支持:
      1. 单个 .parquet 文件路径
      2. JSON 索引文件 (格式: {"key": {"parquet_root": "path/to.parquet"}, ...})
      返回 parquet 路径列表.
    """
    if not data_path.endswith(".json"):
        return [data_path]

    with open(data_path, "r", encoding="utf-8") as f:
        index = json.load(f)

    paths = []
    for key, val in index.items():
        if isinstance(val, str):
            paths.append(val)
        elif isinstance(val, dict):
            paths.append(val.get("parquet_root", val.get("parquet_path", "")))
        else:
            raise TypeError(f"Unsupported index entry type for key '{key}': {type(val)}")

    # 去重并保持顺序
    seen = set()
    unique = []
    for p in paths:
        if p and p not in seen:
            seen.add(p)
            unique.append(p)

    print(f"Resolved {len(unique)} parquet paths from index: {data_path}")
    return unique


def create_dataset_config(args) -> DictConfig:
    """构建 RLHFDataset 需要的配置."""
    return DictConfig({
        "cache_dir": os.path.expanduser("~/.cache/verl/rlhf"),
        "prompt_key": "prompt",
        "image_key": "image",
        "video_key": "videos",
        "max_prompt_length": args.max_prompt_length,
        "return_raw_chat": False,
        "return_full_prompt": False,
        "truncation": "error",
        "filter_overlong_prompts": False,
        "filter_overlong_prompts_workers": 1,
        "chat_template_func": None,
        "need_tools_kwargs": False,
        "filter_prompts": False,
        "enable_visualization": False,
        "enable_data_analysis": False,
    })


def load_model_and_tokenizer(model_path: str, args):
    """加载 tokenizer / processor 和 vLLM LLM 实例."""
    print("=" * 70)
    print("Loading tokenizer & processor ...")
    print(f"  model_path: {model_path}")

    tokenizer = hf_tokenizer(model_path, trust_remote_code=True)
    processor = hf_processor(model_path, use_fast=True, trust_remote_code=True)

    print(f"  tokenizer: {type(tokenizer).__name__}")
    print(f"  processor: {type(processor).__name__}")
    print(f"  pad_token_id:  {tokenizer.pad_token_id}")
    print(f"  eos_token_id:  {tokenizer.eos_token_id}")

    # ── 创建 vLLM LLM 实例 ──
    # 使用 distributed_executor_backend="external_launcher" 让 vLLM 在当前进程运行，
    # 避免 multiprocessing fork+CUDA 问题（和训练 pipeline 的 SPMD rollout 一致）。
    # 同时使用 load_format="dummy" 跳过 checkpoint 直接加载，
    # 因为 checkpoint 中 adaptor_model.mlp1.* 等键名与 vLLM 的 InternVLChatModel
    # （mlp1.*，无 adaptor_model 前缀）不匹配，需要手动加载并 remap。
    print()
    print("Creating vLLM LLM instance (in-process executor, dummy weights) ...")
    print(f"  tensor_parallel_size:  {args.tensor_parallel_size}")
    print(f"  gpu_memory_utilization: {args.gpu_memory_utilization}")
    print(f"  enforce_eager:          {args.enforce_eager}")

    max_model_len = args.max_prompt_length + args.max_response_length
    llm = LLM(
        model=model_path,
        tensor_parallel_size=args.tensor_parallel_size,
        distributed_executor_backend="external_launcher",
        dtype="bfloat16",
        enforce_eager=args.enforce_eager,
        gpu_memory_utilization=args.gpu_memory_utilization,
        trust_remote_code=True,
        max_model_len=max_model_len,
        disable_mm_preprocessor_cache=True,
        skip_tokenizer_init=False,
        enable_prefix_caching=True,
        load_format="dummy",
        seed=0,
        limit_mm_per_prompt={"image": 35},
    )

    # ── 加载真实权重：通过 NIOVLModel 加载 checkpoint，remap 后同步到 vLLM ──
    _sync_real_weights(llm, model_path)

    print(f"  vLLM LLM ready.")
    print()
    return tokenizer, processor, llm


def _sync_real_weights(llm, model_path: str):
    """用 NIOVLModel 加载 checkpoint 权重并同步到 vLLM。

    NIOVLModel 的 state_dict 有 adaptor_model.mlp1.* 等前缀，
    而 vLLM 的 InternVLChatModel 用的是 mlp1.*（无 adaptor_model. 前缀）。
    我们在此手动去掉 adaptor_model. 前缀后，调用 vLLM 的 load_weights。
    """
    print("  Loading real weights from checkpoint into vLLM ...")
    from verl.mlm.niovl import NIOVLModel

    # 用 NIOVLModel 加载 checkpoint（它会正确处理 adaptor_model 前缀）
    hf_model = NIOVLModel.from_pretrained(
        model_path,
        trust_remote_code=True,
        torch_dtype="bfloat16",
        device_map="cpu",
    )

    # 构建去掉 adaptor_model. 前缀的 state_dict
    renamed_weights = []
    for key, tensor in hf_model.state_dict().items():
        # strip adaptor_model. prefix so vLLM InternVLChatModel can match
        if key.startswith("adaptor_model."):
            key = key[len("adaptor_model."):]
        renamed_weights.append((key, tensor))

    # 同步到 vLLM
    model_runner = llm.llm_engine.model_executor.driver_worker.worker.model_runner
    vllm_model = model_runner.model
    loaded = vllm_model.load_weights(renamed_weights)
    print(f"  Loaded {len(loaded)} weight tensors into vLLM")

    # 释放 HF 模型内存
    del hf_model


def load_dataset(data_path: str, tokenizer, processor, config: DictConfig):
    """通过 RLHFDataset 加载并处理数据."""
    print("=" * 70)
    print("Loading dataset via RLHFDataset ...")
    print(f"  data_path: {data_path}")

    dataset = RLHFDataset(
        data_files=[data_path],
        tokenizer=tokenizer,
        processor=processor,
        config=config,
    )
    print(f"  dataset len: {len(dataset)}")
    print()
    return dataset


# ═══════════════════════════════════════════════════════════════════════════════
# 标准模式推理 (使用 RLHFDataset 的预处理结果)
# ═══════════════════════════════════════════════════════════════════════════════


def run_vllm_inference(
    llm: LLM,
    dataset: RLHFDataset,
    tokenizer,
    args,
    raw_df=None,  # 原始 parquet dataframe，用于 reward 计算
) -> List[dict]:
    """遍历 RLHFDataset，用 vLLM 推理，返回结果列表.

    RLHFDataset 预处理的数据包括:
        - raw_prompt_ids:   tokenized prompt (已根据 num_tiles 展开 <image>)
        - raw_prompt_text:  展开后的 prompt 文本
        - multi_modal_data: {"image": [PIL-tile-0, PIL-tile-1, ...] — 预切分的 tile

    如果传入了 raw_df，会对每个样本调用 vla_no_entry_reward 计算 reward，
    debug=True 会自动保存 pkl 文件到 /tmp/vla_reward_debug/。
    """
    # 加载 reward 函数
    from verl.utils.reward_score.vla_no_entry_v1 import vla_no_entry_reward

    sampling_params = SamplingParams(
        n=1,
        temperature=args.temperature,
        top_p=args.top_p,
        max_tokens=args.max_response_length,
        detokenize=False,
    )

    num_samples = min(args.num_samples, len(dataset))
    results = []

    print("=" * 70)
    print(f"Running inference on {num_samples} samples ...")
    print(f"  temperature:  {args.temperature}")
    print(f"  max_tokens:   {args.max_response_length}")
    print(f"  reward:       {'enabled' if raw_df is not None else 'disabled'}")
    print("=" * 70)

    for i in range(args.start_index, args.start_index + num_samples):
        sample_idx = i
        seq = i - args.start_index + 1
        print(f"\n{'─' * 70}")
        print(f"[Sample {seq}/{num_samples}]  dataset index={sample_idx}")
        print(f"{'─' * 70}")

        # ── 获取 RLHFDataset 处理后的数据 ──
        try:
            row_dict = dataset[sample_idx]
        except Exception as e:
            print(f"  ⚠  Dataset __getitem__ 失败: {e}")
            results.append({"index": sample_idx, "error": str(e)})
            continue

        raw_prompt_ids = row_dict["raw_prompt_ids"]
        multi_modal_data = row_dict.get("multi_modal_data", {})
        raw_prompt_text = row_dict.get("raw_prompt_text")

        num_images = len(multi_modal_data.get("image", []))
        print(f"  prompt_token_ids:  {len(raw_prompt_ids)} tokens")
        print(f"  tiles (images):    {num_images}")
        if raw_prompt_text:
            n_image_tags = raw_prompt_text.count("<image>")
            print(f"  <image> in prompt: {n_image_tags}")
            print(f"  prompt head:       {raw_prompt_text[:200]}...")

        # ── 构建 vLLM 输入 (TokensPrompt 格式，和 SPMD rollout 一致) ──
        vllm_input = {
            "prompt_token_ids": (
                raw_prompt_ids.tolist()
                if isinstance(raw_prompt_ids, np.ndarray)
                else list(raw_prompt_ids)
            ),
            "multi_modal_data": multi_modal_data,
        }
        # 同时传入 raw prompt text，让 vLLM 的多模态处理器据此定位 <image>
        if raw_prompt_text:
            vllm_input["prompt"] = raw_prompt_text

        # ── 推理 ──
        t_start = time.time()
        try:
            outputs = llm.generate(
                prompts=[vllm_input],
                sampling_params=sampling_params,
                use_tqdm=False,
            )
        except Exception as e:
            print(f"  ⚠  vLLM generate 失败: {e}")
            import traceback
            traceback.print_exc()
            results.append({"index": sample_idx, "error": str(e)})
            continue
        t_elapsed = time.time() - t_start

        output = outputs[0]
        response_ids = output.outputs[0].token_ids

        # ── 解码 ──
        response_text = tokenizer.decode(response_ids, skip_special_tokens=False)
        response_text_clean = tokenizer.decode(response_ids, skip_special_tokens=True)

        # 截断到 <|im_end|>
        if "<|im_end|>" in response_text:
            response_text = response_text.split("<|im_end|>")[0]

        print(f"  ⏱  elapsed:         {t_elapsed:.2f}s")
        print(f"  📝 num tokens:      {len(response_ids)}")
        print(f"  📝 raw response:    {repr(response_text)}")
        print(f"  📝 clean response:  {repr(response_text_clean)}")

        # ── 计算 reward（仿照 verl 训练 pipeline）──
        reward_result = None
        if raw_df is not None and sample_idx < len(raw_df):
            try:
                row = raw_df.iloc[sample_idx]
                data_source = row.get("data_source", "unknown")
                ground_truth = row.get("reward_model", {}).get("ground_truth", [])
                extra_info = row.get("extra_info", {})

                reward_result = vla_no_entry_reward(
                    data_source=data_source,
                    solution_str=response_text,  # 用 raw 版本，保留 <action_N> 等 special token
                    ground_truth=ground_truth,
                    extra_info=extra_info,
                    debug=True,
                )
                score = reward_result.get("score", "?")
                reason = reward_result.get("reason", "?")
                print(f"  🎯 reward score:    {score}")
                print(f"  🎯 reward reason:   {reason}")
            except Exception as e:
                print(f"  ⚠  Reward computation failed: {e}")
                reward_result = {"error": str(e)}

        # 从 parquet / dataset 中提取 evaluator 兼容字段
        extra_info = row_dict.get("extra_info", {})
        clip_id = str(
            extra_info.get("clip_id",
            row_dict.get("tools_kwargs", {}).get("clip_id", "unknown"))
        )
        question_text = extra_info.get("question", raw_prompt_text or "")
        answer_text = extra_info.get("answer", "")

        # 如果 extra_info.answer 为空，尝试从 raw_df 中获取
        if not answer_text and raw_df is not None and sample_idx < len(raw_df):
            row = raw_df.iloc[sample_idx]
            answer_text = row.get("reward_model", {}).get("ground_truth", "")
            if not answer_text:
                answer_text = row.get("extra_info", {}).get("answer", "")

        # 提取 traj_label（真值轨迹）
        traj_label = None
        if raw_df is not None and sample_idx < len(raw_df):
            row = raw_df.iloc[sample_idx]
            traj_label = row.get("extra_info", {}).get("gt_ego_fut_trajs")
            if traj_label is None:
                traj_label = row.get("gt_ego_fut_trajs")

        # 原始图像路径（用于 evaluator 输出）
        image_paths = None
        if raw_df is not None and sample_idx < len(raw_df):
            row = raw_df.iloc[sample_idx]
            image_paths = row.get("image")

        results.append({
            "index": sample_idx,
            "clip_id": clip_id,
            "qa_id": 0,
            "question": question_text,
            "answer": answer_text,
            "image": image_paths,
            "traj_label": traj_label,
            "prompt_length": len(raw_prompt_ids),
            "num_tiles": num_images,
            "response_ids": response_ids,
            "response_text": response_text,
            "response_text_clean": response_text_clean,
            "inference_time_s": round(t_elapsed, 3),
            "reward": reward_result,
            "error": None,
        })

    print(f"\n{'=' * 70}")
    print(f"Inference done. {len(results)} samples processed.")
    print(f"{'=' * 70}")
    return results


# ═══════════════════════════════════════════════════════════════════════════════
# 简化模式推理 (不用 RLHFDataset，直接 vLLM 原生处理)
# ═══════════════════════════════════════════════════════════════════════════════


def run_vllm_inference_simple(
    llm: LLM,
    data_path: str,
    tokenizer,
    processor,
    args,
) -> List[dict]:
    """简化版推理：直接从 parquet 读取，用 vLLM 原生多模态处理。

    这个版本不使用 RLHFDataset 的预切分逻辑：
      1. 从 parquet 读取 messages + 原始图像路径
      2. 通过 RLHFDataset.load_image() 加载图像（处理 Ceph 路径）
      3. 构建纯文本 prompt（chat template）+ 图像列表
      4. 交给 vLLM 全权处理（tokenize + 图像切分 + 推理）
    """
    import pandas as pd

    sampling_params = SamplingParams(
        n=1,
        temperature=args.temperature,
        top_p=args.top_p,
        max_tokens=args.max_response_length,
        detokenize=False,
    )

    print("=" * 70)
    print("Loading parquet directly (simple mode) ...")
    print(f"  data_path: {data_path}")

    df = pd.read_parquet(data_path)
    print(f"  total samples: {len(df)}")
    num_samples = min(args.num_samples, len(df))
    results = []

    # 创建一个临时 dataset 实例，只用于调 load_image 方法
    _tmp_config = DictConfig({
        "cache_dir": os.path.expanduser("~/.cache/verl/rlhf"),
        "prompt_key": "prompt",
        "image_key": "image",
        "video_key": "videos",
        "max_prompt_length": args.max_prompt_length,
        "filter_overlong_prompts": False,
        "filter_overlong_prompts_workers": 1,
        "chat_template_func": None,
        "need_tools_kwargs": False,
        "filter_prompts": False,
        "enable_visualization": False,
        "enable_data_analysis": False,
    })
    # 用同一个 data_path 初始化 dataset，但不真正使用其 __getitem__
    _tmp_dataset = RLHFDataset(
        data_files=[data_path],
        tokenizer=tokenizer,
        processor=processor,
        config=_tmp_config,
    )

    for i in range(args.start_index, args.start_index + num_samples):
        sample_idx = i
        seq = i - args.start_index + 1
        print(f"\n{'─' * 70}")
        print(f"[Sample {seq}/{num_samples}]  row index={sample_idx}")
        print(f"{'─' * 70}")

        try:
            row = df.iloc[sample_idx]
        except Exception as e:
            print(f"  ⚠  Read failed: {e}")
            results.append({"index": sample_idx, "error": str(e)})
            continue

        # ── 构建 messages ──
        prompt_data = row["prompt"]
        if isinstance(prompt_data, np.ndarray):
            messages = prompt_data.tolist()
        else:
            messages = list(prompt_data)

        # 添加 system message（与训练一致）
        if not any(m.get("role") == "system" for m in messages):
            messages.insert(0, {
                "role": "system",
                "content": (
                    "你是由蔚来汽车大模型团队开发的自动驾驶多模态大模型，"
                    "英文名叫NIOVL, 是一个有用无害的人工智能助手。"
                ),
            })

        # ── 加载图像 (通过 RLHFDataset.load_image 处理 Ceph 路径) ──
        images_raw = row["image"]
        images = []
        for img_path in images_raw:
            try:
                img = _tmp_dataset.load_image(img_path)
                images.append(img)
            except Exception as e:
                print(f"  ⚠  load_image failed: {e}  (path: {str(img_path)[:80]}...)")
                from PIL import Image as PILImage
                images.append(PILImage.new("RGB", (512, 512), color=(128, 128, 128)))

        print(f"  messages: {len(messages)} turns, roles: {[m['role'] for m in messages]}")
        print(f"  images:   {len(images)} loaded")

        # ── Apply chat template 得到纯文本 prompt ──
        prompt_text = tokenizer.apply_chat_template(
            messages,
            add_generation_prompt=True,
            tokenize=False,
        )
        n_image_tags = prompt_text.count("<image>")
        print(f"  <image> in prompt: {n_image_tags}")
        print(f"  prompt head:       {prompt_text[:200]}...")

        # ── 构建 vLLM 输入 (TextPrompt 格式 + multi_modal_data) ──
        vllm_input = {
            "prompt": prompt_text,
            "multi_modal_data": {"image": images},
        }

        # ── 推理 ──
        t_start = time.time()
        try:
            outputs = llm.generate(
                prompts=[vllm_input],
                sampling_params=sampling_params,
                use_tqdm=False,
            )
        except Exception as e:
            print(f"  ⚠  vLLM generate 失败: {e}")
            import traceback
            traceback.print_exc()
            results.append({"index": sample_idx, "error": str(e)})
            continue
        t_elapsed = time.time() - t_start

        output = outputs[0]
        response_ids = output.outputs[0].token_ids

        # ── 解码 ──
        response_text = tokenizer.decode(response_ids, skip_special_tokens=False)
        response_text_clean = tokenizer.decode(response_ids, skip_special_tokens=True)

        if "<|im_end|>" in response_text:
            response_text = response_text.split("<|im_end|>")[0]

        print(f"  ⏱  elapsed:         {t_elapsed:.2f}s")
        print(f"  📝 num tokens:      {len(response_ids)}")
        print(f"  📝 raw response:    {repr(response_text)}")
        print(f"  📝 clean response:  {repr(response_text_clean)}")

        # 从 parquet 中提取 evaluator 兼容字段
        extra_info = row.get("extra_info", {}) if isinstance(row.get("extra_info"), dict) else {}
        question_text = extra_info.get("question", prompt_text)
        answer_text = extra_info.get("answer", "")
        if not answer_text:
            answer_text = row.get("reward_model", {}).get("ground_truth", "")
        traj_label = extra_info.get("gt_ego_fut_trajs") or row.get("gt_ego_fut_trajs")
        image_paths = row.get("image")

        results.append({
            "index": sample_idx,
            "clip_id": str(row.get("clip_id", "unknown")),
            "qa_id": 0,
            "question": question_text,
            "answer": answer_text,
            "image": image_paths,
            "traj_label": traj_label,
            "num_images": len(images),
            "prompt_length": len(prompt_text),
            "response_ids": response_ids,
            "response_text": response_text,
            "response_text_clean": response_text_clean,
            "inference_time_s": round(t_elapsed, 3),
            "error": None,
        })

    print(f"\n{'=' * 70}")
    print(f"Inference (simple mode) done. {len(results)} samples processed.")
    print(f"{'=' * 70}")
    return results


# ═══════════════════════════════════════════════════════════════════════════════
# 结果输出
# ═══════════════════════════════════════════════════════════════════════════════


def _to_json_safe(val):
    """递归转换 numpy 类型为 Python 原生类型，确保 JSON 可序列化."""
    if isinstance(val, (np.ndarray,)):
        # object dtype 的 ndarray 用 .tolist() 可能残留嵌套 ndarray，需递归处理
        return _to_json_safe(val.tolist())
    if isinstance(val, (np.integer,)):
        return int(val)
    if isinstance(val, (np.floating,)):
        return float(val)
    if isinstance(val, (np.bool_,)):
        return bool(val)
    if isinstance(val, dict):
        return {k: _to_json_safe(v) for k, v in val.items()}
    if isinstance(val, (list, tuple)):
        return [_to_json_safe(v) for v in val]
    return val


def save_results(results: List[dict], output_dir: str, args):
    """保存推理结果到 JSONL（与 mlm-evaluator NIOBenchInference 输出格式一致）。

    输出文件: inference_result.jsonl
    每行一个 JSON 对象，字段对齐 evaluator 的 NIOBenchInference 输出格式:
        clip_id, qa_id, question_atom_type, plot_info, image, question,
        answer, prediction, traj_label, [prompt_suffix], [extra]
    """
    os.makedirs(output_dir, exist_ok=True)

    jsonl_path = os.path.join(output_dir, "inference_result.jsonl")
    with open(jsonl_path, "w", encoding="utf-8") as f:
        for r in results:
            line = {
                "clip_id": r.get("clip_id", "unknown"),
                "qa_id": r.get("qa_id", 0),
                "question_atom_type": r.get("question_atom_type"),
                "plot_info": r.get("plot_info"),
                "image": r.get("image", r.get("image_paths")),
                "question": r.get("question", ""),
                "answer": r.get("answer", ""),
                "prediction": r.get("response_text", "") if not r.get("error") else "",
                "traj_label": r.get("traj_label"),
            }

            # 如果有 prompt_suffix（如 <COT>, <NO_COT>）
            if r.get("prompt_suffix"):
                line["prompt_suffix"] = r["prompt_suffix"]

            # 如果有多轮推理结果，放入 extra
            if r.get("extra"):
                line["extra"] = r["extra"]

            # reward 结果放入 extra（便于后续分析）
            if r.get("reward"):
                rw = r["reward"]
                line.setdefault("extra", {})
                line["extra"]["reward"] = {
                    "score": rw.get("score"),
                    "reason": rw.get("reason"),
                }

            # 错误样本：prediction 为空，附上 error 信息
            if r.get("error"):
                line.setdefault("extra", {})
                line["extra"]["error"] = r["error"]

            f.write(json.dumps(_to_json_safe(line), ensure_ascii=False) + "\n")

    print(f"Results saved to: {jsonl_path}  ({len(results)} samples)")


def save_results_txt(results: List[dict], output_dir: str, args):
    """保存可读的 TXT 摘要（辅助调试）。"""
    txt_path = os.path.join(output_dir, "inference_results.txt")
    with open(txt_path, "w", encoding="utf-8") as f:
        f.write("=" * 70 + "\n")
        f.write("NIOVL vLLM Inference Results\n")
        f.write(f"Model:  {args.model_path}\n")
        f.write(f"Data:   {args.data_path}\n")
        f.write(f"Samples: {len(results)}\n")
        f.write("=" * 70 + "\n\n")
        for r in results:
            f.write(f"{'─' * 70}\n")
            f.write(f"Sample Index: {r['index']}\n")
            f.write(f"Clip ID:      {r.get('clip_id', 'N/A')}\n")
            if r.get("error"):
                f.write(f"ERROR:        {r['error']}\n\n")
                continue
            f.write(f"Num Images:   {r.get('num_images', r.get('num_tiles', 'N/A'))}\n")
            f.write(f"Inference:    {r.get('inference_time_s', 'N/A')}s\n")
            reward = r.get("reward")
            if reward:
                f.write(f"Reward Score: {reward.get('score', '?')}\n")
                f.write(f"Reward Reason: {reward.get('reason', '?')}\n")
            f.write(f"\n--- Raw Response ---\n")
            f.write(r.get("response_text", "N/A"))
            f.write(f"\n--- Clean Response ---\n")
            f.write(r.get("response_text_clean", "N/A"))
            f.write("\n\n")
    print(f"Text summary saved to: {txt_path}")


def print_summary(results: List[dict]):
    """打印最终的汇总表."""
    print("\n" + "=" * 70)
    print("SUMMARY")
    print("=" * 70)
    for r in results:
        idx = r["index"]
        err = r.get("error")
        if err:
            print(f"  [{idx}] ERROR: {err}")
        else:
            resp = r.get("response_text_clean", r.get("response_text", ""))
            disp = resp[:120] + "..." if len(resp) > 120 else resp
            clip = r.get("clip_id", "?")
            n_tok = len(r.get("response_ids", []))
            reward = r.get("reward")
            score_str = f" | score={reward['score']} {reward['reason']}" if reward else ""
            print(f"  [{idx}] clip={clip} | tokens={n_tok}{score_str} | {repr(disp)}")

    success = [r for r in results if not r.get("error")]
    failed = [r for r in results if r.get("error")]
    print(f"\nSuccess: {len(success)}  Failed: {len(failed)}")
    if success:
        avg_tok = sum(len(r.get("response_ids", [])) for r in success) / len(success)
        avg_t = sum(r.get("inference_time_s", 0) for r in success) / len(success)
        print(f"Avg tokens: {avg_tok:.1f}  Avg time: {avg_t:.2f}s")


# ═══════════════════════════════════════════════════════════════════════════════
# 主入口
# ═══════════════════════════════════════════════════════════════════════════════


def main():
    args = parse_args()

    # 解析数据路径（支持 JSON 索引文件 → 多个 parquet）
    parquet_paths = resolve_data_paths(args.data_path)
    print(f"Data paths: {len(parquet_paths)} parquet file(s)")

    tokenizer, processor, llm = load_model_and_tokenizer(args.model_path, args)

    all_results = []
    samples_per_file = max(1, args.num_samples // len(parquet_paths)) if parquet_paths else args.num_samples

    for parquet_path in parquet_paths:
        print(f"\n{'#' * 70}")
        print(f"# Processing: {parquet_path}")
        print(f"{'#' * 70}")

        if args.skip_dataset:
            results = run_vllm_inference_simple(
                llm=llm,
                data_path=parquet_path,
                tokenizer=tokenizer,
                processor=processor,
                args=args,
            )
        else:
            import pandas as pd
            dataset_config = create_dataset_config(args)
            dataset = load_dataset(parquet_path, tokenizer, processor, dataset_config)
            raw_df = pd.read_parquet(parquet_path)

            # 每个 parquet 只推理 samples_per_file 条（除非 num_samples=0 表示全部）
            file_args = argparse.Namespace(**vars(args))
            file_args.num_samples = samples_per_file
            # start_index 仅对第一个 parquet 有效，后续从 0 开始
            if parquet_path != parquet_paths[0]:
                file_args.start_index = 0

            results = run_vllm_inference(
                llm=llm,
                dataset=dataset,
                tokenizer=tokenizer,
                args=file_args,
                raw_df=raw_df,
            )

        all_results.extend(results)

        # 如果已经收集够了，停止
        if args.num_samples > 0 and len(all_results) >= args.num_samples:
            all_results = all_results[:args.num_samples]
            break

    print(f"\n{'#' * 70}")
    print(f"# Total: {len(all_results)} samples from {len(parquet_paths)} parquet file(s)")
    print(f"{'#' * 70}")

    save_results(all_results, args.output_dir, args)
    save_results_txt(all_results, args.output_dir, args)
    print_summary(all_results)


if __name__ == "__main__":
    main()
