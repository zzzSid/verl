"""
交叉路口检测与筛选模块。

用于出口/no_entry 数据的预处理：在 PKL → parquet 转换前，筛选出在交叉路口
附近（默认 0~15m）的帧，对于 exit 数据额外排除连接路全是出口路的情况。

对于 exit 数据：
  - 路网来源：extra.vla_road_construction_info → road_link_id
  - 出口路判断：通过 GT answer 计算 exit_path_road_ids
  - 过滤：距离交叉口在阈值内，且连接路不全是出口路

对于 no_entry 数据：
  - 路网来源：extra.road_graphs
  - 过滤：距离交叉口在阈值内
"""

import json
import numpy as np
from typing import Dict, List, Tuple, Optional


# ═══════════════════════════════════════════════════════════════════════════════
#  Geometry helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _min_distance_point_to_polyline(point, polyline):
    """计算点到折线的最小距离及最近点。"""
    point = np.asarray(point, dtype=float)
    min_dist = float('inf')
    closest_pt = None
    for i in range(len(polyline) - 1):
        a = polyline[i]
        b = polyline[i + 1]
        ab = b - a
        ab_len_sq = np.dot(ab, ab)
        if ab_len_sq < 1e-12:
            dist = np.linalg.norm(point - a)
            if dist < min_dist:
                min_dist = dist
                closest_pt = a.copy()
            continue
        t = np.dot(point - a, ab) / ab_len_sq
        t = max(0.0, min(1.0, t))
        closest = a + t * ab
        dist = np.linalg.norm(point - closest)
        if dist < min_dist:
            min_dist = dist
            closest_pt = closest.copy()
    return min_dist, closest_pt


def _find_nearest_road_to_point(point, all_road_geoms):
    """找到离给定点最近的道路。返回 (road_id, min_dist, closest_pt)。"""
    best_road_id = None
    best_dist = float('inf')
    best_pt = None
    point_arr = np.asarray(point, dtype=float)
    for road_id, geom in all_road_geoms.items():
        d, pt = _min_distance_point_to_polyline(point_arr, geom)
        if d < best_dist:
            best_dist = d
            best_pt = pt
            best_road_id = road_id
    return best_road_id, best_dist, best_pt


# ═══════════════════════════════════════════════════════════════════════════════
#  Road geometry extraction
# ═══════════════════════════════════════════════════════════════════════════════

def get_road_geometries(extra: dict, ds_type: str = "exit") -> Dict:
    """根据 ds_type 从 extra 中提取道路几何。

    - exit: 从 vla_road_construction_info 提取，road_id = road_link_id
    - no_entry: 从 road_graphs 提取

    Returns: {road_id: np.array([[x,y], ...]), ...}
    """
    if ds_type == 'exit':
        vla_road_construction_info = extra.get('vla_road_construction_info', {})
        if not isinstance(vla_road_construction_info, dict):
            return {}
        all_road_geoms = {}
        vla_road_info = vla_road_construction_info.get("vla_road_info", [])
        if isinstance(vla_road_info, list):
            for road in vla_road_info:
                road_id = road.get("road_link_id", "")
                way_points = road.get("road_way_point", [])
                if len(way_points) > 1:
                    geo = np.array([[wp["point_x"], wp["point_y"]] for wp in way_points], dtype=float)
                    all_road_geoms[road_id] = geo
        return all_road_geoms
    else:
        road_graphs = extra.get('road_graphs') or {}
        geometries = {}
        for road_id, road_info in road_graphs.items():
            if road_info and 'geometry' in road_info:
                geom = np.array(road_info['geometry'], dtype=float)
                if len(geom) >= 2:
                    geometries[road_id] = geom
        return geometries


# ═══════════════════════════════════════════════════════════════════════════════
#  Exit path road IDs
# ═══════════════════════════════════════════════════════════════════════════════

def compute_exit_path_road_ids(answer_raw: str,
                                vla_road_construction_info: dict,
                                multi_groups: list) -> set:
    """从 GT answer 计算出口路径上的道路 ID 集合。

    1. 解析 GT answer 中的 action trajectory
    2. 从 vla_road_construction_info 构建道路几何
    3. 将 GT 轨迹 segment 绑定到道路
    4. 去除距离原点最近的道路（起点位置）
    5. 加入 multi_groups 中的 road_id
    """
    from verl.utils.reward_score.vla_no_entry_v1 import (
        parse_action_traj,
        action_traj_to_abs,
        bind_segment_to_road,
    )

    # 1. Parse action trajectory from GT answer
    action_traj = parse_action_traj(answer_raw)
    if action_traj is None:
        return set()

    abs_traj = action_traj_to_abs(action_traj)
    if abs_traj is None or len(abs_traj) < 2:
        return set()

    # 2. Build road geometries from vla_road_construction_info
    all_road_geoms = {}
    vla_road_info = vla_road_construction_info.get("vla_road_info", [])
    if isinstance(vla_road_info, list):
        for road in vla_road_info:
            road_id = road.get("road_link_id", "")
            way_points = road.get("road_way_point", [])
            if len(way_points) > 1:
                geo = np.array([[wp["point_x"], wp["point_y"]] for wp in way_points], dtype=float)
                all_road_geoms[road_id] = geo

    if not all_road_geoms:
        return set()

    # 3. Bind trajectory segments to roads (prepend origin)
    origin = np.array([0.0, 0.0])
    full_traj = np.vstack([origin, abs_traj])

    bound_road_ids = set()
    for i in range(len(full_traj) - 2):
        segment = full_traj[i:i + 3]
        road_id, _ = bind_segment_to_road(segment, all_road_geoms)
        if road_id is not None:
            bound_road_ids.add(road_id)

    # 4. Remove the road closest to origin (starting position)
    origin_road_id, _, _ = _find_nearest_road_to_point(origin, all_road_geoms)
    if origin_road_id is not None:
        bound_road_ids.discard(origin_road_id)

    # 5. Add multi_groups road IDs
    for item in multi_groups:
        rid = item.get("road_id")
        if rid:
            bound_road_ids.add(rid)

    return bound_road_ids


# ═══════════════════════════════════════════════════════════════════════════════
#  Intersection detection
# ═══════════════════════════════════════════════════════════════════════════════

def detect_intersection(
    all_road_geoms: Dict,
    near_threshold: Tuple[float, float] = (0.0, 15.0),
    endpoint_dist_threshold: float = 2.0,
    min_connected_roads: int = 2,
    exit_path_road_ids: set = None,
) -> Dict:
    """交叉路口检测 + 出口路过滤。

    算法：
      1. 找到起点 (0,0) 最近的路网
      2. 确定车前方端点（x>0 方向的端点）
      3. 统计该端点连接的其他路网数量
      4. 连接数 >= min_connected_roads → 交叉路口
      5. 距离 = |forward_endpoint - (0,0)|
      6. 如果提供了 exit_path_road_ids，检查连接路是否全是出口路

    Returns:
        {
            "has_intersection": bool,          # 是否检测到交叉路口
            "distance": float or None,          # 到交叉口的距离 (m)
            "num_connected": int,               # 连接的其他道路数量
            "origin_road_id": str or None,      # 起点最近的道路 ID
            "connected_road_ids": list,          # 连接的道路 ID 列表
            "all_connected_are_exit": bool,     # 连接路是否全是出口路
            "num_exit_connected": int,          # 连接路中出口路的数量
            "forward_endpoint": np.array or None,
        }
    """
    result = {
        "has_intersection": False,
        "distance": None,
        "num_connected": 0,
        "origin_road_id": None,
        "connected_road_ids": [],
        "all_connected_are_exit": False,
        "num_exit_connected": 0,
        "forward_endpoint": None,
    }

    if len(all_road_geoms) < 2:
        return result

    # ── 1. 找到起点 (0,0) 最近的路网 ──
    origin = np.array([0.0, 0.0])
    origin_road_id, _, closest_pt = _find_nearest_road_to_point(origin, all_road_geoms)
    if origin_road_id is None:
        return result

    result["origin_road_id"] = origin_road_id
    origin_geom = all_road_geoms[origin_road_id]

    # ── 2. 确定车前方的端点 ──
    car_heading = np.array([1.0, 0.0])  # x 前方

    endpoints = [origin_geom[0], origin_geom[-1]]
    forward_endpoint = None

    for ep in endpoints:
        road_dir = ep - closest_pt
        road_dir_norm = np.linalg.norm(road_dir)
        if road_dir_norm < 1e-6:
            continue
        road_dir_normalized = road_dir / road_dir_norm
        dot = np.dot(road_dir_normalized, car_heading)
        if dot > 0:
            forward_endpoint = ep
            break

    if forward_endpoint is None:
        # Fallback: 选 x 坐标更大的端点
        if origin_geom[0][0] > origin_geom[-1][0]:
            forward_endpoint = origin_geom[0]
        else:
            forward_endpoint = origin_geom[-1]

    result["forward_endpoint"] = forward_endpoint

    # ── 3. 统计该端点连接的其他路网数量 ──
    connected_road_ids = []
    for rid, geom in all_road_geoms.items():
        if rid == origin_road_id:
            continue
        for ep in [geom[0], geom[-1]]:
            if np.linalg.norm(ep - forward_endpoint) <= endpoint_dist_threshold:
                connected_road_ids.append(rid)
                break

    num_connected = len(connected_road_ids)
    result["num_connected"] = num_connected
    result["connected_road_ids"] = connected_road_ids

    # ── 4. 连接数不足 → 不是交叉路口 ──
    if num_connected < min_connected_roads:
        return result

    result["has_intersection"] = True

    # ── 5. 计算距离 ──
    dist = float(np.linalg.norm(forward_endpoint - origin))
    result["distance"] = dist

    # ── 6. 检查连接路是否全是出口路 ──
    if exit_path_road_ids is not None and len(exit_path_road_ids) > 0 and num_connected > 0:
        num_exit = sum(1 for rid in connected_road_ids if rid in exit_path_road_ids)
        result["num_exit_connected"] = num_exit
        result["all_connected_are_exit"] = (num_exit == num_connected)

    return result


# ═══════════════════════════════════════════════════════════════════════════════
#  Main filter function
# ═══════════════════════════════════════════════════════════════════════════════

def should_keep_frame(
    data_item: dict,
    ds_type: str = "exit",
    near_threshold: Tuple[float, float] = (0.0, 15.0),
    endpoint_dist_threshold: float = 2.0,
    min_connected_roads: int = 2,
) -> Tuple[bool, Dict]:
    """判断一帧是否应该保留。

    对于 exit 数据：
      1. 在交叉路口附近（距离在 near_threshold 范围内）
      2. 且连接路不全是出口路

    对于 no_entry 数据：
      1. 在交叉路口附近（距离在 near_threshold 范围内）

    Args:
        data_item: 原始 PKL 数据（包含 extra, conversations 等字段）
        ds_type: "exit" 或 "no_entry"
        near_threshold: (min_dist, max_dist) 有效距离范围
        endpoint_dist_threshold: 判断道路连接的端点距离阈值
        min_connected_roads: 构成交叉路口的最小连接路数

    Returns:
        (keep: bool, info: dict) — keep=True 表示保留该帧
    """
    extra = data_item.get('extra', {})
    if not isinstance(extra, dict):
        return False, {"reason": "no_extra"}

    # ── 获取道路几何 ──
    all_road_geoms = get_road_geometries(extra, ds_type)
    if len(all_road_geoms) < 2:
        return False, {"reason": "insufficient_road_geoms",
                       "num_roads": len(all_road_geoms)}

    # ── 计算出口路 ID（仅 exit 数据） ──
    exit_path_road_ids = None
    if ds_type == 'exit':
        conversations = data_item.get('conversations', [])
        answer_raw = conversations[1]['value'] if len(conversations) > 1 else ''
        vla_road_construction_info = extra.get('vla_road_construction_info', {})
        multi_groups = extra.get('multi_groups', [])
        exit_path_road_ids = compute_exit_path_road_ids(
            answer_raw, vla_road_construction_info, multi_groups)

    # ── 交叉路口检测 ──
    det = detect_intersection(
        all_road_geoms,
        near_threshold=near_threshold,
        endpoint_dist_threshold=endpoint_dist_threshold,
        min_connected_roads=min_connected_roads,
        exit_path_road_ids=exit_path_road_ids,
    )

    info = dict(det)

    if not det["has_intersection"]:
        info["reason"] = "no_intersection"
        return False, info

    min_d, max_d = near_threshold
    dist = det["distance"]
    if dist is None or dist < min_d or dist > max_d:
        info["reason"] = "intersection_out_of_range"
        return False, info

    # exit 数据额外检查：连接路是否全是出口路
    if ds_type == 'exit' and det["all_connected_are_exit"]:
        info["reason"] = "all_connected_are_exit_roads"
        return False, info

    info["reason"] = "near_intersection"
    return True, info


def filter_examples(examples: List[dict],
                    ds_type: str = "exit",
                    near_threshold: Tuple[float, float] = (0.0, 15.0),
                    endpoint_dist_threshold: float = 2.0,
                    min_connected_roads: int = 2,
                    verbose: bool = True) -> Tuple[List[dict], Dict]:
    """对一批 examples 进行交叉路口筛选。

    Args:
        examples: PKL 数据列表
        ds_type: "exit" 或 "no_entry"
        near_threshold: 有效距离范围
        endpoint_dist_threshold: 端点连接阈值
        min_connected_roads: 最小连接路数
        verbose: 是否打印统计信息

    Returns:
        (filtered_examples, stats) — stats 包含各分类的计数
    """
    kept = []
    stats = {
        "total": len(examples),
        "kept": 0,
        "no_intersection": 0,
        "intersection_out_of_range": 0,
        "all_exit_roads": 0,
        "no_extra": 0,
        "insufficient_road_geoms": 0,
        "other_skip": 0,
        "distances": [],
    }

    for ex in examples:
        keep, info = should_keep_frame(
            ex, ds_type=ds_type,
            near_threshold=near_threshold,
            endpoint_dist_threshold=endpoint_dist_threshold,
            min_connected_roads=min_connected_roads,
        )

        if keep:
            kept.append(ex)
            stats["kept"] += 1
        else:
            reason = info.get("reason", "unknown")
            if reason == "no_intersection":
                stats["no_intersection"] += 1
            elif reason == "intersection_out_of_range":
                stats["intersection_out_of_range"] += 1
            elif reason == "all_connected_are_exit_roads":
                stats["all_exit_roads"] += 1
            elif reason == "no_extra":
                stats["no_extra"] += 1
            elif reason == "insufficient_road_geoms":
                stats["insufficient_road_geoms"] += 1
            else:
                stats["other_skip"] += 1

        dist = info.get("distance")
        if dist is not None:
            stats["distances"].append(dist)

    if verbose and stats["total"] > 0:
        print(f"  [intersection_filter] {stats['total']} -> {stats['kept']} "
              f"({stats['kept'] / stats['total'] * 100:.1f}%)")
        print(f"    no_intersection:           {stats['no_intersection']}")
        print(f"    intersection_out_of_range: {stats['intersection_out_of_range']}")
        if ds_type == 'exit':
            print(f"    all_exit_roads:            {stats['all_exit_roads']}")
        print(f"    no_extra/insufficient:     {stats['no_extra'] + stats['insufficient_road_geoms']}")

    return kept, stats
