#!/bin/bash
#
# NIOVL 模型 vLLM 推理脚本 — 仅推理，不更新模型，不做reward。
# 启动方式和 verl 训练脚本类似。
#
# 用法:
#     bash tools/tools_bj/niovl_vllm_inference.sh [--skip-dataset] [--num-samples N]
#
# 环境变量:
#     MODEL_PATH  - 模型路径 (可选)
#     DATA_PATH   - 数据路径 (可选)
#     NUM_SAMPLES - 推理样本数 (默认: 3)
#

set -e

# ── 环境设置 ──
WORK_DIR=${WORK_DIR:-$HOME}
echo "WORK_DIR: $WORK_DIR"

source .venv2/bin/activate

# ── V0 引擎 + external_launcher ──
export VLLM_USE_V1=0
export RANK=0
export LOCAL_RANK=0
export WORLD_SIZE=1
export MASTER_ADDR=127.0.0.1
export MASTER_PORT=29500

export PYTHONPATH=$(pwd)
export PYTHONPATH="${PYTHONPATH}:$(pwd)/verl"

export MODEL_PATH=/perception-hl/kai.long/work_dirs/vla_ppu/0522_9.4Wclip_cot3_traj_vocab-20260522-182412/

# ── 默认配置 ──
MODEL_PATH="${MODEL_PATH:-/perception-hl/beijin.zhou/ali_data/vla-work-dirs/l2_models/260606_no_entry_repeat_no_cot_pos-20260606-003727}"
DATA_PATH="${DATA_PATH:-/perception-hl/beijin.zhou/projects/vlm_no_entry/dataset/replaced_prompt_output/dual_cot/vla_train_out_no_entry_260526_test__df5f809__20260527082619_reduce_v2_chunk_0000.parquet}"
NUM_SAMPLES="${NUM_SAMPLES:-1000}"
GPU_MEM="${GPU_MEM:-0.3}"
MAX_RESPONSE="${MAX_RESPONSE:-128}"
MAX_PROMPT="${MAX_PROMPT:-8192}"
TEMPERATURE="${TEMPERATURE:-0.7}"
TOP_P="${TOP_P:-1.0}"
OUTPUT_DIR="${OUTPUT_DIR:-/tmp/niovl_inference}"
START_INDEX="${START_INDEX:-0}"

echo "========================================================"
echo "NIOVL vLLM Inference"
echo "========================================================"
echo "MODEL_PATH:    $MODEL_PATH"
echo "DATA_PATH:     $DATA_PATH"
echo "NUM_SAMPLES:   $NUM_SAMPLES"
echo "START_INDEX:   $START_INDEX"
echo "GPU_MEM:       $GPU_MEM"
echo "MAX_RESPONSE:  $MAX_RESPONSE"
echo "TEMPERATURE:   $TEMPERATURE"
echo "TOP_P:         $TOP_P"
echo "OUTPUT_DIR:    $OUTPUT_DIR"
echo "========================================================"
echo ""

set -x

python3 tools/tools_bj/niovl_vllm_inference.py \
    --model-path "$MODEL_PATH" \
    --data-path "$DATA_PATH" \
    --num-samples "$NUM_SAMPLES" \
    --start-index "$START_INDEX" \
    --max-response-length "$MAX_RESPONSE" \
    --max-prompt-length "$MAX_PROMPT" \
    --gpu-memory-utilization "$GPU_MEM" \
    --temperature "$TEMPERATURE" \
    --top-p "$TOP_P" \
    --output-dir "$OUTPUT_DIR" \
    "$@"

echo ""
echo "Inference completed. Results saved to: $OUTPUT_DIR"
