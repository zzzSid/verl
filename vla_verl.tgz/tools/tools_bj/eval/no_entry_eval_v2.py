"""
No-Entry Evaluation v2: Road-graph segment-binding based conflict detection.

Same pipeline as no_entry_eval.py (grouping, filtering, trajectory parsing,
Easy/Complex split), but replaces prompt-derived forbidden direction matching
with trajectory-to-road binding:
  - Trajectory is prepended with origin (0,0), yielding 6 points
  - Every 3 consecutive points form a segment (4 segments total)
  - Each segment is bound to the best-matching road in road_graphs
    via a weighted score of distance + angle (reverse direction excluded)
  - Violation = any segment binds to a forbidden road

This avoids ambiguity when multiple roads share the same turning direction
but only some are actually forbidden.
"""

import json
import os
import re
import sys
import numpy as np
from collections import defaultdict

_dir_name = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
sys.path.insert(0, _dir_name)
from tools.utils.data_utils import calculate_meta_action_from_trajectory

# ═══════════════════════════════════════════════════════════════════════════════
#  Configurable thresholds
# ═══════════════════════════════════════════════════════════════════════════════

DISTANCE_THRESHOLD_COMPLEX = 6.0          # max distance_to_intersection (meters) for complex
CURVATURE_MIN_ANGLE_DEG = 3.0             # min cumulative heading change to confirm turning

# v2-specific: segment binding thresholds
BINDING_W_DIST = 0.5          # 距离权重
BINDING_W_ANGLE = 0.5         # 角度权重
BINDING_MAX_DIST = 5.0        # 归一化参考最大距离（米）
BINDING_MIN_POINTS = 5        # 模型输出最少点数，不足直接算 wrong（+origin=8点 → 6 segments）

SKIP_CLIP_IDS = {
    # "83357268-86e1-4307-9dd7-45fd13d0dda4",
}

META_ACTIONS = ["左转", "直行", "右转", "掉头", "未知"]
ACTION_ID_TO_TURN = {0: "左转", 1: "直行", 2: "右转"}

DEFINED_TYPES = {5, 6, 7}
TYPE_NAMES = {5: "禁行标志牌", 6: "导致逆行的地面Marker", 7: "障碍物"}

ACTION_POINTS_RE = re.compile(r"\((\d+),(\d+)\)")
COORD_NORM_MIN = 0
COORD_NORM_MAX = 1000
COORD_PHYS_MIN = -30.0
COORD_PHYS_MAX = 30.0
VOCAB_PATH = "/perception-hl/longan.yang/vla_data/vlm_path/train_dataset/vocab/0804_all/tokens_512_v1.npy"
_VOCABULARY = None


def get_vocabulary():
    global _VOCABULARY
    if _VOCABULARY is None:
        if os.path.exists(VOCAB_PATH):
            _VOCABULARY = np.load(VOCAB_PATH)
        else:
            print(f"[WARN] VOCAB_PATH not found: {VOCAB_PATH}")
            _VOCABULARY = np.array([])
    return _VOCABULARY


# ── Parsing helpers ──────────────────────────────────────────────────────────


def parse_part2(text: str):
    m = re.search(r'\[UNUSED_TOKEN_112\](.*?)\[UNUSED_TOKEN_113\]', text, re.DOTALL)
    return m.group(1) if m else ""


def parse_type_info(part2: str, type_id: int):
    pattern = f'<type>{type_id}</type>'
    idx = part2.find(pattern)
    if idx < 0:
        return None
    start = idx + len(pattern)
    end_tokens = ['<type>', '[UNUSED_TOKEN_113]', '[UNUSED_TOKEN_114]', '[UNUSED_TOKEN_112]']
    end = len(part2)
    for tok in end_tokens:
        pos = part2.find(tok, start)
        if pos >= 0 and pos < end:
            end = pos
    content = part2[start:end]
    if content.startswith('无') or content.strip() == '无':
        return {'action': None, 'is_none': True}
    action_match = re.search(r'\[UNUSED_TOKEN_39\](.*?)\[UNUSED_TOKEN_40\]', content)
    action = None
    if action_match:
        try:
            action = int(action_match.group(1).strip())
        except ValueError:
            pass
    return {'action': action, 'is_none': False}


def get_forbidden_directions(answer_text: str):
    part2 = parse_part2(answer_text)
    if not part2:
        return set()
    forbidden = set()
    for t in DEFINED_TYPES:
        info = parse_type_info(part2, t)
        if info is None:
            continue
        if info['is_none']:
            continue
        if info['action'] is not None:
            turn = ACTION_ID_TO_TURN.get(info['action'])
            if turn:
                forbidden.add(turn)
    return forbidden


def parse_action_traj(prediction_text: str):
    """
    兼容两种格式：
      1. <action>(x,y),...,(x,y)</action>
         返回归一化坐标，后续用 norm_to_abs_traj 转米。
      2. <action><action_123><action_45>...</action>
         根据 vocab 反解，直接返回绝对坐标，单位米。
    """
    if not prediction_text:
        return None

    action_match = re.search(r"<action>(.*?)</action>", prediction_text, re.DOTALL)
    if not action_match:
        return None

    action_content = action_match.group(1)

    points = ACTION_POINTS_RE.findall(action_content)
    if points:
        traj = [[int(x), int(y)] for x, y in points]
        return traj

    token_matches = re.findall(r"<action_(\d+)>", action_content)
    if not token_matches:
        return None

    vocabulary = get_vocabulary()
    if vocabulary is None or vocabulary.size == 0:
        return None

    vocab_indices = [int(m) for m in token_matches]

    x, y, theta = 0.0, 0.0, 0.0
    xs, ys = [], []

    for idx in vocab_indices:
        if idx == 0:
            xs.append(x)
            ys.append(y)
            continue

        vocab_row = idx - 1
        if vocab_row < 0 or vocab_row >= vocabulary.shape[0]:
            continue

        dx, dy, dheading = vocabulary[vocab_row]

        cos_t = np.cos(theta)
        sin_t = np.sin(theta)

        x = float(x + dx * cos_t - dy * sin_t)
        y = float(y + dx * sin_t + dy * cos_t)
        theta = float(np.arctan2(np.sin(theta + dheading), np.cos(theta + dheading)))

        xs.append(x)
        ys.append(y)

    if not xs:
        return None

    return [[x, y] for x, y in zip(xs, ys)]


def norm_to_abs_traj(norm_traj):
    """
    将归一化坐标 0~1000 转换为绝对坐标 -30~30 米。
    x 轴向前，y 轴向左。
    """
    if norm_traj is None or len(norm_traj) == 0:
        return None

    scale = (COORD_PHYS_MAX - COORD_PHYS_MIN) / (COORD_NORM_MAX - COORD_NORM_MIN)
    abs_traj = []
    for x_norm, y_norm in norm_traj:
        x_abs = COORD_PHYS_MIN + x_norm * scale
        y_abs = COORD_PHYS_MIN + y_norm * scale
        abs_traj.append([x_abs, y_abs])
    return np.array(abs_traj, dtype=float)


def action_traj_to_abs(action_traj):
    """
    parse_action_traj 的统一后处理：
      - int: 老格式 0~1000 归一化坐标
      - float: token 压缩后，已经是绝对坐标，单位米
    """
    if action_traj is None or len(action_traj) == 0:
        return None

    if isinstance(action_traj[0][0], int):
        return norm_to_abs_traj(action_traj)

    return np.array(action_traj, dtype=float)


# ── Trajectory utilities ─────────────────────────────────────────────────────


def delta_to_absolute_traj(delta_traj):
    if delta_traj is None or len(delta_traj) == 0:
        return None
    arr = np.array(delta_traj, dtype=float)
    if arr.ndim == 3 and arr.shape[0] == 1:
        arr = arr[0]
    if arr.ndim == 1:
        arr = arr.reshape(-1, 2)
    return np.cumsum(arr, axis=0)


def traj_turn_direction(traj, input_is_delta: bool = True):
    """Compute turn direction from a trajectory."""
    if input_is_delta:
        abs_traj = delta_to_absolute_traj(traj)
    else:
        abs_traj = None if traj is None else np.array(traj, dtype=float)
    if abs_traj is None:
        return {"未知"}
    turns = calculate_meta_action_from_trajectory(abs_traj)
    if turns is None or len(turns) == 0:
        return {"未知"}
    if isinstance(turns, str):
        return {turns}
    return {t if t in ACTION_ID_TO_TURN.values() else "未知" for t in turns}


def get_pred_traj_from_line(line):
    """Get trajectory from <action> tokens in prediction text, fall back to traj_pred.

    Returns (traj, is_delta). is_delta=True means delta trajectory.
    """
    pred_text = line.get("prediction", line.get("pred", ""))
    action_traj = parse_action_traj(pred_text)
    if action_traj is not None:
        abs_traj = action_traj_to_abs(action_traj)
        return abs_traj, False

    traj_pred = line.get("traj_pred")
    if traj_pred is not None:
        return traj_pred, True

    return None, True


def compute_traj_curvature(traj_label):
    """Compute cumulative heading change from traj_label, excluding zero-padding."""
    arr = np.array(traj_label, dtype=float)
    if arr.size == 0:
        return None
    if arr.ndim == 1:
        if arr.size % 2 != 0:
            return None
        arr = arr.reshape(-1, 2)

    motion_mask = ~((arr[:, 0] == 0.0) & (arr[:, 1] == 0.0))
    valid = arr[motion_mask]
    if len(valid) < 2:
        return None

    abs_traj = np.cumsum(valid, axis=0)
    headings = []
    for i in range(1, len(abs_traj)):
        dx = abs_traj[i, 0] - abs_traj[i - 1, 0]
        dy = abs_traj[i, 1] - abs_traj[i - 1, 1]
        headings.append(np.arctan2(dy, dx))
    headings = np.array(headings)

    cum_change = headings - headings[0]
    return {
        'max_left_deg': float(np.degrees(np.max(cum_change))),
        'max_right_deg': float(np.degrees(np.min(cum_change))),
    }


def curvature_confirms_turn(traj_label, conflict_direction):
    """Check whether traj_label curvature confirms the conflict turn direction."""
    if conflict_direction == "直行":
        return True
    curv = compute_traj_curvature(traj_label)
    if curv is None:
        return False
    if conflict_direction == "左转":
        return curv['max_left_deg'] > CURVATURE_MIN_ANGLE_DEG
    elif conflict_direction == "右转":
        return abs(curv['max_right_deg']) > CURVATURE_MIN_ANGLE_DEG
    return True


# ── v2: Road geometry helpers ────────────────────────────────────────────────


def _to_abs_traj(traj, is_delta):
    """Convert a trajectory to absolute coordinates numpy array."""
    if traj is None:
        return None
    if is_delta:
        return delta_to_absolute_traj(traj)
    if isinstance(traj, np.ndarray):
        return traj.astype(float)
    return np.array(traj, dtype=float)


FORBIDDEN_ROAD_CLASSES = {'noEntryRoad', 'noEntryRoadBarrier', 'ArriveDeadEndRoad', 'onlyRetrograde'}


def get_forbidden_road_ids_from_line(line):
    """
    Identify forbidden road IDs from a single line based on road class.
    Roads with class in {noEntryRoad, noEntryRoadBarrier, ArriveDeadEndRoad, onlyRetrograde} are forbidden.
    """
    select_road_ids = line.get('select_road_ids') or []
    select_road_cls = line.get('select_road_cls') or []

    forbidden_ids = set()
    for road_id, road_cls in zip(select_road_ids, select_road_cls):
        if road_cls in FORBIDDEN_ROAD_CLASSES:
            forbidden_ids.add(road_id)

    return forbidden_ids


def _min_distance_point_to_polyline(point, polyline):
    """
    Compute minimum distance from `point` (2,) to a polyline (N, 2).
    Returns (min_dist, closest_point_on_polyline).
    """
    point = np.asarray(point, dtype=float)
    min_dist = float('inf')
    closest_pt = None

    for i in range(len(polyline) - 1):
        a = polyline[i]
        b = polyline[i + 1]
        ab = b - a
        ab_len_sq = np.dot(ab, ab)

        if ab_len_sq < 1e-12:
            dist = np.linalg.norm(point - a)
            if dist < min_dist:
                min_dist = dist
                closest_pt = a.copy()
            continue

        t = np.dot(point - a, ab) / ab_len_sq
        t = max(0.0, min(1.0, t))
        closest = a + t * ab
        dist = np.linalg.norm(point - closest)
        if dist < min_dist:
            min_dist = dist
            closest_pt = closest.copy()

    return min_dist, closest_pt


def _road_direction_at_point(polyline, closest_point):
    """
    Get the direction vector of the polyline segment nearest to closest_point.
    Returns a unit direction vector (2,).
    """
    min_seg_dist = float('inf')
    best_dir = None

    for i in range(len(polyline) - 1):
        a = polyline[i]
        b = polyline[i + 1]
        mid = (a + b) / 2.0
        d = np.linalg.norm(closest_point - mid)
        if d < min_seg_dist:
            min_seg_dist = d
            seg_dir = b - a
            seg_len = np.linalg.norm(seg_dir)
            if seg_len > 1e-8:
                best_dir = seg_dir / seg_len

    return best_dir


def get_all_road_geometries(line):
    """Get geometry arrays for ALL roads from road_graphs."""
    road_graphs = line.get('road_graphs') or {}
    geometries = {}
    for road_id, road_info in road_graphs.items():
        if road_info and 'geometry' in road_info:
            geom = np.array(road_info['geometry'], dtype=float)
            if len(geom) >= 2:
                geometries[road_id] = geom
    return geometries


def get_road_id_to_cls(line):
    """Build road_id → road_cls mapping from select_road_ids and select_road_cls."""
    select_road_ids = line.get('select_road_ids') or []
    select_road_cls = line.get('select_road_cls') or []
    return dict(zip(select_road_ids, select_road_cls))


def compute_segment_binding_score(segment, geom, w_dist, w_angle, max_dist):
    """
    Compute binding score for a trajectory segment to a road geometry.

    Args:
        segment: (3, 2) array of 3 consecutive trajectory points
        geom: (N, 2) array of road geometry points
        w_dist: distance weight
        w_angle: angle weight
        max_dist: reference max distance for normalization

    Returns:
        (score, dist, angle_deg, closest_pt) or None if road is reverse direction
    """
    # Segment center point
    center = np.mean(segment, axis=0)

    # Distance from center to road
    min_dist, closest_pt = _min_distance_point_to_polyline(center, geom)

    # Hard distance threshold: exclude roads that are too far
    if min_dist > max_dist:
        return None

    # Segment direction (from first to last point)
    seg_vec = segment[-1] - segment[0]
    seg_len = np.linalg.norm(seg_vec)
    if seg_len < 1e-6:
        return None  # Segment has no direction

    seg_heading = np.arctan2(seg_vec[1], seg_vec[0])

    # Road direction at closest point
    road_dir = _road_direction_at_point(geom, closest_pt)
    if road_dir is None:
        return None

    road_heading = np.arctan2(road_dir[1], road_dir[0])

    # Angle difference, normalized to [-180, 180]
    angle_diff = seg_heading - road_heading
    angle_diff = np.degrees(np.arctan2(np.sin(angle_diff), np.cos(angle_diff)))

    abs_angle = abs(angle_diff)

    # Crossing exclusion: if trajectory is roughly perpendicular to the
    # road (60° < |angle| < 120°), the vehicle is CROSSING the road, not
    # entering it.  This applies unconditionally — even for roads that
    # span both sides of the origin.
    if 60.0 < abs_angle < 120.0:
        return None

    # Reverse exclusion: if trajectory is heading opposite to the road
    # (|angle| > 90°), the vehicle is going AWAY from the road.  BUT if
    # the road geometry spans both sides of the origin (has points ahead
    # AND behind), the geometry direction may not match the actual
    # driving direction — so we skip this exclusion.
    has_both_sides = (np.any(geom[:, 1] > 0) and np.any(geom[:, 1] < 0))
    if not has_both_sides and abs_angle > 90.0:
        return None

    # Global direction check: even if local direction passes, check the
    # road's OVERALL direction (first point → last point).  This catches
    # cases where the road's entry point happens to align with the
    # trajectory, but the road itself goes in a perpendicular direction.
    if len(geom) >= 2:
        global_vec = geom[-1] - geom[0]
        global_heading = np.arctan2(global_vec[1], global_vec[0])
        global_angle_diff = seg_heading - global_heading
        global_angle_diff = np.degrees(np.arctan2(np.sin(global_angle_diff), np.cos(global_angle_diff)))
        abs_global_angle = abs(global_angle_diff)

        # If overall direction is perpendicular, exclude even if local passed
        if 60.0 < abs_global_angle < 120.0:
            return None

    # Normalize distance and angle
    norm_dist = min(min_dist / max_dist, 1.0)
    norm_angle = abs(angle_diff) / 90.0

    # Score: lower is better
    score = w_dist * norm_dist + w_angle * norm_angle

    return {
        'score': score,
        'dist': float(min_dist),
        'angle_deg': float(angle_diff),
        'closest_pt': closest_pt.tolist(),
    }


def bind_segment_to_road(segment, all_road_geoms, w_dist, w_angle, max_dist):
    """
    Bind a trajectory segment to the best-matching road.

    Returns:
        (best_road_id, binding_info) or (None, None) if no valid binding
    """
    best_road_id = None
    best_score = float('inf')
    best_info = None

    for road_id, geom in all_road_geoms.items():
        result = compute_segment_binding_score(segment, geom, w_dist, w_angle, max_dist)
        if result is None:
            continue
        if result['score'] < best_score:
            best_score = result['score']
            best_road_id = road_id
            best_info = result

    return best_road_id, best_info


def find_nearest_road_to_point(point, all_road_geoms):
    """
    Find the road whose geometry is closest to a given point.

    Args:
        point: (2,) array-like, point in BEV coordinates (meters)
        all_road_geoms: dict mapping road_id → (N, 2) geometry array

    Returns:
        (best_road_id, min_dist, closest_pt) or (None, inf, None) if no roads
    """
    best_road_id = None
    best_dist = float('inf')
    best_pt = None
    point_arr = np.asarray(point, dtype=float)

    for road_id, geom in all_road_geoms.items():
        d, pt = _min_distance_point_to_polyline(point_arr, geom)
        if d < best_dist:
            best_dist = d
            best_pt = pt
            best_road_id = road_id

    return best_road_id, best_dist, best_pt


def has_reachable_non_forbidden_road(origin_geom, origin_road_id, all_road_geoms, all_forbidden_ids,
                                      angle_threshold_deg=45.0, endpoint_dist_threshold=2.0):
    """
    Check if there is at least one connected non-forbidden road reachable from the
    origin-bound road, considering the car's forward heading and road direction.

    Algorithm:
      1. Project the car position (0,0) onto the origin road to find closest_pt
      2. For each endpoint, compute the road direction from closest_pt to the endpoint
      3. Check if this road direction is within ±angle_threshold_deg of car's forward direction
      4. If exactly one endpoint is within threshold, car is heading in that direction (no U-turn)
         If zero or two endpoints are within threshold, car can go in either direction
      5. For each reachable endpoint, find connected roads (within endpoint_dist_threshold)
      6. If any connected road is not forbidden, return True

    Args:
        origin_geom: (N, 2) geometry array of the road the origin is bound to
        origin_road_id: ID of the origin road (excluded from connected road check)
        all_road_geoms: dict road_id → (M, 2) geometry for all roads
        all_forbidden_ids: set of forbidden road IDs
        angle_threshold_deg: max angle deviation from car heading (default 45°)
        endpoint_dist_threshold: max distance between endpoints for connectivity (meters)

    Returns:
        (has_reachable: bool, details: dict)
    """
    car_pos = np.array([0.0, 0.0])
    car_heading = np.array([1.0, 0.0])  # forward along +x

    # Find closest point on origin road to car position
    _, closest_pt = _min_distance_point_to_polyline(car_pos, origin_geom)

    # Endpoints of the origin road
    endpoints = [origin_geom[0], origin_geom[-1]]

    # Check which endpoints the car is heading towards (road direction within ±threshold)
    heading_endpoints = []
    for ep in endpoints:
        road_dir = ep - closest_pt
        road_dir_norm = np.linalg.norm(road_dir)
        if road_dir_norm < 1e-6:
            continue  # endpoint is at the same location as closest_pt
        road_dir_normalized = road_dir / road_dir_norm

        # Compute angle between road direction and car heading
        angle = np.degrees(np.arctan2(road_dir_normalized[1], road_dir_normalized[0]))

        # Check if angle is within threshold
        if abs(angle) <= angle_threshold_deg:
            heading_endpoints.append(ep)

    # Determine reachable endpoints based on heading
    if len(heading_endpoints) == 1:
        # Car is heading in a specific direction, can only go that way (no U-turn)
        reachable_endpoints = heading_endpoints
    else:
        # Car is not heading in any particular direction (or heading towards both),
        # can go in either direction (e.g., perpendicular road like horizontal)
        reachable_endpoints = endpoints

    details = {
        'origin_road_id': origin_road_id,
        'origin_endpoints': [ep.tolist() for ep in endpoints],
        'closest_pt': closest_pt.tolist(),
        'heading_endpoints': [ep.tolist() for ep in heading_endpoints],
        'reachable_endpoints': [ep.tolist() for ep in reachable_endpoints],
        'connected_roads': [],
        'non_forbidden_connected': [],
    }

    # Find roads connected to any reachable endpoint (via endpoint proximity)
    connected_roads = set()
    for ep in reachable_endpoints:
        for road_id, geom in all_road_geoms.items():
            if road_id == origin_road_id:
                continue
            for other_ep in [geom[0], geom[-1]]:
                dist = np.linalg.norm(other_ep - ep)
                if dist <= endpoint_dist_threshold:
                    connected_roads.add(road_id)
                    break

    details['connected_roads'] = list(connected_roads)

    # Check if any connected road is NOT forbidden
    non_forbidden = [rid for rid in connected_roads if rid not in all_forbidden_ids]
    details['non_forbidden_connected'] = non_forbidden

    if non_forbidden:
        return True, details
    else:
        details['reason'] = 'no_non_forbidden_connected_road'
        return False, details


# Cache for decoded masks to avoid re-decoding the same RLE data
_mask_cache = {}


def decode_unsafe_mask(rle):
    """Decode freespace RLE mask and return 600x600 binary mask.

    The RLE data is encoded by pycocotools.maskUtils.encode(np.asfortranarray(...))
    using the standard COCO RLE format. Must use pycocotools for correct decoding.

    Caches results to avoid re-decoding the same RLE data.

    Args:
        rle: dict with 'size' [h,w] and 'counts' (bytes or str)
    Returns:
        numpy array (h, w) with 1 for unsafe, 0 for safe. Returns None if invalid.
    """
    if not rle or 'counts' not in rle:
        return None

    counts = rle['counts']
    # Use bytes directly as cache key (most common case)
    if isinstance(counts, str):
        cache_key = (tuple(rle['size']), counts.encode('utf-8'))
    else:
        cache_key = (tuple(rle['size']), bytes(counts))

    if cache_key in _mask_cache:
        return _mask_cache[cache_key]

    # pycocotools is required: data is encoded with maskUtils.encode(np.asfortranarray(...))
    from pycocotools import mask as coco_mask
    try:
        m = coco_mask.decode({'size': rle['size'], 'counts': cache_key[1]})
        result = m.astype(np.uint8)
        _mask_cache[cache_key] = result
        return result
    except Exception:
        return None


def bev_to_mask_coords(x_meters, y_meters, mask_size=600):
    """Convert BEV coordinates (meters) to mask pixel coordinates.

    BEV: x forward, y left, origin at center
    Mask: row down, col right, origin at top-left

    The mask encodes: col → right, row → backward (down = backward).
    Trajectory y is left-positive, so we negate: col = (-y + offset) / scale.

    Args:
        x_meters: forward distance in meters
        y_meters: left distance in meters
        mask_size: mask size (default 600 for 60m x 60m)

    Returns:
        (row, col) pixel coordinates, or None if out of bounds
    """
    scale = 60.0 / mask_size  # 0.1 m/pixel for 600x600
    offset = 30.0

    # Reverse transformation from decode_freespace_rle
    # x forward → row (top=forward): row = (offset - x) / scale
    # y left → col (right=positive col): col = (-y + offset) / scale
    row = (offset - x_meters) / scale
    col = (-y_meters + offset) / scale

    row_int = int(round(row))
    col_int = int(round(col))

    if 0 <= row_int < mask_size and 0 <= col_int < mask_size:
        return (row_int, col_int)
    return None


def point_in_polygon(point, polygon):
    """Check if a point is inside a polygon using ray casting algorithm.
    Points on the boundary are considered inside.

    Args:
        point: (2,) array [x, y]
        polygon: (N, 2) array of polygon vertices
    Returns:
        bool: True if point is inside polygon or on boundary
    """
    x, y = point
    n = len(polygon)

    # Check if point is on boundary
    for i in range(n):
        p1x, p1y = polygon[i]
        p2x, p2y = polygon[(i + 1) % n]

        # Check if point is on this edge
        # First check if point is within bounding box of edge
        if min(p1x, p2x) <= x <= max(p1x, p2x) and min(p1y, p2y) <= y <= max(p1y, p2y):
            # Check if point is on the line (using cross product)
            cross = (x - p1x) * (p2y - p1y) - (y - p1y) * (p2x - p1x)
            if abs(cross) < 1e-10:  # Point is on the line
                return True

    # Ray casting algorithm for interior points
    inside = False
    p1x, p1y = polygon[0]
    for i in range(1, n + 1):
        p2x, p2y = polygon[i % n]
        if y > min(p1y, p2y):
            if y <= max(p1y, p2y):
                if x <= max(p1x, p2x):
                    if p1y != p2y:
                        xinters = (y - p1y) * (p2x - p1x) / (p2y - p1y) + p1x
                    if p1x == p2x or x <= xinters:
                        inside = not inside
        p1x, p1y = p2x, p2y
    return inside


def _coco_decode(size, counts):
    """Minimal RLE decode without pycocotools dependency."""
    h, w = size
    if isinstance(counts, str):
        counts = counts.encode('utf-8')
    counts_list = []
    for c in counts:
        counts_list.append(c)
    # Decode RLE
    mask = np.zeros(h * w, dtype=np.uint8)
    pos = 0
    val = 0
    i = 0
    while i < len(counts_list):
        x = 0
        k = 0
        more = True
        while more:
            c = counts_list[i] - 48
            x |= (c & 0x1f) << (5 * k)
            more = c & 0x20
            i += 1
            k += 1
            if not more and (c & 0x10):
                x |= -1 << (5 * k)
        if pos > 0:
            x += counts_list[i - 1]
        counts_list[i - 1] = x
        for j in range(x):
            if pos < len(mask):
                mask[pos] = val
                pos += 1
        val = 1 - val
    return mask.reshape((h, w), order='F')


def point_in_polygon(point, polygon):
    """Check if a point is inside a polygon using ray casting algorithm.
    Points on the boundary are considered inside.

    Args:
        point: (2,) array [x, y]
        polygon: (N, 2) array of polygon vertices
    Returns:
        bool: True if point is inside polygon or on boundary
    """
    x, y = point
    n = len(polygon)

    # Check if point is on boundary
    for i in range(n):
        p1x, p1y = polygon[i]
        p2x, p2y = polygon[(i + 1) % n]

        # Check if point is on this edge
        # First check if point is within bounding box of edge
        if min(p1x, p2x) <= x <= max(p1x, p2x) and min(p1y, p2y) <= y <= max(p1y, p2y):
            # Check if point is on the line (using cross product)
            cross = (x - p1x) * (p2y - p1y) - (y - p1y) * (p2x - p1x)
            if abs(cross) < 1e-10:  # Point is on the line
                return True

    # Ray casting algorithm for interior points
    inside = False
    p1x, p1y = polygon[0]
    for i in range(1, n + 1):
        p2x, p2y = polygon[i % n]
        if y > min(p1y, p2y):
            if y <= max(p1y, p2y):
                if x <= max(p1x, p2x):
                    if p1y != p2y:
                        xinters = (y - p1y) * (p2x - p1x) / (p2y - p1y) + p1x
                    if p1x == p2x or x <= xinters:
                        inside = not inside
        p1x, p1y = p2x, p2y
    return inside


def check_traj_crash_into_wall(abs_traj, unsafe_masks, min_points=BINDING_MIN_POINTS):
    """
    Check if trajectory crashes into wall (enters unsafe area).

    Uses O(1) mask lookup: convert BEV coords to mask pixels and check directly.

    Rules:
      - If ≥2 points are in unsafe area → crash

    Args:
        abs_traj: trajectory in BEV coordinates (meters)
        unsafe_masks: list of numpy arrays (h, w) with 1 for unsafe, 0 for safe
        min_points: minimum trajectory points required

    Returns:
        (is_crash: bool, details: dict)
    """
    if abs_traj is None or len(abs_traj) < min_points:
        return False, {'reason': 'no_crash'}

    if not unsafe_masks:
        return False, {'reason': 'no_crash'}

    traj_points = abs_traj[:min_points]  # 5 points
    unsafe_indices = []

    for idx, pt in enumerate(traj_points):
        x_meters, y_meters = pt[0], pt[1]
        for mask in unsafe_masks:
            h, w = mask.shape
            pixel_coords = bev_to_mask_coords(x_meters, y_meters, mask_size=h)
            if pixel_coords is not None:
                row, col = pixel_coords
                if mask[row, col] == 1:
                    unsafe_indices.append(idx)
                    break

    # Check rules
    num_unsafe = len(unsafe_indices)

    if num_unsafe >= 2:
        return True, {
            'reason': 'crash_into_wall',
            'unsafe_points': unsafe_indices,
            'num_unsafe': num_unsafe,
        }

    return False, {'reason': 'no_crash'}


def check_traj_violation_by_binding(
    abs_traj,
    all_road_geoms,
    road_id_to_cls,
    forbidden_ids,
    unsafe_masks=None,
    w_dist=BINDING_W_DIST,
    w_angle=BINDING_W_ANGLE,
    max_dist=BINDING_MAX_DIST,
    min_points=BINDING_MIN_POINTS,
):
    """
    Check if trajectory violates by binding segments to roads.

    Logic:
      1. Prepend origin (0,0) to trajectory → 6 points total
      2. Create 4 segments of 3 consecutive points each
      3. Bind each segment to best-matching road
      4. If any segment binds to a forbidden road → violation
      5. If trajectory crashes into wall (unsafe area) → violation (lower priority)

    Returns:
        (is_violation: bool, details: dict or None)
    """
    if abs_traj is None or len(abs_traj) < min_points:
        # Trajectory too short → automatically wrong
        return True, {'reason': 'trajectory_too_short', 'num_points': len(abs_traj) if abs_traj is not None else 0}

    # Prepend origin
    origin = np.array([[0.0, 0.0]])
    full_traj = np.vstack([origin, abs_traj[:min_points]])  # 6 points

    # Create segments: [0,1,2], [1,2,3], [2,3,4], [3,4,5]
    segment_bindings = []
    for i in range(len(full_traj) - 2):
        segment = full_traj[i:i+3]
        road_id, info = bind_segment_to_road(segment, all_road_geoms, w_dist, w_angle, max_dist)

        segment_bindings.append({
            'segment_idx': i,
            'road_id': road_id,
            'info': info,
        })

        # Check if this segment binds to a forbidden road
        if road_id is not None and road_id in forbidden_ids:
            return True, {
                'reason': 'segment_binds_to_forbidden_road',
                'segment_idx': i,
                'road_id': road_id,
                'road_cls': road_id_to_cls.get(road_id, 'unknown'),
                'binding_info': info,
            }

    # Check crash into wall (lower priority)
    if unsafe_masks:
        is_crash, crash_details = check_traj_crash_into_wall(abs_traj, unsafe_masks, min_points)
        if is_crash:
            return True, {
                'reason': 'crash_into_wall',
                'segment_bindings': segment_bindings,
                **crash_details
            }

    # No segment binds to forbidden road and no crash
    return False, {
        'reason': 'no_violation',
        'segment_bindings': segment_bindings,
    }


# ── Grouping ─────────────────────────────────────────────────────────────────


def group_lines(lines):
    """Group lines by (clip_id, FW_first_image)."""
    groups = defaultdict(lambda: {'prediction': None, 'answers': [], 'lines': []})
    for line in lines:
        cid = line['clip_id']
        image_field = line.get('image', {})
        fw_imgs = image_field.get('FW') or image_field.get('FRONT', [])
        fw_first = fw_imgs[0].split()[0] if fw_imgs else None
        if fw_first and fw_first.startswith('huailai_cos:'):
            fw_first = fw_first[len('huailai_cos:'):]
        group_key = (cid, fw_first)
        group = groups[group_key]
        if group['prediction'] is None:
            group['prediction'] = line.get('prediction', '')
        group['answers'].append(line.get('answer', ''))
        group['lines'].append(line)
    return groups


def extract_fw_filename(image_path):
    """Extract filename from FW image path for matching with pre-inference data."""
    if not image_path:
        return None
    # Remove prefix like 'huailai_cos:' or 's3://'
    if ':' in image_path:
        image_path = image_path.split(':', 1)[1]
    # Get just the filename
    return os.path.basename(image_path.split()[0])


def build_pre_inference_index(pre_jsonl_path):
    """Build a lookup index from pre-inference data: {(clip_id, fw_filename): entry}."""
    index = {}
    with open(pre_jsonl_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            entry = json.loads(line)
            cid = entry.get('clip_id', entry.get('extra', {}).get('clip_id', ''))
            images = entry.get('image', {})
            fw_imgs = images.get('FW') or images.get('FRONT', [])
            fw_path = fw_imgs[0] if fw_imgs else None
            fw_filename = extract_fw_filename(fw_path)
            if cid and fw_filename:
                index[(cid, fw_filename)] = entry
    print(f"Pre-inference index: {len(index)} entries from {pre_jsonl_path}")
    return index


def get_unsafe_masks_from_line(line, pre_entry=None):
    """
    Extract unsafe masks from line's freespace_info or pre_entry.
    Returns list of numpy arrays (h, w) with 1 for unsafe, 0 for safe.
    """
    # Try pre_entry first (from pre-inference data)
    if pre_entry:
        freespace_info = pre_entry.get('freespace_info', {})
        unsafe_rle = freespace_info.get('unsafe')
        if unsafe_rle:
            mask = decode_unsafe_mask(unsafe_rle)
            return [mask] if mask is not None else []

    # Fall back to line's pre_entry field
    line_pre_entry = line.get('pre_entry')
    if not line_pre_entry:
        return []

    freespace_info = line_pre_entry.get('freespace_info', {})
    unsafe_rle = freespace_info.get('unsafe')
    if not unsafe_rle:
        return []

    mask = decode_unsafe_mask(unsafe_rle)
    return [mask] if mask is not None else []


# ── Reusable group evaluation functions ──────────────────────────────────────


def evaluate_group_easy(group, pre_entry=None):
    """
    Evaluate a single group for easy evaluation.

    Args:
        group: dict with 'lines', 'prediction', 'answers'
        pre_entry: pre-inference data for unsafe masks

    Returns:
        dict with:
          - evaluable: bool
          - result: 'correct' / 'wrong' / None
          - forbidden_roads: set of forbidden road IDs
          - violation_details: dict with segment binding info
    """
    # Collect forbidden road IDs from all lines
    all_forbidden_ids = set()
    for ln in group['lines']:
        all_forbidden_ids |= get_forbidden_road_ids_from_line(ln)

    if not all_forbidden_ids:
        return {'evaluable': False, 'result': None, 'forbidden_roads': set(), 'violation_details': None}

    # Get all road geometries, road_id → road_cls mapping, and unsafe masks
    all_road_geoms = {}
    road_id_to_cls = {}
    all_unsafe_masks = []
    for ln in group['lines']:
        all_road_geoms.update(get_all_road_geometries(ln))
        road_id_to_cls.update(get_road_id_to_cls(ln))
        all_unsafe_masks.extend(get_unsafe_masks_from_line(ln, pre_entry))

    if not all_road_geoms:
        return {'evaluable': False, 'result': None, 'forbidden_roads': all_forbidden_ids, 'violation_details': None}

    # Filter: skip if origin (0,0) is on a forbidden road
    origin_road_id, origin_dist, origin_pt = find_nearest_road_to_point([0.0, 0.0], all_road_geoms)
    if (origin_road_id is not None
        and origin_road_id in road_id_to_cls
        and road_id_to_cls[origin_road_id] in FORBIDDEN_ROAD_CLASSES
        and origin_road_id in all_forbidden_ids):
        return {
            'evaluable': False, 'result': None,
            'forbidden_roads': all_forbidden_ids,
            'violation_details': {
                'reason': 'origin_on_forbidden_road',
                'road_id': origin_road_id,
                'road_cls': road_id_to_cls[origin_road_id],
                'distance': origin_dist,
            },
        }

    # Filter: skip if no reachable non-forbidden road from origin-bound road
    if origin_road_id is not None and origin_road_id in all_road_geoms:
        origin_geom = all_road_geoms[origin_road_id]
        has_reachable, connectivity_details = has_reachable_non_forbidden_road(
            origin_geom, origin_road_id, all_road_geoms, all_forbidden_ids
        )
        if not has_reachable:
            return {
                'evaluable': False, 'result': None,
                'forbidden_roads': all_forbidden_ids,
                'violation_details': {
                    'reason': 'no_reachable_non_forbidden_road',
                    'connectivity_details': connectivity_details,
                },
            }

    # Get pred trajectory
    traj_pred, pred_is_delta = get_pred_traj_from_line(group['lines'][0])
    if traj_pred is None:
        return {'evaluable': False, 'result': None, 'forbidden_roads': all_forbidden_ids, 'violation_details': None}

    # Check has_multiple_direction and distance 8-15m
    first_line = group['lines'][0]
    has_multi = first_line.get('has_multiple_direction', False)
    distance = first_line.get('distance_to_intersection')
    multi_ok = has_multi is True or has_multi == 'true' or has_multi == 'True'
    dist_ok = distance is not None and 8 <= distance <= 15

    if not (multi_ok and dist_ok):
        return {'evaluable': False, 'result': None, 'forbidden_roads': all_forbidden_ids, 'violation_details': None}

    # Convert pred trajectory to absolute coordinates
    abs_traj = _to_abs_traj(traj_pred, pred_is_delta)

    # Check if pred trajectory binds to forbidden road (with crash detection)
    is_violation, details = check_traj_violation_by_binding(
        abs_traj, all_road_geoms, road_id_to_cls, all_forbidden_ids,
        unsafe_masks=all_unsafe_masks
    )

    result = 'wrong' if is_violation else 'correct'
    return {
        'evaluable': True,
        'result': result,
        'forbidden_roads': all_forbidden_ids,
        'violation_details': details
    }


def evaluate_group_complex(group, pre_entry=None):
    """
    Evaluate a single group for complex evaluation.

    Args:
        group: dict with 'lines', 'prediction', 'answers'
        pre_entry: pre-inference data for unsafe masks

    Returns:
        dict with:
          - evaluable: bool
          - result: 'violates' / 'avoids' / None
          - forbidden_roads: set of forbidden road IDs
          - gt_conflict_details: dict with GT trajectory binding info
          - pred_conflict_details: dict with pred trajectory binding info
    """
    # Collect forbidden road IDs from all lines
    all_forbidden_ids = set()
    for ln in group['lines']:
        all_forbidden_ids |= get_forbidden_road_ids_from_line(ln)

    if not all_forbidden_ids:
        return {'evaluable': False, 'result': None, 'forbidden_roads': set(),
                'gt_conflict_details': None, 'pred_conflict_details': None}

    # Get GT trajectory
    first_line = group['lines'][0]
    traj_label = first_line.get('traj_label')
    if traj_label is None or len(traj_label) == 0:
        return {'evaluable': False, 'result': None, 'forbidden_roads': all_forbidden_ids,
                'gt_conflict_details': None, 'pred_conflict_details': None}

    # Get all road geometries, road_id → road_cls mapping, and unsafe masks
    all_road_geoms = {}
    road_id_to_cls = {}
    all_unsafe_masks = []
    for ln in group['lines']:
        all_road_geoms.update(get_all_road_geometries(ln))
        road_id_to_cls.update(get_road_id_to_cls(ln))
        all_unsafe_masks.extend(get_unsafe_masks_from_line(ln, pre_entry))

    if not all_road_geoms:
        return {'evaluable': False, 'result': None, 'forbidden_roads': all_forbidden_ids,
                'filter_reason': 'no_road_geoms',
                'gt_conflict_details': None, 'pred_conflict_details': None}

    # Filter: skip if origin (0,0) is on a forbidden road
    origin_road_id, origin_dist, origin_pt = find_nearest_road_to_point([0.0, 0.0], all_road_geoms)
    if (origin_road_id is not None
        and origin_road_id in road_id_to_cls
        and road_id_to_cls[origin_road_id] in FORBIDDEN_ROAD_CLASSES
        and origin_road_id in all_forbidden_ids):
        return {'evaluable': False, 'result': None, 'forbidden_roads': all_forbidden_ids,
                'filter_reason': 'origin_on_forbidden_road',
                'origin_road_id': origin_road_id,
                'gt_conflict_details': None, 'pred_conflict_details': None}

    # Filter: skip if no reachable non-forbidden road from origin-bound road
    if origin_road_id is not None and origin_road_id in all_road_geoms:
        origin_geom = all_road_geoms[origin_road_id]
        has_reachable, connectivity_details = has_reachable_non_forbidden_road(
            origin_geom, origin_road_id, all_road_geoms, all_forbidden_ids
        )
        if not has_reachable:
            return {'evaluable': False, 'result': None, 'forbidden_roads': all_forbidden_ids,
                    'filter_reason': 'all_forward_forbidden',
                    'connectivity_details': connectivity_details,
                    'gt_conflict_details': None, 'pred_conflict_details': None}

    # Filter 1: conflict = GT trajectory binds to forbidden road
    abs_traj_label = _to_abs_traj(traj_label, True)
    gt_conflict, gt_conflict_details = check_traj_violation_by_binding(
        abs_traj_label, all_road_geoms, road_id_to_cls, all_forbidden_ids,
        unsafe_masks=all_unsafe_masks
    )

    if not gt_conflict:
        return {'evaluable': False, 'result': None, 'forbidden_roads': all_forbidden_ids,
                'filter_reason': 'no_gt_conflict',
                'gt_conflict_details': None, 'pred_conflict_details': None}

    # Filter 2: distance + multi_dir
    distance = first_line.get('distance_to_intersection')
    has_multi = first_line.get('has_multiple_direction', False)
    multi_ok = has_multi is True or has_multi == 'true' or has_multi == 'True'
    dist_ok = distance is not None and distance < DISTANCE_THRESHOLD_COMPLEX

    if not (multi_ok and dist_ok):
        return {'evaluable': False, 'result': None, 'forbidden_roads': all_forbidden_ids,
                'gt_conflict_details': gt_conflict_details, 'pred_conflict_details': None}

    # Filter 3: curvature confirmation
    gt_turns = traj_turn_direction(traj_label)
    primary_conflict = list(gt_turns)[0] if gt_turns else "未知"
    if not curvature_confirms_turn(traj_label, primary_conflict):
        return {'evaluable': False, 'result': None, 'forbidden_roads': all_forbidden_ids,
                'gt_conflict_details': gt_conflict_details, 'pred_conflict_details': None}

    # This frame passes all filters → evaluate model behavior
    traj_pred, pred_is_delta = get_pred_traj_from_line(first_line)
    if traj_pred is None or len(traj_pred) == 0:
        return {'evaluable': False, 'result': None, 'forbidden_roads': all_forbidden_ids,
                'gt_conflict_details': gt_conflict_details, 'pred_conflict_details': None}

    # Check if pred trajectory binds to forbidden road (with crash detection)
    abs_traj_pred = _to_abs_traj(traj_pred, pred_is_delta)
    model_conflict, pred_conflict_details = check_traj_violation_by_binding(
        abs_traj_pred, all_road_geoms, road_id_to_cls, all_forbidden_ids,
        unsafe_masks=all_unsafe_masks
    )

    result = 'violates' if model_conflict else 'avoids'
    return {
        'evaluable': True,
        'result': result,
        'forbidden_roads': all_forbidden_ids,
        'gt_conflict_details': gt_conflict_details,
        'pred_conflict_details': pred_conflict_details
    }


# ── Evaluation: Easy (v2: road geometry based) ───────────────────────────────


def evaluate_direction_easy(jsonl_path, pre_jsonl_path=None):
    with open(jsonl_path, 'r', encoding='utf-8') as f:
        lines = [json.loads(line.strip()) for line in f if line.strip()]

    # Build pre-inference index if provided
    pre_index = {}
    if pre_jsonl_path and os.path.exists(pre_jsonl_path):
        pre_index = build_pre_inference_index(pre_jsonl_path)

    groups = group_lines(lines)

    total_groups = 0          # groups with forbidden roads evaluated
    correct = 0
    wrong = 0
    skipped_clip_filter = 0
    skipped_no_forbidden = 0  # groups where no forbidden roads found
    skipped_no_traj = 0       # groups with no traj_pred
    skipped_no_multi_dir_or_dist = 0  # groups not meeting has_multiple_direction + distance filter
    skipped_origin_on_forbidden = 0  # groups where origin (0,0) is on forbidden road
    skipped_all_forward_forbidden = 0  # groups where all forward roads are forbidden

    per_direction = {
        "左转": {"total": 0, "wrong": 0},
        "直行": {"total": 0, "wrong": 0},
        "右转": {"total": 0, "wrong": 0},
    }

    wrong_examples = []
    wrong_reason_counts = {}  # reason -> count

    # 有效性指标计数器
    crash_count = 0  # 碰撞数
    length_error_count = 0  # 输出长度错误数

    for (cid, fw_first), group in groups.items():
        # Skip clips in the skip list
        if cid in SKIP_CLIP_IDS:
            skipped_clip_filter += 1
            continue

        # ── v2: Collect forbidden roads from ALL lines in group ──
        all_forbidden_ids = set()
        for ln in group['lines']:
            all_forbidden_ids |= get_forbidden_road_ids_from_line(ln)

        if not all_forbidden_ids:
            skipped_no_forbidden += 1
            continue

        # Get trajectory from prediction action or traj_pred
        traj_pred, pred_is_delta = get_pred_traj_from_line(group['lines'][0])
        if traj_pred is None:
            skipped_no_traj += 1
            continue

        # Only evaluate when has_multiple_direction is True AND distance 8-15m
        extra = group['lines'][0]
        has_multi = extra.get('has_multiple_direction', False)
        distance = extra.get('distance_to_intersection')
        if not (has_multi is True or has_multi == 'true' or has_multi == 'True'):
            skipped_no_multi_dir_or_dist += 1
            continue
        if distance is None or not (8 <= distance <= 15):
            skipped_no_multi_dir_or_dist += 1
            continue

        # ── v2: Get ALL road geometries and road_id → road_cls mapping ──
        all_road_geoms = {}
        road_id_to_cls = {}
        all_unsafe_masks = []

        # Look up pre_entry from pre_index
        fw_filename = extract_fw_filename(fw_first)
        pre_entry = pre_index.get((cid, fw_filename)) if pre_index else None

        for ln in group['lines']:
            all_road_geoms.update(get_all_road_geometries(ln))
            road_id_to_cls.update(get_road_id_to_cls(ln))
            all_unsafe_masks.extend(get_unsafe_masks_from_line(ln, pre_entry))

        if not all_road_geoms:
            skipped_no_forbidden += 1
            continue

        # Filter: skip if origin (0,0) is on a forbidden road
        origin_road_id, origin_dist, origin_pt = find_nearest_road_to_point([0.0, 0.0], all_road_geoms)
        if (origin_road_id is not None
            and origin_road_id in road_id_to_cls
            and road_id_to_cls[origin_road_id] in FORBIDDEN_ROAD_CLASSES
            and origin_road_id in all_forbidden_ids):
            skipped_origin_on_forbidden += 1
            continue

        # Filter: skip if no reachable non-forbidden road from origin-bound road
        if origin_road_id is not None and origin_road_id in all_road_geoms:
            origin_geom = all_road_geoms[origin_road_id]
            has_reachable, connectivity_details = has_reachable_non_forbidden_road(
                origin_geom, origin_road_id, all_road_geoms, all_forbidden_ids
            )
            if not has_reachable:
                skipped_all_forward_forbidden += 1
                continue

        total_groups += 1

        # v2: Get GT turn direction for per-direction breakdown
        pred_turns = traj_turn_direction(traj_pred, input_is_delta=pred_is_delta)
        gt_turns = set()
        for ln in group['lines']:
            traj_label = ln.get('traj_label')
            if traj_label is not None and len(traj_label) > 0:
                gt_turns |= traj_turn_direction(traj_label)

        # ── v2: Check if predicted trajectory binds to forbidden road ──
        abs_traj = _to_abs_traj(traj_pred, pred_is_delta)
        is_violation, details = check_traj_violation_by_binding(
            abs_traj, all_road_geoms, road_id_to_cls, all_forbidden_ids,
            unsafe_masks=all_unsafe_masks
        )

        if is_violation:
            wrong += 1
            # Track violation reason
            reason = details.get('reason', 'unknown')
            wrong_reason_counts[reason] = wrong_reason_counts.get(reason, 0) + 1

            # 统计碰撞和长度错误
            if reason == 'crash_into_wall':
                crash_count += 1
            elif reason == 'trajectory_too_short':
                length_error_count += 1

            for d in gt_turns:
                if d in per_direction:
                    per_direction[d]["total"] += 1
                    per_direction[d]["wrong"] += 1
            wrong_examples.append({
                "clip_id": cid,
                "fw_first_image": fw_first,
                "forbidden_roads": list(all_forbidden_ids),
                "violation_reason": details.get('reason'),
                "segment_idx": details.get('segment_idx'),
                "violation_road": details.get('road_id'),
                "road_cls": details.get('road_cls'),
                "binding_info": details.get('binding_info'),
                "trajectory_turn": list(pred_turns),
            })
        else:
            correct += 1
            for d in gt_turns:
                if d in per_direction:
                    per_direction[d]["total"] += 1

    # ── 打印结果 ──────────────────────────────────────────────────────────
    print("=" * 70)
    print("禁行路方向评测结果（简单）[v2]")
    print("=" * 70)
    print(f"总行数:                    {len(lines)}")
    print(f"总组数:                    {len(groups)}")
    print(f"评测组数:                  {total_groups}")
    print(f"正确数:                    {correct}")
    print(f"错误数:                    {wrong}")
    print(f"准确率:                    {correct / total_groups * 100:.2f}%" if total_groups > 0 else "准确率: N/A")

    print("\n--- 按方向分类 ---")
    for d in ["左转", "直行", "右转"]:
        t = per_direction[d]["total"]
        w = per_direction[d]["wrong"]
        rate = w / t * 100 if t > 0 else 0
        print(f"  {d}: 禁行数={t}, 违规数={w}, 违规率={rate:.2f}%")

    # ── 错误原因分类 ─────────────────────────────────────
    print("\n--- 错误原因分类 ---")
    if wrong > 0:
        for reason, count in sorted(wrong_reason_counts.items(), key=lambda x: -x[1]):
            pct = count / wrong * 100
            print(f"  {reason}: {count} ({pct:.2f}%)")
    else:
        print("  （无违规）")

    # ── 有效性指标（去除碰撞和长度错误）─────────────────────────────────
    effective_total = total_groups - crash_count - length_error_count
    # 进入禁行路数 = wrong - crash_count - length_error_count
    # 注意：有些case可能同时是wrong但既不是crash也不是length_error（即真正进入禁行路）
    effective_wrong = wrong - crash_count - length_error_count
    effective_correct = effective_total - effective_wrong
    effective_acc = effective_correct / effective_total * 100 if effective_total > 0 else 0

    print("\n--- 有效性指标（去除碰撞和长度错误）---")
    print(f"  评测总数:                  {total_groups}")
    print(f"  碰撞数:                    {crash_count}")
    print(f"  输出长度错误数:            {length_error_count}")
    print(f"  有效评测数:                {effective_total}")
    print(f"  实际进入禁行路数:          {effective_wrong}")
    print(f"  实际禁行路进入率:          {effective_wrong / effective_total * 100:.2f}%" if effective_total > 0 else "  实际禁行路进入率: N/A")
    print(f"  有效率（未进入禁行路）:    {effective_acc:.2f}%" if effective_total > 0 else "  有效率（未进入禁行路）: N/A")

    # ── Formatted result table ──────────────────────────────────────────
    total = total_groups
    total_correct = correct
    total_acc = correct / total * 100 if total > 0 else 0

    dir_correct = {}
    dir_acc = {}
    for d in ["直行", "左转", "右转"]:
        t = per_direction[d]["total"]
        w = per_direction[d]["wrong"]
        c = t - w
        dir_correct[d] = c
        dir_acc[d] = c / t * 100 if t > 0 else 0

    def _dw(s):
        w = 0
        for c in s:
            w += 2 if '一' <= c <= '鿿' or '　' <= c <= '〿' or '＀' <= c <= '￯' else 1
        return w
    def _pad(s, w):
        return s + ' ' * max(0, w - _dw(s))

    CW = 18
    label = f"简单SR（{total}）"
    print(f"\n")
    print(f"  {'':12s}{_pad('总计', CW)}{_pad('直行', CW)}{_pad('左转', CW)}{_pad('右转', CW)}")
    cells = [
        f'{total_acc:.2f}%（{total_correct}）',
        f'{dir_acc["直行"]:.2f}%（{dir_correct["直行"]}）',
        f'{dir_acc["左转"]:.2f}%（{dir_correct["左转"]}）',
        f'{dir_acc["右转"]:.2f}%（{dir_correct["右转"]}）',
    ]
    print(f"  {_pad(label, 12)}" + "".join(_pad(c, CW) for c in cells))

    print("\n" + "=" * 70)

    result = {
        "total_lines": len(lines),
        "total_groups": len(groups),
        "skipped_clip_filter": skipped_clip_filter,
        "skipped_no_forbidden": skipped_no_forbidden,
        "skipped_no_traj": skipped_no_traj,
        "skipped_no_multi_dir_or_dist": skipped_no_multi_dir_or_dist,
        "evaluated_groups": total_groups,
        "correct": correct,
        "wrong": wrong,
        "accuracy": round(correct / total_groups, 4) if total_groups > 0 else 0.0,
        "per_direction": {
            d: {
                "total_forbids": per_direction[d]["total"],
                "violations": per_direction[d]["wrong"],
                "violation_rate": round(per_direction[d]["wrong"] / per_direction[d]["total"], 4)
                if per_direction[d]["total"] > 0 else 0.0,
            }
            for d in ["左转", "直行", "右转"]
        },
        "wrong_reason_breakdown": {
            reason: {
                "count": count,
                "percentage": round(count / wrong * 100, 2) if wrong > 0 else 0.0,
            }
            for reason, count in wrong_reason_counts.items()
        },
        "有效指标": {
            "评测总数": total_groups,
            "碰撞数": crash_count,
            "输出长度错误数": length_error_count,
            "有效评测数": effective_total,
            "实际进入禁行路数": effective_wrong,
            "实际禁行路进入率": f"{effective_wrong / effective_total * 100:.2f}%" if effective_total > 0 else "N/A",
            "有效率": f"{effective_acc:.2f}%",
        },
    }

    # Save metrics
    # remote_dir = os.path.dirname(jsonl_path)
    # output_path = os.path.join(remote_dir, 'no_entry_direction_metrics_v2.json')
    # try:
    #     with open(output_path, 'w', encoding='utf-8') as f:
    #         json.dump(result, f, ensure_ascii=False, indent=2)
    #     print(f"\nMetrics saved to: {output_path}")
    # except PermissionError:
    #     output_path = 'no_entry_direction_metrics_v2.json'
    #     with open(output_path, 'w', encoding='utf-8') as f:
    #         json.dump(result, f, ensure_ascii=False, indent=2)
    #     print(f"\nMetrics saved to: {output_path} (fallback)")

    return result


# ── Evaluation: Complex (v2: road geometry based) ────────────────────────────


def evaluate_conflict_complex(jsonl_path, pre_jsonl_path=None):
    with open(jsonl_path, 'r', encoding='utf-8') as f:
        lines = [json.loads(line.strip()) for line in f if line.strip()]

    # Build pre-inference index if provided
    pre_index = {}
    if pre_jsonl_path and os.path.exists(pre_jsonl_path):
        pre_index = build_pre_inference_index(pre_jsonl_path)

    groups = group_lines(lines)

    # ── Counters ──────────────────────────────────────────────────────────
    total_groups = len(groups)

    skipped_clip_filter = 0
    skipped_no_forbidden = 0
    skipped_no_traj_label = 0
    skipped_no_traj_pred = 0
    skipped_origin_on_forbidden = 0  # origin (0,0) is on forbidden road
    skipped_all_forward_forbidden = 0  # all reachable roads from origin are forbidden
    skipped_no_conflict = 0       # has forbidden roads but GT doesn't enter them
    skipped_no_distance = 0       # conflict but distance/multi_dir fail
    skipped_no_curvature = 0      # conflict+dist but curvature not confirmed

    evaluated = 0                  # frames that pass all 3 filters

    model_violates = 0             # traj_pred enters forbidden road
    model_avoids = 0               # traj_pred does NOT enter forbidden road

    per_direction = {
        "左转": {"conflict_frames": 0, "model_violates": 0, "model_avoids": 0},
        "直行": {"conflict_frames": 0, "model_violates": 0, "model_avoids": 0},
        "右转": {"conflict_frames": 0, "model_violates": 0, "model_avoids": 0},
    }

    violation_examples = []
    avoid_examples = []
    violation_reason_counts = {}  # reason -> count

    # 有效性指标计数器
    crash_count = 0  # 碰撞数
    length_error_count = 0  # 输出长度错误数

    for (cid, fw_first), group in groups.items():
        # ── Skip clips in the skip list ──────────────────────────────────
        if cid in SKIP_CLIP_IDS:
            skipped_clip_filter += 1
            continue

        # ── v2: Parse forbidden roads from all lines ─────────────────────
        all_forbidden_ids = set()
        for ln in group['lines']:
            all_forbidden_ids |= get_forbidden_road_ids_from_line(ln)

        if not all_forbidden_ids:
            skipped_no_forbidden += 1
            continue

        # ── GT trajectory turn direction ─────────────────────────────────
        first_line = group['lines'][0]
        traj_label = first_line.get('traj_label')
        if traj_label is None or len(traj_label) == 0:
            skipped_no_traj_label += 1
            continue

        gt_turns = traj_turn_direction(traj_label)

        # ── v2 Filter 1: conflict = GT trajectory binds to forbidden road ──
        abs_traj_label = _to_abs_traj(traj_label, True)

        # Get ALL road geometries and road_id → road_cls mapping
        all_road_geoms = {}
        road_id_to_cls = {}
        all_unsafe_masks = []

        # Look up pre_entry from pre_index
        fw_filename = extract_fw_filename(fw_first)
        pre_entry = pre_index.get((cid, fw_filename)) if pre_index else None

        for ln in group['lines']:
            all_road_geoms.update(get_all_road_geometries(ln))
            road_id_to_cls.update(get_road_id_to_cls(ln))
            all_unsafe_masks.extend(get_unsafe_masks_from_line(ln, pre_entry))

        if not all_road_geoms:
            skipped_no_forbidden += 1
            continue

        # Filter: skip if origin (0,0) is on a forbidden road
        origin_road_id, origin_dist, origin_pt = find_nearest_road_to_point([0.0, 0.0], all_road_geoms)
        if (origin_road_id is not None
            and origin_road_id in road_id_to_cls
            and road_id_to_cls[origin_road_id] in FORBIDDEN_ROAD_CLASSES
            and origin_road_id in all_forbidden_ids):
            skipped_origin_on_forbidden += 1
            continue

        # Filter: skip if no reachable non-forbidden road from origin-bound road
        if origin_road_id is not None and origin_road_id in all_road_geoms:
            origin_geom = all_road_geoms[origin_road_id]
            has_reachable, connectivity_details = has_reachable_non_forbidden_road(
                origin_geom, origin_road_id, all_road_geoms, all_forbidden_ids
            )
            if not has_reachable:
                skipped_all_forward_forbidden += 1
                continue

        gt_conflict, gt_conflict_details = check_traj_violation_by_binding(
            abs_traj_label, all_road_geoms, road_id_to_cls, all_forbidden_ids,
            unsafe_masks=all_unsafe_masks
        )
        if not gt_conflict:
            skipped_no_conflict += 1
            continue

        # ── Filter 2: distance + multi_dir ───────────────────────────────
        distance = first_line.get('distance_to_intersection')
        has_multi = first_line.get('has_multiple_direction', False)
        multi_ok = has_multi is True or has_multi == 'true' or has_multi == 'True'
        dist_ok = distance is not None and distance < DISTANCE_THRESHOLD_COMPLEX

        if not (multi_ok and dist_ok):
            skipped_no_distance += 1
            continue

        # ── Filter 3: curvature confirmation (use GT turn direction) ───── [DISABLED]
        # primary_conflict = list(gt_turns)[0] if gt_turns else "未知"
        # if not curvature_confirms_turn(traj_label, primary_conflict):
        #     skipped_no_curvature += 1
        #     continue

        # ── This frame passes all filters → evaluate model behavior ──────
        evaluated += 1

        traj_pred, pred_is_delta = get_pred_traj_from_line(first_line)
        if traj_pred is None or len(traj_pred) == 0:
            skipped_no_traj_pred += 1
            continue

        # v2: Check if predicted trajectory binds to forbidden road
        abs_traj_pred = _to_abs_traj(traj_pred, pred_is_delta)
        model_conflict, pred_conflict_details = check_traj_violation_by_binding(
            abs_traj_pred, all_road_geoms, road_id_to_cls, all_forbidden_ids,
            unsafe_masks=all_unsafe_masks
        )

        for d in gt_turns:
            if d in per_direction:
                per_direction[d]["conflict_frames"] += 1

        if model_conflict:
            model_violates += 1
            # Track violation reason
            reason = pred_conflict_details.get('reason', 'unknown')
            violation_reason_counts[reason] = violation_reason_counts.get(reason, 0) + 1

            # 统计碰撞和长度错误
            if reason == 'crash_into_wall':
                crash_count += 1
            elif reason == 'trajectory_too_short':
                length_error_count += 1

            for d in gt_turns:
                if d in per_direction:
                    per_direction[d]["model_violates"] += 1
            violation_examples.append({
                "clip_id": cid,
                "fw_first_image": fw_first,
                "forbidden_roads": list(all_forbidden_ids),
                "gt_turn": list(gt_turns),
                "gt_conflict_reason": gt_conflict_details.get('reason'),
                "gt_conflict_road": gt_conflict_details.get('road_id'),
                "pred_conflict_reason": pred_conflict_details.get('reason'),
                "pred_conflict_road": pred_conflict_details.get('road_id'),
                "pred_segment_idx": pred_conflict_details.get('segment_idx'),
                "distance": distance,
            })
        else:
            model_avoids += 1
            for d in gt_turns:
                if d in per_direction:
                    per_direction[d]["model_avoids"] += 1
            avoid_examples.append({
                "clip_id": cid,
                "fw_first_image": fw_first,
                "forbidden_roads": list(all_forbidden_ids),
                "gt_turn": list(gt_turns),
                "gt_conflict_reason": gt_conflict_details.get('reason'),
                "gt_conflict_road": gt_conflict_details.get('road_id'),
                "distance": distance,
            })

    # ── 打印结果 ────────────────────────────────────────────────────
    total_evaluated = model_violates + model_avoids
    avoidance_rate = (model_avoids / total_evaluated * 100) if total_evaluated > 0 else 0.0

    print("=" * 70)
    print("禁行路冲突评测（复杂）[v2]")
    print("=" * 70)
    print(f"总组数:                      {total_groups}")
    print(f"评测冲突帧数:                {evaluated}")
    print(f"  模型违规（跟随GT）:        {model_violates}")
    print(f"  模型避让（覆盖GT）:        {model_avoids}")
    print(f"  模型避让率:                {avoidance_rate:.2f}%")

    print(f"\n--- 按方向分类 ---")
    for d in ["左转", "直行", "右转"]:
        cf = per_direction[d]["conflict_frames"]
        mv = per_direction[d]["model_violates"]
        ma = per_direction[d]["model_avoids"]
        rate = ma / cf * 100 if cf > 0 else 0
        print(f"  {d}: 冲突帧数={cf}, 模型违规={mv}, 模型避让={ma}, 避让率={rate:.2f}%")

    # ── 违规原因分类 ─────────────────────────────────────
    print(f"\n--- 模型违规原因分类 ---")
    if model_violates > 0:
        for reason, count in sorted(violation_reason_counts.items(), key=lambda x: -x[1]):
            pct = count / model_violates * 100
            print(f"  {reason}: {count} ({pct:.2f}%)")
    else:
        print("  （无违规）")

    # ── 有效性指标（去除碰撞和长度错误）─────────────────────────────────
    effective_total = total_evaluated - crash_count - length_error_count
    effective_violates = model_violates - crash_count - length_error_count
    effective_avoids = model_avoids
    effective_avoidance_rate = effective_avoids / effective_total * 100 if effective_total > 0 else 0

    print("\n--- 有效性指标（去除碰撞和长度错误）---")
    print(f"  评测总数:                  {total_evaluated}")
    print(f"  碰撞数:                    {crash_count}")
    print(f"  输出长度错误数:            {length_error_count}")
    print(f"  有效评测数:                {effective_total}")
    print(f"  实际进入禁行路数:          {effective_violates}")
    print(f"  实际禁行路进入率:          {effective_violates / effective_total * 100:.2f}%" if effective_total > 0 else "  实际禁行路进入率: N/A")
    print(f"  有效避让率:                {effective_avoidance_rate:.2f}%" if effective_total > 0 else "  有效避让率: N/A")

    # ── Formatted result table ──────────────────────────────────────────
    total_evaluated = model_violates + model_avoids
    total_rate = model_avoids / total_evaluated * 100 if total_evaluated > 0 else 0

    dir_avoids = {}
    dir_rate = {}
    for d in ["直行", "左转", "右转"]:
        cf = per_direction[d]["conflict_frames"]
        ma = per_direction[d]["model_avoids"]
        dir_avoids[d] = ma
        dir_rate[d] = ma / cf * 100 if cf > 0 else 0

    def _dw(s):
        w = 0
        for c in s:
            w += 2 if '一' <= c <= '鿿' or '　' <= c <= '〿' or '＀' <= c <= '￯' else 1
        return w
    def _pad(s, w):
        return s + ' ' * max(0, w - _dw(s))

    CW = 18
    label = f"复杂SR（{total_evaluated}）"
    print(f"\n")
    print(f"  {'':12s}{_pad('总计', CW)}{_pad('直行', CW)}{_pad('左转', CW)}{_pad('右转', CW)}")
    cells = [
        f'{total_rate:.2f}%（{model_avoids}）',
        f'{dir_rate["直行"]:.2f}%（{dir_avoids["直行"]}）',
        f'{dir_rate["左转"]:.2f}%（{dir_avoids["左转"]}）',
        f'{dir_rate["右转"]:.2f}%（{dir_avoids["右转"]}）',
    ]
    print(f"  {_pad(label, 12)}" + "".join(_pad(c, CW) for c in cells))

    print("\n" + "=" * 70)

    # ── Build result dict ────────────────────────────────────────────────
    result = {
        "total_groups": total_groups,
        "skipped_clip_filter": skipped_clip_filter,
        "skipped_no_forbidden": skipped_no_forbidden,
        "skipped_no_traj_label": skipped_no_traj_label,
        "skipped_origin_on_forbidden": skipped_origin_on_forbidden,
        "skipped_all_forward_forbidden": skipped_all_forward_forbidden,
        "skipped_no_conflict": skipped_no_conflict,
        "skipped_no_distance": skipped_no_distance,
        "skipped_no_curvature": skipped_no_curvature,
        "skipped_no_traj_pred": skipped_no_traj_pred,
        "evaluated": evaluated,
        "model_violates": model_violates,
        "model_avoids": model_avoids,
        "model_avoidance_rate": round(avoidance_rate, 2),
        "per_direction": {
            d: {
                "conflict_frames": per_direction[d]["conflict_frames"],
                "model_violates": per_direction[d]["model_violates"],
                "model_avoids": per_direction[d]["model_avoids"],
                "avoidance_rate": round(
                    per_direction[d]["model_avoids"] / per_direction[d]["conflict_frames"] * 100, 2
                ) if per_direction[d]["conflict_frames"] > 0 else 0.0,
            }
            for d in ["左转", "直行", "右转"]
        },
        "violation_reason_breakdown": {
            reason: {
                "count": count,
                "percentage": round(count / model_violates * 100, 2) if model_violates > 0 else 0.0,
            }
            for reason, count in violation_reason_counts.items()
        },
        "有效指标": {
            "评测总数": total_evaluated,
            "碰撞数": crash_count,
            "输出长度错误数": length_error_count,
            "有效评测数": effective_total,
            "实际进入禁行路数": effective_violates,
            "实际禁行路进入率": f"{effective_violates / effective_total * 100:.2f}%" if effective_total > 0 else "N/A",
            "有效避让率": f"{effective_avoidance_rate:.2f}%",
        },
    }

    # ── Save metrics ─────────────────────────────────────────────────────
    # remote_dir = os.path.dirname(jsonl_path)
    # output_path = os.path.join(remote_dir, 'no_entry_conflict_metrics_v2.json')
    # try:
    #     with open(output_path, 'w', encoding='utf-8') as f:
    #         json.dump(result, f, ensure_ascii=False, indent=2)
    #     print(f"\nMetrics saved to: {output_path}")
    # except PermissionError:
    #     output_path = 'no_entry_conflict_metrics_v2.json'
    #     with open(output_path, 'w', encoding='utf-8') as f:
    #         json.dump(result, f, ensure_ascii=False, indent=2)
    #     print(f"\nMetrics saved to: {output_path} (fallback)")

    return result


if __name__ == "__main__":
    # jsonl_path = sys.argv[1] if len(sys.argv) > 1 else (
    #     # "/perception-hl/beijin.zhou/action_model_output/0522_9.4Wclip_cot3_traj_vocab-20260522-182412"
    #     "/perception-hl/beijin.zhou/action_model_output/260601_no_entry_01_cot_forbid_exp3-r4-20260601-230239"
    #     # "/perception-hl/beijin.zhou/action_model_output/0525_minitrain_cot3_traj_vocab-20260526-111239"
    #     "/vla_train_out_no_entry_260526_test__df5f809__20260527082619_simplified/inference_result_<COT>.jsonl"
    # )
    # jsonl_path = "/perception-hl/beijin.zhou/action_model_output/0525_minitrain_cot3_traj_vocab-20260526-111239/vla_train_out_no_entry_260526_test__df5f809__20260527082619_simplified/inference_result_<NO_COT>.jsonl"
    # jsonl_path = "/perception-hl/beijin.zhou/action_model_output/260527_no_entry_no_cot_exp1-r4-20260528-111308/vla_train_out_no_entry_260526_test__df5f809__20260527082619_simplified/inference_result_<NO_COT>.jsonl"
    # jsonl_path = "/perception-hl/beijin.zhou/action_model_output/260601_no_entry_fake_cot_exp2-r4-20260601-214312/vla_train_out_no_entry_260526_test__df5f809__20260527082619_simplified/inference_result_<COT>.jsonl"
    # jsonl_path = "/perception-hl/beijin.zhou/action_model_output/260601_no_entry_01_cot_forbid_exp3-r4-20260601-230239/vla_train_out_no_entry_260526_test__df5f809__20260527082619_simplified/inference_result_<COT>.jsonl"
    # jsonl_path = "/perception-hl/beijin.zhou/action_model_output/260601_no_entry_01_cot_forbid_exp3-r4-mix-exit-20260602-182842/vla_train_out_no_entry_260526_test__df5f809__20260527082619_simplified/inference_result_<COT>.jsonl"
    # jsonl_path = "/perception-hl/beijin.zhou/action_model_output/260601_no_entry_01_cot_forbid_exp3-r4-mix-exit-20260602-182842/vla_train_out_no_entry_260526_test__df5f809__20260527082619_simplified/inference_result_<COT>.jsonl"
    # jsonl_path = "/perception-hl/beijin.zhou/action_model_output/260601_no_entry_01_cot_forbid_exp3-r4-20260602-180010/vla_train_out_no_entry_260526_test__df5f809__20260527082619_simplified/inference_result_<COT>.jsonl"

    ## 260606
    # jsonl_path = "/perception-hl/beijin.zhou/action_model_output/260606_no_entry_repeat_no_cot_pos-20260606-003727/vla_train_out_no_entry_260526_test__df5f809__20260527082619_simplified/inference_result_<NO_COT>.jsonl"
    # jsonl_path = "/perception-hl/beijin.zhou/action_model_output/260606_no_entry_repeat_cot_all-20260606-003842/vla_train_out_no_entry_260526_test__df5f809__20260527082619_simplified/inference_result_<COT>.jsonl"

    ## baseline
    jsonl_path = "/perception-hl/beijin.zhou/action_model_output/0522_9.4Wclip_cot3_traj_vocab-20260522-182412/vla_train_out_no_entry_260526_test__df5f809__20260527082619_simplified_raw_prompt/inference_result_<COT>.jsonl"

    ## 260601 exp
    # jsonl_path = "/perception-hl/beijin.zhou/action_model_output/260601_no_entry_01_cot_forbid_exp3-r4-20260601-230239/vla_train_out_no_entry_260526_test__df5f809__20260527082619_simplified/inference_result_<COT>.jsonl"
    # jsonl_path = "/perception-hl/beijin.zhou/action_model_output/260601_no_entry_01_cot_forbid_exp3-r4-20260602-180010/vla_train_out_no_entry_260526_test__df5f809__20260527082619_simplified/inference_result_<COT>.jsonl"
    # jsonl_path = "/perception-hl/beijin.zhou/action_model_output/260608_no_entry_repeat_no_cot_pos-20260608-134116/vla_train_out_no_entry_260526_test__df5f809__20260527082619_simplified_raw_prompt/inference_result_<NO_COT>.jsonl"

    pre_jsonl_path = "/perception-hl/beijin.zhou/projects/vlm_no_entry/dataset/replaced_prompt_output/dual_cot/vla_train_out_no_entry_260526_test__df5f809__20260527082619.jsonl"

    if not os.path.exists(jsonl_path):
        print(f"File not found: {jsonl_path}")
        sys.exit(1)

    print(f"Processing evaluation for: {jsonl_path}")
    if pre_jsonl_path:
        print(f"Pre-inference data: {pre_jsonl_path}\n")
    else:
        print("No pre-inference data provided (crash detection disabled)\n")

    # Run Easy Evaluation
    evaluate_direction_easy(jsonl_path, pre_jsonl_path)

    # Run Complex Evaluation
    evaluate_conflict_complex(jsonl_path, pre_jsonl_path)
