import math

class ADGeometry:
    def __init__(self, direction='vertical', front_edge_to_center=3.5, back_edge_to_center=1.0,
                 right_edge_to_center=1.2, left_edge_to_center=1.2):
        self.direction = direction
        self.front_edge_to_center = front_edge_to_center
        self.back_edge_to_center = back_edge_to_center
        self.right_edge_to_center = right_edge_to_center
        self.left_edge_to_center = left_edge_to_center
        
        if self.direction == 'horizontal':
            self.car_box = [[front_edge_to_center, \
                front_edge_to_center, \
                -back_edge_to_center, \
                -back_edge_to_center, \
                front_edge_to_center],\
                [right_edge_to_center,\
                -left_edge_to_center,\
                -left_edge_to_center,\
                right_edge_to_center,\
                right_edge_to_center]]
        elif self.direction == 'vertical':
            self.car_box = [
                [right_edge_to_center,\
                -left_edge_to_center,\
                -left_edge_to_center,\
                right_edge_to_center,\
                right_edge_to_center],
                [front_edge_to_center, \
                front_edge_to_center, \
                -back_edge_to_center, \
                -back_edge_to_center, \
                front_edge_to_center]]
        

    def set_width_length(self, width, length):
        self.width = width
        self.length = length
        self.car_box= [[length/2, \
            length/2, \
            -length/2, \
            -length/2, \
            length/2],\
            [width/2,\
            -width/2,\
            -width/2,\
            width/2,\
            width/2]]
    
    def tf_car2world_2d(self, x0_w, y0_w, theta_w):
        world_box = [[],[]]
        for i in range(len(self.car_box[0])):
            cos = math.cos(theta_w)
            sin = math.sin(theta_w)
            x_w = cos * self.car_box[0][i] - sin * self.car_box[1][i] + x0_w
            y_w = sin * self.car_box[0][i] + cos * self.car_box[1][i] + y0_w
            world_box[0].append(x_w)
            world_box[1].append(y_w)
        return world_box
    
    def point_car2world_2d(self, x0_w, y0_w, theta_w, car_x, car_y):
        cos = math.cos(theta_w)
        sin = math.sin(theta_w)
        x_w = cos * car_x - sin * car_y + x0_w
        y_w = sin * car_x + cos * car_y + y0_w
        return x_w, y_w