import os, niofs, time
import numpy as np
from PIL import Image
from io import BytesIO
from loguru import logger
from bokeh.plotting import ColumnDataSource
from bokeh.models import (LabelSet,
                          CategoricalColorMapper,
                          HoverTool,
                          DatetimeTickFormatter,
                          Arrow,
                          NormalHead)
from bokeh.palettes import TolRainbow
from base64 import b64encode

def convert_to_webp(image_data, quality=80, speed=4):
    """
    将图像转换为WebP格式，调整编码速度（0-6，0最快，6最慢但压缩率更高）
    """
    img = Image.open(BytesIO(image_data))
    output = BytesIO()
    # 设置编码速度，0最快，但压缩率可能较低；6最慢，压缩率更高。
    img.save(output, format='WEBP', quality=quality, method=speed, optimize=True)
    return output.getvalue()

class ArrowLayer:
    def __init__(self, fig, params) -> None:
        self.fig = fig
        self.data_source = ColumnDataSource(data=dict(x0=[], y0=[], x1=[], y1=[], angle=[]))
        self.x0 = 'x0'
        self.y0 = 'y0'
        self.x1 = 'x1'
        self.y1 = 'y1'
        
        self.segment = self.fig.segment(x0='x0', y0='y0', x1='x1', y1='y1',
                                        source=self.data_source, line_width=2, color='black')
        self.scatter = self.fig.scatter(x='x1', y='y1', size=14, marker='triangle', 
                                        angle='angle', source=self.data_source, color='black')
        
    def update(self, x_start, y_start, x_end, y_end):
        """更新数据源以绘制新箭头，之前的数据会被覆盖"""
        dx = x_end - x_start
        dy = y_end - y_start
        angle = np.arctan2(dy, dx) - 3.141593 / 2
        self.data_source.data = {
            'x0': [x_start],
            'y0': [y_start],
            'x1': [x_end],
            'y1': [y_end],
            'angle': [angle]
        }
    def clear(self):
        self.data_source.data = {
            'x0': [],
            'y0': [],
            'x1': [],
            'y1': [],
            'angle': []
        }

class ImageLayer:
    def __init__(self, fig, params) -> None:
        self.fig = fig
        self.url = "url"
        self.xs, self.ys = 'x', 'y'
        self.data_source = ColumnDataSource(data={
        self.url: [],
        # self.xs : [0],
        # self.ys : [0],
        })
        self.image = self.fig.image_url(self.url, source=self.data_source, **params)

    def update(self, url, client:niofs.Client=None, scale_factor=0.25):
        t0 = time.time()

        def parse_niofs_path(path: str):
            path = path.strip()
            if not path:
                raise ValueError("Empty path")

            if path.startswith("s3://"):
                path = path[5:]
            elif path.startswith("huailai_cos:"):
                path = path[12:]
            elif path.startswith("huailai:"):
                path = path[8:]

            path = path.lstrip("/")

            if "://" in path:
                parts = path.split("://", 1)
            elif ":" in path:
                parts = path.split(":", 1)
            elif "/" in path:
                parts = path.split("/", 1)
            else:
                raise ValueError(f"Invalid path format: {path}")

            bucket = parts[0].strip()
            key = parts[1].strip().lstrip("/")

            return bucket, key

        if 'ad-cn-ali-multimodal' in url:
            bucket, file_path = parse_niofs_path(url)
            image_data = client.get_object(bucket, file_path, Retry=True)['Body'].read()
            webp_data = convert_to_webp(image_data, quality=80, speed=0)
        elif ':' in url:
            bucket, file_path = client.divide_niofs_path(url)
            image_data = client.get_object(bucket, file_path, Retry=True)['Body'].read()
            webp_data = convert_to_webp(image_data, quality=80, speed=0)
        else:
            # 读取并编码图像
            if not os.path.exists(url):
                logger.warning(f'{url} not exists')
                return
            image_data = Image.open(url)
            new_width = int(image_data.width * scale_factor)
            new_height = int(image_data.height * scale_factor)
            resample_method = Image.Resampling.LANCZOS if hasattr(Image, 'Resampling') else Image.LANCZOS # 使用高质量缩放下采样
            image_data = image_data.resize((new_width, new_height), resample_method)
            output = BytesIO()
            image_data.save(output, format='WEBP', quality=80, method=0, optimize=True) # method 0-6，0最快
            webp_data = output.getvalue()

        b64_image = b64encode(webp_data).decode("utf-8")
        img_url = f"data:image/webp;base64,{b64_image}"
        t1 = time.time()
        self.data_source.data.update({
            self.url : [img_url],
            # self.xs: pts_xs,
            # self.ys: pts_ys,
        })
        
    def clear(self):
        self.data_source.data.update({
            self.url : [],
            # self.xs: pts_xs,
            # self.ys: pts_ys,
        })

class MultiPolygonColorLayer:
  def __init__(self, fig, params):
    self.fig = fig
    self.xs, self.ys, self.colors = 'pts_xs', 'pts_ys', 'colors'
    self.data_source = ColumnDataSource(data={
      self.xs: [],
      self.ys: [],
      self.colors: []
    })

    self.plot = self.fig.multi_polygons(self.xs,
                  self.ys,
                  color = self.colors,
                  # set visual properties for selected glyphs
                  # selection_color="yellow",

                  # set visual properties for non-selected glyphs
                  # nonselection_fill_alpha=0.2,
                  # nonselection_fill_color="blue",
                  # nonselection_line_color="firebrick",
                  # nonselection_line_alpha=1.0,
                  source=self.data_source,
                  **params)

  def update(self, pts_xs, pts_ys, colors):
    self.data_source.data.update({
      self.xs: pts_xs,
      self.ys: pts_ys,
      self.colors: colors
    })

class MultiPolygonLayer:
  def __init__(self, fig, params):
    self.fig = fig
    self.xs, self.ys = 'pts_xs', 'pts_ys'
    self.data_source = ColumnDataSource(data={
      self.xs: [],
      self.ys: [],
    })

    self.plot = self.fig.multi_polygons(self.xs,
                  self.ys,
                  source=self.data_source,
                  **params)

  def update(self, pts_xs, pts_ys):
    self.data_source.data.update({
      self.xs: pts_xs,
      self.ys: pts_ys,
    })

class MultiLinesWithColorLayer:
  def __init__(self, fig, params):
    self.fig = fig
    self.xs, self.ys, self.colors, self.types = 'pts_xs', 'pts_ys', 'line_colors', 'line_types'
    self.data_source = ColumnDataSource(data={
      self.xs: [],
      self.ys: [],
      self.colors: [],
      self.types: []
    })

    self.plot = self.fig.multi_line(self.xs,
                  self.ys,
                  line_color = self.colors,
                  line_dash = self.types,
                  source=self.data_source,
                  **params)

  def update(self, pts_xs, pts_ys, colors, types):
    self.data_source.data.update({
      self.xs: pts_xs,
      self.ys: pts_ys,
      self.colors: colors,
      self.types: types
    })
  
  def clear(self):
    self.data_source.data.update({
      self.xs: [],
      self.ys: [],
      self.colors: [],
      self.types: []
    })

class MultiLinesLayer:
  def __init__(self, fig, params):
    self.fig = fig
    self.xs, self.ys = 'pts_xs', 'pts_ys'
    self.data_source = ColumnDataSource(data={
      self.xs: [],
      self.ys: [],
    })

    self.plot = self.fig.multi_line(self.xs,
                  self.ys,
                  source=self.data_source,
                  **params)

  def update(self, pts_xs, pts_ys):
    self.data_source.data.update({
      self.xs: pts_xs,
      self.ys: pts_ys,
    })


class PointsWithColorLayer:
  def __init__(self, fig, params):
    self.fig = fig
    self.xs, self.ys, self.colors = 'pts_xs', 'pts_ys', 'point_colors'
    self.data_source = ColumnDataSource(data={
      self.xs: [],
      self.ys: [],
      self.colors: [],
    })
    self.plot = self.fig.scatter(self.xs,
                                 self.ys,
                                 color = self.colors,
                                 source = self.data_source,
                                 **params)
  def update(self, pts_xs, pts_ys, colors):
    self.data_source.data.update({
      self.xs: pts_xs,
      self.ys: pts_ys,
      self.colors: colors
    })


class PointsLayer:
  def __init__(self, fig, params):
    self.fig = fig
    self.xs, self.ys = 'pts_xs', 'pts_ys'
    self.data_source = ColumnDataSource(data={
      self.xs: [],
      self.ys: [],
    })

    self.plot = self.fig.scatter(self.xs,
                  self.ys,
                  source=self.data_source,
                  **params)

  def update(self, pts_xs, pts_ys):
    self.data_source.data.update({
      self.xs: pts_xs,
      self.ys: pts_ys,
    })

class TimeEnumLayer:
  def __init__(self, fig, enum_class, params):
    self.fig = fig
    self.time, self.enum_name, self.enum_value = 'time', 'enum_name', 'enum_value'
    self.data_source = ColumnDataSource(data={
        self.time: [],
        self.enum_name: [],
        self.enum_value: [],
    })
    # categories = [e.name for e in enum_class]
    # print(categories)
    # colors = TolRainbow[len(categories)]
    # color_mapper = CategoricalColorMapper(
    #     factors=categories, 
    #     palette=colors
    # )
    self.plot = self.fig.scatter(x=self.time, y=self.enum_name,
                                source=self.data_source, **params)
    # self.fig.xaxis.formatter = DatetimeTickFormatter(
    #         hours="%Y-%m-%d %H:%M",
    #         days="%m/%d %H:%M",
    #         months="%Y/%m",
    #         years="%Y"
    #     )
    hover = fig.select(dict(type=HoverTool))
    hover.tooltips = [
        ("时间", "@time{%F %T}"),
        ("类型", "@enum_value"),
    ]
    hover.formatters = {'@time': 'datetime'}  # 格式化时间显示
  
  def update(self, pts_time, pts_enum):
    self.data_source.data.update({
      self.time: pts_time,
      self.enum_name: [enum.name for enum in pts_enum],
      self.enum_value: [enum.value for enum in pts_enum]
    })

class TextLabelLayer:
  def __init__(self, fig, params):
    self.fig = fig
    self.xs, self.ys = 'pts_xs', 'pts_ys'
    self.texts = 'texts'
    self.data_source = ColumnDataSource(data={
      self.xs: [],
      self.ys: [],
      self.texts: []
    })
    
    self.plot = LabelSet(x=self.xs, y=self.ys, text=self.texts,
          x_offset=0, y_offset=0, source=self.data_source, **params)
    
    fig.add_layout(self.plot)    
    
  def update(self, pts_xs, pts_ys, texts):
    self.data_source.data.update({
      self.xs: pts_xs,
      self.ys: pts_ys,
      self.texts: texts
    })
  def clear(self):
    self.data_source.data.update({
      self.xs: [],
      self.ys: [],
      self.texts: []
    })
    
class BBoxLayer:
    def __init__(self, fig, params):
        self.fig = fig
        self.xs, self.ys, self.hs, self.ws = 'center_xs', 'cemter_ys', 'heights', 'widths'
        self.data_source = ColumnDataSource(data={
          self.xs: [],
          self.ys: [],
          self.hs: [],
          self.ws: []
        })
        self.plot = self.fig.rect(self.xs,
                  self.ys,
                  self.hs,
                  self.ws,
                  source=self.data_source,
                  **params)
    def update(self, center_xs, center_ys, heights, widths):
        self.data_source.data.update({
          self.xs: center_xs,
          self.ys: center_ys,
          self.hs: heights,
          self.ws: widths
        })
    def clear(self):
        self.data_source.data.update({
          self.xs: [],
          self.ys: [],
          self.hs: [],
          self.ws: []
        })
        
        
class BBoxWithColorLayer:
    def __init__(self, fig, params):
        self.fig = fig
        self.xs, self.ys, self.hs, self.ws, self.colors = 'center_xs', 'cemter_ys', 'heights', 'widths', 'line_colors'
        self.data_source = ColumnDataSource(data={
          self.xs: [],
          self.ys: [],
          self.hs: [],
          self.ws: [],
          self.colors: []
        })
        self.plot = self.fig.rect(self.xs,
                  self.ys,
                  self.hs,
                  self.ws,
                  line_color=self.colors,
                  source=self.data_source,
                  **params)
    def update(self, center_xs, center_ys, heights, widths, colors):
        self.data_source.data.update({
          self.xs: center_xs,
          self.ys: center_ys,
          self.hs: heights,
          self.ws: widths,
          self.colors: colors
        })
    def clear(self):
        self.data_source.data.update({
          self.xs: [],
          self.ys: [],
          self.hs: [],
          self.ws: [],
          self.colors: []
        })