import panel as pn
import abc
import os
import pickle as pkl
pn.extension()

class AbstractClipViewer(abc.ABC):

    def __init__(self, key_list, groups_3d, summ_pkl_path, open_save, model_name_watching=None):
        assert len(key_list) > 0 and len(groups_3d) > 0, 'data empty!'
        self.open_save = open_save
        self.summ_pkl_path = summ_pkl_path
        self.model_name_watching = model_name_watching
        self.key_list = key_list
        self.groups_3d = groups_3d
        self.clip_index = 0                     # 当前clip索引
        self.frame_index = 0                    # 当前clip中的frame索引
        self.vqa_index = 0                      # 当前clip的当前frame的VQA索引
        self.all_vqa_index = 0                  # 当前VQA在所有VQAs中的索引
        self.all_vqa_index_info = {}            # all_vqa_index与(clip_index, frame_index, vqa_idx)的映射表
        self.all_vqa_index_info_reserved = {}   # (clip_index, frame_index, vqa_idx)与all_vqa_index的映射表
        self.all_frame_index = 0                # 当前frame在所有frames中的索引
        self.all_frame_index_info = {}          # all_frame_index与(clip_index, frame_index, 0)的映射表
        self.all_frame_index_info_reserved = {} # (clip_index, frame_index, 0)与all_frame_index的映射表
        self.get_index_mapping() #计算映射表

        self.prev_clip_btn = pn.widgets.Button(name='上一包', button_type='primary')
        self.next_clip_btn = pn.widgets.Button(name='下一包', button_type='primary')
        self.prev_frame_btn = pn.widgets.Button(name='上一帧', button_type='primary')
        self.next_frame_btn = pn.widgets.Button(name='下一帧', button_type='danger')
        self.prev_qa_btn = pn.widgets.Button(name='上一问', button_type='primary')
        self.next_qa_btn = pn.widgets.Button(name='下一问', button_type='danger')
        self.save_btn = pn.widgets.Button(name='保存', button_type='warning')
        self.search_btn = pn.widgets.Button(name='搜索', button_type='warning')
        
        self.prev_clip_btn.on_click(self.prev_clip_pair)
        self.next_clip_btn.on_click(self.next_clip_pair)
        self.prev_frame_btn.on_click(self.prev_frame_pair)
        self.next_frame_btn.on_click(self.next_frame_pair)
        self.prev_qa_btn.on_click(self.prev_vqa_pair)
        self.next_qa_btn.on_click(self.next_vqa_pair)
        self.save_btn.on_click(self.save)
        self.search_btn.on_click(self.on_search)

        self.view = pn.Column()

    def get_index_mapping(self):
        vqa_count = 0
        frame_count = 0
        for clip_index in range(len(self.key_list)):
            clip_id = self.key_list[clip_index]
            clip_value = self.groups_3d[clip_id]
            if isinstance(clip_value, str) and os.path.exists(clip_value):
                clip_value = pkl.load(open(clip_value, "rb"))
            for frame_index in range(len(clip_value['frame_list'])):
                frame_id = clip_value['frame_list'][frame_index]
                self.all_frame_index_info[frame_count] = (clip_index, frame_index, 0)
                self.all_frame_index_info_reserved[(clip_index, frame_index, 0)] = frame_count
                frame_count += 1
                frame_value = clip_value[frame_id]
                if isinstance(frame_value, dict):
                    vqa_list = frame_value['vqa_list']
                elif hasattr(frame_value, 'prompt_info'):
                    vqa_list = frame_value.prompt_info.vqa_list
                else:
                    raise TypeError(f'not support frame_value type {type(frame_value)}')
                for vqa_idx in range(len(vqa_list)):
                    self.all_vqa_index_info[vqa_count] = (clip_index, frame_index, vqa_idx)
                    self.all_vqa_index_info_reserved[(clip_index, frame_index, vqa_idx)] = vqa_count
                    vqa_count += 1
                    
    def clear_index_mapping(self):
        self.clip_index = 0                     # 当前clip索引
        self.frame_index = 0                    # 当前clip中的frame索引
        self.vqa_index = 0                      # 当前clip的当前frame的VQA索引
        self.all_vqa_index = 0                  # 当前VQA在所有VQAs中的索引
        self.all_vqa_index_info = {}            # all_vqa_index与(clip_index, frame_index, vqa_idx)的映射表
        self.all_vqa_index_info_reserved = {}   # (clip_index, frame_index, vqa_idx)与all_vqa_index的映射表
        self.all_frame_index = 0                # 当前frame在所有frames中的索引
        self.all_frame_index_info = {}          # all_frame_index与(clip_index, frame_index, 0)的映射表
        self.all_frame_index_info_reserved = {} # (clip_index, frame_index, 0)与all_frame_index的映射表

    # 弹窗覆盖层
    def _create_popup(self, event=None, info_str=''):
        def close_popup(event):
            self.view.pop(-1)
        # 弹窗内容
        popup_content = pn.Column(
            pn.layout.HSpacer(height=300),
            pn.Row(
                pn.layout.HSpacer(),
                pn.Column(
                    pn.pane.Alert(info_str, alert_type="warning"),
                    pn.widgets.Button(name="确定", button_type="light"),
                    styles={"background": "white", "padding": "20px", "border-radius": "5px"}
                ),
                pn.layout.HSpacer()
            ),
            styles={
                "position": "fixed",
                "top": "0",
                "left": "0",
                "width": "100%",
                "height": "100%",
                "background": "rgba(0,0,0,0.3)",
                "z-index": "999"
            }
        )
        # 绑定确定按钮的点击事件
        popup_content[1][1][1].on_click(close_popup)  # 层级：Column > Row > Column > Button
        return popup_content

    def _toggle_popup(self, event=None, info_str=''):
        if "popup" not in self.view.objects:
            popup = self._create_popup(event, info_str)
            self.view.append(popup)

    @abc.abstractmethod
    def update_display(self, event=None):
        pass

    def prev_clip_pair(self, event=None):
        self.clip_index -= 1
        if self.clip_index < 0:
            self.clip_index = len(self.key_list) - 1
        self.frame_index = 0
        self.vqa_index = 0
        self.all_frame_index = self.all_frame_index_info_reserved[(self.clip_index, self.frame_index, 0)]
        self.all_vqa_index = self.all_vqa_index_info_reserved[(self.clip_index, self.frame_index, self.vqa_index)]
        self.update_display(event)

    def next_clip_pair(self, event=None):
        self.clip_index += 1
        if self.clip_index > len(self.key_list) - 1:
            self.clip_index = 0
        self.frame_index = 0
        self.vqa_index = 0
        self.all_frame_index = self.all_frame_index_info_reserved[(self.clip_index, self.frame_index, 0)]
        self.all_vqa_index = self.all_vqa_index_info_reserved[(self.clip_index, self.frame_index, self.vqa_index)]
        self.update_display(event)
    
    def prev_frame_pair(self, event=None):
        while True:
            self.all_frame_index -= 1
            if self.all_frame_index in self.all_frame_index_info:
                break

        if self.open_save:
            self.save()
        if self.all_frame_index < 0:
            self.all_frame_index = len(self.all_frame_index_info) - 1
        self.clip_index, self.frame_index, self.vqa_index = self.all_frame_index_info[self.all_frame_index]
        self.all_vqa_index = self.all_vqa_index_info_reserved[(self.clip_index, self.frame_index, self.vqa_index)]
        self.update_display(event)

    def next_frame_pair(self, event=None):
        while True:
            self.all_frame_index += 1
            if self.all_frame_index in self.all_frame_index_info:
                break
            
        if self.open_save:
            self.save()
        if self.all_frame_index >= len(self.all_frame_index_info):
            self.all_frame_index = 0
        self.clip_index, self.frame_index, self.vqa_index = self.all_frame_index_info[self.all_frame_index]
        self.all_vqa_index = self.all_vqa_index_info_reserved[(self.clip_index, self.frame_index, self.vqa_index)]
        self.update_display(event)

    def prev_vqa_pair(self, event=None):
        while True:
            self.all_vqa_index -= 1
            if self.all_vqa_index in self.all_vqa_index_info:
                break

        if self.all_vqa_index < 0:
            self.all_vqa_index = len(self.all_vqa_index_info) - 1
        self.clip_index, self.frame_index, self.vqa_index = self.all_vqa_index_info[self.all_vqa_index]
        self.all_frame_index = self.all_frame_index_info_reserved[(self.clip_index, self.frame_index, 0)]
        self.update_display(event)

    def next_vqa_pair(self, event=None):
        while True:
            self.all_vqa_index += 1
            if self.all_vqa_index in self.all_vqa_index_info:
                break

        if self.all_vqa_index >= len(self.all_vqa_index_info):
            self.all_vqa_index = 0
        self.clip_index, self.frame_index, self.vqa_index = self.all_vqa_index_info[self.all_vqa_index]
        self.all_frame_index = self.all_frame_index_info_reserved[(self.clip_index, self.frame_index, 0)]
        self.update_display(event)

    @abc.abstractmethod
    def save(self, event=None):
        pass

    @abc.abstractmethod
    def on_search(self, event=None):
        pass