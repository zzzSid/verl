from bokeh_wrapper.measure_tool import MeasureTools
import bokeh.plotting as bkp
from bokeh.models import TapTool, WheelZoomTool, BoxSelectTool

def GenTopViewFigsGroup(dict_set):
    title_name = list(dict_set.keys())[0]
    x_label = list(dict_set.values())[0]['x_label']
    y_label = list(dict_set.values())[0]['y_label']
    WIDTH = list(dict_set.values())[0]['size'][0]
    HEIGHT = list(dict_set.values())[0]['size'][1]
    fig = bkp.figure(title=title_name, x_axis_label=x_label, y_axis_label=y_label, match_aspect=True, \
                width=WIDTH, height=HEIGHT, output_backend="webgl")
    fig.min_border = 0
    fig.background_fill_color = 'gray'
    fig.background_fill_alpha = 0.5
    fig.xgrid.grid_line_color = 'gray'
    fig.xgrid.grid_line_alpha = 0.6
    fig.xgrid.grid_line_dash = 'dashed'
    fig.ygrid.grid_line_color ='gray'
    fig.ygrid.grid_line_alpha = 0.6
    fig.ygrid.grid_line_dash = 'dashed'
    fig.toolbar.active_scroll = fig.select_one(WheelZoomTool)
    fig.toolbar_location = "above"
    # 添加框选工具
    box_select = BoxSelectTool()
    fig.add_tools(box_select)
    # fig.add_tools(TapTool())
    # MeasureTools(fig)
    return fig

def CompareEgoAgentModalitySpeedData(dict_set):
    title_name = list(dict_set.keys())[0]
    x_label = list(dict_set.values())[0]['x_label']
    y_label = list(dict_set.values())[0]['y_label']
    WIDTH = list(dict_set.values())[0]['size'][0]
    HEIGHT = list(dict_set.values())[0]['size'][1]
    fig = bkp.figure(title=title_name, x_axis_label=x_label, y_axis_label=y_label, match_aspect=True, \
                width=WIDTH, height=HEIGHT, output_backend="webgl")
    fig.background_fill_color = 'gray'
    fig.background_fill_alpha = 0.5
    fig.xgrid.grid_line_color = 'gray'
    fig.xgrid.grid_line_alpha = 0.6
    fig.xgrid.grid_line_dash = 'dashed'
    fig.ygrid.grid_line_color ='gray'
    fig.ygrid.grid_line_alpha = 0.6
    fig.ygrid.grid_line_dash = 'dashed'
    fig.toolbar.active_scroll = fig.select_one(WheelZoomTool)
    fig.toolbar_location = "above"
    # MeasureTools(fig)
    return fig