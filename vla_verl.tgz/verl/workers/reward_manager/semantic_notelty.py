
"""
Semantic Novelty Reward Manager

This module implements a reward adjustment mechanism based on semantic novelty for RLHF training,
encouraging the model to generate both correct and innovative answers while avoiding repetitive or mediocre responses.

Core ideas:
1. For correct answers: Calculate maximum and average similarity with correct solution group, reward range 0.5-1
2. For incorrect answers: Only consider global similarity (average and maximum), reward range -1 to -0.5
3. \\boxed invalid answers: Directly give -1 reward

Uses remote vLLM API to compute embeddings, supporting efficient batch processing.
"""
## 确定 获取的是ans的embedding 还是 整个response的 embedding -> 整个response的 embedding
## self.n_votes_per_prompt #需要修正为 rollout_n

from collections import defaultdict
from transformers import AutoTokenizer,AutoModel
from typing import List,Dict
import numpy as np
import torch
import time
import random
import pdb
import os
import re
import requests
import json

from verl import DataProto
from verl.utils.reward_score import test_time_train_metrics
from verl.utils.reward_score.utils import *
from verl.utils.reward_score.orsta import *


# Optional import of HF tokenizer for token-level truncation of embedding text to avoid exceeding embedding model context
try:
    from transformers import AutoTokenizer  # type: ignore
    HF_TRANSFORMERS_AVAILABLE = True
except Exception:
    HF_TRANSFORMERS_AVAILABLE = False


class SemanticTTRLRewardManager:
    """
    TTRL Reward Manager with Semantic Novelty Adjustment
    
    This class adds semantic novelty evaluation mechanism on top of the original TTRL reward:
    1. Novelty calculation: Average similarity calculated within groups, maximum similarity calculated globally
    2. Novelty normalization: Normalized within correct answer groups, normalized within incorrect answer groups
    3. For correct answers: All correct answers receive positive rewards
       - All correct answers: reward range [0.5,1] (higher novelty = higher reward)
    4. For incorrect answers: All incorrect answers receive negative rewards
       - All incorrect answers: reward range [-1,-0.5] (higher novelty = less punishment)
    5. For \\boxed invalid answers: Directly give -1 reward, not participating in semantic similarity calculation
    
    Uses remote vLLM API to compute embeddings, supporting efficient batch processing.
    
    Simplified reward mechanism:
    - Correct answers: Uniformly rescaled to [0.5,1] range, higher novelty = higher reward
    - Incorrect answers: Uniformly rescaled to [-1,-0.5] range, higher novelty = less punishment
    - Invalid answers: Directly give -1 reward
    """

    def __init__(self,tokenizer,num_examine,reward_fn_key="data_source",compute_score=None,use_semantic_novelty: bool = True) -> None:
        # === Basic parameter setup ===
        self.tokenizer = tokenizer
        self.num_examine = num_examine
        self.reward_fn_key = reward_fn_key
        self.n_votes_per_prompt = 8 
        self.n_samples_per_prompt = 8 # rollouts中有多少用训练
        self.embedding_dim = 2560
        self.model_path = "/lustre/neos.yan/open_models/Qwen3-Embedding-4B"
        
      
        
        # Parameter validity check
        assert self.n_votes_per_prompt >= self.n_samples_per_prompt, \
            f"TTRL requirement: n_votes_per_prompt({self.n_votes_per_prompt}) >= n_samples_per_prompt({self.n_samples_per_prompt})"

        # === Semantic novelty parameter setup and validation ===
        self.use_semantic_novelty = use_semantic_novelty
        
    
        
        # Semantic novelty parameter validation
        if self.use_semantic_novelty:
            assert self.embedding_dim > 0, f"embedding_dim must be greater than 0, current value: {self.embedding_dim}"
        
        # Initialize related components
        if self.use_semantic_novelty:
            self._init_novelty_components()

    def _init_novelty_components(self):
        """
        Initialize semantic novelty related components
        """
        # Statistics
        self._retry_stats = {"total_calls": 0, "total_retries": 0, "failed_calls": 0}
        self._internal_step = 0
        
        # Novelty statistics (for wandb logging)
        self._novelty_stats = {}

        # Embedding-side tokenizer and safe token limit (leave safety margin to avoid overflow)
        # Note: vLLM server sets max_model_len=16384, here we pre-truncate on client side with slightly smaller threshold
        # to absorb tokenization differences and avoid server errors.
        self.embedding_max_token_len = 16000
        self._embedding_tokenizer = None
        if HF_TRANSFORMERS_AVAILABLE:
            try:
                # Use the same model name as embedding service for consistent tokenization behavior
                self._embedding_tokenizer = AutoTokenizer.from_pretrained(
                    self.model_path, trust_remote_code=True, use_fast=True
                )
                print("  - Embedding tokenizer: loaded, used for safe truncation")
            except Exception as e:
                self._embedding_tokenizer = None
                print(f"  - Embedding tokenizer: loading failed, fallback to character truncation ({e})")

    def _truncate_for_embedding(self, text: str) -> str:
        """
        Use embedding model's tokenizer to safely truncate text to no more than embedding_max_token_len tokens.
        If tokenizer cannot be used, fall back to conservative character truncation strategy (approximately 4 characters/token).
        """
        try:
            if self._embedding_tokenizer is not None:
                token_ids = self._embedding_tokenizer.encode(text, add_special_tokens=False)
                if len(token_ids) <= self.embedding_max_token_len:
                    return text
                # Keep the end part, discard the front (consistent with user requirements)
                truncated_ids = token_ids[-self.embedding_max_token_len:]
                truncated_text = self._embedding_tokenizer.decode(truncated_ids, skip_special_tokens=True)
                return truncated_text
            else:
                # Fallback: character truncation (roughly assuming ~4 characters/token)
                max_chars = self.embedding_max_token_len * 4
                # Keep end characters, discard front
                return text[-max_chars:]
        except Exception:
            # Any exception falls back to character truncation for robustness
            max_chars = self.embedding_max_token_len * 4
            return text[-max_chars:]

  
    def _get_semantic_embeddings_batch(self, texts: list[str]) -> list[np.ndarray]:
        """
        Batch get semantic embedding vectors for multiple texts (using remote vLLM API)
        """
        if not texts:
            return []

        # First perform safe truncation to avoid exceeding embedding server max_model_len
        original_count = len(texts)
        truncated_texts = []
        truncated_num = 0
        for t in texts:
            t2 = self._truncate_for_embedding(t)
            if t2 is not t and len(t2) < len(t):
                truncated_num += 1
            truncated_texts.append(t2)
        if truncated_num > 0:
            print(f"    Safely truncated {truncated_num}/{original_count} texts to adapt to embedding model length limit")

        MAX_BATCH_SIZE = 512

        if len(truncated_texts) > MAX_BATCH_SIZE:
            all_embeddings = []
            for i in range(0, len(truncated_texts), MAX_BATCH_SIZE):
                batch_texts = truncated_texts[i:i + MAX_BATCH_SIZE]
                batch_embeddings = self._get_embeddings_batch_direct(batch_texts) # 调用 _get_embeddings_batch_direct() 函数获取 embedding
                all_embeddings.extend(batch_embeddings)
            return all_embeddings
            
        return self._get_embeddings_batch_direct(truncated_texts) 
    
    def _get_embeddings_batch_direct(self, texts: list[str]) -> list[np.ndarray]:
        """
        Directly call remote vLLM API to get embedding vectors
        """
        try:
            embeddings = cal_batch_embedding(texts)
            return embeddings
            
        except Exception as e:
            print(f"Get batch embeddings failed! {str(e)}")
            print(f"Falling back to single text processing...")
            return [self._get_semantic_embedding_single(text) for text in texts] #批量推理失败的话 单个推理
    
    def _get_semantic_embedding_single(self, text: str) -> np.ndarray:
        """
        Get semantic embedding vector for a single text (fallback solution)
        """
        try:
            embedding = cal_single_embedding(text)
            return embedding

        except Exception as e:
            print(f"Get semantic embedding single failed! {str(e)}")
            print(f"Falling back to random embedding vector...")
            np.random.seed(hash(text) % (2**32 - 1))
            return np.random.rand(self.embedding_dim).astype(np.float32)

    def _extract_answer(self,solution_str:str)->str:
        return extract_answer(solution_str)
        
    def _is_format_valid(self,data_list:List[Dict])->List[bool]:
        format_rewards = [0.0]*len(data_list)
        for i,item in enumerate(data_list):
            question = item['ground_truth'].get('question',None)
            question_type = item['ground_truth'].get('verifier',None)
            gt = item['ground_truth'].get('ground_truth',None)
            pred = item.get('solution_str',None)
            try:
                score = orsta_format_reward(pred,question_type,question,gt)
            except:
                score = 0.0
            format_rewards[i] =  score 
        format_valid = [score > 0.0 for score in format_rewards]

        return format_valid

    def _compute_novelty_rewards(self, pred_outputs: list[str], base_rewards: list[float], data_list: List[Dict]) -> list[float]:
        """
        Core method for semantic novelty reward calculation
        
        New reward calculation logic:
        1. Novelty calculation: Average similarity calculated within groups (correct vs correct, incorrect vs incorrect), maximum similarity calculated globally
        2. Novelty normalization: Normalized within correct answer groups, normalized within incorrect answer groups to [0,1] range
        3. For correct answers: Control positive reward ratio based on positive_reward_ratio
           - Top ratio answers: Secondary rescale to [0.5,1] range (fully utilize positive reward space)
           - Remaining answers: Secondary rescale to [-1,-0.5] range (fully utilize negative reward space)
        4. For incorrect answers: All incorrect answers handled uniformly
           - All incorrect answers: rescaled to [-1,-0.5] range (higher novelty = less punishment)
        5. \\boxed invalid answers: Directly give -1 reward, not participating in semantic similarity calculation
        6. Simplified reward strategy: Correct answers [0.5,1], incorrect answers [-1,-0.5], adjusted based on novelty
        """
      
        n_answers = len(pred_outputs)
        
        # Edge case: single answer cannot calculate novelty
        if n_answers <= 1:
            final_rewards = base_rewards
            # Set basic statistics
            self._novelty_stats = {
                "answer_groups": {
                    "n_correct": sum(1 for r in base_rewards if r > 0),
                    "n_incorrect": sum(1 for r in base_rewards if r <= 0),
                    "n_invalid_boxed": 0,
                    "n_positive_rewards": sum(1 for r in base_rewards if r > 0),
                    "n_negative_rewards": sum(1 for r in base_rewards if r <= 0),
                    "n_zero_rewards": 0
                }
            }
        else:
            # === Step 1: Extract content after </think> for semantic comparison ===
            # print(f"    Extracting final answer parts from {n_answers} answers...")  # Simplified output
            processed_outputs = []
            invalid_indices = []
           
 
            for i, output in enumerate(pred_outputs):
                after_think = self._extract_answer(output)  #自己实现 提取答案内容
                processed_outputs.append(after_think)
                
            valid_indices = self._is_format_valid(data_list)
            for i,valid in enumerate(valid_indices):
                if not valid:
                    invalid_indices.append(i)



            # === Handle \boxed invalid answers: directly give -1 reward ===
            if invalid_indices:
                # print(f"    Found {len(invalid_indices)} \\boxed invalid answers, directly giving -1 reward...")
                
                final_rewards_with_invalid = [-1.0] * n_answers
                
                # Record invalid boxed statistics and include complete necessary keys
                self._novelty_stats = {
                    "answer_groups": {
                        "n_correct": sum(1 for r in base_rewards if r > 0),
                        "n_incorrect": sum(1 for r in base_rewards if r <= 0),
                        "n_invalid_boxed": len(invalid_indices),
                        "n_positive_rewards": 0,
                        "n_negative_rewards": len(invalid_indices),
                        "n_zero_rewards": 0
                    }
                }
                
                if len(invalid_indices) == n_answers:
                    # print(f"    All answers are \\boxed invalid, all given -1 reward")
                    final_rewards = final_rewards_with_invalid
                else:
                    # Filter out valid answers to continue similarity calculation
                    valid_indices = [i for i in range(n_answers) if i not in invalid_indices]
                    # print(f"    Calculating novelty for {len(valid_indices)} \\boxed valid answers...")
                    
                    # Rebuild data containing only valid answers
                    processed_outputs = [processed_outputs[i] for i in valid_indices]
                    base_rewards = [base_rewards[i] for i in valid_indices]
                    n_answers = len(processed_outputs)
                    
                    if n_answers <= 1:
                        # print(f"    Insufficient valid answers (<2), cannot calculate novelty")
                        final_rewards = final_rewards_with_invalid
                    else:
                        # Calculate novelty rewards
                        computed_rewards = self._compute_similarity_based_rewards(processed_outputs, base_rewards)
                        
                        # Map calculated novelty rewards back to original positions
                        for i, valid_idx in enumerate(valid_indices):
                            final_rewards_with_invalid[valid_idx] = computed_rewards[i]
                        
                        final_rewards = final_rewards_with_invalid
            else:
                # Normal mode: calculate novelty for all answers
                final_rewards = self._compute_similarity_based_rewards(processed_outputs, base_rewards) # 调用 _compute_similarity_based_rewards 计算格式正确的奖励
        
        
        return final_rewards

    def _compute_similarity_based_rewards(self, processed_outputs: list[str], base_rewards: list[float]) -> list[float]:
        """
        Core logic for calculating novelty rewards based on similarity
        1.创新性计算：组内平均相似度 与 全局最大相似度
        2.新颖性归一化: 在正确答案组内进行归一化 在错误答案组内归一化至[0,1]
        3.对于正确答案: 所有正确答案均按[0.5,1]范围重新规定 (higher novelty = higher reward)
        4.对于错误答案: 所有错误答案均按[-1,-0.5]区间重新缩放 (higher novelty = less punishment)
        5.简化奖励策略: 正确答案[0.5,1],错误答案[-1,-0.5]
        """
        n_answers = len(processed_outputs)
        
        # Initialize novelty statistics collection
        novelty_stats = {
            "answer_groups": {},
            "novelty_scores": {},
            "rewards": {},
            "similarity": {}
        }
     
        # === Step 2: Batch get semantic embeddings for processed texts ===
        # print(f"    Batch calculating semantic embeddings for {n_answers} final answers...")  # Simplified output
        embeddings = self._get_semantic_embeddings_batch(processed_outputs)

        # === Step 3: Calculate similarity matrix ===
        # print(f"    Calculating {n_answers}x{n_answers} similarity matrix...")  # Simplified output
        
        # Convert embedding list to matrix
        embedding_matrix = np.array(embeddings, dtype=np.float32)
        
        # Calculate L2 norm for normalization
        norms = np.linalg.norm(embedding_matrix, axis=1, keepdims=True)
        norms = np.maximum(norms, 1e-8)
        
        # Normalize embedding matrix
        normalized_embeddings = embedding_matrix / norms
        
        # Calculate cosine similarity matrix
        cosine_sim_matrix = np.dot(normalized_embeddings, normalized_embeddings.T)
        
        # Clip to [0,1] range
        sim_matrix = np.clip(cosine_sim_matrix, 0.0, 1.0)
        
        # Record similarity statistics
        upper_triangle_mask = np.triu(np.ones_like(sim_matrix, dtype=bool), k=1)
        similarity_values = sim_matrix[upper_triangle_mask]
        novelty_stats["similarity"]["mean"] = float(np.mean(similarity_values))
        novelty_stats["similarity"]["std"] = float(np.std(similarity_values))
        novelty_stats["similarity"]["min"] = float(np.min(similarity_values))
        novelty_stats["similarity"]["max"] = float(np.max(similarity_values))
        
        # === Step 4: Group by correctness ===
        correct_indices = [i for i, r in enumerate(base_rewards) if r > 0]
        incorrect_indices = [i for i, r in enumerate(base_rewards) if r <= 0]
        
        # print(f"    Semantic novelty calculation: {len(correct_indices)} correct answers, {len(incorrect_indices)} incorrect answers")
        
        # Record answer group statistics
        novelty_stats["answer_groups"]["n_correct"] = len(correct_indices)
        novelty_stats["answer_groups"]["n_incorrect"] = len(incorrect_indices)
        
        # === Step 5: Calculate normalized novelty scores ===
        # print(f"    Calculating normalized novelty scores (average: within groups, maximum: globally)...")  # Simplified output
        
        novelty_scores = np.zeros(n_answers)
        
        for i in range(n_answers):
            is_correct = base_rewards[i] > 0
            
            # Average similarity: only calculated within same group
            if is_correct:
                # Correct answers: only calculate average similarity with other correct answers
                group_indices = [j for j in correct_indices if j != i]
            else:
                # Incorrect answers: only calculate average similarity with other incorrect answers
                group_indices = [j for j in incorrect_indices if j != i]
            
            # Maximum similarity: calculated with all other answers
            all_other_indices = [j for j in range(n_answers) if j != i]
            
            if group_indices:
                # Intra-group average similarity
                group_similarities = [sim_matrix[i, j] for j in group_indices]
                avg_similarity = np.mean(group_similarities)
            else:
                # If only one answer in group, use global average similarity
                if all_other_indices:
                    all_similarities = [sim_matrix[i, j] for j in all_other_indices]
                    avg_similarity = np.mean(all_similarities)
                else:
                    avg_similarity = 0.5  # Global single answer case
            
            if all_other_indices:
                # Global maximum similarity
                all_similarities = [sim_matrix[i, j] for j in all_other_indices]
                max_similarity = np.max(all_similarities)
            else:
                max_similarity = 0.5  # Global single answer case
            
            # Use weighted combination: 50% average similarity + 50% maximum similarity
            combined_similarity = 0.5 * avg_similarity + 0.5 * max_similarity
            novelty_scores[i] = 1.0 - combined_similarity
            
        
        # === Step 6: Normalize novelty scores by group to [0,1] range ===
        # print(f"    Normalizing novelty scores by group...")  # Simplified output
        
        # Normalize correct answer group and incorrect answer group separately
        if correct_indices and len(correct_indices) > 1:
            correct_novelty_scores = novelty_scores[correct_indices]
            min_correct = np.min(correct_novelty_scores)
            max_correct = np.max(correct_novelty_scores)
            if max_correct > min_correct:
                normalized_correct = (correct_novelty_scores - min_correct) / (max_correct - min_correct)
                for i, idx in enumerate(correct_indices):
                    novelty_scores[idx] = normalized_correct[i]
            
        elif correct_indices:
            # Only one correct answer, set to medium novelty
            for idx in correct_indices:
                novelty_scores[idx] = 0.5
        
        if incorrect_indices and len(incorrect_indices) > 1:
            incorrect_novelty_scores = novelty_scores[incorrect_indices]
            min_incorrect = np.min(incorrect_novelty_scores)
            max_incorrect = np.max(incorrect_novelty_scores)
            if max_incorrect > min_incorrect:
                normalized_incorrect = (incorrect_novelty_scores - min_incorrect) / (max_incorrect - min_incorrect)
                for i, idx in enumerate(incorrect_indices):
                    novelty_scores[idx] = normalized_incorrect[i]
            
        elif incorrect_indices:
            # Only one incorrect answer, set to medium novelty
            for idx in incorrect_indices:
                novelty_scores[idx] = 0.5
        
        # Record novelty score statistics
        novelty_stats["novelty_scores"]["mean"] = float(np.mean(novelty_scores))
        novelty_stats["novelty_scores"]["std"] = float(np.std(novelty_scores))
        novelty_stats["novelty_scores"]["min"] = float(np.min(novelty_scores))
        novelty_stats["novelty_scores"]["max"] = float(np.max(novelty_scores))
        
        # Group novelty statistics
        if correct_indices:
            correct_novelty = novelty_scores[correct_indices]
            novelty_stats["novelty_scores"]["correct"] = {
                "mean": float(np.mean(correct_novelty)),
                "std": float(np.std(correct_novelty))
            }
        
        if incorrect_indices:
            incorrect_novelty = novelty_scores[incorrect_indices]
            novelty_stats["novelty_scores"]["incorrect"] = {
                "mean": float(np.mean(incorrect_novelty)),
                "std": float(np.std(incorrect_novelty))
            }
        
        # === Step 7: Assign rewards for correct answers ===
        # Simplified output - remove detailed reward assignment information

        final_rewards = np.zeros(n_answers)

        if correct_indices:
            correct_novelty_scores = novelty_scores[correct_indices]
            n_correct = len(correct_indices)

            # All correct answers assigned to [0.5,1] range, rescaled based on novelty
            if len(correct_indices) > 1:
                min_correct = min(correct_novelty_scores)
                max_correct = max(correct_novelty_scores)
                if max_correct > min_correct:
                    # Rescale to [0.5,1] range
                    for i, idx in enumerate(correct_indices):
                        novelty = novelty_scores[idx]
                        rescaled_novelty = (novelty - min_correct) / (max_correct - min_correct)
                        final_rewards[idx] = 0.5 + 0.5 * rescaled_novelty  # Map to [0.5,1]
                else:
                    # All correct answers have same novelty, give medium reward
                    for idx in correct_indices:
                        final_rewards[idx] = 0.75  # Midpoint of [0.5,1]
            else:
                # Only one correct answer, give highest reward
                final_rewards[correct_indices[0]] = 1.0

            
            # Record correct answer reward statistics
            novelty_stats["answer_groups"]["n_positive_rewards"] = len(correct_indices)
            novelty_stats["answer_groups"]["n_negative_rewards"] = 0
            novelty_stats["answer_groups"]["n_zero_rewards"] = 0
            
            correct_rewards = [final_rewards[idx] for idx in correct_indices]
            novelty_stats["rewards"]["positive_rewards"] = {
                "mean": float(np.mean(correct_rewards)),
                "std": float(np.std(correct_rewards))
            }
            
            # Clear negative reward statistics
            novelty_stats["rewards"]["negative_rewards"] = {
                "mean": 0.0,
                "std": 0.0
            }
        
        # === Step 8: Assign rewards for incorrect answers ===
        # print(f"    Assigning rewards for incorrect answers (all incorrect answers in [-1,-0.5] range)...")  # Simplified output

        if incorrect_indices:
            incorrect_novelty_scores = novelty_scores[incorrect_indices]
            n_incorrect = len(incorrect_indices)

            # All incorrect answers assigned to [-1,-0.5] range, rescaled based on novelty
            if len(incorrect_indices) > 1:
                min_incorrect = min(incorrect_novelty_scores)
                max_incorrect = max(incorrect_novelty_scores)
                if max_incorrect > min_incorrect:
                    # Rescale to [-1,-0.5] range
                    for i, idx in enumerate(incorrect_indices):
                        novelty = novelty_scores[idx]
                        rescaled_novelty = (novelty - min_incorrect) / (max_incorrect - min_incorrect)
                        final_rewards[idx] = -1.0 + 0.5 * rescaled_novelty  # Map to [-1,-0.5]
                else:
                    # All incorrect answers have same novelty, give medium reward
                    for idx in incorrect_indices:
                        final_rewards[idx] = -0.75  # Midpoint of [-1,-0.5]
            else:
                # Only one incorrect answer, give relatively high error reward
                final_rewards[incorrect_indices[0]] = -0.5

            
            
            # Record incorrect answer reward statistics
            incorrect_rewards = [final_rewards[idx] for idx in incorrect_indices]
            novelty_stats["rewards"]["incorrect_novel_rewards"] = {
                "mean": float(np.mean(incorrect_rewards))
            }
            
            # Clear group statistics
            novelty_stats["rewards"]["incorrect_not_novel_rewards"] = {
                "mean": 0.0
            }
        

        
        # Record overall reward statistics
        all_rewards = final_rewards.flatten() if isinstance(final_rewards, np.ndarray) else final_rewards
        novelty_stats["rewards"]["mean"] = float(np.mean(all_rewards))
        novelty_stats["rewards"]["std"] = float(np.std(all_rewards))
        novelty_stats["rewards"]["min"] = float(np.min(all_rewards))
        novelty_stats["rewards"]["max"] = float(np.max(all_rewards))
        
        # Save statistics to class member variable
        self._novelty_stats = novelty_stats
        
       
        return final_rewards.tolist()

    #  a token-level entropy regularizer to maintain diversity during the initial generation process:
    def _compute_strategy_entropy(self, data_items):
        """
        Calculate strategy entropy Ĥ_ttrl(π_θ) = -1/N ∑(i=1 to N) (1/|y*|) ∑(t=1 to |y*|) log π_θ(y_t*|y_<t)

        Note: Returns token-normalized negative log-likelihood (similar to cross-entropy) for easy comparison across different sequence lengths

        Args:
            data_items: List of data items from DataProto

        Returns:
            float: Average normalized negative log-likelihood value (averaged by token)
        """
        try:
            if not data_items:
                return 0.0

            total_neg_log_likelihood = 0.0
            total_sequences = 0
            first_success = True

            for data_item in data_items:
                try:
                    # Check if log probability data exists
                    if hasattr(data_item, 'batch') and "old_log_probs" in data_item.batch:
                        # Get response length
                        prompt_length = data_item.batch["prompts"].shape[-1]
                        attention_mask = data_item.batch.get("attention_mask", None)

                        if attention_mask is not None and len(attention_mask) > prompt_length:
                            response_length = attention_mask[prompt_length:].sum().item()

                            if response_length > 0:
                                old_log_probs = data_item.batch["old_log_probs"]

                                # Fix slicing logic: old_log_probs only contains response part
                                if isinstance(old_log_probs, torch.Tensor) and old_log_probs.numel() > 0:
                                    log_probs_length = old_log_probs.shape[-1]

                                    # Choose slicing strategy based on actual length of old_log_probs
                                    if log_probs_length == response_length:
                                        # Case 1: old_log_probs only contains response part, use directly
                                        response_log_probs = old_log_probs
                                    elif log_probs_length == prompt_length + response_length:
                                        # Case 2: old_log_probs contains prompt+response, need to slice
                                        response_log_probs = old_log_probs[prompt_length:prompt_length+response_length]
                                    elif log_probs_length > response_length:
                                        # Case 3: Take last response_length tokens (fallback strategy)
                                        response_log_probs = old_log_probs[-response_length:]
                                    else:
                                        # Case 4: Insufficient length, skip
                                        continue

                                    # Calculate total log probability of sequence (sum over all tokens)
                                    if response_log_probs.numel() > 0:
                                        sequence_log_prob = torch.sum(response_log_probs).item()
                                        # Calculate normalized negative log-likelihood (averaged by token)
                                        normalized_neg_log_likelihood = -sequence_log_prob / response_length
                                        total_neg_log_likelihood += normalized_neg_log_likelihood
                                        total_sequences += 1

                                        # Print debug info on first success
                                        if first_success: 
                                            print(f"    Strategy entropy calculation enabled: old_log_probs shape={old_log_probs.shape}, response_length={response_length}")
                                            first_success = False
                except Exception as e:
                    # Single data item processing failed, skip
                    continue

            # Calculate average negative log-likelihood
            if total_sequences > 0:
                return total_neg_log_likelihood / total_sequences
            else:
                return 0.0

        except Exception as e:
            # Overall calculation failed, return 0
            return 0.0


    def _compute_ttrl_reward(self, data: DataProto):
        """
        Calculate TTRL rewards during training (with semantic novelty adjustment)
        
        This is the core method for training mode, responsible for:
        1. Processing data by prompt groups
        2. Using test_time_train_metrics to calculate base rewards (based on voting)
        3. Applying semantic novelty adjustment (if enabled)
        4. Building reward tensor for training use

        Args:
            data (DataProto): Training data containing prompts, responses, etc.
            
        Returns:
            tuple: (reward_tensor, reward_extra_info, ttrl_info)
                - reward_tensor: Reward tensor with shape (batch_size, seq_len)
                - reward_extra_info: Additional reward information
                - ttrl_info: TTRL training metrics

        改用 ground_truth['id'] 收拢同一 prompt 的所有回答，再写回原始顺序。
        """
        

        # print(f"Starting TTRL reward calculation during training (semantic novelty: {'enabled' if self.use_semantic_novelty else 'disabled'})...")

        reward_extra_info = defaultdict(list)
        ttrl_info = {}

        # ===  collect prompt groups by id. like {'11818':0,1,2,3,4,5,6,7} === 
        id2items = defaultdict(list)
        for idx, item in enumerate(data):
            gid = item.non_tensor_batch["reward_model"]["ground_truth"]['id']
            id2items[gid].append(idx)

        #  === Initialize reward tensor  === 

        ## 这里因为data不是按照id顺序组织的 所以截断的话 并不能实现一组中选择若干个
        # # Initialize reward tensor: only allocate space for samples actually used for training
        # reward_tensor = torch.zeros_like(
        #     data.batch["responses"][:prompt_num * self.n_samples_per_prompt], 
        #     dtype=torch.float32
        # )
        
        reward_tensor = torch.zeros_like(data.batch["responses"], dtype=torch.float32)
            
        scores = [0.0 for _ in range(len(data))] # Scores for all samples
        all_ttrl_metrics = defaultdict(list) # Collect all TTRL metrics

        # ===  Process by prompt groups === 
        for gid, idx_list in id2items.items():
            #  collect one prompt's all responses
            group_pred_outputs = []
            group_labels = []
            group_extra_info = []
            current_group_data = []
            current_group_data_list = []
            valid_response_lengths = [] #记录每个response reward的填充位置

            for idx in idx_list:

                item = data[idx]
                current_group_data.append(item)

                # Parse token sequences
                prompt_idx = item.batch["prompts"]
                prompt_length = prompt_idx.shape[-1]
                valid_prompt_length = item.batch["attention_mask"][:prompt_length].sum()
                valid_prompt_idx = prompt_idx[-valid_prompt_length:]
                
                response_idx = item.batch["responses"]
                valid_response_length = item.batch["attention_mask"][prompt_length:].sum()
                valid_response_idx = response_idx[:valid_response_length]
                

                # Decode to text
                prompt_str = self.tokenizer.decode(valid_prompt_idx, skip_special_tokens=False)
                response_str = self.tokenizer.decode(valid_response_idx, skip_special_tokens=False)
                response_str = response_str.split('<|im_end|>')[0].strip()
                if len(response_str) > 0 and response_str[0] == ':':
                    response_str = response_str[1:]
                
                # Get metadata
                ground_truth = item.non_tensor_batch["reward_model"]["ground_truth"]
                data_source = item.non_tensor_batch[self.reward_fn_key]
                extra_info = item.non_tensor_batch["extra_info"]
                    

                group_pred_outputs.append(response_str)
                group_labels.append(ground_truth)
                group_extra_info.append(extra_info)

                valid_response_lengths.append(valid_response_length)

                temp_data = {
                    "ground_truth": ground_truth,
                    "data_source": data_source,
                    "solution_str": response_str,
                    "extra_info": extra_info,
                }
                current_group_data_list.append(temp_data)
            question_type = temp_data["ground_truth"]["verifier"]



            # === Calculate base rewards (correctness judgment based on voting) TTRL ===
            base_rewards, ttrl_metrics = test_time_train_metrics(current_group_data_list)

            # === Calculate strategy entropy ===
            strategy_entropy = self._compute_strategy_entropy(current_group_data)
            ttrl_metrics["neg_log_likelihood"] = strategy_entropy
            if strategy_entropy > 0:
                print(f"    Strategy entropy: H_ttrl={strategy_entropy:.3f} (normalized negative log-likelihood)")

            # === Apply semantic novelty adjustment ===
            if self.use_semantic_novelty:
                # print(f"    Applying semantic novelty adjustment...")
                final_rewards = self._compute_novelty_rewards(group_pred_outputs, base_rewards,current_group_data_list)
            else:
                print(f"    Using original TTRL rewards...")
                final_rewards = base_rewards
            
            
            # === Fill reward tensor and score list === 

            for i,idx in enumerate(idx_list):
                scores[idx] = final_rewards[i]
                # Accumulate TTRL metrics ttrl_metrics -> all_ttrl_metrics
                for k, v in ttrl_metrics.items():
                    all_ttrl_metrics[k].append(v)


        # === Update accuracy field in data ===
        data.batch["acc"] = torch.tensor(scores, dtype=torch.float32, device=data.batch["prompts"].device)

        ## 这里 id_list,valid_response_lengths,scores 位置一一对应
        for i,length,score in zip(idx_list,valid_response_lengths,scores):
            reward_tensor[i,length-1] = score
     

        # === Calculate and output average metrics ===
        print(f"\n=== TTRL Training Metrics Summary ===")
        for k, v in all_ttrl_metrics.items():
            if isinstance(v, list):
                avg_v = np.mean(v)
                print(f"[{k}] {avg_v:.4f}")
                ttrl_info[k] = avg_v


        return reward_tensor, dict(reward_extra_info), ttrl_info


    def __call__(self, data: DataProto, return_dict=False):
        """
        Main calling interface for reward manager
        
        Automatically selects appropriate reward calculation method based on current mode (train/eval).
        This is the main entry point for external calls. Each call automatically increments internal step counter for wandb logging.
        
        Args:
            data (DataProto): Input data containing prompts, responses, etc.
            return_dict (bool): Whether to return detailed information dictionary
                - False: Only return reward tensor
                - True: Return dictionary containing reward tensor, extra information and metrics
                
        Returns:
            torch.Tensor or dict: 
                - If return_dict=False: Return reward tensor
                - If return_dict=True: Return dictionary with the following keys:
                    * "reward_tensor": Reward tensor
                    * "reward_extra_info": Additional reward information
                    * "ttrl_info": TTRL training/evaluation metrics
                    
        Example:
            >>> manager = TTRLRewardManager(tokenizer, ...)
            >>> 
            >>> # Simple call, only get reward tensor (automatically logged to wandb)
            >>> rewards = manager(data)
            >>> 
            >>> # Detailed call, get complete information (automatically logged to wandb)
            >>> result = manager(data, return_dict=True)
            >>> rewards = result["reward_tensor"]
            >>> metrics = result["ttrl_info"]
        """
        # Increment internal step counter
        if self.use_semantic_novelty:
            self._internal_step += 1
        
        print(f"\n{'='*50}")
        print(f"TTRLRewardManager execution started")
        print(f"Data size: {len(data)}")
        print(f"Semantic novelty: {'enabled' if self.use_semantic_novelty else 'disabled'}")
        if self.use_semantic_novelty:
            print(f"Internal step: {self._internal_step}")
        print(f"{'='*50}")
        
        # Select appropriate calculation method based on mode
        """
        __call__()-> _compute_ttrl_reward()
        _compute_ttrl_reward()
            -> test_time_train_metrics() 计算每组的 ttrl_reward 
            -> self._compute_strategy_entropy() 计算每组的 strategy_entropy 
            -> self._compute_novelty_rewards() 计算 novelty_rewards

        """
        reward_tensor, reward_extra_info, ttrl_info = self._compute_ttrl_reward(data)
    
    
        print(f"\n{'='*50}")
        print(f"TTRLRewardManager execution completed")
        print(f"Reward tensor shape: {reward_tensor.shape}")
        print(f"Average reward: {reward_tensor.mean().item():.4f}")
        print(f"Reward range: [{reward_tensor.min().item():.4f}, {reward_tensor.max().item():.4f}]")
        print(f"{'='*50}\n")

        # Return result based on return format requirements
        if return_dict:
            return {
                "reward_tensor": reward_tensor,
                "reward_extra_info": reward_extra_info,
                "ttrl_info": ttrl_info,
            }
        else:
            return reward_tensor 

"""
Usage Example - Semantic Novelty Reward Manager
==============================================

# Simplified reward allocation logic:
# - Novelty calculation: Average similarity calculated within groups, maximum similarity calculated globally, normalized to [0,1] within each group
# - Correct answers: All correct answers rescaled to [0.5,1] range (higher novelty = higher reward)
# - Incorrect answers: All incorrect answers rescaled to [-1,-0.5] range (higher novelty = less punishment)
# - \\boxed invalid answers: Directly give -1 reward
# - Simplified reward strategy: Correct answers [0.5,1], incorrect answers [-1,-0.5], adjusted based on novelty

# Create reward manager example:
reward_manager = SemanticTTRLRewardManager(
    tokenizer=tokenizer,
    num_examine=2,
    use_semantic_novelty=True,
    embedding_dim=2560,
    vllm_api_url="http://30.159.163.76:2341",
    vllm_model_name="Qwen/Qwen3-Embedding-4B"
)

# Use reward manager:
rewards = reward_manager(data)
""" 
if __name__ == '__main__':
    reward_manager = SemanticTTRLRewardManager(
    tokenizer=None,
    num_examine=2,
    use_semantic_novelty=True,
    )
    data_list =  [{'ground_truth': {'accuracy_ratio': 1.0, 'format_ratio': 1.0, 'think_ratio': 1.0, 'question': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?', 'ground_truth': '72', 'verifier': 'MATH', 'image_path': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'id': 29781}, 'data_source': 'mmk12', 'solution_str': '24', 'extra_info': {'image': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'content': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?'}}, {'ground_truth': {'accuracy_ratio': 1.0, 'format_ratio': 1.0, 'think_ratio': 1.0, 'question': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?', 'ground_truth': '72', 'verifier': 'MATH', 'image_path': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'id': 29781}, 'data_source': 'mmk12', 'solution_str': '120', 'extra_info': {'image': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'content': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?'}}, {'ground_truth': {'accuracy_ratio': 1.0, 'format_ratio': 1.0, 'think_ratio': 1.0, 'question': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?', 'ground_truth': '72', 'verifier': 'MATH', 'image_path': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'id': 29781}, 'data_source': 'mmk12', 'solution_str': '**Answer:** Since there are 6 vertices, the first vertex can have 4 ways of coloring, and the other 5 vertices each have 3 ways of coloring. According to the principle of multiplication, there are $\\boxed{4 \\times 3 \\times 3 \\times 3 \\times 3 = 216}$ ways in total.', 'extra_info': {'image': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'content': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?'}}, {'ground_truth': {'accuracy_ratio': 1.0, 'format_ratio': 1.0, 'think_ratio': 1.0, 'question': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?', 'ground_truth': '72', 'verifier': 'MATH', 'image_path': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'id': 29781}, 'data_source': 'mmk12', 'solution_str': '**Analysis:** By using the exclusion method, first calculate all the color combinations based on the given conditions, then subtract the cases where the endpoints of the same edge have the same color to arrive at the answer.\n\n- Total cases: $4^4 = 256$\n- Cases where the endpoints of the same edge have the same color: $4C_4 = 6$\n- Answer: $256 - 6 = \\boxed{250}$', 'extra_info': {'image': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'content': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?'}}, {'ground_truth': {'accuracy_ratio': 1.0, 'format_ratio': 1.0, 'think_ratio': 1.0, 'question': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?', 'ground_truth': '72', 'verifier': 'MATH', 'image_path': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'id': 29781}, 'data_source': 'mmk12', 'solution_str': '64', 'extra_info': {'image': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'content': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?'}}, {'ground_truth': {'accuracy_ratio': 1.0, 'format_ratio': 1.0, 'think_ratio': 1.0, 'question': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?', 'ground_truth': '72', 'verifier': 'MATH', 'image_path': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'id': 29781}, 'data_source': 'mmk12', 'solution_str': '60', 'extra_info': {'image': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'content': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?'}}, {'ground_truth': {'accuracy_ratio': 1.0, 'format_ratio': 1.0, 'think_ratio': 1.0, 'question': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?', 'ground_truth': '72', 'verifier': 'MATH', 'image_path': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'id': 29781}, 'data_source': 'mmk12', 'solution_str': '**Analysis:** To solve this problem, it is important to first understand that if we can allocate 4 colors, there\'s nothing wrong with using all 4 colors. The key is to determine how to fix the allocation of colors to the two ends of the same edge: "the same quadrant remains the same", "alignment does not repeat", and that constraints remain unchanged. We start to allocate the 4 colors and deal with "partial allocation" and "allocation of top and lower". Calculating it by group and constraint, and varying the volume of 2 colors by 1, we eventually get a comprehensive answer.\n\n**Step-by-step Solution:**\n\n1. **First allocate a color to the midpoint of the bottom edge, with the other end arbitrarily allocated one of the 3 colors: 3 scenarios.**\n\n2. **Then allocate colors to the quadrilateral forming the upper end guide line; the bottom color must be different from the color allocated above: 3 scenarios.**\n\n3. **The 4-pointing side only uses the remaining 2 colors; it can allocate these 3 colors in an exchangeable manner: 1 scenario. As a result, we have $3 \\times 3 \\times 1 = 9$ scenarios.**\n\n4. **Allocate the top edge outlines and intersecting points to satisfy the "the same quadrant remains the same", "alignment does not repeat" condition: $3$ scenarios. Since the lower edge and upper ends themselves have allocation constraints, this step is like distributing 2 colors. Thus, we get $1$ scenario.**\n\n5. **Allocate the remaining color to the upper end guides like the upper end guide to obtain a complete frame of 5 colors. In this way, there is one color. Allocate the top color from $4$ scenarios and the bottom color from 3 scenarios. Since the top lower end already has 3 colors, the remaining one color has to be allocated in $1$ scenario.**\n\n6. **Allocate the remaining two colors completely in $1$ scenario.**\n\n7. **Allocate the top edge mountains under the upper ends: use the unallocated 6 numbers to replace the top and lower ends; we get all 6 scenarios, which we treat collectively.**\n\n8. **In this problem, all the step descriptions make it a comprehensive allocation, and the number of scenarios with allocation is $9 \\times 3 \\times 2 = 54$ scenarios.**\n\nTherefore, there are $\\boxed{54}$ different coloring methods.\n\n**Verify the answer:**\n\nChoosing counting techniques, as the step description is comprehensive. Reviewing, there are $\\boxed{54}$ different coloring methods.', 'extra_info': {'image': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'content': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?'}}, {'ground_truth': {'accuracy_ratio': 1.0, 'format_ratio': 1.0, 'think_ratio': 1.0, 'question': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?', 'ground_truth': '72', 'verifier': 'MATH', 'image_path': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'id': 29781}, 'data_source': 'mmk12', 'solution_str': '108', 'extra_info': {'image': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'content': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?'}}]

    pred_outputs = ['**Analysis**\n\nThis problem examines the principles of divided counting and permutation. The key is to apply the conclusion used.\n\n**Solution**\n\nWhen the corner of parallelogym $D$ is of one color, we have $4 \\times 3 \\times 2 \\times 1$ ways to paint this parallelogym.\n\nWhen the corner of parallelogym $D$ is of the second color, do one by one and then activate the previous color, remaining $4 \\times 3 \\times 2$ ways.\n\nTherefore, the total number of different coloring methods is $4 \\times (1 + 4 \\times 3 \\times 2 \\times 1)$, which simplifies to $36$.\n\nHence, the answer is $\\boxed{36}$.', 
        '216', 
        '60', 
        '**Analysis**:\nThis problem examines combinatorial calculations. According to the problem, assigning different colors to adjacent edges of the tetrahedron is the same as assigning different colors to the faces of a tetrahedron. When assigning colors to the faces of a tetrahedron, there are $C_4^1 C_3^1 C_2^1=24$ methods.\n\nTherefore, the answer is $\\boxed{24}$.', 
        '216', 
        '192', 
        'You can select any one of the four colors for the first vertex, resulting in $4^4$ ways. After coloring the first vertex, for instance if the color of the lower vertex is red, there are three remaining colors for the bottom vertex, and three for the middle, resulting in $3^3 \\times 4$ ways. Therefore, there are a total of $4^4 \\times 3^3 \\times 4$ coloring methods. This problem employs the "Place - Permutation" method, with its essence being the multiplication principle, requiring a flexible application of the principle. It serves as a basic problem that effectively tests the understanding of the method of permutations and the layered categorization principle, paying attention to possible answers. $\\boxed{432}$', 
        '108']
    base_rewards = [0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0]
    question_type = "MATH"

    batch_embedding = reward_manager._get_embeddings_batch_direct(pred_outputs)
    print(batch_embedding)
    novelty_rewards = reward_manager._compute_novelty_rewards(pred_outputs,base_rewards,data_list)
    print(novelty_rewards)


  