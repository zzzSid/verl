#!/usr/bin/env python
# Copyright 2024 Bytedance Ltd. and/or its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# -*- coding: utf-8 -*-
"""File-system agnostic IO APIs"""

import hashlib
import os
import shutil
import tempfile

try:
    from hdfs_io import copy, exists, makedirs  # for internal use only
except ImportError:
    from .hdfs_io import copy, exists, makedirs

__all__ = ["copy", "exists", "makedirs"]

_HDFS_PREFIX = "hdfs://"

# ── NIOFS / S3 support ───────────────────────────────────────────────────
# Mirrors the pattern in tools/tools_bj/no-entry_jsonl2parquet.py

_NIOFS_AK = "aed7ef63fcad0706"
_NIOFS_SK = "aa7100f53b0c4f4d8d2d849d7730f7ef"
_niofs_client = None


def _get_niofs_client():
    """Lazily create and cache a niofs Client (thread-safe enough for this use)."""
    global _niofs_client
    if _niofs_client is None:
        import niofs
        _niofs_client = niofs.Client(_NIOFS_AK, _NIOFS_SK, max_pool_connections=2000)
    return _niofs_client


def is_niofs_path(path: str) -> bool:
    """Check whether *path* points to a NIOFS / S3 object.

    Recognised patterns (from process_trajectory_vocab.py / no-entry_jsonl2parquet.py)::

        s3:bucket/key
        s3://bucket/key
        huailai_cos:bucket/key
        /s3:bucket/key
        /ad-cn-.../...          (leading-slash Ceph absolute paths)
    """
    if not path:
        return False
    if path.startswith(("s3:", "s3://", "huailai_cos:")):
        return True
    if path.startswith(("/s3:", "/ad")):
        return True
    if ":" in path and not path.startswith("/"):
        return True
    return False


def parse_niofs_path(path: str):
    """Parse a NIOFS / S3 path into *(bucket, key)*.

    Raises :class:`ValueError` when the path cannot be parsed.
    """
    if path.startswith("/"):
        path_without_leading = path[1:]
        bucket = path_without_leading.split("/")[0]
        key = "/".join(path_without_leading.split("/")[1:])
    elif ":" in path:
        path_part = path.split(":", 1)[1] if ":" in path else path
        bucket = path_part.split("/")[0]
        key = "/".join(path_part.split("/")[1:])
    else:
        raise ValueError(f"Cannot parse niofs path: {path}")
    return bucket, key


def _download_niofs_to_local(src: str, dst: str) -> None:
    """Download the file at NIOFS/S3 *src* and write it to local *dst*.

    Tries ``read_cache_op_py`` first (fast cache-hit path), then falls
    back to a direct ``niofs.Client.get_object`` call.
    """
    # 1) Fast path — hardware cache
    try:
        from read_cache_op_py import read_cache_op_py
        raw = read_cache_op_py([src])
        data = raw[0] if isinstance(raw, list) else raw
        with open(dst, "wb") as f:
            f.write(data)
        return
    except Exception:
        pass

    # 2) Fallback — direct S3 download via niofs
    client = _get_niofs_client()
    bucket, key = parse_niofs_path(src)
    resp = client.get_object(bucket, key, Retry=True)
    with open(dst, "wb") as f:
        f.write(resp["Body"].read())


def is_non_local(path):
    return path.startswith(_HDFS_PREFIX) or is_niofs_path(path)


def md5_encode(path: str) -> str:
    return hashlib.md5(path.encode()).hexdigest()


def get_local_temp_path(hdfs_path: str, cache_dir: str) -> str:
    """Generate a unique local cache path for an HDFS resource.
    Creates a MD5-hashed subdirectory in cache_dir to avoid name conflicts,
    then returns path combining this subdirectory with the HDFS basename.

    Args:
        hdfs_path (str): Source HDFS path to be cached
        cache_dir (str): Local directory for storing cached files

    Returns:
        str: Absolute local filesystem path in format:
            {cache_dir}/{md5(hdfs_path)}/{basename(hdfs_path)}
    """
    # make a base64 encoding of hdfs_path to avoid directory conflict
    encoded_hdfs_path = md5_encode(hdfs_path)
    temp_dir = os.path.join(cache_dir, encoded_hdfs_path)
    os.makedirs(temp_dir, exist_ok=True)
    dst = os.path.join(temp_dir, os.path.basename(hdfs_path))
    return dst


def _record_directory_structure(folder_path):
    record_file = os.path.join(folder_path, ".directory_record.txt")
    with open(record_file, "w") as f:
        for root, dirs, files in os.walk(folder_path):
            for dir_name in dirs:
                relative_dir = os.path.relpath(os.path.join(root, dir_name), folder_path)
                f.write(f"dir:{relative_dir}\n")
            for file_name in files:
                if file_name != ".directory_record.txt":
                    relative_file = os.path.relpath(os.path.join(root, file_name), folder_path)
                    f.write(f"file:{relative_file}\n")
    return record_file


def _check_directory_structure(folder_path, record_file):
    if not os.path.exists(record_file):
        return False
    existing_entries = set()
    for root, dirs, files in os.walk(folder_path):
        for dir_name in dirs:
            relative_dir = os.path.relpath(os.path.join(root, dir_name), folder_path)
            existing_entries.add(f"dir:{relative_dir}")
        for file_name in files:
            if file_name != ".directory_record.txt":
                relative_file = os.path.relpath(os.path.join(root, file_name), folder_path)
                existing_entries.add(f"file:{relative_file}")
    with open(record_file) as f:
        recorded_entries = set(f.read().splitlines())
    return existing_entries == recorded_entries


def copy_to_local(src: str, cache_dir=None, filelock=".file.lock", verbose=False, always_recopy=False) -> str:
    """Copy files/directories from a remote (HDFS / NIOFS-S3) path to local cache.

    Args:
        src (str): Source path — ``hdfs://...``, ``s3:bucket/key``, or local filesystem path
        cache_dir (str, optional): Local directory for cached files. Uses system tempdir if None
        filelock (str): Base name for file lock. Defaults to ".file.lock"
        verbose (bool): Enable copy operation logging. Defaults to False
        always_recopy (bool): Force fresh copy ignoring cache. Defaults to False

    Returns:
        str: Local filesystem path to copied resource
    """
    return copy_local_path_from_hdfs(src, cache_dir, filelock, verbose, always_recopy)


def copy_local_path_from_hdfs(src: str, cache_dir=None, filelock=".file.lock", verbose=False, always_recopy=False) -> str:
    """Download *src* to a local cache if it is a remote (HDFS / NIOFS) path.

    Local paths are returned as-is.
    """
    from filelock import FileLock

    assert src[-1] != "/", f"Make sure the last char in src is not / because it will cause error. Got {src}"

    if not is_non_local(src):
        return src

    # ── Common setup ──
    if cache_dir is None:
        cache_dir = tempfile.gettempdir()
    os.makedirs(cache_dir, exist_ok=True)
    assert os.path.exists(cache_dir)
    local_path = get_local_temp_path(src, cache_dir)
    lock_name = md5_encode(src) + ".lock"
    lock_file = os.path.join(cache_dir, lock_name)

    with FileLock(lock_file=lock_file):
        if always_recopy and os.path.exists(local_path):
            if os.path.isdir(local_path):
                shutil.rmtree(local_path, ignore_errors=True)
            else:
                os.remove(local_path)

        if not os.path.exists(local_path):
            if verbose:
                print(f"Copy from {src} to {local_path}")

            # ── HDFS path ──
            if src.startswith(_HDFS_PREFIX):
                copy(src, local_path)
                if os.path.isdir(local_path):
                    _record_directory_structure(local_path)

            # ── NIOFS / S3 path (parquet, pickle, …) ──
            elif is_niofs_path(src):
                _download_niofs_to_local(src, local_path)

            else:
                raise ValueError(f"Unsupported remote path scheme: {src}")

        elif os.path.isdir(local_path):
            # always_recopy=False, local path exists, and it is a folder: check
            # whether there is anything missing
            record_file = os.path.join(local_path, ".directory_record.txt")
            if not _check_directory_structure(local_path, record_file):
                if verbose:
                    print(f"Recopy from {src} to {local_path} due to missing files or directories.")
                shutil.rmtree(local_path, ignore_errors=True)
                copy(src, local_path)
                _record_directory_structure(local_path)

    return local_path
