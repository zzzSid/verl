# Copyright 2024 Bytedance Ltd. and/or its affiliates
# Copyright 2023-2024 SGLang Team
# Copyright 2025 ModelBest Inc. and/or its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import copy
import logging
import os
import re
from collections import defaultdict
from typing import List, Optional, Union
import json
import datasets
import numpy as np
import torch
from omegaconf import DictConfig, ListConfig
from torch.utils.data import Dataset
from transformers import PreTrainedTokenizer, ProcessorMixin
import cv2
import random
from PIL import Image
from read_cache_op_py import read_cache_op_py
import verl.utils.torch_functional as verl_F
from verl.utils.model import compute_position_id_with_mask

if int(os.getenv("ON_TXSH", "1")):  # by default, data is on txsh cluster.
    from niofs.read_cache_op_py import read_cache_op_py
    ON_TXSH = True
else:
    from read_cache_op_py import read_cache_op_py
    ON_TXSH = False

from tools.visualize.data_analyzer import DataAnalyzer
from tools.visualize.gt_visualize import GTVisualize


logger = logging.getLogger(__name__)


def find_closest_aspect_ratio(aspect_ratio, target_ratios, width, height, tile_size):
    best_ratio_diff = float('inf')
    best_ratio = (1, 1)
    area = width * height
    for ratio in target_ratios:
        target_aspect_ratio = ratio[0] / ratio[1]
        ratio_diff = abs(aspect_ratio - target_aspect_ratio)
        if ratio_diff < best_ratio_diff:
            best_ratio_diff = ratio_diff
            best_ratio = ratio
        elif ratio_diff == best_ratio_diff:
            if area > 0.5 * tile_size * tile_size * ratio[0] * ratio[1]:
                best_ratio = ratio
    # print(f'width: {width}, height: {height}, best_ratio: {best_ratio}')
    return best_ratio


def dynamic_preprocess(image, min_num=1, max_num=8, tile_size=448, use_thumbnail=False):
    """Split image into tiles matching the reference dataset.py behavior.

    Resizes the image to fit exactly N tiles then crops into tile_size × tile_size
    chunks.  When min_num == max_num the tile count is forced to that value.
    Returns a list of PIL Image tiles (NOT just a count).
    """
    orig_width, orig_height = image.size
    aspect_ratio = orig_width / orig_height

    max_num = int(min(max_num, np.ceil(orig_width / tile_size) * np.ceil(orig_height / tile_size)))

    # calculate the existing image aspect ratio
    target_ratios = set(
        (i, j) for n in range(min_num, max_num + 1) for i in range(1, n + 1) for j in range(1, n + 1)
        if i * j <= max_num and i * j >= min_num)
    target_ratios = sorted(target_ratios, key=lambda x: x[0] * x[1])

    # find the closest aspect ratio to the target
    target_aspect_ratio = find_closest_aspect_ratio(
        aspect_ratio, target_ratios, orig_width, orig_height, tile_size)

    # calculate the target width and height
    target_width = tile_size * target_aspect_ratio[0]
    target_height = tile_size * target_aspect_ratio[1]
    blocks = target_aspect_ratio[0] * target_aspect_ratio[1]

    # resize the image
    resized_img = image.resize((target_width, target_height))
    processed_images = []
    for i in range(blocks):
        box = (
            (i % (target_width // tile_size)) * tile_size,
            (i // (target_width // tile_size)) * tile_size,
            ((i % (target_width // tile_size)) + 1) * tile_size,
            ((i // (target_width // tile_size)) + 1) * tile_size,
        )
        # split the image
        split_img = resized_img.crop(box)
        processed_images.append(split_img)
    assert len(processed_images) == blocks
    if use_thumbnail and len(processed_images) != 1:
        thumbnail_img = image.resize((tile_size, tile_size))
        processed_images.append(thumbnail_img)
    return processed_images


def collate_fn(data_list: list[dict]) -> dict:


    """Collate a batch of data."""
    tensors = defaultdict(list)
    non_tensors = defaultdict(list)

    for data in data_list:
        for key, val in data.items():
            if isinstance(val, torch.Tensor):
                tensors[key].append(val)
            else:
                non_tensors[key].append(val)

    for key, val in tensors.items():
        tensors[key] = torch.stack(val, dim=0)
            

    for key, val in non_tensors.items():
        non_tensors[key] = np.array(val, dtype=object)

    return {**tensors, **non_tensors}


class RLHFDataset(Dataset):
    """
    We assume the dataset contains a column that contains prompts and other information
    """

    def __init__(
        self,
        data_files: Union[str, List[str]],
        tokenizer: PreTrainedTokenizer,
        config: DictConfig,
        processor: Optional[ProcessorMixin] = None,
    ):
        if not isinstance(data_files, (List, ListConfig)):
            data_files = [data_files]

        self.data_files = copy.deepcopy(data_files)
        self.original_data_files = copy.deepcopy(data_files)  # use for resume
        self.tokenizer = tokenizer
        self.processor = processor
        # self.preprocessor = None

        self.config = config

        self.cache_dir = os.path.expanduser(config.get("cache_dir", "~/.cache/verl/rlhf"))
        self.prompt_key = config.get("prompt_key", "prompt")
        self.image_key = config.get("image_key", "images")
        self.video_key = config.get("video_key", "videos")
        self.max_prompt_length = config.get("max_prompt_length", 1024)
        self.return_raw_chat = config.get("return_raw_chat", False)
        self.return_full_prompt = config.get("return_full_prompt", False)
        self.truncation = config.get("truncation", "error")
        self.filter_overlong_prompts = config.get("filter_overlong_prompts", True)
        
        self.num_workers = config.get("filter_overlong_prompts_workers", max(1, os.cpu_count() // 4))
        self.num_workers = min(self.num_workers, os.cpu_count())
        self.chat_template_func = config.get("chat_template_func", None)
        self.need_tools_kwargs = config.get("need_tools_kwargs", False)
        self.filter_prompts = config.get("filter_prompts", True)
        self.serialize_dataset = False
        self._download()
        self._read_files_and_tokenize()
        self.mount_point = (
            "/lustre" if os.path.exists("/lustre") else "/perception-hl/MLM_evaluator"
        )
        self.enable_visualization = config.get("enable_visualization", True)
        self.enable_data_analysis = config.get("enable_data_analysis", True)
        self.num_vis = config.get("num_vis", 400)
        # if self.enable_data_analysis:
        #     self.data_analyzer = DataAnalyzer(
        #         self,
        #         max_samples = self.num_vis,
        #         random_seed = 42,
        #     )

        # if self.enable_visualization:
        #     self.visualize = GTVisualize(
        #         self,
        #         num_vis = self.num_vis,
        #         max_total_width = 6000,
        #     )

    def _download(self, use_origin_parquet=False):
        from verl.utils.fs import copy_to_local

        data_files = self.data_files if not use_origin_parquet else self.original_data_files
        for i, parquet_file in enumerate(data_files):
            self.data_files[i] = copy_to_local(src=parquet_file, cache_dir=self.cache_dir)

    def _read_files_and_tokenize(self):
        dataframes = []
        for parquet_file in self.data_files:
            # read parquet files and cache
            dataframe = datasets.load_dataset("parquet", data_files=parquet_file)["train"]
            dataframes.append(dataframe)
        self.dataframe: datasets.Dataset = datasets.concatenate_datasets(dataframes)

        print(f"dataset len: {len(self.dataframe)}")

        # filter out too long prompts
        if self.filter_overlong_prompts:
            tokenizer = self.tokenizer
            prompt_key = self.prompt_key
            self.dataframe = self.dataframe.filter(
                lambda doc: len(tokenizer.apply_chat_template(doc[prompt_key], add_generation_prompt=True)) <= self.max_prompt_length,
                num_proc=self.num_workers,
                desc=f"Filtering prompts longer than {self.max_prompt_length} tokens",
            )

            print(f"filter dataset len: {len(self.dataframe)}")

    def resume_dataset_state(self):
        self.serialize_dataset = not hasattr(self, "original_data_files")
        # resume dataframe if not it's serialized in data.pt
        if not self.serialize_dataset:
            self._download(use_origin_parquet=True)  # download and resume from original parquet files
            self._read_files_and_tokenize()
        else:
            print(r"old dataloader ckpt file is used, please train from scratch for better ckpt performance")

    def __len__(self):
        return len(self.dataframe)
    
    def load_image(self, image_path, tar_saved=False):
        # Ceph 路径有两种格式:
        #   1. 带协议前缀: "s3:bucket/key.jpg 12345" 或 "/s3:bucket/key.jpg 12345"
        #   2. 绝对路径 + 文件大小: "/ad-cn-hlidc-multimodal/.../key.jpg 12345"
        # 两者都应通过 read_cache_op_py 读取。
        if ":" in image_path or (" " in image_path and image_path.startswith("/")):
            read_ceph_kwargs = {}
            if ON_TXSH:
                read_ceph_kwargs["mnt_point"] = self.mount_point
            if tar_saved:
                tar_path, tar_size, img_offset, img_size = image_path.split(" ")
                tar_path = f"{tar_path} {tar_size}"
                ceph_path = "/" + tar_path.split(":")[1]
                raw_bytes = read_cache_op_py([ceph_path], **read_ceph_kwargs)
                image_bytes = raw_bytes[0][int(img_offset) : int(img_offset) + int(img_size)]
            else:
                if not ON_TXSH:
                    if ":" in image_path:
                        ceph_path = "/" + image_path.split(":")[1]
                    else:
                        if not image_path.startswith("/"):
                            logger.error(
                                f"[read_cache fail] wrong path format: {image_path}"
                            )
                        ceph_path = image_path
                    if " " not in ceph_path:
                        logger.error(
                            f"[read_cache fail] missing file_size: {ceph_path}"
                        )
                else:
                    if image_path.startswith("/"):
                        ceph_path = image_path.split(" ")[0]
                    else:
                        ceph_path = "/" + image_path.split(" ")[0].split(":")[1]
                raw_bytes = read_cache_op_py([ceph_path], **read_ceph_kwargs)
                image_bytes = raw_bytes[0]

            decoded = cv2.imdecode(np.frombuffer(image_bytes, np.uint8), -1)  # BGR
            if decoded.ndim == 2:
                decoded = np.tile(decoded[..., np.newaxis], (1, 1, 3))
            image = Image.fromarray(decoded[:, :, ::-1], "RGB")
        else:
            if "/" in image_path:
                image = Image.open(image_path).convert('RGB')
            else:
                image_path = os.path.join(self.root, image_path)
                image = Image.open(image_path).convert('RGB')

        return image


    def _build_messages(self, example: dict):
        messages: list = example.pop(self.prompt_key)

        # Ensure a system message is present (model was trained with one).
        # The evaluator always adds this via the internvl2_5 conversation template.
        if not any(m.get("role") == "system" for m in messages):
            messages.insert(0, {
                "role": "system",
                "content": "你是由蔚来汽车大模型团队开发的自动驾驶多模态大模型，英文名叫NIOVL, 是一个有用无害的人工智能助手。",
            })

        if self.image_key in example or self.video_key in example:
            for message in messages:
                content = message["content"]
                content_list = []
                for segment in re.split("(<image>|<video>)", content):
                    if segment == "<image>":
                        content_list.append({"type": "image"})
                    elif segment == "<video>":
                        content_list.append({"type": "video"})
                    else:
                        content_list.append({"type": "text", "text": segment})

                message["content"] = content_list

        return messages

    def __getitem__(self, item):
        """
        Note that we also return the raw_input_ids so that it can be combined with other chat template
        """
        while True:
            try:
                row_dict: dict = self.dataframe[item]
                messages = self._build_messages(row_dict)
                model_inputs = {}

                if self.processor is not None:
                    from verl.utils.dataset.vision_utils import process_image, process_video
                    raw_prompt = self.processor.apply_chat_template(messages, add_generation_prompt=True, tokenize=False)
                    multi_modal_data = {}

                    images = None
                    if self.image_key in row_dict:
                        if row_dict.get('type', None) in ["poi", "no-entry"]:
                            images = [self.load_image(image) for image in row_dict.pop(self.image_key)]
                        elif self.image_key == "images":
                            # images表示orsta的读法
                            images = [process_image(image) for image in row_dict.pop(self.image_key)]
                        else:
                            # 传入的关键字是 image，表示图片的路径
                            if isinstance(row_dict[self.image_key], str):
                                images = [self.load_image(row_dict.pop(self.image_key))]
                            elif isinstance(row_dict[self.image_key], list):
                                images = [self.load_image(image) for image in row_dict.pop(self.image_key)]

                        multi_modal_data["image"] = images

                    videos = None
                    if self.video_key in row_dict:
                        videos = [process_video(video) for video in row_dict.pop(self.video_key)]
                        multi_modal_data["video"] = [video.numpy() for video in videos]

                    # ── Pre-tile images and expand <image> per camera ──
                    # Each <image> → num_tiles copies, keeping camera context grouped.
                    TILE_SIZE = 512
                    USE_THUMBNAIL = True
                    image_num_tiles_stored = row_dict.get('image_num_tiles', [0])
                    all_tiles = []
                    num_tiles_per_image = []
                    for img_idx, image in enumerate(images):
                        if (img_idx < len(image_num_tiles_stored)
                                and int(image_num_tiles_stored[img_idx]) > 0):
                            num_tile = int(image_num_tiles_stored[img_idx])
                        else:
                            num_tile = 1
                        tile_imgs = dynamic_preprocess(
                            image, min_num=num_tile, max_num=num_tile,
                            tile_size=TILE_SIZE, use_thumbnail=USE_THUMBNAIL,
                        )
                        all_tiles.extend(tile_imgs)
                        num_tiles_per_image.append(len(tile_imgs))

                    # Expand each <image> to num_tiles copies, keeping camera context.
                    # Use split/join instead of .replace to avoid matching within replacement.
                    parts = raw_prompt.split('<image>')
                    raw_prompt = parts[0]
                    for i in range(min(len(parts) - 1, len(num_tiles_per_image))):
                        n_tiles = num_tiles_per_image[i]
                        raw_prompt += '<image>' * n_tiles + parts[i + 1]

                    # Pass pre-tiled images: each 512×512 tile → 1 patch → 64 tokens
                    multi_modal_data["image"] = all_tiles

                    model_inputs = self.processor(
                        text=[raw_prompt],
                        images=all_tiles,
                        return_tensors="pt",
                    )

                    input_ids = model_inputs.pop("input_ids")
                    attention_mask = model_inputs.pop("attention_mask")

                    if "second_per_grid_ts" in model_inputs:
                        model_inputs.pop("second_per_grid_ts")

                    # There's a trap here, multi_modal_inputs has to be a dict, not BatchFeature
                    row_dict["multi_modal_data"] = multi_modal_data
                    row_dict["multi_modal_inputs"] = dict(model_inputs)

                    # second_per_grid_ts isn't used for training, just for mrope
                    row_dict["multi_modal_inputs"].pop("second_per_grid_ts", None)

                else:
                    raw_prompt = self.tokenizer.apply_chat_template(messages, add_generation_prompt=True, tokenize=False)
                    model_inputs = self.tokenizer(raw_prompt, return_tensors="pt", add_special_tokens=True)
                    input_ids = model_inputs.pop("input_ids")
                    attention_mask = model_inputs.pop("attention_mask")

                input_ids, attention_mask = verl_F.postprocess_data(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    max_length=self.max_prompt_length,
                    pad_token_id=self.tokenizer.pad_token_id,
                    left_pad=True,
                    truncation=self.truncation,
                )

                if self.processor is not None and "Qwen2" in self.processor.__class__.__name__:
                    from verl.models.transformers.qwen2_vl import get_rope_index

                    position_ids = [
                        get_rope_index(
                            self.processor,
                            input_ids=input_ids[0],
                            image_grid_thw=model_inputs.get("image_grid_thw"),
                            video_grid_thw=model_inputs.get("video_grid_thw"),
                            second_per_grid_ts=model_inputs.get("second_per_grid_ts"),
                            attention_mask=attention_mask[0],
                        )
                    ]  # (1, 3, seq_len)

                else:
                    position_ids = compute_position_id_with_mask(attention_mask)

                row_dict["input_ids"] = input_ids[0]
                row_dict["attention_mask"] = attention_mask[0]
                row_dict["position_ids"] = position_ids[0]

                raw_prompt_ids = self.tokenizer.encode(raw_prompt, add_special_tokens=False)
                # Keep raw prompt text so vLLM's PromptReplacement can find <image> in text.
                row_dict["raw_prompt_text"] = raw_prompt
                if len(raw_prompt_ids) > self.max_prompt_length:
                    if self.truncation == "left":
                        raw_prompt_ids = raw_prompt_ids[-self.max_prompt_length :]
                    elif self.truncation == "right":
                        raw_prompt_ids = raw_prompt_ids[: self.max_prompt_length]
                    elif self.truncation == "middle":
                        left_half = self.max_prompt_length // 2
                        right_half = self.max_prompt_length - left_half
                        raw_prompt_ids = raw_prompt_ids[:left_half] + raw_prompt_ids[-right_half:]
                    elif self.truncation == "error":
                        raise RuntimeError(f"Prompt length {len(raw_prompt_ids)} is longer than {self.max_prompt_length}.")

                row_dict["raw_prompt_ids"] = raw_prompt_ids
                # encode prompts without chat template
                if self.return_raw_chat:
                    row_dict["raw_prompt"] = messages

                # get prompts with chat template
                if self.return_full_prompt:
                    row_dict["full_prompts"] = raw_prompt  # array of strings

                # add index for each prompt
                index = row_dict.get("extra_info", {}).get("index", 0)
                tools_kwargs = row_dict.get("extra_info", {}).get("tools_kwargs", {})
                need_tools_kwargs = row_dict.get("extra_info", {}).get("need_tools_kwargs", self.need_tools_kwargs)
                if need_tools_kwargs and not tools_kwargs:
                    logger.warning("tools_kwargs is empty for index {}, data source: {}", index, row_dict["data_source"])
                row_dict["index"] = index
                row_dict["tools_kwargs"] = tools_kwargs

                # row_dict['pixel_values'] = row_dict['multi_modal_inputs'].get('pixel_values', None)
                # row_dict['pixel_values'] = row_dict['multi_modal_inputs']
                # row_dict['conversations_debug'] = [
                #     {
                #         "from": "human",
                #         "value": raw_prompt,
                #     },
                #     {
                #         "from": "gpt",
                #         "value": row_dict["reward_model"]["ground_truth"]["ground_truth"],
                #     }
                # ]
                # row_dict['dataset_name_debug'] = row_dict['data_source']

                break
            
            except Exception as e:
                print(f"[Error] Meeting Error is {e}!!!!")
                item = random.randint(1, len(self.dataframe)) - 1
        return row_dict

    def __getstate__(self):
        if not self.serialize_dataset:
            state = self.__dict__.copy()

            if "dataframe" in state:
                del state["dataframe"]
            return state

        return self.__dict__.copy()


if __name__ == "__main__":
    from hydra import initialize_config_dir, compose
    from verl.utils import hf_processor, hf_tokenizer

    config_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "trainer/config")
    config_name = "ppo_trainer"

    MODEL_PATH = "/perception-hl/kai.long/work_dirs/vla_ppu/0522_9.4Wclip_cot3_traj_vocab-20260522-182412"
    TRAIN_DATA = "/perception-hl/beijin.zhou/deeprl/v1_data/vla_train_out_no_entry_260526_train__df5f809__20260528070111_part2_part0000_severe_error.parquet"
    VAL_DATA   = "/perception-hl/beijin.zhou/deeprl/v1_data/vla_train_out_no_entry_260526_train__df5f809__20260528070111_part2_part0001_severe_error.parquet"

    print("=" * 60)
    print("Loading config & processor ...")
    print("=" * 60)

    with initialize_config_dir(config_dir=config_dir, job_name="test_job"):
        config = compose(config_name=config_name)
    data = config.data
    data.train_files = TRAIN_DATA
    data.val_files = VAL_DATA
    data.train_batch_size = 8
    data.max_prompt_length = 4096
    data.max_response_length = 1024
    data.filter_overlong_prompts = False   # skip filtering for debug
    data.truncation = 'error'
    data.image_key = 'image'

    tokenizer = hf_tokenizer(MODEL_PATH, trust_remote_code=True)
    processor = hf_processor(MODEL_PATH, use_fast=True, trust_remote_code=True)
    print(f"processor type: {type(processor).__name__}")

    dataset = RLHFDataset(
        data_files=[TRAIN_DATA],
        tokenizer=tokenizer,
        processor=processor,
        config=data,
    )
    print(f"dataset len: {len(dataset)}\n")

    # ── Inspect first 3 samples ──
    for i in range(min(3, len(dataset))):
        ret = dataset.__getitem__(i)
        input_ids = ret['input_ids']
        attn_mask = ret['attention_mask']
        pixel_values = ret['multi_modal_inputs'].get('pixel_values')
        num_tiles = ret['multi_modal_inputs'].get('num_tiles_per_image', 'N/A')

        print(f"=== sample {i} ===")
        print(f"  input_ids shape:           {input_ids.shape}")
        print(f"  input_ids len:             {input_ids.shape[0]} tokens")
        print(f"  pixel_values shape:        {pixel_values.shape if pixel_values is not None else 'None'}")
        print(f"  num_tiles_per_image:       {num_tiles}  sum={sum(num_tiles) if num_tiles != 'N/A' else 'N/A'}")
        print(f"  <image> in prompt:         {ret.get('full_prompts', '').count('<image>')}")
        if pixel_values is not None:
            print(f"  pixel_values mem (MB):     {pixel_values.element_size() * pixel_values.nelement() / 1024 / 1024:.1f}")
        print()

    print("=" * 60)
    print("Done.")