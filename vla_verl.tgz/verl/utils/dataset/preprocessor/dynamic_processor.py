from typing import List, Optional, Tuple, Union

from transformers.models.got_ocr2 import GotOcr2ImageProcessorFast
from collections import defaultdict

from transformers.image_processing_base import BatchFeature
from transformers.image_transforms import (group_images_by_shape, reorder_images)
from transformers.image_utils import SizeDict
from transformers.utils.import_utils import (
    is_torch_available,
    is_torchvision_available,
    is_torchvision_v2_available,
)
from transformers.utils.generic import TensorType
from transformers.models.got_ocr2.image_processing_got_ocr2_fast import GotOcr2ImageProcessorKwargs
if is_torch_available():
    import torch

if is_torchvision_available():
    if is_torchvision_v2_available():
        from torchvision.transforms.v2 import functional as F
    else:
        from torchvision.transforms import functional as F


class NIODynamicImageProcessorKwargs(GotOcr2ImageProcessorKwargs):
    image_num_tiles: Optional[List[int]]

   
class NIODynamicImageProcessor(GotOcr2ImageProcessorFast):
    valid_kwargs = NIODynamicImageProcessorKwargs
    
    def _preprocess(
        self,
        images: List["torch.Tensor"],
        do_resize: bool,
        size: SizeDict,
        crop_to_patches: bool,
        min_patches: int,
        max_patches: int,
        interpolation: Optional["F.InterpolationMode"],
        do_center_crop: bool,
        crop_size: SizeDict,
        do_rescale: bool,
        rescale_factor: float,
        do_normalize: bool,
        image_mean: Optional[Union[float, List[float]]],
        image_std: Optional[Union[float, List[float]]],
        return_tensors: Optional[Union[str, TensorType]],
        image_num_tiles: Optional[List[int]] = None,
    ) -> BatchFeature:
        if image_num_tiles is None:  #[NOTE] neos.yan: 如果没用动态分辨率采样，那么就默认给一个全1的tiles
            image_num_tiles = [1 for _ in range(len(images))]  

        if crop_to_patches:
            assert len(images) == len(image_num_tiles), "image_num_tiles must match number of images"
            grouped_images = defaultdict(list)
            grouped_indices = defaultdict(list)

            for idx, (img, patch_count) in enumerate(zip(images, image_num_tiles)):
                grouped_images[patch_count].append(img)
                grouped_indices[patch_count].append(idx)

            processed_images_per_group = {}
            num_patches_per_group = {}

            for patch_count, img_list in grouped_images.items():
                # batch stack: [B, C, H, W]
                batch_images = torch.stack(img_list, dim=0)
                patched = self.crop_image_to_patches(
                    batch_images,
                    min_patches=patch_count,
                    max_patches=patch_count,
                    patch_size=size,
                    interpolation=interpolation,
                )  # [B, N, C, ph, pw]
                processed_images_per_group[patch_count] = patched
                num_patches_per_group[patch_count] = [patched.shape[1]] * patched.shape[0]
            reordered_images = []
            # 构建一个索引->(patches) 映射
            indexed_images = [None] * len(images)
            indexed_num_patches = [None] * len(images)

            for patch_count, indices in grouped_indices.items():
                group_patches = processed_images_per_group[patch_count]
                group_num_patches = num_patches_per_group[patch_count]
                for i, idx in enumerate(indices):
                    # group_patches[i]: [N, C, H, W]
                    indexed_images[idx] = list(group_patches[i])  # 展平每张图的 patch
                    indexed_num_patches[idx] = group_num_patches[i]
            # 拼成最终顺序
            for patch_list in indexed_images:
                reordered_images.extend(patch_list)

            num_patches = indexed_num_patches
            images = reordered_images
        else:
            num_patches = [1] * len(images)
        # Group images by size for batched resizing
        grouped_images, grouped_images_index = group_images_by_shape(images)
        resized_images_grouped = {}
        for shape, stacked_images in grouped_images.items():
            if do_resize:
                stacked_images = self.resize(image=stacked_images, size=size, interpolation=interpolation)
            resized_images_grouped[shape] = stacked_images
        resized_images = reorder_images(resized_images_grouped, grouped_images_index)

        # Group images by size for further processing
        # Needed in case do_resize is False, or resize returns images with different sizes
        grouped_images, grouped_images_index = group_images_by_shape(resized_images)
        processed_images_grouped = {}
        for shape, stacked_images in grouped_images.items():
            if do_center_crop:
                stacked_images = self.center_crop(stacked_images, crop_size)
            # Fused rescale and normalize
            stacked_images = self.rescale_and_normalize(
                stacked_images, do_rescale, rescale_factor, do_normalize, image_mean, image_std
            )
            processed_images_grouped[shape] = stacked_images

        processed_images = reorder_images(processed_images_grouped, grouped_images_index)
        processed_images = torch.stack(processed_images, dim=0) if return_tensors else processed_images
            
        return BatchFeature(
            data={"pixel_values": processed_images, "num_patches": num_patches}, tensor_type=return_tensors
        )
