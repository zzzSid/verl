# Copyright 2024 Bytedance Ltd. and/or its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Utils for tokenization."""
import re
import warnings
from transformers import AutoConfig, AutoModelForVision2Seq

# Register NIOVLConfig for niovl model type
from verl.mlm.niovl import NIOVLConfig, NIOVLModel

AutoConfig.register("niovl", NIOVLConfig)
AutoModelForVision2Seq.register(NIOVLConfig, NIOVLModel)

# Register NIOVLModel in vLLM model registry as InternVLChatModel (multimodal)
from vllm.model_executor.models.registry import ModelRegistry
from vllm.model_executor.models.internvl import InternVLChatModel
ModelRegistry.register_model("NIOVLModel", InternVLChatModel)

__all__ = ["hf_tokenizer", "hf_processor"]


def set_pad_token_id(tokenizer):
    """Set pad_token_id to eos_token_id if it is None.

    Args:
        tokenizer (transformers.PreTrainedTokenizer): The tokenizer to be set.

    """
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token_id = tokenizer.eos_token_id
        warnings.warn(f"tokenizer.pad_token_id is None. Now set to {tokenizer.eos_token_id}", stacklevel=1)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
        warnings.warn(f"tokenizer.pad_token is None. Now set to {tokenizer.eos_token}", stacklevel=1)


def hf_tokenizer(name_or_path, correct_pad_token=True, correct_gemma2=True, **kwargs):
    """Create a huggingface pretrained tokenizer which correctness handles eos and pad tokens.

    Args:

        name (str): The name of the tokenizer.
        correct_pad_token (bool): Whether to correct the pad token id.
        correct_gemma2 (bool): Whether to correct the gemma2 tokenizer.

    Returns:

        transformers.PreTrainedTokenizer: The pretrained tokenizer.

    """
    from transformers import AutoTokenizer

    if correct_gemma2 and isinstance(name_or_path, str) and "gemma-2-2b-it" in name_or_path:
        # the EOS token in gemma2 is ambiguious, which may worsen RL performance.
        # https://huggingface.co/google/gemma-2-2b-it/commit/17a01657f5c87135bcdd0ec7abb4b2dece04408a
        warnings.warn("Found gemma-2-2b-it tokenizer. Set eos_token and eos_token_id to <end_of_turn> and 107.", stacklevel=1)
        kwargs["eos_token"] = "<end_of_turn>"
        kwargs["eos_token_id"] = 107
    trust_remote_code=kwargs.pop("trust_remote_code", True)
    tokenizer = AutoTokenizer.from_pretrained(name_or_path, **kwargs)
    config = AutoConfig.from_pretrained(name_or_path, trust_remote_code=trust_remote_code)
    if re.match("internvl|niovl", config.model_type):
        tokenizer.context_image_token = "<IMG_CONTEXT>"
        tokenizer.end_image_token="</img>"
        tokenizer.start_image_token="<img>"
        tokenizer.video_token = "<video>"
        tokenizer.context_image_token_id = tokenizer.convert_tokens_to_ids(tokenizer.context_image_token) #for transformers >= 4.52.2
        print("tokenizer.context_image_token_id:", tokenizer.context_image_token_id)
        tokenizer.chat_template="""{% for message in messages %}{{'<|im_start|>' + message['role'] + '\n'}}{% if message['content'] is string %}{{ message['content'] }}{% else %}{% for content in message['content'] %}{% if content['type'] == 'image' %}{{ '<image>' }}{% elif content['type'] == 'video' %}{{ '<video>' }}{% elif content['type'] == 'text' %}{{ content['text'] }}{% endif %}{% endfor %}{% endif %}{{'<|im_end|>'}}{% endfor %}{% if add_generation_prompt %}{{'<|im_start|>assistant\n' }}{% endif %}"""
    if correct_pad_token:
        set_pad_token_id(tokenizer)
    return tokenizer


def hf_processor(name_or_path, **kwargs):
    """Create a huggingface processor to process multimodal data.

    Args:
        name_or_path (str): The name of the processor.

    Returns:
        transformers.ProcessorMixin: The pretrained processor.
    """
    from transformers import AutoProcessor
    SIGLIP_MEAN = [0.5, 0.5, 0.5]
    SIGLIP_STD = [0.5, 0.5, 0.5]
    trust_remote_code=kwargs.get("trust_remote_code", True)
    config = AutoConfig.from_pretrained(name_or_path, trust_remote_code=trust_remote_code)
    try:
        if re.match("internvl|niovl", config.model_type, re.IGNORECASE):
            print("NIODynamicImageProcessor initilizing")
            from verl.utils.dataset.preprocessor.dynamic_processor import NIODynamicImageProcessor
            image_processor = NIODynamicImageProcessor(
                crop_to_patches=False,
                data_format="channels_first",
                default_to_square=True,
                do_center_crop=None,
                do_convert_rgb=True,
                do_normalize=True,
                do_rescale=True,
                do_resize=True,
                resample=3,
                rescale_factor=0.00392156862745098,
                size={"height":config.force_image_size, "width": config.force_image_size},
                max_patches=config.max_dynamic_patch,
                min_patches=config.min_dynamic_patch,
                return_tensors=None,
                image_mean=SIGLIP_MEAN,
                image_std=SIGLIP_STD
            )
            from verl.utils.dataset.preprocessor.internvl import InternVLProcessor
            tokenizer = hf_tokenizer(name_or_path, trust_remote_code=trust_remote_code)
            processor = InternVLProcessor(
                image_processor=image_processor,
                image_seq_length=64,
                tokenizer=tokenizer,
                chat_template=tokenizer.chat_template
            )
            print("Training the InternVL series")
        else:
            processor = AutoProcessor.from_pretrained(name_or_path, **kwargs)
    except Exception as e:
        print("Processor initial failed, get error",e)
        processor = None
    # Avoid load tokenizer, see:
    # https://github.com/huggingface/transformers/blob/v4.49.0/src/transformers/models/auto/processing_auto.py#L344
    if processor is not None and "Processor" not in processor.__class__.__name__:
        processor = None
    return processor
