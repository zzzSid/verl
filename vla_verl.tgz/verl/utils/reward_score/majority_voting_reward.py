import re
import pdb
import copy
import torch
import numpy as np
from collections import Counter
from typing import List, Dict, Callable
from transformers import BertTokenizer, BertModel
from sklearn.metrics.pairwise import cosine_similarity
from verl.utils.reward_score.utils import *
from verl.utils.reward_score.orsta import *

EPS =  1e-6


def format_reward(
        predict_lower:str=None, 
        question_type:str=None,
        question:str=None,
        solution_str:str=None):

    count = 0.0
    if question != "" and "<think>" in question:
        if predict_lower.count("<think>") == 1 and predict_lower.count("</think>") == 1 and predict_lower.count("<answer>") == 1 and predict_lower.count("</answer>") == 1:
            count = 1.0

        answer_str = ""

        if "<answer>" in predict_lower and "</answer>" in predict_lower:
            match = re.search(r'<answer>(.*?)</answer>', predict_lower, re.DOTALL)
            answer_str = match.group(1).strip() if match else predict_lower
            
        if len(answer_str) == 0 or answer_str == ' ' or answer_str == '\n':
            count = 0.0
            return count

        think_str = ""

        if "<think>" in predict_lower and "</think>" in predict_lower:
            match = re.search(r'<think>(.*?)</think>', predict_lower, re.DOTALL)
            think_str = match.group(1).strip() if match else predict_lower

        if len(think_str) == 0 or think_str == ' ' or think_str == '\n':
            count = 0.0
            return count

    box_count = 0
    if question_type == "Grounding":
        if (predict_lower.count("<ref>") != predict_lower.count("</ref>")) or (predict_lower.count("<ref>") != predict_lower.count("<box>")) or (predict_lower.count("<ref>") != predict_lower.count("</box>")) or predict_lower.count("<ref>") == 0:
            pass
        else:
            ref = re.findall(r'<ref>(.*?)</ref>', predict_lower)
            box = re.findall(r'<box>(.*?)</box>', predict_lower)
            for r, b in zip(ref, box):
                try:
                    b = list(map(int, b.split(",")))
                    if len(r) > 0 and len(b) == 4:
                        box_count += 1
                except:
                    pass
            box_count = box_count / (len(ref) + EPS)
            # box_count = grounding_format_reward(predict_lower,question)
    
    if question_type == "MCQ":
        if 0 < len(predict_lower) <= 2:
            box_count = 1 / (1 + EPS)

    if question_type in ['MATH', 'GeneralVQA']:
        if 0 < len(predict_lower) <= len(solution_str) + 20:
            box_count = 1 / (1 + EPS)

    count = (count + box_count) / 2

    return count


def majority_vote_acc_reward(rollouts: List[Dict]) -> List[float]:
    """
    多数投票奖励：空/无效答案不参与投票，直接 0 分
    """
   
    preds = [rollout.get('solution_str', '') for rollout in rollouts]
    question_type = rollouts[0]['ground_truth'].get('verifier', 'MATH')

    # ---------- 通用：标记无效 ----------
    def _valid(ans: str) -> bool:
        return bool(ans and re.search(r'[\da-zA-Z]', ans))   # 至少一个字母或数字

    # ---------- Moore Voting ----------
    def _moore_vote_reward(valid_items:List, similarity_func:Callable,threshold:float)->List[float]:
        """
        使用摩尔投票法，根据自定义的相似度函数计算奖励。

        Args:
            valid_items: 有效的预测项列表。
            similarity_func: 比较两个项相似度的函数。
            threshold: 判定为“相同”的相似度阈值。

        Returns:
            与 valid_items 对应的奖励列表 1.0 表示属于多数派 0.0 表示不是。
        """
        n_valid = len(valid_items)
        if n_valid == 0:
            return []
        if n_valid == 1:
            return [1.0]
        
        # 1. find candidates
        candidate_idx = 0
        count = 1
        for i in range(1,n_valid):
            try:
                score = similarity_func(valid_items[candidate_idx],valid_items[i])
            except Exception as e:
                print(f'_moore_vote find candidates failed: {e}')
                score = 0.0
            
            if score >= threshold:
                count += 1
            else:
                count -= 1
                if count == 0:
                    candidate_idx = i
                    count = 1
        
        # 2.verify candidates
     
        majority_members = []
        for i in range(n_valid):
            try:
                score = similarity_func(valid_items[candidate_idx],valid_items[i])
            except Exception as e:
                print(f'_moore_vote verify candidates failed: {e}')
                score = 0.0
            if score >= threshold:
                majority_members.append(i)
            
        if not majority_members:
            return [0.0] * n_valid

        reward_valid = [0.0]*n_valid
        for idx in majority_members:
            reward_valid[idx] = 1.0

        return reward_valid

    # ---------- Grounding 分支 ----------
    if question_type == "Grounding":
        boxes = []
        valid_mask = []
        for pred in preds:
            m = re.search(r'<box>(.*?)</box>', pred, re.DOTALL)
            if not m:
                boxes.append([0.0, 0.0, 0.0, 0.0])
                valid_mask.append(False)
                continue
            box_str = m.group(1).strip('[]')
            try:
                coords = [float(re.sub(r'[^\d.-]', '', x)) for x in box_str.split(',')][:4]
                coords = coords + [0.0] * max(0, 4 - len(coords))
            except Exception:
                coords = [0.0, 0.0, 0.0, 0.0]
            boxes.append(coords)
            valid_mask.append(True)

        if not any(valid_mask):
            return [0.0] * len(preds)

        valid_idx = np.where(valid_mask)[0]
        valid_boxes = [boxes[i] for i in valid_idx]

        reward_valid = _moore_vote_reward(valid_boxes,cal_iou,threshold=0.5)

        reward = [0.0] * len(preds)
        for i, rel_idx in enumerate(valid_idx):
            reward[rel_idx] = reward_valid[i]
        return reward

    # ---------- MCQ 分支 ----------
    elif question_type == "MCQ":
        preds = [p.upper() for p in preds]
        preds = [''.join([c for c in p if c.isalpha()]) for p in preds]
        preds = [''.join(sorted(p)) for p in preds]
        valid_mask = [_valid(p) for p in preds]
        if not any(valid_mask):
            return [0.0] * len(preds)

        valid_idx = np.where(valid_mask)[0]
        valid_pred = [preds[i] for i in valid_idx]
        counts = Counter(valid_pred)
        max_vote = max(counts.values())
        majority_answers = {ans for ans, c in counts.items() if c == max_vote}  
        reward_valid = [1.0 if p in majority_answers else 0.0 for p in valid_pred]

        reward = [0.0] * len(preds)
        for i, rel_idx in enumerate(valid_idx):
            reward[rel_idx] = reward_valid[i]
        return reward

    # ---------- MATH 分支 ----------
    elif question_type == "MATH":
        
        answers = [extract_answer(p) for p in preds]
        extractor = Math_Extractor()
        answers = [extractor.extract_answer(a) for a in answers]
        answers = [strip_string(a) for a in answers]
        valid_mask = [_valid(a) for a in answers]
        if not any(valid_mask):
            return [0.0] * len(preds)

        verify_func = math_metric(
            gold_extraction_target=(LatexExtractionConfig(),),
            pred_extraction_target=(ExprExtractionConfig(), LatexExtractionConfig()),
        )

        def math_similarity(a:str,b:str)->float:
            try:
                score, _ = verify_func(["\\boxed{" + a + "}"], ["\\boxed{" + b + "}"])
            except:
                score = 0.0
            return score

        valid_idx = np.where(valid_mask)[0]
        valid_ans = [answers[i] for i in valid_idx]

    
        reward_valid = _moore_vote_reward(valid_ans,math_similarity,threshold=1.0)
    
        reward = [0.0] * len(preds)
        for i, rel_idx in enumerate(valid_idx):
            reward[rel_idx] = reward_valid[i]
        return reward

    # ---------- General VQA / 默认 ----------
    else:
        valid_mask = [_valid(p) for p in preds]
        if not any(valid_mask):
            return [0.0] * len(preds)

        valid_idx = np.where(valid_mask)[0]
        valid_pred = [preds[i] for i in valid_idx]

        reward_valid = _moore_vote_reward(valid_pred,cal_similarity,threshold=0.8)

        reward = [0.0] * len(preds)
        for i, rel_idx in enumerate(valid_idx):
            reward[rel_idx] = reward_valid[i]
        return reward
        
def rule_base_acc_reward(predict_str: str, solution: dict)->float:
    question_type = solution['verifier']
    try:
        if question_type == "MATH":
            try:
                ori_str = predict_str
                predict_str = extract_answer(predict_str)
                extractor = Math_Extractor()
                predict_str = extractor.extract_answer(predict_str)
                predict_str = strip_string(predict_str)
                
                solution_str = extractor.extract_answer(solution["ground_truth"])
                solution_str = strip_string(solution_str)

                verify_func = math_metric(
                    gold_extraction_target=(LatexExtractionConfig(),),
                    pred_extraction_target=(ExprExtractionConfig(), LatexExtractionConfig()),
                )
                gt = "\\boxed{" + solution_str + "}"
                predict_str = "\\boxed{" + predict_str + "}"
                accu_reward, _ = verify_func([gt], [predict_str])
            except:
                predict_str = extract_answer(predict_str)
                solution_str = extract_answer(solution["ground_truth"])
                accu_reward = 1.0 if solution_str == predict_str else 0.0

            return accu_reward

        elif question_type == "GeneralVQA":
            predict_str = extract_answer(predict_str)
            solution_str = extract_answer(solution["ground_truth"])

            accu_reward = 1.0 if predict_str == solution_str else 0.0
            return accu_reward

        elif question_type == "MCQ":
            predict_str = extract_answer(predict_str)
            solution_str = extract_answer(solution["ground_truth"])
            p, s = "", ""
            for pd in predict_str:
                if 97 <= ord(pd) <= 122:
                    p = pd
                    break
            for sh in solution_str:
                if 97 <= ord(sh) <= 122:
                    s = sh
                    break
            if p == s and p != "":
                accu_reward = 1.0
            else:
                accu_reward = 0.0
            return accu_reward

        elif question_type == "Grounding":
            predict_str = extract_answer(predict_str)
            solution_str = extract_answer(solution["ground_truth"])
            
            accu_reward = cal_grounding(predict_str, solution_str)
            return accu_reward

        else:
            raise ValueError
            
    except:
        return 0.0


def majority_voting_reward_fn(data_list):
    data_dict = {}
    id_to_mapping = {}

    for idx,item in enumerate(data_list):
        item_id = item['ground_truth'].get('id',None)
        if item_id not in data_dict:
            data_dict[item_id] = [item]
            id_to_mapping[item_id] = [(idx,0)]
        else:
            group_inner_idx = len(data_dict[item_id])  
            data_dict[item_id].append(item)
            id_to_mapping[item_id].append((idx, group_inner_idx))

    id_to_group_rewards = {}
    for item_id,rollouts in data_dict.items():
        # List[Dict]
        group_size = len(rollouts)
        format_rewards = [0.0]*group_size # 逐个计算
        think_rewards = [0.0]*group_size # 逐个计算
        acc_rewards =  majority_vote_acc_reward(rollouts)# 成组计算
       

        accuracy_ratios = [rollout['ground_truth'].get('accuracy_ratio',0.0) for rollout in rollouts]
        format_ratios = [rollout['ground_truth'].get('format_ratio',0.0) for rollout in rollouts]
        think_ratios = [rollout['ground_truth'].get('think_ratio',0.0) for rollout in rollouts]


        # calutate rollouts reward
        for i,rollout in enumerate(rollouts):
            question = rollout['ground_truth'].get('question',None)
            question_type = rollout['ground_truth'].get('verifier',None)
            gt = rollout['ground_truth'].get('ground_truth',None)
            pred = rollout.get('solution_str',None)

            try:
                format_rewards[i] = format_reward(pred,question_type,question,gt)
            except:
                format_rewards[i] = 0.0
       
        group_rewards =[format_reward*format_ratio + think_reward*think_ratio + acc_reward*acc_ratio for format_reward,think_reward,acc_reward,format_ratio,think_ratio,acc_ratio in zip(format_rewards,think_rewards,acc_rewards,format_ratios,think_ratios,accuracy_ratios)]
        id_to_group_rewards[item_id] = group_rewards

    answer_reward = [0.0] * len(data_list)  
    for item_id, mapping_list in id_to_mapping.items():
        group_rewards = id_to_group_rewards[item_id]
        for data_list_idx, group_inner_idx in mapping_list:
            answer_reward[data_list_idx] = group_rewards[group_inner_idx]
   

    return answer_reward


def majority_vote_rule_base_reward_fn(data_list):
    """ 0.5TTRL + 0.5Rule Based """
    data_dict = {}
    id_to_mapping = {}

    for idx,item in enumerate(data_list):
        item_id = item['ground_truth'].get('id',None)
        if item_id not in data_dict:
            data_dict[item_id] = [item]
            id_to_mapping[item_id] = [(idx,0)]
        else:
            group_inner_idx = len(data_dict[item_id])  
            data_dict[item_id].append(item)
            id_to_mapping[item_id].append((idx, group_inner_idx))


    id_to_group_rewards = {}
    for item_id,rollouts in data_dict.items():
        # List[Dict]
        group_size = len(rollouts)
        format_rewards = [0.0]*group_size # 逐个计算
        think_rewards = [0.0]*group_size # 逐个计算
        acc_rewards = majority_vote_acc_reward(rollouts)# 成组计算
        
        for i,rollout in enumerate(rollouts):
            pred = rollout.get('solution_str',None)
            gt = rollout.get('ground_truth',None)
            try:
                acc_rewards[i] += rule_base_acc_reward(pred,gt) # orsta_new_reward(predict_str: str, solution: dict)
            except:
                acc_rewards[i] += 0.0
            acc_rewards[i] += rule_base_acc_reward(pred,gt)
        acc_rewards = [acc_reward/2 for acc_reward in acc_rewards]

        accuracy_ratios = [rollout['ground_truth'].get('accuracy_ratio',0.0) for rollout in rollouts]
        format_ratios = [rollout['ground_truth'].get('format_ratio',0.0) for rollout in rollouts]
        think_ratios = [rollout['ground_truth'].get('think_ratio',0.0) for rollout in rollouts]


        # calutate rollouts reward
        for i,rollout in enumerate(rollouts):
            question = rollout['ground_truth'].get('question',None)
            question_type = rollout['ground_truth'].get('verifier',None)
            gt = rollout['ground_truth'].get('ground_truth',None)
            pred = rollout.get('solution_str',None)

            try:
                format_rewards[i] = format_reward(pred,question_type,question,gt)
            except:
                format_rewards[i] = 0.0
       
        group_rewards =[format_reward*format_ratio + think_reward*think_ratio + acc_reward*acc_ratio for format_reward,think_reward,acc_reward,format_ratio,think_ratio,acc_ratio in zip(format_rewards,think_rewards,acc_rewards,format_ratios,think_ratios,accuracy_ratios)]
        id_to_group_rewards[item_id] = group_rewards

    answer_reward = [0.0] * len(data_list)  
    for item_id, mapping_list in id_to_mapping.items():
        group_rewards = id_to_group_rewards[item_id]
        for data_list_idx, group_inner_idx in mapping_list:
            answer_reward[data_list_idx] = group_rewards[group_inner_idx]

    return answer_reward




if __name__ == "__main__":
    data_list =  [{'ground_truth': {'accuracy_ratio': 1.0, 'format_ratio': 1.0, 'think_ratio': 1.0, 'question': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?', 'ground_truth': '72', 'verifier': 'MATH', 'image_path': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'id': 29781}, 'data_source': 'mmk12', 'solution_str': '24', 'extra_info': {'image': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'content': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?'}}, {'ground_truth': {'accuracy_ratio': 1.0, 'format_ratio': 1.0, 'think_ratio': 1.0, 'question': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?', 'ground_truth': '72', 'verifier': 'MATH', 'image_path': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'id': 29781}, 'data_source': 'mmk12', 'solution_str': '120', 'extra_info': {'image': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'content': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?'}}, {'ground_truth': {'accuracy_ratio': 1.0, 'format_ratio': 1.0, 'think_ratio': 1.0, 'question': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?', 'ground_truth': '72', 'verifier': 'MATH', 'image_path': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'id': 29781}, 'data_source': 'mmk12', 'solution_str': '**Answer:** Since there are 6 vertices, the first vertex can have 4 ways of coloring, and the other 5 vertices each have 3 ways of coloring. According to the principle of multiplication, there are $\\boxed{4 \\times 3 \\times 3 \\times 3 \\times 3 = 216}$ ways in total.', 'extra_info': {'image': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'content': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?'}}, {'ground_truth': {'accuracy_ratio': 1.0, 'format_ratio': 1.0, 'think_ratio': 1.0, 'question': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?', 'ground_truth': '72', 'verifier': 'MATH', 'image_path': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'id': 29781}, 'data_source': 'mmk12', 'solution_str': '**Analysis:** By using the exclusion method, first calculate all the color combinations based on the given conditions, then subtract the cases where the endpoints of the same edge have the same color to arrive at the answer.\n\n- Total cases: $4^4 = 256$\n- Cases where the endpoints of the same edge have the same color: $4C_4 = 6$\n- Answer: $256 - 6 = \\boxed{250}$', 'extra_info': {'image': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'content': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?'}}, {'ground_truth': {'accuracy_ratio': 1.0, 'format_ratio': 1.0, 'think_ratio': 1.0, 'question': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?', 'ground_truth': '72', 'verifier': 'MATH', 'image_path': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'id': 29781}, 'data_source': 'mmk12', 'solution_str': '64', 'extra_info': {'image': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'content': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?'}}, {'ground_truth': {'accuracy_ratio': 1.0, 'format_ratio': 1.0, 'think_ratio': 1.0, 'question': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?', 'ground_truth': '72', 'verifier': 'MATH', 'image_path': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'id': 29781}, 'data_source': 'mmk12', 'solution_str': '60', 'extra_info': {'image': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'content': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?'}}, {'ground_truth': {'accuracy_ratio': 1.0, 'format_ratio': 1.0, 'think_ratio': 1.0, 'question': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?', 'ground_truth': '72', 'verifier': 'MATH', 'image_path': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'id': 29781}, 'data_source': 'mmk12', 'solution_str': '**Analysis:** To solve this problem, it is important to first understand that if we can allocate 4 colors, there\'s nothing wrong with using all 4 colors. The key is to determine how to fix the allocation of colors to the two ends of the same edge: "the same quadrant remains the same", "alignment does not repeat", and that constraints remain unchanged. We start to allocate the 4 colors and deal with "partial allocation" and "allocation of top and lower". Calculating it by group and constraint, and varying the volume of 2 colors by 1, we eventually get a comprehensive answer.\n\n**Step-by-step Solution:**\n\n1. **First allocate a color to the midpoint of the bottom edge, with the other end arbitrarily allocated one of the 3 colors: 3 scenarios.**\n\n2. **Then allocate colors to the quadrilateral forming the upper end guide line; the bottom color must be different from the color allocated above: 3 scenarios.**\n\n3. **The 4-pointing side only uses the remaining 2 colors; it can allocate these 3 colors in an exchangeable manner: 1 scenario. As a result, we have $3 \\times 3 \\times 1 = 9$ scenarios.**\n\n4. **Allocate the top edge outlines and intersecting points to satisfy the "the same quadrant remains the same", "alignment does not repeat" condition: $3$ scenarios. Since the lower edge and upper ends themselves have allocation constraints, this step is like distributing 2 colors. Thus, we get $1$ scenario.**\n\n5. **Allocate the remaining color to the upper end guides like the upper end guide to obtain a complete frame of 5 colors. In this way, there is one color. Allocate the top color from $4$ scenarios and the bottom color from 3 scenarios. Since the top lower end already has 3 colors, the remaining one color has to be allocated in $1$ scenario.**\n\n6. **Allocate the remaining two colors completely in $1$ scenario.**\n\n7. **Allocate the top edge mountains under the upper ends: use the unallocated 6 numbers to replace the top and lower ends; we get all 6 scenarios, which we treat collectively.**\n\n8. **In this problem, all the step descriptions make it a comprehensive allocation, and the number of scenarios with allocation is $9 \\times 3 \\times 2 = 54$ scenarios.**\n\nTherefore, there are $\\boxed{54}$ different coloring methods.\n\n**Verify the answer:**\n\nChoosing counting techniques, as the step description is comprehensive. Reviewing, there are $\\boxed{54}$ different coloring methods.', 'extra_info': {'image': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'content': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?'}}, {'ground_truth': {'accuracy_ratio': 1.0, 'format_ratio': 1.0, 'think_ratio': 1.0, 'question': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?', 'ground_truth': '72', 'verifier': 'MATH', 'image_path': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'id': 29781}, 'data_source': 'mmk12', 'solution_str': '108', 'extra_info': {'image': '/lustre/MLM_evaluator/data/open_data/orsta/images/MMK12_24437.jpg', 'content': '<image>As shown in the figure, each vertex of a quadrilateral pyramid is to be colored with one color, and the two endpoints of the same edge must be of different colors. If only 4 colors are available, how many different coloring methods are there?'}}]

    # print(majority_vote_rule_base_reward_fn(data_list))
    
    # print(majority_voting_reward_fn(data_list,None,None))
    print(majority_vote_acc_reward(data_list))
