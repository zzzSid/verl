from collections import Counter
import re
import copy
import json
# from xtuner.utils import RewardModelClient
from . import orsta


def normalize_to_01(float_list):
    """
    将float列表归一化到[0,1]范围
    :param float_list: 输入的float类型列表
    :return: 归一化后的列表（元素范围[0,1]）
    """
    # 处理空列表
    if not float_list:
        raise ValueError("输入列表不能为空")
    
    # 计算最小值和最大值
    min_val = min(float_list)
    max_val = max(float_list)
    diff = max_val - min_val
    
    # 处理所有元素相同的情况（避免除以0）
    if diff == 0:
        return [0.0 for _ in float_list]  # 或全1.0，根据需求选择
    
    # 归一化：(x - min) / (max - min)
    normalized = [(x - min_val) / diff for x in float_list]
    return normalized


def extract_answer(solution_str):
    solution_str = solution_str.lower().replace("'", '"')
    if "<answer>" in solution_str:
        match = re.search(r'<answer>(.*?)</answer>', solution_str, re.DOTALL)
        solution_str = match.group(1).strip() if match else solution_str

    return solution_str


def extract_think(solution_str):
    solution_str = solution_str.lower().replace("'", '"')
    if "<think>" in solution_str:
        match = re.search(r'<think>(.*?)</think>', solution_str, re.DOTALL)
        solution_str = match.group(1).strip() if match else solution_str
        return solution_str
    else:
        return ""


def get_rule_rewards(data_list):
    tmp_reward = []
    for idx, data_item in enumerate(data_list):
        predict_str = data_item['solution_str']
        solution = data_item['ground_truth']
        reward = orsta.orsta_new_reward(predict_str, solution)
        tmp_reward.append(reward)
    return tmp_reward


def get_format_rewards(data_list):
    tmp_reward = []
    for idx, data_item in enumerate(data_list):
        predict_str = data_item['solution_str']
        solution = data_item['ground_truth']
        reward = orsta.orsta_format_reward(
            predict_str,
            solution['verifier'],
            solution.get("question", ""), 
            solution['ground_truth']
        )
        tmp_reward.append(reward)
    return tmp_reward


def client_reward_fn(data_list, answer_reward_client=None, think_reward_client=None):

    data_dict = {}
    data_idx2no = {}
    for idx, data_item in enumerate(data_list):
        if data_dict.get(data_item['ground_truth']['id'], None) is None:
            data_dict[data_item['ground_truth']['id']] = [data_item]
        else:
            data_dict[data_item['ground_truth']['id']].append(data_item)
        t_len = len(data_dict[data_item['ground_truth']['id']])
        data_idx2no[f"{data_item['ground_truth']['id']}_{t_len}"] = idx

    answer_reward = [0 for _ in range(len(data_list))]

    for key, value in data_dict.items():

        # every rollout
        n_response = len(value)
        answers = [extract_answer(data_item['solution_str']) for data_item in value]
        thinks = [extract_think(data_item['solution_str']) for data_item in value]

        questions = [data_item['ground_truth']['question'] for data_item in value]
        responses = [data_item['ground_truth']['ground_truth'] for data_item in value]

        image_paths = [data_item['ground_truth'].get("image_path", "") for data_item in value]
        question_types = [data_item['ground_truth']['verifier'] for data_item in value]

        answer_data = []
        think_data = []
        response_length = 0
        for idx in range(n_response):
            question = questions[idx]
            answer = answers[idx]
            response = responses[idx]
            think = thinks[idx]
            image_path = image_paths[idx]

            response_length += len(response)

            data = {
                "prompt": [{"role": "user", "content": question}],
                "reference": [{"role": "assistant", "content": response}],
                "output": [{"role": "assistant", "content": answer}]
            }
            answer_data.append(data)

            t_data = {
                "image": image_path,
                "question": question,
                "response_list_str": json.dumps([think])
            }
            think_data.append(t_data)

        # TODO[neos.yan]: add think reward in it.

        if question_types[0] != 'Grounding':
            # long - text VQA
            if answer_reward_client is not None:
                try:
                    tmp_reward = answer_reward_client(answer_data)
                    tmp_reward = normalize_to_01(tmp_reward)

                    tmp_format_reward = get_format_rewards(value)
                    tmp_reward = [a + b for a, b in zip(tmp_reward, tmp_format_reward)]
                except:
                    tmp_reward = get_rule_rewards(value)

        else:
            # short - rule reward
            tmp_reward = get_rule_rewards(value)
        
        for idx, reward in enumerate(tmp_reward):
            t_idx = data_idx2no[f"{key}_{idx + 1}"]
            answer_reward[t_idx] = reward

    return answer_reward

if __name__ == "__main__":

    answer_reward_client = RewardModelClient(
        "internlm/POLAR-7B",
        server_type="vllm",
        server_address="172.24.146.124:30000"
    )
    data_list = [
        {
            "ground_truth": {
                "ground_truth": "B. 2",
                "question": "1+1 = ? \nA. 1\nB. 2\nC. 3",
                "image_path": "",
                "verifier": "GeneralVQA",
                "id": 1
            },
            "solution_str": "C"
        },{
            "ground_truth": {
                "ground_truth": "B. 2",
                "question": "1+1 = ? \nA. 1\nB. 2\nC. 3",
                "image_path": "",
                "verifier": "GeneralVQA",
                "id": 2
            },
            "solution_str": "2"
        },{
            "ground_truth": {
                "ground_truth": "B. 2",
                "question": "1+1 = ? \nA. 1\nB. 2\nC. 3",
                "image_path": "",
                "verifier": "GeneralVQA",
                "id": 1
            },
            "solution_str": "B"
        },
        {
            "ground_truth": {
                "ground_truth": "B. 2",
                "question": "1+1 = ? \nA. 1\nB. 2\nC. 3",
                "image_path": "",
                "verifier": "GeneralVQA",
                "id": 1
            },
            "solution_str": "B. 2"
        },
        {
            "ground_truth": {
                "ground_truth": "B. 2",
                "question": "1+1 = ? \nA. 1\nB. 2\nC. 3",
                "image_path": "",
                "verifier": "GeneralVQA",
                "id": 1
            },
            "solution_str": "B. 2"
        }
    ]
    print(client_reward_fn(data_list, answer_reward_client))