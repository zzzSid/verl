import re

class AgentTaskScheduleReward:
    
    def __init__(self) -> None:
        pass
    
    def calc_score_no_cot(self, pred:str, gt:str):
        """
        """
        # s1: 预处理
        post_pred = pred.replace(' ', '')
        all_ans = pred.split("\n")
        pred_category = all_ans[0].strip().upper()
        pred_tsr_info = all_ans[1] if len(all_ans) > 1 else None
        pred_tsr_sensor_no = pred_tsr_info.split('<box>')[0] if pred_tsr_info else None
        pred_tsr_sensor_bbox = re.search(r'<box>(.*?)</box>', pred_tsr_info).split(',') if pred_tsr_info else None
        pred_ent_info = all_ans[2] if len(all_ans) > 2 else None
        pred_ent_sensor_no = pred_ent_info.split('<box>')[0] if pred_ent_info else None
        pred_ent_sensor_bbox = re.search(r'<box>(.*?)</box>', pred_ent_info).split(',') if pred_ent_info else None
        
        all_gt = gt.split("\n")
        gt_category = all_gt[0].strip().upper()
        gt_tsr_info = all_gt[1] if len(all_gt) > 1 else None
        gt_tsr_sensor_no = gt_tsr_info.split('<box>')[0] if gt_tsr_info else None
        gt_tsr_sensor_bbox = re.search(r'<box>(.*?)</box>', gt_tsr_info).split(',') if gt_tsr_info else None
        gt_ent_info = all_gt[2] if len(all_gt) > 2 else None
        gt_ent_sensor_no = gt_ent_info.split('<box>')[0] if gt_ent_info else None
        gt_ent_sensor_bbox = re.search(r'<box>(.*?)</box>', gt_ent_info).split(',') if gt_ent_info else None
        
        # s1: 计算分数
        score = 0
        return score
    
    def calc_score_with_cot(self, pred:str, gt:str):
        score = 0
        return score
    
    def __call__(self, pred, gt):
        return self.calc_score_no_cot(pred, gt)