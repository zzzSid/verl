"""
VLA No-Entry Reward v4.3 — v4 + exit reward for ds_type="exit".

基于 vla_no_entry_v4.py，增加 ds_type="exit" 的支持。

For ds_type="no_entry" (or missing ds_type): same as v4.
  - intersection-distance-weighted forbidden penalty (v3)
  - exit-direction bonus when near intersection with exit sign (v4)

For ds_type="exit":
  - Skip forbidden-road penalty and exit-direction bonus.
  - Build road geometries from vla_road_construction_info.
  - Detect intersection distance (same detect_intersection_distance as no_entry).
  - Check wall crash (same as no_entry).
  - Bind predicted trajectory segments to roads.
  - If any bound road ID is in exit_path_road_ids:
      intersection dist < 6m  → +4.0
      intersection dist < 12m → +3.0
      intersection dist >= 12m → +2.0
  - Otherwise → 0.0.

Unified diff_score (3 dims for both ds_type):
    diff_score = [traj_valid, road_binding, wall]

Scoring rules (≤ 0, higher is better):
    ─────────────────────────────────────────────────────────────────────
    no_entry (same as v4 — intersection-distance + exit-direction bonus):
      无禁行路 + 沿出口                                  +2.0
      无禁行路 + 不沿出口                                 0.0
      无法解析轨迹                                        -4.0
      轨迹过短 + 沿出口                                  -1.0
      轨迹过短 + 不沿出口                                -3.0
      正确 + 沿出口                                      +2.0
      正确 + 不沿出口                                     0.0
      进入禁行路 (dist < 6m,  沿出口)                    -2.0
      进入禁行路 (dist < 6m,  不沿出口)                  -4.0
      进入禁行路 (dist < 12m, 沿出口)                    -1.0
      进入禁行路 (dist < 12m, 不沿出口)                  -3.0
      进入禁行路 (dist >= 12m)                           -2.0
      撞墙 + 沿出口                                      -(N-2)
      撞墙 + 不沿出口                                    -N×1.0
    exit:
      正确匹配出口路径路网 (dist < 6m)                 +4.0  (road_binding)
      正确匹配出口路径路网 (dist < 12m)                +3.0  (road_binding)
      正确匹配出口路径路网 (dist >= 12m)               +2.0  (road_binding)
      撞墙                                          -N * WALL_PENALTY
      无法解析轨迹                                   -4.0
      轨迹过短                                      -3.0
    ─────────────────────────────────────────────────────────────────────
"""

import json
import logging
import os
import re
from typing import Optional

import numpy as np

logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════════════
#  Reuse shared helpers from v4
# ═══════════════════════════════════════════════════════════════════════════════

from verl.utils.reward_score.vla_no_entry_v4 import (
    # Trajectory parsing
    parse_action_traj,
    action_traj_to_abs,
    COORD_NORM_MIN, COORD_NORM_MAX, COORD_PHYS_MIN, COORD_PHYS_MAX,
    # Road data
    FORBIDDEN_ROAD_CLASSES,
    get_forbidden_road_ids,
    get_all_road_geometries,
    get_road_id_to_cls,
    # Geometry / binding
    _min_distance_point_to_polyline,
    compute_segment_binding_score,
    bind_segment_to_road,
    # Intersection (v3)
    find_nearest_road_to_point,
    detect_intersection_distance,
    get_intersection_penalty,
    INTERSECTION_NEAR_6M, INTERSECTION_NEAR_12M,
    INTERSECTION_ENDPOINT_DIST_THRESHOLD, INTERSECTION_MIN_CONNECTED_ROADS,
    # Wall crash
    get_unsafe_masks,
    check_traj_crash_into_wall,
    # Constants
    BINDING_W_DIST, BINDING_W_ANGLE, BINDING_MAX_DIST, BINDING_MIN_POINTS,
    WALL_PENALTY,
    FORBIDDEN_PENALTY_NEAR, FORBIDDEN_PENALTY_MEDIUM, FORBIDDEN_PENALTY_FAR,
    # Core violation check
    check_traj_violation_by_binding,
    # v4: Exit direction bonus
    find_best_lane_for_goal,
    check_trajectory_follows_exit_direction,
    EXIT_DIRECTION_BONUS,
)


# ═══════════════════════════════════════════════════════════════════════════════
#  Exit reward constants (distance-based, analogous to forbidden penalty tiers)
# ═══════════════════════════════════════════════════════════════════════════════

EXIT_REWARD_NEAR   = 4.0   # dist < 6m
EXIT_REWARD_MEDIUM = 3.0   # dist < 12m
EXIT_REWARD_FAR    = 2.0   # dist >= 12m


# ═══════════════════════════════════════════════════════════════════════════════
#  vla_road_construction_info → all_road_geoms
# ═══════════════════════════════════════════════════════════════════════════════

def build_road_geoms_from_vla_construction(vla_road_construction_info: dict):
    """Convert ``vla_road_construction_info`` to the standard ``all_road_geoms`` dict.

    Returns dict: ``{road_id: np.array([[x,y], ...]), ...}``.
    """
    all_road_geoms = {}
    vla_road_info = vla_road_construction_info.get("vla_road_info", [])
    if isinstance(vla_road_info, list):
        for road in vla_road_info:
            road_id = road.get("road_link_id", "")
            way_points = road.get("road_way_point", [])
            if len(way_points) > 1:
                geo = np.array([[wp["point_x"], wp["point_y"]] for wp in way_points], dtype=float)
                all_road_geoms[road_id] = geo
    return all_road_geoms


def get_exit_reward(intersection_distance: Optional[float]) -> float:
    """Return exit reward based on intersection distance (same tiers as forbidden penalty)."""
    if intersection_distance is None:
        return EXIT_REWARD_FAR
    if intersection_distance < INTERSECTION_NEAR_6M:
        return EXIT_REWARD_NEAR
    elif intersection_distance < INTERSECTION_NEAR_12M:
        return EXIT_REWARD_MEDIUM
    return EXIT_REWARD_FAR


def check_exit_path_match(abs_traj, all_road_geoms, exit_path_road_ids: set,
                          min_points=BINDING_MIN_POINTS):
    """Check whether the predicted trajectory binds to any road in exit_path_road_ids.

    Returns (is_match: bool, details: dict).
    """
    if abs_traj is None or len(abs_traj) < min_points:
        return False, {
            "reason": "trajectory_too_short",
            "num_points": len(abs_traj) if abs_traj is not None else 0,
        }

    if not all_road_geoms:
        return False, {"reason": "no_road_geometries"}

    if not exit_path_road_ids:
        return False, {"reason": "no_exit_path_road_ids"}

    origin = np.array([[0.0, 0.0]])
    full_traj = np.vstack([origin, abs_traj[:min_points]])

    matched_road_ids = []
    for i in range(len(full_traj) - 2):
        segment = full_traj[i:i + 3]
        road_id, info = bind_segment_to_road(segment, all_road_geoms)
        if road_id is not None and road_id in exit_path_road_ids:
            matched_road_ids.append({
                "segment_idx": i,
                "road_id": road_id,
                "binding_info": info,
            })

    if matched_road_ids:
        return True, {
            "reason": "exit_path_matched",
            "matched_road_ids": matched_road_ids,
        }

    return False, {"reason": "no_exit_path_match"}


# ═══════════════════════════════════════════════════════════════════════════════
#  Reward interface
# ═══════════════════════════════════════════════════════════════════════════════

class TaskVLANoEntryRewardV43:
    """VLA no-entry / exit reward v4.3.

    - ds_type="no_entry" (or missing): same as v4
      (intersection-weighted penalty + exit-direction bonus)
    - ds_type="exit": exit-path road-network matching reward
    """

    def __init__(self, debug=False, debug_dir="/tmp/vla_reward_test"):
        self._last_details = {}
        self._debug = debug
        self._step = 0
        self._debug_first_n = 200
        self._debug_log_every = 20
        self._debug_dir = debug_dir or os.environ.get('VLA_DEBUG_DIR') or '/tmp/vla_reward_debug'

    def __call__(self, data_source, solution_str, ground_truth, extra_info):
        self._step += 1
        return self.compute_score(data_source, solution_str, ground_truth, extra_info)

    def _dbg(self, msg):
        if self._debug:
            with open("/tmp/vla_reward_debug.log", "a") as f:
                f.write(msg + "\n")

    @staticmethod
    def _extract_kwargs(extra_info):
        tools_kwargs = extra_info.get('tools_kwargs', {})
        reward_cfg = tools_kwargs.get('calc_no-entry_reward', {})
        return reward_cfg.get('calc_reward_kwargs', {})

    def compute_score(self, data_source, solution_str, ground_truth, extra_info):
        kwargs = self._extract_kwargs(extra_info)
        clip_id = extra_info.get('clip_id', '?')
        ds_type = extra_info.get('ds_type', 'no_entry')
        vocab_path = kwargs.get('vocab_path', None)

        # ── Parse trajectory ──
        action_traj = parse_action_traj(solution_str, vocab_path=vocab_path)
        abs_traj = action_traj_to_abs(action_traj) if action_traj is not None else None

        # ── Common fields ──
        freespace_info = json.loads(kwargs.get('freespace_info', '{}'))
        vla_goal_point = json.loads(kwargs.get('vla_goal_point', '{}'))
        has_exit_sign  = json.loads(kwargs.get('has_exit_sign', 'false'))

        if ds_type == 'exit':
            result = self._compute_exit_score(
                kwargs, action_traj, abs_traj, freespace_info,
                clip_id, data_source, solution_str,
                vla_goal_point, has_exit_sign,
            )
        else:
            result = self._compute_no_entry_score(
                kwargs, action_traj, abs_traj, freespace_info,
                clip_id, data_source, solution_str,
                vla_goal_point, has_exit_sign,
            )

        result['debug'] = {
            'clip_id': clip_id,
            'data_source': data_source,
            'ds_type': ds_type,
            'score': result['score'],
            'reason': result['reason'],
            'diff_score': result.get('diff_score', []),
            'has_exit_sign': has_exit_sign,
        }
        return result

    # ── Exit reward ──────────────────────────────────────────────────────────

    def _compute_exit_score(self, kwargs, action_traj, abs_traj, freespace_info,
                            clip_id, data_source, solution_str,
                            vla_goal_point, has_exit_sign):
        vla_road_construction_info = json.loads(
            kwargs.get('vla_road_construction_info', '{}') or '{}')
        exit_path_road_ids = set(json.loads(
            kwargs.get('exit_path_road_ids', '[]') or '[]'))

        all_road_geoms = build_road_geoms_from_vla_construction(vla_road_construction_info)
        unsafe_masks = get_unsafe_masks(freespace_info)

        # ── Distance-based exit reward (same intersection detection as no_entry) ──
        intersection_info = detect_intersection_distance(all_road_geoms)
        intersection_distance = intersection_info.get("distance")
        exit_reward_value = get_exit_reward(intersection_distance)

        _base_result = {
            "score": 0.0, "reason": "", "details": {},
            "num_points": 0, "required": BINDING_MIN_POINTS,
        }

        if action_traj is None:
            result = dict(_base_result, score=-4.0, reason="no_trajectory_parsed",
                          details={"reason": "no_trajectory_parsed"})
            self._last_details = {'reason': 'no_trajectory_parsed'}
        else:
            num_points = len(abs_traj) if abs_traj is not None else 0
            if num_points < BINDING_MIN_POINTS:
                result = dict(_base_result, score=round(-3.0, 4),
                              reason="trajectory_too_short",
                              num_points=num_points,
                              required=BINDING_MIN_POINTS,
                              details={"reason": "trajectory_too_short",
                                       "num_points": num_points})
                self._last_details = {'reason': 'trajectory_too_short',
                                      'num_points': num_points}
            elif unsafe_masks:
                # Wall crash check takes priority over exit match.
                is_crash, crash_details = check_traj_crash_into_wall(
                    abs_traj, unsafe_masks, min_points=BINDING_MIN_POINTS)
                if is_crash:
                    penalty = min(crash_details.get('num_unsafe', 1),
                                  BINDING_MIN_POINTS) * WALL_PENALTY
                    result = dict(_base_result, score=round(-penalty, 4),
                                  reason="crash_into_wall", details=crash_details)
                    self._last_details = crash_details
                elif not all_road_geoms:
                    result = dict(_base_result, reason="no_road_geometries",
                                  details={"reason": "no_road_geometries"})
                    self._last_details = {'reason': 'no_road_geometries'}
                else:
                    is_match, details = check_exit_path_match(
                        abs_traj, all_road_geoms, exit_path_road_ids)
                    if is_match:
                        details['intersection_distance'] = intersection_distance
                        details['exit_reward_value'] = exit_reward_value
                        result = dict(_base_result, score=exit_reward_value,
                                      reason="exit_path_matched", details=details)
                        self._last_details = details
                    else:
                        result = dict(_base_result, score=0.0,
                                      reason=details.get('reason', 'no_exit_path_match'),
                                      details=details)
                        self._last_details = details
            elif not all_road_geoms:
                result = dict(_base_result, reason="no_road_geometries",
                              details={"reason": "no_road_geometries"})
                self._last_details = {'reason': 'no_road_geometries'}
            else:
                is_match, details = check_exit_path_match(
                    abs_traj, all_road_geoms, exit_path_road_ids)
                if is_match:
                    details['intersection_distance'] = intersection_distance
                    details['exit_reward_value'] = exit_reward_value
                    result = dict(_base_result, score=exit_reward_value,
                                  reason="exit_path_matched", details=details)
                    self._last_details = details
                else:
                    result = dict(_base_result, score=0.0,
                                  reason=details.get('reason', 'no_exit_path_match'),
                                  details=details)
                    self._last_details = details

        # ── Build GDPO diff_score ──
        diff_list, dim_dict = self._build_exit_diff_score(result, exit_reward_value)
        result['diff_score'] = diff_list
        result.update(dim_dict)

        # ── Debug ──
        if self._debug:
            self._log_exit_debug(clip_id, data_source, solution_str,
                                 action_traj, abs_traj, result,
                                 exit_path_road_ids, vla_road_construction_info,
                                 vla_goal_point, has_exit_sign,
                                 intersection_distance, exit_reward_value,
                                 intersection_info)

        return result

    # ── No-entry reward (v4-compatible — includes exit-direction bonus) ───────

    def _compute_no_entry_score(self, kwargs, action_traj, abs_traj, freespace_info,
                                clip_id, data_source, solution_str,
                                vla_goal_point, has_exit_sign):
        road_graphs     = json.loads(kwargs.get('road_graphs', '{}'))
        select_road_ids = json.loads(kwargs.get('select_road_ids', '[]'))
        select_road_cls = json.loads(kwargs.get('select_road_cls', '[]'))

        forbidden_ids = get_forbidden_road_ids(select_road_ids, select_road_cls)
        all_road_geoms = get_all_road_geometries(road_graphs)
        road_id_to_cls = get_road_id_to_cls(select_road_ids, select_road_cls)
        unsafe_masks = get_unsafe_masks(freespace_info)

        intersection_info = detect_intersection_distance(all_road_geoms)
        intersection_distance = intersection_info.get("distance")
        forbidden_penalty = get_intersection_penalty(intersection_distance)

        # ── v4: Exit direction check ──
        exit_bonus = 0.0
        follows_exit = False
        exit_details = {}

        if abs_traj is not None and len(abs_traj) >= 2:
            follows_exit, exit_bonus, exit_details = check_trajectory_follows_exit_direction(
                abs_traj, all_road_geoms, vla_goal_point, has_exit_sign,
                intersection_distance,
            )

        _base_result = {
            "score": 0.0, "reason": "", "details": {},
            "num_points": 0, "required": BINDING_MIN_POINTS,
        }

        if action_traj is None:
            result = dict(_base_result, score=-4.0 + exit_bonus,
                          reason="no_trajectory_parsed",
                          details={"reason": "no_trajectory_parsed",
                                   "exit_bonus": exit_bonus,
                                   "exit_details": exit_details})
            self._last_details = {'reason': 'no_trajectory_parsed'}
        elif not all_road_geoms and not unsafe_masks:
            result = dict(_base_result, score=exit_bonus,
                          reason="no_road_geometries",
                          details={"reason": "no_road_geometries",
                                   "exit_bonus": exit_bonus,
                                   "exit_details": exit_details})
            self._last_details = {'reason': 'no_road_geometries'}
        else:
            num_points = len(abs_traj) if abs_traj is not None else 0
            if num_points < BINDING_MIN_POINTS:
                result = dict(_base_result, score=round(-3.0 + exit_bonus, 4),
                              reason="trajectory_too_short",
                              num_points=num_points,
                              required=BINDING_MIN_POINTS,
                              details={"reason": "trajectory_too_short",
                                       "num_points": num_points,
                                       "exit_bonus": exit_bonus,
                                       "exit_details": exit_details})
                self._last_details = {'reason': 'trajectory_too_short',
                                      'num_points': num_points}
            elif not forbidden_ids:
                if unsafe_masks:
                    is_crash, crash_details = check_traj_crash_into_wall(
                        abs_traj, unsafe_masks, min_points=BINDING_MIN_POINTS)
                    if is_crash:
                        penalty = min(crash_details.get('num_unsafe', 1),
                                      BINDING_MIN_POINTS) * WALL_PENALTY
                        result = dict(_base_result, score=round(-penalty + exit_bonus, 4),
                                      reason="crash_into_wall",
                                      details={**crash_details, "exit_bonus": exit_bonus,
                                               "exit_details": exit_details})
                        self._last_details = crash_details
                    else:
                        result = dict(_base_result, score=round(exit_bonus, 4),
                                      reason="no_forbidden_roads",
                                      details={"reason": "no_forbidden_roads",
                                               "exit_bonus": exit_bonus,
                                               "exit_details": exit_details})
                        self._last_details = {'reason': 'no_forbidden_roads'}
                else:
                    result = dict(_base_result, score=round(exit_bonus, 4),
                                  reason="no_forbidden_roads",
                                  details={"reason": "no_forbidden_roads",
                                           "exit_bonus": exit_bonus,
                                           "exit_details": exit_details})
                    self._last_details = {'reason': 'no_forbidden_roads'}
            else:
                is_violation, details = check_traj_violation_by_binding(
                    abs_traj, all_road_geoms, road_id_to_cls, forbidden_ids,
                    unsafe_masks=unsafe_masks,
                )

                if not is_violation:
                    result = dict(_base_result, score=round(exit_bonus, 4),
                                  reason="correct",
                                  details={**details, "exit_bonus": exit_bonus,
                                           "exit_details": exit_details})
                    self._last_details = {'reason': 'correct'}
                else:
                    reason = details.get('reason', 'unknown')
                    score = 0.0
                    if reason == 'segment_binds_to_forbidden_road':
                        score -= forbidden_penalty
                        details['intersection_distance'] = intersection_distance
                        details['forbidden_penalty'] = forbidden_penalty
                    elif reason == 'crash_into_wall':
                        score -= min(details.get('num_unsafe', 1),
                                     BINDING_MIN_POINTS) * WALL_PENALTY

                    # ── v4: Add exit bonus ──
                    score += exit_bonus
                    details['exit_bonus'] = exit_bonus
                    details['exit_details'] = exit_details

                    result = dict(_base_result, score=round(score, 4),
                                  reason=reason, details=details)
                    self._last_details = details

        # ── Build GDPO diff_score ──
        diff_list, dim_dict = self._build_no_entry_diff_score(
            result, forbidden_penalty, exit_bonus)
        result['diff_score'] = diff_list
        result.update(dim_dict)

        # ── Debug ──
        if self._debug:
            self._log_no_entry_debug(
                clip_id, data_source, solution_str,
                action_traj, abs_traj, result,
                forbidden_ids, road_graphs,
                select_road_ids, select_road_cls,
                freespace_info, vocab_path=None,
                intersection_distance=intersection_distance,
                forbidden_penalty=forbidden_penalty,
                intersection_info=intersection_info,
                vla_goal_point=vla_goal_point,
                has_exit_sign=has_exit_sign,
                exit_bonus=exit_bonus,
                follows_exit=follows_exit,
                exit_details=exit_details,
            )

        return result

    # ── diff_score builders ──────────────────────────────────────────────────

    @staticmethod
    def _build_no_entry_diff_score(result, forbidden_penalty=FORBIDDEN_PENALTY_FAR,
                                   exit_bonus=0.0):
        """Build diff_score for no_entry reward (v4 logic).

        Unified 3-dim format (same as exit):
            diff_score = [traj_valid, road_binding, wall]

        road_binding: -forbidden_penalty + exit_bonus  (v3+v4 combined)
        wall:         wall-crash penalty (≤ 0)
        """
        reason = result.get('reason', 'unknown')
        details = result.get('details', {})
        score = result.get('score', 0.0)

        if reason == 'no_trajectory_parsed':
            traj_valid = -4.0
        elif reason == 'trajectory_too_short':
            traj_valid = -3.0
        else:
            traj_valid = 0.0

        # Forbidden road dim: fixed penalty + exit bonus (v3+v4 combined)
        if reason == 'segment_binds_to_forbidden_road':
            road_binding = -forbidden_penalty + exit_bonus
        elif reason in ('no_forbidden_roads', 'correct', 'no_trajectory_parsed',
                         'trajectory_too_short', 'no_road_geometries', 'no_violation'):
            road_binding = exit_bonus
        else:
            road_binding = exit_bonus

        if reason == 'crash_into_wall':
            n = details.get('num_unsafe', 0)
            wall = -min(n, BINDING_MIN_POINTS) * WALL_PENALTY
        elif reason in ('no_trajectory_parsed', 'trajectory_too_short', 'no_road_geometries'):
            wall = 0.0
        else:
            wall = 0.0

        diff_list = [traj_valid, road_binding, wall]
        dim_dict = {'diff_traj_valid': traj_valid, 'diff_road_binding': road_binding,
                    'diff_wall': wall}

        if abs(sum(diff_list) - score) > 0.01:
            logger.warning(
                f"diff_score sum ({sum(diff_list)}) != total score ({score}); "
                f"reason={reason}, diff={diff_list}"
            )

        return diff_list, dim_dict

    @staticmethod
    def _build_exit_diff_score(result, exit_reward_value=EXIT_REWARD_FAR):
        """Build diff_score for exit reward.

        Unified 3-dim format (same as no_entry):
            diff_score = [traj_valid, road_binding, wall]

        road_binding: +exit_reward_value when matched to exit path, else 0.0
        wall:         wall-crash penalty (≤ 0)
        """
        reason = result.get('reason', 'unknown')
        details = result.get('details', {})
        score = result.get('score', 0.0)

        if reason == 'no_trajectory_parsed':
            traj_valid = -4.0
        elif reason == 'trajectory_too_short':
            traj_valid = -3.0
        else:
            traj_valid = 0.0

        if reason == 'exit_path_matched':
            road_binding = exit_reward_value
        elif reason in ('no_trajectory_parsed', 'trajectory_too_short',
                         'no_road_geometries'):
            road_binding = 0.0
        else:
            road_binding = 0.0

        if reason == 'crash_into_wall':
            n = details.get('num_unsafe', 0)
            wall = -min(n, BINDING_MIN_POINTS) * WALL_PENALTY
        elif reason in ('no_trajectory_parsed', 'trajectory_too_short',
                         'no_road_geometries'):
            wall = 0.0
        else:
            wall = 0.0

        diff_list = [traj_valid, road_binding, wall]
        dim_dict = {'diff_traj_valid': traj_valid, 'diff_road_binding': road_binding,
                    'diff_wall': wall}

        if abs(sum(diff_list) - score) > 0.01:
            logger.warning(
                f"diff_score sum ({sum(diff_list)}) != total score ({score}); "
                f"reason={reason}, diff={diff_list}"
            )

        return diff_list, dim_dict

    # ── Debug logging ────────────────────────────────────────────────────────

    def _log_exit_debug(self, clip_id, data_source, solution_str,
                        action_traj, abs_traj, result,
                        exit_path_road_ids, vla_road_construction_info,
                        vla_goal_point, has_exit_sign,
                        intersection_distance, exit_reward_value,
                        intersection_info):
        if not self._debug:
            return
        score = result.get('score', '?')
        reason = result.get('reason', '?')
        diff_score = result.get('diff_score', [])
        is_inter = intersection_info.get('is_intersection', False) if intersection_info else False
        num_conn = intersection_info.get('num_connected_roads', 0) if intersection_info else 0
        if self._step <= self._debug_first_n:
            self._dbg(f"=== VLA-Reward-v4.3 exit step={self._step} FULL DUMP ===")
            self._dbg(f"  clip_id:      {clip_id}")
            self._dbg(f"  score:        {score}")
            self._dbg(f"  reason:       {reason}")
            self._dbg(f"  diff_score:   {diff_score}")
            self._dbg(f"  exit_path_ids: {sorted(exit_path_road_ids)}")
            self._dbg(f"  intersection:  dist={intersection_distance} is_inter={is_inter} "
                      f"connected={num_conn} → exit_reward={exit_reward_value}")
            self._dbg(f"  exit_sign:    {has_exit_sign}")
            self._dbg(f"  sol_len:      {len(solution_str)}")
            self._dbg(f"  solution_str: {repr(solution_str)}")
        elif self._step % self._debug_log_every == 0:
            self._dbg(f"VLA-Reward-v4.3 exit step={self._step} | score={score} "
                      f"reason={reason} diff={diff_score} "
                      f"inter_dist={intersection_distance} inter={is_inter} "
                      f"exit_reward={exit_reward_value} "
                      f"exit_sign={has_exit_sign} sol_len={len(solution_str)}")

    def _log_no_entry_debug(self, clip_id, data_source, solution_str,
                            action_traj, abs_traj, result,
                            forbidden_ids, road_graphs,
                            select_road_ids, select_road_cls,
                            freespace_info, vocab_path,
                            intersection_distance, forbidden_penalty,
                            intersection_info,
                            vla_goal_point, has_exit_sign,
                            exit_bonus, follows_exit, exit_details):
        if not self._debug:
            return
        score = result.get('score', '?')
        reason = result.get('reason', '?')
        diff_score = result.get('diff_score', [])
        if self._step <= self._debug_first_n:
            self._dbg(f"=== VLA-Reward-v4.3 no_entry step={self._step} FULL DUMP ===")
            self._dbg(f"  clip_id:      {clip_id}")
            self._dbg(f"  score:        {score}")
            self._dbg(f"  reason:       {reason}")
            self._dbg(f"  diff_score:   {diff_score}")
            self._dbg(f"  intersection: dist={intersection_distance} penalty={forbidden_penalty}")
            self._dbg(f"  exit:         bonus={exit_bonus} follows={follows_exit} sign={has_exit_sign}")
            self._dbg(f"  forbidden:    {forbidden_ids}")
            self._dbg(f"  sol_len:      {len(solution_str)}")
            self._dbg(f"  solution_str: {repr(solution_str)}")
        elif self._step % self._debug_log_every == 0:
            self._dbg(f"VLA-Reward-v4.3 no_entry step={self._step} | score={score} "
                      f"reason={reason} diff={diff_score} "
                      f"inter_dist={intersection_distance} "
                      f"exit_bonus={exit_bonus} "
                      f"exit_sign={has_exit_sign} sol_len={len(solution_str)}")

    @property
    def last_details(self):
        return self._last_details


# ═══════════════════════════════════════════════════════════════════════════════
#  Top-level function
# ═══════════════════════════════════════════════════════════════════════════════

_scorer = None
_scorer_debug = None


def vla_no_entry_reward(data_source, solution_str, ground_truth, extra_info,
                        debug=True, reward_version=None, iou_threshold=None,
                        debug_dir=None, **kwargs):
    global _scorer, _scorer_debug
    if _scorer is None or _scorer_debug != debug:
        _scorer = TaskVLANoEntryRewardV43(debug=debug, debug_dir=debug_dir)
        _scorer_debug = debug
    return _scorer(data_source, solution_str, ground_truth, extra_info)


# ═══════════════════════════════════════════════════════════════════════════════
#  __main__ — quick test
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import pandas as pd

    PARQUET_PATH = "/perception-hl/beijin.zhou/deeprl/260701_rl_exit_data/vln2_cotv3_UG_PARKING_EXIT_20260701_0534_part0000.parquet"
    NUM_SAMPLES = 3

    print(f"Loading parquet: {PARQUET_PATH}")
    df = pd.read_parquet(PARQUET_PATH)
    print(f"  {len(df)} samples\n")

    scorer = TaskVLANoEntryRewardV43(debug=True, debug_dir='/tmp/vla_reward_debug')

    for i in range(min(NUM_SAMPLES, len(df))):
        row = df.iloc[i]
        extra_info = row['extra_info']
        kwargs = extra_info['tools_kwargs']['calc_no-entry_reward']['calc_reward_kwargs']

        ds_type = extra_info.get('ds_type', 'no_entry')
        vla_road_construction_info = json.loads(kwargs.get('vla_road_construction_info', '{}') or '{}')
        exit_path_road_ids = set(json.loads(kwargs.get('exit_path_road_ids', '[]') or '[]'))

        all_road_geoms = build_road_geoms_from_vla_construction(vla_road_construction_info)
        intersection_info = detect_intersection_distance(all_road_geoms)
        intersection_distance = intersection_info.get("distance")
        exit_reward_value = get_exit_reward(intersection_distance)

        print(f"{'='*60}")
        print(f"Sample {i}  clip_id={extra_info['clip_id']}  ds_type={ds_type}")
        print(f"  exit_path_road_ids: {sorted(exit_path_road_ids)}")
        print(f"  num roads from vla_construction: {len(all_road_geoms)}")
        print(f"  intersection: dist={intersection_distance} "
              f"is_inter={intersection_info.get('is_intersection')} "
              f"connected={intersection_info.get('num_connected_roads')} "
              f"→ exit_reward={exit_reward_value}")

        test_trajs = [
            ("vocab format", "<action><action_200><action_304><action_302><action_399><action_108></action>"),
        ]

        for label, traj_str in test_trajs:
            result = scorer("no-entry_v4.3", traj_str, [], extra_info)
            score = result['score']
            reason = result.get('reason', '?')
            diff = result.get('diff_score', [])
            detail = result.get('details', {})
            matched = detail.get('matched_road_ids', [])
            print(f"  {label:12s} → score={score:6.2f}  diff={diff}  reason={reason}")
            if matched:
                for m in matched:
                    print(f"    seg#{m['segment_idx']} → road={m['road_id']}")

    print(f"\n{'='*60}")
    print("Done (v4.3).")
