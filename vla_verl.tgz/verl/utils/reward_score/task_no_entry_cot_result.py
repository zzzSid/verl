import re
import json
from typing import List


def extract_bbox(text):
    match = re.search(r"<box>([\d\.\-]+),([\d\.\-]+),([\d\.\-]+),([\d\.\-]+)</box>", text)
    if match:
        try:
            box = tuple(map(float, match.groups()))
        except:
            box = None
        return  box
    return None

def calculate_iou(box1, box2):
    """
    计算两个边界框的 IoU。
    输入: box1 和 box2 为 (xmin, ymin, xmax, ymax) 元组
    返回: IoU 值（0~1）
    """
    xA = max(box1[0], box2[0])
    yA = max(box1[1], box2[1])
    xB = min(box1[2], box2[2])
    yB = min(box1[3], box2[3])

    inter_w = max(0, xB - xA)
    inter_h = max(0, yB - yA)
    inter_area = inter_w * inter_h

    if inter_area == 0:
        return 0.0

    box1_area = (box1[2] - box1[0]) * (box1[3] - box1[1])
    box2_area = (box2[2] - box2[0]) * (box2[3] - box2[1])

    iou = inter_area / (box1_area + box2_area - inter_area)
    return iou

def bbox_reward(predict_str: str, solution_str: str, iou_threshold: float = 0.2) -> float:
    """
    计算预测边界框与 GT 边界框的奖励。
    - 若两者都无框，返回 1.0（无目标场景）
    - 若有一个有框一个没框（误检或漏检），返回 0.0
    - 若都有框，返回 IoU，若 IoU >= 0.7，返回 1.0
    """
    gt_box = extract_bbox(solution_str)
    pred_box = extract_bbox(predict_str)

    if gt_box is None and pred_box is None:
        return 1.0  # 无目标场景，得满分
    elif gt_box is None or pred_box is None:
        return 0.0  # 漏检 or 误检，0 分
    else:
        iou = calculate_iou(gt_box, pred_box)
        # return 1.0 if iou >= iou_threshold else iou*5
        return iou

def extract_tag(text: str, tag: str):
    """提取 <tag>...</tag> 内容；找不到返回 None"""
    m = re.search(rf"<{tag}>\s*(.*?)\s*</{tag}>", text, flags=re.S | re.I)
    return m.group(1) if m else None

def extract_answer_labels(pred_text: str):
    """从 <answer> 中提取 A;B;A -> ['A','B','A']。提取失败返回 None"""
    ans = extract_tag(pred_text, "answer")
    if ans is None:
        return None
    ans = re.sub(r"\s+", "", ans)  # 去掉空白
    if ans == "":
        return []
    return ans.split(";")
    
def no_entry_reward(
    data_source,
    solution_str,
    ground_truth,
    extra_info,
    reward_version="SimpleCot",
    iou_threshold=0.5,
):
    scorer = TaskNoEntryReward(reward_version=reward_version, iou_threshold=iou_threshold)
    # 这里用 __call__ 来算分
    return scorer(data_source, solution_str, ground_truth, extra_info)

class TaskNoEntryReward:
    
    def __init__(self, reward_version, iou_threshold) -> None:
        self.reward_version = reward_version
        self.iou_threshold = iou_threshold
        self._format_score = 0.0
        self._format_score_details = list()
        self._content_score = 0.0
        self._content_score_details = list()
    
    def __call__(self, data_source, solution_str, ground_truth, extra_info):
        
        if "no-entry" not in data_source:
            raise ValueError(f"data_source: {data_source} is not for no-entry task!")
        final_score = self.calc_score_simple_cot(solution_str, ground_truth)
        # print(f'{__file__}:', data_source, extract_tag(solution_str,"answer"), ground_truth,final_score)
        print(f'{__file__}:', data_source, solution_str, ground_truth,final_score)

        return final_score
    
    def calc_score_simple_cot(self, pred:str, all_gts:List[List[str]]):
        # post_pred = pred.replace(' ', '')
        post_pred = extract_tag(pred,"answer")
        thinking = extract_tag(pred, "thinking")
        all_road_preds = post_pred.replace(' ', '').split(";") if post_pred is not None else ""

        tag_check = False
        length_check = True
        AB_check = True
        img_id_check = True
        bbox_check = True

        if thinking is not None and post_pred is not None:
            pos_th = pred.lower().find("<thinking>")
            pos_an = pred.lower().find("<answer>")
            if pos_th != -1 and pos_an != -1 and pos_th < pos_an:
                tag_check = True
        if len(all_road_preds) != len(all_gts):
            length_check = False
            
        
        for idx,road_pred in enumerate(all_road_preds):
            if idx >= len(all_gts): break
            true_answer = all_gts[idx][0]
            true_label = true_answer[0].upper() # 第一个字符是答案
            if len(road_pred) == 0:
                AB_check = False
            elif len(road_pred) == 1:
                if road_pred not in ['A', 'B']:
                    AB_check = False
            else:
                ## A不需要框
                if true_label == 'A':
                    continue
                img_id = re.search(r"\[UNUSED_TOKEN_32\](.*?)\[UNUSED_TOKEN_33\]", road_pred)
                if img_id == None:
                    img_id_check = False
                elif img_id.group(1) not in ['[UNUSED_TOKEN_53]', '[UNUSED_TOKEN_54]', 
                                             '[UNUSED_TOKEN_55]', '[UNUSED_TOKEN_56]']:
                    img_id_check = False
                bbox = re.search(r'<box>(.*?)</box>', road_pred)
                if bbox == None:
                    bbox_check = False
                else:
                    try:
                        coords = [float(x) for x in bbox.group(1).split(',')]
                        if len(coords) != 4:
                            bbox_check = False
                        else:
                            for coord in coords:
                                if coord < 0 or coord > 999:
                                    bbox_check = False
                    except ValueError as e:
                        bbox_check = False
                    
        format_score = 0.0
        _length_score = 0.0
        _AB_score = 0.0
        _img_id_score = 0.0
        _bbox_score = 0.0
        _tag_score = 0.0
        if length_check: _length_score = 0.2
        if AB_check: _AB_score = 0.2
        if img_id_check: _img_id_score = 0.2
        if bbox_check: _bbox_score = 0.2
        if tag_check: _tag_score=0.2
        format_score = _length_score + _AB_score + _img_id_score + _bbox_score + _tag_score
            
        content_score = 0.0
        _category_score = 0.0
        _grounding_score = 0.0
        max_content_score = 0.0  # 用于归一化
        grounding_list = list()
        category_score_list = list()
        if length_check and tag_check:
            for pred, gts in zip(all_road_preds, all_gts):
                true_label = gts[0][0].upper()
                grounding_list.append(0)
                # 计算该条路的最大可能内容分
                if true_label == "B":
                    # B: 分类最多10分 + grounding最多2分
                    max_content_score += 12.0
                else:  # A 最多8分
                    max_content_score += 8.0
                # 依次计算每个预测的的得分
                gts_img_id = [re.search(r"\[UNUSED_TOKEN_32\](.*?)\[UNUSED_TOKEN_33\]", gt) for gt in gts]
                pred_img_id = re.search(r"\[UNUSED_TOKEN_32\](.*?)\[UNUSED_TOKEN_33\]", pred)
                if pred_img_id != None and gts_img_id.count(None) != len(gts):
                    # 匹配上真值中任意一个，即可得分
                    grounding_score_list = list()
                    for each_gt in gts:
                        gt_img_id = re.search(r"\[UNUSED_TOKEN_32\](.*?)\[UNUSED_TOKEN_33\]", each_gt)
                        if gt_img_id != None and gt_img_id.group(1) == pred_img_id.group(1):
                            temp_score = bbox_reward(pred, each_gt, self.iou_threshold)
                            grounding_score_list.append(temp_score)
                    
                    if grounding_score_list != []:
                        _grounding_score += max(grounding_score_list)*2.0
                        grounding_list[-1] = max(grounding_score_list)*2.0
                        
                ##  B 如果答对+2分，A 如果答对+1分，倾向于把b答对
                # 真实答案是A，但预测为B，给0分
                # 真实答案是B，但预测为A，给0分
                # 真实答案是B，但预测为B，给10分
                # 真实答案是A，但预测为A，给8分
                if len(pred)> 0 :
                    if pred[0].upper() == gts[0][0].upper():
                        if true_label == "B":
                            _category_score += 10.0
                            category_score_list.append(10.0)
                        else:
                            _category_score += 8.0
                            category_score_list.append(8.0)
                    else:
                        if true_label == "B":
                            _category_score += 2.0
                            category_score_list.append(2.0)
                        else:
                            _category_score += 0.0
                            category_score_list.append(0.0)

              
        content_score = _grounding_score + _category_score
        ## 归一化
        if max_content_score > 0:
            content_score_norm = content_score / max_content_score
        else:
            content_score_norm = 0.0
        
        from itertools import zip_longest
        each_score_list = [x + y for x, y in zip_longest(grounding_list, category_score_list, fillvalue=0)]
        if len(each_score_list)< len(all_gts):
            each_score_list.extend([0]*(len(all_gts)-len(each_score_list)))
        # dump score details
        self._format_score = format_score
        self._content_score = content_score_norm
        self._format_score_details = [_length_score, _AB_score, _img_id_score, _bbox_score,_tag_score]
        self._content_score_details = [_grounding_score, _category_score]
        # 正则，比例1:1
        # return format_score + content_score_norm
        return {
            "score": format_score + content_score_norm,
            "format_score": format_score,
            "content_score": content_score_norm,
            "diff_score":each_score_list+[format_score]

        }
                
            


if __name__ == "__main__":
    # data_path = '/lustre/joeden.zhuang/projects/vlm_no_entry/output_prod/no_entry_road_test_1110-1.jsonl'
    # # data_path = '/lustre/joeden.zhuang/projects/vlm_no_entry/output_prod/no_entry_road_train_1110-1.jsonl'
    # with open(data_path, 'r') as f:
    #     data_list = [json.loads(line.strip()) for line in f]
    pred = """<thinking>\n路线1（从Question提取：第1条）：\n第0步：观察路线坐标序列，y值从-2.95大幅减少至-17.47，x值持续增加 → 根据路线描述及BEV坐标变化趋势 → 中间结论：该路线意图是向右行驶，因此后续重点检查与向右方向相关的标牌/箭头/障碍物。\n第1步：观察在 [UNUSED_TOKEN_53] 视角中，逐步搜索标牌区域，未锁定到任何禁行标牌；在 [UNUSED_TOKEN_56] 视角中，也未观察到“禁止通行”或“单行通道 禁止逆行”文字 → 根据【存在禁行标牌】（出现“禁止通行标识牌无文字”或文字为“单行通道，禁止逆行”的禁行牌）→ 中间结论：未触发。\n第2步：观察在 [UNUSED_TOKEN_53] 视角中，地面黄色箭头指向右前方，与路线向右行驶方向一致；参考 [UNUSED_TOKEN_34]...[UNUSED_TOKEN_35] 中的方向信息辅助确认 → 根据【存在禁行marker】（自车/路线方向与道路箭头方向不一致）→ 中间结论：未触发。\n第3步：观察在 [UNUSED_TOKEN_53] 和 [UNUSED_TOKEN_56] 视角中，搜索路线路径区域，未发现护栏/水马/锥桶/道闸等障碍物阻挡本车道 → 根据【存在禁行临时障碍物】（护栏/水马/锥桶/道闸等使对应道路无法通行）→ 中间结论：未触发。\n第4步：观察在 [UNUSED_TOKEN_53] 视角中，道路为单向通道，无对向车道；未发现禁行标牌或障碍物出现在对向 → 根据【双向路对向车道禁行(负样本，可通行)】→ 中间结论：本向仍可行/可排除禁行。\n第5步：因此该路线为A，关键依据是【可通行道路(负样本，可通行)】（不存在禁行标牌/marker逆行/本车道障碍物）。\n\n路线2（从Question提取：第2条）：\n第0步：观察路线坐标序列，y值从-2.95大幅增加至18.22，x值持续增加 → 根据路线描述及BEV坐标变化趋势 → 中间结论：该路线意图是向左行驶，因此后续重点检查与向左方向相关的标牌/箭头/障碍物。\n第1步：观察在 [UNUSED_TOKEN_53] 视角中，逐步搜索标牌区域，未锁定到任何禁行标牌；在 [UNUSED_TOKEN_55] 视角中，也未观察到“禁止通行”或“单行通道 禁止逆行”文字 → 根据【存在禁行标牌】（出现“禁止通行标识牌无文字”或文字为“单行通道，禁止逆行”的禁行牌）→ 中间结论：未触发。\n第2步：观察在 [UNUSED_TOKEN_53] 视角中，地面黄色箭头指向左前方，与路线向左行驶方向一致；参考 [UNUSED_TOKEN_34]...[UNUSED_TOKEN_35] 中的方向信息辅助确认 → 根据【存在禁行marker】（自车/路线方向与道路箭头方向不一致）→ 中间结论：未触发。\n第3步：观察在 [UNUSED_TOKEN_53] 和 [UNUSED_TOKEN_55] 视角中，搜索路线路径区域，未发现护栏/水马/锥桶/道闸等障碍物阻挡本车道 → 根据【存在禁行临时障碍物】（护栏/水马/锥桶/道闸等使对应道路无法通行）→ 中间结论：未触发。\n第4步：观察在 [UNUSED_TOKEN_53] 视角中，道路为单向通道，无对向车道；未发现禁行标牌或障碍物出现在对向 → 根据【双向路对向车道禁行(负样本，可通行)】→ 中间结论：本向仍可行/可排除禁行。\n第5步：因此该路线为A，关键依据是【可通行道路(负样本，可通行)】（不存在禁行标牌/marker逆行/本车道障碍物）。\n\n路线3（从Question提取：第3条）：\n第0步：观察路线坐标序列，y值从-2.95大幅减少至-24.85，x值减少 → 根据路线描述及BEV坐标变化趋势 → 中间结论：该路线意图是向右后方行驶（可能为掉头或右转），因此后续重点检查与该方向相关的标牌/箭头/障碍物。\n第1步：观察在 [UNUSED_TOKEN_53] 视角中，逐步搜索并锁定到 <box>645,363,674,384</box> 区域，观察到红圈白杠的禁止通行标志 → 根据【存在禁行标牌】（出现“禁止通行标识牌无文字”或文字为“单行通道，禁止逆行”的禁行牌）→ 中间结论：触发。\n第2步：观察在 [UNUSED_TOKEN_53] 视角中，地面箭头指向直行方向，与路线向右后方行驶方向不一致；参考 [UNUSED_TOKEN_34]...[UNUSED_TOKEN_35] 中的方向信息辅助确认 → 根据【存在禁行marker】（自车/路线方向与道路箭头方向不一致）→ 中间结论：触发。\n第3步：观察在 [UNUSED_TOKEN_53] 视角中，搜索路线路径区域，未发现护栏/水马/锥桶/道闸等障碍物阻挡本车道 → 根据【存在禁行临时障碍物】（护栏/水马/锥桶/道闸等使对应道路无法通行）→ 中间结论：未触发。\n第4步：观察在 [UNUSED_TOKEN_53] 视角中，道路为单向通道，禁行标志位于本路线要走的车道上，非对向车道 → 根据【双向路对向车道禁行(负样本，可通行)】→ 中间结论：不属于对向负样本，不能排除禁行。\n第5步：因此该路线为B，关键依据是【存在禁行标牌】（出现“禁止通行标识牌无文字”）。\n\n路线4（从Question提取：第4条）：\n第0步：观察路线坐标序列，y值从-0.07小幅减少至-2.95，x值增加 → 根据路线描述及BEV坐标变化趋势 → 中间结论：该路线意图是直行，因此后续重点检查与直行方向相关的标牌/箭头/障碍物。\n第1步：观察在 [UNUSED_TOKEN_53] 视角中，逐步搜索标牌区域，未锁定到任何禁行标牌；在 [UNUSED_TOKEN_54] 视角中，也未观察到“禁止通行”或“单行通道 禁止逆行”文字 → 根据【存在禁行标牌】（出现“禁止通行标识牌无文字”或文字为“单行通道，禁止逆行”的禁行牌）→ 中间结论：未触发。\n第2步：观察在 [UNUSED_TOKEN_53] 视角中，地面黄色箭头指向直行方向，与路线直行方向一致；参考 [UNUSED_TOKEN_34]...[UNUSED_TOKEN_35] 中的方向信息辅助确认 → 根据【存在禁行marker】（自车/路线方向与道路箭头方向不一致）→ 中间结论：未触发。\n第3步：观察在 [UNUSED_TOKEN_53] 和 [UNUSED_TOKEN_54] 视角中，搜索路线路径区域，未发现护栏/水马/锥桶/道闸等障碍物阻挡本车道 → 根据【存在禁行临时障碍物】（护栏/水马/锥桶/道闸等使对应道路无法通行）→ 中间结论：未触发。\n第4步：观察在 [UNUSED_TOKEN_53] 视角中，道路为单向通道，无对向车道；未发现禁行标牌或障碍物出现在对向 → 根据【双向路对向车道禁行(负样本，可通行)】→ 中间结论：本向仍可行/可排除禁行。\n第5步：因此该路线为A，关键依据是【可通行道路(负样本，可通行)】（不存在禁行标牌/marker逆行/本车道障碍物）。\n</thinking>\n<answer>A;A;B[UNUSED_TOKEN_32][UNUSED_TOKEN_53][UNUSED_TOKEN_33]<box>645,363,674,384</box>;A</answer>"""
    all_gts = [['A'], ['A'],['B[UNUSED_TOKEN_32][UNUSED_TOKEN_53][UNUSED_TOKEN_33]<box>645,363,674,440</box>',
    'B[UNUSED_TOKEN_32][UNUSED_TOKEN_56][UNUSED_TOKEN_33]<box>379,458,385,472</box>'],['A']]
    reward_scorer = TaskNoEntryReward('simple-cot', 0.5)
    final_score = reward_scorer.calc_score_simple_cot(pred=pred, all_gts=all_gts)
    print(f'final_score={final_score}', \
        f'format_score_details:{reward_scorer._format_score_details}', \
        f'content_score_details:{reward_scorer._content_score_details}')
    # for data in data_list[:200]:
    #     pred = data['conversations'][1]['value']
    #     all_gts = data['extra']['all_cand_gts']

    #     final_score = reward_scorer.calc_score_simple_cot(pred=pred, all_gts=all_gts)
    #     print(f'final_score={final_score}', \
    #         f'format_score_details:{reward_scorer._format_score_details}', \
    #         f'content_score_details:{reward_scorer._content_score_details}')
    