"""
VLA No-Entry Reward v1 — trajectory-to-road binding based conflict detection.

Evaluates whether the model's predicted trajectory enters forbidden roads
or crashes into walls. Core logic adapted from tools/tools_bj/ref/eval.py.

Simultaneously compatible with GRPO and GDPO:
  - "score"  : scalar total reward, used by GRPO (and other adv estimators)
  - "diff_score" : 3-dim decomposed reward vector, used by GDPO for
                   per-dimension group-wise normalization

Scoring rules (≤ 0, higher is better):
    ─────────────────────────────────────────────────────────────
    场景                                   score     reason
    ─────────────────────────────────────────────────────────────
    无禁行路（所有路均可通行）              0.0       no_forbidden_roads
    无法解析轨迹（无 <action> 标签）       -4.0       no_trajectory_parsed
    轨迹过短（< 5 个点）                 -3.0       trajectory_too_short
    正确（未进禁行路、未撞墙）              0.0       correct
    进入禁行路                             -2.5      segment_binds_to_forbidden_road
    撞墙（N 个 unsafe 点）               -1.0×N    crash_into_wall
    ─────────────────────────────────────────────────────────────

GDPO diff_score decomposition (3 fixed dimensions, sum = total score):
    diff_score = [
        trajectory_validity_score,   # -4.0/-3.0/0.0
        forbidden_road_score,        # -2.5/0.0
        wall_crash_score,            # -N*1.0/0.0
    ]
    N/A dimensions default to 0.0 (group-mean, yielding zero advantage).

Field-distinction summary:
    - no_forbidden_roads   : scene has zero forbidden roads → skip evaluation
    - no_trajectory_parsed : model output lacks valid <action>...</action>
    - trajectory_too_short : parsed, but fewer than 5 trajectory points → -3.0
    - correct              : trajectory avoids all forbidden roads & walls
    - forbidden_road / wall: violation detected
"""

import json
import logging
import os
import pickle
import random
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════════════
#  Constants
# ═══════════════════════════════════════════════════════════════════════════════

FORBIDDEN_ROAD_CLASSES = {'noEntryRoad', 'noEntryRoadBarrier', 'ArriveDeadEndRoad', 'onlyRetrograde'}

BINDING_W_DIST   = 0.5
BINDING_W_ANGLE  = 0.5
BINDING_MAX_DIST = 5.0        # meters
BINDING_MIN_POINTS = 5        # minimum trajectory points (after prepending origin)

WALL_PENALTY      = 1.0       # per unsafe-point
FORBIDDEN_PENALTY = 2.5       # entering forbidden road

COORD_NORM_MIN, COORD_NORM_MAX = 0, 1000
COORD_PHYS_MIN, COORD_PHYS_MAX = -30.0, 30.0

ACTION_POINTS_RE = re.compile(r"\((\d+),(\d+)\)")
ACTION_TOKEN_RE  = re.compile(r"<action_(\d+)>")

# Vocab-based decoding (for <action_N> token format)
_DEFAULT_VOCAB_PATH = "/perception-hl/longan.yang/vla_data/vlm_path/train_dataset/vocab/0804_all/tokens_512_v1.npy"
_VOCABULARY = None
_VOCAB_PATH_USED = None


def get_vocabulary(vocab_path=None):
    """Load vocabulary for decoding <action_N> tokens.

    Vocabulary is a (V, 3) array where each row is (dx, dy, dheading).
    Cached globally so it's only loaded once.
    """
    global _VOCABULARY, _VOCAB_PATH_USED
    path = vocab_path or os.environ.get('VLA_VOCAB_PATH') or _DEFAULT_VOCAB_PATH
    if _VOCABULARY is not None and _VOCAB_PATH_USED == path:
        return _VOCABULARY
    if os.path.exists(path):
        _VOCABULARY = np.load(path)
        _VOCAB_PATH_USED = path
    else:
        logger.warning(f"VLA vocab path not found: {path}")
        _VOCABULARY = np.array([])
        _VOCAB_PATH_USED = path
    return _VOCABULARY

# ═══════════════════════════════════════════════════════════════════════════════
#  Trajectory parsing
# ═══════════════════════════════════════════════════════════════════════════════

def parse_action_traj(prediction_text: str, vocab_path=None):
    """Parse trajectory from model output.

    Supports two formats:
      1. <action>(x,y),(x,y),...</action>  → normalized coords (0-1000)
      2. <action><action_123><action_45>...</action> → vocab-based absolute coords (meters)

    Returns list of [x, y] pairs or None.
    """
    if not prediction_text:
        return None

    action_match = re.search(r"<action>(.*?)</action>", prediction_text, re.DOTALL)
    if not action_match:
        return None

    content = action_match.group(1)

    # Format 1: (x,y) coordinate pairs
    points = ACTION_POINTS_RE.findall(content)
    if points:
        return [[int(x), int(y)] for x, y in points]

    # Format 2: <action_N> token sequences → decode via vocabulary
    token_matches = ACTION_TOKEN_RE.findall(content)
    if not token_matches:
        return None

    vocabulary = get_vocabulary(vocab_path)
    if vocabulary is None or vocabulary.size == 0:
        return None

    vocab_indices = [int(m) for m in token_matches]

    # Decode: accumulate (dx, dy, dheading) from vocab, apply rotation by current heading
    x, y, theta = 0.0, 0.0, 0.0
    xs, ys = [], []

    for idx in vocab_indices:
        if idx == 0:
            xs.append(x)
            ys.append(y)
            continue

        vocab_row = idx - 1
        if vocab_row < 0 or vocab_row >= vocabulary.shape[0]:
            continue

        dx, dy, dheading = vocabulary[vocab_row]

        cos_t = np.cos(theta)
        sin_t = np.sin(theta)

        x = float(x + dx * cos_t - dy * sin_t)
        y = float(y + dx * sin_t + dy * cos_t)
        theta = float(np.arctan2(np.sin(theta + dheading), np.cos(theta + dheading)))

        xs.append(x)
        ys.append(y)

    if not xs:
        return None

    return [[x, y] for x, y in zip(xs, ys)]


def norm_to_abs_traj(norm_traj):
    """Convert normalized coords 0-1000 to BEV meters -30..30."""
    if norm_traj is None or len(norm_traj) == 0:
        return None
    scale = (COORD_PHYS_MAX - COORD_PHYS_MIN) / (COORD_NORM_MAX - COORD_NORM_MIN)
    abs_traj = []
    for x_n, y_n in norm_traj:
        abs_traj.append([
            COORD_PHYS_MIN + x_n * scale,
            COORD_PHYS_MIN + y_n * scale,
        ])
    return np.array(abs_traj, dtype=float)


def action_traj_to_abs(action_traj):
    """Convert parsed action_traj to absolute BEV coordinates (meters)."""
    if action_traj is None or len(action_traj) == 0:
        return None
    if isinstance(action_traj[0][0], int):
        return norm_to_abs_traj(action_traj)
    return np.array(action_traj, dtype=float)

# ═══════════════════════════════════════════════════════════════════════════════
#  Road data helpers
# ═══════════════════════════════════════════════════════════════════════════════

def get_forbidden_road_ids(select_road_ids, select_road_cls):
    """Return set of road IDs whose class is in FORBIDDEN_ROAD_CLASSES."""
    forbidden = set()
    for rid, cls in zip(select_road_ids, select_road_cls):
        if cls in FORBIDDEN_ROAD_CLASSES:
            forbidden.add(rid)
    return forbidden


def get_all_road_geometries(road_graphs):
    """Extract road_id → (N,2) geometry arrays from road_graphs dict."""
    geometries = {}
    for road_id, info in road_graphs.items():
        if info and 'geometry' in info:
            geom = np.array(info['geometry'], dtype=float)
            if len(geom) >= 2:
                geometries[road_id] = geom
    return geometries


def get_road_id_to_cls(select_road_ids, select_road_cls):
    """Build road_id → road_cls dict."""
    return dict(zip(select_road_ids, select_road_cls))

# ═══════════════════════════════════════════════════════════════════════════════
#  Geometry helpers (segment → road binding)
# ═══════════════════════════════════════════════════════════════════════════════

def _min_distance_point_to_polyline(point, polyline):
    """Minimum distance from `point` (2,) to a polyline (N,2)."""
    point = np.asarray(point, dtype=float)
    min_dist = float('inf')
    closest_pt = None
    for i in range(len(polyline) - 1):
        a, b = polyline[i], polyline[i + 1]
        ab = b - a
        ab_len_sq = np.dot(ab, ab)
        if ab_len_sq < 1e-12:
            dist = np.linalg.norm(point - a)
            if dist < min_dist:
                min_dist, closest_pt = dist, a.copy()
            continue
        t = max(0.0, min(1.0, np.dot(point - a, ab) / ab_len_sq))
        closest = a + t * ab
        dist = np.linalg.norm(point - closest)
        if dist < min_dist:
            min_dist, closest_pt = dist, closest.copy()
    return min_dist, closest_pt


def _road_direction_at_point(polyline, closest_point):
    """Direction vector of the polyline segment nearest to closest_point."""
    min_seg_dist = float('inf')
    best_dir = None
    for i in range(len(polyline) - 1):
        a, b = polyline[i], polyline[i + 1]
        mid = (a + b) / 2.0
        d = np.linalg.norm(closest_point - mid)
        if d < min_seg_dist:
            min_seg_dist = d
            seg_dir = b - a
            seg_len = np.linalg.norm(seg_dir)
            if seg_len > 1e-8:
                best_dir = seg_dir / seg_len
    return best_dir


def compute_segment_binding_score(segment, geom):
    """Score how well a 3-point trajectory segment binds to a road geometry.

    Returns dict with score/dist/angle_deg/closest_pt, or None if excluded.
    """
    center = np.mean(segment, axis=0)
    min_dist, closest_pt = _min_distance_point_to_polyline(center, geom)
    if min_dist > BINDING_MAX_DIST:
        return None

    seg_vec = segment[-1] - segment[0]
    seg_len = np.linalg.norm(seg_vec)
    if seg_len < 1e-6:
        return None
    seg_heading = np.arctan2(seg_vec[1], seg_vec[0])

    road_dir = _road_direction_at_point(geom, closest_pt)
    if road_dir is None:
        return None
    road_heading = np.arctan2(road_dir[1], road_dir[0])

    angle_diff = seg_heading - road_heading
    angle_diff = np.degrees(np.arctan2(np.sin(angle_diff), np.cos(angle_diff)))
    abs_angle = abs(angle_diff)

    # Crossing exclusion (60° < |angle| < 120°)
    if 60.0 < abs_angle < 120.0:
        return None

    # Reverse exclusion (skip if road spans both sides of origin)
    has_both_sides = (np.any(geom[:, 1] > 0) and np.any(geom[:, 1] < 0))
    if not has_both_sides and abs_angle > 90.0:
        return None

    # Global direction check
    if len(geom) >= 2:
        global_vec = geom[-1] - geom[0]
        global_heading = np.arctan2(global_vec[1], global_vec[0])
        global_diff = seg_heading - global_heading
        global_diff = np.degrees(np.arctan2(np.sin(global_diff), np.cos(global_diff)))
        if 60.0 < abs(global_diff) < 120.0:
            return None

    norm_dist = min(min_dist / BINDING_MAX_DIST, 1.0)
    norm_angle = abs_angle / 90.0
    score = BINDING_W_DIST * norm_dist + BINDING_W_ANGLE * norm_angle

    return {
        'score': score,
        'dist': float(min_dist),
        'angle_deg': float(angle_diff),
        'closest_pt': closest_pt.tolist(),
    }


def bind_segment_to_road(segment, all_road_geoms):
    """Find the best-matching road for a trajectory segment.

    Returns (best_road_id, binding_info) or (None, None).
    """
    best_road_id = None
    best_score = float('inf')
    best_info = None
    for road_id, geom in all_road_geoms.items():
        result = compute_segment_binding_score(segment, geom)
        if result is None:
            continue
        if result['score'] < best_score:
            best_score = result['score']
            best_road_id = road_id
            best_info = result
    return best_road_id, best_info

# ═══════════════════════════════════════════════════════════════════════════════
#  Unsafe-mask / wall-crash helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _decode_rle_mask(rle):
    """Decode COCO RLE mask to numpy array. Falls back to minimal decoder."""
    if not rle or 'counts' not in rle or 'size' not in rle:
        return None
    try:
        from pycocotools import mask as coco_mask
        counts = rle['counts']
        if isinstance(counts, str):
            counts = counts.encode('utf-8')
        m = coco_mask.decode({'size': rle['size'], 'counts': counts})
        return m.astype(np.uint8)
    except ImportError:
        pass

    # Minimal fallback RLE decoder
    try:
        h, w = rle['size']
        counts = rle['counts']
        if isinstance(counts, str):
            counts = counts.encode('utf-8')
        mask = np.zeros(h * w, dtype=np.uint8)
        counts_list = list(counts)
        pos, val = 0, 0
        i = 0
        while i < len(counts_list):
            x, k = 0, 0
            more = True
            while more:
                c = counts_list[i] - 48
                x |= (c & 0x1f) << (5 * k)
                more = c & 0x20
                i += 1
                k += 1
                if not more and (c & 0x10):
                    x |= -1 << (5 * k)
            for _ in range(x):
                if pos < len(mask):
                    mask[pos] = val
                    pos += 1
            val = 1 - val
        return mask.reshape((h, w), order='F')
    except Exception:
        return None


def bev_to_mask_coords(x_m, y_m, mask_size=600):
    """Convert BEV meters → mask pixel (row, col)."""
    scale = 60.0 / mask_size
    offset = 30.0
    row = int(round((offset - x_m) / scale))
    col = int(round((-y_m + offset) / scale))
    if 0 <= row < mask_size and 0 <= col < mask_size:
        return (row, col)
    return None


def get_unsafe_masks(freespace_info):
    """Decode unsafe RLE mask from freespace_info. Returns list of masks."""
    if not freespace_info:
        return []
    unsafe_rle = freespace_info.get('unsafe')
    if not unsafe_rle:
        return []
    mask = _decode_rle_mask(unsafe_rle)
    return [mask] if mask is not None else []


def check_traj_crash_into_wall(abs_traj, unsafe_masks, min_points=BINDING_MIN_POINTS):
    """Check whether trajectory crashes into wall (unsafe area)."""
    if abs_traj is None or len(abs_traj) < min_points:
        return False, {'reason': 'no_crash'}

    if not unsafe_masks:
        return False, {'reason': 'no_crash'}

    traj_points = abs_traj[:min_points]
    unsafe_indices = []
    for idx, pt in enumerate(traj_points):
        for mask in unsafe_masks:
            h, w = mask.shape
            pixel = bev_to_mask_coords(float(pt[0]), float(pt[1]), mask_size=h)
            if pixel is not None:
                r, c = pixel
                if mask[r, c] == 1:
                    unsafe_indices.append(idx)
                    break

    num_unsafe = len(unsafe_indices)
    if num_unsafe >= 2:
        return True, {
            'reason': 'crash_into_wall',
            'unsafe_points': unsafe_indices,
            'num_unsafe': num_unsafe,
        }
    return False, {'reason': 'no_crash'}

# ═══════════════════════════════════════════════════════════════════════════════
#  Core: segment-binding violation check
# ═══════════════════════════════════════════════════════════════════════════════

def check_traj_violation_by_binding(
    abs_traj,
    all_road_geoms,
    road_id_to_cls,
    forbidden_ids,
    unsafe_masks=None,
    min_points=BINDING_MIN_POINTS,
):
    """Check if trajectory enters a forbidden road or crashes into wall.

    Algorithm:
      1. Prepend origin (0,0) to trajectory → 6 points
      2. Create 4 segments of 3 consecutive points each
      3. Bind each segment to best-matching road
      4. If any segment binds to a forbidden road → violation
      5. Else, check crash-into-wall (lower priority)

    Returns (is_violation: bool, details: dict).
    """
    if abs_traj is None or len(abs_traj) < min_points:
        return True, {'reason': 'trajectory_too_short',
                      'num_points': len(abs_traj) if abs_traj is not None else 0}

    origin = np.array([[0.0, 0.0]])
    full_traj = np.vstack([origin, abs_traj[:min_points]])  # 6 points

    for i in range(len(full_traj) - 2):
        segment = full_traj[i:i + 3]
        road_id, info = bind_segment_to_road(segment, all_road_geoms)

        if road_id is not None and road_id in forbidden_ids:
            return True, {
                'reason': 'segment_binds_to_forbidden_road',
                'segment_idx': i,
                'road_id': road_id,
                'road_cls': road_id_to_cls.get(road_id, 'unknown'),
                'binding_info': info,
            }

    # Fallback: check wall crash
    if unsafe_masks:
        is_crash, crash_details = check_traj_crash_into_wall(abs_traj, unsafe_masks, min_points)
        if is_crash:
            return True, crash_details

    return False, {'reason': 'no_violation'}

# ═══════════════════════════════════════════════════════════════════════════════
#  Reward interface
# ═══════════════════════════════════════════════════════════════════════════════

class TaskVLANoEntryReward:
    """VLA no-entry reward: trajectory-binding based conflict scoring.

    Usage (verl compatible):
        scorer = TaskVLANoEntryReward(debug=True)
        result = scorer(data_source, solution_str, ground_truth, extra_info)
        # result is a float score (≤0), or a dict with "score" key
    """

    def __init__(self, debug=False, debug_dir="/tmp/vla_reward_test"):
        self._last_details = {}
        self._debug = debug
        self._step = 0
        self._debug_first_n = 200       # 前 N 步打印完整模型输出
        self._debug_log_every = 20    # 之后每 K 步打印摘要
        self._debug_dir = debug_dir or os.environ.get('VLA_DEBUG_DIR') or '/tmp/vla_reward_debug'

    def __call__(self, data_source, solution_str, ground_truth, extra_info):
        self._step += 1
        return self.compute_score(data_source, solution_str, ground_truth, extra_info)

    def _dbg(self, msg):
        if self._debug:
            # Write to file so output is visible from main console via `tail -f`
            with open("/tmp/vla_reward_debug.log", "a") as f:
                f.write(msg + "\n")

    def _save_debug_pkl(self, debug_data):
        """Save full debug data to a pickle file for offline visualization."""
        if not self._debug:
            return
        try:
            os.makedirs(self._debug_dir, exist_ok=True)
            clip_id = debug_data.get('clip_id', 'unknown')
            rnd = random.randint(1000, 9999)
            fname = f"{clip_id}_{rnd}.pkl"
            fpath = os.path.join(self._debug_dir, fname)
            with open(fpath, 'wb') as f:
                pickle.dump(debug_data, f)
            self._dbg(f"  [PKL] saved → {fpath}")
        except Exception as e:
            self._dbg(f"  [PKL] FAILED to save: {e}")

    def _log_model_output(self, solution_str, action_traj, abs_traj, result, debug_data):
        """Debug logging: text log (rate-limited) + full pkl dump (every sample)."""
        if not self._debug:
            return

        score = result.get('score', '?')
        reason = result.get('reason', '?')
        diff_score = result.get('diff_score', [])
        clip_id = debug_data.get('clip_id', '?')

        # Pkl dump: always saved when debug is on
        # self._save_debug_pkl(debug_data)

        # Text log: rate-limited to avoid flooding
        if self._step <= self._debug_first_n:
            self._dbg(f"=== VLA-Reward step={self._step} FULL DUMP ===")
            self._dbg(f"  clip_id:     {clip_id}")
            self._dbg(f"  score:       {score}")
            self._dbg(f"  reason:      {reason}")
            self._dbg(f"  diff_score:  {diff_score}")
            self._dbg(f"  forbidden:   {debug_data.get('forbidden_ids', set())}")
            self._dbg(f"  sol_len:     {len(solution_str)}")
            self._dbg(f"  traj_pts:    {len(action_traj) if action_traj else 0}")
            self._dbg(f"  solution_str ({len(solution_str)} chars):")
            self._dbg(f"  {repr(solution_str)}")
        elif self._step % self._debug_log_every == 0:
            self._dbg(f"VLA-Reward step={self._step} | score={score} "
                      f"reason={reason} diff={diff_score} "
                      f"sol_len={len(solution_str)}")

    def _extract_kwargs(self, extra_info):
        """Extract reward-relevant data from extra_info."""
        tools_kwargs = extra_info.get('tools_kwargs', {})
        reward_cfg = tools_kwargs.get('calc_no-entry_reward', {})
        kwargs = reward_cfg.get('calc_reward_kwargs', {})
        return kwargs

    def compute_score(self, data_source, solution_str, ground_truth, extra_info):
        """Compute VLA no-entry reward score.

        Args:
            data_source: str, e.g. "no-entry_260611-no_entry-v1.0"
            solution_str: model's output text (contains <action> trajectory)
            ground_truth: all_cand_gts (not used for VLA reward)
            extra_info: dict with tools_kwargs → calc_reward_kwargs

        Returns:
            dict: {"score": float ≤ 0, "reason": str, ...}
        """
        kwargs = self._extract_kwargs(extra_info)
        clip_id = extra_info.get('clip_id', '?')
        vocab_path = kwargs.get('vocab_path', None)

        # ── Parse road data from JSON-encoded fields ──
        road_graphs     = json.loads(kwargs.get('road_graphs', '{}'))
        select_road_ids = json.loads(kwargs.get('select_road_ids', '[]'))
        select_road_cls = json.loads(kwargs.get('select_road_cls', '[]'))
        freespace_info  = json.loads(kwargs.get('freespace_info', '{}'))

        # ── Identify forbidden roads ──
        forbidden_ids = get_forbidden_road_ids(select_road_ids, select_road_cls)

        # Track action_traj and abs_traj — always parse for debug visualization
        action_traj = None
        abs_traj = None
        result = None

        # ── Always parse trajectory first (for debug pkl visualization) ──
        action_traj = parse_action_traj(solution_str, vocab_path=vocab_path)

        # ── Road geometries & class mapping ──
        all_road_geoms = get_all_road_geometries(road_graphs)
        road_id_to_cls = get_road_id_to_cls(select_road_ids, select_road_cls)
        unsafe_masks = get_unsafe_masks(freespace_info)

        if action_traj is not None:
            abs_traj = action_traj_to_abs(action_traj)

        # ── Standardised result template: all keys must be present for every sample ──
        # The NaiveRewardManager collects per-key lists from the returned dict;
        # missing keys cause length mismatches and fail the validation assert.
        _base_result = {
            "score": 0.0,
            "reason": "",
            "details": {},
            "num_points": 0,
            "required": BINDING_MIN_POINTS,
        }

        if action_traj is None:
            result = dict(_base_result, score=-4.0, reason="no_trajectory_parsed",
                          details={"reason": "no_trajectory_parsed"})
            self._last_details = {'reason': 'no_trajectory_parsed'}
        elif not all_road_geoms and not unsafe_masks:
            # nothing to check against
            result = dict(_base_result, reason="no_road_geometries",
                          details={"reason": "no_road_geometries"})
            self._last_details = {'reason': 'no_road_geometries'}
        else:
            num_points = len(abs_traj) if abs_traj is not None else 0
            if num_points < BINDING_MIN_POINTS:
                penalty = 3.0
                result = dict(_base_result,
                              score=round(-penalty, 4),
                              reason="trajectory_too_short",
                              num_points=num_points,
                              required=BINDING_MIN_POINTS,
                              details={"reason": "trajectory_too_short",
                                       "num_points": num_points})
                self._last_details = {'reason': 'trajectory_too_short',
                                      'num_points': num_points}
            elif not forbidden_ids:
                # ── No forbidden roads → only check wall crash ──
                if unsafe_masks:
                    is_crash, crash_details = check_traj_crash_into_wall(
                        abs_traj, unsafe_masks, min_points=BINDING_MIN_POINTS)
                    if is_crash:
                        penalty = min(crash_details.get('num_unsafe', 1), BINDING_MIN_POINTS) * WALL_PENALTY
                        result = dict(_base_result, score=round(-penalty, 4),
                                      reason="crash_into_wall", details=crash_details)
                        self._last_details = crash_details
                    else:
                        result = dict(_base_result, reason="no_forbidden_roads",
                                      details={"reason": "no_forbidden_roads"})
                        self._last_details = {'reason': 'no_forbidden_roads'}
                else:
                    result = dict(_base_result, reason="no_forbidden_roads",
                                  details={"reason": "no_forbidden_roads"})
                    self._last_details = {'reason': 'no_forbidden_roads'}
            else:
                # ── Has forbidden roads → full violation check ──
                is_violation, details = check_traj_violation_by_binding(
                    abs_traj, all_road_geoms, road_id_to_cls, forbidden_ids,
                    unsafe_masks=unsafe_masks,
                )

                if not is_violation:
                    result = dict(_base_result, reason="correct", details=details)
                    self._last_details = {'reason': 'correct'}
                else:
                    reason = details.get('reason', 'unknown')
                    score = 0.0
                    if reason == 'segment_binds_to_forbidden_road':
                        score -= FORBIDDEN_PENALTY
                    elif reason == 'crash_into_wall':
                        score -= min(details.get('num_unsafe', 1), BINDING_MIN_POINTS) * WALL_PENALTY
                    result = dict(_base_result, score=round(score, 4),
                                  reason=reason, details=details)
                    self._last_details = details

        # ── Build GDPO diff_score vector (list) + per-dim scalars (for wandb) ──
        diff_list, dim_dict = self._build_diff_score(result)
        result['diff_score'] = diff_list
        result.update(dim_dict)  # diff_traj_valid, diff_forbidden, diff_wall

        # ── Build comprehensive debug data for pkl (only in debug mode) ──
        if self._debug:
            # Convert abs_traj to list for pickling
            abs_traj_list = abs_traj.tolist() if abs_traj is not None else None

            # Collect road geometries as lists (numpy → list for picklable)
            all_road_geoms_serializable = {}
            _geoms = get_all_road_geometries(road_graphs)
            for rid, g in _geoms.items():
                all_road_geoms_serializable[rid] = g.tolist()
            _road_id_to_cls = get_road_id_to_cls(select_road_ids, select_road_cls)

            # Collect unsafe mask metadata (not the full decoded mask, which is huge)
            unsafe_info = {}
            unsafe_rle = freespace_info.get('unsafe') if freespace_info else None
            if unsafe_rle:
                unsafe_info['rle_size'] = unsafe_rle.get('size')
                unsafe_info['rle_counts_len'] = len(unsafe_rle.get('counts', '')) if isinstance(unsafe_rle.get('counts', ''), str) else len(unsafe_rle.get('counts', b''))
                # Also save decoded mask shape if available
                unsafe_masks_list = get_unsafe_masks(freespace_info) if freespace_info else []
                unsafe_info['num_masks'] = len(unsafe_masks_list)
                if unsafe_masks_list:
                    unsafe_info['mask_shape'] = list(unsafe_masks_list[0].shape)

            debug_data = {
                'clip_id': clip_id,
                'data_source': data_source,
                'step': self._step,
                'solution_str': solution_str,
                'action_traj': action_traj,
                'abs_traj': abs_traj_list,
                'diff_score': result.get('diff_score', []),
                'forbidden_ids': forbidden_ids,
                'select_road_ids': select_road_ids,
                'select_road_cls': select_road_cls,
                'road_id_to_cls': _road_id_to_cls,
                'all_road_geoms': all_road_geoms_serializable,
                'freespace_info': freespace_info,  # raw RLE data for freespace decoding
                'unsafe_info': unsafe_info,
                'vocab_path': vocab_path,
                'result': result,
            }
            self._log_model_output(solution_str, action_traj, abs_traj, result, debug_data)

        # Include minimal debug info in return so trainer logs it in reward_extra_infos_dict
        result['debug'] = {
            'clip_id': clip_id,
            'data_source': data_source,
            'forbidden_ids': forbidden_ids,
            'score': result['score'],
            'reason': result['reason'],
            'diff_score': result.get('diff_score', []),
        }

        return result

    @staticmethod
    def _build_diff_score(result):
        """Build 3-dim diff_score vector for GDPO from result dict.

        Dimensions:
          0. trajectory_validity_score : -4.0 (no parse) / -3.0 (too short) / 0.0 (ok)
          1. forbidden_road_score      : -2.5 (entered forbidden) / 0.0 (safe / N/A)
          2. wall_crash_score          : -N*1.0 (crashed) / 0.0 (safe / N/A)

        Sum of diff_score always equals result["score"] (GRPO scalar).
        N/A dimensions default to 0.0.

        Returns (diff_list, dim_dict) where:
          - diff_list: [traj_valid, forbidden, wall] for GDPO
          - dim_dict:  {"diff_traj_valid": ..., "diff_forbidden": ..., "diff_wall": ...}
                       individual scalars for wandb per-dimension visualization
        """
        reason = result.get('reason', 'unknown')
        details = result.get('details', {})
        score = result.get('score', 0.0)

        # Dimension 0: trajectory validity
        if reason == 'no_trajectory_parsed':
            traj_valid = -4.0
        elif reason == 'trajectory_too_short':
            traj_valid = -3.0
        else:
            traj_valid = 0.0

        # Dimension 1: forbidden road avoidance
        if reason == 'segment_binds_to_forbidden_road':
            forbidden = -FORBIDDEN_PENALTY  # -2.5
        elif reason in ('no_forbidden_roads', 'correct', 'no_trajectory_parsed',
                         'trajectory_too_short', 'no_road_geometries', 'no_violation'):
            forbidden = 0.0
        else:
            forbidden = 0.0  # crash_into_wall → forbidden was OK, or N/A

        # Dimension 2: wall safety
        if reason == 'crash_into_wall':
            n = details.get('num_unsafe', 0)
            wall = -min(n, BINDING_MIN_POINTS) * WALL_PENALTY
        elif reason in ('no_trajectory_parsed', 'trajectory_too_short', 'no_road_geometries'):
            wall = 0.0  # N/A
        else:
            wall = 0.0

        diff_list = [traj_valid, forbidden, wall]
        dim_dict = {
            'diff_traj_valid': traj_valid,
            'diff_forbidden': forbidden,
            'diff_wall': wall,
        }

        # Sanity check
        if abs(sum(diff_list) - score) > 0.01:
            logger.warning(
                f"diff_score sum ({sum(diff_list)}) != total score ({score}); "
                f"reason={reason}, diff={diff_list}"
            )

        return diff_list, dim_dict

    @property
    def last_details(self):
        return self._last_details


# ═══════════════════════════════════════════════════════════════════════════════
#  Top-level function (verl-compatible entry point)
# ═══════════════════════════════════════════════════════════════════════════════

# Module-level singleton so _step counter persists across calls
_scorer = None
_scorer_debug = None

def vla_no_entry_reward(data_source, solution_str, ground_truth, extra_info,
                        debug=True, reward_version=None, iou_threshold=None, debug_dir=None, **kwargs):
    """Top-level reward function for verl registration.

    Args:
        debug: enable debug logging and pkl dump
        debug_dir: directory for debug pkl files (also settable via VLA_DEBUG_DIR env var)
    """
    global _scorer, _scorer_debug
    if _scorer is None or _scorer_debug != debug:
        _scorer = TaskVLANoEntryReward(debug=debug, debug_dir=debug_dir)
        _scorer_debug = debug
    return _scorer(data_source, solution_str, ground_truth, extra_info)

# ═══════════════════════════════════════════════════════════════════════════════
#  __main__ — quick test
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import pandas as pd

    PARQUET_PATH = "/perception-hl/beijin.zhou/deeprl/v1_data/vla_train_out_no_entry_260526_train__df5f809__20260528070111_part2_part0003.parquet"
    NUM_SAMPLES = 3

    print(f"Loading parquet: {PARQUET_PATH}")
    df = pd.read_parquet(PARQUET_PATH)
    print(f"  {len(df)} samples\n")

    scorer = TaskVLANoEntryReward(debug=True, debug_dir='/tmp/vla_reward_debug')

    for i in range(min(NUM_SAMPLES, len(df))):
        row = df.iloc[i]
        extra_info = row['extra_info']

        # Inspect what forbidden roads exist in this sample
        kwargs = extra_info['tools_kwargs']['calc_no-entry_reward']['calc_reward_kwargs']
        select_road_ids = json.loads(kwargs['select_road_ids'])
        select_road_cls = json.loads(kwargs['select_road_cls'])
        forbidden_ids = get_forbidden_road_ids(select_road_ids, select_road_cls)

        print(f"{'='*60}")
        print(f"Sample {i}  clip_id={extra_info['clip_id']}")
        print(f"  select_road_ids: {select_road_ids}")
        print(f"  select_road_cls: {select_road_cls}")
        print(f"  forbidden_ids:   {forbidden_ids}")
        print(f"  has_unsafe_mask:  {bool(json.loads(kwargs['freespace_info']).get('unsafe'))}")

        if not forbidden_ids:
            print("  → No forbidden roads, skip trajectory tests")
            continue

        # ── Test with synthesised trajectories ──
        # Trajectory format: normalized coords (0-1000), 5 points
        test_trajs = [
            ("直行", "<action>(500,500),(600,500),(700,500),(800,500),(900,500)</action>"),
            ("右转", "<action>(500,500),(550,450),(650,350),(750,250),(850,150)</action>"),
            ("左转", "<action>(500,500),(450,550),(350,650),(250,750),(150,850)</action>"),
            ("掉头", "<action>(500,500),(490,400),(500,300),(510,200),(500,100)</action>"),
        ]

        for label, traj_str in test_trajs:
            result = scorer("no-entry_v1", traj_str, [], extra_info)
            score = result['score']
            reason = result.get('reason', '?')
            diff = result.get('diff_score', [])
            detail = result.get('details', {})
            road_id = detail.get('road_id', '-')
            road_cls = detail.get('road_cls', '-')
            print(f"  {label:4s} → score={score:6.2f}  diff={diff}  "
                  f"reason={reason:35s}  road={road_id}  cls={road_cls}")

    print(f"\n{'='*60}")
    print("Done.")
