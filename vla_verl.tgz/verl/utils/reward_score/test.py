import re
def cot_format_reward(predict_lower,solution_str):

    count = 0.0
    # - 要有<think></think>且有<answer></answer>,+1
    if '<think>' in predict_lower and '</think>' in predict_lower and '<answer>' in predict_lower and '</answer>' in predict_lower:
        count += 1.0

    # - 在<think></think>内 要有step x 且 x为递增的顺序 ,+1
    flag = True
    think_steps = re.search(r'<think>(.*?)</think>',pred,re.DOTALL)
    if think_steps:
        think_steps = think_steps.group(1)
        steps = re.findall(r'(?i)\bStep\b\s*[:._-]*\s*(\d+)',think_steps,re.DOTALL)
        print(steps)
        if len(steps) == 0:
            flag = False
        elif len(steps) > 1:
            for i in range(len(steps)-1):
                if steps[i] >= steps[i+1]:
                    flag = False
                    break
    if flag:
        count += 1.0

    # - <answer></answer>内要有回答,且回答的长度0< <GT+10,+1
    pred_ans = re.search(r'<answer>(.*?)</answer>',pred,re.DOTALL)
    if pred_ans:
        if 0 < len(pred_ans.group(1)) <= len(solution_str) + 20:
            count += 1.0





pred = """<think>

# Step 1: Identify the region described by "left tan sleeve" in the image. This refers to the person on the far left, wearing a tan sleeve.

# Step 2: Determine the bounding box coordinates for this region. The coordinates should encompass the person with the tan sleeve.


#Step 3: Now align the answer with the format of the question, and the final answer is <ref>left tan sleeve</ref>: <box>0,270,100,987</box></think>

<answer><ref>left tan sleeve</ref>: <box>0,270,100,987</box></answer>
"""

gt = "<answer><ref>left tan sleeve</ref>: <box>0,270,100,987</box></answer>"

cot_format_reward(pred,gt)


