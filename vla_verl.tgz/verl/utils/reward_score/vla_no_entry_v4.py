"""
VLA No-Entry Reward v4 — v3 + exit-direction bonus near intersections.

基于 vla_no_entry_v3.py，增加出口方向判断和加分：
  - 如果距离交叉点 < 12m 且当前帧存在出口标识（has_exit_sign）
  - 判断模型预测轨迹是否沿着出口方向
  - 出口方向由 vla_goal_point 决定，通过 find_best_lane_for_goal
    找到 goal point 绑定的最佳路网（出口路），然后检查轨迹是否与之同向
  - 如果沿着出口方向 → +2.0 加分

出口方向判断逻辑（基于路网绑定）：
  1. 使用 find_best_lane_for_goal 将 vla_goal_point 绑定到最佳路网（出口路）
  2. 将预测轨迹 prepend origin (0,0)，逐段 bind_segment_to_road
  3. 如果任一段轨迹绑定到与 goal point 相同的道路上 → 沿着出口方向

Scoring rules (v3 base + v4 exit bonus in ALL cases when dist<12m & has_exit_sign):
    ───────────────────────────────────────────────────────────────────────────
    场景                                              score       reason
    ───────────────────────────────────────────────────────────────────────────
    无禁行路 + 沿出口                                  +2.0        no_forbidden_roads
    无禁行路 + 不沿出口                                 0.0         no_forbidden_roads
    无法解析轨迹                                        -4.0        no_trajectory_parsed
    轨迹过短 + 沿出口                                  -1.0        trajectory_too_short
    轨迹过短 + 不沿出口                                -3.0        trajectory_too_short
    正确 + 沿出口                                      +2.0        correct
    正确 + 不沿出口                                     0.0         correct
    进入禁行路 (dist < 6m,  沿出口)                    -2.0        segment_binds_to_forbidden_road
    进入禁行路 (dist < 6m,  不沿出口)                  -4.0        segment_binds_to_forbidden_road
    进入禁行路 (dist < 12m, 沿出口)                    -1.0        segment_binds_to_forbidden_road
    进入禁行路 (dist < 12m, 不沿出口)                  -3.0        segment_binds_to_forbidden_road
    进入禁行路 (dist >= 12m)                           -2.0        segment_binds_to_forbidden_road
    撞墙 + 沿出口                                      -(N-2)      crash_into_wall
    撞墙 + 不沿出口                                    -N×1.0     crash_into_wall
    ───────────────────────────────────────────────────────────────────────────

GDPO diff_score decomposition (3 fixed dimensions, sum = total score):
    diff_score = [
        trajectory_validity_score,
        forbidden_road_score,      # -4.0/-3.0/-2.0 + exit_bonus / 0.0
        wall_crash_score,
    ]
"""

import json
import logging
import os
import pickle
import random
import re
from typing import Optional

import numpy as np

logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════════════
#  Constants
# ═══════════════════════════════════════════════════════════════════════════════

FORBIDDEN_ROAD_CLASSES = {'noEntryRoad', 'noEntryRoadBarrier', 'ArriveDeadEndRoad', 'onlyRetrograde'}

BINDING_W_DIST   = 0.5
BINDING_W_ANGLE  = 0.5
BINDING_MAX_DIST = 5.0
BINDING_MIN_POINTS = 5

WALL_PENALTY      = 1.0

# ── Intersection-distance-based forbidden road penalties (v3) ──
FORBIDDEN_PENALTY_NEAR   = 4.0   # dist < 6m
FORBIDDEN_PENALTY_MEDIUM = 3.0   # dist < 12m
FORBIDDEN_PENALTY_FAR    = 2.0   # dist >= 12m

# ── Intersection distance thresholds ──
INTERSECTION_NEAR_6M   = 6.0
INTERSECTION_NEAR_12M  = 12.0
INTERSECTION_ENDPOINT_DIST_THRESHOLD = 2.0
INTERSECTION_MIN_CONNECTED_ROADS = 2

# ── Exit direction bonus (v4 new) ──
EXIT_DIRECTION_BONUS = 2.0
GOAL_LANE_W_DIST  = 0.3                 # weight for distance in goal→lane binding
GOAL_LANE_W_ANGLE = 0.7                 # weight for angle in goal→lane binding

COORD_NORM_MIN, COORD_NORM_MAX = 0, 1000
COORD_PHYS_MIN, COORD_PHYS_MAX = -30.0, 30.0

ACTION_POINTS_RE = re.compile(r"\((\d+),(\d+)\)")
ACTION_TOKEN_RE  = re.compile(r"<action_(\d+)>")

_DEFAULT_VOCAB_PATH = "/perception-hl/longan.yang/vla_data/vlm_path/train_dataset/vocab/0804_all/tokens_512_v1.npy"
_VOCABULARY = None
_VOCAB_PATH_USED = None


def get_vocabulary(vocab_path=None):
    global _VOCABULARY, _VOCAB_PATH_USED
    path = vocab_path or os.environ.get('VLA_VOCAB_PATH') or _DEFAULT_VOCAB_PATH
    if _VOCABULARY is not None and _VOCAB_PATH_USED == path:
        return _VOCABULARY
    if os.path.exists(path):
        _VOCABULARY = np.load(path)
        _VOCAB_PATH_USED = path
    else:
        logger.warning(f"VLA vocab path not found: {path}")
        _VOCABULARY = np.array([])
        _VOCAB_PATH_USED = path
    return _VOCABULARY

# ═══════════════════════════════════════════════════════════════════════════════
#  Trajectory parsing
# ═══════════════════════════════════════════════════════════════════════════════

def parse_action_traj(prediction_text: str, vocab_path=None):
    if not prediction_text:
        return None
    action_match = re.search(r"<action>(.*?)</action>", prediction_text, re.DOTALL)
    if not action_match:
        return None
    content = action_match.group(1)
    points = ACTION_POINTS_RE.findall(content)
    if points:
        return [[int(x), int(y)] for x, y in points]
    token_matches = ACTION_TOKEN_RE.findall(content)
    if not token_matches:
        return None
    vocabulary = get_vocabulary(vocab_path)
    if vocabulary is None or vocabulary.size == 0:
        return None
    vocab_indices = [int(m) for m in token_matches]
    x, y, theta = 0.0, 0.0, 0.0
    xs, ys = [], []
    for idx in vocab_indices:
        if idx == 0:
            xs.append(x); ys.append(y)
            continue
        vocab_row = idx - 1
        if vocab_row < 0 or vocab_row >= vocabulary.shape[0]:
            continue
        dx, dy, dheading = vocabulary[vocab_row]
        cos_t, sin_t = np.cos(theta), np.sin(theta)
        x = float(x + dx * cos_t - dy * sin_t)
        y = float(y + dx * sin_t + dy * cos_t)
        theta = float(np.arctan2(np.sin(theta + dheading), np.cos(theta + dheading)))
        xs.append(x); ys.append(y)
    if not xs:
        return None
    return [[x, y] for x, y in zip(xs, ys)]


def norm_to_abs_traj(norm_traj):
    if norm_traj is None or len(norm_traj) == 0:
        return None
    scale = (COORD_PHYS_MAX - COORD_PHYS_MIN) / (COORD_NORM_MAX - COORD_NORM_MIN)
    return np.array([[COORD_PHYS_MIN + x * scale, COORD_PHYS_MIN + y * scale]
                     for x, y in norm_traj], dtype=float)


def action_traj_to_abs(action_traj):
    if action_traj is None or len(action_traj) == 0:
        return None
    if isinstance(action_traj[0][0], int):
        return norm_to_abs_traj(action_traj)
    return np.array(action_traj, dtype=float)

# ═══════════════════════════════════════════════════════════════════════════════
#  Road data helpers
# ═══════════════════════════════════════════════════════════════════════════════

def get_forbidden_road_ids(select_road_ids, select_road_cls):
    forbidden = set()
    for rid, cls in zip(select_road_ids, select_road_cls):
        if cls in FORBIDDEN_ROAD_CLASSES:
            forbidden.add(rid)
    return forbidden


def get_all_road_geometries(road_graphs):
    geometries = {}
    for road_id, info in road_graphs.items():
        if info and 'geometry' in info:
            geom = np.array(info['geometry'], dtype=float)
            if len(geom) >= 2:
                geometries[road_id] = geom
    return geometries


def get_road_id_to_cls(select_road_ids, select_road_cls):
    return dict(zip(select_road_ids, select_road_cls))

# ═══════════════════════════════════════════════════════════════════════════════
#  Geometry helpers (segment → road binding)
# ═══════════════════════════════════════════════════════════════════════════════

def _min_distance_point_to_polyline(point, polyline):
    point = np.asarray(point, dtype=float)
    min_dist = float('inf')
    closest_pt = None
    for i in range(len(polyline) - 1):
        a, b = polyline[i], polyline[i + 1]
        ab = b - a
        ab_len_sq = np.dot(ab, ab)
        if ab_len_sq < 1e-12:
            dist = np.linalg.norm(point - a)
            if dist < min_dist:
                min_dist, closest_pt = dist, a.copy()
            continue
        t = max(0.0, min(1.0, np.dot(point - a, ab) / ab_len_sq))
        closest = a + t * ab
        dist = np.linalg.norm(point - closest)
        if dist < min_dist:
            min_dist, closest_pt = dist, closest.copy()
    return min_dist, closest_pt


def _road_direction_at_point(polyline, closest_point):
    min_seg_dist = float('inf')
    best_dir = None
    for i in range(len(polyline) - 1):
        a, b = polyline[i], polyline[i + 1]
        mid = (a + b) / 2.0
        d = np.linalg.norm(closest_point - mid)
        if d < min_seg_dist:
            min_seg_dist = d
            seg_dir = b - a
            seg_len = np.linalg.norm(seg_dir)
            if seg_len > 1e-8:
                best_dir = seg_dir / seg_len
    return best_dir


def compute_segment_binding_score(segment, geom):
    center = np.mean(segment, axis=0)
    min_dist, closest_pt = _min_distance_point_to_polyline(center, geom)
    if min_dist > BINDING_MAX_DIST:
        return None
    seg_vec = segment[-1] - segment[0]
    seg_len = np.linalg.norm(seg_vec)
    if seg_len < 1e-6:
        return None
    seg_heading = np.arctan2(seg_vec[1], seg_vec[0])
    road_dir = _road_direction_at_point(geom, closest_pt)
    if road_dir is None:
        return None
    road_heading = np.arctan2(road_dir[1], road_dir[0])
    angle_diff = seg_heading - road_heading
    angle_diff = np.degrees(np.arctan2(np.sin(angle_diff), np.cos(angle_diff)))
    abs_angle = abs(angle_diff)
    if 60.0 < abs_angle < 120.0:
        return None
    has_both_sides = (np.any(geom[:, 1] > 0) and np.any(geom[:, 1] < 0))
    if not has_both_sides and abs_angle > 90.0:
        return None
    if len(geom) >= 2:
        global_vec = geom[-1] - geom[0]
        global_heading = np.arctan2(global_vec[1], global_vec[0])
        global_diff = seg_heading - global_heading
        global_diff = np.degrees(np.arctan2(np.sin(global_diff), np.cos(global_diff)))
        if 60.0 < abs(global_diff) < 120.0:
            return None
    norm_dist = min(min_dist / BINDING_MAX_DIST, 1.0)
    norm_angle = abs_angle / 90.0
    score = BINDING_W_DIST * norm_dist + BINDING_W_ANGLE * norm_angle
    return {
        'score': score, 'dist': float(min_dist),
        'angle_deg': float(angle_diff), 'closest_pt': closest_pt.tolist(),
    }


def bind_segment_to_road(segment, all_road_geoms):
    best_road_id = None
    best_score = float('inf')
    best_info = None
    for road_id, geom in all_road_geoms.items():
        result = compute_segment_binding_score(segment, geom)
        if result is None:
            continue
        if result['score'] < best_score:
            best_score = result['score']
            best_road_id = road_id
            best_info = result
    return best_road_id, best_info

# ═══════════════════════════════════════════════════════════════════════════════
#  Goal → lane binding (v4 new — ported from visualize_no_entry_jsonl.py)
# ═══════════════════════════════════════════════════════════════════════════════

def find_best_lane_for_goal(goal_point: dict, all_road_geoms: dict):
    """将 vla_goal_point 绑定到最佳匹配的道路上（出口路）。

    绑定打分 = w_d * 距离分 + w_a * 方向分  (w_d=0.3, w_a=0.7, 角度主导)
    - 距离分: 1/(1+dist), goal_point 离道路越近分越高
    - 方向分: max(0, cos(夹角)), 夹角>=75°时直接归零, 避免错误绑定
    - 道路方向: 离原点较近的端点 → 离原点较远的端点

    Args:
        goal_point: dict with point_x, point_y, yaw
        all_road_geoms: dict of road_id → (N,2) geometry

    Returns:
        (best_road_id, best_geometry, best_score, best_debug) or
        (None, None, -1, {})
    """
    if not goal_point or not all_road_geoms:
        return None, None, -1.0, {}

    px = goal_point.get('point_x', 0)
    py = goal_point.get('point_y', 0)
    yaw = goal_point.get('yaw', 0)
    goal_pos = np.array([px, py])
    goal_dir = np.array([np.cos(yaw), np.sin(yaw)])

    w_d = GOAL_LANE_W_DIST
    w_a = GOAL_LANE_W_ANGLE

    best_score = -1.0
    best_road_id = None
    best_geometry = None
    best_debug = {}

    for road_id, geometry in all_road_geoms.items():
        if len(geometry) < 2:
            continue

        road_best_score = -1.0
        road_best_debug = {}
        for i in range(len(geometry) - 1):
            p1 = geometry[i]
            p2 = geometry[i + 1]

            # 道路方向：离原点较近 → 离原点较远
            d1 = np.linalg.norm(p1)
            d2 = np.linalg.norm(p2)
            lane_dir = (p2 - p1) if d1 <= d2 else (p1 - p2)
            lane_dir_norm = np.linalg.norm(lane_dir)
            if lane_dir_norm < 1e-6:
                continue
            lane_dir = lane_dir / lane_dir_norm

            # goal_point 到线段的最短距离
            v = p2 - p1
            w = goal_pos - p1
            v_dot_v = np.dot(v, v)
            if v_dot_v < 1e-6:
                dist = np.linalg.norm(goal_pos - p1)
            else:
                t = np.clip(np.dot(w, v) / v_dot_v, 0.0, 1.0)
                projection = p1 + t * v
                dist = np.linalg.norm(goal_pos - projection)

            cos_angle = np.dot(goal_dir, lane_dir)
            angle_deg = np.degrees(np.arccos(np.clip(cos_angle, -1.0, 1.0)))
            # 夹角 > 75° 的路段直接排除
            if cos_angle < 0.2588:  # cos(75°) ≈ 0.2588
                continue

            dist_score = 1.0 / (1.0 + dist)
            angle_score = max(0.0, cos_angle)
            score = w_d * dist_score + w_a * angle_score

            if score > road_best_score:
                road_best_score = score
                road_best_debug = {
                    'seg_idx': i,
                    'dist': round(dist, 2),
                    'angle_deg': round(angle_deg, 1),
                    'dist_score': round(dist_score, 3),
                    'angle_score': round(angle_score, 3),
                    'score': round(score, 3),
                }

        if road_best_score > best_score:
            best_score = road_best_score
            best_road_id = road_id
            best_geometry = geometry
            best_debug = road_best_debug

    return best_road_id, best_geometry, best_score, best_debug


def check_trajectory_follows_exit_direction(
    abs_traj,
    all_road_geoms,
    vla_goal_point,
    has_exit_sign,
    intersection_distance,
):
    """检查预测轨迹是否沿着出口方向（绑定到与 goal point 相同的出口路）。

    仅在以下条件同时满足时检查：
      1. 距离交叉点 < 12m
      2. 当前帧存在出口标识（has_exit_sign = True）
      3. vla_goal_point 有效

    出口方向判断（基于路网绑定）：
      1. 使用 find_best_lane_for_goal 找到 goal point 绑定的最佳路网（出口路）
      2. 将轨迹 prepend origin (0,0) 后，逐段 bind_segment_to_road
      3. 如果任一段轨迹绑定到与 goal point 相同的道路上 → 沿着出口方向

    Returns:
        (follows_exit: bool, exit_bonus: float, details: dict)
    """
    if intersection_distance is None or intersection_distance >= INTERSECTION_NEAR_12M:
        return False, 0.0, {'reason': 'not_near_intersection',
                            'distance': intersection_distance}

    if not has_exit_sign:
        return False, 0.0, {'reason': 'no_exit_sign'}

    if not vla_goal_point or not vla_goal_point.get('point_x') or not vla_goal_point.get('yaw'):
        return False, 0.0, {'reason': 'no_goal_point'}

    if abs_traj is None or len(abs_traj) < BINDING_MIN_POINTS:
        return False, 0.0, {'reason': 'trajectory_too_short_for_exit_check',
                            'num_points': len(abs_traj) if abs_traj is not None else 0}

    if not all_road_geoms:
        return False, 0.0, {'reason': 'no_road_geoms'}

    # ── 1. 找到 goal point 绑定的出口路 ──
    exit_road_id, exit_geometry, exit_score, exit_debug = find_best_lane_for_goal(
        vla_goal_point, all_road_geoms)

    if exit_road_id is None or exit_geometry is None:
        return False, 0.0, {'reason': 'goal_not_bound_to_any_road',
                            'goal_point': vla_goal_point}

    # ── 2. 检查轨迹是否绑定到同一个出口路上 ──
    # 使用与 check_traj_violation_by_binding 相同的轨迹构造方式
    origin = np.array([[0.0, 0.0]])
    full_traj = np.vstack([origin, abs_traj[:BINDING_MIN_POINTS]])

    segment_bindings = []
    for i in range(len(full_traj) - 2):
        segment = full_traj[i:i + 3]
        bound_road_id, binding_info = bind_segment_to_road(segment, all_road_geoms)
        segment_bindings.append({
            'segment_idx': i,
            'bound_road_id': bound_road_id,
            'binding_info': binding_info,
        })
        if bound_road_id == exit_road_id:
            follows_exit = True
            exit_bonus = EXIT_DIRECTION_BONUS
            return follows_exit, exit_bonus, {
                'reason': 'follows_exit',
                'exit_road_id': exit_road_id,
                'matched_segment_idx': i,
                'binding_info': binding_info,
                'exit_score': round(exit_score, 3),
                'exit_debug': exit_debug,
                'intersection_distance': intersection_distance,
                'has_exit_sign': has_exit_sign,
            }

    # No segment bound to exit road
    return False, 0.0, {
        'reason': 'trajectory_not_bound_to_exit_road',
        'exit_road_id': exit_road_id,
        'exit_score': round(exit_score, 3),
        'exit_debug': exit_debug,
        'segment_bindings': segment_bindings,
        'intersection_distance': intersection_distance,
        'has_exit_sign': has_exit_sign,
    }

# ═══════════════════════════════════════════════════════════════════════════════
#  Intersection detection (from v3)
# ═══════════════════════════════════════════════════════════════════════════════

def find_nearest_road_to_point(point, all_road_geoms):
    best_road_id = None
    best_dist = float('inf')
    best_pt = None
    point_arr = np.asarray(point, dtype=float)
    for road_id, geom in all_road_geoms.items():
        d, pt = _min_distance_point_to_polyline(point_arr, geom)
        if d < best_dist:
            best_dist = d
            best_pt = pt
            best_road_id = road_id
    return best_road_id, best_dist, best_pt


def detect_intersection_distance(
    all_road_geoms,
    endpoint_dist_threshold=INTERSECTION_ENDPOINT_DIST_THRESHOLD,
    min_connected_roads=INTERSECTION_MIN_CONNECTED_ROADS,
):
    result = {
        "is_intersection": False, "distance": None,
        "num_connected_roads": 0, "origin_road_id": None,
        "intersection_point": None, "forward_endpoint": None,
        "closest_pt": None, "connected_road_ids": set(),
    }
    if len(all_road_geoms) < 2:
        return result

    origin = np.array([0.0, 0.0])
    origin_road_id, _, closest_pt = find_nearest_road_to_point(origin, all_road_geoms)
    if origin_road_id is None:
        return result

    result["origin_road_id"] = origin_road_id
    result["closest_pt"] = closest_pt
    origin_geom = all_road_geoms[origin_road_id]

    car_heading = np.array([1.0, 0.0])
    endpoints = [origin_geom[0], origin_geom[-1]]
    forward_endpoint = None

    for ep in endpoints:
        road_dir = ep - closest_pt
        road_dir_norm = np.linalg.norm(road_dir)
        if road_dir_norm < 1e-6:
            continue
        if np.dot(road_dir / road_dir_norm, car_heading) > 0:
            forward_endpoint = ep
            break

    if forward_endpoint is None:
        forward_endpoint = origin_geom[0] if origin_geom[0][0] > origin_geom[-1][0] else origin_geom[-1]

    connected_road_ids = set()
    for rid, geom in all_road_geoms.items():
        if rid == origin_road_id:
            continue
        for ep in [geom[0], geom[-1]]:
            if np.linalg.norm(ep - forward_endpoint) <= endpoint_dist_threshold:
                connected_road_ids.add(rid)
                break

    result["num_connected_roads"] = len(connected_road_ids)
    result["forward_endpoint"] = forward_endpoint
    result["connected_road_ids"] = connected_road_ids

    if len(connected_road_ids) < min_connected_roads:
        return result

    result["is_intersection"] = True
    result["intersection_point"] = forward_endpoint
    result["distance"] = float(np.linalg.norm(forward_endpoint - origin))
    return result


def get_intersection_penalty(intersection_distance: Optional[float]) -> float:
    """根据到交叉点的距离返回固定禁行路扣分值。"""
    if intersection_distance is None:
        return FORBIDDEN_PENALTY_FAR
    if intersection_distance < INTERSECTION_NEAR_6M:
        return FORBIDDEN_PENALTY_NEAR
    elif intersection_distance < INTERSECTION_NEAR_12M:
        return FORBIDDEN_PENALTY_MEDIUM
    return FORBIDDEN_PENALTY_FAR

# ═══════════════════════════════════════════════════════════════════════════════
#  Unsafe-mask / wall-crash helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _decode_rle_mask(rle):
    if not rle or 'counts' not in rle or 'size' not in rle:
        return None
    try:
        from pycocotools import mask as coco_mask
        counts = rle['counts']
        if isinstance(counts, str):
            counts = counts.encode('utf-8')
        return coco_mask.decode({'size': rle['size'], 'counts': counts}).astype(np.uint8)
    except ImportError:
        pass
    try:
        h, w = rle['size']
        counts = rle['counts']
        if isinstance(counts, str):
            counts = counts.encode('utf-8')
        mask = np.zeros(h * w, dtype=np.uint8)
        counts_list = list(counts)
        pos, val = 0, 0
        i = 0
        while i < len(counts_list):
            x, k = 0, 0
            more = True
            while more:
                c = counts_list[i] - 48
                x |= (c & 0x1f) << (5 * k)
                more = c & 0x20
                i += 1; k += 1
                if not more and (c & 0x10):
                    x |= -1 << (5 * k)
            for _ in range(x):
                if pos < len(mask):
                    mask[pos] = val; pos += 1
            val = 1 - val
        return mask.reshape((h, w), order='F')
    except Exception:
        return None


def bev_to_mask_coords(x_m, y_m, mask_size=600):
    scale = 60.0 / mask_size
    offset = 30.0
    row = int(round((offset - x_m) / scale))
    col = int(round((-y_m + offset) / scale))
    if 0 <= row < mask_size and 0 <= col < mask_size:
        return (row, col)
    return None


def get_unsafe_masks(freespace_info):
    if not freespace_info:
        return []
    unsafe_rle = freespace_info.get('unsafe')
    if not unsafe_rle:
        return []
    mask = _decode_rle_mask(unsafe_rle)
    return [mask] if mask is not None else []


def check_traj_crash_into_wall(abs_traj, unsafe_masks, min_points=BINDING_MIN_POINTS):
    if abs_traj is None or len(abs_traj) < min_points:
        return False, {'reason': 'no_crash'}
    if not unsafe_masks:
        return False, {'reason': 'no_crash'}
    traj_points = abs_traj[:min_points]
    unsafe_indices = []
    for idx, pt in enumerate(traj_points):
        for mask in unsafe_masks:
            h, w = mask.shape
            pixel = bev_to_mask_coords(float(pt[0]), float(pt[1]), mask_size=h)
            if pixel is not None:
                r, c = pixel
                if mask[r, c] == 1:
                    unsafe_indices.append(idx)
                    break
    num_unsafe = len(unsafe_indices)
    if num_unsafe >= 2:
        return True, {'reason': 'crash_into_wall', 'unsafe_points': unsafe_indices,
                      'num_unsafe': num_unsafe}
    return False, {'reason': 'no_crash'}

# ═══════════════════════════════════════════════════════════════════════════════
#  Core: segment-binding violation check
# ═══════════════════════════════════════════════════════════════════════════════

def check_traj_violation_by_binding(
    abs_traj, all_road_geoms, road_id_to_cls, forbidden_ids,
    unsafe_masks=None, min_points=BINDING_MIN_POINTS,
):
    if abs_traj is None or len(abs_traj) < min_points:
        return True, {'reason': 'trajectory_too_short',
                      'num_points': len(abs_traj) if abs_traj is not None else 0}
    origin = np.array([[0.0, 0.0]])
    full_traj = np.vstack([origin, abs_traj[:min_points]])
    for i in range(len(full_traj) - 2):
        segment = full_traj[i:i + 3]
        road_id, info = bind_segment_to_road(segment, all_road_geoms)
        if road_id is not None and road_id in forbidden_ids:
            return True, {
                'reason': 'segment_binds_to_forbidden_road',
                'segment_idx': i, 'road_id': road_id,
                'road_cls': road_id_to_cls.get(road_id, 'unknown'),
                'binding_info': info,
            }
    if unsafe_masks:
        is_crash, crash_details = check_traj_crash_into_wall(abs_traj, unsafe_masks, min_points)
        if is_crash:
            return True, crash_details
    return False, {'reason': 'no_violation'}

# ═══════════════════════════════════════════════════════════════════════════════
#  Reward interface
# ═══════════════════════════════════════════════════════════════════════════════

class TaskVLANoEntryReward:
    """VLA no-entry reward v4: intersection-weighted penalty + exit-direction bonus."""

    def __init__(self, debug=False, debug_dir="/tmp/vla_reward_test"):
        self._last_details = {}
        self._debug = debug
        self._step = 0
        self._debug_first_n = 200
        self._debug_log_every = 20
        self._debug_dir = debug_dir or os.environ.get('VLA_DEBUG_DIR') or '/tmp/vla_reward_debug'

    def __call__(self, data_source, solution_str, ground_truth, extra_info):
        self._step += 1
        return self.compute_score(data_source, solution_str, ground_truth, extra_info)

    def _dbg(self, msg):
        if self._debug:
            with open("/tmp/vla_reward_debug.log", "a") as f:
                f.write(msg + "\n")

    def _extract_kwargs(self, extra_info):
        tools_kwargs = extra_info.get('tools_kwargs', {})
        reward_cfg = tools_kwargs.get('calc_no-entry_reward', {})
        return reward_cfg.get('calc_reward_kwargs', {})

    def compute_score(self, data_source, solution_str, ground_truth, extra_info):
        kwargs = self._extract_kwargs(extra_info)
        clip_id = extra_info.get('clip_id', '?')
        vocab_path = kwargs.get('vocab_path', None)

        # ── Parse road data ──
        road_graphs     = json.loads(kwargs.get('road_graphs', '{}'))
        select_road_ids = json.loads(kwargs.get('select_road_ids', '[]'))
        select_road_cls = json.loads(kwargs.get('select_road_cls', '[]'))
        freespace_info  = json.loads(kwargs.get('freespace_info', '{}'))

        # ── v4 new fields ──
        vla_goal_point = json.loads(kwargs.get('vla_goal_point', '{}'))
        has_exit_sign  = json.loads(kwargs.get('has_exit_sign', 'false'))

        # ── Identify forbidden roads ──
        forbidden_ids = get_forbidden_road_ids(select_road_ids, select_road_cls)

        action_traj = None
        abs_traj = None

        action_traj = parse_action_traj(solution_str, vocab_path=vocab_path)

        all_road_geoms = get_all_road_geometries(road_graphs)
        road_id_to_cls = get_road_id_to_cls(select_road_ids, select_road_cls)
        unsafe_masks = get_unsafe_masks(freespace_info)

        # ── Intersection detection (v3) ──
        intersection_info = detect_intersection_distance(all_road_geoms)
        intersection_distance = intersection_info.get("distance")
        forbidden_penalty = get_intersection_penalty(intersection_distance)

        if action_traj is not None:
            abs_traj = action_traj_to_abs(action_traj)

        # ── v4: Exit direction check ──
        exit_bonus = 0.0
        follows_exit = False
        exit_details = {}

        if abs_traj is not None and len(abs_traj) >= 2:
            follows_exit, exit_bonus, exit_details = check_trajectory_follows_exit_direction(
                abs_traj, all_road_geoms, vla_goal_point, has_exit_sign,
                intersection_distance,
            )

        _base_result = {
            "score": 0.0, "reason": "", "details": {},
            "num_points": 0, "required": BINDING_MIN_POINTS,
        }

        if action_traj is None:
            # Even with no trajectory, exit bonus could apply but we can't check direction
            result = dict(_base_result, score=-4.0 + exit_bonus,
                          reason="no_trajectory_parsed",
                          details={"reason": "no_trajectory_parsed",
                                   "exit_bonus": exit_bonus,
                                   "exit_details": exit_details})
            self._last_details = {'reason': 'no_trajectory_parsed'}
        elif not all_road_geoms and not unsafe_masks:
            result = dict(_base_result, score=exit_bonus,
                          reason="no_road_geometries",
                          details={"reason": "no_road_geometries",
                                   "exit_bonus": exit_bonus,
                                   "exit_details": exit_details})
            self._last_details = {'reason': 'no_road_geometries'}
        else:
            num_points = len(abs_traj) if abs_traj is not None else 0
            if num_points < BINDING_MIN_POINTS:
                result = dict(_base_result, score=round(-3.0 + exit_bonus, 4),
                              reason="trajectory_too_short",
                              num_points=num_points,
                              required=BINDING_MIN_POINTS,
                              details={"reason": "trajectory_too_short",
                                       "num_points": num_points,
                                       "exit_bonus": exit_bonus,
                                       "exit_details": exit_details})
                self._last_details = {'reason': 'trajectory_too_short',
                                      'num_points': num_points}
            elif not forbidden_ids:
                if unsafe_masks:
                    is_crash, crash_details = check_traj_crash_into_wall(
                        abs_traj, unsafe_masks, min_points=BINDING_MIN_POINTS)
                    if is_crash:
                        penalty = min(crash_details.get('num_unsafe', 1),
                                      BINDING_MIN_POINTS) * WALL_PENALTY
                        result = dict(_base_result, score=round(-penalty + exit_bonus, 4),
                                      reason="crash_into_wall",
                                      details={**crash_details, "exit_bonus": exit_bonus,
                                               "exit_details": exit_details})
                        self._last_details = crash_details
                    else:
                        result = dict(_base_result, score=round(exit_bonus, 4),
                                      reason="no_forbidden_roads",
                                      details={"reason": "no_forbidden_roads",
                                               "exit_bonus": exit_bonus,
                                               "exit_details": exit_details})
                        self._last_details = {'reason': 'no_forbidden_roads'}
                else:
                    result = dict(_base_result, score=round(exit_bonus, 4),
                                  reason="no_forbidden_roads",
                                  details={"reason": "no_forbidden_roads",
                                           "exit_bonus": exit_bonus,
                                           "exit_details": exit_details})
                    self._last_details = {'reason': 'no_forbidden_roads'}
            else:
                is_violation, details = check_traj_violation_by_binding(
                    abs_traj, all_road_geoms, road_id_to_cls, forbidden_ids,
                    unsafe_masks=unsafe_masks,
                )

                if not is_violation:
                    result = dict(_base_result, score=round(exit_bonus, 4),
                                  reason="correct",
                                  details={**details, "exit_bonus": exit_bonus,
                                           "exit_details": exit_details})
                    self._last_details = {'reason': 'correct'}
                else:
                    reason = details.get('reason', 'unknown')
                    score = 0.0
                    if reason == 'segment_binds_to_forbidden_road':
                        # ── v3: Apply intersection-distance-based fixed penalty ──
                        score -= forbidden_penalty
                        details['intersection_distance'] = intersection_distance
                        details['forbidden_penalty'] = forbidden_penalty
                    elif reason == 'crash_into_wall':
                        score -= min(details.get('num_unsafe', 1),
                                     BINDING_MIN_POINTS) * WALL_PENALTY

                    # ── v4: Add exit bonus ──
                    score += exit_bonus
                    details['exit_bonus'] = exit_bonus
                    details['exit_details'] = exit_details

                    result = dict(_base_result, score=round(score, 4),
                                  reason=reason, details=details)
                    self._last_details = details

        # ── Build GDPO diff_score ──
        diff_list, dim_dict = self._build_diff_score(result, forbidden_penalty, exit_bonus)
        result['diff_score'] = diff_list
        result.update(dim_dict)

        # ── Debug ──
        if self._debug:
            abs_traj_list = abs_traj.tolist() if abs_traj is not None else None
            all_road_geoms_serializable = {}
            _geoms = get_all_road_geometries(road_graphs)
            for rid, g in _geoms.items():
                all_road_geoms_serializable[rid] = g.tolist()
            _road_id_to_cls = get_road_id_to_cls(select_road_ids, select_road_cls)

            debug_data = {
                'clip_id': clip_id, 'data_source': data_source, 'step': self._step,
                'solution_str': solution_str, 'action_traj': action_traj,
                'abs_traj': abs_traj_list,
                'diff_score': result.get('diff_score', []),
                'forbidden_ids': forbidden_ids,
                'select_road_ids': select_road_ids,
                'select_road_cls': select_road_cls,
                'road_id_to_cls': _road_id_to_cls,
                'all_road_geoms': all_road_geoms_serializable,
                'freespace_info': freespace_info,
                'vocab_path': vocab_path,
                'result': result,
                # v3/v4-specific
                'intersection_distance': intersection_distance,
                'forbidden_penalty': forbidden_penalty,
                'intersection_info': {
                    k: (v.tolist() if isinstance(v, np.ndarray) else
                        list(v) if isinstance(v, set) else v)
                    for k, v in intersection_info.items()
                },
                'vla_goal_point': vla_goal_point,
                'has_exit_sign': has_exit_sign,
                'exit_bonus': exit_bonus,
                'follows_exit': follows_exit,
                'exit_details': exit_details,
            }
            self._log_model_output(solution_str, action_traj, abs_traj, result, debug_data)

        result['debug'] = {
            'clip_id': clip_id, 'data_source': data_source,
            'forbidden_ids': forbidden_ids,
            'score': result['score'], 'reason': result['reason'],
            'diff_score': result.get('diff_score', []),
            'intersection_distance': intersection_distance,
            'forbidden_penalty': forbidden_penalty,
            'has_exit_sign': has_exit_sign,
            'exit_bonus': exit_bonus,
            'follows_exit': follows_exit,
        }

        return result

    def _log_model_output(self, solution_str, action_traj, abs_traj, result, debug_data):
        if not self._debug:
            return
        score = result.get('score', '?')
        reason = result.get('reason', '?')
        diff_score = result.get('diff_score', [])
        clip_id = debug_data.get('clip_id', '?')
        if self._step <= self._debug_first_n:
            self._dbg(f"=== VLA-Reward-v4 step={self._step} FULL DUMP ===")
            self._dbg(f"  clip_id:         {clip_id}")
            self._dbg(f"  score:           {score}")
            self._dbg(f"  reason:          {reason}")
            self._dbg(f"  diff_score:      {diff_score}")
            self._dbg(f"  intersection:    dist={debug_data.get('intersection_distance')} "
                      f"penalty={debug_data.get('forbidden_penalty')}")
            self._dbg(f"  exit:            bonus={debug_data.get('exit_bonus')} "
                      f"follows={debug_data.get('follows_exit')} "
                      f"sign={debug_data.get('has_exit_sign')}")
            self._dbg(f"  vla_goal_point:  {debug_data.get('vla_goal_point')}")
            self._dbg(f"  forbidden:       {debug_data.get('forbidden_ids', set())}")
            self._dbg(f"  sol_len:         {len(solution_str)}")
            self._dbg(f"  solution_str ({len(solution_str)} chars):")
            self._dbg(f"  {repr(solution_str)}")
        elif self._step % self._debug_log_every == 0:
            self._dbg(f"VLA-Reward-v4 step={self._step} | score={score} "
                      f"reason={reason} diff={diff_score} "
                      f"inter_dist={debug_data.get('intersection_distance')} "
                      f"penalty={debug_data.get('forbidden_penalty')} "
                      f"exit_bonus={debug_data.get('exit_bonus')} "
                      f"exit_sign={debug_data.get('has_exit_sign')} "
                      f"sol_len={len(solution_str)}")

    @staticmethod
    def _build_diff_score(result, forbidden_penalty=FORBIDDEN_PENALTY_FAR, exit_bonus=0.0):
        reason = result.get('reason', 'unknown')
        details = result.get('details', {})
        score = result.get('score', 0.0)

        if reason == 'no_trajectory_parsed':
            traj_valid = -4.0
        elif reason == 'trajectory_too_short':
            traj_valid = -3.0
        else:
            traj_valid = 0.0

        # Forbidden road dim: fixed penalty + exit bonus (v3+v4 combined)
        if reason == 'segment_binds_to_forbidden_road':
            forbidden = -forbidden_penalty + exit_bonus
        elif reason in ('no_forbidden_roads', 'correct', 'no_trajectory_parsed',
                         'trajectory_too_short', 'no_road_geometries', 'no_violation'):
            forbidden = exit_bonus  # exit bonus may apply even without forbidden entry
        else:
            forbidden = exit_bonus

        if reason == 'crash_into_wall':
            n = details.get('num_unsafe', 0)
            wall = -min(n, BINDING_MIN_POINTS) * WALL_PENALTY
        elif reason in ('no_trajectory_parsed', 'trajectory_too_short', 'no_road_geometries'):
            wall = 0.0
        else:
            wall = 0.0

        diff_list = [traj_valid, forbidden, wall]
        dim_dict = {'diff_traj_valid': traj_valid, 'diff_forbidden': forbidden,
                    'diff_wall': wall}

        if abs(sum(diff_list) - score) > 0.01:
            logger.warning(
                f"diff_score sum ({sum(diff_list)}) != total score ({score}); "
                f"reason={reason}, diff={diff_list}"
            )

        return diff_list, dim_dict

    @property
    def last_details(self):
        return self._last_details


# ═══════════════════════════════════════════════════════════════════════════════
#  Top-level function
# ═══════════════════════════════════════════════════════════════════════════════

_scorer = None
_scorer_debug = None

def vla_no_entry_reward(data_source, solution_str, ground_truth, extra_info,
                        debug=True, reward_version=None, iou_threshold=None,
                        debug_dir=None, **kwargs):
    global _scorer, _scorer_debug
    if _scorer is None or _scorer_debug != debug:
        _scorer = TaskVLANoEntryReward(debug=debug, debug_dir=debug_dir)
        _scorer_debug = debug
    return _scorer(data_source, solution_str, ground_truth, extra_info)

# ═══════════════════════════════════════════════════════════════════════════════
#  __main__ — quick test
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import pandas as pd

    PARQUET_PATH = "/perception-hl/beijin.zhou/deeprl/v1_data/vla_train_out_no_entry_260526_train__df5f809__20260528070111_part2_part0003.parquet"
    NUM_SAMPLES = 3

    print(f"Loading parquet: {PARQUET_PATH}")
    df = pd.read_parquet(PARQUET_PATH)
    print(f"  {len(df)} samples\n")

    scorer = TaskVLANoEntryReward(debug=True, debug_dir='/tmp/vla_reward_debug')

    for i in range(min(NUM_SAMPLES, len(df))):
        row = df.iloc[i]
        extra_info = row['extra_info']
        kwargs = extra_info['tools_kwargs']['calc_no-entry_reward']['calc_reward_kwargs']

        select_road_ids = json.loads(kwargs['select_road_ids'])
        select_road_cls = json.loads(kwargs['select_road_cls'])
        forbidden_ids = get_forbidden_road_ids(select_road_ids, select_road_cls)
        road_graphs = json.loads(kwargs.get('road_graphs', '{}'))
        vla_goal_point = json.loads(kwargs.get('vla_goal_point', '{}'))
        has_exit_sign = json.loads(kwargs.get('has_exit_sign', 'false'))

        all_road_geoms = get_all_road_geometries(road_graphs)
        intersection_info = detect_intersection_distance(all_road_geoms)

        # Test goal→lane binding
        exit_road_id, _, exit_score, exit_debug = find_best_lane_for_goal(
            vla_goal_point, all_road_geoms)

        print(f"{'='*60}")
        print(f"Sample {i}  clip_id={extra_info['clip_id']}")
        print(f"  select_road_ids:      {select_road_ids}")
        print(f"  select_road_cls:      {select_road_cls}")
        print(f"  forbidden_ids:        {forbidden_ids}")
        print(f"  vla_goal_point:       {vla_goal_point}")
        print(f"  has_exit_sign:        {has_exit_sign}")
        print(f"  intersection dist:     {intersection_info.get('distance')}")
        print(f"  is_intersection:       {intersection_info.get('is_intersection')}")
        print(f"  num_connected:         {intersection_info.get('num_connected_roads')}")
        print(f"  forbidden_penalty:     {get_intersection_penalty(intersection_info.get('distance'))}")
        print(f"  goal→lane binding:     road={exit_road_id} score={exit_score:.3f} "
              f"debug={exit_debug}")

        if not forbidden_ids:
            print("  → No forbidden roads, skip trajectory tests")
            continue

        test_trajs = [
            ("直行", "<action>(500,500),(600,500),(700,500),(800,500),(900,500)</action>"),
            ("右转", "<action>(500,500),(550,450),(650,350),(750,250),(850,150)</action>"),
            ("左转", "<action>(500,500),(450,550),(350,650),(250,750),(150,850)</action>"),
            ("掉头", "<action>(500,500),(490,400),(500,300),(510,200),(500,100)</action>"),
        ]

        for label, traj_str in test_trajs:
            result = scorer("no-entry_v4", traj_str, [], extra_info)
            score = result['score']
            reason = result.get('reason', '?')
            diff = result.get('diff_score', [])
            detail = result.get('details', {})
            road_id = detail.get('road_id', '-')
            road_cls = detail.get('road_cls', '-')
            penalty = detail.get('forbidden_penalty', FORBIDDEN_PENALTY_FAR)
            exit_bon = detail.get('exit_bonus', 0.0)
            exit_det = detail.get('exit_details', {})
            print(f"  {label:4s} → score={score:6.2f}  diff={diff}  "
                  f"reason={reason:35s}  road={road_id}  cls={road_cls}  "
                  f"penalty={penalty}  exit_bonus={exit_bon}  "
                  f"exit={exit_det.get('reason', 'N/A')}")

    print(f"\n{'='*60}")
    print("Done (v4).")
