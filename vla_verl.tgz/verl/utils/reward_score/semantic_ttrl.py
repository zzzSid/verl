from verl.utils.reward_score.majority_voting_reward import *



def test_time_train_metrics(data_list):

    data_dict = {}
    id_to_mapping = {}

    for idx,item in enumerate(data_list):
        item_id = item['ground_truth'].get('id',None)
        if item_id not in data_dict:
            data_dict[item_id] = [item]
            id_to_mapping[item_id] = [(idx,0)]
        else:
            group_inner_idx = len(data_dict[item_id])  
            data_dict[item_id].append(item)
            id_to_mapping[item_id].append((idx, group_inner_idx))

    id_to_group_rewards = {}
    for item_id,rollouts in data_dict.items():
        # List[Dict]
        group_size = len(rollouts)
        format_rewards = [0.0]*group_size # 逐个计算
        think_rewards = [0.0]*group_size # 逐个计算
        acc_rewards =  majority_vote_acc_reward(rollouts)# 成组计算

        accuracy_ratios = [rollout['ground_truth'].get('accuracy_ratio',0.0) for rollout in rollouts]
        format_ratios = [rollout['ground_truth'].get('format_ratio',0.0) for rollout in rollouts]
        think_ratios = [rollout['ground_truth'].get('think_ratio',0.0) for rollout in rollouts]


        # calutate rollouts reward
        for i,rollout in enumerate(rollouts):
            question = rollout['ground_truth'].get('question',None)
            question_type = rollout['ground_truth'].get('verifier',None)
            gt = rollout['ground_truth'].get('ground_truth',None)
            pred = rollout.get('solution_str',None)

            try:
                format_rewards[i] = format_reward(pred,question_type,question,gt)
            except:
                format_rewards[i] = 0.0
       
        group_rewards =[format_reward*format_ratio + think_reward*think_ratio + acc_reward*acc_ratio for format_reward,think_reward,acc_reward,format_ratio,think_ratio,acc_ratio in zip(format_rewards,think_rewards,acc_rewards,format_ratios,think_ratios,accuracy_ratios)]
        id_to_group_rewards[item_id] = group_rewards

    answer_reward = [0.0] * len(data_list)  
    for item_id, mapping_list in id_to_mapping.items():
        group_rewards = id_to_group_rewards[item_id]
        for data_list_idx, group_inner_idx in mapping_list:
            answer_reward[data_list_idx] = group_rewards[group_inner_idx]

    ttrl_metrics = {
        "neg_log_likelihood": 0.0,  # Policy entropy placeholder, will be calculated in semantic_novelty.py
    }

    return answer_reward,ttrl_metrics




if __name__ == "__main__":
    data_list =  [{'ground_truth': {'accuracy_ratio': 1.0, 'format_ratio': 1.0, 'think_ratio': 1.0, 'question': '<image>\nPlease provide the bounding box coordinate of the region this sentence describes:<ref>a giraffe with the top of its neck hidden</ref>\nOutput the thinking process in <think> </think> and final answer in <answer> </answer> tags.', 'ground_truth': '<ref>a giraffe with the top of its neck hidden</ref>: <box>561,119,711,955</box>.', 'verifier': 'Grounding', 'image_path': '/lustre/MLM_evaluator/data/RefCOCO/coco/train2014/COCO_train2014_000000164241.jpg', 'id': 143234}, 'data_source': 'Refcocog', 'solution_str': '</pre>', 'extra_info': {'image': '/lustre/MLM_evaluator/data/RefCOCO/coco/train2014/COCO_train2014_000000164241.jpg', 'content': '<image>\nPlease provide the bounding box coordinate of the region this sentence describes:<ref>a giraffe with the top of its neck hidden</ref>\nOutput the thinking process in <think> </think> and final answer in <answer> </answer> tags.'}}, {'ground_truth': {'accuracy_ratio': 1.0, 'format_ratio': 1.0, 'think_ratio': 1.0, 'question': '<image>\nPlease provide the bounding box coordinate of the region this sentence describes:<ref>a giraffe with the top of its neck hidden</ref>\nOutput the thinking process in <think> </think> and final answer in <answer> </answer> tags.', 'ground_truth': '<ref>a giraffe with the top of its neck hidden</ref>: <box>561,119,711,955</box>.', 'verifier': 'Grounding', 'image_path': '/lustre/MLM_evaluator/data/RefCOCO/coco/train2014/COCO_train2014_000000164241.jpg', 'id': 143234}, 'data_source': 'Refcocog', 'solution_str': '>Answer: <think> giraffe standing closest to the mountains </think>', 'extra_info': {'image': '/lustre/MLM_evaluator/data/RefCOCO/coco/train2014/COCO_train2014_000000164241.jpg', 'content': '<image>\nPlease provide the bounding box coordinate of the region this sentence describes:<ref>a giraffe with the top of its neck hidden</ref>\nOutput the thinking process in <think> </think> and final answer in <answer> </answer> tags.'}}, {'ground_truth': {'accuracy_ratio': 1.0, 'format_ratio': 1.0, 'think_ratio': 1.0, 'question': '<image>\nPlease provide the bounding box coordinate of the region this sentence describes:<ref>a giraffe with the top of its neck hidden</ref>\nOutput the thinking process in <think> </think> and final answer in <answer> </answer> tags.', 'ground_truth': '<ref>a giraffe with the top of its neck hidden</ref>: <box>561,119,711,955</box>.', 'verifier': 'Grounding', 'image_path': '/lustre/MLM_evaluator/data/RefCOCO/coco/train2014/COCO_train2014_000000164241.jpg', 'id': 143234}, 'data_source': 'Refcocog', 'solution_str': '</pre></answer>', 'extra_info': {'image': '/lustre/MLM_evaluator/data/RefCOCO/coco/train2014/COCO_train2014_000000164241.jpg', 'content': '<image>\nPlease provide the bounding box coordinate of the region this sentence describes:<ref>a giraffe with the top of its neck hidden</ref>\nOutput the thinking process in <think> </think> and final answer in <answer> </answer> tags.'}}, {'ground_truth': {'accuracy_ratio': 1.0, 'format_ratio': 1.0, 'think_ratio': 1.0, 'question': '<image>\nPlease provide the bounding box coordinate of the region this sentence describes:<ref>a giraffe with the top of its neck hidden</ref>\nOutput the thinking process in <think> </think> and final answer in <answer> </answer> tags.', 'ground_truth': '<ref>a giraffe with the top of its neck hidden</ref>: <box>561,119,711,955</box>.', 'verifier': 'Grounding', 'image_path': '/lustre/MLM_evaluator/data/RefCOCO/coco/train2014/COCO_train2014_000000164241.jpg', 'id': 143234}, 'data_source': 'Refcocog', 'solution_str': '</b>', 'extra_info': {'image': '/lustre/MLM_evaluator/data/RefCOCO/coco/train2014/COCO_train2014_000000164241.jpg', 'content': '<image>\nPlease provide the bounding box coordinate of the region this sentence describes:<ref>a giraffe with the top of its neck hidden</ref>\nOutput the thinking process in <think> </think> and final answer in <answer> </answer> tags.'}}, {'ground_truth': {'accuracy_ratio': 1.0, 'format_ratio': 1.0, 'think_ratio': 1.0, 'question': '<image>\nPlease provide the bounding box coordinate of the region this sentence describes:<ref>a giraffe with the top of its neck hidden</ref>\nOutput the thinking process in <think> </think> and final answer in <answer> </answer> tags.', 'ground_truth': '<ref>a giraffe with the top of its neck hidden</ref>: <box>561,119,711,955</box>.', 'verifier': 'Grounding', 'image_path': '/lustre/MLM_evaluator/data/RefCOCO/coco/train2014/COCO_train2014_000000164241.jpg', 'id': 143234}, 'data_source': 'Refcocog', 'solution_str': 'think: Examine the giraffe standing on the right side of the image to determine the details about the tag. Answer: The answer is unable', 'extra_info': {'image': '/lustre/MLM_evaluator/data/RefCOCO/coco/train2014/COCO_train2014_000000164241.jpg', 'content': '<image>\nPlease provide the bounding box coordinate of the region this sentence describes:<ref>a giraffe with the top of its neck hidden</ref>\nOutput the thinking process in <think> </think> and final answer in <answer> </answer> tags.'}}, {'ground_truth': {'accuracy_ratio': 1.0, 'format_ratio': 1.0, 'think_ratio': 1.0, 'question': '<image>\nPlease provide the bounding box coordinate of the region this sentence describes:<ref>a giraffe with the top of its neck hidden</ref>\nOutput the thinking process in <think> </think> and final answer in <answer> </answer> tags.', 'ground_truth': '<ref>a giraffe with the top of its neck hidden</ref>: <box>561,119,711,955</box>.', 'verifier': 'Grounding', 'image_path': '/lustre/MLM_evaluator/data/RefCOCO/coco/train2014/COCO_train2014_000000164241.jpg', 'id': 143234}, 'data_source': 'Refcocog', 'solution_str': '</pre>', 'extra_info': {'image': '/lustre/MLM_evaluator/data/RefCOCO/coco/train2014/COCO_train2014_000000164241.jpg', 'content': '<image>\nPlease provide the bounding box coordinate of the region this sentence describes:<ref>a giraffe with the top of its neck hidden</ref>\nOutput the thinking process in <think> </think> and final answer in <answer> </answer> tags.'}}, {'ground_truth': {'accuracy_ratio': 1.0, 'format_ratio': 1.0, 'think_ratio': 1.0, 'question': '<image>\nPlease provide the bounding box coordinate of the region this sentence describes:<ref>a giraffe with the top of its neck hidden</ref>\nOutput the thinking process in <think> </think> and final answer in <answer> </answer> tags.', 'ground_truth': '<ref>a giraffe with the top of its neck hidden</ref>: <box>561,119,711,955</box>.', 'verifier': 'Grounding', 'image_path': '/lustre/MLM_evaluator/data/RefCOCO/coco/train2014/COCO_train2014_000000164241.jpg', 'id': 143234}, 'data_source': 'Refcocog', 'solution_str': '</thinking>', 'extra_info': {'image': '/lustre/MLM_evaluator/data/RefCOCO/coco/train2014/COCO_train2014_000000164241.jpg', 'content': '<image>\nPlease provide the bounding box coordinate of the region this sentence describes:<ref>a giraffe with the top of its neck hidden</ref>\nOutput the thinking process in <think> </think> and final answer in <answer> </answer> tags.'}}, {'ground_truth': {'accuracy_ratio': 1.0, 'format_ratio': 1.0, 'think_ratio': 1.0, 'question': '<image>\nPlease provide the bounding box coordinate of the region this sentence describes:<ref>a giraffe with the top of its neck hidden</ref>\nOutput the thinking process in <think> </think> and final answer in <answer> </answer> tags.', 'ground_truth': '<ref>a giraffe with the top of its neck hidden</ref>: <box>561,119,711,955</box>.', 'verifier': 'Grounding', 'image_path': '/lustre/MLM_evaluator/data/RefCOCO/coco/train2014/COCO_train2014_000000164241.jpg', 'id': 143234}, 'data_source': 'Refcocog', 'solution_str': '</br>Answer: first giraffe, brid on camel neck', 'extra_info': {'image': '/lustre/MLM_evaluator/data/RefCOCO/coco/train2014/COCO_train2014_000000164241.jpg', 'content': '<image>\nPlease provide the bounding box coordinate of the region this sentence describes:<ref>a giraffe with the top of its neck hidden</ref>\nOutput the thinking process in <think> </think> and final answer in <answer> </answer> tags.'}}]
    print(test_time_train_metrics(data_list))

