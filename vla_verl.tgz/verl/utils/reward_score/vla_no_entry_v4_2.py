"""
VLA No-Entry Reward v4.2 — v4 + COT (Chain-of-Thought) scoring branch.

基于 vla_no_entry_v4.py，增加 COT 模式的分支判断：
  - 如果 prompt（extra_info["question"]）包含 <NO_COT>：使用与 v4 完全相同的评分逻辑
  - 如果 prompt（extra_info["question"]）包含 <COT>：在 v4 action 评分基础上，增加 COT 禁行框评分：
      a. 解析模型输出的禁行框（方向token + 视角token + 中心点）
      b. 与 GT 比对：
         - 方向+视角+中心点全对 → 每个框 +0.5（全对，按 GT 框数归一化）
         - 仅方向对 → 每个框 +0.2（方向对，按 GT 框数归一化）
      c. 输出格式不遵循模版 → -0.5
      d. GT 禁行框方向与预测的 meta action 不冲突 → +0.3（不朝禁行方向行驶，禁行认知与行为一致）
      e. 轨迹方向与 meta action 一致 → +0.4（仅有效轨迹：未进入禁行路，且碰撞数<2，言行一致加分）
      f. 预测框数≠GT框数 → -abs(预测框数-GT框数)×0.2（对多检/漏检的惩罚，按 GT 框数归一化）

方向 token → meta action 映射：
  [UNUSED_TOKEN_110], [UNUSED_TOKEN_111] → 左转 (meta action 0)
  [UNUSED_TOKEN_112], [UNUSED_TOKEN_113] → 直行 (meta action 1)
  [UNUSED_TOKEN_114], [UNUSED_TOKEN_115] → 右转 (meta action 2)

Scoring rules (v4 base + COT extras when <COT>):
    ───────────────────────────────────────────────────────────────────────────
    场景                                              score       reason
    ───────────────────────────────────────────────────────────────────────────
    (v4 base scoring — same as vla_no_entry_v4.py, for both NO_COT and COT)
    COT-格式错误                                       -0.5        cot_format_error
    COT-全对框（方向+视角+中心，归一化）               +0.5×n_full/GT数  cot_direction_full_correct
    COT-仅方向对框（归一化）                            +0.2×n_only/GT数  cot_direction_only_correct
    COT-GT_Direction→Meta不冲突                        +0.3        cot_direction_meta_no_conflict
    COT-Meta→Trajectory一致                           +0.4        cot_meta_traj_match
    COT-框数不匹配（多检/漏检，归一化）               -abs(pred-gt)×0.2/GT数  cot_count_mismatch
    ───────────────────────────────────────────────────────────────────────────

GDPO diff_score decomposition (always 4 dims for consistency):
    Both modes: [trajectory_validity, forbidden_road, wall_crash, cot]
    NO_COT mode: cot = 0.0
"""

import json
import logging
import os
import pickle
import random
import re
from typing import Optional

import numpy as np

logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════════════
#  Constants
# ═══════════════════════════════════════════════════════════════════════════════

FORBIDDEN_ROAD_CLASSES = {'noEntryRoad', 'noEntryRoadBarrier', 'ArriveDeadEndRoad', 'onlyRetrograde'}

BINDING_W_DIST   = 0.5
BINDING_W_ANGLE  = 0.5
BINDING_MAX_DIST = 5.0
BINDING_MIN_POINTS = 5

WALL_PENALTY      = 1.0

# ── Intersection-distance-based forbidden road penalties (v3) ──
FORBIDDEN_PENALTY_NEAR   = 4.0   # dist < 6m
FORBIDDEN_PENALTY_MEDIUM = 3.0   # dist < 12m
FORBIDDEN_PENALTY_FAR    = 2.0   # dist >= 12m

# ── Intersection distance thresholds ──
INTERSECTION_NEAR_6M   = 6.0
INTERSECTION_NEAR_12M  = 12.0
INTERSECTION_ENDPOINT_DIST_THRESHOLD = 2.0
INTERSECTION_MIN_CONNECTED_ROADS = 2

# ── Exit direction bonus (v4 new) ──
EXIT_DIRECTION_BONUS = 2.0
GOAL_LANE_W_DIST  = 0.3                 # weight for distance in goal→lane binding
GOAL_LANE_W_ANGLE = 0.7                 # weight for angle in goal→lane binding

# ── COT scoring constants (v4.2 new) ──
COT_DIRECTION_CORRECT_BONUS     = 0.5    # per box full match: direction + camera + center all correct
COT_DIRECTION_ONLY_BONUS        = 0.2    # per box direction-only match (camera/center may be wrong)
COT_DIRECTION_META_NO_CONFLICT   = 0.3    # GT direction→meta no conflict: no GT forbidden road direction matches predicted turn (not heading into forbidden road)
COT_META_TRAJ_MATCH_BONUS       = 0.4    # meta→trajectory consistency (only when traj didn't enter forbidden road)
COT_FORMAT_PENALTY              = 0.5    # output doesn't follow COT template
COT_COUNT_MISMATCH_PENALTY       = 0.2    # per box difference: abs(num_pred - num_gt)

# Direction token → meta action mapping (6 tokens, 30° each)
#   110,111 → left(0), 112,113 → straight(1), 114,115 → right(2)
DIR_TOKEN_TO_META_ACTION = {
    '[UNUSED_TOKEN_110]': 0, '[UNUSED_TOKEN_111]': 0,  # 左转
    '[UNUSED_TOKEN_112]': 1, '[UNUSED_TOKEN_113]': 1,  # 直行
    '[UNUSED_TOKEN_114]': 2, '[UNUSED_TOKEN_115]': 2,  # 右转
}

# Meta action ID → name
META_ACTION_NAMES = ["左转", "直行", "右转", "掉头", "未知"]

# Camera/sensor token mappings
CAM_TOKEN_TO_NAME = {
    '[UNUSED_TOKEN_53]': 'FW', '[UNUSED_TOKEN_54]': 'FN',
    '[UNUSED_TOKEN_55]': 'FL', '[UNUSED_TOKEN_56]': 'FR',
}

COORD_NORM_MIN, COORD_NORM_MAX = 0, 1000
COORD_PHYS_MIN, COORD_PHYS_MAX = -30.0, 30.0

ACTION_POINTS_RE = re.compile(r"\((\d+),(\d+)\)")
ACTION_TOKEN_RE  = re.compile(r"<action_(\d+)>")

# ── COT parsing regex (v4.2 new) ──
# COT segment: [UNUSED_TOKEN_1XX][UNUSED_TOKEN_5X][UNUSED_TOKEN_73]CX,CY[UNUSED_TOKEN_74]
COT_SEGMENT_RE = re.compile(
    r'\[UNUSED_TOKEN_(1\d{2})\]'            # direction token (110-115)
    r'(\[UNUSED_TOKEN_5[3-6]\])'            # camera token (53-56)
    r'\[UNUSED_TOKEN_73\]'                  # center point start
    r'(\d+),(\d+)'                          # cx, cy (0-999)
    r'\[UNUSED_TOKEN_74\]'                  # center point end
)
# COT turn: digit right before <action> or at end of COT prefix
COT_TURN_RE = re.compile(r'(\d)\s*<action>')
# COT "无" pattern: model says no forbidden roads
COT_NO_CLUE_RE = re.compile(r'无(\d)')
# GT clue string parser: B[UNUSED_TOKEN_32]{CAM}[UNUSED_TOKEN_33]<box>{x1},{y1},{x2},{y2}</box>
GT_CLUE_RE = re.compile(
    r'\[UNUSED_TOKEN_32\]'
    r'(\[UNUSED_TOKEN_5[3-6]\])'
    r'\[UNUSED_TOKEN_33\]'
    r'<box>(\d+),(\d+),(\d+),(\d+)</box>'
)

_DEFAULT_VOCAB_PATH = "/perception-hl/longan.yang/vla_data/vlm_path/train_dataset/vocab/0804_all/tokens_512_v1.npy"
_VOCABULARY = None
_VOCAB_PATH_USED = None


def get_vocabulary(vocab_path=None):
    global _VOCABULARY, _VOCAB_PATH_USED
    path = vocab_path or os.environ.get('VLA_VOCAB_PATH') or _DEFAULT_VOCAB_PATH
    if _VOCABULARY is not None and _VOCAB_PATH_USED == path:
        return _VOCABULARY
    if os.path.exists(path):
        _VOCABULARY = np.load(path)
        _VOCAB_PATH_USED = path
    else:
        logger.warning(f"VLA vocab path not found: {path}")
        _VOCABULARY = np.array([])
        _VOCAB_PATH_USED = path
    return _VOCABULARY

# ═══════════════════════════════════════════════════════════════════════════════
#  Trajectory parsing
# ═══════════════════════════════════════════════════════════════════════════════

def parse_action_traj(prediction_text: str, vocab_path=None):
    if not prediction_text:
        return None
    action_match = re.search(r"<action>(.*?)</action>", prediction_text, re.DOTALL)
    if not action_match:
        return None
    content = action_match.group(1)
    points = ACTION_POINTS_RE.findall(content)
    if points:
        return [[int(x), int(y)] for x, y in points]
    token_matches = ACTION_TOKEN_RE.findall(content)
    if not token_matches:
        return None
    vocabulary = get_vocabulary(vocab_path)
    if vocabulary is None or vocabulary.size == 0:
        return None
    vocab_indices = [int(m) for m in token_matches]
    x, y, theta = 0.0, 0.0, 0.0
    xs, ys = [], []
    for idx in vocab_indices:
        if idx == 0:
            xs.append(x); ys.append(y)
            continue
        vocab_row = idx - 1
        if vocab_row < 0 or vocab_row >= vocabulary.shape[0]:
            continue
        dx, dy, dheading = vocabulary[vocab_row]
        cos_t, sin_t = np.cos(theta), np.sin(theta)
        x = float(x + dx * cos_t - dy * sin_t)
        y = float(y + dx * sin_t + dy * cos_t)
        theta = float(np.arctan2(np.sin(theta + dheading), np.cos(theta + dheading)))
        xs.append(x); ys.append(y)
    if not xs:
        return None
    return [[x, y] for x, y in zip(xs, ys)]


def norm_to_abs_traj(norm_traj):
    if norm_traj is None or len(norm_traj) == 0:
        return None
    scale = (COORD_PHYS_MAX - COORD_PHYS_MIN) / (COORD_NORM_MAX - COORD_NORM_MIN)
    return np.array([[COORD_PHYS_MIN + x * scale, COORD_PHYS_MIN + y * scale]
                     for x, y in norm_traj], dtype=float)


def action_traj_to_abs(action_traj):
    if action_traj is None or len(action_traj) == 0:
        return None
    if isinstance(action_traj[0][0], int):
        return norm_to_abs_traj(action_traj)
    return np.array(action_traj, dtype=float)

# ═══════════════════════════════════════════════════════════════════════════════
#  Road data helpers
# ═══════════════════════════════════════════════════════════════════════════════

def get_forbidden_road_ids(select_road_ids, select_road_cls):
    forbidden = set()
    for rid, cls in zip(select_road_ids, select_road_cls):
        if cls in FORBIDDEN_ROAD_CLASSES:
            forbidden.add(rid)
    return forbidden


def get_all_road_geometries(road_graphs):
    geometries = {}
    for road_id, info in road_graphs.items():
        if info and 'geometry' in info:
            geom = np.array(info['geometry'], dtype=float)
            if len(geom) >= 2:
                geometries[road_id] = geom
    return geometries


def get_road_id_to_cls(select_road_ids, select_road_cls):
    return dict(zip(select_road_ids, select_road_cls))

# ═══════════════════════════════════════════════════════════════════════════════
#  Geometry helpers (segment → road binding)
# ═══════════════════════════════════════════════════════════════════════════════

def _min_distance_point_to_polyline(point, polyline):
    point = np.asarray(point, dtype=float)
    min_dist = float('inf')
    closest_pt = None
    for i in range(len(polyline) - 1):
        a, b = polyline[i], polyline[i + 1]
        ab = b - a
        ab_len_sq = np.dot(ab, ab)
        if ab_len_sq < 1e-12:
            dist = np.linalg.norm(point - a)
            if dist < min_dist:
                min_dist, closest_pt = dist, a.copy()
            continue
        t = max(0.0, min(1.0, np.dot(point - a, ab) / ab_len_sq))
        closest = a + t * ab
        dist = np.linalg.norm(point - closest)
        if dist < min_dist:
            min_dist, closest_pt = dist, closest.copy()
    return min_dist, closest_pt


def _road_direction_at_point(polyline, closest_point):
    min_seg_dist = float('inf')
    best_dir = None
    for i in range(len(polyline) - 1):
        a, b = polyline[i], polyline[i + 1]
        mid = (a + b) / 2.0
        d = np.linalg.norm(closest_point - mid)
        if d < min_seg_dist:
            min_seg_dist = d
            seg_dir = b - a
            seg_len = np.linalg.norm(seg_dir)
            if seg_len > 1e-8:
                best_dir = seg_dir / seg_len
    return best_dir


def compute_segment_binding_score(segment, geom):
    center = np.mean(segment, axis=0)
    min_dist, closest_pt = _min_distance_point_to_polyline(center, geom)
    if min_dist > BINDING_MAX_DIST:
        return None
    seg_vec = segment[-1] - segment[0]
    seg_len = np.linalg.norm(seg_vec)
    if seg_len < 1e-6:
        return None
    seg_heading = np.arctan2(seg_vec[1], seg_vec[0])
    road_dir = _road_direction_at_point(geom, closest_pt)
    if road_dir is None:
        return None
    road_heading = np.arctan2(road_dir[1], road_dir[0])
    angle_diff = seg_heading - road_heading
    angle_diff = np.degrees(np.arctan2(np.sin(angle_diff), np.cos(angle_diff)))
    abs_angle = abs(angle_diff)
    if 60.0 < abs_angle < 120.0:
        return None
    has_both_sides = (np.any(geom[:, 1] > 0) and np.any(geom[:, 1] < 0))
    if not has_both_sides and abs_angle > 90.0:
        return None
    if len(geom) >= 2:
        global_vec = geom[-1] - geom[0]
        global_heading = np.arctan2(global_vec[1], global_vec[0])
        global_diff = seg_heading - global_heading
        global_diff = np.degrees(np.arctan2(np.sin(global_diff), np.cos(global_diff)))
        if 60.0 < abs(global_diff) < 120.0:
            return None
    norm_dist = min(min_dist / BINDING_MAX_DIST, 1.0)
    norm_angle = abs_angle / 90.0
    score = BINDING_W_DIST * norm_dist + BINDING_W_ANGLE * norm_angle
    return {
        'score': score, 'dist': float(min_dist),
        'angle_deg': float(angle_diff), 'closest_pt': closest_pt.tolist(),
    }


def bind_segment_to_road(segment, all_road_geoms):
    best_road_id = None
    best_score = float('inf')
    best_info = None
    for road_id, geom in all_road_geoms.items():
        result = compute_segment_binding_score(segment, geom)
        if result is None:
            continue
        if result['score'] < best_score:
            best_score = result['score']
            best_road_id = road_id
            best_info = result
    return best_road_id, best_info

# ═══════════════════════════════════════════════════════════════════════════════
#  Goal → lane binding (v4 new — ported from visualize_no_entry_jsonl.py)
# ═══════════════════════════════════════════════════════════════════════════════

def find_best_lane_for_goal(goal_point: dict, all_road_geoms: dict):
    """将 vla_goal_point 绑定到最佳匹配的道路上（出口路）。

    绑定打分 = w_d * 距离分 + w_a * 方向分  (w_d=0.3, w_a=0.7, 角度主导)
    - 距离分: 1/(1+dist), goal_point 离道路越近分越高
    - 方向分: max(0, cos(夹角)), 夹角>=75°时直接归零, 避免错误绑定
    - 道路方向: 离原点较近的端点 → 离原点较远的端点

    Args:
        goal_point: dict with point_x, point_y, yaw
        all_road_geoms: dict of road_id → (N,2) geometry

    Returns:
        (best_road_id, best_geometry, best_score, best_debug) or
        (None, None, -1, {})
    """
    if not goal_point or not all_road_geoms:
        return None, None, -1.0, {}

    px = goal_point.get('point_x', 0)
    py = goal_point.get('point_y', 0)
    yaw = goal_point.get('yaw', 0)
    goal_pos = np.array([px, py])
    goal_dir = np.array([np.cos(yaw), np.sin(yaw)])

    w_d = GOAL_LANE_W_DIST
    w_a = GOAL_LANE_W_ANGLE

    best_score = -1.0
    best_road_id = None
    best_geometry = None
    best_debug = {}

    for road_id, geometry in all_road_geoms.items():
        if len(geometry) < 2:
            continue

        road_best_score = -1.0
        road_best_debug = {}
        for i in range(len(geometry) - 1):
            p1 = geometry[i]
            p2 = geometry[i + 1]

            # 道路方向：离原点较近 → 离原点较远
            d1 = np.linalg.norm(p1)
            d2 = np.linalg.norm(p2)
            lane_dir = (p2 - p1) if d1 <= d2 else (p1 - p2)
            lane_dir_norm = np.linalg.norm(lane_dir)
            if lane_dir_norm < 1e-6:
                continue
            lane_dir = lane_dir / lane_dir_norm

            # goal_point 到线段的最短距离
            v = p2 - p1
            w = goal_pos - p1
            v_dot_v = np.dot(v, v)
            if v_dot_v < 1e-6:
                dist = np.linalg.norm(goal_pos - p1)
            else:
                t = np.clip(np.dot(w, v) / v_dot_v, 0.0, 1.0)
                projection = p1 + t * v
                dist = np.linalg.norm(goal_pos - projection)

            cos_angle = np.dot(goal_dir, lane_dir)
            angle_deg = np.degrees(np.arccos(np.clip(cos_angle, -1.0, 1.0)))
            # 夹角 > 75° 的路段直接排除
            if cos_angle < 0.2588:  # cos(75°) ≈ 0.2588
                continue

            dist_score = 1.0 / (1.0 + dist)
            angle_score = max(0.0, cos_angle)
            score = w_d * dist_score + w_a * angle_score

            if score > road_best_score:
                road_best_score = score
                road_best_debug = {
                    'seg_idx': i,
                    'dist': round(dist, 2),
                    'angle_deg': round(angle_deg, 1),
                    'dist_score': round(dist_score, 3),
                    'angle_score': round(angle_score, 3),
                    'score': round(score, 3),
                }

        if road_best_score > best_score:
            best_score = road_best_score
            best_road_id = road_id
            best_geometry = geometry
            best_debug = road_best_debug

    return best_road_id, best_geometry, best_score, best_debug


def check_trajectory_follows_exit_direction(
    abs_traj,
    all_road_geoms,
    vla_goal_point,
    has_exit_sign,
    intersection_distance,
):
    """检查预测轨迹是否沿着出口方向（绑定到与 goal point 相同的出口路）。

    仅在以下条件同时满足时检查：
      1. 距离交叉点 < 12m
      2. 当前帧存在出口标识（has_exit_sign = True）
      3. vla_goal_point 有效

    出口方向判断（基于路网绑定）：
      1. 使用 find_best_lane_for_goal 找到 goal point 绑定的最佳路网（出口路）
      2. 将轨迹 prepend origin (0,0) 后，逐段 bind_segment_to_road
      3. 如果任一段轨迹绑定到与 goal point 相同的道路上 → 沿着出口方向

    Returns:
        (follows_exit: bool, exit_bonus: float, details: dict)
    """
    if intersection_distance is None or intersection_distance >= INTERSECTION_NEAR_12M:
        return False, 0.0, {'reason': 'not_near_intersection',
                            'distance': intersection_distance}

    if not has_exit_sign:
        return False, 0.0, {'reason': 'no_exit_sign'}

    if not vla_goal_point or not vla_goal_point.get('point_x') or not vla_goal_point.get('yaw'):
        return False, 0.0, {'reason': 'no_goal_point'}

    if abs_traj is None or len(abs_traj) < BINDING_MIN_POINTS:
        return False, 0.0, {'reason': 'trajectory_too_short_for_exit_check',
                            'num_points': len(abs_traj) if abs_traj is not None else 0}

    if not all_road_geoms:
        return False, 0.0, {'reason': 'no_road_geoms'}

    # ── 1. 找到 goal point 绑定的出口路 ──
    exit_road_id, exit_geometry, exit_score, exit_debug = find_best_lane_for_goal(
        vla_goal_point, all_road_geoms)

    if exit_road_id is None or exit_geometry is None:
        return False, 0.0, {'reason': 'goal_not_bound_to_any_road',
                            'goal_point': vla_goal_point}

    # ── 2. 检查轨迹是否绑定到同一个出口路上 ──
    # 使用与 check_traj_violation_by_binding 相同的轨迹构造方式
    origin = np.array([[0.0, 0.0]])
    full_traj = np.vstack([origin, abs_traj[:BINDING_MIN_POINTS]])

    segment_bindings = []
    for i in range(len(full_traj) - 2):
        segment = full_traj[i:i + 3]
        bound_road_id, binding_info = bind_segment_to_road(segment, all_road_geoms)
        segment_bindings.append({
            'segment_idx': i,
            'bound_road_id': bound_road_id,
            'binding_info': binding_info,
        })
        if bound_road_id == exit_road_id:
            follows_exit = True
            exit_bonus = EXIT_DIRECTION_BONUS
            return follows_exit, exit_bonus, {
                'reason': 'follows_exit',
                'exit_road_id': exit_road_id,
                'matched_segment_idx': i,
                'binding_info': binding_info,
                'exit_score': round(exit_score, 3),
                'exit_debug': exit_debug,
                'intersection_distance': intersection_distance,
                'has_exit_sign': has_exit_sign,
            }

    # No segment bound to exit road
    return False, 0.0, {
        'reason': 'trajectory_not_bound_to_exit_road',
        'exit_road_id': exit_road_id,
        'exit_score': round(exit_score, 3),
        'exit_debug': exit_debug,
        'segment_bindings': segment_bindings,
        'intersection_distance': intersection_distance,
        'has_exit_sign': has_exit_sign,
    }

# ═══════════════════════════════════════════════════════════════════════════════
#  COT scoring helpers (v4.2 new)
# ═══════════════════════════════════════════════════════════════════════════════

def _cal_vector_angle(v2, v1=(1.0, 0.0)):
    """Calculate signed angle (degrees) from v1 to v2."""
    angle_rad = np.arctan2(v2[1], v2[0]) - np.arctan2(v1[1], v1[0])
    angle_deg = np.degrees(angle_rad)
    return (angle_deg + 180.0) % 360.0 - 180.0


def _compute_turn(v1, v2, th_forward=30.0, th_back=150.0):
    """Classify direction change between two vectors: 直行/左转/右转/掉头."""
    ang = abs(_cal_vector_angle(v2, v1))
    cross = v1[0] * v2[1] - v1[1] * v2[0]
    if ang < th_forward:
        return "直行"
    elif ang > th_back:
        return "掉头"
    else:
        return "左转" if cross > 0 else "右转"


def _get_candidate_turns(points):
    """Compute turn directions between consecutive points in a trajectory."""
    if len(points) <= 2:
        return None, None
    v1 = v0 = (1.0, 0.0)
    dir_to_last, dir_to_start = [], []
    for i in range(len(points) - 1):
        v = (points[i + 1][0] - points[i][0], points[i + 1][1] - points[i][1])
        dir_to_last.append(_compute_turn(v1, v))
        dir_to_start.append(_compute_turn(v0, v))
        v1 = v
    return dir_to_last, dir_to_start


def _determine_trajectory_type(dir_to_last, dir_to_start, dist_y):
    """Determine the overall turn type from per-segment directions."""
    if dir_to_start is None:
        return ["未知"]
    if "掉头" in dir_to_start:
        first_index = dir_to_start.index("掉头")
        if len(set(dir_to_start[first_index:])) == 1:
            if max(abs(dist_y[first_index:])) <= 4:
                return ["掉头"]
        return ["未知"]
    last_direction, find_first, turn_directions = "直行", False, []
    for i, direction in enumerate(dir_to_start):
        if direction != last_direction:
            if not find_first:
                if direction == "掉头":
                    return ["未知"]
                turn_directions.append(direction)
                find_first = True
                last_direction = direction
            else:
                if dir_to_last[i] != "直行" and dir_to_last[i] != "掉头":
                    turn_directions.append(dir_to_last[i])
                    last_direction = direction
                else:
                    turn_directions.append("未知")
                    break
    if len(turn_directions) == 0:
        turn_directions = ["直行"]
    return turn_directions


def interpolate_trajectory(abs_traj, num_points=18):
    """Interpolate a sparse trajectory to a fixed number of points via arc-length sampling.

    The model outputs 5 action tokens (~5m each, 25m total), but the turn classifier
    was designed for ~20-point trajectories. Sparse sampling misses subtle direction
    changes. This function upsamples via linear interpolation along the path.

    Args:
        abs_traj: (N, 2) numpy array of absolute trajectory points.
        num_points: target number of interpolated points.

    Returns:
        (num_points, 2) numpy array, or the original traj if too short.
    """
    if abs_traj is None or len(abs_traj) < 2:
        return abs_traj

    # Prepend origin to form the full path
    full = np.vstack([np.zeros((1, 2)), abs_traj])

    # Cumulative arc length along the path
    diffs = np.diff(full, axis=0)
    seg_lens = np.sqrt(np.sum(diffs ** 2, axis=1))
    cum_len = np.concatenate([[0.0], np.cumsum(seg_lens)])
    total_len = cum_len[-1]

    if total_len < 1e-6:
        return abs_traj

    # Evenly spaced sample distances
    sample_lens = np.linspace(0.0, total_len, num_points)

    # Linear interpolation for x and y
    interp_x = np.interp(sample_lens, cum_len, full[:, 0])
    interp_y = np.interp(sample_lens, cum_len, full[:, 1])

    return np.column_stack([interp_x, interp_y])


def calculate_meta_action_from_trajectory(traj, num_interp_points=18):
    """Compute meta action (turn type) from an absolute trajectory.

    Ported from tools/utils/data_utils.py.  Interpolates sparse trajectories
    (e.g. 5 action tokens) to num_interp_points before classification so the
    turn detector sees sufficient angular resolution.

    Args:
        traj: (N, 2) or (N, 3) numpy array of absolute trajectory points.
        num_interp_points: number of points to interpolate to (default 18).

    Returns:
        list of turn type strings, e.g. ["直行"], ["左转"], ["掉头"], etc.
    """
    if isinstance(traj, list):
        traj = np.array(traj)
    if len(traj) < 1:
        return []

    # Interpolate to match the point density the turn classifier expects
    if traj.ndim == 2 and traj.shape[1] == 2 and len(traj) < num_interp_points:
        traj = interpolate_trajectory(traj, num_points=num_interp_points)

    if traj.ndim == 2 and traj.shape[1] == 2:
        traj = np.hstack([traj, np.zeros((traj.shape[0], 1))])
    traj = np.vstack([np.zeros((1, 3)), traj])
    dir_to_last, dir_to_start = _get_candidate_turns(traj)
    turn_types = _determine_trajectory_type(dir_to_last, dir_to_start, traj[1:, 1])
    return turn_types


def _compute_bearing_to_point(pt):
    """Compute bearing angle to a point in user system (right=0°, forward=90°, left=180°)."""
    x, y = pt[0], pt[1]
    std_deg = np.degrees(np.arctan2(y, x))
    return (std_deg + 90.0) % 360.0


def compute_road_direction_angle(geometry):
    """Compute road direction angle from geometry.

    Angle system: right of car = 0°, forward = 90°, left = 180°.
    Direction: from nearest-to-origin point to farthest-to-origin point.

    Returns direction_angle_deg (float), or -1.0 if geometry insufficient.
    """
    if not geometry or len(geometry) < 2:
        return -1.0
    pts = np.array(geometry, dtype=float)
    dists = np.sqrt(pts[:, 0] ** 2 + pts[:, 1] ** 2)
    near_idx = int(np.argmin(dists))
    far_idx = int(np.argmax(dists))
    direction = pts[far_idx] - pts[near_idx]
    dx, dy = direction[0], direction[1]
    std_dir_deg = np.degrees(np.arctan2(dy, dx))
    direction_angle_deg = (std_dir_deg + 90.0) % 360.0
    return direction_angle_deg


def angle_to_direction_token(angle_deg):
    """Map road direction angle to one of 6 direction tokens.

    Angle system: right=0°, forward=90°, left=180°.
    180° forward-facing semicircle divided into 6 bins of 30° each.
    [UNUSED_TOKEN_110] = 150°-180° (leftmost)
    [UNUSED_TOKEN_115] = 0°-30°   (rightmost)
    Angles > 180° are mirrored to the front hemisphere via 360 - angle.
    """
    if angle_deg < 0:
        angle_deg = 0.0
    if angle_deg > 180.0:
        angle_deg = 360.0 - angle_deg
    angle_deg = max(0.0, min(180.0, angle_deg))
    bin_idx = min(int(angle_deg // 30), 5)
    token_num = 115 - bin_idx
    return f"[UNUSED_TOKEN_{token_num}]"


def parse_gt_clue(clue_str):
    """Parse a GT clue string to extract (camera_token, box_coords).

    GT format: B[UNUSED_TOKEN_32]{CAM}[UNUSED_TOKEN_33]<box>{x1},{y1},{x2},{y2}</box>

    Returns (cam_token_str, (x1, y1, x2, y2)) or None.
    """
    match = GT_CLUE_RE.search(clue_str) if clue_str else None
    if not match:
        return None
    cam_token = match.group(1)
    x1, y1, x2, y2 = int(match.group(2)), int(match.group(3)), int(match.group(4)), int(match.group(5))
    return cam_token, (x1, y1, x2, y2)


def point_in_box(cx, cy, box):
    """Check if a center point (cx, cy) falls within a GT box [x1, y1, x2, y2]."""
    x1, y1, x2, y2 = box
    return (min(x1, x2) <= cx <= max(x1, x2)) and (min(y1, y2) <= cy <= max(y1, y2))


def parse_cot_response(response_text):
    """Parse a COT-format model response into structured components.

    Expected format:
      {DIR_TOKEN}{CAM}[UNUSED_TOKEN_73]{cx},{cy}[UNUSED_TOKEN_74]...{turn}<action>...</action>
    or:
      无{turn}<action>...</action>   (no forbidden roads detected)

    Returns dict with:
      - segments: list of {dir_token, cam_token, cx, cy}
      - turn: int or None (0-4)
      - has_clue: bool
      - format_valid: bool (strict: entire COT part must be consumed by valid patterns)
      - raw_cot_part: str (everything before <action>)
      - format_error_reason: str or None
      - extra_tokens: list of unrecognized substrings in COT part
    """
    result = {
        'segments': [],
        'turn': None,
        'has_clue': True,
        'format_valid': False,
        'raw_cot_part': '',
        'format_error_reason': None,
        'extra_tokens': [],
    }

    if not response_text:
        result['format_error_reason'] = 'empty_response'
        return result

    # Extract everything before <action>
    action_match = re.search(r'<action>', response_text)
    if not action_match:
        result['format_error_reason'] = 'no_action_tag'
        return result

    cot_part = response_text[:action_match.start()]
    result['raw_cot_part'] = cot_part.strip()

    if not cot_part.strip():
        result['format_error_reason'] = 'empty_cot_part'
        return result

    # ── Check for "无" (no forbidden roads) pattern ──
    no_clue_match = COT_NO_CLUE_RE.search(cot_part)
    if no_clue_match:
        turn_str = no_clue_match.group(1)
        try:
            turn = int(turn_str)
            if 0 <= turn <= 4:
                # Strict check: the entire COT part must be exactly "无{turn}"
                expected = f'无{turn}'
                if cot_part.strip() == expected:
                    result['turn'] = turn
                    result['has_clue'] = False
                    result['format_valid'] = True
                else:
                    result['format_error_reason'] = f'no_clue_extra_chars: expected "{expected}", got "{cot_part.strip()}"'
                    result['extra_tokens'] = [cot_part.strip()]
            else:
                result['format_error_reason'] = f'turn_out_of_range: {turn}'
        except (ValueError, IndexError):
            result['format_error_reason'] = f'no_clue_bad_turn: {turn_str}'
        return result

    # ── Parse COT segments with strict validation ──
    segments_raw = COT_SEGMENT_RE.findall(cot_part)

    if not segments_raw:
        result['format_error_reason'] = 'no_valid_segments'
        result['extra_tokens'] = [cot_part.strip()]
        return result

    # Validate each segment's cx, cy are in range 0-999
    for dir_num, cam_token, cx_str, cy_str in segments_raw:
        cx, cy = int(cx_str), int(cy_str)
        if not (0 <= cx <= 999 and 0 <= cy <= 999):
            result['format_error_reason'] = f'center_out_of_range: ({cx},{cy})'
            result['extra_tokens'] = [f'[UNUSED_TOKEN_73]{cx},{cy}[UNUSED_TOKEN_74]']
            return result
        result['segments'].append({
            'dir_token': f'[UNUSED_TOKEN_{dir_num}]',
            'cam_token': cam_token,
            'cx': cx,
            'cy': cy,
        })

    # ── Strict check: remove all valid segments from COT part, only whitespace + turn should remain ──
    remainder = cot_part
    for seg_match in COT_SEGMENT_RE.finditer(cot_part):
        remainder = remainder.replace(seg_match.group(0), '', 1)

    # Remove the turn digit if present
    turn_match_in_cot = re.search(r'(\d)\s*$', remainder)
    turn_str_raw = None
    if turn_match_in_cot:
        turn_str_raw = turn_match_in_cot.group(1)
        remainder = remainder[:turn_match_in_cot.start()] + remainder[turn_match_in_cot.end():]

    # Also try parsing turn from the full response (digit before <action>)
    turn_match = COT_TURN_RE.search(response_text)
    if turn_match:
        turn_str_raw = turn_match.group(1)

    # Validate turn
    if turn_str_raw is not None:
        try:
            turn = int(turn_str_raw)
            if 0 <= turn <= 4:
                result['turn'] = turn
            else:
                result['format_error_reason'] = f'turn_out_of_range: {turn}'
                return result
        except (ValueError, IndexError):
            result['format_error_reason'] = f'bad_turn: {turn_str_raw}'
            return result
    else:
        result['format_error_reason'] = 'no_turn_found'
        return result

    # Check if anything non-whitespace remains in the COT part
    remainder_clean = remainder.strip()
    if remainder_clean:
        result['format_error_reason'] = f'extra_tokens_in_cot: "{remainder_clean}"'
        result['extra_tokens'] = [remainder_clean]
        return result

    # All checks passed
    result['format_valid'] = True
    return result


def compute_cot_score(
    response_text,
    select_road_ids,
    select_road_cls,
    road_graphs,
    all_cand_gts,
    abs_traj,
    traj_is_successful=False,
):
    """Compute COT scoring for <COT> mode.

    Scoring rules:
      1. 全对框（方向+视角+中心）: +0.5 per box, normalized by num_gt
      2. 仅方向对框: +0.2 per box, normalized by num_gt
      3. GT_Direction→Meta不冲突: +0.3 if no GT forbidden road direction matches predicted turn (not heading into forbidden road)
      4. Meta→Trajectory一致: +0.4 if predicted turn matches trajectory turn (only effective traj: no forbidden road entry, crash<2)
      5. Format错误: -0.5
      6. 框数不匹配: -abs(num_pred - num_gt) × 0.2, normalized by num_gt（多检/漏检惩罚）
         Box子分数公式: (raw_box_bonus - raw_count_penalty) / num_gt

    Args:
        response_text: model's full output text
        select_road_ids: list of road IDs
        select_road_cls: list of road classes (same length)
        road_graphs: dict of road_id → {geometry, ...}
        all_cand_gts: list of lists of GT clue strings (one list per road)
        abs_traj: absolute trajectory from action parsing (or None)
        traj_is_successful: whether trajectory is effective (no forbidden road entry AND crash<2)

    Returns:
        (cot_score: float, cot_details: dict)
    """
    cot_details = {
        'score': 0.0,
        'direction_full_correct': 0,
        'direction_only_correct': 0,
        'direction_total': 0,
        'format_error': False,
        'direction_meta_no_conflict': False,
        'meta_traj_match': False,
        'pred_turn': None,
        'traj_turn': None,
        'parsed': None,
        'raw_box_bonus': 0.0,
        'raw_count_penalty': 0.0,
        'box_score': 0.0,
        'num_pred_boxes': 0,
        'num_gt_roads': 0,
    }

    # ── Parse COT response ──
    parsed = parse_cot_response(response_text)
    cot_details['parsed'] = parsed

    score = 0.0

    # ── 1. Format check: -0.5 ──
    if not parsed['format_valid']:
        score -= COT_FORMAT_PENALTY
        cot_details['format_error'] = True
        cot_details['score'] = round(score, 4)
        return score, cot_details

    # ── Build GT for each forbidden road (used by both box matching and direction→meta conflict check) ──
    forbidden_roads_gt = []  # list of {road_id, dir_token, clues: [(cam, box), ...]}
    for rid, rcls, cand_gts in zip(select_road_ids, select_road_cls, all_cand_gts):
        rcls_str = str(rcls) if rcls is not None else ''
        if rcls_str not in FORBIDDEN_ROAD_CLASSES:
            continue
        road_data = road_graphs.get(rid, {})
        geometry = road_data.get('geometry', [])
        if geometry and len(geometry) >= 2:
            angle_deg = compute_road_direction_angle(geometry)
            dir_token = angle_to_direction_token(angle_deg)
        else:
            dir_token = None
        clues = []
        if isinstance(cand_gts, (list, np.ndarray)):
            for clue_str in cand_gts:
                parsed_clue = parse_gt_clue(clue_str)
                if parsed_clue:
                    clues.append(parsed_clue)
        forbidden_roads_gt.append({
            'road_id': rid,
            'dir_token': dir_token,
            'clues': clues,
        })

    cot_details['direction_total'] = len(forbidden_roads_gt)

    # ── 2. Box correctness: +0.5 full match, +0.2 direction-only (normalized by num_gt) ──
    raw_box_bonus = 0.0  # accumulated before normalization
    if parsed['has_clue'] and parsed['segments']:
        # ── Greedy matching: each GT road → best unmatched predicted segment ──
        if forbidden_roads_gt and parsed['segments']:
            available = list(range(len(parsed['segments'])))

            for gt_road in forbidden_roads_gt:
                gt_dir = gt_road['dir_token']
                gt_clues = gt_road['clues']

                if gt_dir is None:
                    continue

                best_idx = None
                best_score = -1  # -1=no_match, 2=full(dir+cam+center), 1=dir+cam, 0=dir_only

                for j in available:
                    pred_seg = parsed['segments'][j]

                    # Direction must match at meta-action level (110↔111, 112↔113, 114↔115)
                    if DIR_TOKEN_TO_META_ACTION.get(pred_seg['dir_token']) != DIR_TOKEN_TO_META_ACTION.get(gt_dir):
                        continue

                    # Check camera and center match against GT clues
                    full_match = False
                    dir_cam_match = False
                    for gt_cam, gt_box in gt_clues:
                        if pred_seg['cam_token'] == gt_cam:
                            dir_cam_match = True
                            if point_in_box(pred_seg['cx'], pred_seg['cy'], gt_box):
                                full_match = True
                                break

                    if full_match:
                        cand_score = 2
                    elif dir_cam_match:
                        cand_score = 1
                    else:
                        cand_score = 0  # direction match only

                    if cand_score > best_score:
                        best_score = cand_score
                        best_idx = j
                        if cand_score == 2:
                            break  # can't do better than full match

                if best_idx is not None:
                    if best_score == 2:
                        cot_details['direction_full_correct'] += 1
                        raw_box_bonus += COT_DIRECTION_CORRECT_BONUS  # +0.5
                    else:
                        cot_details['direction_only_correct'] += 1
                        raw_box_bonus += COT_DIRECTION_ONLY_BONUS  # +0.2
                    available.remove(best_idx)

    # ── 2.5. 框数不匹配惩罚（多检/漏检）: -abs(num_pred - num_gt) × 0.2 ──
    num_pred_boxes = len(parsed['segments']) if parsed['has_clue'] else 0
    num_gt_roads = len(forbidden_roads_gt)
    num_diff = abs(num_pred_boxes - num_gt_roads)
    raw_count_penalty = num_diff * COT_COUNT_MISMATCH_PENALTY if num_diff > 0 else 0.0

    # ── Normalize box reward by num_gt so multi-box scenes don't dominate ──
    raw_box_score = raw_box_bonus - raw_count_penalty
    if num_gt_roads > 0:
        box_score = raw_box_score / num_gt_roads
    else:
        box_score = raw_box_score  # no GT boxes; raw_count_penalty for false positives stands as-is

    score += box_score
    cot_details['raw_box_bonus'] = raw_box_bonus
    cot_details['raw_count_penalty'] = raw_count_penalty
    cot_details['box_score'] = round(box_score, 4)
    cot_details['num_pred_boxes'] = num_pred_boxes
    cot_details['num_gt_roads'] = num_gt_roads

    # ── 3. Direction→Meta不冲突: +0.3 if no GT forbidden road direction matches predicted turn ──
    # GT 禁行框方向是不能走的方向，meta action 与其不冲突说明模型不朝禁行方向行驶
    pred_turn = parsed['turn']
    cot_details['pred_turn'] = pred_turn

    if pred_turn is not None and pred_turn in (0, 1, 2) and forbidden_roads_gt:
        has_conflict = any(
            DIR_TOKEN_TO_META_ACTION.get(gt_road['dir_token']) == pred_turn
            for gt_road in forbidden_roads_gt
            if gt_road['dir_token'] is not None
        )
        if not has_conflict:
            score += COT_DIRECTION_META_NO_CONFLICT
            cot_details['direction_meta_no_conflict'] = True

    # ── 4. Meta→Trajectory一致: +0.4 (仅有效轨迹: 未进入禁行路，且碰撞数<2) ──
    if traj_is_successful and abs_traj is not None and len(abs_traj) >= 2 and pred_turn is not None:
        traj_turns = calculate_meta_action_from_trajectory(abs_traj)
        if traj_turns:
            traj_turn_name = traj_turns[0]
            traj_turn_id = {"左转": 0, "直行": 1, "右转": 2, "掉头": 3, "未知": 4}.get(traj_turn_name, 4)
            cot_details['traj_turn'] = traj_turn_name
            if traj_turn_id == pred_turn:
                score += COT_META_TRAJ_MATCH_BONUS
                cot_details['meta_traj_match'] = True

    cot_details['score'] = round(score, 4)
    return score, cot_details


# ═══════════════════════════════════════════════════════════════════════════════
#  Intersection detection (from v3)
# ═══════════════════════════════════════════════════════════════════════════════

def find_nearest_road_to_point(point, all_road_geoms):
    best_road_id = None
    best_dist = float('inf')
    best_pt = None
    point_arr = np.asarray(point, dtype=float)
    for road_id, geom in all_road_geoms.items():
        d, pt = _min_distance_point_to_polyline(point_arr, geom)
        if d < best_dist:
            best_dist = d
            best_pt = pt
            best_road_id = road_id
    return best_road_id, best_dist, best_pt


def detect_intersection_distance(
    all_road_geoms,
    endpoint_dist_threshold=INTERSECTION_ENDPOINT_DIST_THRESHOLD,
    min_connected_roads=INTERSECTION_MIN_CONNECTED_ROADS,
):
    result = {
        "is_intersection": False, "distance": None,
        "num_connected_roads": 0, "origin_road_id": None,
        "intersection_point": None, "forward_endpoint": None,
        "closest_pt": None, "connected_road_ids": set(),
    }
    if len(all_road_geoms) < 2:
        return result

    origin = np.array([0.0, 0.0])
    origin_road_id, _, closest_pt = find_nearest_road_to_point(origin, all_road_geoms)
    if origin_road_id is None:
        return result

    result["origin_road_id"] = origin_road_id
    result["closest_pt"] = closest_pt
    origin_geom = all_road_geoms[origin_road_id]

    car_heading = np.array([1.0, 0.0])
    endpoints = [origin_geom[0], origin_geom[-1]]
    forward_endpoint = None

    for ep in endpoints:
        road_dir = ep - closest_pt
        road_dir_norm = np.linalg.norm(road_dir)
        if road_dir_norm < 1e-6:
            continue
        if np.dot(road_dir / road_dir_norm, car_heading) > 0:
            forward_endpoint = ep
            break

    if forward_endpoint is None:
        forward_endpoint = origin_geom[0] if origin_geom[0][0] > origin_geom[-1][0] else origin_geom[-1]

    connected_road_ids = set()
    for rid, geom in all_road_geoms.items():
        if rid == origin_road_id:
            continue
        for ep in [geom[0], geom[-1]]:
            if np.linalg.norm(ep - forward_endpoint) <= endpoint_dist_threshold:
                connected_road_ids.add(rid)
                break

    result["num_connected_roads"] = len(connected_road_ids)
    result["forward_endpoint"] = forward_endpoint
    result["connected_road_ids"] = connected_road_ids

    if len(connected_road_ids) < min_connected_roads:
        return result

    result["is_intersection"] = True
    result["intersection_point"] = forward_endpoint
    result["distance"] = float(np.linalg.norm(forward_endpoint - origin))
    return result


def get_intersection_penalty(intersection_distance: Optional[float]) -> float:
    """根据到交叉点的距离返回固定禁行路扣分值。"""
    if intersection_distance is None:
        return FORBIDDEN_PENALTY_FAR
    if intersection_distance < INTERSECTION_NEAR_6M:
        return FORBIDDEN_PENALTY_NEAR
    elif intersection_distance < INTERSECTION_NEAR_12M:
        return FORBIDDEN_PENALTY_MEDIUM
    return FORBIDDEN_PENALTY_FAR

# ═══════════════════════════════════════════════════════════════════════════════
#  Unsafe-mask / wall-crash helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _decode_rle_mask(rle):
    if not rle or 'counts' not in rle or 'size' not in rle:
        return None
    try:
        from pycocotools import mask as coco_mask
        counts = rle['counts']
        if isinstance(counts, str):
            counts = counts.encode('utf-8')
        return coco_mask.decode({'size': rle['size'], 'counts': counts}).astype(np.uint8)
    except ImportError:
        pass
    try:
        h, w = rle['size']
        counts = rle['counts']
        if isinstance(counts, str):
            counts = counts.encode('utf-8')
        mask = np.zeros(h * w, dtype=np.uint8)
        counts_list = list(counts)
        pos, val = 0, 0
        i = 0
        while i < len(counts_list):
            x, k = 0, 0
            more = True
            while more:
                c = counts_list[i] - 48
                x |= (c & 0x1f) << (5 * k)
                more = c & 0x20
                i += 1; k += 1
                if not more and (c & 0x10):
                    x |= -1 << (5 * k)
            for _ in range(x):
                if pos < len(mask):
                    mask[pos] = val; pos += 1
            val = 1 - val
        return mask.reshape((h, w), order='F')
    except Exception:
        return None


def bev_to_mask_coords(x_m, y_m, mask_size=600):
    scale = 60.0 / mask_size
    offset = 30.0
    row = int(round((offset - x_m) / scale))
    col = int(round((-y_m + offset) / scale))
    if 0 <= row < mask_size and 0 <= col < mask_size:
        return (row, col)
    return None


def get_unsafe_masks(freespace_info):
    if not freespace_info:
        return []
    unsafe_rle = freespace_info.get('unsafe')
    if not unsafe_rle:
        return []
    mask = _decode_rle_mask(unsafe_rle)
    return [mask] if mask is not None else []


def check_traj_crash_into_wall(abs_traj, unsafe_masks, min_points=BINDING_MIN_POINTS):
    if abs_traj is None or len(abs_traj) < min_points:
        return False, {'reason': 'no_crash'}
    if not unsafe_masks:
        return False, {'reason': 'no_crash'}
    traj_points = abs_traj[:min_points]
    unsafe_indices = []
    for idx, pt in enumerate(traj_points):
        for mask in unsafe_masks:
            h, w = mask.shape
            pixel = bev_to_mask_coords(float(pt[0]), float(pt[1]), mask_size=h)
            if pixel is not None:
                r, c = pixel
                if mask[r, c] == 1:
                    unsafe_indices.append(idx)
                    break
    num_unsafe = len(unsafe_indices)
    if num_unsafe >= 2:
        return True, {'reason': 'crash_into_wall', 'unsafe_points': unsafe_indices,
                      'num_unsafe': num_unsafe}
    return False, {'reason': 'no_crash'}

# ═══════════════════════════════════════════════════════════════════════════════
#  Core: segment-binding violation check
# ═══════════════════════════════════════════════════════════════════════════════

def check_traj_violation_by_binding(
    abs_traj, all_road_geoms, road_id_to_cls, forbidden_ids,
    unsafe_masks=None, min_points=BINDING_MIN_POINTS,
):
    if abs_traj is None or len(abs_traj) < min_points:
        return True, {'reason': 'trajectory_too_short',
                      'num_points': len(abs_traj) if abs_traj is not None else 0}
    origin = np.array([[0.0, 0.0]])
    full_traj = np.vstack([origin, abs_traj[:min_points]])
    for i in range(len(full_traj) - 2):
        segment = full_traj[i:i + 3]
        road_id, info = bind_segment_to_road(segment, all_road_geoms)
        if road_id is not None and road_id in forbidden_ids:
            return True, {
                'reason': 'segment_binds_to_forbidden_road',
                'segment_idx': i, 'road_id': road_id,
                'road_cls': road_id_to_cls.get(road_id, 'unknown'),
                'binding_info': info,
            }
    if unsafe_masks:
        is_crash, crash_details = check_traj_crash_into_wall(abs_traj, unsafe_masks, min_points)
        if is_crash:
            return True, crash_details
    return False, {'reason': 'no_violation'}

# ═══════════════════════════════════════════════════════════════════════════════
#  Reward interface
# ═══════════════════════════════════════════════════════════════════════════════

class TaskVLANoEntryReward:
    """VLA no-entry reward v4.2: v4 base + COT scoring branch.

    Detects <NO_COT> or <COT> in extra_info["question"] to decide scoring mode:
      - <NO_COT>: same as v4 (intersection-weighted penalty + exit-direction bonus)
      - <COT>: v4 action scoring + COT box/turn scoring
    """

    def __init__(self, debug=False, debug_dir="/tmp/vla_reward_test"):
        self._last_details = {}
        self._debug = debug
        self._step = 0
        self._debug_first_n = 200
        self._debug_log_every = 20
        self._debug_dir = debug_dir or os.environ.get('VLA_DEBUG_DIR') or '/tmp/vla_reward_debug'

    def __call__(self, data_source, solution_str, ground_truth, extra_info):
        self._step += 1
        return self.compute_score(data_source, solution_str, ground_truth, extra_info)

    def _dbg(self, msg):
        if self._debug:
            with open("/tmp/vla_reward_debug.log", "a") as f:
                f.write(msg + "\n")

    def _extract_kwargs(self, extra_info):
        tools_kwargs = extra_info.get('tools_kwargs', {})
        reward_cfg = tools_kwargs.get('calc_no-entry_reward', {})
        return reward_cfg.get('calc_reward_kwargs', {})

    def compute_score(self, data_source, solution_str, ground_truth, extra_info):
        kwargs = self._extract_kwargs(extra_info)
        clip_id = extra_info.get('clip_id', '?')
        vocab_path = kwargs.get('vocab_path', None)

        # ── Parse road data ──
        road_graphs     = json.loads(kwargs.get('road_graphs', '{}'))
        select_road_ids = json.loads(kwargs.get('select_road_ids', '[]'))
        select_road_cls = json.loads(kwargs.get('select_road_cls', '[]'))
        freespace_info  = json.loads(kwargs.get('freespace_info', '{}'))

        # ── v4 new fields ──
        vla_goal_point = json.loads(kwargs.get('vla_goal_point', '{}'))
        has_exit_sign  = json.loads(kwargs.get('has_exit_sign', 'false'))

        # ── Identify forbidden roads ──
        forbidden_ids = get_forbidden_road_ids(select_road_ids, select_road_cls)

        action_traj = None
        abs_traj = None

        action_traj = parse_action_traj(solution_str, vocab_path=vocab_path)

        all_road_geoms = get_all_road_geometries(road_graphs)
        road_id_to_cls = get_road_id_to_cls(select_road_ids, select_road_cls)
        unsafe_masks = get_unsafe_masks(freespace_info)

        # ── Intersection detection (v3) ──
        intersection_info = detect_intersection_distance(all_road_geoms)
        intersection_distance = intersection_info.get("distance")
        forbidden_penalty = get_intersection_penalty(intersection_distance)

        if action_traj is not None:
            abs_traj = action_traj_to_abs(action_traj)

        # ── v4: Exit direction check ──
        exit_bonus = 0.0
        follows_exit = False
        exit_details = {}

        if abs_traj is not None and len(abs_traj) >= 2:
            follows_exit, exit_bonus, exit_details = check_trajectory_follows_exit_direction(
                abs_traj, all_road_geoms, vla_goal_point, has_exit_sign,
                intersection_distance,
            )

        _base_result = {
            "score": 0.0, "reason": "", "details": {},
            "num_points": 0, "required": BINDING_MIN_POINTS,
        }

        if action_traj is None:
            # Even with no trajectory, exit bonus could apply but we can't check direction
            result = dict(_base_result, score=-4.0 + exit_bonus,
                          reason="no_trajectory_parsed",
                          details={"reason": "no_trajectory_parsed",
                                   "exit_bonus": exit_bonus,
                                   "exit_details": exit_details})
            self._last_details = {'reason': 'no_trajectory_parsed'}
        elif not all_road_geoms and not unsafe_masks:
            result = dict(_base_result, score=exit_bonus,
                          reason="no_road_geometries",
                          details={"reason": "no_road_geometries",
                                   "exit_bonus": exit_bonus,
                                   "exit_details": exit_details})
            self._last_details = {'reason': 'no_road_geometries'}
        else:
            num_points = len(abs_traj) if abs_traj is not None else 0
            if num_points < BINDING_MIN_POINTS:
                result = dict(_base_result, score=round(-3.0 + exit_bonus, 4),
                              reason="trajectory_too_short",
                              num_points=num_points,
                              required=BINDING_MIN_POINTS,
                              details={"reason": "trajectory_too_short",
                                       "num_points": num_points,
                                       "exit_bonus": exit_bonus,
                                       "exit_details": exit_details})
                self._last_details = {'reason': 'trajectory_too_short',
                                      'num_points': num_points}
            elif not forbidden_ids:
                if unsafe_masks:
                    is_crash, crash_details = check_traj_crash_into_wall(
                        abs_traj, unsafe_masks, min_points=BINDING_MIN_POINTS)
                    if is_crash:
                        penalty = min(crash_details.get('num_unsafe', 1),
                                      BINDING_MIN_POINTS) * WALL_PENALTY
                        result = dict(_base_result, score=round(-penalty + exit_bonus, 4),
                                      reason="crash_into_wall",
                                      details={**crash_details, "exit_bonus": exit_bonus,
                                               "exit_details": exit_details})
                        self._last_details = crash_details
                    else:
                        result = dict(_base_result, score=round(exit_bonus, 4),
                                      reason="no_forbidden_roads",
                                      details={"reason": "no_forbidden_roads",
                                               "exit_bonus": exit_bonus,
                                               "exit_details": exit_details})
                        self._last_details = {'reason': 'no_forbidden_roads'}
                else:
                    result = dict(_base_result, score=round(exit_bonus, 4),
                                  reason="no_forbidden_roads",
                                  details={"reason": "no_forbidden_roads",
                                           "exit_bonus": exit_bonus,
                                           "exit_details": exit_details})
                    self._last_details = {'reason': 'no_forbidden_roads'}
            else:
                is_violation, details = check_traj_violation_by_binding(
                    abs_traj, all_road_geoms, road_id_to_cls, forbidden_ids,
                    unsafe_masks=unsafe_masks,
                )

                if not is_violation:
                    result = dict(_base_result, score=round(exit_bonus, 4),
                                  reason="correct",
                                  details={**details, "exit_bonus": exit_bonus,
                                           "exit_details": exit_details})
                    self._last_details = {'reason': 'correct'}
                else:
                    reason = details.get('reason', 'unknown')
                    score = 0.0
                    if reason == 'segment_binds_to_forbidden_road':
                        # ── v3: Apply intersection-distance-based fixed penalty ──
                        score -= forbidden_penalty
                        details['intersection_distance'] = intersection_distance
                        details['forbidden_penalty'] = forbidden_penalty
                    elif reason == 'crash_into_wall':
                        score -= min(details.get('num_unsafe', 1),
                                     BINDING_MIN_POINTS) * WALL_PENALTY

                    # ── v4: Add exit bonus ──
                    score += exit_bonus
                    details['exit_bonus'] = exit_bonus
                    details['exit_details'] = exit_details

                    result = dict(_base_result, score=round(score, 4),
                                  reason=reason, details=details)
                    self._last_details = details

        # ── v4.2: COT scoring branch ──
        question = extra_info.get('question', '')
        is_cot = '<COT>' in question

        cot_score = 0.0
        cot_details = {}
        if is_cot:
            # Trajectory is considered effective if:
            #  - did NOT enter forbidden road, AND
            #  - crash count < 2 (minor collision tolerable)
            traj_is_successful = (
                result['reason'] in ('correct', 'no_forbidden_roads', 'no_road_geometries')
                or (
                    result['reason'] == 'crash_into_wall'
                    and result.get('details', {}).get('num_unsafe', 0) < 2
                )
            )

            # Get GT clues for camera/center matching
            all_cand_gts = kwargs.get('ground_truth', [])
            if isinstance(all_cand_gts, str):
                try:
                    all_cand_gts = json.loads(all_cand_gts)
                except (json.JSONDecodeError, TypeError):
                    all_cand_gts = []

            try:
                cot_score, cot_details = compute_cot_score(
                    response_text=solution_str,
                    select_road_ids=select_road_ids,
                    select_road_cls=select_road_cls,
                    road_graphs=road_graphs,
                    all_cand_gts=all_cand_gts,
                    abs_traj=abs_traj,
                    traj_is_successful=traj_is_successful,
                )
            except Exception:
                logger.warning(
                    f"COT scoring failed for clip_id={clip_id}, returning cot_score=0. "
                    f"Missing data or unexpected error.",
                    exc_info=True,
                )
                cot_score = 0.0
                cot_details = {'error': 'cot_scoring_failed'}

        # ── Add COT score to v4 base score ──
        if is_cot and cot_score != 0.0:
            result['score'] = round(result['score'] + cot_score, 4)
            result['details']['cot_score'] = cot_score
            result['details']['cot_details'] = cot_details

        # ── Build GDPO diff_score ──
        diff_list, dim_dict = self._build_diff_score(result, forbidden_penalty, exit_bonus, is_cot)
        result['diff_score'] = diff_list
        result.update(dim_dict)

        # ── Debug ──
        if self._debug:
            abs_traj_list = abs_traj.tolist() if abs_traj is not None else None
            all_road_geoms_serializable = {}
            _geoms = get_all_road_geometries(road_graphs)
            for rid, g in _geoms.items():
                all_road_geoms_serializable[rid] = g.tolist()
            _road_id_to_cls = get_road_id_to_cls(select_road_ids, select_road_cls)

            debug_data = {
                'clip_id': clip_id, 'data_source': data_source, 'step': self._step,
                'solution_str': solution_str, 'action_traj': action_traj,
                'abs_traj': abs_traj_list,
                'diff_score': result.get('diff_score', []),
                'forbidden_ids': forbidden_ids,
                'select_road_ids': select_road_ids,
                'select_road_cls': select_road_cls,
                'road_id_to_cls': _road_id_to_cls,
                'all_road_geoms': all_road_geoms_serializable,
                'freespace_info': freespace_info,
                'vocab_path': vocab_path,
                'result': result,
                # v3/v4-specific
                'intersection_distance': intersection_distance,
                'forbidden_penalty': forbidden_penalty,
                'intersection_info': {
                    k: (v.tolist() if isinstance(v, np.ndarray) else
                        list(v) if isinstance(v, set) else v)
                    for k, v in intersection_info.items()
                },
                'vla_goal_point': vla_goal_point,
                'has_exit_sign': has_exit_sign,
                'exit_bonus': exit_bonus,
                'follows_exit': follows_exit,
                'exit_details': exit_details,
                # v4.2 COT
                'is_cot': is_cot,
                'cot_score': cot_score,
                'cot_details': cot_details,
            }
            self._log_model_output(solution_str, action_traj, abs_traj, result, debug_data)

        result['debug'] = {
            'clip_id': clip_id, 'data_source': data_source,
            'forbidden_ids': forbidden_ids,
            'score': result['score'], 'reason': result['reason'],
            'diff_score': result.get('diff_score', []),
            'intersection_distance': intersection_distance,
            'forbidden_penalty': forbidden_penalty,
            'has_exit_sign': has_exit_sign,
            'exit_bonus': exit_bonus,
            'follows_exit': follows_exit,
            # v4.2 COT
            'is_cot': is_cot,
            'cot_score': cot_score,
        }

        return result

    def _log_model_output(self, solution_str, action_traj, abs_traj, result, debug_data):
        if not self._debug:
            return
        score = result.get('score', '?')
        reason = result.get('reason', '?')
        diff_score = result.get('diff_score', [])
        clip_id = debug_data.get('clip_id', '?')
        if self._step <= self._debug_first_n:
            self._dbg(f"=== VLA-Reward-v4.2 step={self._step} FULL DUMP ===")
            self._dbg(f"  clip_id:         {clip_id}")
            self._dbg(f"  score:           {score}")
            self._dbg(f"  reason:          {reason}")
            self._dbg(f"  diff_score:      {diff_score}")
            self._dbg(f"  intersection:    dist={debug_data.get('intersection_distance')} "
                      f"penalty={debug_data.get('forbidden_penalty')}")
            self._dbg(f"  exit:            bonus={debug_data.get('exit_bonus')} "
                      f"follows={debug_data.get('follows_exit')} "
                      f"sign={debug_data.get('has_exit_sign')}")
            self._dbg(f"  cot:             is_cot={debug_data.get('is_cot')} "
                      f"cot_score={debug_data.get('cot_score')}")
            self._dbg(f"  vla_goal_point:  {debug_data.get('vla_goal_point')}")
            self._dbg(f"  forbidden:       {debug_data.get('forbidden_ids', set())}")
            self._dbg(f"  sol_len:         {len(solution_str)}")
            self._dbg(f"  solution_str ({len(solution_str)} chars):")
            self._dbg(f"  {repr(solution_str)}")
        elif self._step % self._debug_log_every == 0:
            self._dbg(f"VLA-Reward-v4.2 step={self._step} | score={score} "
                      f"reason={reason} diff={diff_score} "
                      f"inter_dist={debug_data.get('intersection_distance')} "
                      f"penalty={debug_data.get('forbidden_penalty')} "
                      f"exit_bonus={debug_data.get('exit_bonus')} "
                      f"exit_sign={debug_data.get('has_exit_sign')} "
                      f"cot={debug_data.get('is_cot')}/{debug_data.get('cot_score')} "
                      f"sol_len={len(solution_str)}")

    @staticmethod
    def _build_diff_score(result, forbidden_penalty=FORBIDDEN_PENALTY_FAR, exit_bonus=0.0, is_cot=False):
        """Build diff_score vector for GDPO.

        Always 4 dims for consistency: [traj_valid, forbidden, wall, cot]
        NO_COT mode: cot = 0.0
        """
        reason = result.get('reason', 'unknown')
        details = result.get('details', {})
        score = result.get('score', 0.0)

        # Dimension 0: trajectory validity
        if reason == 'no_trajectory_parsed':
            traj_valid = -4.0
        elif reason == 'trajectory_too_short':
            traj_valid = -3.0
        else:
            traj_valid = 0.0

        # Dimension 1: forbidden road avoidance
        if reason == 'segment_binds_to_forbidden_road':
            forbidden = -forbidden_penalty + exit_bonus
        elif reason in ('no_forbidden_roads', 'correct', 'no_trajectory_parsed',
                         'trajectory_too_short', 'no_road_geometries', 'no_violation'):
            forbidden = exit_bonus
        else:
            forbidden = exit_bonus

        # Dimension 2: wall safety
        if reason == 'crash_into_wall':
            n = details.get('num_unsafe', 0)
            wall = -min(n, BINDING_MIN_POINTS) * WALL_PENALTY
        elif reason in ('no_trajectory_parsed', 'trajectory_too_short', 'no_road_geometries'):
            wall = 0.0
        else:
            wall = 0.0

        diff_list = [traj_valid, forbidden, wall]
        dim_dict = {'diff_traj_valid': traj_valid, 'diff_forbidden': forbidden,
                    'diff_wall': wall}

        # Dimension 3: COT score (always present; 0.0 in NO_COT mode)
        cot_dim = details.get('cot_score', 0.0)
        diff_list.append(cot_dim)
        dim_dict['diff_cot'] = cot_dim

        if abs(sum(diff_list) - score) > 0.02:
            logger.warning(
                f"diff_score sum ({sum(diff_list)}) != total score ({score}); "
                f"reason={reason}, diff={diff_list}"
            )

        return diff_list, dim_dict

    @property
    def last_details(self):
        return self._last_details


# ═══════════════════════════════════════════════════════════════════════════════
#  Top-level function
# ═══════════════════════════════════════════════════════════════════════════════

_scorer = None
_scorer_debug = None

def vla_no_entry_reward(data_source, solution_str, ground_truth, extra_info,
                        debug=True, reward_version=None, iou_threshold=None,
                        debug_dir=None, **kwargs):
    global _scorer, _scorer_debug
    if _scorer is None or _scorer_debug != debug:
        _scorer = TaskVLANoEntryReward(debug=debug, debug_dir=debug_dir)
        _scorer_debug = debug
    return _scorer(data_source, solution_str, ground_truth, extra_info)

# ═══════════════════════════════════════════════════════════════════════════════
#  __main__ — quick test
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import pandas as pd

    PARQUET_PATH = "/perception-hl/beijin.zhou/deeprl/v1_data/vla_train_out_no_entry_260526_train__df5f809__20260528070111_part2_part0003.parquet"
    NUM_SAMPLES = 3

    print(f"Loading parquet: {PARQUET_PATH}")
    df = pd.read_parquet(PARQUET_PATH)
    print(f"  {len(df)} samples\n")

    scorer = TaskVLANoEntryReward(debug=True, debug_dir='/tmp/vla_reward_debug')

    for i in range(min(NUM_SAMPLES, len(df))):
        row = df.iloc[i]
        extra_info = row['extra_info']
        kwargs = extra_info['tools_kwargs']['calc_no-entry_reward']['calc_reward_kwargs']

        select_road_ids = json.loads(kwargs['select_road_ids'])
        select_road_cls = json.loads(kwargs['select_road_cls'])
        forbidden_ids = get_forbidden_road_ids(select_road_ids, select_road_cls)
        road_graphs = json.loads(kwargs.get('road_graphs', '{}'))
        vla_goal_point = json.loads(kwargs.get('vla_goal_point', '{}'))
        has_exit_sign = json.loads(kwargs.get('has_exit_sign', 'false'))

        all_road_geoms = get_all_road_geometries(road_graphs)
        intersection_info = detect_intersection_distance(all_road_geoms)

        # Test goal→lane binding
        exit_road_id, _, exit_score, exit_debug = find_best_lane_for_goal(
            vla_goal_point, all_road_geoms)

        print(f"{'='*60}")
        print(f"Sample {i}  clip_id={extra_info['clip_id']}")
        print(f"  select_road_ids:      {select_road_ids}")
        print(f"  select_road_cls:      {select_road_cls}")
        print(f"  forbidden_ids:        {forbidden_ids}")
        print(f"  vla_goal_point:       {vla_goal_point}")
        print(f"  has_exit_sign:        {has_exit_sign}")
        print(f"  intersection dist:     {intersection_info.get('distance')}")
        print(f"  is_intersection:       {intersection_info.get('is_intersection')}")
        print(f"  num_connected:         {intersection_info.get('num_connected_roads')}")
        print(f"  forbidden_penalty:     {get_intersection_penalty(intersection_info.get('distance'))}")
        print(f"  goal→lane binding:     road={exit_road_id} score={exit_score:.3f} "
              f"debug={exit_debug}")

        if not forbidden_ids:
            print("  → No forbidden roads, skip trajectory tests")
            continue

        test_trajs = [
            ("直行", "<action>(500,500),(600,500),(700,500),(800,500),(900,500)</action>"),
            ("右转", "<action>(500,500),(550,450),(650,350),(750,250),(850,150)</action>"),
            ("左转", "<action>(500,500),(450,550),(350,650),(250,750),(150,850)</action>"),
            ("掉头", "<action>(500,500),(490,400),(500,300),(510,200),(500,100)</action>"),
        ]

        for label, traj_str in test_trajs:
            result = scorer("no-entry_v4.2", traj_str, [], extra_info)
            score = result['score']
            reason = result.get('reason', '?')
            diff = result.get('diff_score', [])
            detail = result.get('details', {})
            road_id = detail.get('road_id', '-')
            road_cls = detail.get('road_cls', '-')
            penalty = detail.get('forbidden_penalty', FORBIDDEN_PENALTY_FAR)
            exit_bon = detail.get('exit_bonus', 0.0)
            exit_det = detail.get('exit_details', {})
            print(f"  {label:4s} → score={score:6.2f}  diff={diff}  "
                  f"reason={reason:35s}  road={road_id}  cls={road_cls}  "
                  f"penalty={penalty}  exit_bonus={exit_bon}  "
                  f"exit={exit_det.get('reason', 'N/A')}")

    print(f"\n{'='*60}")
    print("Done (v4.2).")
