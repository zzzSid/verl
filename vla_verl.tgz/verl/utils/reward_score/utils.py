from collections import Counter
import re
import copy
import numpy as np
from typing import List,Dict
import json
import os
import re
import pdb
import numpy as np
import requests
import math_verify
from tqdm import tqdm
from PIL import Image
from sklearn.metrics.pairwise import cosine_similarity

from latex2sympy2_extended import NormalizationConfig
from typing import Any, Callable, Dict, List, Optional, Type, TypeVar, Tuple, Union
try:
    from math_verify.errors import TimeoutException
    from math_verify.metric import math_metric
    from math_verify.parser import ExprExtractionConfig, LatexExtractionConfig
except ImportError:
    print("To use Math-Verify, please install it first by running `pip install math-verify`.")


EPS = 1e-6
API_URL = "http://172.24.157.151:2341/embed"


################################ For Math ################################


def fix_fracs(string):
    """fix frac 把所有不规范的 \frac 写法，自动补全为带 {} 的标准格式"""
    try:
        substrs = string.split('\\frac')
        new_str = substrs[0]
        if len(substrs) > 1:
            substrs = substrs[1:]
            for substr in substrs:
                new_str += '\\frac'
                if substr[0] == '{':
                    new_str += substr
                else:
                    try:
                        assert len(substr) >= 2
                    except AssertionError:
                        return string
                    a = substr[0]
                    b = substr[1]
                    if b != '{':
                        if len(substr) > 2:
                            post_substr = substr[2:]
                            new_str += '{' + a + '}{' + b + '}' + post_substr
                        else:
                            new_str += '{' + a + '}{' + b + '}'
                    else:
                        if len(substr) > 2:
                            post_substr = substr[2:]
                            new_str += '{' + a + '}' + b + post_substr
                        else:
                            new_str += '{' + a + '}' + b
        string = new_str
        return string
    except:
        return string

def fix_a_slash_b(string):
    """
     把 '9/5' 转为 '\\frac{9}{5}'；无法解析则原样返回。
    """
    if '/' not in string:
        return string
    string = re.sub(r'[A-Za-z]', '', string)
    if len(string.split('/')) != 2:
        return string
    a = string.split('/')[0]
    b = string.split('/')[1]
    try:
        a = int(a)
        b = int(b)
        assert string == '{}/{}'.format(a, b)
        new_string = '\\frac{' + str(a) + '}{' + str(b) + '}'
        return new_string
    except Exception:
        return string

def remove_right_units(string):
    # "\\text{ " only ever occurs (at least in the val set)
    if '\\text{ ' in string:
        splits = string.split('\\text{ ')
        # assert len(splits) == 2
        return splits[-1]
    else:
        return string

def fix_sqrt(string):
    """fix sqrt"""
    if '\\sqrt' not in string:
        return string
    splits = string.split('\\sqrt')
    new_string = splits[0]
    for split in splits[1:]:
        if not split:
            new_substr = ''
        elif split[0] != '{':
            a = split[0]
            new_substr = '\\sqrt{' + a + '}' + split[1:]
        else:
            new_substr = '\\sqrt' + split
        new_string += new_substr
    return new_string

def strip_string(string):
    """
    Strip and normalize a string of math expression.
    Adapted from the MATH dataset evaluation script.
    """
    if string is None:
        return ""
    
    #[NOTE] add some normalize

    # remove chinese
    string = re.sub(r'[\u4e00-\u9fff]', '', string)

    # remove leading/trailing whitespace 
    string = str(string).strip()

    # Remove $ at start/end (common in LaTeX math)
    if string.startswith("$") and string.endswith("$"):
        string = string[1:-1]

    # Remove \boxed{...}
    if string.startswith("\\boxed"):
        string = string[7:]  # len("\boxed") = 7
        # Remove possible leading { and trailing }
        if string.startswith("{") and string.endswith("}"):
            string = string[1:-1]

    # Remove \text{...}, \mbox{...}, etc.
    string = re.sub(r"\\text{.*?}", "", string)
    string = re.sub(r"\\mbox{.*?}", "", string)

    # Replace \left, \right, \big, etc. (just remove)
    string = re.sub(r"\\left", "", string)
    string = re.sub(r"\\right", "", string)
    string = re.sub(r"\\big", "", string)

    # Remove all spaces
    string = string.replace(" ", "")

    # Normalize common expressions
    string = string.replace("^{*}", "*")  # handle ^{*}
    string = string.replace('^{\\circ}', '')   # Remove circ (degrees)
    string = string.replace('^\\circ', '')
    string = string.replace("%", "")  # remove percent sign


    # Fix common issues
    string = string.replace("=", "")  # often used in alignment
    string = string.replace(":", "")
    string = string.replace("\\dots", "")
    string = string.replace("...", "")

    # Remove common LaTeX commands
    string = string.replace("\\,", "").replace("\\!", "").replace("\\;", "")  # thin spaces
    string = string.replace("\\newline", "").replace("\\cr", "")


    # Remove any remaining { }
    string = string.replace("{", "").replace("}", "")

    # linebreaks
    string = string.replace('\n', '')

    # remove inverse spaces
    string = string.replace('\\!', '')

    # replace \\ with \
    string = string.replace('\\\\', '\\')

    # replace tfrac and dfrac with frac
    string = string.replace('tfrac', 'frac')
    string = string.replace('dfrac', 'frac')

    # remove dollar signs
    string = string.replace('\\$', '')

    # remove units (on the right)
    string = remove_right_units(string)

    # remove percentage
    string = string.replace('\\%', '')
    string = string.replace('\%', '')  # noqa: W605

    string = string.replace(' .', ' 0.')
    string = string.replace('{.', '{0.')

    # if empty, return empty string
    if len(string) == 0:
        return string
    if string[0] == '.':
        string = '0' + string

    # to consider: get rid of e.g. "k = " or "q = " at beginning
    if len(string.split('=')) == 2:
        if len(string.split('=')[0]) <= 2:
            string = string.split('=')[1]

    # fix sqrt3 --> sqrt{3}
    string = fix_sqrt(string)

    # remove spaces
    string = string.replace(' ', '')

    string = fix_fracs(string)

    # manually change 0.5 --> \frac{1}{2}
    if string == '0.5':
        string = '\\frac{1}{2}'

    string = fix_a_slash_b(string)
    string = string.replace('x \\in', '').strip()  # noqa: W605

    # a_b == a, a_{b} == a_b for bit conversion
    if string.find('_') >= 0:
        p = string.split('_')
        p[1] = p[1].replace('{', '').replace('}', '')
        string = '_'.join(p)

    # 10800 == 10,800; we only deal with single number
    if string.strip().find(' ') == -1 and string.find('(') == -1:
        string = string.replace(',', '')

    return string

def extract_answer(solution_str):
    try:
        solution_str = solution_str.lower().replace("'", '"')
        if "<answer>" in solution_str:
            match = re.search(r'<answer>(.*?)</answer>', solution_str, re.DOTALL)
            solution_str = match.group(1).strip() if match else solution_str

        if "\\boxed{" in solution_str:
            match = re.search(r'\\boxed{(.*?)}', solution_str, re.DOTALL)
            solution_str = match.group(1).strip() if match else solution_str

        solution_str = solution_str.replace(" ", "")

        if "#answer" in solution_str:
            solution_str = solution_str.split('#answer')[-1]
            
        if 'theansweris' in solution_str:
            solution_str = solution_str.split('theansweris')[-1]
        
        if 'theshortanswer' in solution_str:
            solution_str = solution_str.split('theshortanswer')[-1]
        
        if "answer" in solution_str:
            solution_str = solution_str.split('answer')[-1]
        
        return solution_str
    except:
        return solution_str
        



class Math_Extractor:

    def extract_matching_bracket(cls, target_str: str):
        if not target_str:
            return target_str
        current_nest_level = 1
        for i, ch in enumerate(target_str):
            if ch == '{':
                current_nest_level += 1
            elif ch == '}':
                current_nest_level -= 1
            if current_nest_level == 0:
                break
        return target_str[:i]

    def clean(cls, target_str: str):
        opt = target_str.strip().replace('{{', '{').replace('}}', '}')
        if not opt:
            return opt
        if opt[-1] == '.' or opt[-1] == '。':
            return opt[:-1]
        return opt

    def extract_answer(cls, pred: str, extract_last_num=False):
        if pred.find('The final answer is ') >= 0:
            x = pred[pred.find('The final answer is ') +
                     len('The final answer is '):]
            x = x[1:x.find('$.')]
            # print(x)
            return cls.clean(x)
        pred = pred.replace('{','').replace('}','')
        if pred.find('\n\nQuestion:') >= 0:
            pred = pred.split('\n\nQuestion:')[0]
            if pred.find('The answer is'):
                pred = pred[pred.find('The answer is') + len('The answer is'):]
                return cls.clean(pred)
        if pred.find('# Answer') >= 0:
            return cls.clean(pred[pred.find('# Answer') + len('# Answer'):])
        if pred.find('The answer is:') >= 0:
            return cls.clean(pred[pred.find('The answer is:') +
                                  len('The answer is:'):])
        if pred.find('####') >= 0:
            return cls.clean(pred[pred.find('####') + 4:])
        if pred.find('the short answer:') >= 0:
            return cls.clean(pred[pred.find('the short answer:') + len('the short answer:'):])
        if pred.find('the short answer is:') >= 0:
            return cls.clean(pred[pred.find('the short answer is:') + len('the short answer is:'):])
        if pred.find('answer:') >= 0:
            return cls.clean(pred[pred.find('answer:') + len('answer:'):])
        if pred.find('Answer:') >= 0:
            return cls.clean(pred[pred.find('Answer:') + len('Answer:'):])
        if pred.find('ANSWER:') >= 0:
            return cls.clean(pred[pred.find('ANSWER:') + len('ANSWER:'):])
        if pred.find('The answer is') >= 0:
            return cls.clean(pred[pred.find('The answer is') + len('The answer is'):])
        if pred.find('[answer]') >= 0:
            return cls.clean(pred[pred.find('[answer]') + len('[answer]'):])
        if pred.find('{"answer":') >= 0:
            return cls.clean(pred[pred.find('{"answer":') + len('{"answer":'):])



        if "\\boxed{" in pred:
            left = '\\boxed{'
            if pred.find(left) >= 0:
                pred = pred[pred.find(left) + len(left):]
                return cls.clean(cls.extract_matching_bracket(pred))

            if extract_last_num:
                nums = []
                opt = ''

                def contain_digit(opt):
                    for ch in opt:
                        if ch.isdigit():
                            return True
                    return False

                for ch in pred:
                    if ch.isdigit() or ch in ' ,.':
                        opt = opt + ch
                    else:
                        if contain_digit(opt):
                            nums.append(opt)
                        opt = ''
                if contain_digit(opt):
                    return cls.clean(opt)
                if nums:
                    return cls.clean(nums[-1])

        return cls.clean(pred)

################################ For Grounding ################################

def cal_iou(box1, box2):
    if isinstance(box1, str):
        box1 = list(map(int, box1.split(",")))

    if isinstance(box2, str):
        box2 = list(map(int, box2.split(",")))
    
    x1 = max(box1[0], box2[0])
    y1 = max(box1[1], box2[1])
    x2 = min(box1[2], box2[2])
    y2 = min(box1[3], box2[3])

    # 无交集
    if x2 <= x1 or y2 <= y1:
        return 0.0

    inter = (x2 - x1) * (y2 - y1)
    area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
    area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
    union = area1 + area2 - inter

    return inter / union if union > 0 else 0.0

def compute_iou(box1, box2):
    """Compute Intersection over Union (IoU) between two bounding boxes.
    
    Args:
        box1: List or tuple of 4 values [x1, y1, x2, y2] representing first box
        box2: List or tuple of 4 values [x1, y1, x2, y2] representing second box
        
    Returns:
        float: IoU value between the two boxes (0.0 to 1.0)
    """
    # Find coordinates of intersection
    inter_x1 = max(box1[0], box2[0])
    inter_y1 = max(box1[1], box2[1])
    inter_x2 = min(box1[2], box2[2])
    inter_y2 = min(box1[3], box2[3])

    # Check if boxes overlap
    if inter_x2 <= inter_x1 or inter_y2 <= inter_y1:
        return 0.0

    # Calculate intersection area
    inter_area = (inter_x2 - inter_x1) * (inter_y2 - inter_y1)

    # Calculate areas of both boxes
    box1_area = (box1[2] - box1[0]) * (box1[3] - box1[1])
    box2_area = (box2[2] - box2[0]) * (box2[3] - box2[1])

    # Calculate union area
    union_area = box1_area + box2_area - inter_area

    # Return IoU
    return float(inter_area) / union_area

def greedy_match_by_iou_max_label_first(predict_bbox, answer_bbox, iou_threshold):
    """
    Use IoU as metric to perform greedy match.
    First find the matched labels for both predict and answer.
    Then use max IoU to find the best match.
    """
    matches = []
    matched_pred_idx = set()
    for gt_idx, gt_bbox in enumerate(answer_bbox):
        label = gt_bbox["label"].lower()

        # Find the potential matches and IoU scores
        potential_matches, iou_scores = [], []
        for pred_idx, pred_bbox in enumerate(predict_bbox):
            if pred_idx in matched_pred_idx:
                continue

            pred_label = pred_bbox["label"].lower()
            if pred_label == label:
                iou = compute_iou(pred_bbox["bbox_2d"], gt_bbox["bbox_2d"])
                potential_matches.append(pred_idx)
                iou_scores.append(iou)

        if len(potential_matches) == 0:
            continue

        max_iou, max_iou_idx = np.max(iou_scores), np.argmax(iou_scores)
        if max_iou >= iou_threshold:
            matches.append({"pred_idx": potential_matches[max_iou_idx], "gt_idx": gt_idx, "iou": max_iou})
            matched_pred_idx.add(potential_matches[max_iou_idx])

    return matches

def compute_map(
        predict_bbox: List[Dict[str, Union[List[int], str]]],
        answer_bbox: List[Dict[str, Union[List[int], str]]],
        iou_threshold: Union[float, str] = "average",
    step_ratio: float = 0.5,
    ) -> Dict[str, float]:
    """
    基于固定的 det_verifier_normalized=True 和 det_reward_ratio，
    计算“greedy_match_by_iou_max_label_first”策略下的加权 IoU 得分，并输出最终分数和相关中间指标。

    Args:
        predict_bbox:
            List of 预测框字典，每个格式：
              { 'bbox_2d': [x1, y1, x2, y2], 'label': '类名' }
        answer_bbox:
            List of 真实框字典，格式同上。
        image_grid_thw:
            用于归一化的图像信息列表。例如 [[T, H, W]]，取第一项的 H、W 对预测框进行归一化。
        iou_threshold:
            用于最终加权 IoU 得分选阈值：
              - 若 "average"，则对阈值 [0.50,0.55,...,0.99] 的加权 IoU 求平均；
              - 若 "dynamic"，则根据 step_ratio 在 {0.85,0.95,0.99} 中选择；
              - 否则应为 0.50,0.55,...,0.99 之一。
        step_ratio:
            仅在 iou_threshold="dynamic" 时生效，用来区分使用 0.85/0.95/0.99。

    Returns:
        包含以下键的字典（float 值）：

        {
            'final_score',                          # 最终归一化后综合得分
            'size_penalty',                         # 长度差惩罚
            'pure_iou_score_max_label',             # “label-first”策略下 select_iou 的 weighted IoU（未乘 size_penalty）
            'weighted_iou_score_max_label',         # 加权后乘 size_penalty 的 weighted IoU
            'pure_map_score',                       # 始终为 0.0
            'pure_map50_score',                     # 始终为 0.0
            'pure_map75_score',                     # 始终为 0.0
            'weighted_map_score',                   # 始终为 0.0
            'weighted_map50_score',                 # 始终为 0.0
            'weighted_map75_score',                 # 始终为 0.0
            'report_iou_50_label_match_pure',       # IoU=0.50 时的 mean IoU
            'report_iou_50_label_match_precision',  # IoU=0.50 时的 precision
            'report_iou_50_label_match_recall',     # IoU=0.50 时的 recall
            'report_iou_75_label_match_pure',       # IoU=0.75 时的 mean IoU
            'report_iou_75_label_match_precision',  # IoU=0.75 时的 precision
            'report_iou_75_label_match_recall',     # IoU=0.75 时的 recall
            'report_iou_95_label_match_pure',       # IoU=0.95 时的 mean IoU
            'report_iou_95_label_match_precision',  # IoU=0.95 时的 precision
            'report_iou_95_label_match_recall',     # IoU=0.95 时的 recall
            'report_iou_99_label_match_pure',       # IoU=0.99 时的 mean IoU
            'report_iou_99_label_match_precision',  # IoU=0.99 时的 precision
            'report_iou_99_label_match_recall',     # IoU=0.99 时的 recall
        }
    """

    # ————————————————————————————————
    # 0. 将新版本bbox和旧版本对齐
    # ————————————————————————————————

    def extract_box_content(input_str):
        """提取所有<box>标签内的内容"""
        pattern = r'<box>(.*?)</box>'
        matches = re.findall(pattern, input_str)
        if len(matches) > 0:
            nums = [int(x) for x in matches[0].split(',')]
            return nums
        return input_str
    for obj_item in predict_bbox:
        if isinstance(obj_item['bbox_2d'], list):
            continue
        elif isinstance(obj_item['bbox_2d'], str):
            obj_item['bbox_2d'] = extract_box_content(obj_item['bbox_2d'])

    for obj_item in answer_bbox:
        if isinstance(obj_item['bbox_2d'], list):
            continue
        elif isinstance(obj_item['bbox_2d'], str):
            obj_item['bbox_2d'] = extract_box_content(obj_item['bbox_2d'])

    # ————————————————————————————————
    # 1. 固定 det_reward_ratio
    # ————————————————————————————————
    completeness_weight = 0.30000001192092896
    # 对应 iou_weight = 1.0 - completeness_weight
    iou_weight = 1.0 - completeness_weight  # = 0.699999988079071

    # det_reward_ratio 中各项权重
    weight_iou_label = 1.0
    weight_iou_iou = 0.0    # 不使用
    weight_map = 0.0
    weight_map50 = 0.0
    weight_map75 = 0.0
    norm_factor = weight_iou_label + weight_iou_iou + weight_map + weight_map50 + weight_map75  # = 1.3

    # ————————————————————————————————
    # 2. 如果没有 GT 框，所有分数归零
    # ————————————————————————————————
    if len(answer_bbox) == 0:
        return {
            'final_score': 0.0,
            'size_penalty': 0.0,
            'pure_iou_score_max_label': 0.0,
            'weighted_iou_score_max_label': 0.0,
            'pure_map_score': 0.0,
            'pure_map50_score': 0.0,
            'pure_map75_score': 0.0,
            'weighted_map_score': 0.0,
            'weighted_map50_score': 0.0,
            'weighted_map75_score': 0.0,
            'report_iou_50_label_match_pure': 0.0,
            'report_iou_50_label_match_precision': 0.0,
            'report_iou_50_label_match_recall': 0.0,
            'report_iou_75_label_match_pure': 0.0,
            'report_iou_75_label_match_precision': 0.0,
            'report_iou_75_label_match_recall': 0.0,
            'report_iou_95_label_match_pure': 0.0,
            'report_iou_95_label_match_precision': 0.0,
            'report_iou_95_label_match_recall': 0.0,
            'report_iou_99_label_match_pure': 0.0,
            'report_iou_99_label_match_precision': 0.0,
            'report_iou_99_label_match_recall': 0.0,
        }
    # ————————————————————————————————
    # 3. 对预测框进行归一化
    # ————————————————————————————————
    # 不需要归一化，默认都是 0-100 相对坐标

    # ————————————————————————————————
    # 4. 计算 size_penalty：0.6 ^ |n_pred - n_gt|
    # ————————————————————————————————
    size_penalty_ratio = 0.6
    size_penalty = size_penalty_ratio ** abs(len(predict_bbox) - len(answer_bbox))

    # ————————————————————————————————
    # 5. 定义函数：计算指定阈值下 “label-first” 策略的 IoU 指标
    # ————————————————————————————————
    def compute_label_first_iou(
        p_boxes: List[Dict[str, Union[List[int], str]]],
        gt_boxes: List[Dict[str, Union[List[int], str]]],
        iou_thr: float
    ) -> Dict[str, float]:
        """
        使用 greedy_match_by_iou_max_label_first 计算匹配结果：
          返回字典 {
            'mean_iou_score': ...,
            'precision': ...,
            'recall': ...,
            'weighted_iou_score': ...
          }
        """

        # matches 列表中每个元素 { 'pred_idx': i, 'gt_idx': j, 'iou': val }
        matches = greedy_match_by_iou_max_label_first(p_boxes, gt_boxes, iou_thr)
        num_matches = len(matches)
        num_gt = len(gt_boxes)
        num_pred = len(p_boxes)

        # mean_iou_score = IoU 之和 / num_gt（若 matches=0，则为 0）
        if num_matches > 0:
            mean_iou_score = sum(m["iou"] for m in matches) / num_gt
        else:
            mean_iou_score = 0.0

        miss_rate = (num_gt - num_matches) / num_gt
        false_alarm_rate = 0.0 if num_pred == 0 else (num_pred - num_matches) / num_pred

        precision = 1.0 - false_alarm_rate
        recall = 1.0 - miss_rate
        completeness_score = 1.0 - 0.5 * (miss_rate + false_alarm_rate)

        weighted_iou_score = mean_iou_score * iou_weight + completeness_score * completeness_weight

        return {
            'mean_iou_score': mean_iou_score,
            'precision': precision,
            'recall': recall,
            'weighted_iou_score': weighted_iou_score
        }

    # ————————————————————————————————
    # 6. 对 11 个阈值 [0.50, 0.55, …, 0.99] 计算 “label-first” 的 IoU 指标
    # ————————————————————————————————
    iou_thresholds = [0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95, 0.99]
    label_first_results = {}
    for thr in iou_thresholds:
        label_first_results[thr] = compute_label_first_iou(predict_bbox, answer_bbox, thr)

    # 计算“average”阈值下的加权 IoU 平均值
    avg_weighted = sum(label_first_results[thr]['weighted_iou_score'] for thr in iou_thresholds) / len(iou_thresholds)
    label_first_results['average'] = {'weighted_iou_score': avg_weighted}

    # ————————————————————————————————
    # 7. 选取最终阈值 select_iou（与原逻辑相同）
    # ————————————————————————————————
    if isinstance(iou_threshold, str) and iou_threshold == "dynamic":
        if step_ratio <= 0.1:
            select_iou = 0.85
        elif step_ratio <= 0.25:
            select_iou = 0.95
        else:
            select_iou = 0.99
    elif isinstance(iou_threshold, str) and iou_threshold == "average":
        select_iou = "average"
    else:
        select_iou = float(iou_threshold)
        if select_iou not in iou_thresholds:
            raise ValueError(f"Invalid iou_threshold: {select_iou}")

    # ————————————————————————————————
    # 8. 提取 pure_iou_score_max_label
    # ————————————————————————————————
    if select_iou == "average":
        pure_iou_score_max_label = label_first_results['average']['weighted_iou_score']
    else:
        pure_iou_score_max_label = label_first_results[select_iou]['weighted_iou_score']

    # 考虑 size_penalty 后，得到 weighted_iou_score_max_label
    weighted_iou_score_max_label = pure_iou_score_max_label * size_penalty

    # ————————————————————————————————
    # 9. COCO mAP 部分全置为 0（权重为 0）
    # ————————————————————————————————
    pure_map_score = pure_map50_score = pure_map75_score = 0.0
    weighted_map_score = weighted_map50_score = weighted_map75_score = 0.0

    # ————————————————————————————————
    # 10. 计算最终分数：只用 weighted_iou_score_max_label * weight_iou_label / norm_factor
    # ————————————————————————————————
    final_score = (weighted_iou_score_max_label * weight_iou_label) / norm_factor

    # ————————————————————————————————
    # 11. 从 label_first_results 中提取报告指标（在阈值 0.50, 0.75, 0.95, 0.99 下的 mean IoU、precision、recall）
    # ————————————————————————————————
    report_iou_50 = label_first_results[0.50]
    report_iou_75 = label_first_results[0.75]
    report_iou_95 = label_first_results[0.95]
    report_iou_99 = label_first_results[0.99]

    result = {
        'final_score': final_score,
        'size_penalty': size_penalty,
        'pure_iou_score_max_label': pure_iou_score_max_label,
        'weighted_iou_score_max_label': weighted_iou_score_max_label,
        'pure_map_score': pure_map_score,
        'pure_map50_score': pure_map50_score,
        'pure_map75_score': pure_map75_score,
        'weighted_map_score': weighted_map_score,
        'weighted_map50_score': weighted_map50_score,
        'weighted_map75_score': weighted_map75_score,
        'report_iou_50_label_match_pure': report_iou_50['mean_iou_score'],
        'report_iou_50_label_match_precision': report_iou_50['precision'],
        'report_iou_50_label_match_recall': report_iou_50['recall'],
        'report_iou_75_label_match_pure': report_iou_75['mean_iou_score'],
        'report_iou_75_label_match_precision': report_iou_75['precision'],
        'report_iou_75_label_match_recall': report_iou_75['recall'],
        'report_iou_95_label_match_pure': report_iou_95['mean_iou_score'],
        'report_iou_95_label_match_precision': report_iou_95['precision'],
        'report_iou_95_label_match_recall': report_iou_95['recall'],
        'report_iou_99_label_match_pure': report_iou_99['mean_iou_score'],
        'report_iou_99_label_match_precision': report_iou_99['precision'],
        'report_iou_99_label_match_recall': report_iou_99['recall'],
    }

    return result["final_score"]

def cal_grounding(pd, gt):
    ref_pd = re.findall(r'<ref>(.*?)</ref>', pd)
    ref_gt = re.findall(r'<ref>(.*?)</ref>', gt)

    box_pd = re.findall(r'<box>(.*?)</box>', pd)
    box_gt = re.findall(r'<box>(.*?)</box>', gt)

    d = {}
    score = 0
    for ref, box in zip(ref_pd, box_pd):
        if d.get(ref, None) is None:
            d[ref] = [[box, 0]]
        else:
            d[ref].append([box, 0])
    
    for ref, box in zip(ref_gt, box_gt):
        if d.get(ref, None) is None:
            continue

        box2 = list(map(int, box.split(",")))
        max_iou, t_id = 0, -1
        
        for idx, d_ref in enumerate(d[ref]):
            pd_box, useful = d_ref

            if useful != 0:
                continue
            
            box1 = list(map(int, pd_box.split(",")))
            iou = compute_iou(box1, box2)
            # print(box1, box2, iou)
            if iou > max_iou:
                max_iou = iou
                t_id = idx

        if t_id != -1:
            d[ref][t_id][1] = 1
        
        score += min(1.0, 2 * max_iou)
    
    return score / (len(ref_gt) + EPS)


def grounding_format_reward(predict_lower,question):
    """
    针对Grounding任务优化奖励函数
    return reward(-1~1)
    """
    reward = 0.0
    eps = 1e-6
    total_pairs = 0
    valid_pairs = 0

    ref_open = predict_lower.count("<ref>")
    ref_close = predict_lower.count("</ref>")
    box_open = predict_lower.count("<box>")
    box_close = predict_lower.count("</box>")

    # --------------------------
    # 1. 格式检查 核对ref 与 box数量
    # --------------------------
    # 标签数量不匹配或无标签
    if ref_open == 0 or box_open == 0 \
        or ref_open != ref_close or box_open != box_close :
        if ref_open == 0 or box_open == 0:
            return -1.0 # 没有任何标注
        else:
            return -0.5 # 标签数量不匹配
    
    total_pairs = ref_open

    # --------------------------
    # 2. 提取并验证<ref>和<box>内容
    # --------------------------
    refs = re.findall(r'<ref>(.*?)</ref>',predict_lower,re.DOTALL)
    boxes = re.findall(r'<box>(.*?)</box>',predict_lower,re.DOTALL)

    for ref,box in zip(refs,boxes):
        try:
            box = list(map(int,box.strip().split(",")))
            if len(ref) > 0 and len(box) == 4:
                valid_pairs += 1
        except:
            pass
        
    validity_ratio = valid_pairs/(total_pairs+eps)
    reward = -0.5 + validity_ratio * 1.5 
    return reward

################################ For MCQ ################################





################################ For VQA ################################


def cal_similarity(
    text1: str,
    text2: str,
) -> float:
    if "<answer>" in text1:
        match = re.search(r'<answer>(.*?)</answer>', text1, re.DOTALL)
        text1 = match.group(1).strip() if match else text1

    if "<answer>" in text2:
        match = re.search(r'<answer>(.*?)</answer>', text2, re.DOTALL)
        text2 = match.group(1).strip() if match else text2

    texts = [text1, text2]

    api_url = API_URL
    headers = {
        "Content-Type": "application/json"
    }

    payload = {
        "texts": texts
    }

    response = requests.post(api_url, headers=headers, json=payload, timeout=30)
    response.raise_for_status()

    response_data = response.json()

    if "embeddings" not in response_data:
        print(f"API returned abnormal content: {response_data}")
        return None

    if len(response_data["embeddings"]) != len(texts):
        print(f"Warning: returned embedding count ({len(response_data['embeddings'])}) does not match input text count ({len(texts)})!")
        return None

    embeddings = []
    for i, embedding_array in enumerate(response_data["embeddings"]):
        embedding_array = np.array(embedding_array, dtype=np.float32)
        # if len(embedding_array) != self.embedding_dim:
        #     print(f"Warning: text {i+1} embedding dimension mismatch! Expected {self.embedding_dim}, got {len(embedding_array)}")
        embeddings.append(embedding_array)

    similarity_score = cosine_similarity(embeddings[0].reshape(1, -1), embeddings[1].reshape(1, -1))
    return float(similarity_score[0][0])


def cal_batch_embedding(texts: str):
    api_url = API_URL
    headers = {
        "Content-Type": "application/json"
    }

    payload = {
        "texts": texts
    }

    response = requests.post(api_url, headers=headers, json=payload, timeout=30)
    response.raise_for_status()

    response_data = response.json()

    if "embeddings" not in response_data:
        print(f"API returned abnormal content: {response_data}")
        return None

    if len(response_data["embeddings"]) != len(texts):
        print(f"Warning: returned embedding count ({len(response_data['embeddings'])}) does not match input text count ({len(texts)})!")
        return None

    embeddings = []
    for i, embedding_array in enumerate(response_data["embeddings"]):
        embedding_array = np.array(embedding_array, dtype=np.float32)
        # if len(embedding_array) != self.embedding_dim:
        #     print(f"Warning: text {i+1} embedding dimension mismatch! Expected {self.embedding_dim}, got {len(embedding_array)}")
        embeddings.append(embedding_array)

    return embeddings


def cal_single_embedding(text:str):
    api_url = API_URL
    headers = {
        "Content-Type": "application/json"
    }

    payload = {
        "texts": [text]
    }

    response = requests.post(api_url, headers=headers, json=payload, timeout=30)
    response.raise_for_status()

    response_data = response.json()

    if "embeddings" not in response_data:
        print(f"API returned abnormal content: {response_data}")
        raise KeyError("API returned content missing 'embeddings' field")
            
    embedding = np.array(response_data["embeddings"][0], dtype=np.float32)

    return embedding


###################### COT ############################
def cot_format_reward(predict_lower, question_type, question, solution_str):

    count = 0.0
    # - 要有<think></think>且有<answer></answer>,+1
    if '<think>' in predict_lower and '</think>' in predict_lower and '<answer>' in predict_lower and '</answer>' in predict_lower:
        count += 1.0

    # - 在<think></think>内 要有step x 且 x为递增的顺序 ,+1
    flag = True
    think_steps = re.search(r'<think>(.*?)</think>',predict_lower,re.DOTALL)
    if think_steps:
        think_steps = think_steps.group(1)
        steps = re.findall(r'(?i)\bStep\b\s*[:._-]*\s*(\d+)',think_steps,re.DOTALL)
        if len(steps) == 0:
            flag = False
        elif len(steps) > 1:
            for i in range(len(steps)-1):
                if steps[i] >= steps[i+1]:
                    flag = False
                    break
    if flag:
        count += 1.0

    # - <answer></answer>内要有回答,且回答的长度0< <GT+10,+1
    pred_ans = re.search(r'<answer>(.*?)</answer>',predict_lower,re.DOTALL)
    if pred_ans:
        if 0 < len(pred_ans.group(1)) <= len(solution_str) + 20:
            count += 1.0
            
    box_count = 0
    if question_type == "Grounding":
        if (predict_lower.count("<ref>") != predict_lower.count("</ref>")) or (predict_lower.count("<ref>") != predict_lower.count("<box>")) or (predict_lower.count("<ref>") != predict_lower.count("</box>")) or predict_lower.count("<ref>") == 0:
            pass
        else:
            ref = re.findall(r'<ref>(.*?)</ref>', predict_lower)
            box = re.findall(r'<box>(.*?)</box>', predict_lower)
            for r, b in zip(ref, box):
                try:
                    b = list(map(int, b.split(",")))
                    if len(r) > 0 and len(b) == 4:
                        box_count += 1
                except:
                    pass
            box_count = box_count / (len(ref) + EPS)
    
    if question_type == "MCQ":
        if 0 < len(predict_lower) <= 2:
            box_count = 1 / (1 + EPS)

    if question_type in ['MATH', 'GeneralVQA']:
        if 0 < len(predict_lower) <= len(solution_str) + 20:
            box_count = 1 / (1 + EPS)

    count = (count + box_count) / 4

    return count

### -------------------------------------- test-------------------------------
if __name__ == '__main__':
    pred = """<think>

    # Step 1: Identify the region described by "left tan sleeve" in the image. This refers to the person on the far left, wearing a tan sleeve.

    # Step 2: Determine the bounding box coordinates for this region. The coordinates should encompass the person with the tan sleeve.


    #Step 3: Now align the answer with the format of the question, and the final answer is <ref>left tan sleeve</ref>: <box>0,270,100,987</box></think>

    <answer><ref>left tan sleeve</ref>: <box>0,270,100,987</box></answer>
    """

    gt = "<answer><ref>left tan sleeve</ref>: <box>0,270,100,987</box></answer>"
    # print(cot_format_reward(pred,"",'Grounding',gt))
    print(cal_similarity(pred,gt))

