import re
import json
from typing import List


def extract_bbox(text):
    match = re.search(r"<box>([\d\.\-]+),([\d\.\-]+),([\d\.\-]+),([\d\.\-]+)</box>", text)
    if match:
        try:
            box = tuple(map(float, match.groups()))
        except:
            box = None
        return  box
    return None

def calculate_iou(box1, box2):
    """
    计算两个边界框的 IoU。
    输入: box1 和 box2 为 (xmin, ymin, xmax, ymax) 元组
    返回: IoU 值（0~1）
    """
    xA = max(box1[0], box2[0])
    yA = max(box1[1], box2[1])
    xB = min(box1[2], box2[2])
    yB = min(box1[3], box2[3])

    inter_w = max(0, xB - xA)
    inter_h = max(0, yB - yA)
    inter_area = inter_w * inter_h

    if inter_area == 0:
        return 0.0

    box1_area = (box1[2] - box1[0]) * (box1[3] - box1[1])
    box2_area = (box2[2] - box2[0]) * (box2[3] - box2[1])

    iou = inter_area / (box1_area + box2_area - inter_area)
    return iou

def bbox_reward(predict_str: str, solution_str: str, iou_threshold: float = 0.2) -> float:
    """
    计算预测边界框与 GT 边界框的奖励。
    - 若两者都无框，返回 1.0（无目标场景）
    - 若有一个有框一个没框（误检或漏检），返回 0.0
    - 若都有框，返回 IoU，若 IoU >= 0.7，返回 1.0
    """
    gt_box = extract_bbox(solution_str)
    pred_box = extract_bbox(predict_str)

    if gt_box is None and pred_box is None:
        return 1.0  # 无目标场景，得满分
    elif gt_box is None or pred_box is None:
        return 0.0  # 漏检 or 误检，0 分
    else:
        iou = calculate_iou(gt_box, pred_box)
        # return 1.0 if iou >= iou_threshold else iou*5
        return iou
    
def no_entry_reward(
    data_source,
    solution_str,
    ground_truth,
    extra_info,
    reward_version="SimpleCot",
    iou_threshold=0.5,
):
    scorer = TaskNoEntryReward(reward_version=reward_version, iou_threshold=iou_threshold)
    # 这里用 __call__ 来算分
    return scorer(data_source, solution_str, ground_truth, extra_info)

class TaskNoEntryReward:
    
    def __init__(self, reward_version, iou_threshold) -> None:
        self.reward_version = reward_version
        self.iou_threshold = iou_threshold
        self._format_score = 0.0
        self._format_score_details = list()
        self._content_score = 0.0
        self._content_score_details = list()
    
    def __call__(self, data_source, solution_str, ground_truth, extra_info):
        
        if "no-entry" not in data_source:
            raise ValueError(f"data_source: {data_source} is not for no-entry task!")
        final_score = self.calc_score_simple_cot(solution_str, ground_truth)
        print(f'{__file__}:', data_source, solution_str, ground_truth,final_score)
        return final_score
    
    def calc_score_simple_cot(self, pred:str, all_gts:List[List[str]]):
        post_pred = pred.replace(' ', '')
        all_road_preds = post_pred.split(";")

        length_check = True
        AB_check = True
        img_id_check = True
        bbox_check = True
        if len(all_road_preds) != len(all_gts):
            length_check = False
        for idx,road_pred in enumerate(all_road_preds):
            if idx >= len(all_gts): break
            true_answer = all_gts[idx][0]
            true_label = true_answer[0].upper() # 第一个字符是答案
            if len(road_pred) == 0:
                AB_check = False
            elif len(road_pred) == 1:
                if road_pred not in ['A', 'B']:
                    AB_check = False
            else:
                ## A不需要框
                if true_label == 'A':
                    continue
                img_id = re.search(r"\[UNUSED_TOKEN_32\](.*?)\[UNUSED_TOKEN_33\]", road_pred)
                if img_id == None:
                    img_id_check = False
                elif img_id.group(1) not in ['[UNUSED_TOKEN_53]', '[UNUSED_TOKEN_54]', 
                                             '[UNUSED_TOKEN_55]', '[UNUSED_TOKEN_56]']:
                    img_id_check = False
                bbox = re.search(r'<box>(.*?)</box>', road_pred)
                if bbox == None:
                    bbox_check = False
                else:
                    try:
                        coords = [float(x) for x in bbox.group(1).split(',')]
                        if len(coords) != 4:
                            bbox_check = False
                        else:
                            for coord in coords:
                                if coord < 0 or coord > 999:
                                    bbox_check = False
                    except ValueError as e:
                        bbox_check = False
                    
        format_score = 0.0
        _length_score = 0.0
        _AB_score = 0.0
        _img_id_score = 0.0
        _bbox_score = 0.0
        if length_check: _length_score = 0.25
        if AB_check: _AB_score = 0.25
        if img_id_check: _img_id_score = 0.25
        if bbox_check: _bbox_score = 0.25
        format_score = _length_score + _AB_score + _img_id_score + _bbox_score
            
        content_score = 0.0
        _category_score = 0.0
        _grounding_score = 0.0
        max_content_score = 0.0  # 用于归一化
        grounding_list = list()
        category_score_list = list()
        view_category_score_list = list()
        view_grounding_score_list = list() # 存放真正B选项的iou分数，值域【0-1】

        if length_check:
            for pred, gts in zip(all_road_preds, all_gts):
                true_label = gts[0][0].upper()
                grounding_list.append(0)
                # 计算该条路的最大可能内容分
                if true_label == "B":
                    # B: 分类最多10分 + grounding最多2分
                    max_content_score += 12.0
                else:  # A 最多8分
                    max_content_score += 8.0
                # 依次计算每个预测的的得分
                gts_img_id = [re.search(r"\[UNUSED_TOKEN_32\](.*?)\[UNUSED_TOKEN_33\]", gt) for gt in gts]
                pred_img_id = re.search(r"\[UNUSED_TOKEN_32\](.*?)\[UNUSED_TOKEN_33\]", pred)
                if pred_img_id != None and gts_img_id.count(None) != len(gts):
                    # 匹配上真值中任意一个，即可得分
                    grounding_score_list = list()
                    for each_gt in gts:
                        gt_img_id = re.search(r"\[UNUSED_TOKEN_32\](.*?)\[UNUSED_TOKEN_33\]", each_gt)
                        if gt_img_id != None and gt_img_id.group(1) == pred_img_id.group(1):
                            temp_score = bbox_reward(pred, each_gt, self.iou_threshold)
                            grounding_score_list.append(temp_score)
                    
                    if grounding_score_list != []:
                        _grounding_score += max(grounding_score_list)*2.0
                        grounding_list[-1] = max(grounding_score_list)*2.0
                        view_grounding_score_list.append(max(grounding_score_list))
                        
                ##  B 如果答对+2分，A 如果答对+1分，倾向于把b答对
                # 真实答案是A，但预测为B，给0分
                # 真实答案是B，但预测为A，给2分
                # 真实答案是B，但预测为B，给10分
                # 真实答案是A，但预测为A，给8分
                if len(pred)> 0 :
                    if pred[0].upper() == gts[0][0].upper():
                        if true_label == "B":
                            _category_score += 10.0 
                            category_score_list.append(10.0)
                            view_category_score_list.append(1.0)
                        else:
                            _category_score += 8.0 
                            category_score_list.append(8.0)
                            view_category_score_list.append(1.0)
                    else:
                        if true_label == "B":
                            _category_score += 2.0 
                            category_score_list.append(2.0)
                            view_category_score_list.append(2.0)
                        else:
                            _category_score += 0.0 
                            category_score_list.append(0.0)
                            view_category_score_list.append(0.0)

        
        content_score = _grounding_score + _category_score
        from itertools import zip_longest
        each_score_list = [x + y for x, y in zip_longest(grounding_list, category_score_list, fillvalue=0)]
        if len(each_score_list)< len(all_gts):
            each_score_list.extend([0]*(len(all_gts)-len(each_score_list)))
            
        ## 归一化
        if max_content_score > 0:
            content_score_norm = content_score / max_content_score
        else:
            content_score_norm = 0.0
        
        # dump score details
        self._format_score = format_score
        self._content_score = content_score_norm
        self._format_score_details = [_length_score, _AB_score, _img_id_score, _bbox_score]
        self._content_score_details = [_grounding_score, _category_score]
        # 正则，比例1:1
        return {
            "score": format_score + content_score_norm,
            "format_score": format_score,
            "content_score": content_score_norm,
            "diff_score":each_score_list+[format_score],
            "category_score": view_category_score_list,
            "grounding_score": view_grounding_score_list,

        }
        # return [format_score + content_score_norm,format_score,content_score_norm]
                
            
# def calc_score_simple_cot_def(self, pred:str, all_gts:List[List[str]]):
#     post_pred = pred.replace(' ', '')
#     all_road_preds = post_pred.split(";")

#     length_check = True
#     AB_check = True
#     img_id_check = True
#     bbox_check = True
#     if len(all_road_preds) != len(all_gts):
#         length_check = False
#     for road_pred in all_road_preds:
#         if len(road_pred) == 0:
#             AB_check = False
#         elif len(road_pred) == 1:
#             if road_pred not in ['A', 'B']:
#                 AB_check = False
#         else:
#             img_id = re.search(r"\[UNUSED_TOKEN_32\](.*?)\[UNUSED_TOKEN_33\]", road_pred)
#             if img_id == None:
#                 img_id_check = False
#             elif img_id.group(1) not in ['[UNUSED_TOKEN_53]', '[UNUSED_TOKEN_54]', 
#                                          '[UNUSED_TOKEN_55]', '[UNUSED_TOKEN_56]']:
#                 img_id_check = False
#             bbox = re.search(r'<box>(.*?)</box>', road_pred)
#             if bbox == None:
#                 bbox_check = False
#             else:
#                 coords = [float(x) for x in bbox.group(1).split(',')]
#                 if len(coords) != 4:
#                     bbox_check = False
#                 else:
#                     for coord in coords:
#                         if coord < 0 or coord > 999:
#                             bbox_check = False
#     format_score = 0.0
#     if length_check:
#         format_score += 0.25
#     if AB_check:
#         format_score += 0.25
#     if img_id_check:
#         format_score += 0.25
#     if bbox_check:
#         format_score += 0.25
        
#     content_score = 0.0
#     category_score = 0.0
#     grounding_score = 0.0
#     if length_check:
#         for pred, gts in zip(all_road_preds, all_gts):
#             # 依次计算每个预测的的得分
#             gts_img_id = [re.search(r"\[UNUSED_TOKEN_32\](.*?)\[UNUSED_TOKEN_33\]", gt) for gt in gts]
#             pred_img_id = re.search(r"\[UNUSED_TOKEN_32\](.*?)\[UNUSED_TOKEN_33\]", pred)
#             if img_id == None and gts_img_id.count(None) == len(gts):
#                 if pred[0].upper() == gts[0][0].upper():
#                     category_score += 1.0
#             elif img_id == None and gts_img_id.count(None) != len(gts):
#                 if pred[0].upper() == gts[0][0].upper():
#                     category_score += 0.5
#             elif img_id != None and gts_img_id.count(None) == len(gts):
#                 if pred[0].upper() == gts[0][0].upper():
#                     category_score += 0.5
#             else:
#                 # 匹配上真值中任意一个，即可得分
#                 grounding_score_list = list()
#                 for each_gt in gts:
#                     gt_img_id = re.search(r"\[UNUSED_TOKEN_32\](.*?)\[UNUSED_TOKEN_33\]", each_gt)
#                     if gt_img_id != None and gt_img_id.group(1) == pred_img_id.group(1):
#                         temp_score = 0.5 * bbox_reward(pred, each_gt, self.iou_threshold)
#                         grounding_score_list.append(temp_score)
                
#                 if grounding_score_list != []:
#                     grounding_score += max(grounding_score_list)
                    
#                 if pred[0].upper() == gts[0][0].upper():
#                     category_score += 0.5
                
#     content_score = grounding_score + category_score
#     return format_score + content_score

if __name__ == "__main__":
    # data_path = '/lustre/joeden.zhuang/projects/vlm_no_entry/output_prod/no_entry_road_test_1110-1.jsonl'
    # # data_path = '/lustre/joeden.zhuang/projects/vlm_no_entry/output_prod/no_entry_road_train_1110-1.jsonl'
    # with open(data_path, 'r') as f:
    #     data_list = [json.loads(line.strip()) for line in f]
    
    # reward_scorer = TaskNoEntryReward('simple-cot', 0.5)
    # for data in data_list[:200]:
    #     pred = data['conversations'][1]['value']
    #     all_gts = data['extra']['all_cand_gts']

    #     final_score = reward_scorer.calc_score_simple_cot(pred=pred, all_gts=all_gts)
    #     print(f'final_score={final_score}', \
    #         f'format_score_details:{reward_scorer._format_score_details}', \
    #         f'content_score_details:{reward_scorer._content_score_details}')

    pred = """A;A;B[UNUSED_TOKEN_32][UNUSED_TOKEN_53][UNUSED_TOKEN_33]<box>645,381,674,384</box>;A"""
    all_gts = [['A'], ['A'],['B[UNUSED_TOKEN_32][UNUSED_TOKEN_53][UNUSED_TOKEN_33]<box>645,363,674,440</box>',
    'B[UNUSED_TOKEN_32][UNUSED_TOKEN_56][UNUSED_TOKEN_33]<box>379,458,385,472</box>'],['A']]
    reward_scorer = TaskNoEntryReward('simple-cot', 0.2)
    final_score = reward_scorer.calc_score_simple_cot(pred=pred, all_gts=all_gts)
    print(f'final_score={final_score}', \
        f'format_score_details:{reward_scorer._format_score_details}', \
        f'content_score_details:{reward_scorer._content_score_details}')
    