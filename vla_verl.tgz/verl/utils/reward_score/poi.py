import json
import re
from collections import Counter

def extract_special_tokens(text, special_token_pattern=r"\[UNUSED_TOKEN_[^\[\]]+\]"):
    """提取special token"""
    return re.findall(special_token_pattern, text)


def extract_bbox(text):
    match = re.search(r"<box>([\d\.\-]+),([\d\.\-]+),([\d\.\-]+),([\d\.\-]+)</box>", text)
    if match:
        return tuple(map(float, match.groups()))
    return None


def extract_turn(text):
    match = re.search(r"\[UNUSED_TOKEN_39\](.*?)\[UNUSED_TOKEN_40\]", text, re.DOTALL)
    if match:
        return match.group(1).strip()
    return None


def extract_orientation(text):
    match = re.search(r"\[UNUSED_TOKEN_41\](.*?)\[UNUSED_TOKEN_42\]", text, re.DOTALL)
    if match:
        return match.group(1).strip()
    return None


def extract_distance(text):
    match = re.search(r"\[UNUSED_TOKEN_43\](.*?)\[UNUSED_TOKEN_44\]", text, re.DOTALL)
    if match:
        return match.group(1).strip().rstrip('m')
    return None


def calculate_iou(box1, box2):
    """
    计算两个边界框的 IoU。
    输入: box1 和 box2 为 (xmin, ymin, xmax, ymax) 元组
    返回: IoU 值（0~1）
    """
    xA = max(box1[0], box2[0])
    yA = max(box1[1], box2[1])
    xB = min(box1[2], box2[2])
    yB = min(box1[3], box2[3])

    inter_w = max(0, xB - xA)
    inter_h = max(0, yB - yA)
    inter_area = inter_w * inter_h

    if inter_area == 0:
        return 0.0

    box1_area = (box1[2] - box1[0]) * (box1[3] - box1[1])
    box2_area = (box2[2] - box2[0]) * (box2[3] - box2[1])

    iou = inter_area / (box1_area + box2_area - inter_area)
    return iou


def poi_format_reward(predict_str: str, solution: str) -> float:
    """
    计算 prediction 中 special token 与 gt 一致性的奖励分数。
    满分为 1，如果 prediction 中的 special token 与 gt 完全一致（种类和数量），得分为 1。
    否则按匹配比例得分。
    """
    special_token_pattern=r"\[UNUSED_TOKEN_[^\[\]]+\]"
    gt_tokens = extract_special_tokens(solution, special_token_pattern)
    pred_tokens = extract_special_tokens(predict_str, special_token_pattern)

    if not gt_tokens and not pred_tokens:
        return 1.0  # 如果gt没有special token，直接满分
    if not gt_tokens:
        return 0.0  # gt为C，预测为A/B
    gt_counter = Counter(gt_tokens)
    pred_counter = Counter(pred_tokens)

    matched = sum(min(gt_counter[token], pred_counter.get(token, 0)) for token in gt_counter)
    total = sum(gt_counter.values())

    return matched / total


def bbox_reward(predict_str: str, solution_str: str, iou_threshold: float = 0.7) -> float:
    """
    计算预测边界框与 GT 边界框的奖励。
    - 若两者都无框，返回 1.0（无目标场景）
    - 若有一个有框一个没框（误检或漏检），返回 0.0
    - 若都有框，返回 IoU，若 IoU >= 0.7，返回 1.0
    """
    gt_box = extract_bbox(solution_str)
    pred_box = extract_bbox(predict_str)

    if gt_box is None and pred_box is None:
        return 1.0  # 无目标场景，得满分
    elif gt_box is None or pred_box is None:
        return 0.0  # 漏检 or 误检，0 分
    else:
        iou = calculate_iou(gt_box, pred_box)
        return 1.0 if iou >= iou_threshold else iou


def turn_reward(predict_str: str, solution_str: str) -> float:
    """
    对方向信息段进行匹配打分。
    - 若两者都无方向段，得 1.0
    - 若有内容且完全一致，得 1.0
    - 否则得 0.0
    """
    gt_turn = extract_turn(solution_str)
    pred_turn = extract_turn(predict_str)

    if gt_turn is None and pred_turn is None:
        return 1.0
    elif gt_turn == pred_turn:
        return 1.0
    else:
        return 0.0
    

def orientation_reward(predict_str: str, solution_str: str) -> float:
    """
    对方向信息段进行匹配打分。
    - 若两者都无方向段，得 1.0
    - 若有内容且完全一致，得 1.0
    - 否则得 0.0
    """
    gt_orientation = extract_orientation(solution_str)
    pred_orientation = extract_orientation(predict_str)

    if gt_orientation is None and pred_orientation is None:
        return 1.0
    elif gt_orientation == pred_orientation:
        return 1.0
    else:
        return 0.0
    
    
def distance_reward(predict_str: str, solution_str: str,  max_error = 10, min_error = 5) -> float:
    """
    对方向信息段进行匹配打分。
    - 若两者都无方向段，得 1.0
    - 若有内容且完全一致，得 1.0
    - 否则得 0.0
    """
    gt_distance = extract_distance(solution_str)
    pred_distance = extract_distance(predict_str)

    if gt_distance is None and pred_distance is None:
        return 1.0
    if gt_distance is None or pred_distance is None:
        return 0.0
    try:
        error = abs(float(gt_distance) - float(pred_distance))
    except:
        return 0.0    
    if error >= max_error:
        return 0.0
    if error <= min_error:
        return 1.0
    else:
        return 1.0 - (error / max_error)
    
    
def poi_reward(predict_str: str, solution: dict) -> float:
    """
    orsta reward 组成: accu_ratio * accu_reward + format_ratio + format_reward
    """
    accu_ratio = solution["accuracy_ratio"]
    format_ratio = solution["format_ratio"]
    solution_str = solution['ground_truth']
    # format 奖励
    format_reward = poi_format_reward(predict_str, solution_str)
    accu_reward = 0
    if "answer" in solution["verifier"]:
        # 解析 A/B/C选项 并计算得分
        try:
            if solution_str[0] == predict_str[0]:
                accu_reward += 1.0
            else:
                accu_reward += 0.0
        except:
            accu_reward += 0.0
    if 'grounding' in solution['verifier']:
        # 计算grounding iou 得分
        accu_reward += bbox_reward(predict_str, solution_str)
    if 'turn' in solution['verifier']:
        # 方向得分
        accu_reward += turn_reward(predict_str, solution_str)
    if 'orientation' in solution['verifier']:
        # 朝向得分
        accu_reward += orientation_reward(predict_str, solution_str)
    if 'distance' in solution['verifier']:
        # 距离得分
        accu_reward += distance_reward(predict_str, solution_str)
    
    return accu_ratio * accu_reward/len(solution['verifier']) + format_ratio * format_reward


if __name__ == "__main__":
    data_path = '/perception-hl/xiwen.zhang/mlm-data/poi/multitask/train_charging_v3_portion1_rl_nodynamic.jsonl'
    with open(data_path, 'r') as f:
        data = [json.loads(line.strip()) for line in f]
    for d in data:
        prediction = d['conversations'][1]['value']
        print(poi_reward(
            predict_str=prediction,
            solution=d['reward_model']['ground_truth'],
        ))
        print()