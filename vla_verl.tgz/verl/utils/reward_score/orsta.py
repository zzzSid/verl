import json
import os
import re
import pdb
import numpy as np
import requests
import math_verify
from latex2sympy2_extended import NormalizationConfig
from typing import Any, Callable, Dict, List, Optional, Type, TypeVar, Tuple, Union
try:
    from math_verify.errors import TimeoutException
    from math_verify.metric import math_metric
    from math_verify.parser import ExprExtractionConfig, LatexExtractionConfig
except ImportError:
    print("To use Math-Verify, please install it first by running `pip install math-verify`.")
from verl.utils.reward_score.utils import *

EPS = 1e-6


def orsta_format_reward(predict_lower, question_type, question, solution_str):
    
    count = 0.0
    if question != "" and "<think>" in question:
        if predict_lower.count("<think>") == 1 and predict_lower.count("</think>") == 1 and predict_lower.count("<answer>") == 1 and predict_lower.count("</answer>") == 1:
            count = 1.0

        answer_str = ""

        if "<answer>" in predict_lower and "</answer>" in predict_lower:
            match = re.search(r'<answer>(.*?)</answer>', predict_lower, re.DOTALL)
            answer_str = match.group(1).strip() if match else predict_lower
            
        if len(answer_str) == 0 or answer_str == ' ' or answer_str == '\n':
            count = 0.0
            return count

        think_str = ""

        if "<think>" in predict_lower and "</think>" in predict_lower:
            match = re.search(r'<think>(.*?)</think>', predict_lower, re.DOTALL)
            think_str = match.group(1).strip() if match else predict_lower

        if len(think_str) == 0 or think_str == ' ' or think_str == '\n':
            count = 0.0
            return count

    box_count = 0
    if question_type == "Grounding":
        if (predict_lower.count("<ref>") != predict_lower.count("</ref>")) or (predict_lower.count("<ref>") != predict_lower.count("<box>")) or (predict_lower.count("<ref>") != predict_lower.count("</box>")) or predict_lower.count("<ref>") == 0:
            pass
        else:
            ref = re.findall(r'<ref>(.*?)</ref>', predict_lower)
            box = re.findall(r'<box>(.*?)</box>', predict_lower)
            for r, b in zip(ref, box):
                try:
                    b = list(map(int, b.split(",")))
                    if len(r) > 0 and len(b) == 4:
                        box_count += 1
                except:
                    pass
            box_count = box_count / (len(ref) + EPS)
            #box_count = grounding_format_reward(predict_lower,question)
    
    if question_type == "MCQ":
        if 0 < len(predict_lower) <= 2:
            box_count = 1 / (1 + EPS)

    if question_type in ['MATH', 'GeneralVQA']:
        if 0 < len(predict_lower) <= len(solution_str) + 20:
            box_count = 1 / (1 + EPS)

    count = (count + box_count) / 2

    return count


def orsta_math_reward(predict_lower, solution_lower):
    try:
        gold_parsed = math_verify.parse(
            solution_lower,
            extraction_mode="first_match",
        )
    except:
        return 0.0
    if len(gold_parsed) != 0:
        try:
            answer_parsed = math_verify.parse(
                predict_lower,
                extraction_config=[
                    math_verify.LatexExtractionConfig(
                        normalization_config=NormalizationConfig(
                            nits=False,
                            malformed_operators=False,
                            basic_latex=True,
                            boxed="all",
                            units=True,
                        ),
                        # Ensures that boxed is tried first
                        boxed_match_priority=0,
                        try_extract_without_anchor=False,
                    )
                ],
                extraction_mode="first_match",
            )
        except:
            return 0.0
        # Compute binary rewards if verifiable, `None` otherwise to skip this example
        try:
            reward = float(math_verify.verify(gold_parsed, answer_parsed))
        except Exception as e:
            reward = 0.
    else:
        # If the gold solution is not parseable, we assign `None` to skip this example
        reward = 0.

    return reward


def orsta_detection_reward(predict_lower, solution_lower):
    try:
        pred_bbox_list = json.loads(predict_lower)
        sol_bbox_list = json.loads(solution_lower)
        map_reward = compute_map(pred_bbox_list, sol_bbox_list)
        return map_reward
    
    except:
        return 0.0


def orsta_think_reward(solution_str, question, image_path):

    # pdb.set_trace()

    if ("<think>" not in solution_str) or ("</think>" not in solution_str):
        return 0.0
    
    # OpenGVLab/VisualPRM-8B. 0~1
    SERVER_URL = "http://172.24.138.143:8081/infer"

    match = re.search(r'<think>(.*?)</think>', solution_str, re.DOTALL)
    solution_str = match.group(1).strip() if match else solution_str
    try:
        data = {
            "image": image_path,
            "question": question,
            "response_list_str": json.dumps([solution_str]),
        }
        response = requests.post(SERVER_URL, data=data)

        if response.status_code == 200:
            ans = response.json()['answer'][0][1]
            return ans
        else:
            return 0.0
    except:
        return 0.0


def orsta_new_reward(predict_str: str, solution: dict) -> float:

    if len(predict_str) == 0:
        return {
            "score": 0.0,
            "acc": 0.0
        }

    accu_ratio = solution.get("accuracy_ratio", 1)
    format_ratio = solution.get("format_ratio", 1)
    think_ratio = solution.get("think_ratio", 1)

    question_type = solution['verifier']
    format_reward = orsta_format_reward(
        predict_str,
        question_type, 
        solution.get("question", ""), 
        solution['ground_truth']
    )
    think_reward = orsta_think_reward(
        predict_str, 
        solution.get("question", ""), 
        solution.get("image_path", "")
    )

    try:
        if question_type == "MATH":
            try:

                ori_str = predict_str

                predict_str = extract_answer(predict_str)
                extractor = Math_Extractor()
                predict_str = extractor.extract_answer(predict_str)
                predict_str = strip_string(predict_str)
                
                solution_str = extractor.extract_answer(solution["ground_truth"])
                solution_str = strip_string(solution_str)

                verify_func = math_metric(
                    gold_extraction_target=(LatexExtractionConfig(),),
                    pred_extraction_target=(ExprExtractionConfig(), LatexExtractionConfig()),
                )
                gt = "\\boxed{" + solution_str + "}"
                predict_str = "\\boxed{" + predict_str + "}"
                accu_reward, _ = verify_func([gt], [predict_str])

                # if predict_str == ("\\boxed{" + "}"):

                #     print("==========pd-Pre==========")
                #     print(ori_str)

                #     print("==========gt==========")
                #     print(gt)

                #     print("==========pd-Aft==========")
                #     print(predict_str)
            except:

                predict_str = extract_answer(predict_str)
                solution_str = extract_answer(solution["ground_truth"])

                accu_reward = 1.0 if solution_str == predict_str else 0.0

        elif question_type == "GeneralVQA":
            # accu_reward = cal_similarity(predict_str, solution["ground_truth"])
            # if accu_reward is None:
            predict_str = extract_answer(predict_str)
            solution_str = extract_answer(solution["ground_truth"])

            accu_reward = 1.0 if predict_str == solution_str else 0.0

        elif question_type == "MCQ":
            predict_str = extract_answer(predict_str)
            solution_str = extract_answer(solution["ground_truth"])
            p, s = "", ""
            for pd in predict_str:
                if 97 <= ord(pd) <= 122:
                    p = pd
                    break
            for sh in solution_str:
                if 97 <= ord(sh) <= 122:
                    s = sh
                    break
            if p == s and p != "":
                accu_reward = 1.0
            else:
                accu_reward = 0.0

        elif question_type == "Grounding":
            predict_str = extract_answer(predict_str)
            solution_str = extract_answer(solution["ground_truth"])

            accu_reward = cal_grounding(predict_str, solution_str)

        else:
            raise ValueError
            
    except:
        accu_reward = 0.0

    reward = accu_ratio * accu_reward + format_ratio * format_reward + think_ratio * think_reward

    return {
        "score": reward,
        "acc": accu_reward
    }


def orsta_reward(predict_str: str, solution: dict) -> float:
    """
    orsta reward 组成: accu_ratio * accu_reward + format_ratio + format_reward
    """
    accu_ratio = solution.get("accuracy_ratio", 1)
    format_ratio = solution.get("format_ratio", 1)
    think_ratio = solution.get("think_ratio", 1)
    
    # format 奖励
   
    format_reward = orsta_format_reward(predict_str)
    think_reward = orsta_think_reward(predict_str, solution.get("question", ""), solution.get("image", ""))

    question_type = solution['verifier']

    if question_type == 'MATH':
        # 答案在 \boxed{}
        try:
            predict_str = extract_answer(predict_str)
            extractor = Math_Extractor()
            predict_str = extractor.extract_answer(predict_str)
            predict_str = strip_string(predict_str)
            
            solution_str = extractor.extract_answer(solution["ground_truth"])
            solution_str = strip_string(solution_str)

            verify_func = math_metric(
                gold_extraction_target=(LatexExtractionConfig(),),
                pred_extraction_target=(ExprExtractionConfig(), LatexExtractionConfig()),
            )
            gt = "\\boxed{" + solution_str + "}"
            predict_str = "\\boxed{" + predict_str + "}"
            accu_reward, _ = verify_func([gt], [predict_str])
        except:
            accu_reward = 1.0 if solution["ground_truth"] == predict_str else 0.0
    elif question_type == 'Grounding':
        # 形如 <ref>ref</ref>: <box>box</box>
        predict_str = extract_answer(predict_str)
        accu_reward = cal_grounding(predict_str, solution["ground_truth"])
    else:
        predict_str = extract_answer(predict_str)
        accu_reward = 1.0 if solution["ground_truth"].lower() == predict_str else 0.0
            
    return accu_ratio * accu_reward + format_ratio * format_reward + think_ratio * think_reward


def compute_score(solution: str, predict_str: str) -> float:    
    predict_lower = predict_str.lower().replace("'", '"')
    solution_lower = solution.lower().replace("'", '"')
    accu_reward = orsta_math_reward(predict_lower, solution_lower)

    return accu_reward


if __name__ == "__main__":
    # p_box = "<ref>sweetorange</ref>:<box>336,309,784,582</box>."
    # a_box = {
    #     "accuracy_ratio": 1.0,
    #     "format_ratio": 0.0,
    #     "verifier": "MATH",
    #     "ground_truth": "<ref>sweetorange</ref>:<box>343,308,795,602</box>"
    # }
    # print(orsta_new_reward(
    #     predict_str=p_box,
    #     solution=a_box,
    # ))

    # math reward test

    pred = "<think>\n# Step 1: Identify the man in the blue plaid shirt in the image.\n# Step 2: Determine the bounding box coordinates for the man in the blue plaid shirt.\n# Step 3: The man in the blue plaid shirt is sitting on the right side of the image. The bounding box should cover his upper body and head.\n\n#Step 4: Now align the answer with the format of the question, and the final answer is <ref>man in blue plaid shirt sitting</ref>: <box>806,42,1000,989</box></think>\n<answer><ref>man in blue plaid shirt sitting</ref>: <box>806,42,1000,989</box></answer>"
    gt = {
        "accuracy_ratio": 1.0,
        "format_ratio": 0.0,
        "verifier": "GeneralVQA",
        "ground_truth": "<ref>sweetorange</ref>:<box>343,308,795,602</box>"
    }
    print(orsta_new_reward(
        predict_str=pred,
        solution=gt,
    ))