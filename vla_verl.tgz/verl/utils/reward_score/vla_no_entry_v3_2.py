"""
VLA No-Entry Reward v3.2 — v3 + exit reward for ds_type="exit".

For ds_type="no_entry" (or missing ds_type): same as v3.
For ds_type="exit":
  - Skip forbidden-road penalty.
  - Build road geometries from vla_road_construction_info.
  - Check wall crash (same as no_entry).
  - Bind predicted trajectory segments to roads.
  - If any bound road ID is in exit_path_road_ids → +2.0.
  - Otherwise → 0.0.

Unified diff_score (3 dims for both ds_type):
    diff_score = [traj_valid, road_binding, wall]

Scoring rules (≤ 0, higher is better):
    ─────────────────────────────────────────────────────────────────────
    no_entry:
      (same as v3 — intersection-distance-weighted forbidden penalty)
      road_binding ≤ 0  (penalty for forbidden-road binding)
      wall         ≤ 0  (penalty for wall crash)
    exit:
      正确匹配出口路径路网                            +2.0  (road_binding)
      撞墙                                          -N * WALL_PENALTY
      无法解析轨迹                                   -4.0
      轨迹过短                                      -3.0
    ─────────────────────────────────────────────────────────────────────
"""

import json
import logging
import os
import re
from typing import Optional

import numpy as np

logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════════════
#  Reuse shared helpers from v3
# ═══════════════════════════════════════════════════════════════════════════════

from verl.utils.reward_score.vla_no_entry_v3 import (
    # Trajectory parsing
    parse_action_traj,
    action_traj_to_abs,
    COORD_NORM_MIN, COORD_NORM_MAX, COORD_PHYS_MIN, COORD_PHYS_MAX,
    # Road data
    FORBIDDEN_ROAD_CLASSES,
    get_forbidden_road_ids,
    get_all_road_geometries,
    get_road_id_to_cls,
    # Geometry / binding
    _min_distance_point_to_polyline,
    compute_segment_binding_score,
    bind_segment_to_road,
    # Intersection (v3)
    find_nearest_road_to_point,
    detect_intersection_distance,
    get_intersection_penalty,
    INTERSECTION_NEAR_6M, INTERSECTION_NEAR_12M,
    INTERSECTION_ENDPOINT_DIST_THRESHOLD, INTERSECTION_MIN_CONNECTED_ROADS,
    # Wall crash
    get_unsafe_masks,
    check_traj_crash_into_wall,
    # Constants
    BINDING_W_DIST, BINDING_W_ANGLE, BINDING_MAX_DIST, BINDING_MIN_POINTS,
    WALL_PENALTY,
    FORBIDDEN_PENALTY_NEAR, FORBIDDEN_PENALTY_MEDIUM, FORBIDDEN_PENALTY_FAR,
    # Core violation check
    check_traj_violation_by_binding,
)


# ═══════════════════════════════════════════════════════════════════════════════
#  Exit reward constants
# ═══════════════════════════════════════════════════════════════════════════════

EXIT_REWARD_MATCH    = 2.0   # reward when pred trajectory matches exit path


# ═══════════════════════════════════════════════════════════════════════════════
#  vla_road_construction_info → all_road_geoms
# ═══════════════════════════════════════════════════════════════════════════════

def build_road_geoms_from_vla_construction(vla_road_construction_info: dict):
    """Convert ``vla_road_construction_info`` to the standard ``all_road_geoms`` dict.

    Returns dict: ``{road_id: np.array([[x,y], ...]), ...}``.
    """
    all_road_geoms = {}
    vla_road_info = vla_road_construction_info.get("vla_road_info", [])
    if isinstance(vla_road_info, list):
        for road in vla_road_info:
            road_id = road.get("road_link_id", "")
            way_points = road.get("road_way_point", [])
            if len(way_points) > 1:
                geo = np.array([[wp["point_x"], wp["point_y"]] for wp in way_points], dtype=float)
                all_road_geoms[road_id] = geo
    return all_road_geoms


def check_exit_path_match(abs_traj, all_road_geoms, exit_path_road_ids: set,
                          min_points=BINDING_MIN_POINTS):
    """Check whether the predicted trajectory binds to any road in exit_path_road_ids.

    Returns (is_match: bool, details: dict).
    """
    if abs_traj is None or len(abs_traj) < min_points:
        return False, {
            "reason": "trajectory_too_short",
            "num_points": len(abs_traj) if abs_traj is not None else 0,
        }

    if not all_road_geoms:
        return False, {"reason": "no_road_geometries"}

    if not exit_path_road_ids:
        return False, {"reason": "no_exit_path_road_ids"}

    origin = np.array([[0.0, 0.0]])
    full_traj = np.vstack([origin, abs_traj[:min_points]])

    matched_road_ids = []
    for i in range(len(full_traj) - 2):
        segment = full_traj[i:i + 3]
        road_id, info = bind_segment_to_road(segment, all_road_geoms)
        if road_id is not None and road_id in exit_path_road_ids:
            matched_road_ids.append({
                "segment_idx": i,
                "road_id": road_id,
                "binding_info": info,
            })

    if matched_road_ids:
        return True, {
            "reason": "exit_path_matched",
            "matched_road_ids": matched_road_ids,
        }

    return False, {"reason": "no_exit_path_match"}


# ═══════════════════════════════════════════════════════════════════════════════
#  Reward interface
# ═══════════════════════════════════════════════════════════════════════════════

class TaskVLANoEntryRewardV32:
    """VLA no-entry / exit reward v3.2.

    - ds_type="no_entry" (or missing): same as v3
    - ds_type="exit": exit-path road-network matching reward
    """

    def __init__(self, debug=False, debug_dir="/tmp/vla_reward_test"):
        self._last_details = {}
        self._debug = debug
        self._step = 0
        self._debug_first_n = 200
        self._debug_log_every = 20
        self._debug_dir = debug_dir or os.environ.get('VLA_DEBUG_DIR') or '/tmp/vla_reward_debug'

    def __call__(self, data_source, solution_str, ground_truth, extra_info):
        self._step += 1
        return self.compute_score(data_source, solution_str, ground_truth, extra_info)

    def _dbg(self, msg):
        if self._debug:
            with open("/tmp/vla_reward_debug.log", "a") as f:
                f.write(msg + "\n")

    @staticmethod
    def _extract_kwargs(extra_info):
        tools_kwargs = extra_info.get('tools_kwargs', {})
        reward_cfg = tools_kwargs.get('calc_no-entry_reward', {})
        return reward_cfg.get('calc_reward_kwargs', {})

    def compute_score(self, data_source, solution_str, ground_truth, extra_info):
        kwargs = self._extract_kwargs(extra_info)
        clip_id = extra_info.get('clip_id', '?')
        ds_type = extra_info.get('ds_type', 'no_entry')
        vocab_path = kwargs.get('vocab_path', None)

        # ── Parse trajectory ──
        action_traj = parse_action_traj(solution_str, vocab_path=vocab_path)
        abs_traj = action_traj_to_abs(action_traj) if action_traj is not None else None

        # ── Common fields ──
        freespace_info = json.loads(kwargs.get('freespace_info', '{}'))
        vla_goal_point = json.loads(kwargs.get('vla_goal_point', '{}'))
        has_exit_sign  = json.loads(kwargs.get('has_exit_sign', 'false'))

        if ds_type == 'exit':
            result = self._compute_exit_score(
                kwargs, action_traj, abs_traj, freespace_info,
                clip_id, data_source, solution_str,
                vla_goal_point, has_exit_sign,
            )
        else:
            result = self._compute_no_entry_score(
                kwargs, action_traj, abs_traj, freespace_info,
                clip_id, data_source, solution_str,
                vla_goal_point, has_exit_sign,
            )

        result['debug'] = {
            'clip_id': clip_id,
            'data_source': data_source,
            'ds_type': ds_type,
            'score': result['score'],
            'reason': result['reason'],
            'diff_score': result.get('diff_score', []),
            'has_exit_sign': has_exit_sign,
        }
        return result

    # ── Exit reward ──────────────────────────────────────────────────────────

    def _compute_exit_score(self, kwargs, action_traj, abs_traj, freespace_info,
                            clip_id, data_source, solution_str,
                            vla_goal_point, has_exit_sign):
        vla_road_construction_info = json.loads(
            kwargs.get('vla_road_construction_info', '{}') or '{}')
        exit_path_road_ids = set(json.loads(
            kwargs.get('exit_path_road_ids', '[]') or '[]'))

        all_road_geoms = build_road_geoms_from_vla_construction(vla_road_construction_info)
        unsafe_masks = get_unsafe_masks(freespace_info)

        _base_result = {
            "score": 0.0, "reason": "", "details": {},
            "num_points": 0, "required": BINDING_MIN_POINTS,
        }

        if action_traj is None:
            result = dict(_base_result, score=-4.0, reason="no_trajectory_parsed",
                          details={"reason": "no_trajectory_parsed"})
            self._last_details = {'reason': 'no_trajectory_parsed'}
        else:
            num_points = len(abs_traj) if abs_traj is not None else 0
            if num_points < BINDING_MIN_POINTS:
                result = dict(_base_result, score=round(-3.0, 4),
                              reason="trajectory_too_short",
                              num_points=num_points,
                              required=BINDING_MIN_POINTS,
                              details={"reason": "trajectory_too_short",
                                       "num_points": num_points})
                self._last_details = {'reason': 'trajectory_too_short',
                                      'num_points': num_points}
            elif unsafe_masks:
                # Wall crash check takes priority over exit match.
                is_crash, crash_details = check_traj_crash_into_wall(
                    abs_traj, unsafe_masks, min_points=BINDING_MIN_POINTS)
                if is_crash:
                    penalty = min(crash_details.get('num_unsafe', 1),
                                  BINDING_MIN_POINTS) * WALL_PENALTY
                    result = dict(_base_result, score=round(-penalty, 4),
                                  reason="crash_into_wall", details=crash_details)
                    self._last_details = crash_details
                elif not all_road_geoms:
                    result = dict(_base_result, reason="no_road_geometries",
                                  details={"reason": "no_road_geometries"})
                    self._last_details = {'reason': 'no_road_geometries'}
                else:
                    is_match, details = check_exit_path_match(
                        abs_traj, all_road_geoms, exit_path_road_ids)
                    if is_match:
                        result = dict(_base_result, score=EXIT_REWARD_MATCH,
                                      reason="exit_path_matched", details=details)
                        self._last_details = details
                    else:
                        result = dict(_base_result, score=0.0,
                                      reason=details.get('reason', 'no_exit_path_match'),
                                      details=details)
                        self._last_details = details
            elif not all_road_geoms:
                result = dict(_base_result, reason="no_road_geometries",
                              details={"reason": "no_road_geometries"})
                self._last_details = {'reason': 'no_road_geometries'}
            else:
                is_match, details = check_exit_path_match(
                    abs_traj, all_road_geoms, exit_path_road_ids)
                if is_match:
                    result = dict(_base_result, score=EXIT_REWARD_MATCH,
                                  reason="exit_path_matched", details=details)
                    self._last_details = details
                else:
                    result = dict(_base_result, score=0.0,
                                  reason=details.get('reason', 'no_exit_path_match'),
                                  details=details)
                    self._last_details = details

        # ── Build GDPO diff_score ──
        diff_list, dim_dict = self._build_exit_diff_score(result)
        result['diff_score'] = diff_list
        result.update(dim_dict)

        # ── Debug ──
        if self._debug:
            self._log_exit_debug(clip_id, data_source, solution_str,
                                 action_traj, abs_traj, result,
                                 exit_path_road_ids, vla_road_construction_info,
                                 vla_goal_point, has_exit_sign)

        return result

    # ── No-entry reward (v3-compatible) ──────────────────────────────────────

    def _compute_no_entry_score(self, kwargs, action_traj, abs_traj, freespace_info,
                                clip_id, data_source, solution_str,
                                vla_goal_point, has_exit_sign):
        road_graphs     = json.loads(kwargs.get('road_graphs', '{}'))
        select_road_ids = json.loads(kwargs.get('select_road_ids', '[]'))
        select_road_cls = json.loads(kwargs.get('select_road_cls', '[]'))

        forbidden_ids = get_forbidden_road_ids(select_road_ids, select_road_cls)
        all_road_geoms = get_all_road_geometries(road_graphs)
        road_id_to_cls = get_road_id_to_cls(select_road_ids, select_road_cls)
        unsafe_masks = get_unsafe_masks(freespace_info)

        intersection_info = detect_intersection_distance(all_road_geoms)
        intersection_distance = intersection_info.get("distance")
        forbidden_penalty = get_intersection_penalty(intersection_distance)

        _base_result = {
            "score": 0.0, "reason": "", "details": {},
            "num_points": 0, "required": BINDING_MIN_POINTS,
        }

        if action_traj is None:
            result = dict(_base_result, score=-4.0, reason="no_trajectory_parsed",
                          details={"reason": "no_trajectory_parsed"})
            self._last_details = {'reason': 'no_trajectory_parsed'}
        elif not all_road_geoms and not unsafe_masks:
            result = dict(_base_result, reason="no_road_geometries",
                          details={"reason": "no_road_geometries"})
            self._last_details = {'reason': 'no_road_geometries'}
        else:
            num_points = len(abs_traj) if abs_traj is not None else 0
            if num_points < BINDING_MIN_POINTS:
                result = dict(_base_result, score=round(-3.0, 4),
                              reason="trajectory_too_short",
                              num_points=num_points,
                              required=BINDING_MIN_POINTS,
                              details={"reason": "trajectory_too_short",
                                       "num_points": num_points})
                self._last_details = {'reason': 'trajectory_too_short',
                                      'num_points': num_points}
            elif not forbidden_ids:
                if unsafe_masks:
                    is_crash, crash_details = check_traj_crash_into_wall(
                        abs_traj, unsafe_masks, min_points=BINDING_MIN_POINTS)
                    if is_crash:
                        penalty = min(crash_details.get('num_unsafe', 1),
                                      BINDING_MIN_POINTS) * WALL_PENALTY
                        result = dict(_base_result, score=round(-penalty, 4),
                                      reason="crash_into_wall", details=crash_details)
                        self._last_details = crash_details
                    else:
                        result = dict(_base_result, reason="no_forbidden_roads",
                                      details={"reason": "no_forbidden_roads"})
                        self._last_details = {'reason': 'no_forbidden_roads'}
                else:
                    result = dict(_base_result, reason="no_forbidden_roads",
                                  details={"reason": "no_forbidden_roads"})
                    self._last_details = {'reason': 'no_forbidden_roads'}
            else:
                is_violation, details = check_traj_violation_by_binding(
                    abs_traj, all_road_geoms, road_id_to_cls, forbidden_ids,
                    unsafe_masks=unsafe_masks,
                )

                if not is_violation:
                    result = dict(_base_result, reason="correct", details=details)
                    self._last_details = {'reason': 'correct'}
                else:
                    reason = details.get('reason', 'unknown')
                    score = 0.0
                    if reason == 'segment_binds_to_forbidden_road':
                        score -= forbidden_penalty
                        details['intersection_distance'] = intersection_distance
                        details['forbidden_penalty'] = forbidden_penalty
                    elif reason == 'crash_into_wall':
                        score -= min(details.get('num_unsafe', 1),
                                     BINDING_MIN_POINTS) * WALL_PENALTY
                    result = dict(_base_result, score=round(score, 4),
                                  reason=reason, details=details)
                    self._last_details = details

        # ── Build GDPO diff_score ──
        diff_list, dim_dict = self._build_no_entry_diff_score(result, forbidden_penalty)
        result['diff_score'] = diff_list
        result.update(dim_dict)

        # ── Debug ──
        if self._debug:
            self._log_no_entry_debug(clip_id, data_source, solution_str,
                                     action_traj, abs_traj, result,
                                     forbidden_ids, road_graphs,
                                     select_road_ids, select_road_cls,
                                     freespace_info, vocab_path=None,
                                     intersection_distance=intersection_distance,
                                     forbidden_penalty=forbidden_penalty,
                                     intersection_info=intersection_info,
                                     vla_goal_point=vla_goal_point,
                                     has_exit_sign=has_exit_sign)

        return result

    # ── diff_score builders ──────────────────────────────────────────────────

    @staticmethod
    def _build_no_entry_diff_score(result, forbidden_penalty=FORBIDDEN_PENALTY_FAR):
        """Build diff_score for no_entry reward.

        Unified 3-dim format (same as exit):
            diff_score = [traj_valid, road_binding, wall]

        road_binding: -forbidden_penalty when binding to forbidden road, else 0.0
        wall:         wall-crash penalty (≤ 0)
        """
        reason = result.get('reason', 'unknown')
        details = result.get('details', {})
        score = result.get('score', 0.0)

        if reason == 'no_trajectory_parsed':
            traj_valid = -4.0
        elif reason == 'trajectory_too_short':
            traj_valid = -3.0
        else:
            traj_valid = 0.0

        if reason == 'segment_binds_to_forbidden_road':
            road_binding = -forbidden_penalty
        elif reason in ('no_forbidden_roads', 'correct', 'no_trajectory_parsed',
                         'trajectory_too_short', 'no_road_geometries', 'no_violation'):
            road_binding = 0.0
        else:
            road_binding = 0.0

        if reason == 'crash_into_wall':
            n = details.get('num_unsafe', 0)
            wall = -min(n, BINDING_MIN_POINTS) * WALL_PENALTY
        elif reason in ('no_trajectory_parsed', 'trajectory_too_short', 'no_road_geometries'):
            wall = 0.0
        else:
            wall = 0.0

        diff_list = [traj_valid, road_binding, wall]
        dim_dict = {'diff_traj_valid': traj_valid, 'diff_road_binding': road_binding,
                    'diff_wall': wall}

        if abs(sum(diff_list) - score) > 0.01:
            logger.warning(
                f"diff_score sum ({sum(diff_list)}) != total score ({score}); "
                f"reason={reason}, diff={diff_list}"
            )

        return diff_list, dim_dict

    @staticmethod
    def _build_exit_diff_score(result):
        """Build diff_score for exit reward.

        Unified 3-dim format (same as no_entry):
            diff_score = [traj_valid, road_binding, wall]

        road_binding: +EXIT_REWARD_MATCH when matched to exit path, else 0.0
        wall:         wall-crash penalty (≤ 0)
        """
        reason = result.get('reason', 'unknown')
        details = result.get('details', {})
        score = result.get('score', 0.0)

        if reason == 'no_trajectory_parsed':
            traj_valid = -4.0
        elif reason == 'trajectory_too_short':
            traj_valid = -3.0
        else:
            traj_valid = 0.0

        if reason == 'exit_path_matched':
            road_binding = EXIT_REWARD_MATCH
        elif reason in ('no_trajectory_parsed', 'trajectory_too_short',
                         'no_road_geometries'):
            road_binding = 0.0
        else:
            road_binding = 0.0

        if reason == 'crash_into_wall':
            n = details.get('num_unsafe', 0)
            wall = -min(n, BINDING_MIN_POINTS) * WALL_PENALTY
        elif reason in ('no_trajectory_parsed', 'trajectory_too_short',
                         'no_road_geometries'):
            wall = 0.0
        else:
            wall = 0.0

        diff_list = [traj_valid, road_binding, wall]
        dim_dict = {'diff_traj_valid': traj_valid, 'diff_road_binding': road_binding,
                    'diff_wall': wall}

        if abs(sum(diff_list) - score) > 0.01:
            logger.warning(
                f"diff_score sum ({sum(diff_list)}) != total score ({score}); "
                f"reason={reason}, diff={diff_list}"
            )

        return diff_list, dim_dict

    # ── Debug logging ────────────────────────────────────────────────────────

    def _log_exit_debug(self, clip_id, data_source, solution_str,
                        action_traj, abs_traj, result,
                        exit_path_road_ids, vla_road_construction_info,
                        vla_goal_point, has_exit_sign):
        if not self._debug:
            return
        score = result.get('score', '?')
        reason = result.get('reason', '?')
        diff_score = result.get('diff_score', [])
        if self._step <= self._debug_first_n:
            self._dbg(f"=== VLA-Reward-v3.2 exit step={self._step} FULL DUMP ===")
            self._dbg(f"  clip_id:      {clip_id}")
            self._dbg(f"  score:        {score}")
            self._dbg(f"  reason:       {reason}")
            self._dbg(f"  diff_score:   {diff_score}")
            self._dbg(f"  exit_path_ids: {sorted(exit_path_road_ids)}")
            self._dbg(f"  exit_sign:    {has_exit_sign}")
            self._dbg(f"  sol_len:      {len(solution_str)}")
            self._dbg(f"  solution_str: {repr(solution_str)}")
        elif self._step % self._debug_log_every == 0:
            self._dbg(f"VLA-Reward-v3.2 exit step={self._step} | score={score} "
                      f"reason={reason} diff={diff_score} "
                      f"exit_sign={has_exit_sign} sol_len={len(solution_str)}")

    def _log_no_entry_debug(self, clip_id, data_source, solution_str,
                            action_traj, abs_traj, result,
                            forbidden_ids, road_graphs,
                            select_road_ids, select_road_cls,
                            freespace_info, vocab_path,
                            intersection_distance, forbidden_penalty,
                            intersection_info,
                            vla_goal_point, has_exit_sign):
        if not self._debug:
            return
        score = result.get('score', '?')
        reason = result.get('reason', '?')
        diff_score = result.get('diff_score', [])
        if self._step <= self._debug_first_n:
            self._dbg(f"=== VLA-Reward-v3.2 no_entry step={self._step} FULL DUMP ===")
            self._dbg(f"  clip_id:      {clip_id}")
            self._dbg(f"  score:        {score}")
            self._dbg(f"  reason:       {reason}")
            self._dbg(f"  diff_score:   {diff_score}")
            self._dbg(f"  intersection: dist={intersection_distance} penalty={forbidden_penalty}")
            self._dbg(f"  forbidden:    {forbidden_ids}")
            self._dbg(f"  exit_sign:    {has_exit_sign}")
            self._dbg(f"  sol_len:      {len(solution_str)}")
            self._dbg(f"  solution_str: {repr(solution_str)}")
        elif self._step % self._debug_log_every == 0:
            self._dbg(f"VLA-Reward-v3.2 no_entry step={self._step} | score={score} "
                      f"reason={reason} diff={diff_score} "
                      f"inter_dist={intersection_distance} "
                      f"exit_sign={has_exit_sign} sol_len={len(solution_str)}")

    @property
    def last_details(self):
        return self._last_details


# ═══════════════════════════════════════════════════════════════════════════════
#  Top-level function
# ═══════════════════════════════════════════════════════════════════════════════

_scorer = None
_scorer_debug = None


def vla_no_entry_reward(data_source, solution_str, ground_truth, extra_info,
                        debug=True, reward_version=None, iou_threshold=None,
                        debug_dir=None, **kwargs):
    global _scorer, _scorer_debug
    if _scorer is None or _scorer_debug != debug:
        _scorer = TaskVLANoEntryRewardV32(debug=debug, debug_dir=debug_dir)
        _scorer_debug = debug
    return _scorer(data_source, solution_str, ground_truth, extra_info)


# ═══════════════════════════════════════════════════════════════════════════════
#  __main__ — quick test
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import pandas as pd

    PARQUET_PATH = "/perception-hl/beijin.zhou/deeprl/260701_rl_exit_data/vln2_cotv3_UG_PARKING_EXIT_20260701_0534_part0000.parquet"
    NUM_SAMPLES = 3

    print(f"Loading parquet: {PARQUET_PATH}")
    df = pd.read_parquet(PARQUET_PATH)
    print(f"  {len(df)} samples\n")

    scorer = TaskVLANoEntryRewardV32(debug=True, debug_dir='/tmp/vla_reward_debug')

    for i in range(min(NUM_SAMPLES, len(df))):
        row = df.iloc[i]
        extra_info = row['extra_info']
        kwargs = extra_info['tools_kwargs']['calc_no-entry_reward']['calc_reward_kwargs']

        ds_type = extra_info.get('ds_type', 'no_entry')
        vla_road_construction_info = json.loads(kwargs.get('vla_road_construction_info', '{}') or '{}')
        exit_path_road_ids = set(json.loads(kwargs.get('exit_path_road_ids', '[]') or '[]'))

        all_road_geoms = build_road_geoms_from_vla_construction(vla_road_construction_info)

        print(f"{'='*60}")
        print(f"Sample {i}  clip_id={extra_info['clip_id']}  ds_type={ds_type}")
        print(f"  exit_path_road_ids: {sorted(exit_path_road_ids)}")
        print(f"  num roads from vla_construction: {len(all_road_geoms)}")

        test_trajs = [
            ("vocab format", "<action><action_200><action_304><action_302><action_399><action_108></action>"),
        ]

        for label, traj_str in test_trajs:
            result = scorer("no-entry_v3.2", traj_str, [], extra_info)
            score = result['score']
            reason = result.get('reason', '?')
            diff = result.get('diff_score', [])
            detail = result.get('details', {})
            matched = detail.get('matched_road_ids', [])
            print(f"  {label:12s} → score={score:6.2f}  diff={diff}  reason={reason}")
            if matched:
                for m in matched:
                    print(f"    seg#{m['segment_idx']} → road={m['road_id']}")

    print(f"\n{'='*60}")
    print("Done (v3.2).")
