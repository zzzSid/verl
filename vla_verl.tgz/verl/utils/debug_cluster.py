"""
Ray 集群多进程调试工具。
通过环境变量控制各进程的 debugpy 监听端口。
用法：
    export DEBUGPY_ENABLE=1            # 启用 debugpy
    export DEBUGPY_BASE_PORT=5678      # 基础端口（driver=5678, task_runner=5679, worker=5680+）
    export DEBUGPY_WAIT_CLIENT=1       # 启动后等待 VS Code attach（设为0则不等待）

在 main_ppo.py 中:
    from verl.utils.debug_cluster import attach_debugpy
    attach_debugpy("driver")  # 不同进程传入不同标识
"""

import os
import socket


def _get_free_port(base_port: int, max_attempts: int = 20) -> int:
    """找一个空闲端口。"""
    for offset in range(max_attempts):
        port = base_port + offset
        with socket.socket(socket.AF_INET, socket.SOL_SOCKET) as s:
            if s.connect_ex(("0.0.0.0", port)) != 0:
                return port
    raise RuntimeError(f"No free port found in range [{base_port}, {base_port + max_attempts})")


def attach_debugpy(role: str = "driver", wait_for_client: bool = True):
    """
    为当前进程启动 debugpy 监听。

    通过环境变量控制:
        DEBUGPY_ENABLE=1       → 启用
        DEBUGPY_BASE_PORT=5678 → 起始端口
        DEBUGPY_WAIT_CLIENT=1  → 是否等待 client attach
        DEBUGPY_{ROLE}_PORT=N  → 为特定 role 指定固定端口（可选）

    端口分配:
        driver       → base_port
        task_runner  → base_port + 1
        actor_worker → base_port + 2 + (RANK or 0)
        ref_worker   → base_port + base_port + 10 + (RANK or 0)  (预留)
    """
    if not os.environ.get("DEBUGPY_ENABLE", "").strip():
        return

    try:
        import debugpy
    except ImportError:
        print(f"[DEBUGPY] debugpy not installed. Install with: pip install debugpy")
        return

    base_port = int(os.environ.get("DEBUGPY_BASE_PORT", "5678"))
    # env var 优先，否则用函数参数
    wait = int(os.environ.get("DEBUGPY_WAIT_CLIENT", str(int(wait_for_client))))

    # 允许手动为某个 role 指定固定端口
    env_port = os.environ.get(f"DEBUGPY_{role.upper()}_PORT", "")
    if env_port:
        port = int(env_port)
    else:
        role_offsets = {
            "driver": 0,
            "task_runner": 1,
            "actor_worker": 2,
            "ref_worker": 12,
        }
        offset = role_offsets.get(role, 20)
        # 对于 worker，加上 RANK 避免同节点多 worker 端口冲突
        if role.endswith("worker"):
            rank = int(os.environ.get("RANK", os.environ.get("LOCAL_RANK", "0")))
            offset += rank
        port = _get_free_port(base_port + offset)

    host = "0.0.0.0"

    try:
        debugpy.listen((host, port))
        node = os.environ.get("RAY_NODE_IP", socket.gethostname())
        print(f"[DEBUGPY] role={role} listening on {node}:{port} (PID={os.getpid()})")

        if wait:
            print(f"[DEBUGPY] role={role} waiting for client to attach on {node}:{port}...")
            debugpy.wait_for_client()
            print(f"[DEBUGPY] role={role} client attached, resuming execution.")
    except Exception as e:
        print(f"[DEBUGPY] role={role} failed to start on {node}:{port}: {e}")
