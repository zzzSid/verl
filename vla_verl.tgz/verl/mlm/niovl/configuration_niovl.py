import copy
from .siglip import SiglipVisionConfig
from .qwen2 import Qwen2Config
from transformers.utils import logging
from transformers.configuration_utils import PretrainedConfig

logger = logging.get_logger(__name__)

class NIOVLConfig(PretrainedConfig):
    model_type = "niovl"
    is_composition = True

    def __init__(
        self,
        vision_config=None,
        llm_config=None,
        force_image_size=None,
        downsample_ratio=0.5,
        template=None,
        dynamic_image_size=False,
        use_thumbnail=False,
        ps_version="v1",
        min_dynamic_patch=1,
        max_dynamic_patch=12,
        use_LDP=False,
        **kwargs,
    ):
        super().__init__(**kwargs)
        if vision_config is None:
            vision_config = {}
            logger.info('vision_config is None. Initializing the SiglipVisionConfig with default values.')
        
        if llm_config is None:
            llm_config = {}
            logger.info('llm_config is None. Initializing the Qwen2Config config with default values (`Qwen2Config`).')
        
        self.vision_config = SiglipVisionConfig(**vision_config)
        self.llm_config = Qwen2Config(**llm_config)
        self.force_image_size = force_image_size
        self.downsample_ratio = downsample_ratio
        self.template = template
        self.dynamic_image_size = dynamic_image_size
        self.use_thumbnail = use_thumbnail
        self.ps_version = ps_version  # pixel shuffle version
        self.min_dynamic_patch = min_dynamic_patch
        self.max_dynamic_patch = max_dynamic_patch
        self.use_LDP = use_LDP

        # Compat: vllm internvl.py expects these on the top-level config
        self.select_layer = -1

    # Proxy common LLM config attributes for compatibility
    # vLLM expects text_config for LLM config
    @property
    def text_config(self):
        return self.llm_config

    @property
    def hidden_size(self):
        return self.llm_config.hidden_size

    @property
    def num_attention_heads(self):
        return self.llm_config.num_attention_heads

    @property
    def num_hidden_layers(self):
        return self.llm_config.num_hidden_layers

    @property
    def num_key_value_heads(self):
        return self.llm_config.num_key_value_heads

    @property
    def head_dim(self):
        return self.llm_config.head_dim

    @property
    def hidden_act(self):
        return self.llm_config.hidden_act

    @property
    def intermediate_size(self):
        return self.llm_config.intermediate_size

    @property
    def max_position_embeddings(self):
        return self.llm_config.max_position_embeddings

    @property
    def vocab_size(self):
        return self.llm_config.vocab_size

    def to_dict(self):
        """
        Serializes this instance to a Python dictionary. Override the default [`~PretrainedConfig.to_dict`].

        Returns:
            `Dict[str, any]`: Dictionary of all the attributes that make up this configuration instance,
        """
        output = copy.deepcopy(self.__dict__)
        output["model_type"] = self.__class__.model_type
        output["vision_config"] = self.vision_config.to_dict()
        output["llm_config"] = self.llm_config.to_dict()
        output["force_image_size"] = self.force_image_size
        output["downsample_ratio"] = self.downsample_ratio
        output["template"] = self.template
        output['dynamic_image_size'] = self.dynamic_image_size
        output['use_thumbnail'] = self.use_thumbnail
        output["ps_version"] = self.ps_version
        output['min_dynamic_patch'] = self.min_dynamic_patch
        output['max_dynamic_patch'] = self.max_dynamic_patch
        output["use_LDP"] = self.use_LDP

        return output
