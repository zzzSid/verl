#!/bin/bash
# ============================================================
# NIOVL 环境完整安装脚本（从头安装，不使用 --system-site-packages）
# 基于 INSTALL.md + 实际调试经验
# ============================================================
set -e

PROJECT_ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
VENV="$PROJECT_ROOT/.venv2"

echo "=== 1. 创建虚拟环境 ==="
python3 -m venv "$VENV"
source "$VENV/bin/activate"

# ============================================================
# 配置 pip 源
# ============================================================
export PIP_INDEX_URL="https://aiext-pypi.mirrors.aliyuncs.com/pg1-pip/pypi_index/simple/"
export PIP_EXTRA_INDEX_URL="https://mirrors.aliyun.com/pypi/simple/"
export PIP_TRUSTED_HOST="aiext-pypi.mirrors.aliyuncs.com mirrors.aliyun.com"

# 代理（按需开启）
# export HTTP_PROXY=http://proxy.nioint.com:8080
# export HTTPS_PROXY=http://proxy.nioint.com:8080

# ============================================================
echo "=== 2. 安装 Ray（必须最先装，确保依赖干净）==="
pip install "ray[default]==2.54.0"

ray stop --force 2>/dev/null; rm -rf /tmp/ray/session_* 2>/dev/null
timeout 30 ray start --head --port=6379 --disable-usage-stats 2>&1 | grep -q "Ray runtime started" \
    && echo "  ray OK" || { echo "  ray FAILED!"; exit 1; }
ray stop --force 2>/dev/null

# ============================================================
echo "=== 3. 安装 PPU torch 全家桶 ==="
pip install packaging setuptools wheel

pip install "torch==2.6.0+ppu1.7.0" "triton==3.0.0+ppu1.7.0"
pip install "torchvision==0.21.0+ppu1.7.0" \
            "torchaudio==2.6.0+ppu1.7.0" \
            "torchdata==0.11.0+ppu1.7.0"

# ============================================================
echo "=== 4. 软链接系统预编译包（PPU 兼容，跳过编译）==="
SYS="/usr/local/lib/python3.10/site-packages"
V2="$VENV/lib/python3.10/site-packages"

link_pkg() {
    local name=$1
    [ -e "$SYS/$name" ] && ln -sf "$SYS/$name" "$V2/$name" && echo "  linked $name"
}

# flash-attn (PPU 编译版，系统预装)
link_pkg flash_attn
ln -sf "$SYS/flash_attn_2_cuda.cpython-310-x86_64-linux-gnu.so" "$V2/"
ln -sf "$SYS/flash_attn-2.7.2.dist-info" "$V2/"

# numba + llvmlite（系统预编译，跳过编译）
link_pkg numba
ln -sf "$SYS/numba-0.62.1+0.ge6a402793.dirty.dist-info" "$V2/"
link_pkg llvmlite
ln -sf "$SYS/llvmlite-0.45.1.dist-info" "$V2/"

# pyzmq
link_pkg zmq
link_pkg pyzmq.libs
ln -sf "$SYS/pyzmq-27.1.0.dist-info" "$V2/"

# numpy 不用软链接（pip 装包时会覆盖系统文件导致权限错误），改为 pip 安装
pip install numpy

# ============================================================
echo "=== 5. 下载 vllm + acext PPU 预编译 wheel（绕过策略系统）==="
PPU_GENERIC="https://aiext-pypi.mirrors.aliyuncs.com/pg1-pip/generic"

if [ ! -f /tmp/vllm-ppu.whl ]; then
    echo "  下载 vllm (1.3GB)..."
    curl -L --retry 3 -o /tmp/vllm-ppu.whl \
        "$PPU_GENERIC/vllm/0.8.5+ppu1.7.0/vllm-0.8.5+cu126torch2.6.0ubuntu2204oe-cp310-cp310-linux_x86_64.whl"
fi
pip install --no-deps /tmp/vllm-ppu.whl

if [ ! -f /tmp/acext-ppu.whl ]; then
    echo "  下载 acext (630MB)..."
    curl -L --retry 3 -o /tmp/acext-ppu.whl \
        "$PPU_GENERIC/acext/1.0.0+ppu1.7.0/acext-1.0.0+cu126torch2.6.0ubuntu2204oe-cp310-cp310-linux_x86_64.whl"
fi
pip install --no-deps /tmp/acext-ppu.whl

# xformers 必须用 PPU 编译版（阿里云标准 CUDA 版不支持 PPU）
if [ ! -f /tmp/xformers-ppu.whl ]; then
    echo "  下载 xformers (196MB)..."
    curl -L --retry 3 -o /tmp/xformers-ppu.whl \
        "$PPU_GENERIC/xformers/0.0.29.post1+ppu1.7.0/xformers-0.0.29.post1+cu124torch2.6.0ubuntu2204oe-cp310-cp310-linux_x86_64.whl"
fi
pip install --force-reinstall --no-deps /tmp/xformers-ppu.whl

# ============================================================
echo "=== 6. 安装 transformers 和 vllm 依赖 ==="
# ⚠️ transformers 必须 4.52.x！5.x 需要 torch.float8_e8m0fnu，PPU torch 2.6.0 不支持
pip install "transformers==4.52.3"

pip install \
    "einops" "scipy" "sentencepiece" "cachetools" "blake3" \
    "psutil" "py-cpuinfo" "python-json-logger" "watchfiles" \
    "tiktoken" "cloudpickle" "partial-json-parser" "msgspec" \
    "ninja" "lark==1.2.2" "gguf>=0.13.0" \
    "compressed-tensors==0.9.3" "depyf==0.18.0" \
    "xgrammar==0.1.18" \
    "outlines==0.1.11" \
    "lm-format-enforcer<0.11,>=0.10.11" \
    "llguidance<0.8.0,>=0.7.9" \
    "fastapi[standard]>=0.115.0" \
    "openai>=1.52.0" "pydantic>=2.9" \
    "prometheus-fastapi-instrumentator>=7.0.0" \
    "mistral_common[opencv]>=1.5.4" "opencv-python-headless" \
    "aiohttp" "sentencepiece" "filelock" "huggingface-hub" "pyyaml" "requests"

# OpenTelemetry: 只装 SDK（不装 exporter-otlp，会导致 ray dashboard_agent 崩溃）
pip install "opentelemetry-sdk" "opentelemetry-semantic-conventions-ai<0.5.0,>=0.4.1"

# protobuf: 必须 >=5.29.6（google-api-core 要求），否则 ray GCS 通信失败
pip install "protobuf==6.33.6"

# 项目额外依赖
pip install scikit-learn matplotlib

# ============================================================
echo "=== 7. 私有源包 ==="
pip install \
    -i https://artifactory.nioint.com/artifactory/api/pypi/dd-pypi-all-virtual/simple \
    --trusted-host artifactory.nioint.com \
    "read-cache-op-py==1.7.4" "niofs==1.1.2+read-cache-op"

# ============================================================
echo "=== 8. 项目依赖 ==="
pip install \
    math_verify codetiming hydra-core pybind11 pylatexenc wandb \
    hf-transfer qwen-vl-utils liger-kernel mathruler py-spy pyext \
    pre-commit ruff "tensordict==0.6.2" "optree>=0.13.0" \
    peft "pyarrow>=19.0.0" datasets pandas

# ============================================================
echo "=== 9. 安装项目本身 ==="
pip install --no-deps -e "$PROJECT_ROOT"

# ============================================================
echo "=== 10. 配置 LD_LIBRARY_PATH ==="
ACE_LIB="$VENV/lib/python3.10/site-packages/lib"
TORCH_LIB="$VENV/lib/python3.10/site-packages/torch/lib"
PPU_LIBS="/usr/local/PPU_SDK/CUDA_SDK/lib64:/usr/local/PPU_SDK/lib"

grep -q "PPU vllm" "$VENV/bin/activate" 2>/dev/null || cat >> "$VENV/bin/activate" << EOF

# PPU vllm + acext shared libraries
export LD_LIBRARY_PATH="$ACE_LIB:$TORCH_LIB:$PPU_LIBS:\$LD_LIBRARY_PATH"
EOF

# ============================================================
echo "=== 11. 打 vLLM internvl.py NIOVL 补丁 ==="
source "$VENV/bin/activate"

INTERNVL="$VENV/lib/python3.10/site-packages/vllm/model_executor/models/internvl.py"

python3 - "$INTERNVL" << 'PATCH_SCRIPT'
import re
import sys

internvl_path = sys.argv[1]
with open(internvl_path, 'r') as f:
    content = f.read()

# Patch 1: _init_vision_model — 添加 NIOVL 检测（使用 SiglipVisionModel）
old1 = '''    def _init_vision_model(
        self,
        config: PretrainedConfig,
        quant_config: Optional[QuantizationConfig],
        *,
        is_mono: bool,
        prefix: str,
    ):
        if not is_mono:'''
new1 = '''    def _init_vision_model(
        self,
        config: PretrainedConfig,
        quant_config: Optional[QuantizationConfig],
        *,
        is_mono: bool,
        prefix: str,
    ):
        # Check if this is NIOVL model - use SiglipVisionModel instead of InternVisionModel
        if hasattr(config, "model_type") and config.model_type == "niovl":
            from .siglip import SiglipVisionModel
            return SiglipVisionModel(config.vision_config, prefix=prefix)
        if not is_mono:'''
content = content.replace(old1, new1)

# Patch 2: extract_feature — SiglipVisionModel 分支（无 CLS token）
old2 = '''    def extract_feature(self, pixel_values: torch.Tensor) -> torch.Tensor:
        vit_embeds = self.vision_model(pixel_values=pixel_values)
        vit_embeds = vit_embeds[:, 1:, :]

        h = w = int(vit_embeds.shape[1]**0.5)
        vit_embeds = vit_embeds.reshape(vit_embeds.shape[0], h, w, -1)
        vit_embeds = self.pixel_shuffle(vit_embeds,
                                        scale_factor=self.downsample_ratio)
        vit_embeds = vit_embeds.reshape(vit_embeds.shape[0], -1,
                                        vit_embeds.shape[-1])
        vit_embeds = self.mlp1(vit_embeds)
        return vit_embeds'''
new2 = '''    def extract_feature(self, pixel_values: torch.Tensor) -> torch.Tensor:
        if hasattr(self.vision_model, "vision_model"):
            # SiglipVisionModel path (NIOVL) — 无 CLS token
            vit_embeds = self.vision_model(pixel_values=pixel_values)
            h = w = int(vit_embeds.shape[1] ** 0.5)
            vit_embeds = vit_embeds.reshape(vit_embeds.shape[0], h, w, -1)
            vit_embeds = self.pixel_shuffle(vit_embeds, scale_factor=self.downsample_ratio)
            vit_embeds = vit_embeds.reshape(vit_embeds.shape[0], -1, vit_embeds.shape[-1])
            vit_embeds = self.mlp1(vit_embeds)
            h_after_ps, w_after_ps = h // 2, w // 2
            vit_embeds = vit_embeds.permute(0, 2, 1).reshape(vit_embeds.shape[0], -1, h_after_ps, w_after_ps)
            vit_embeds = self.LDPNetv2_dwn(vit_embeds)
            vit_embeds = self.LDPNetv2_peg(vit_embeds) + vit_embeds
            vit_embeds = vit_embeds.flatten(2).transpose(1, 2)
            return vit_embeds

        vit_embeds = self.vision_model(pixel_values=pixel_values)
        vit_embeds = vit_embeds[:, 1:, :]

        h = w = int(vit_embeds.shape[1]**0.5)
        vit_embeds = vit_embeds.reshape(vit_embeds.shape[0], h, w, -1)
        vit_embeds = self.pixel_shuffle(vit_embeds,
                                        scale_factor=self.downsample_ratio)
        vit_embeds = vit_embeds.reshape(vit_embeds.shape[0], -1,
                                        vit_embeds.shape[-1])
        vit_embeds = self.mlp1(vit_embeds)
        return vit_embeds'''
content = content.replace(old2, new2)

# Patch 3: skip_prefixes — 添加 adaptor_model
old3 = '''        skip_prefixes = [
            "action_embed", "temporal_embed", "track_embed",
            "track_embed_decoder", "box_token", "cg_criterion", "cg_model",
            "loc_encoder", "loc_decoder", "sam", "temporal_token",
            "track_token"
        ]'''
new3 = '''        skip_prefixes = [
            "action_embed", "temporal_embed", "track_embed",
            "track_embed_decoder", "box_token", "cg_criterion", "cg_model",
            "loc_encoder", "loc_decoder", "sam", "temporal_token",
            "track_token", "adaptor_model"
        ]'''
content = content.replace(old3, new3)

# Patch 4: __init__ — NIOVL 的 LDPNetv2 层初始化
old4 = '''        self.mlp1 = self._init_mlp1(config)

        self.img_context_token_id = None'''
new4 = '''        self.mlp1 = self._init_mlp1(config)

        # NIOVL: initialize LDPNetv2 adaptor layers for extract_feature
        if hasattr(config, "model_type") and config.model_type == "niovl" and getattr(config, "use_LDP", False):
            llm_hidden_size = config.text_config.hidden_size
            self.LDPNetv2_dwn = nn.Sequential(
                nn.AdaptiveAvgPool2d((8, 8))
            )
            self.LDPNetv2_peg = nn.Sequential(
                nn.Conv2d(llm_hidden_size, llm_hidden_size, 3, 1, 1, bias=True, groups=llm_hidden_size)
            )

        self.img_context_token_id = None'''
content = content.replace(old4, new4)

with open(internvl_path, 'w') as f:
    f.write(content)

print("  vLLM internvl.py patches applied (1-4)")
PATCH_SCRIPT

# ============================================================
echo "=== 12. 验证 ==="
source "$VENV/bin/activate"

python -c "
import torch; print('1. torch:', torch.__version__)
import transformers; print('2. transformers:', transformers.__version__)
import flash_attn; print('3. flash-attn:', flash_attn.__version__)
import vllm; print('4. vllm:', vllm.__version__)
import ray; print('5. ray:', ray.__version__)
print('=== ALL OK ===')
"

ray stop --force 2>/dev/null; rm -rf /tmp/ray/session_* 2>/dev/null
echo ""
echo "============================================="
echo " 安装完成！"
echo "============================================="
echo " 源码修改已自动完成："
echo "   - verl/mlm/niovl/configuration_niovl.py"
echo "   - verl/workers/fsdp_workers.py"
echo "   - verl/utils/tokenizer.py"
echo "   - vLLM internvl.py (4 patches)"
echo ""
echo " 使用方式:"
echo "   source .venv2/bin/activate"
echo "   ray start --head"
echo "   运行训练脚本"
echo "============================================="
