import torch
from typing import Optional, List, Union, Tuple
from transformers import GenerationConfig
from transformers.utils import logging
from transformers.modeling_utils import PreTrainedModel
from transformers.modeling_outputs import CausalLMOutputWithPast
from .configuration_niovl import NIOVLConfig
from .siglip import SiglipVisionModel
from .qwen2 import Qwen2ForCausalLM
from .adaptor import NIOAdaptor

logger = logging.get_logger(__name__)

class NIOVLModel(PreTrainedModel):
    config_class = NIOVLConfig
    main_input_name = "pixel_values"
    _no_split_modules = ["SiglipEncoderLayer", "Qwen2DecoderLayer"]
    _supports_flash_attn_2 = True
    supports_gradient_checkpointing = True
    _supports_gradient_checkpointing = True

    def __init__(
        self,
        config: NIOVLConfig,
        img_context_token_id=None,
        vision_model=None,
        language_model=None,
        adaptor_model=None,
        
    ):
        super().__init__(config)

        self.img_context_token_id = img_context_token_id
        image_size = config.force_image_size or 512
        patch_size = config.vision_config.patch_size
        self.patch_size = patch_size
        self.template = config.template
        self.use_LDP = config.use_LDP
        self.num_image_token = int((image_size // patch_size) ** 2 * (config.downsample_ratio ** 2)) // 4
        self.downsample_ratio = config.downsample_ratio
        self.ps_version = config.ps_version

        if vision_model is not None:
            self.vision_model = vision_model
        else:
            self.vision_model = SiglipVisionModel(config.vision_config)
        
        if language_model is not None:
            self.language_model = language_model
        else:
            self.language_model = Qwen2ForCausalLM(config.llm_config)
        
        if adaptor_model is not None:
            self.adaptor_model = adaptor_model
        else:
            self.adaptor_model = NIOAdaptor(
                config.vision_config.hidden_size, 
                config.llm_config.hidden_size, 
                config.downsample_ratio, 
                config.use_LDP,
                config.ps_version,
            )
    

    def forward(
        self,
        pixel_values: torch.FloatTensor,
        # pixel_attention_mask: torch.Tensor,
        # spatial_shapes: torch.LongTensor,
        input_ids: torch.LongTensor = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        image_flags: Optional[torch.LongTensor] = None,
        past_key_values: Optional[List[torch.FloatTensor]] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        cu_seq_lens_q: Optional[torch.LongTensor] = None,
        cu_seq_lens_k: Optional[torch.LongTensor] = None,
        max_length_q: Optional[torch.LongTensor] = None,
        max_length_k: Optional[torch.LongTensor] = None,
        **kwargs,
    )-> Union[Tuple, CausalLMOutputWithPast]:
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict

        vit_embeds = self.extract_feature(pixel_values)

        if image_flags is not None:
            vit_embeds = vit_embeds[image_flags.squeeze(-1) == 1]
        

        input_embeds = self.language_model.get_input_embeddings()(input_ids).clone()
        B, N, C = input_embeds.shape
        input_embeds = input_embeds.reshape(B * N, C)

        if torch.distributed.is_initialized() and torch.distributed.get_rank() == 0:
            vit_batch_size = pixel_values.shape[0]
            print(f'dynamic ViT batch size: {vit_batch_size}, images per sample: {vit_batch_size / B}, dynamic token length: {N}')
        
        selected = (input_ids.reshape(B * N) == self.img_context_token_id)
        try:
            input_embeds[selected] = input_embeds[selected] * 0.0 + vit_embeds.reshape(-1, C)
            ignore_flag = False
        except Exception as e:
            vit_embeds = vit_embeds.reshape(-1, C)
            print(f'warning: {e}, input_embeds[selected].shape={input_embeds[selected].shape}, '
                  f'vit_embeds.shape={vit_embeds.shape}')
            n_token = selected.sum()
            input_embeds[selected] = input_embeds[selected] * 0.0 + vit_embeds[:n_token]
            ignore_flag = True
        
        input_embeds = input_embeds.reshape(B, N, C)

        outputs = self.language_model(
            inputs_embeds=input_embeds,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
            cu_seq_lens_q=cu_seq_lens_q,
            cu_seq_lens_k=cu_seq_lens_k,
            max_length_q=max_length_q,
            max_length_k=max_length_k,
            **kwargs,
        )
        logits = outputs.logits

        loss = None
        if labels is not None:
            if cu_seq_lens_q is not None:
                shift_labels = labels.flatten()
                cu_seq_lens = cu_seq_lens_q.to('cpu', non_blocking=True)
                for i in range(len(cu_seq_lens) - 1):
                    start_idx = cu_seq_lens[i].item()
                    end_idx = cu_seq_lens[i + 1].item()
                    left_len = (end_idx - 1) - start_idx
                    right_len = end_idx - (start_idx + 1)

                    if left_len != right_len:
                        print(f"Mismatch at i={i}: start={start_idx}, end={end_idx}, left_len={left_len}, right_len={right_len}, shift_labels_len={len(shift_labels)}")
                    if end_idx - start_idx > 1:
                        shift_labels[start_idx:end_idx-1] = shift_labels[start_idx+1:end_idx].clone()
                        shift_labels[end_idx-1] = -100

                shift_logits = logits.view(-1, self.language_model.config.vocab_size)
                loss_fct = torch.nn.CrossEntropyLoss()
                loss = loss_fct(shift_logits, shift_labels)
            else:
                # Standard loss calculation for non-packed sequences
                # Both logits and labels need to be shifted to align predictions
                shift_logits = logits[..., :-1, :].contiguous()
                shift_labels = labels[..., 1:].contiguous()
                # Flatten the tokens
                loss_fct = torch.nn.CrossEntropyLoss()
                shift_logits = shift_logits.view(-1, self.language_model.config.vocab_size)
                shift_labels = shift_labels.view(-1)
                # Enable model parallelism
                shift_labels = shift_labels.to(shift_logits.device)
                loss = loss_fct(shift_logits, shift_labels)
            if ignore_flag:
                loss = loss * 0.0

        if not return_dict:
            output = (logits,) + outputs[1:]
            return (loss,) + output if loss is not None else output

        return CausalLMOutputWithPast(
            loss=loss,
            logits=logits,
            past_key_values=outputs.past_key_values,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
        )
    

    def extract_feature(
        self,
        pixel_values,   # B, 3, 512, 512
        # pixel_attention_mask,
        # spatial_shapes,
    ):
        
        vit_embeds = self.vision_model(
            pixel_values=pixel_values,
            # attention_mask=pixel_attention_mask,
            # spatial_shapes=spatial_shapes,
        ).last_hidden_state     # B, 1024, 768
        vit_embeds = self.adaptor_model(vit_embeds, self.downsample_ratio)
        return vit_embeds

    

    def chat(
        self,
        tokenizer,
        pixel_values,
        question,
        generation_config,
        history=None,
        return_history=False,
        num_patches_list=None,
        IMG_START_TOKEN='<img>',
        IMG_END_TOKEN='</img>',
        IMG_CONTEXT_TOKEN='<IMG_CONTEXT>',
        verbose=False
    ):

        if history is None and pixel_values is not None and '<image>' not in question:
            question = '<image>\n' + question

        if num_patches_list is None:
            num_patches_list = [pixel_values.shape[0]] if pixel_values is not None else []
        assert pixel_values is None or len(pixel_values) == sum(num_patches_list)

        for num_patches in num_patches_list:
            image_tokens = IMG_START_TOKEN + IMG_CONTEXT_TOKEN * self.num_image_token * num_patches + IMG_END_TOKEN
            question = question.replace('<image>', image_tokens, 1)

        if self.img_context_token_id is None:
            self.img_context_token_id = tokenizer.convert_tokens_to_ids(IMG_CONTEXT_TOKEN)

        from mlm.utils.conversation import get_conv_template

        template = get_conv_template(self.template)
        eos_token_id = tokenizer.convert_tokens_to_ids(template.sep)

        history = [] if history is None else history
        for (old_question, old_answer) in history:
            template.append_message(template.roles[0], old_question)
            template.append_message(template.roles[1], old_answer)
        template.append_message(template.roles[0], question)
        template.append_message(template.roles[1], None)
        query = template.get_prompt()

        if verbose and pixel_values is not None:
            image_bs = pixel_values.shape[0]
            print(f'dynamic ViT batch size: {image_bs}')


        model_inputs = tokenizer(query, return_tensors='pt')
        input_ids = model_inputs['input_ids'].cuda()
        attention_mask = model_inputs['attention_mask'].cuda()
        generation_config['eos_token_id'] = eos_token_id
        generation_output = self.generate(
            pixel_values=pixel_values,
            input_ids=input_ids,
            attention_mask=attention_mask,
            **generation_config
        )
        response = tokenizer.batch_decode(generation_output, skip_special_tokens=False)[0]
        response = response.split(template.sep)[0].strip()
        history.append((question, response))
        if return_history:
            return response, history
        else:
            query_to_print = query.replace(IMG_CONTEXT_TOKEN, '')
            query_to_print = query_to_print.replace(f'{IMG_START_TOKEN}{IMG_END_TOKEN}', '<image>')
            if verbose:
                print(query_to_print, response)
            return response

    def batch_chat(
        self,
        tokenizer,
        pixel_values,
        image_counts,
        questions,
        generation_config,
        history=None,
        return_history=False,
        IMG_START_TOKEN='<img>',
        IMG_END_TOKEN='</img>',
        IMG_CONTEXT_TOKEN='<IMG_CONTEXT>',
    ):
        if history is not None or return_history:
            print('Now multi-turn chat is not supported in batch_chat.')
            raise NotImplementedError

        if len(image_counts) == 0:
            return []

        if isinstance(image_counts[0], int):
            image_counts = [[int(x)] for x in image_counts]
        else:
            image_counts = [[int(x) for x in counts] for counts in image_counts]

        total_tiles = sum(sum(c) for c in image_counts)
        assert pixel_values.shape[0] == total_tiles, \
            f"pixel_values tiles({pixel_values.shape[0]}) != total_tiles({total_tiles}) from image_counts"

        img_context_token_id = tokenizer.convert_tokens_to_ids(IMG_CONTEXT_TOKEN)
        self.img_context_token_id = img_context_token_id

        from mlm.utils.conversation import get_conv_template

        template0 = get_conv_template(self.template)
        eos_token_id = tokenizer.convert_tokens_to_ids(template0.sep)
        generation_config['eos_token_id'] = eos_token_id
        sep = template0.sep

        if isinstance(generation_config, dict):
            generation_config = GenerationConfig(**generation_config)

        def build_image_tokens(counts):
            return [
                IMG_START_TOKEN + (IMG_CONTEXT_TOKEN * self.num_image_token * tiles) + IMG_END_TOKEN
                for tiles in counts
            ]

        def inject_images(question, tokens):
            k = len(tokens)
            if k == 0:
                return question

            placeholder = '<image>'
            cnt = question.count(placeholder)
            if cnt == 0:
                question = placeholder + '\n' + question
                cnt = 1
            if cnt < k:
                question = (placeholder + '\n') * (k - cnt) + question

            parts = question.split(placeholder)
            out = parts[0]
            for i in range(k):
                out += tokens[i]
                if i + 1 < len(parts):
                    out += parts[i + 1]
            if len(parts) > k + 1:
                out += placeholder + placeholder.join(parts[k + 1:])
            return out

        queries = []
        for idx, counts in enumerate(image_counts):
            tokens = build_image_tokens(counts)
            q = inject_images(questions[idx], tokens)

            template = get_conv_template(self.template)
            template.append_message(template.roles[0], q)
            template.append_message(template.roles[1], None)
            queries.append(template.get_prompt())

        old_padding_side = tokenizer.padding_side
        tokenizer.padding_side = 'left'
        model_inputs = tokenizer(queries, return_tensors='pt', padding=True)
        tokenizer.padding_side = old_padding_side

        input_ids = model_inputs['input_ids'].cuda(non_blocking=True)
        attention_mask = model_inputs['attention_mask'].cuda(non_blocking=True)

        generation_output = self.generate(
            pixel_values=pixel_values,
            input_ids=input_ids,
            attention_mask=attention_mask,
            generation_config=generation_config,
        )

        responses = tokenizer.batch_decode(generation_output, skip_special_tokens=False)
        responses = [r.split(sep)[0].strip() for r in responses]
        return responses

    @torch.no_grad()
    def generate(
            self,
            pixel_values: Optional[torch.FloatTensor] = None,
            input_ids: Optional[torch.FloatTensor] = None,
            attention_mask: Optional[torch.LongTensor] = None,
            visual_features: Optional[torch.FloatTensor] = None,
            generation_config: Optional[GenerationConfig] = None,
            output_hidden_states: Optional[bool] = None,
            return_dict: Optional[bool] = None,
            **generate_kwargs,
    ) -> torch.LongTensor:

        assert self.img_context_token_id is not None
        if pixel_values is not None:
            if visual_features is not None:
                vit_embeds = visual_features
            else:
                vit_embeds = self.extract_feature(pixel_values)

            input_embeds = self.language_model.get_input_embeddings()(input_ids)
            B, N, C = input_embeds.shape
            input_embeds = input_embeds.reshape(B * N, C)

            selected = (input_ids.reshape(B * N) == self.img_context_token_id)
            assert selected.sum() != 0
            input_embeds[selected] = vit_embeds.reshape(-1, C).to(input_embeds.device)

            input_embeds = input_embeds.reshape(B, N, C)
        else:
            input_embeds = self.language_model.get_input_embeddings()(input_ids)

        outputs = self.language_model.generate(
            inputs_embeds=input_embeds,
            attention_mask=attention_mask,
            generation_config=generation_config,
            output_hidden_states=output_hidden_states,
            # return_dict=return_dict,
            use_cache=True,
            **generate_kwargs,
        )

        return outputs