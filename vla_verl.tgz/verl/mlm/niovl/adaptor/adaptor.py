import warnings
import torch.nn as nn

class NIOAdaptor(nn.Module):
    def __init__(
        self,
        vit_hidden_size,
        llm_hidden_size,
        downsample_ratio,
        use_LDP=False,
        ps_version="v1",
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.use_LDP = use_LDP
        self.ps_version = ps_version
        self.mlp1 = nn.Sequential(
            nn.LayerNorm(vit_hidden_size * int(1 / downsample_ratio) ** 2),
            nn.Linear(vit_hidden_size * int(1 / downsample_ratio) ** 2, llm_hidden_size),
            nn.GELU(),
            nn.Linear(llm_hidden_size, llm_hidden_size)
        )
        for layer in self.mlp1:
            if isinstance(layer, nn.Linear):
                layer.weight.data.normal_(mean=0.0, std=0.02)
                if layer.bias is not None:
                    layer.bias.data.zero_()
        
        if self.use_LDP:
            self.LDPNetv2_dwn = nn.Sequential(
                nn.AdaptiveAvgPool2d((8, 8))
            )
            self.LDPNetv2_peg = nn.Sequential(
                nn.Conv2d(llm_hidden_size, llm_hidden_size, 3, 1, 1, bias=True, groups=llm_hidden_size)
            )
            for layer in self.LDPNetv2_peg:
                if isinstance(layer, nn.Conv2d):
                    layer.weight.data.normal_(mean=0.0, std=0.02)
                    if layer.bias is not None:
                        layer.bias.data.zero_()
    

    def pixel_shuffle(self, x, scale_factor=0.5):
        n, w, h, c = x.size()
        # N, W, H, C --> N, W, H * scale, C // scale
        x = x.view(n, w, int(h * scale_factor), int(c / scale_factor))
        # N, W, H * scale, C // scale --> N, H * scale, W, C // scale
        x = x.permute(0, 2, 1, 3).contiguous()
        # N, H * scale, W, C // scale --> N, H * scale, W * scale, C // (scale ** 2)
        x = x.view(n, int(h * scale_factor), int(w * scale_factor),
                   int(c / (scale_factor * scale_factor)))
        if self.ps_version == 'v1':
            warnings.warn("In ps_version 'v1', the height and width have not been swapped back, "
                          'which results in a transposed image.')
        else:
            x = x.permute(0, 2, 1, 3).contiguous()
        return x


    def forward(self, vit_embeds, scale_factor):
        h = w = int(vit_embeds.shape[1] ** 0.5)
        vit_embeds = vit_embeds.reshape(vit_embeds.shape[0], h, w, -1)
        vit_embeds = self.pixel_shuffle(vit_embeds, scale_factor)
        vit_embeds = vit_embeds.reshape(vit_embeds.shape[0], -1, vit_embeds.shape[-1])
        vit_embeds = self.mlp1(vit_embeds)#.to(pixel_values.device)

        if self.use_LDP:
            vit_embeds = vit_embeds.permute(0, 2, 1).reshape(vit_embeds.shape[0], -1, h//2, w//2)  # B, C, H/2, W/2
            vit_embeds = self.LDPNetv2_dwn(vit_embeds)    # B, C, H/4, W/4
            vit_embeds = self.LDPNetv2_peg(vit_embeds) + vit_embeds    # B, C, H/4, W/4
            vit_embeds = vit_embeds.flatten(2).transpose(1, 2)      # B, H/4 * W/4, C
        return vit_embeds