# GDPO 在 VERL 框架中的适配分析

> GDPO (Group Direct Preference Optimization) — 多维 reward 组内标准化，提供细粒度学习信号。

---

## 一、总览

GDPO 的核心创新：每个 response 产生一个**多维 reward 向量**（而非单一标量），在组内按维度分别标准化后求和形成标量 advantage。

完整适配路径（6 个阶段）：

```
Reward 函数 → Reward Manager → compute_reward → compute_advantage(GDPO分支)
  → compute_gdpo_outcome_advantage → masked_whiten → PPO Policy Loss
```

---

## 二、阶段 1：Reward 函数生成多维 `diff_score`

**文件**: `verl/utils/reward_score/task_no_entry.py` (行 208–228)

```python
each_score_list = [grounding_i + category_i for ...]  # 每个 GT 条目一个分数
return {
    "score": format_score + content_score_norm,      # 总标量，用于日志
    "diff_score": each_score_list + [format_score],  # ← ragged 多维向量
    "format_score": format_score,
    "content_score": content_score_norm,
    ...
}
```

**关键**：`diff_score` 是一个**变长 list**——不同 prompt 的 GT 条目数不同：

```
Prompt A（3 个 GT）：[0.8, 0.5, 0.9, 1.0]   # 前 3 个是 content，最后是 format
Prompt B（5 个 GT）：[0.7, 0.3, 0.6, 0.4, 0.8, 1.0]
```

长度 `L = 该条目的 GT 数量 + 1（format_score）`。

---

## 三、阶段 2：Reward Manager 透传

**文件**: `verl/workers/reward_manager/naive.py` (行 84–88)

```python
if isinstance(score, dict):
    reward = score["score"]
    for key, value in score.items():
        reward_extra_info[key].append(value)   # diff_score 原样存入 list
```

`NaiveRewardManager` 不做任何转换，`diff_score` 以 **Python list of lists** 的形式存入 `reward_extra_info["diff_score"]`。

---

## 四、阶段 3：`compute_reward` 提取并拆分

**文件**: `verl/trainer/ppo/reward.py` (行 127–164)

```python
reward_result = reward_fn(data, return_dict=True)
reward_extra_infos_dict = reward_result["reward_extra_info"]
diff_score = reward_extra_infos_dict.get("diff_score", None)  # list of lists
# ...
return reward_tensor, {}, diff_score, seperate_score
#                        ^^^^^^^^^^  ^^^^^^^^^^^^^^
#                        ragged 2D   各维度独立 tensor（仅用于日志）
```

返回值中有**两套 reward 表示**：

| 变量 | 结构 | 用途 |
|------|------|------|
| `reward_tensor` | `(bs, response_length)` tensor | 标准 token-level，用于 GAE/GRPO 等模式 |
| `diff_score` | `list[list[float]]` | ragged 多维，**GDPO 专用** |
| `seperate_score` | `dict[str, tensor]` | 各维度独立 tensor，仅用于**日志记录** |

---

## 五、阶段 4：`compute_advantage` 的 GDPO 分支

**文件**: `verl/trainer/ppo/ray_trainer.py` (行 254–271)

```python
elif adv_estimator == AdvantageEstimator.GDPO:
    # 1. 获取 response_mask
    response_mask = attention_mask[:, -response_length:]

    # 2. 传入 ragged 2D reward
    token_level_scores = diff_num_score  # list of lists
    new_advantage, returns = core_algos.compute_gdpo_outcome_advantage(
        token_level_rewards=token_level_scores,
        response_mask=data.batch["response_mask"],
        index=data.non_tensor_batch["uid"],  # 按 prompt 分组
    )

    # 3. 全局白化
    advantages = masked_whiten(new_advantage, response_mask) * response_mask
    data.batch["advantages"] = advantages
    data.batch["returns"] = advantages          # advantage 和 return 相同
```

### 与 GRPO 分支的关键差异

```python
# GRPO（行 205-211）：标量 reward，支持 multi_turn loss_mask
if multi_turn:
    grpo_calculation_mask = data.batch["loss_mask"][:, -response_length:]
advantages, returns = compute_grpo_outcome_advantage(
    token_level_rewards=data.batch["token_level_rewards"],  # 标量 tensor
    ...
)

# GDPO（行 254-271）：多维 reward，不检查 multi_turn
token_level_scores = diff_num_score  # ragged list
# ⚠️ 未使用 multi_turn 参数，未替换 response_mask 为 loss_mask
```

> **注意**：GDPO 分支未像 GRPO 那样处理 multi-turn 的 `loss_mask`，在 multi-turn 场景下 group 统计可能用到不该参与 loss 计算的 token。这是当前版本的已知局限。

---

## 六、阶段 5：`compute_gdpo_outcome_advantage` 核心算法

**文件**: `verl/trainer/ppo/core_algos.py` (行 112–177)

### 函数签名

```python
def compute_gdpo_outcome_advantage(
    token_level_rewards: Sequence[Sequence[float]],  # ragged 2D
    response_mask: torch.Tensor,                     # (bs, response_length)
    index: np.ndarray,                               # (bs,) 分组 ID
    epsilon: float = 1e-6,
    norm_adv_by_std_in_grpo: bool = True,
):
```

### Step A: 按 uid 分组（行 135–139）

```python
id2inds = defaultdict(list)
for i in range(bs):
    id2inds[index[i]].append(i)       # 同 prompt 的不同 rollout → 同组
    id2inds[index[i]].append(token_level_rewards[i])
```

### Step B: 组内按维度标准化（行 141–175）

```python
for idx, inds in id2inds.items():
    L = len(token_level_rewards[inds[0]])           # 该组的 reward 维度数

    # 组内 stack: (rollout_n, L)
    group = torch.stack(
        [torch.as_tensor(token_level_rewards[i]) for i in inds], dim=0
    )

    # 安全检查：组内长度一致
    if group.shape[1] != L:
        raise ValueError(f"group {idx} has inconsistent num_score lengths")

    # 按维度（dim=0）计算组内均值和标准差
    if group.shape[0] == 1:
        mu = torch.zeros(L)                         # 单样本组：零均值
        sd = torch.ones(L)                          # 单样本组：单位方差
    else:
        mu = group.mean(dim=0)                      # (L,) 每个维度的组均值
        sd = group.std(dim=0, unbiased=False)       # (L,) 每个维度的组标准差

    # 按维度标准化
    if norm_adv_by_std_in_grpo:
        group_norm = (group - mu) / (sd + epsilon)  # (rollout_n, L)
    else:
        group_norm = group - mu                     # Dr. GRPO 变体

    # 求和得到一个标量 advantage
    group_sum = group_norm.sum(dim=-1)             # (rollout_n,)

    # 写回到每个样本位置
    for k, i in enumerate(inds):
        normed[i] = group_norm[k]   # shape: (L,)
        summed[i] = group_sum[k]    # scalar
```

### 核心思想图解

假设 rollout_n=4, L=3（3 个 GT + 0 个 format，简化示例）：

```
         dim_0   dim_1   dim_2
resp_0:  [0.8,    0.5,    0.9]        组内按维度标准化
resp_1:  [0.6,    0.7,    0.4]   →   每个维度独立 (x-μ)/σ  →  求和 →  标量 adv
resp_2:  [0.9,    0.3,    0.8]
resp_3:  [0.4,    0.8,    0.6]

μ:       [0.675,  0.575,  0.675]    ← 按 dim=0 计算
σ:       [0.192,  0.192,  0.192]

标准化后:
resp_0:  [ 0.65,  -0.39,   1.17]  →  sum =  1.43  (远高于组均值)
resp_1:  [-0.39,   0.65,  -1.43]  →  sum = -1.17  (低于组均值)
resp_2:  [ 1.17,  -1.43,   0.65]  →  sum =  0.39  (略高于组均值)
resp_3:  [-1.43,   1.17,  -0.39]  →  sum = -0.65  (略低于组均值)
```

### Step C: 广播到 token 维度（行 176）

```python
summed = summed.unsqueeze(-1) * response_mask   # (bs,) → (bs, response_length)
```

每个 response 得到一个标量 advantage 值，复制到所有有效 token 位置。

### Step D: 全局白化（回到 ray_trainer.py 行 269）

```python
advantages = masked_whiten(new_advantage, response_mask) * response_mask
```

在**组内标准化之后**，再做一次**全局** masked whiten（减均值除标准差），形成**双重归一化**：

1. **组内逐维标准化**：消除 prompt 难度差异 + 细粒度子任务信号
2. **全局 whiten**：进一步稳定训练，防止梯度爆炸

---

## 七、阶段 6：标准 PPO Policy Loss 消费

**文件**: `verl/trainer/ppo/core_algos.py` (行 422–489)

GDPO 产生的 advantage 形状与 GAE/GRPO **完全一致**（`(bs, response_length)`），因此**无需任何 GDPO 专用 loss 函数**：

```python
def compute_policy_loss(old_log_prob, log_prob, advantages, response_mask, ...):
    ratio = exp(log_prob - old_log_prob)              # π_new / π_old

    pg_losses1 = -advantages * ratio                  # 无裁剪
    pg_losses2 = -advantages * clip(ratio, 1-ε, 1+ε) # 裁剪版本
    clip_pg = max(pg_losses1, pg_losses2)             # 悲观估计

    # Dual-clip PPO（当 advantage < 0 时）
    pg_losses3 = -advantages * clip_ratio_c           # c = 3.0
    final_loss = min(clip_pg, pg_losses3)             # 仅在 adv < 0 时生效

    pg_loss = agg_loss(final_loss, response_mask)
```

---

## 八、完整数据流图

```
┌──────────────────────────────────────────────────────────┐
│ task_no_entry.py                                         │
│ return {"diff_score": [0.8, 0.5, 0.9, 1.0], ...}        │
│         ↑ ragged list, 长度 = GT数量 + 1(format)          │
└──────────────────────┬───────────────────────────────────┘
                       │
┌──────────────────────▼───────────────────────────────────┐
│ NaiveRewardManager (naive.py)                            │
│ reward_extra_info["diff_score"].append([0.8, 0.5, ...])  │
│ → batch_size 个不定长 list                               │
└──────────────────────┬───────────────────────────────────┘
                       │
┌──────────────────────▼───────────────────────────────────┐
│ compute_reward (reward.py:127-164)                       │
│ diff_score = reward_extra_infos_dict.get("diff_score")   │
│ return reward_tensor, {}, diff_score, seperate_score     │
│        (标量,用于GRPO)  (ragged, GDPO专用) (各维度,日志)  │
└──────────────────────┬───────────────────────────────────┘
                       │ 作为 diff_num_score 传入
┌──────────────────────▼───────────────────────────────────┐
│ compute_advantage (ray_trainer.py:254-271)               │
│ if adv_estimator == GDPO:                                │
│   adv, ret = compute_gdpo_outcome_advantage(             │
│       token_level_rewards=diff_num_score,  ← ragged list │
│       response_mask=...,                                 │
│       index=uid,                  ← 按 prompt 分组       │
│   )                                                      │
│   advantages = masked_whiten(adv, mask) * mask           │
└──────────────────────┬───────────────────────────────────┘
                       │ (bs, response_length) tensor
┌──────────────────────▼───────────────────────────────────┐
│ compute_gdpo_outcome_advantage (core_algos.py:112-177)   │
│ ① 按 uid 聚合同 prompt 的不同 rollout                    │
│ ② 组内 stack → (rollout_n, L)                            │
│ ③ 按维度标准化: (x - μ_dim) / σ_dim                      │
│ ④ 求和: sum(normed, dim=-1) → 标量                       │
│ ⑤ 广播: scalar * response_mask → (bs, response_length)   │
└──────────────────────┬───────────────────────────────────┘
                       │ (bs, response_length)
┌──────────────────────▼───────────────────────────────────┐
│ compute_policy_loss (core_algos.py:422-489)              │
│ 标准 PPO clipped surrogate — 无需 GDPO 专用代码          │
│ pg_loss = max(-A*ratio, -A*clip(ratio))                  │
└──────────────────────────────────────────────────────────┘
```

---

## 九、关键设计总结

| 维度 | 设计选择 |
|------|---------|
| **接入方式** | `algorithm.adv_estimator: gdpo` 配置项，通过 `AdvantageEstimator` 枚举路由 |
| **数据结构** | ragged list of lists（不固定 L），避免 padding 浪费 |
| **归一化策略** | 双重归一化：① 组内按维度标准化 → ② 求和 → ③ 全局 whiten |
| **Loss 复用** | advantage 最终 shape 与 GAE/GRPO 一致，完全复用 `compute_policy_loss` |
| **不需要 Critic** | 与 GRPO 一样，`use_critic = False` |
| **数据侵入性** | 仅 reward 函数需返回 `diff_score`，其余链路透明透传 |
| **已知局限** | multi-turn 场景下未使用 `loss_mask`，可能导致 group 统计不准确 |

### 与 GRPO 的本质区别

```
GRPO:  reward_scalar → group_norm([r1, r2, r3, r4]) → 标量 adv → 广播到 token
GDPO:  reward_vector → group_norm_per_dim([[v1], [v2], [v3], [v4]]) → sum → 标量 adv → 广播到 token
```

GDPO 通过**逐维度标准化**让模型感知到 "我在这个具体的子任务上比同组其他回答好还是差"，而不仅仅是 "整体好不好"。对于多 GT 的分类/接地任务，这提供了更细粒度的学习信号。

---

## 十、关键文件索引

| 文件 | 作用 |
|------|------|
| `verl/trainer/ppo/ray_trainer.py` (行 82–93, 254–271) | GDPO 枚举定义、`compute_advantage` 中 GDPO 分支 |
| `verl/trainer/ppo/core_algos.py` (行 112–177) | `compute_gdpo_outcome_advantage` 核心算法 |
| `verl/trainer/ppo/core_algos.py` (行 422–489) | `compute_policy_loss` 标准 PPO loss（GDPO 复用） |
| `verl/trainer/ppo/reward.py` (行 127–164) | `compute_reward` 提取 `diff_score` |
| `verl/workers/reward_manager/naive.py` | Reward Manager 透传 `diff_score` |
| `verl/utils/reward_score/task_no_entry.py` | 自定义 reward 函数，产出 `diff_score` list |
| `verl/utils/torch_functional.py` (行 146–152) | `masked_whiten` 全局白化 |
