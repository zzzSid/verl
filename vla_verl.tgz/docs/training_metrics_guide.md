# VERL 训练参数/指标详解

> 本文档详细解释 VERL PPO 训练过程中所有被记录和上报的指标（metrics），包括 Actor 策略网络指标、Critic 价值网络指标、性能指标、时序指标等。

---

## 目录

1. [Actor 策略网络指标](#1-actor-策略网络指标)
   - [1.1 PPO 核心指标](#11-ppo-核心指标)
   - [1.2 BAPO 特有指标](#12-bapo-特有指标)
   - [1.3 FlowRL 特有指标](#13-flowrl-特有指标)
   - [1.4 SPPO 特有指标](#14-sppo-特有指标)
2. [Critic 价值网络指标](#2-critic-价值网络指标)
   - [2.1 Critic 更新指标](#21-critic-更新指标)
   - [2.2 数据统计指标](#22-数据统计指标)
3. [KL 惩罚相关指标](#3-kl-惩罚相关指标)
4. [序列长度指标](#4-序列长度指标)
5. [性能指标](#5-性能指标)
6. [时序指标](#6-时序指标)
7. [批次均衡指标](#7-批次均衡指标)
8. [训练进度指标](#8-训练进度指标)
9. [验证指标](#9-验证指标)
10. [关键配置参数速查](#10-关键配置参数速查)
11. [指标记录流程](#11-指标记录流程)

---

## 1. Actor 策略网络指标

Actor 指标在 `update_actor` 阶段产生，记录策略网络（policy network）的训练状态。

### 1.1 PPO 核心指标

#### `actor/pg_loss`
- **含义**：Policy Gradient Loss（策略梯度损失），即 PPO 的代理目标函数（surrogate loss）值。
- **计算公式**：
  ```
  ratio = exp(log_prob - old_log_prob)                           # 重要性采样比率
  pg_losses1 = -advantages * ratio                                # 未裁剪损失
  pg_losses2 = -advantages * clip(ratio, 1-ε_low, 1+ε_high)     # 裁剪后损失
  pg_losses3 = -advantages * clip_ratio_c                         # dual-clip 下界
  pg_loss = agg_loss(final_losses, response_mask, loss_agg_mode)  # 按 mask 聚合
  ```
- **说明**：PPO 的核心损失。对于正 advantage，取 `max(pg_losses1, pg_losses2)` 防止 ratio 过大；对于负 advantage，取 `min(clip_pg_losses, pg_losses3)` 防止 ratio 过小。
- **代码位置**：`verl/trainer/ppo/core_algos.py` -> `compute_policy_loss()`
- **合理范围**：通常在 -0.1 到 1.0 之间，取决于 reward scale。如果 loss 持续为 0，可能 advantage 全为 0。

#### `actor/pg_clipfrac`
- **含义**：Policy Gradient Clip Fraction（策略梯度裁剪比例）—— 被 PPO 上界裁剪机制触发（即 `pg_losses2 > pg_losses1`）的 token 占比。
- **计算公式**：
  ```
  pg_clipfrac = masked_mean((pg_losses2 > pg_losses1).float(), response_mask)
  ```
- **说明**：衡量 PPO clipping 对 loss 的影响范围。clipfrac 越高，说明越多 token 的 ratio 超出了 `[1-ε_low, 1+ε_high]` 范围。
- **合理范围**：通常 0.01~0.20。过高（>0.3）说明策略更新步长过大，建议降低 learning rate 或增大 clip_ratio。

#### `actor/pg_clipfrac_lower`
- **含义**：Policy Gradient Lower Clip Fraction（策略梯度下界裁剪比例）—— 被 PPO dual-clip 下界（`clip_ratio_c`）触发的 token 占比，仅在 advantage < 0 时统计。
- **计算公式**：
  ```
  pg_clipfrac_lower = masked_mean(
      (clip_pg_losses1 > pg_losses3) * (advantages < 0).float(),
      response_mask
  )
  ```
- **说明**：dual-clip PPO 的额外安全机制，防止负 advantage 的 ratio 过度下降导致策略崩溃。此值高说明很多负 advantage token 的 ratio 降得太低。
- **合理范围**：通常接近 0。若持续 > 0.1 需关注。

#### `actor/ppo_kl`
- **含义**：Approximate KL Divergence（近似 KL 散度）—— 当前策略与旧采样策略之间的估计 KL 散度。
- **计算公式**：
  ```
  negative_approx_kl = log_prob - old_log_prob
  ppo_kl = masked_mean(-negative_approx_kl, response_mask)
  ```
- **说明**：这个值是基于 importance sampling ratio 的一种近似 KL 估计，并非真正的 KL 散度。用于监控策略更新幅度。
- **合理范围**：通常 0.001~0.05。过高的 KL 表明策略变化过大。

#### `actor/kl_loss`
- **含义**：KL Divergence Loss（KL 散度正则化损失）—— 当前策略与参考策略（reference policy）之间 KL 散度的加权值。
- **计算公式**：
  ```
  kld = kl_penalty(log_prob, ref_log_prob, kl_loss_type)
  kl_loss = agg_loss(kld * kl_loss_coef, response_mask, loss_agg_mode)
  ```
- **说明**：仅当 `use_kl_loss=True` 时启用。将 KL 惩罚直接加在 loss 中，防止策略偏离参考策略太远。
- **KL 类型**（`kl_loss_type`）：
  - `kl`：`log_prob - ref_log_prob`
  - `abs`：`|log_prob - ref_log_prob|`
  - `mse`：`0.5 * (log_prob - ref_log_prob)^2`
  - `low_var_kl`：`clamp(exp(kl) - kl - 1, min, max)`，其中 `kl = ref_log_prob - log_prob`
  - `full`：完整的 KL 散度估计

#### `actor/kl_coef`
- **含义**：KL Loss Coefficient（KL 损失系数）—— `kl_loss` 的缩放系数。
- **配置参数**：`actor_rollout_ref.actor.kl_loss_coef`，默认值 0.001。
- **说明**：此值越大，KL 正则化越强。

#### `actor/entropy_loss`
- **含义**：Entropy Loss（熵损失）—— 策略输出 token 分布的分类熵（Categorical Entropy）。
- **计算公式**：
  ```
  entropy = entropy_from_logits(logits)        # 每个 token 的分类熵
  entropy_loss = masked_mean(entropy, response_mask)
  ```
- **说明**：仅当 `entropy_coeff != 0` 时计算。熵正则化鼓励策略保持一定的探索性。在 loss 中为 `-entropy_coeff * entropy_loss`。
- **合理范围**：取决于 vocab_size，通常在 0.5~3.0 之间。熵过低 → 策略过于确定（可能过拟合）；熵过高 → 策略过于随机。

#### `actor/lr`
- **含义**：Actor Learning Rate（Actor 当前学习率）—— 从优化器的 LR Scheduler 获取的当前学习率。
- **说明**：反映学习率衰减/预热的状态。

#### `actor/grad_norm`
- **含义**：Actor Gradient Norm（Actor 梯度范数）—— 经过梯度裁剪（`grad_clip`）后的全局梯度 L2 范数。
- **说明**：用于监控梯度爆炸/消失。若持续等于 `grad_clip` 值，说明梯度经常被裁剪，可能需要调整学习率。

---

### 1.2 BAPO 特有指标

BAPO（Balanced Adaptive Policy Optimization）是 `policy_loss_type = "bapo"` 时的策略损失变体，动态调整 clip bound。

#### `actor/bapo_clip_low`
- **含义**：BAPO 算法最终确定的动态下界裁剪比例。
- **说明**：BAPO 通过迭代调整 `ε_low` 以维持目标正负 advantage 贡献比。

#### `actor/bapo_clip_high`
- **含义**：BAPO 算法最终确定的动态上界裁剪比例。
- **说明**：同上，BAPO 动态调整 `ε_high`。

#### `actor/bapo_pos_neg_ratio`
- **含义**：BAPO 调整后实际达到的正/负 advantage 贡献比。
- **合理范围**：与目标比率（默认 1.0，即 1:1）接近。

---

### 1.3 FlowRL 特有指标

FlowRL 使用轨迹平衡（Trajectory Balance）损失替代 PPO 损失。

#### `actor/logpf`
- **含义**：当前策略下响应 token 的 **对数前向概率**（log p_forward）的 masked mean。
- **说明**：表示当前模型对生成 token 的"信心"。

#### `actor/logp_ref`
- **含义**：参考策略（reference policy）下响应 token 的 **对数概率** 的 masked mean。

#### `actor/log_z`
- **含义**：**对数配分函数**（log partition function）的均值。由一个从 prompt 隐藏状态学习的小 MLP（`ProjZModule`）预测。
- **说明**：log_z 表示从当前状态出发可到达的所有轨迹的"流量"，是 FlowRL 的核心概念。

#### `actor/log_reward`
- **含义**：响应 token 上 reward（advantage）的 masked mean。

#### `actor/tb_loss`
- **含义**：Trajectory Balance Loss（轨迹平衡损失）—— FlowRL 的主损失函数。
- **计算公式**：
  ```
  delta = log_z + avg_logpf - 15 * seq_log_reward - avg_logp_ref
  tb_loss = mean(importance_weight * delta^2)
  ```
- **说明**：要求 `log_z + forward_logp ≈ reward * scale + ref_logp`，满足轨迹平衡条件。

#### `actor/pos_high_ratio_frac`
- **含义**：reward > 0 且 importance ratio > `1 + clip_ratio` 的 token 占比。

#### `actor/pos_low_ratio_frac`
- **含义**：reward > 0 且 importance ratio < `1 - clip_ratio` 的 token 占比。

#### `actor/neg_high_ratio_frac`
- **含义**：reward < 0 且 importance ratio > `1 + clip_ratio` 的 token 占比。

#### `actor/neg_low_ratio_frac`
- **含义**：reward < 0 且 importance ratio < `1 - clip_ratio` 的 token 占比。

---

### 1.4 SPPO 特有指标

SPPO（Self-Play Preference Optimization）的指标。

| 指标 | 含义 |
|------|------|
| `actor/loss` | SPPO 总损失 |
| `actor/log_ratio_mean` | 对数比率 `log(p_θ / p_ref)` 的均值 |
| `actor/preference_mean` | 偏好分数的均值 |

---

## 2. Critic 价值网络指标

Critic 指标在 `update_critic` 阶段产生，记录价值网络（value network）的训练状态。

### 2.1 Critic 更新指标

#### `critic/vf_loss`
- **含义**：Value Function Loss（价值函数损失）—— 带裁剪的 MSE 损失。
- **计算公式**：
  ```
  vpred_clipped = clip(vpreds, values - cliprange_value, values + cliprange_value)
  vf_losses1 = (vpreds - returns)^2
  vf_losses2 = (vpred_clipped - returns)^2
  vf_loss = 0.5 * masked_mean(max(vf_losses1, vf_losses2), response_mask)
  ```
- **说明**：与 PPO policy loss 类似，用裁剪限制价值函数的单次更新幅度。
- **合理范围**：取决于 return 的 scale。标准化 advantage 后通常在 0.01~1.0。

#### `critic/vf_clipfrac`
- **含义**：Value Function Clip Fraction（价值函数裁剪比例）—— 被裁剪机制触发的 token 占比。
- **计算公式**：
  ```
  vf_clipfrac = masked_mean((vf_losses2 > vf_losses1).float(), response_mask)
  ```
- **说明**：类似 `pg_clipfrac`，但针对价值函数。过高说明 value 更新步长过大。

#### `critic/vpred_mean`
- **含义**：Value Prediction Mean（价值预测均值）—— Critic 对每个有效 token 预测的期望回报的均值。
- **计算公式**：
  ```
  vpred_mean = masked_mean(vpreds, response_mask)
  ```
- **说明**：用于监控 Critic 的预测水平。此值应与 returns 的均值接近。

#### `critic/lr`
- **含义**：Critic Learning Rate（Critic 当前学习率）。

#### `critic/grad_norm`
- **含义**：Critic Gradient Norm（Critic 梯度范数）。

---

### 2.2 数据统计指标

这些指标在 advantage 计算后，从 batch 数据中统计得出，反映当前 batch 的奖励、优势、回报等分布。

#### 分数指标（来自 Reward Model）

| 指标 | 含义 | 条件 |
|------|------|------|
| `critic/score/mean` | 原始分数（`token_level_scores.sum(-1)`）的均值 | 总是存在 |
| `critic/score/max` | 原始分数的最大值 | 总是存在 |
| `critic/score/min` | 原始分数的最小值 | 总是存在 |
| `critic/content_score/mean` | 内容评分均值 | 当 batch 中存在 `content_score` |
| `critic/format_score/mean` | 格式评分均值 | 当 batch 中存在 `format_score` |
| `critic/length_factor_score/mean` | 长度惩罚因子的均值 | 当 batch 中存在 `length_factor` |

#### 奖励指标

| 指标 | 含义 |
|------|------|
| `critic/rewards/mean` | 奖励（`token_level_rewards.sum(-1)`，可能经 KL 惩罚后）的均值 |
| `critic/rewards/max` | 奖励的最大值 |
| `critic/rewards/min` | 奖励的最小值 |

#### 优势（Advantage）指标

| 指标 | 含义 |
|------|------|
| `critic/advantages/mean` | 有效 token 上 advantage 的均值 |
| `critic/advantages/max` | 有效 token 上 advantage 的最大值 |
| `critic/advantages/min` | 有效 token 上 advantage 的最小值 |

**说明**：Advantage = Returns - Values（当 use_critic=True 时使用 GAE），衡量当前动作比平均期望好多少。理想情况下，GAE advantage 的均值应接近 0，标准差接近 1（经过标准化后）。

#### 回报（Returns）指标

| 指标 | 含义 |
|------|------|
| `critic/returns/mean` | 有效 token 上 return 的均值 |
| `critic/returns/max` | 有效 token 上 return 的最大值 |
| `critic/returns/min` | 有效 token 上 return 的最小值 |

**说明**：Returns = 折扣累积奖励 + 价值 bootstrap，是 Critic 的回归目标。

#### 价值（Values）指标

| 指标 | 含义 | 条件 |
|------|------|------|
| `critic/values/mean` | Critic 预测价值的均值 | `use_critic=True` |
| `critic/values/max` | Critic 预测价值的最大值 | `use_critic=True` |
| `critic/values/min` | Critic 预测价值的最小值 | `use_critic=True` |

#### `critic/vf_explained_var`
- **含义**：Value Function Explained Variance（价值函数解释方差）—— Critic 预测对 return 方差的解释程度。
- **计算公式**：
  ```
  vf_explained_var = 1.0 - Var(returns - values) / (Var(returns) + 1e-5)
  ```
- **合理范围**：
  - **1.0** = 完美预测
  - **0.0** = 预测效果等同于预测常数均值
  - **< 0.0** = 预测比常数均值还差，模型可能有问题
- **说明**：这是衡量 Critic 质量最直观的指标。通常在训练初期为负值，随后上升到 0.3~0.8。

#### 自定义评分指标

| 指标 | 含义 | 条件 |
|------|------|------|
| `critic/category_score/mean` | 视角类别评分的均值 | 仅当 reward 输出包含此维度 |
| `critic/grounding_score/mean` | 视角定位评分的均值 | 仅当 reward 输出包含此维度 |

---

## 3. KL 惩罚相关指标

These are logged during reward computation when `use_kl_in_reward=True`.

#### `actor/reward_kl_penalty`
- **含义**：Reward KL Penalty（奖励中的 KL 惩罚值）—— 当前在奖励中扣除的平均 KL 散度。
- **计算公式**：
  ```
  kld = kl_penalty(old_log_probs, ref_log_prob, kl_penalty_type)
  token_level_rewards = token_level_scores - beta * kld
  reward_kl_penalty = mean(kld)  # 跨所有序列
  ```
- **说明**：KL 控制奖励（KL-Controlled Reward）机制的核心。将 KL 散度作为负奖励，鼓励策略不偏离参考策略太远。
- **合理范围**：通常在 0.001~0.1 之间，取决于 target_kl 设置。

#### `actor/reward_kl_penalty_coeff`
- **含义**：Reward KL Penalty Coefficient（KL 惩罚系数 β）—— 当前使用的 KL 惩罚权重。
- **说明**：当使用 `AdaptiveKLController` 时，β 会自动调节以维持 `current_kl` 接近 `target_kl`：
  - `current_kl > target_kl` → β 增大（惩罚加重，抑制偏离）
  - `current_kl < target_kl` → β 减小（惩罚减轻，允许更多探索）

---

## 4. 序列长度指标

#### 响应长度

| 指标 | 含义 |
|------|------|
| `response_length/mean` | 所有有效响应的平均 token 数 |
| `response_length/max` | 最长响应的 token 数 |
| `response_length/min` | 最短响应的 token 数 |
| `response_length/clip_ratio` | **达到最大生成长度的响应占比**——反映有多少生成长度被截断 |

**说明**：`response_length/clip_ratio` 是一个重要的监控指标。如果此值很高（如 > 0.3），说明模型经常生到最大长度，可能需要增大 `response_length` 或检查模型是否陷入重复生成。

#### 提示长度

| 指标 | 含义 |
|------|------|
| `prompt_length/mean` | 所有 prompt 的平均 token 数 |
| `prompt_length/max` | 最长 prompt 的 token 数 |
| `prompt_length/min` | 最短 prompt 的 token 数 |
| `prompt_length/clip_ratio` | **达到最大 prompt 长度的占比**——反映有多少 prompt 被截断 |

---

## 5. 性能指标

#### `perf/total_num_tokens`
- **含义**：Total Number of Tokens（总 token 数）—— 当前 step 处理的总 token 数（prompt + response），跨所有 worker 求和。
- **公式**：`sum(batch.meta_info["global_token_num"])`

#### `perf/time_per_step`
- **含义**：Time Per Step（每步耗时）—— 完成一个完整训练 step 的墙钟时间（秒）。
- **公式**：`timing_raw["step"]`

#### `perf/throughput`
- **含义**：Throughput（吞吐量）—— 每 GPU 每秒处理的 token 数。
- **公式**：`total_num_tokens / (time_per_step * n_gpus)`
- **合理范围**：取决于模型大小和硬件。例如，0.6B 模型在 A100 上约为 5000~20000 tokens/s/GPU。

#### `perf/mfu/actor`
- **含义**：Model FLOPs Utilization — Actor（Actor 模型算力利用率）。Actor 实际 FLOPs 与 GPU 理论峰值 FLOPs 的比值。
- **公式**：`estimated_flops * ppo_epochs / promised_flops / world_size`
- **说明**：MFU 通常在 0.3~0.6 之间（受通信、内存带宽等限制）。0.5 以上算是较好的利用率。

#### `perf/mfu/critic`
- **含义**：同 `perf/mfu/actor`，但针对 Critic（价值网络）。

#### `perf/max_memory_allocated_gb`
- **含义**：Peak Allocated GPU Memory（峰值已分配 GPU 显存，GB）。
- **公式**：`torch.cuda.max_memory_allocated() / 1024^3`
- **说明**：包括张量、梯度、优化器状态等 PyTorch 实际分配的内存。若接近 GPU 总显存，可能需要减小 batch size。

#### `perf/max_memory_reserved_gb`
- **含义**：Peak Reserved GPU Memory（峰值已预留 GPU 显存，GB）。
- **公式**：`torch.cuda.max_memory_reserved() / 1024^3`
- **说明**：PyTorch 的 CUDA caching allocator 预留的内存（大于 allocated）。反映了 PyTorch 向 CUDA 申请的显存总量。

#### `perf/cpu_memory_used_gb`
- **含义**：CPU Memory Used（CPU 已用内存，GB）。
- **公式**：`psutil.virtual_memory().used / 1024^3`

---

## 6. 时序指标

每个训练阶段的耗时监控，用于性能分析。

#### 秒级时序（`timing_s/{stage}`）

| 指标 | 对应阶段 |
|------|----------|
| `timing_s/step` | **完整 step** 总耗时 |
| `timing_s/gen` | **生成（Generation）**：模型自回归采样生成响应 |
| `timing_s/gen_max` | **基准生成**（仅 ReMax 算法使用） |
| `timing_s/reward` | **奖励计算**：调用 reward function 对生成结果打分 |
| `timing_s/old_log_prob` | **旧策略对数概率**：用采样时的策略重算 log_prob |
| `timing_s/ref` | **参考策略对数概率**：用参考模型计算 log_prob |
| `timing_s/values` | **价值估计**：用 Critic 计算每个 token 的 value |
| `timing_s/adv` | **优势计算**：计算 GAE advantage 和 returns |
| `timing_s/update_critic` | **Critic 更新**：Critic 网络的多轮 PPO epoch 训练 |
| `timing_s/update_actor` | **Actor 更新**：Actor 网络的多轮 PPO epoch 训练 |
| `timing_s/testing` | **验证**：在验证集上评估模型 |
| `timing_s/save_checkpoint` | **保存检查点**：将模型权重写入磁盘 |
| `timing_s/dump_rollout_generations` | **导出生成结果**：将 rollout 结果写入文件（可选） |

#### 毫秒/Token 时序（`timing_per_token_ms/{stage}`）

| 指标 | 归一化方式 |
|------|------------|
| `timing_per_token_ms/gen` | 仅除以 **response token 数** |
| `timing_per_token_ms/ref` | 除以 **prompt + response token 数** |
| `timing_per_token_ms/values` | 除以 **prompt + response token 数** |
| `timing_per_token_ms/adv` | 除以 **prompt + response token 数** |
| `timing_per_token_ms/update_critic` | 除以 **prompt + response token 数** |
| `timing_per_token_ms/update_actor` | 除以 **prompt + response token 数** |

---

## 7. 批次均衡指标

仅当 `config.trainer.balance_batch=True` 时记录，用于监控数据在 GPU 间的分配均匀性。

| 指标 | 含义 |
|------|------|
| `global_seqlen/min` | 均衡前各 DP rank 上的最小 seqlen 总和 |
| `global_seqlen/max` | 均衡前各 DP rank 上的最大 seqlen 总和 |
| `global_seqlen/minmax_diff` | 均衡前最大与最小的差值（越大越不均） |
| `global_seqlen/balanced_min` | Karmarkar-Karp 算法均衡后的最小 seqlen 总和 |
| `global_seqlen/balanced_max` | Karmarkar-Karp 算法均衡后的最大 seqlen 总和 |

**说明**：由于 RL 训练中每条序列的长度不同，各 GPU 的计算负载可能不均。VERL 使用 Karmarkar-Karp 贪心算法将序列分配到各 GPU 以使总 seqlen 尽量均匀，从而减少 GPU 空等时间。

---

## 8. 训练进度指标

| 指标 | 含义 |
|------|------|
| `training/global_step` | 全局训练步数 |
| `training/epoch` | 当前训练的 epoch 数 |
| `train/num_gen_batches` | 当前训练 batch 由多少个生成批次构成（仅 dNPO 使用） |

---

## 9. 验证指标

验证指标的命名模式为：
```
{val-core|val-aux}/{data_source}/{variable_name}/{metric_name}
```

其中：
- `val-core`：核心验证指标（使用 `acc` 或 `reward` + `mean@N` / `best@N` / `maj@N` 中 N 最大者）
- `val-aux`：辅助验证指标（其他所有）

#### 指标类型说明

| metric_name | 含义 |
|-------------|------|
| `mean@{N}` | 每个 prompt 采样 N 次的平均分数 |
| `std@{N}` | 每个 prompt 采样 N 次的标准差 |
| `best@{N}/mean` | Best-of-N 的 bootstrap 均值 |
| `best@{N}/std` | Best-of-N 的 bootstrap 标准差 |
| `worst@{N}/mean` | Worst-of-N 的 bootstrap 均值 |
| `worst@{N}/std` | Worst-of-N 的 bootstrap 标准差 |
| `maj@{N}/mean` | 多数投票（Majority Voting）结果的均值（需有 `pred` 字段） |
| `maj@{N}/std` | 多数投票结果的标准差 |

---

## 10. 关键配置参数速查

以下参数控制上述指标对应的训练行为（以 `actor_rollout_ref.actor` 下的配置为例）：

| 配置参数 | 默认值 | 控制指标 | 说明 |
|----------|--------|----------|------|
| `clip_ratio` | 0.2 | `pg_clipfrac` | PPO 裁剪范围 ε，ratio 被钳制在 `[1-ε, 1+ε]` |
| `clip_ratio_low` | 0.2 | `pg_clipfrac` | 非对称裁剪的下界 |
| `clip_ratio_high` | 0.2 | `pg_clipfrac` | 非对称裁剪的上界 |
| `clip_ratio_c` | 3.0 | `pg_clipfrac_lower` | Dual-clip PPO 的下界常数，防止负 advantage 的 ratio 降得过低 |
| `loss_agg_mode` | `"token-mean"` | `pg_loss` | Loss 聚合方式：`token-mean`（per-token 平均）/ `seq-mean-token-sum` / `seq-mean-token-mean` / `seq-mean-token-sum-norm` |
| `entropy_coeff` | 0.0 | `entropy_loss` | 熵正则化系数，0 = 禁用 |
| `use_kl_loss` | False | `kl_loss`, `kl_coef` | 是否显式添加 KL loss 项 |
| `kl_loss_coef` | 0.001 | `kl_loss` | KL loss 的缩放系数 |
| `kl_loss_type` | `"low_var_kl"` | `kl_loss` | KL 计算方式 |
| `use_kl_in_reward` | False | `reward_kl_penalty` | 是否在 reward 中扣除 KL 惩罚 |
| `kl_penalty` | `"kl"` | `reward_kl_penalty` | 奖励中 KL 惩罚的计算方式 |
| `grad_clip` | 1.0 | `grad_norm` | 梯度裁剪的最大范数 |
| `ppo_epochs` | 1 | 多个 | 每个 batch 的 PPO 更新轮数 |
| `ppo_mini_batch_size` | 256 | 多个 | PPO 小批次大小 |
| `cliprange_value` | 0.2 | `vf_clipfrac` | 价值函数的裁剪范围 |

---

## 11. 指标记录流程

### 11.1 数据流

```
Rollout → Reward → Advantage → Critic Update → Actor Update → Logging
   │         │          │            │               │
   │         │          │            │               └─→ actor/* 指标
   │         │          │            └─→ critic/vf_* 指标
   │         │          └─→ critic/score, critic/rewards, critic/advantages, critic/returns
   │         └─→ actor/reward_kl_penalty (if use_kl_in_reward)
   └─→ response_length/*, prompt_length/*
```

### 11.2 聚合方式

在 `verl/utils/metric/utils.py` 的 `reduce_metrics()` 中定义：

- Key 包含 `"max"` → 对多 worker 的结果取 `np.max`
- Key 包含 `"min"` → 对多 worker 的结果取 `np.min`
- 其他 → 对多 worker 的结果取 `np.mean`

### 11.3 上报后端

通过 `verl/utils/tracking.py` 的 `Tracking` 类支持以下后端：
- **Wandb**（`wandb`）
- **MLflow**（`mlflow`）
- **SwanLab**（`swanlab`）
- **TensorBoard**（`tensorboard`）
- **ClearML**（`clearml`）
- **VEMLP Wandb**（`vemlp_wandb`）
- **Console**（`console`，仅打印到控制台）

---

> **参考文件**：
> - `verl/trainer/ppo/core_algos.py` — PPO/VF loss 核心算法
> - `verl/trainer/ppo/metric_utils.py` — 数据/时序/吞吐量指标计算
> - `verl/trainer/ppo/ray_trainer.py` — 主训练循环和指标收集
> - `verl/workers/actor/dp_actor.py` — Actor 指标记录
> - `verl/workers/critic/dp_critic.py` — Critic 指标记录
> - `verl/utils/tracking.py` — 指标上报后端
