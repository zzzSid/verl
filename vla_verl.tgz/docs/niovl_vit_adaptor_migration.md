# NIOVL ViT + Adaptor 适配迁移文档

> 迁移日期：2026-07-06
> 源：`/home/beijin.zhou/mlm-evaluator-test2/mlm/model/task/niovl/`
> 目标：`/home/beijin.zhou/mlm-verl/verl/mlm/niovl/`

## 概述

将 evaluator 项目中对 NIOVL 模型的 **ViT 中间层压缩（vit_compress）** 和 **Adaptor 适配（compress_in_vit）** 迁移到 verl 项目中，确保模型训练代码和 vLLM 推理代码都能正确支持这些特性。

---

## 修改文件清单

### verl 项目（训练代码 + 配置）

| # | 文件 | 改动类型 | 说明 |
|---|------|---------|------|
| 1 | `verl/mlm/niovl/siglip/configuration_siglip.py` | Edit | `SiglipVisionConfig` 新增 `vit_compress_start_layer`、`vit_compress_ratio`、`vit_compress_ps_version`、`vit_ldp_layer` 配置字段 |
| 2 | `verl/mlm/niovl/siglip/modeling_siglip.py` | Copy+Edit | 从 evaluator 复制，新增 `vision_space_to_depth_shuffle()`、`SiglipEncoder` 压缩/LDP 层和方法 |
| 3 | `verl/mlm/niovl/adaptor/adaptor.py` | Copy | 从 evaluator 复制，`NIOAdaptor` 新增 `compress_in_vit` 模式 |
| 4 | `verl/mlm/niovl/modeling_niovl.py` | Copy+Edit | 从 evaluator 复制，新增 `compress_in_vit`/`ldp_in_vit` 连线、`_supports_flash_attn_2` 等属性、`batch_chat` 方法、修复 import 路径 |

### vLLM venv（推理代码）

| # | 文件 | 改动类型 | 说明 |
|---|------|---------|------|
| 5 | `.venv2/lib/python3.10/site-packages/vllm/model_executor/models/siglip.py` | Edit | 新增 `vision_space_to_depth_shuffle()`、`SiglipEncoder`/`SiglipVisionTransformer`/`SiglipVisionModel` 支持 vit_compress/lpd |
| 6 | `.venv2/lib/python3.10/site-packages/vllm/model_executor/models/internvl.py` | Edit | `_init_vision_model` 传递 vit_compress、`_init_mlp1` 支持 `compress_in_vit`、`extract_feature` 支持条件分支、`num_image_token` 支持 `ldp_in_vit` |

### 推理脚本

| # | 文件 | 改动类型 | 说明 |
|---|------|---------|------|
| 7 | `tools/tools_bj/niovl_vllm_inference.py` | Edit | `limit_mm_per_prompt` 移到 init 后、`_sync_real_weights` 添加 lm_head 诊断/修复、添加 prompt/response 完整输出 |

### 备份

| # | 文件 | 说明 |
|---|------|------|
| 8 | `tools/tools_bj_backup/siglip.py.bak` | vLLM 原始 `siglip.py` |
| 9 | `tools/tools_bj_backup/internvl.py.bak` | vLLM 原始 `internvl.py` |

核心适配包括：
1. **ViT 中间层 token 压缩**：在 ViT encoder 第 k 层做 space-to-depth，减少后续层的 token 数量
2. **ViT 内部 LDP**：可选将 LDP 下采样移到 ViT 内部
3. **Adaptor compress_in_vit 模式**：当压缩在 ViT 内部完成时，adaptor 跳过 pixel_shuffle

---

## 配置文件说明

新模型（wanping.ouyang）的关键配置：

```json
{
  "use_LDP": true,
  "downsample_ratio": 0.5,
  "force_image_size": 512,
  "vision_config": {
    "hidden_size": 768,
    "image_size": 512,
    "patch_size": 16,
    "num_hidden_layers": 12,
    "vit_compress_start_layer": 8,
    "vit_compress_ratio": 0.5,
    "vit_compress_ps_version": "v2",
    "vit_ldp_layer": -1
  },
  "llm_config": {
    "hidden_size": 896,
    "tie_word_embeddings": true
  }
}
```

### Token 数量计算

- 输入：512×512 图像，patch_size=16 → 32×32 = 1024 patches
- ViT 内部压缩（layer 8，ratio=0.5）：1024 → 256 tokens
- Adaptor LDP（AdaptiveAvgPool2d((8,8))）：256 → 64 tokens
- **每个 tile 最终输出 64 个 visual tokens**
- 35 tiles × 64 = 2240 visual tokens 总计

---

## 一、verl 训练代码修改（4 个文件）

### 1.1 `verl/mlm/niovl/siglip/configuration_siglip.py`

**改动**：`SiglipVisionConfig` 新增 4 个配置字段：

```python
vit_compress_start_layer: int = -1,   # ViT 中间层压缩起始层，-1 禁用
vit_compress_ratio: float = 0.5,      # 压缩比例（space-to-depth）
vit_compress_ps_version: str = "v2",  # pixel_shuffle 版本
vit_ldp_layer: int = -1,              # ViT 内部 LDP 层，-1 禁用
```

默认值 -1 表示关闭，向后兼容旧模型。

### 1.2 `verl/mlm/niovl/siglip/modeling_siglip.py`

**改动 1**：新增 `vision_space_to_depth_shuffle()` 函数，实现 space-to-depth 的空间重排。

**改动 2**：`SiglipEncoder` 新增：
- `vit_compress_norm` / `vit_compress_fusion` — 压缩层（LayerNorm + Linear）
- `vit_ldp_dwn` / `vit_ldp_peg` — ViT 内部 LDP 层
- `_compress_sequence()` — 在指定层做 token 压缩
- `_ldp_sequence()` — 在指定层做 LDP 下采样
- `forward()` 改为 `for layer_idx, encoder_layer in enumerate(...)`，在 layer_idx 匹配时调用压缩/LDP

**改动 3**：`SiglipAttention` 中 `_attn_implementation` 访问添加 `getattr(..., "eager")` 回退。

### 1.3 `verl/mlm/niovl/adaptor/adaptor.py`

**改动**：`NIOAdaptor` 新增 `compress_in_vit` 参数：

```python
def __init__(self, ..., compress_in_vit=False):
    if compress_in_vit:
        # ViT 内部已完成压缩 → mlp1 输入维度 = vit_hidden_size
        self.mlp1 = nn.Sequential(
            nn.LayerNorm(vit_hidden_size),
            nn.Linear(vit_hidden_size, llm_hidden_size),
            ...
        )
    else:
        # 标准模式 → pixel_shuffle 将 4 个 token 合并 → 输入维度 ×4
        self.mlp1 = nn.Sequential(
            nn.LayerNorm(vit_hidden_size * int(1/downsample_ratio)**2),
            ...
        )
```

`forward()` 中：`compress_in_vit=True` 时跳过 `pixel_shuffle`。

### 1.4 `verl/mlm/niovl/modeling_niovl.py`

**改动**：
- 添加 `_supports_flash_attn_2 = True` 等 vLLM/HF 兼容属性
- `__init__` 中检测 `compress_in_vit` 和 `ldp_in_vit`，传递给 `NIOAdaptor`
- `use_LDP` 逻辑调整为 `config.use_LDP and (not ldp_in_vit)`
- `extract_feature()` 添加 GPU 端 normalize（`normalize_on_gpu`）
- 修复 `image_flags is not None` 安全守卫
- 修复 `batch_chat()` 中的 import 路径为 `from ..conversation`

---

## 二、vLLM 推理代码修改（2 个文件）

### 2.1 `.venv2/.../vllm/model_executor/models/siglip.py`

与 verl 训练代码对应的 vLLM 侧改动：

- 新增 `vision_space_to_depth_shuffle()` 函数
- `SiglipEncoder` 新增 `vit_compress_*` 和 `vit_ldp_*` 参数和层
- `SiglipEncoder.forward` 支持 layer_idx 级别的压缩/LDP
- `SiglipVisionTransformer` / `SiglipVisionModel` 透传 vit_compress 配置

### 2.2 `.venv2/.../vllm/model_executor/models/internvl.py`

**改动 1**：`_init_vision_model()` — 读取 vit_compress 配置并传递给 `SiglipVisionModel`

**改动 2**：`_init_mlp1()` — 支持 `compress_in_vit` 模式：

```python
compress_in_vit = int(getattr(config.vision_config, "vit_compress_start_layer", -1)) >= 0
if compress_in_vit:
    return nn.Sequential(
        nn.LayerNorm(vit_hidden_size),           # 768，非 768×4
        nn.Linear(vit_hidden_size, llm_hidden_size),
        ...
    )
```

**改动 3**：`extract_feature()` — NIOVL 路径支持 compress_in_vit / ldp_in_vit 条件分支：
- `compress_in_vit=True`：跳过 pixel_shuffle
- `ldp_in_vit=True`：跳过 adaptor 侧 LDP

**改动 4**：`num_image_token` 计算支持 `ldp_in_vit` 检查

---

## 三、推理脚本修改

### 3.1 `tools/tools_bj/niovl_vllm_inference.py`

**改动 1**：`limit_mm_per_prompt` 移到 LLM init 之后设置，避免 dummy run 处理大量图片导致 CUBLAS 错误：

```python
llm = LLM(..., load_format="dummy", seed=0)
# init 后再设 limit，避免 dummy run 跑 35 张图触发 CUBLAS 错误
llm.llm_engine.vllm_config.model_config.multimodal_config.limit_per_prompt = {"image": 35}
```

**改动 2**：`_sync_real_weights()` 添加 lm_head 诊断和修复（见下文）。

**改动 3**：添加完整的 prompt/response 输出和权重加载诊断。

---

## 四、遇到的问题和解决方案

### 4.1 KeyError: `vision_model.encoder.vit_compress_norm.weight`

**原因**：新模型 config 有 `vit_compress_start_layer=8`，verl 代码创建了压缩层，但 vLLM 自带的 siglip.py 没有这些层。

**解决**：在 vLLM 的 siglip.py 中添加对应的压缩/LDP 层。

### 4.2 CUBLAS_STATUS_INTERNAL_ERROR

**原因**：`limit_mm_per_prompt={"image": 35}` 导致 vLLM 在 dummy run（profile 阶段）用 35 张随机图跑 ViT，含 `vit_compress` 随机权重产生异常值。

**解决**：把 `limit_mm_per_prompt` 移到 LLM init 之后设置，profile 阶段使用默认 limit=1。

### 4.3 `tie_word_embeddings=True` 但 lm_head ≠ embed_tokens

**发现**：

| 权重 | L2 Norm |
|------|---------|
| `language_model.lm_head.weight` | 142.98 |
| `language_model.model.embed_tokens.weight` | 110.01 |

- config 标记 `tie_word_embeddings: True`
- 但实际训练时 embed_tokens 和 lm_head 是**独立的、不同的权重**
- vLLM 读到 `tie_word_embeddings=True` 后，复用 `embed_tokens` 作为 `lm_head`，**完全忽略了独立训练的 `lm_head.weight`**
- 导致输出 token ID 偏差，生成格式错误（如 `[UNUSED_TOKEN_34]` 代替 `<action>`）

**状态**：已添加诊断和修复代码，将 lm_head 强制加载到 vLLM 中。但因为 vLLM 的 lm_head 与 embed_tokens 是同一对象，需要先解绑再写入。

### 4.4 --skip-dataset 模式 token 数异常（19800 tokens）

**原因**：`--skip-dataset` 模式把原始图片（非 512×512 tile）直接给 vLLM，vLLM 按实际分辨率动态切 tile，数量远超 RLHFDataset 预处理的 35 个。

**解决**：使用标准模式（RLHFDataset 预处理），prompt 376 text tokens + 35 tile × 64 = 2240 image tokens，符合预期。

---

## 五、备份文件位置

```
tools/tools_bj_backup/
├── siglip.py.bak    — vLLM 原始 siglip.py
└── internvl.py.bak  — vLLM 原始 internvl.py
```

---

## 六、当前状态

- [x] verl 训练代码迁移完成（4 文件）
- [x] vLLM 推理代码迁移完成（2 文件）
- [x] vLLM 推理流程打通（LLM init + weight sync + forward pass）
- [x] 推理脚本适配（limit_mm_per_prompt + 诊断输出）
- [ ] **lm_head 解绑问题待修复**（推理输出格式仍不对）

---

## 七、运行命令

```bash
# 标准模式推理
bash tools/tools_bj/niovl_vllm_inference.sh

# 或手动运行
python3 tools/tools_bj/niovl_vllm_inference.py \
    --model-path /path/to/model \
    --data-path /path/to/data.parquet \
    --num-samples 3 \
    --max-response-length 128 \
    --max-prompt-length 8192 \
    --gpu-memory-utilization 0.3 \
    --temperature 0
```
