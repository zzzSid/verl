# NIOVL 模型迁移文档（add niovl adapt）

> 迁移日期：2026-06-10
> 源：`/home/beijin.zhou/mlm-evaluator-test2/mlm/model/task/niovl/`
> 目标：`/home/beijin.zhou/mlm-verl/verl/mlm/niovl/`
> 提交：`98deba28 add niovl adapt`

## 概述

将 evaluator 项目中的 NIOVL 模型代码（Vision Transformer + Adaptor + Language Model 的完整 multimodal 架构）迁移到 verl 项目中，复用 verl 已有的 InternVL 训练基础设施（FSDP worker、tokenizer），让 NIOVL 模型能够 以 InternVL 的方式 在 verl 框架中完成 RL 训练。

核心思路：NIOVL 复用 InternVL 的 vLLM 推理管线（`InternVLChatModel`）+ 替换 internvl 的模型注册检测逻辑为 internvl|niovl 双检测。

---

## 修改文件清单

### 一、verl 新增文件（从 evaluator 复制+适配）

| # | 文件 | 改动类型 | 说明 |
|---|------|---------|------|
| 1 | `verl/mlm/niovl/__init__.py` | New | 导出 `SiglipImageProcessor`, `SiglipVisionConfig`, `SiglipVisionModel`, `NIOVLConfig`, `NIOVLModel` |
| 2 | `verl/mlm/niovl/configuration_niovl.py` | Copy+Edit | 新增 vLLM 兼容属性（text_config, hidden_size 等 proxy properties） |
| 3 | `verl/mlm/niovl/modeling_niovl.py` | Copy+Edit | 新增 vLLM 兼容属性（`_supports_flash_attn_2` 等）、移除 train 专有代码（LabelSmoother, sequence packing 校验）、简化为仅包含推理所需逻辑 |
| 4 | `verl/mlm/niovl/adaptor/adaptor.py` | Copy+Edit | 移除 `compress_in_vit` 模式（初次迁移暂不包含 ViT 内压缩） |
| 5 | `verl/mlm/niovl/siglip/configuration_siglip.py` | Copy+Edit | 移除 `vit_compress_*`/`vit_ldp_layer` 字段（初次迁移不包含） |
| 6 | `verl/mlm/niovl/siglip/modeling_siglip.py` | Copy+Edit | 移除 `vision_space_to_depth_shuffle()`、ViT 内压缩/LDP 层（初次迁移不包含） |
| 7 | `verl/mlm/niovl/qwen2/modeling_qwen2.py` | Copy+Edit | 移除 `Qwen2FlashAttention2`（sequence packing 支持）、`cu_seq_lens` 参数透传 |
| 8 | `verl/mlm/niovl/install.sh` | New | 完整环境安装脚本（含 vLLM internvl.py 自动补丁） |

### 二、verl 已有文件修改

| # | 文件 | 改动类型 | 说明 |
|---|------|---------|------|
| 9 | `verl/utils/tokenizer.py` | Edit | 注册 NIOVL model type（与 InternVL 共用 vLLM 推理管线）、扩展 `internvl` 检测为 `internvl\|niovl` |
| 10 | `verl/workers/fsdp_workers.py` | Edit | 扩展 internvl 检测为 `internvl\|niovl`、添加 NIOVL vision_model 冻结/gradient_checkpointing 适配 |

---

## 二、修改细节

### 1. 关键设计决策：NIOVL 复用 InternVL 的 vLLM 推理管线

NIOVL 模型结构与 InternVL 高度相似：

```
InternVL:  InternVisionModel → pixel_shuffle → mlp1 → Qwen2ForCausalLM
NIOVL:     SiglipVisionModel  → pixel_shuffle → mlp1 → Qwen2ForCausalLM  (+ optional LDP)

区别仅在于：
1. Vision encoder 从 `InternVisionModel` 换成了 `SiglipVisionModel`（无 CLS token）
2. Adaptor 端多了可选的 LDP（AdaptiveAvgPool2d + depth-wise conv）下采样
3. Config 结构不同（vision/llm 分两个 sub-config）

因为架构高度相似，vLLM 可以直接用已有的 `InternVLChatModel` 来加载和推理 NIOVL，只要：
- 在 vLLM 的 internvl.py 中检测 `model_type == "niovl"` 并走 SiglipVisionModel 路径
- 在 extract_feature 中跳过 CLS token 移除（Siglip 没有 CLS token）

### 2. 模型注册机制

`verl/utils/tokenizer.py` 中做了三步注册，让 NIOVL 在整个 verl 框架中"伪装"成 InternVL：

```python
from verl.mlm.niovl import NIOVLConfig, NIOVLModel

# Step 1: 向 HuggingFace AutoConfig 注册 NIOVL model type
AutoConfig.register("niovl", NIOVLConfig)

# Step 2: 向 HuggingFace AutoModelForVision2Seq 注册 NIOVL
AutoModelForVision2Seq.register(NIOVLConfig, NIOVLModel)

# Step 3: 向 vLLM ModelRegistry 注册 —— 关键！
# NIOVL 在 vLLM 推理时使用 InternVLChatModel（因为架构高度相似）
from vllm.model_executor.models.registry import ModelRegistry
from vllm.model_executor.models.internvl import InternVLChatModel
ModelRegistry.register_model("NIOVLModel", InternVLChatModel)

- Step 3 是整个迁移最核心的一步：它让 vLLM 在加载 NIOVL 模型时走 `InternVLChatModel.__init__`，内部检测到 `model_type == "niovl"` 后走 SiglipVisionModel 分支（通过 install.sh 中的 vLLM patch 实现）。

### 3. 训练代码适配：复用 InternVL 路径

`verl/workers/fsdp_workers.py` 和 `verl/utils/tokenizer.py` 中的改动模式一致：

修改前（只支持 InternVL）：
```python
if re.match("internvl", config.model_type):
    # InternVL 特殊处理...

修改后（支持 InternVL + NIOVL）：
```python
if re.match("internvl|niovl", config.model_type, re.IGNORECASE):
    # InternVL/NIOVL 共用处理逻辑...

具体适配点：
1. tokenizer：NIOVL 使用与 InternVL 相同的 image token 约定（`<img>`, `<IMG_CONTEXT>`, `</img>`）
2. vision_model 冻结：训练时冻结 vision_model 参数（与 InternVL 一致）
3. gradient checkpointing：NIOVL 的 encoder 路径是 `vision_model.vision_model.encoder`，与 InternVL 的 `vision_model.encoder` 不同，需添加 `hasattr` 检测

### 4. `configuration_niovl.py` — vLLM 兼容层

核心改动：新增 proxy properties，让 vLLM 的 `InternVLChatModel` 能通过 NIOVLConfig 读取 LLM 配置。

```python
# vLLM 期望 config.text_config 指向 LLM config
@property
def text_config(self):
    return self.llm_config

# vLLM 在 InternVLChatModel.__init__ 中直接访问 config.hidden_size 等属性
# NIOVL 这些属性在 llm_config 子配置中，需要代理
@property
def hidden_size(self):
    return self.llm_config.hidden_size

@property
def num_attention_heads(self):
    return self.llm_config.num_attention_heads

# ... 其他属性的代理（num_hidden_layers, num_key_value_heads, head_dim,
#     hidden_act, intermediate_size, max_position_embeddings, vocab_size）

另外添加了 `self.select_layer = -1`（vLLM internvl.py 期望此属性存在）。

### 5. `modeling_niovl.py` — 模型主体

从 evaluator 复制后做的修改：

1. 新增 vLLM/HF 兼容属性（训练/推理框架需要）：
```python
   _supports_flash_attn_2 = True
   supports_gradient_checkpointing = True
   _supports_gradient_checkpointing = True

2. 移除 evaluator 训练专有逻辑：
   - 移除 `LabelSmoother` / `IGNORE_INDEX`（eval 侧无 label smoothing）
   - 移除 sequence packing 校验代码（`valid_token_count` / `loss_weight` 参数及其校验逻辑）
   - 移除 `vit_compress` / `ldp_in_vit` 检测逻辑（初次迁移不包含 ViT 内压缩）

3. 修复 `num_image_token` 计算：
```python
   # evaluator 原版（有 LDP 时另外乘 0.25）
   self.num_image_token = int((image_size // patch_size) ** 2 * (config.downsample_ratio ** 2))
   if self.use_LDP:
       self.num_image_token = int(self.num_image_token * 0.25)
   
   # verl 迁移版（统一除以 4，因为 pixel_shuffle 已做空间压缩）
   self.num_image_token = int((image_size // patch_size) ** 2 * (config.downsample_ratio ** 2)) // 4

4. 安全守卫：
```python
   # evaluator 原版（假设 image_flags 一定存在）
   vit_embeds = vit_embeds[image_flags.squeeze(-1) == 1]
   
   # verl 迁移版（加 None 检查）
   if image_flags is not None:
       vit_embeds = vit_embeds[image_flags.squeeze(-1) == 1]

### 6. `adaptor.py` — Adaptor 适配层

从 evaluator 复制后做的修改：

移除 `compress_in_vit` 参数和相关分支（初次迁移不包含 ViT 内压缩功能）：
- 移除 `compress_in_vit` 构造参数
- 移除 `if compress_in_vit` 条件分支（只保留标准 pixel_shuffle 模式）
- 移除 `forward()` 中 `compress_in_vit` 跳过 pixel_shuffle 的条件判断
- 移除 `forward()` 中的 token 计数校验（`h * w != vit_embeds.shape[1]` 检查）

初次迁移的 Adaptor 保持简单：所有输入都经过 pixel_shuffle → mlp1 → (可选 LDP) 的标准流程。

### 7. `siglip/modeling_siglip.py` — Vision Encoder

从 evaluator 复制后做的修改：

移除 ViT 内压缩相关代码（初次迁移不包含，后续在另一个 commit 中加回）：
- 移除 `vision_space_to_depth_shuffle()` 函数
- 移除 `SiglipEncoder` 中的 `vit_compress_norm`/`vit_compress_fusion`/`vit_ldp_dwn`/`vit_ldp_peg`
- 移除 `SiglipEncoder` 中的 `_compress_sequence()`/`_ldp_sequence()` 方法
- 移除 `SiglipEncoder.forward()` 中的 layer_idx 级别压缩/LDP 逻辑
- 修复 `SiglipAttention` 中 `_attn_implementation` 访问：`getattr(self.config, "_attn_implementation", "eager")`

### 8. `siglip/configuration_siglip.py` — Vision Config

从 evaluator 复制后做的修改：

移除 ViT 内压缩配置字段（初次迁移不包含）：
- 移除 `vit_compress_start_layer`
- 移除 `vit_compress_ratio`
- 移除 `vit_compress_ps_version`
- 移除 `vit_ldp_layer`

### 9. `qwen2/modeling_qwen2.py` — Language Model

从 evaluator 复制后做的修改：

移除 sequence packing 相关代码（verl 当时使用的旧版 fa2 不支持 cu_seq_lens 显式传递）：
- 移除 `Qwen2FlashAttention2` 类（继承 `FlashAttentionExplicitCuMixin`）
- 移除 `QWEN2_ATTENTION_CLASSES` 分发字典
- 恢复 `Qwen2DecoderLayer` 使用 `Qwen2Attention` 而非动态分发
- 移除 `Qwen2DecoderLayer.forward()` 中的 `cu_seq_lens_q/k` 参数
- 移除 `Qwen2Model.forward()` 中的 `cu_seq_lens_q/k` 参数和处理逻辑
- 移除 `Qwen2ForCausalLM.forward()` 中的 `KwargsForCausalLM` 文档和相关参数

### 10. `tokenizer.py` — Tokenizer 适配

三步注册 + 一处扩展：

1. 注册 NIOVL model type 到 HuggingFace AutoConfig
2. 注册 NIOVL 到 AutoModelForVision2Seq
3. 注册 NIOVLModel → InternVLChatModel 到 vLLM ModelRegistry
4. 扩展 internvl → `internvl|niovl` 以共用 image token 约定

### 11. `fsdp_workers.py` — 训练 Worker 适配

三处 `internvl` → `internvl|niovl` 扩展：

1. 模型加载参数：InternVL/NIOVL 都不使用 `flash_attention_2` init kwarg（用自己的 attention 实现）
2. Vision 参数冻结：添加 `hasattr(actor_module, "vision_model")` 安全守卫（NIOVL 一定有但加防御）
3. Gradient Checkpointing：NIOVL 的 encoder 路径不同，添加兼容分支：
```python
   if hasattr(actor_module.vision_model, "vision_model"):
       # NIOVL: SiglipVisionModel 有双层嵌套 vision_model.vision_model.encoder
       actor_module.vision_model.vision_model.encoder.gradient_checkpointing = True
   else:
       actor_module.vision_model.encoder.gradient_checkpointing = True

### 12. `install.sh` — 环境安装 + vLLM 补丁

一键安装脚本包含 vLLM internvl.py 的 4 个自动补丁：

| Patch | 位置 | 说明 |
|-------|------|------|
| Patch 1 | `_init_vision_model` | 检测 `model_type == "niovl"` → 使用 `SiglipVisionModel` 而非 `InternVisionModel` |
| Patch 2 | `extract_feature` | Siglip 路径：无 CLS token 移除 + 包含 LDPNetv2 下采样 |
| Patch 3 | `skip_prefixes` | 添加 `"adaptor_model"` 到跳过前缀列表 |
| Patch 4 | `__init__` | NIOVL 模式下初始化 LDPNetv2_dwn 和 LDPNetv2_peg 层 |

---

## Token 数量计算

- 输入：512×512 图像，patch_size=16 → 32×32 = 1024 patches
- ViT 输出：1024 tokens × 768 hidden_size
- Adaptor pixel_shuffle（ratio=0.5）：1024 → 256 tokens（空间上从 32×32 → 16×16）
- Adaptor LDP（AdaptiveAvgPool2d((8,8))）：256 → 64 tokens
- 每个 tile 最终输出 64 个 visual tokens

---

## 直接复制的文件（无修改）

以下文件从 evaluator 原样复制，无需适配：

```
verl/mlm/niovl/siglip/image_processing_siglip.py        — Siglip 图像预处理
verl/mlm/niovl/siglip/image_processing_siglip_fast.py    — Siglip 快速图像预处理
verl/mlm/niovl/siglip/processing_siglip.py               — Siglip 多模态处理器
verl/mlm/niovl/siglip/tokenization_siglip.py              — Siglip tokenizer
verl/mlm/niovl/qwen2/__init__.py                          — Qwen2 子模块导出
verl/mlm/niovl/qwen2/configuration_qwen2.py               — Qwen2 config
verl/mlm/niovl/qwen2/modular_qwen2.py                     — Qwen2 模块化模型
verl/mlm/niovl/qwen2/tokenization_qwen2.py                — Qwen2 tokenizer (slow)
verl/mlm/niovl/qwen2/tokenization_qwen2_fast.py           — Qwen2 tokenizer (fast)

---

## 当前状态

- [x] NIOVL 模型代码迁移到 verl（17 个文件）
- [x] verl 训练框架适配（fsdp_workers + tokenizer）
- [x] vLLM 推理管线打通（InternVLChatModel + 4 个 patch）
- [x] 环境安装脚本（一键安装 + 自动打补丁）
- [ ] ViT 中间层压缩（vit_compress）待后续迁移
- [ ] Adaptor compress_in_vit 模式待后续迁移

---

## 运行命令

```bash
# 一键安装环境
bash verl/mlm/niovl/install.sh

# 激活环境
source .venv2/bin/activate

# 启动 Ray
ray start --head

# 单 GPU debug 训练
python -m verl.trainer.main_ppo \
    algorithm.adv_estimator=grpo \
    data.train_files=[/path/to/train.parquet] \
    data.val_files=/path/to/val.parquet \
    data.train_batch_size=2 \
    data.max_prompt_length=4096 \
    data.max_response_length=1024 \
    data.image_key=image \
    actor_rollout_ref.model.path=/path/to/niovl_model \
    actor_rollout_ref.actor.optim.lr=1e-6 \
    actor_rollout_ref.model.use_remove_padding=True \
    actor_rollout_ref.actor.ppo_mini_batch_size=2 \
    actor_rollout_ref.actor.ppo_micro_batch_size_per_gpu=1 \
    actor_rollout_ref.rollout.name=vllm \
    actor_rollout_ref.rollout.gpu_memory_utilization=0.4 \
    actor_rollout_ref.rollout.enforce_eager=True \
    trainer.n_gpus_per_node=1 \
    trainer.nnodes=1 \
    trainer.total_epochs=1
