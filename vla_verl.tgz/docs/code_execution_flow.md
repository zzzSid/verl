# NIOVL CoT-RL GRPO 训练脚本代码执行流程

> 以 `user_scripts/no_entry/cot_rl/niovl3_06B_cot-rl_16k_data1116-2_recall-iou-res-reward-precB_debug_da-before5_cot.sh` 为例

---

## 一、整体架构概览

```
Shell 脚本
  ├─ [1] 环境初始化 (Ray 集群启动)
  ├─ [2] python3 -m verl.trainer.main_ppo (Hydra 配置 + PPO 训练主循环)
  │      ├─ 加载模型、Tokenizer、Processor
  │      ├─ 加载数据集 (RLHFDataset, 多模态 parquet)
  │      ├─ 初始化 Workers (ActorRollout, RefPolicy)
  │      └─ fit() 训练循环
  │           ├─ ① 生成 (vLLM rollout)
  │           ├─ ② 计算 Reward (自定义 no_entry_reward)
  │           ├─ ③ 计算 old_log_prob
  │           ├─ ④ 计算 ref_log_prob
  │           ├─ ⑤ 计算 Advantage (GRPO)
  │           ├─ ⑥ 更新 Actor (PPO clipped loss + KL loss)
  │           └─ ⑦ 保存 / 验证
  └─ [3] 模型合并 (FSDP shards → HuggingFace 格式)
```

---

## 二、Phase 1: Shell 脚本环境初始化

**文件**: `user_scripts/no_entry/cot_rl/niovl3_06B_cot-rl_16k_data1116-2_recall-iou-res-reward-precB_debug_da-before5_cot.sh`

```
行号   操作说明
────── ──────────────────────────────────────────
10-27  修复 HOME 目录权限（KPT 平台兼容）
29     激活 Python 虚拟环境 .venv2/bin/activate
42-58  解析 /etc/volcano/all.host，启动 Ray Head + Worker 集群
64-65  设置 PYTHONPATH 包含项目根目录和 verl/
68     设置推理引擎 ENGINE=vllm（默认）
72-74  生成时间戳，拼接 PROJECT_NAME 和 EXPERIMENT_NAME
77     设置模型路径 MODEL_PATH（NIOVL 模型 checkpoint）
81     设置训练数据 TRAIN_DATA（parquet 文件）
86-89  NNODES=1, GPU_PER_NODE=1, ROLLOUT_IMAGE_LIMIT=20
```

### 1.1 核心启动命令

```bash
python3 -m verl.trainer.main_ppo \
    algorithm.adv_estimator=grpo \                    # 使用 GRPO 算法
    data.train_files=...parquet \                     # 训练数据路径
    data.max_prompt_length=8192 \                     # 最大 prompt 长度
    data.max_response_length=3200 \                   # 最大 response 长度
    data.image_key=image \                            # 多模态图片 key
    actor_rollout_ref.model.path=$MODEL_PATH \        # 模型路径
    actor_rollout_ref.rollout.n=8 \                   # 每个 prompt 生成 8 条回复
    actor_rollout_ref.actor.use_kl_loss=True \        # 启用 KL 散度损失
    actor_rollout_ref.actor.kl_loss_coef=0.01 \       # KL 损失系数
    trainer.n_gpus_per_node=1 \                        # 每个节点 1 GPU
    trainer.total_epochs=3 \                          # 训练 3 个 epoch
    custom_reward_function.path=...task_no_entry_cot_result_recall-iou.py \  # 自定义 reward
    custom_reward_function.name=no_entry_reward \
    custom_reward_function.reward_kwargs.reward_version='SimpleCot' \       # reward 版本
    custom_reward_function.reward_kwargs.iou_threshold=0.2                   # IoU 阈值
```

> 这些参数通过 Hydra 覆盖 `verl/trainer/config/ppo_trainer.yaml` 中的默认配置。

---

## 三、Phase 2: Python 训练入口 — `main_ppo.py`

**文件**: `verl/trainer/main_ppo.py`

### 3.1 入口函数调用链

```
__main__ (line 245)
  └─ main() (line 62)
       └─ @hydra.main(config_path="config", config_name="ppo_trainer")
          → 加载 verl/trainer/config/ppo_trainer.yaml
          → 用 CLI 传入的参数覆盖默认配置
          └─ run_ppo(config) (line 67)
```

### 3.2 `run_ppo()` (line 67-76)

```python
def run_ppo(config) -> None:
    # 初始化 Ray（如果尚未初始化）
    ray.init(runtime_env={...}, num_cpus=config.ray_init.num_cpus)

    # 创建远程 Ray Actor（避免调度在 head 节点）
    runner = TaskRunner.remote()
    ray.get(runner.run.remote(config))
```

### 3.3 `TaskRunner.run()` (line 79-183) — 核心初始化

```
TaskRunner.run()
  ├─ ① 下载模型 checkpoint 到本地
  ├─ ② 加载 tokenizer + processor（多模态图片处理）
  │      processor = hf_processor(local_path, ...)
  │      → 用于 InternVL/NIOVL 的图片预处理
  ├─ ③ 选择训练策略（FSDP/FSDP2）
  │      actor_rollout_cls = ActorRolloutRefWorker
  │      → verl/workers/fsdp_workers.py
  ├─ ④ 建立角色映射
  │      Role.ActorRollout → ActorRolloutRefWorker
  │      Role.RefPolicy    → ActorRolloutRefWorker (shared for KL loss)
  ├─ ⑤ 加载自定义 Reward 函数
  │      → load_reward_manager() → NaiveRewardManager
  │      → compute_score = no_entry_reward
  │      → 来自 verl/utils/reward_score/task_no_entry_cot_result_recall-iou.py
  ├─ ⑥ 创建数据集
  │      RLHFDataset(train_files)  → 读 parquet，tokenize，处理图片
  │      RLHFDataset(val_files)
  ├─ ⑦ 创建 RayPPOTrainer
  │      trainer = RayPPOTrainer(config, tokenizer, processor, ...)
  │      trainer.init_workers()
  │      trainer.fit()
```

---

## 四、Phase 3: 数据集 — `RLHFDataset`

**文件**: `verl/utils/dataset/rl_dataset.py`

### 4.1 初始化 `__init__()` (line 120-175)

```
RLHFDataset.__init__()
  ├─ datasets.load_dataset("parquet", data_files=...)  # 读取 parquet
  ├─ filter_overlong_prompts: 过滤太长的 prompt
  │    → tokenizer.apply_chat_template() 后检查长度
  │    → max_prompt_length=8192
  └─ 数据列: prompt (对话), image (图片路径), reward_model (GT), extra_info
```

### 4.2 取样本 `__getitem__()` (line 283-382)

```
__getitem__(item)
  ├─ _build_messages(row_dict)  # 构建 chat messages
  ├─ processor.apply_chat_template()  # 应用 chat template → raw_prompt
  ├─ 加载图片
  │    row_dict["image"] → load_image()  # 读取图片文件
  │    → multi_modal_data["image"] = images
  ├─ processor(text=[raw_prompt], images=images, ...)
  │    → 输出 input_ids, attention_mask, pixel_values 等
  ├─ postprocess_data() → left-pad + truncate
  ├─ compute_position_id_with_mask() → position_ids
  └─ 返回 {input_ids, attention_mask, position_ids,
            raw_prompt, multi_modal_data, multi_modal_inputs, ...}
```

### 4.3 Collate Function (line 91-112)

```python
def collate_fn(data_list: list[dict]) -> dict:
    # tensors → torch.stack
    # non_tensors → np.array
    return {**tensors, **non_tensors}
```

---

## 五、Phase 4: Worker 初始化 — `RayPPOTrainer.init_workers()`

**文件**: `verl/trainer/ppo/ray_trainer.py` (line 691-767)

```
init_workers()
  ├─ ResourcePoolManager.create_resource_pool()
  │    → 根据 nnodes × n_gpus_per_node 分配 GPU 资源
  ├─ 创建 ActorRollout Worker
  │    RayClassWithInitArgs(ActorRolloutRefWorker, config, role="actor_rollout")
  ├─ 创建 RefPolicy Worker (因为 use_kl_loss=True)
  │    RayClassWithInitArgs(ActorRolloutRefWorker, config, role="ref")
  ├─ create_colocated_worker_cls() → 合并到同一进程
  ├─ RayWorkerGroup.spawn() → 启动 Ray Workers
  ├─ ref_policy_wg.init_model() → 加载参考模型 (FSDP)
  └─ actor_rollout_wg.init_model() → 加载 actor 模型 + 初始化 vLLM rollout
```

> **关键点**: `actor_rollout_ref.actor.use_kl_loss=True` 会触发 `Role.RefPolicy` 的创建（line 155-157），即会额外加载一个冻结的参考模型用于计算 KL 散度。

---

## 六、Phase 5: 训练主循环 — `RayPPOTrainer.fit()`

**文件**: `verl/trainer/ppo/ray_trainer.py` (line 867-1114)

### 6.1 循环结构

```python
for epoch in range(total_epochs):           # 3 epochs
    for batch_dict in train_dataloader:     # 遍历所有数据
        global_steps += 1

        # === ① 生成 (vLLM Rollout) ===
        gen_batch_output = actor_rollout_wg.generate_sequences(gen_batch)
        #   → vLLM 推理，每个 prompt 生成 n=8 条回复

        # === ② Reward 计算 ===
        reward_tensor, reward_extra_info, diff_reward, seperate_score
            = compute_reward(batch, self.reward_fn)
        #   → NaiveRewardManager → no_entry_reward → TaskNoEntryReward

        # === ③ Old Log Prob ===
        old_log_prob = actor_rollout_wg.compute_log_prob(batch)
        #   → 用当前 actor 计算 log prob

        # === ④ Ref Log Prob (KL loss) ===
        ref_log_prob = ref_policy_wg.compute_ref_log_prob(batch)
        #   → 用冻结的参考模型计算 log prob

        # === ⑤ Advantage 计算 ===
        batch = compute_advantage(batch, adv_estimator=GRPO, ...)
        #   → GRPO: group-level normalized advantage

        # === ⑥ Actor 更新 ===
        actor_output = actor_rollout_wg.update_actor(batch)
        #   → PPO clipped loss + KL divergence loss (FSDP)

        # === ⑦ 保存 / 验证 ===
        if global_steps % save_freq == 0:  _save_checkpoint()
        if global_steps % test_freq == 0:  _validate()
```

### 6.2 各步骤详解

#### 步骤 ①: 生成 (Rollout) — line 931-933

```
actor_rollout_wg.generate_sequences(gen_batch)
  → verl/workers/fsdp_workers.py: ActorRolloutRefWorker.generate_sequences()
  → vLLM 推理引擎
  → 输入: input_ids, attention_mask, position_ids, multi_modal_inputs（图片）
  → 输出: responses (shape: [batch_size, response_length])
  → n=8 意味着每个 prompt 生成 8 条候选回复
```

#### 步骤 ②: Reward 计算 — line 970-979

```python
# 文件: verl/trainer/ppo/reward.py → compute_reward()
reward_result = reward_fn(data, return_dict=True)
# reward_fn 是 NaiveRewardManager 的实例
```

**NaiveRewardManager** (`verl/workers/reward_manager/naive.py` line 32-142):
```python
for i in range(len(data)):
    # 1. 解码 prompt + response
    prompt_str = tokenizer.decode(valid_prompt_ids)
    response_str = tokenizer.decode(valid_response_ids)

    # 2. 调用自定义 reward 函数
    score = self.compute_score(
        data_source=data_source,      # "no-entry"
        solution_str=response_str,    # 模型生成的 CoT + answer
        ground_truth=ground_truth,    # GT 标签
        extra_info=extra_info,
    )
    # 3. score 放在 response 最后一个有效 token 位置
    reward_tensor[i, valid_response_length - 1] = score["score"]
```

**自定义 Reward** (`verl/utils/reward_score/task_no_entry_cot_result_recall-iou.py`):

```
no_entry_reward() (line 74)
  → TaskNoEntryReward.__call__() (line 96)
    → calc_score_simple_cot(solution_str, ground_truth) (line 106)

Reward 组成:
  ├─ Format Score (0.0 ~ 1.0) — 5 项各 0.2 分
  │    ├─ tag_check:     <thinking> 在 <answer> 之前 → 0.2
  │    ├─ length_check:  预测路线数 = GT 路线数 → 0.2
  │    ├─ AB_check:      每个路线预测是 A 或 B → 0.2
  │    ├─ img_id_check:  B 类路线有合法视角标记 [UNUSED_TOKEN_53~56] → 0.2
  │    └─ bbox_check:    B 类路线有合法 <box> 坐标 (0~999, 4 个值) → 0.2
  │
  └─ Content Score (0.0 ~ 1.0, 归一化)
       ├─ Category Score (分类正确性):
       │    ├─ A 类路线预测为 A → +8.0
       │    ├─ B 类路线预测为 B → +10.0
       │    └─ 错误 → +0.0
       │
       └─ Grounding Score (框召回率):
            ├─ 预测的 img_id 匹配 GT 中任意一个
            ├─ 计算 bbox_reward(): IoU ≥ 0.2 → 1.0, 否则 IoU×5
            └─ grounding_score = max(bbox_reward) × 2.0

  最终 reward = format_score + content_score_norm
  同时输出 diff_score: 每条路线的分别得分 + format_score
```

#### 步骤 ③: Old Log Prob — line 982-991

```
actor_rollout_wg.compute_log_prob(batch)
  → Actor 模型 forward（FSDP）
  → 计算 log_probs，不更新参数
  → 同时计算 entropy → entropy_loss
```

#### 步骤 ④: Ref Log Prob — line 993-997

```
ref_policy_wg.compute_ref_log_prob(batch)
  → 冻结的参考模型 forward（FSDP, param_offload=True）
  → 计算 ref_log_probs
  → 用于 KL loss: kl_loss = kl_loss_coef * KL(policy || ref)
```

#### 步骤 ⑤: Advantage 计算 — line 1005-1050

```python
# 使用 GRPO (Group Relative Policy Optimization)
batch = compute_advantage(
    batch, adv_estimator=AdvantageEstimator.GRPO, num_repeat=8, ...
)
```

**GRPO 核心逻辑** (`verl/trainer/ppo/core_algos.py` line 181):
```
compute_grpo_outcome_advantage()
  → 将同一 prompt 的 n=8 条回复分为一组
  → advantage = (reward - group_mean) / group_std  （组内标准化）
  → 鼓励模型选择组内相对更好的回复
```

#### 步骤 ⑥: Actor 更新 — line 1062-1064

```
actor_rollout_wg.update_actor(batch)
  → verl/workers/fsdp_workers.py: ActorRolloutRefWorker.update_actor()

PPO 训练目标:
  ├─ policy_loss = -min(
  │      ratio * advantage,
  │      clip(ratio, 1-ε, 1+ε) * advantage
  │    )   # ε = clip_ratio = 0.2
  │
  └─ kl_loss = kl_loss_coef * KL(policy || ref)  # 0.01 * low_var_kl
     → total_loss = policy_loss + kl_loss + entropy_coeff * entropy_loss
```

#### 步骤 ⑦: 保存 & 验证

```python
# 保存 (line 1092-1094)
if global_steps % 25 == 0:
    _save_checkpoint()
    # → output/{project}/{experiment}/global_step_X/actor/
    # → 保存 FSDP 分片模型权重 + optimizer state

# 验证 (line 1085-1090)
if global_steps % test_freq == 0:
    val_metrics = _validate()
    # → 用 val_dataset 跑一轮 rollout + reward
    # → 记录 val 指标到 wandb
```

---

## 七、Phase 6: 模型合并

**Shell 脚本** (line 143-172):

```bash
# 1. 找到最大的 global_step_X 目录
GLOBAL_STEP_DIR=$(ls ./output/${PROJECT_NAME}/${EXPERIMENT_NAME} | ...)

# 2. 拷贝 mlm 辅助文件
cp verl/mlm/*.py ./output/.../global_step_X/actor

# 3. 执行 FSDP 模型合并
python3 scripts/model_merger.py merge \
    --backend fsdp \
    --local_dir ./output/.../global_step_X/actor \
    --target_dir ./output/.../${EXPERIMENT_NAME}

# 4. 拷贝 mlm 辅助文件到合并后目录
cp verl/mlm/*.py ${MERGE_OUTPUT_DIR}
```

**`scripts/model_merger.py`**:
```
→ 将 FSDP 分片的 state_dict 合并为完整的 HuggingFace 格式模型
→ 包含 model weights + config + tokenizer
→ 输出可直接用于推理的 HF 模型
```

---

## 八、完整文件调用关系图

```
user_scripts/no_entry/cot_rl/niovl3_06B_cot-rl_...sh  ← [入口] Shell 脚本
  │
  ├─ ray start --head / ssh ... ray start --address   ← 启动 Ray 集群
  │
  ├─ python3 -m verl.trainer.main_ppo                   ← [训练入口]
  │   │ verl/trainer/main_ppo.py
  │   │
  │   ├─ verl/trainer/config/ppo_trainer.yaml           ← Hydra 默认配置
  │   │   + CLI overrides                               ← Shell 传入的参数
  │   │
  │   ├─ verl/trainer/ppo/ray_trainer.py                ← RayPPOTrainer
  │   │   ├─ init_workers()      ← 初始化 Ray Workers
  │   │   │   └─ verl/workers/fsdp_workers.py           ← ActorRolloutRefWorker
  │   │   │
  │   │   └─ fit()               ← 训练主循环
  │   │       ├─ generate_sequences()   ← vLLM rollout
  │   │       ├─ compute_reward()       ← 奖励计算
  │   │       │   └─ verl/trainer/ppo/reward.py
  │   │       │       └─ verl/workers/reward_manager/naive.py  ← NaiveRewardManager
  │   │       │           └─ verl/utils/reward_score/task_no_entry_cot_result_recall-iou.py
  │   │       │               └─ no_entry_reward → TaskNoEntryReward.calc_score_simple_cot()
  │   │       │                   ├─ Format Score（tag/length/AB/img_id/bbox）
  │   │       │                   └─ Content Score（category + grounding IoU）
  │   │       │
  │   │       ├─ compute_log_prob()    ← old log prob
  │   │       ├─ compute_ref_log_prob() ← ref log prob (KL loss)
  │   │       ├─ compute_advantage()   ← GRPO advantage
  │   │       │   └─ verl/trainer/ppo/core_algos.py
  │   │       │       └─ compute_grpo_outcome_advantage()
  │   │       │
  │   │       ├─ update_actor()        ← PPO 参数更新
  │   │       ├─ _save_checkpoint()    ← 保存 FSDP 分片
  │   │       └─ _validate()           ← 验证集评估
  │   │
  │   └─ verl/utils/dataset/rl_dataset.py              ← RLHFDataset
  │       ├─ datasets.load_dataset("parquet")
  │       ├─ processor (image processing)
  │       └─ tokenizer
  │
  └─ python3 scripts/model_merger.py merge --backend fsdp   ← [模型合并]
      └─ scripts/model_merger.py
          → FSDP sharded state_dict → HuggingFace format
```

---

## 九、关键设计要点总结

| 阶段 | 关键点 |
|------|--------|
| **分布式** | Ray 集群管理（1 head + N workers），单节点单 GPU 训练 |
| **训练算法** | GRPO (Group Relative Policy Optimization)，group-based advantage normalization |
| **推理引擎** | vLLM 进行高效 rollout 生成，n=8 条回复/每个 prompt |
| **多模态** | InternVL/NIOVL processor 处理图片，动态 tile 切分 (dynamic_preprocess) |
| **Reward** | 格式分(5项×0.2) + 内容分(分类+grounding IoU)，1:1 加权 |
| **KL 约束** | KL loss (low_var_kl) + 冻结参考模型，防止策略偏离过大 |
| **模型保存** | FSDP 分片保存 → 训练后 `model_merger.py` 合并为 HF 格式 |
| **日志** | wandb + console 双通道，记录 reward/format/content/loss/timing 等指标 |
