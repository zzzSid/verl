# VERL 强化学习算法原理与实现分析

> 本文档详细分析 VERL 项目中所有 RL 算法的数学原理、核心公式、代码实现架构及配置方式。

---

## 目录

1. [总体架构概览](#1-总体架构概览)
2. [PPO (Proximal Policy Optimization)](#2-ppo-proximal-policy-optimization)
3. [BAPO (Balanced Adaptive Policy Optimization)](#3-bapo-balanced-adaptive-policy-optimization)
4. [FlowRL (基于 Trajectory Balance)](#4-flowrl-基于-trajectory-balance)
5. [SPPO (Self-Play Preference Optimization)](#5-sppo-self-play-preference-optimization)
6. [ReMax (Reward Maximization)](#6-remax-reward-maximization)
7. [dNPO (Dynamic Negative Preference Optimization)](#7-dnpo-dynamic-negative-preference-optimization)
8. [GRPO (Group Relative Policy Optimization)](#8-grpo-group-relative-policy-optimization)
9. [RLOO (REINFORCE Leave-One-Out)](#9-rloo-reinforce-leave-one-out)
10. [REINFORCE++ / REINFORCE++-Baseline](#10-reinforce--reinforce-baseline)
11. [GDPO (Group Dimension Preference Optimization)](#11-gdpo-group-dimension-preference-optimization)
12. [GAE (Generalized Advantage Estimation)](#12-gae-generalized-advantage-estimation)
13. [算法对比总结](#13-算法对比总结)

---

## 1. 总体架构概览

### 1.1 两层抽象

VERL 的 RL 训练在 **两个独立维度** 上支持多种算法变体：

**维度一：Advantage Estimator（优势估计器）**

定义在 `verl/trainer/ppo/ray_trainer.py` 的 `AdvantageEstimator` 枚举中：

```python
class AdvantageEstimator(str, Enum):
    GAE = "gae"                        # 需要 Critic 网络
    GRPO = "grpo"                      # 不需要 Critic
    REINFORCE_PLUS_PLUS = "reinforce_plus_plus"
    REINFORCE_PLUS_PLUS_BASELINE = "reinforce_plus_plus_baseline"
    REMAX = "remax"
    RLOO = "rloo"
    GDPO = "gdpo"
```

其中仅 `GAE` 需要 Critic（价值网络），其余均为 Critic-Free 方法。

**维度二：Policy Loss Type（策略损失类型）**

定义在 `verl/workers/actor/dp_actor.py` 的 `loss_cal` 配置项中：

- `"ppo"` — 标准 PPO clipped surrogate loss（默认）
- `"bapo"` — BAPO 动态裁剪损失（通过配置 `policy_loss_type="bapo"` 启用）
- `"flowrl"` — 基于 Trajectory Balance 的 FlowRL 损失

`"sppo"` 作为独立 recipe 实现（`recipe/sppo/`），有完整的独立训练器。

### 1.2 数据流

```
Rollout → Reward → Advantage → Critic Update → Actor Update → Logging
   │         │          │            │               │
   │         │          │            │               └─→ actor/* 指标
   │         │          │            └─→ critic/vf_* 指标
   │         │          └─→ critic/score, critic/rewards, critic/advantages
   │         └─→ actor/reward_kl_penalty (if use_kl_in_reward)
   └─→ response_length/*, prompt_length/*
```

### 1.3 关键配置参数

| 配置参数 | 位置 | 说明 |
|----------|------|------|
| `algorithm.adv_estimator` | `config.algorithm` | 选择 advantage 估计器 |
| `actor_rollout_ref.actor.loss_cal` | `config.actor` | 选择策略损失类型（ppo/bapo/flowrl）|
| `actor_rollout_ref.actor.policy_loss_type` | `config.actor.policy_loss` | BAPO 的子配置 |
| `algorithm.use_kl_in_reward` | `config.algorithm` | 是否在 reward 中扣除 KL |
| `actor_rollout_ref.actor.use_kl_loss` | `config.actor` | 是否显式加 KL loss |
| `actor_rollout_ref.actor.clip_ratio` | `config.actor` | PPO 裁剪范围 |

---

## 2. PPO (Proximal Policy Optimization)

### 2.1 原理

PPO 是一种策略梯度方法，通过 clipped surrogate objective 限制每次策略更新的幅度，防止策略崩溃。VERL 实现了标准的 PPO-Clip 及 Dual-Clip PPO。

**核心思想**：在最大化 advantage 的同时，限制新旧策略的 ratio `r_t(θ) = π_θ(a_t|s_t) / π_θold(a_t|s_t)` 不要偏离 1 太远。

### 2.2 数学公式

**Importance Sampling Ratio：**

```
ratio = exp(log_prob - old_log_prob)
```

**标准 PPO Clipped Surrogate Loss：**

```
L_CLIP(θ) = E[min(r_t(θ) * A_t, clip(r_t(θ), 1-ε, 1+ε) * A_t)]
```

对于正 advantage：取 `max(-ratio * A, -clip(ratio) * A)`（防止 ratio 过大）
对于负 advantage：取 `min(-ratio * A, -clip(ratio) * A)`（防止 ratio 过小）

**Dual-Clip PPO（负 advantage 额外保护）：**

```
L_dual_clip = max(L_CLIP, -c * A_t)  # 其中 c = clip_ratio_c，默认 3.0
```

这防止负 advantage 时 ratio 降得过低导致策略崩溃。

### 2.3 代码实现

**文件：** `verl/trainer/ppo/core_algos.py` → `compute_policy_loss()`

```python
def compute_policy_loss(old_log_prob, log_prob, advantages, response_mask,
                        cliprange, cliprange_low, cliprange_high, clip_ratio_c, loss_agg_mode):
    # 1. 计算 ratio
    negative_approx_kl = log_prob - old_log_prob
    ratio = torch.exp(negative_approx_kl)

    # 2. 未裁剪损失和裁剪损失
    pg_losses1 = -advantages * ratio
    pg_losses2 = -advantages * clamp(ratio, 1-cliprange_low, 1+cliprange_high)

    # 3. 正 advantage：取 max（防止 ratio 过大）
    clip_pg_losses1 = max(pg_losses1, pg_losses2)

    # 4. Dual-clip：负 advantage 的下界保护
    pg_losses3 = -advantages * clip_ratio_c
    clip_pg_losses2 = min(pg_losses3, clip_pg_losses1)

    # 5. 最终 loss
    pg_losses = where(advantages < 0, clip_pg_losses2, clip_pg_losses1)

    # 6. 按 response_mask 聚合
    pg_loss = agg_loss(pg_losses, response_mask, loss_agg_mode)
    return pg_loss, pg_clipfrac, ppo_kl, pg_clipfrac_lower
```

**聚合模式（`loss_agg_mode`）：**

| 模式 | 含义 |
|------|------|
| `token-mean` | 对有效 token 做平均（默认） |
| `seq-mean-token-sum` | 先每序列求和，再对序列平均 |
| `seq-mean-token-mean` | 先每序列平均，再对序列平均 |
| `seq-mean-token-sum-norm` | 先每序列求和，再除以 response_length 常数 |

**Actor 更新流程（`verl/workers/actor/dp_actor.py` → `update_policy()`）：**

```
for epoch in ppo_epochs:
    for mini_batch in dataloader:
        for micro_batch in mini_batch:
            log_prob = _forward_micro_batch(micro_batch)
            pg_loss = compute_policy_loss(...)
            if entropy_coeff != 0:
                loss = pg_loss - entropy_coeff * entropy_loss
            if use_kl_loss:
                loss += kl_loss_coef * kl_loss
            loss.backward()
        optimizer.step()
```

**Critic 更新：**

```python
def compute_value_loss(vpreds, returns, values, response_mask, cliprange_value):
    # Clipped value loss，与 PPO policy loss 思路类似
    vpredclipped = clip(vpreds, values - clip, values + clip)
    vf_losses1 = (vpreds - returns)^2
    vf_losses2 = (vpredclipped - returns)^2
    vf_loss = 0.5 * masked_mean(max(vf_losses1, vf_losses2), response_mask)
```

### 2.4 配置激活方式

```yaml
algorithm:
  adv_estimator: "gae"      # 使用 GAE + Critic

actor_rollout_ref:
  actor:
    loss_cal: "ppo"         # 使用标准 PPO loss
    clip_ratio: 0.2
    clip_ratio_c: 3.0       # dual-clip 下界常数
    entropy_coeff: 0.01
    use_kl_loss: false
    kl_loss_coef: 0.001
    ppo_epochs: 1
```

---

## 3. BAPO (Balanced Adaptive Policy Optimization)

### 3.1 原理

BAPO 是 PPO 的一个变体，核心创新在于 **动态调整 PPO 的 clip bound（ε_low 和 ε_high）**，使训练过程中正/负 advantage 的贡献比维持在目标值附近（默认 1:1，即平衡）。

**动机**：标准 PPO 使用固定的 clip range [1-ε, 1+ε]，但训练过程中策略的"激进程度"是变化的。当前策略如果过于保守（ratio 普遍 < 1），正 advantage 贡献会被压制；如果过于激进，负 advantage 会被放大。BAPO 通过迭代调整 clip bound 来维持平衡。

### 3.2 数学公式

**Effective Advantage（有效 advantage）：**

```
effective_ratio = {
    min(ratio, 1 + ε_high),   if A >= 0    # 正 advantage: 限制 ratio 上限
    max(ratio, 1 - ε_low),    if A < 0     # 负 advantage: 限制 ratio 下限
}
effective_adv = effective_ratio * A * response_mask
```

**正负贡献比：**

```
pos_contrib = sum(max(effective_adv, 0))
neg_contrib = sum(max(-effective_adv, 0))
pos_neg_ratio = pos_contrib / neg_contrib
```

**BAPO 迭代调整算法：**

```
1. 从初始 clip bound (ε_low_start, ε_high_start) 开始
2. 计算当前 epoch 的 pos_neg_ratio
3. 若 pos_neg_ratio < target_ratio 且 ε_low < ε_low_max:
      增加 ε_low（放宽下界，允许更多负 advantage 被裁剪）
4. 若仍然 pos_neg_ratio < target_ratio 且 ε_high < ε_high_max:
      增加 ε_high（放宽上界，允许更多正 advantage 不被裁剪）
5. 使用调整后的 (ε_low, ε_high) 计算标准 PPO clipped loss
```

### 3.3 代码实现

**文件：** `verl/trainer/ppo/policy_loss.py` → `compute_policy_loss_bapo()`

```python
def compute_policy_loss_bapo(old_log_prob, log_prob, advantages,
                              response_mask, loss_agg_mode, config):
    # 从配置读取初始值和边界
    ratio_low_cur = pl_config.ratio_lower_start   # ε_low 初始值
    ratio_high_cur = pl_config.ratio_upper_start  # ε_high 初始值
    ratio_low_max = pl_config.ratio_lower_max     # ε_low 最大值
    ratio_high_max = pl_config.ratio_upper_max    # ε_high 最大值
    target_ratio = pl_config.adv_ratio_target     # 目标正负比（默认 1.0）

    # 迭代调整下界（优先）
    while pos_neg_ratio < target_ratio and ratio_low_cur < ratio_low_max:
        ratio_low_cur += ratio_lower_step
        pos_neg_ratio = recompute(...)

    # 若仍未达标，调整上界
    while pos_neg_ratio < target_ratio and ratio_high_cur < ratio_high_max:
        ratio_high_cur += ratio_upper_step
        pos_neg_ratio = recompute(...)

    # 用最终确定的 clip bound 计算 PPO loss
    pg_losses2 = -advantages * clamp(ratio, ratio_low_cur, ratio_high_cur)
    # ... 后续同标准 PPO
```

**训练器：** `verl/trainer/ppo/ray_trainer_bapo.py` → `RayBAPOTrainer(RayPPOTrainer)`
- 继承自 `RayPPOTrainer`，仅做了初始化透传，实际逻辑差异在 `compute_policy_loss_bapo` 中

### 3.4 配置激活方式

```yaml
actor_rollout_ref:
  actor:
    loss_cal: "ppo"           # 仍然走 PPO 路径
    policy_loss:
      type: "bapo"            # 启用 BAPO 动态裁剪
      ratio_lower_start: 0.8  # ε_low 初始值（ratio 下界 = 1-ε_low → 0.2）
      ratio_upper_start: 1.2  # ε_high 初始值（ratio 上界 = 1+ε_high → 2.2）
      ratio_lower_step: 0.05
      ratio_upper_step: 0.05
      ratio_lower_max: 0.9
      ratio_upper_max: 1.5
      adv_ratio_target: 1.0   # 目标正负贡献比 1:1
```

### 3.5 关键指标

| 指标 | 含义 |
|------|------|
| `actor/bapo_clip_low` | BAPO 最终确定的动态下界 |
| `actor/bapo_clip_high` | BAPO 最终确定的动态上界 |
| `actor/bapo_pos_neg_ratio` | 实际达到的正/负 advantage 贡献比 |

---

## 4. FlowRL (基于 Trajectory Balance)

### 4.1 原理

FlowRL 将 **GFlowNet** 的 Trajectory Balance（轨迹平衡）思想引入 LLM 对齐训练。它不用 PPO 的 clipped surrogate loss，而是要求策略的"前向概率流"满足平衡条件：

```
log_z + forward_logp ≈ scale * reward + ref_logp
```

直观理解：从初始状态（prompt）出发，以策略 π 生成完整响应所分配的"流量"（log_z + forward_logp），应该等于到达该状态后获得的"回报"（reward * scale + ref_logp）。

**核心组件：**

- **log_pf（对数前向概率）**：当前策略 π_θ 下，生成每个 response token 的对数概率
- **log_z（对数配分函数）**：由一个小 MLP（`ProjZModule`）从 prompt 的 hidden state 预测，表示从该状态出发可到达的所有轨迹的"总流量"
- **logp_ref（参考策略对数概率）**：参考策略 π_ref 下的对数概率，作为正则化
- **reward（奖励）**：由 reward function 给出的 advantage 信号

### 4.2 数学公式

**Trajectory Balance Loss：**

```
avg_logpf = mean(log_pf)                    # 对 response token 求均值
avg_logp_ref = mean(logp_ref)               # 参考策略的均值
seq_log_reward = mean(reward)               # token-level reward 的序列均值

delta = log_z + avg_logpf - 15 * seq_log_reward - avg_logp_ref

# Importance sampling weight
log_w = sum(logpf - logpf_old)             # 每个 trajectory 的 log importance weight
importance_weight = exp(log_w).detach()
clip_importance_weight = clamp(importance_weight, 1-ε, 1+ε)

# Weighted MSE loss
tb_loss = mean(importance_weight * delta^2)
```

### 4.3 代码实现

**文件：** `verl/workers/actor/dp_actor.py` → `compute_flowrl_objective()`

```python
def compute_flowrl_objective(self, logpf, logf_ref, logpf_old,
                              log_z, reward, response_mask, clip_ratio):
    log_z = log_z.squeeze(-1)                           # (B,)
    avg_logpf = masked_mean(logpf, response_mask, axis=1)
    avg_logp_ref = masked_mean(logf_ref, response_mask, axis=1)
    seq_log_reward = masked_mean(reward, response_mask, axis=1)

    # TB 残差
    delta = log_z + avg_logpf - 15 * seq_log_reward - avg_logp_ref

    # Importance sampling weight（用于离线数据修正）
    log_w = masked_sum(logpf - logpf_old, response_mask, axis=1)
    importance_weight = clamp(exp(log_w).detach(), 1-clip_ratio, 1+clip_ratio)

    # 加权 MSE
    weighted_losses = importance_weight * (delta ** 2)
    avg_loss = mean(weighted_losses)
    return avg_loss, loss_term_dict
```

**`ProjZModule` 的 forward 流程（`dp_actor.py` → `_forward_micro_batch`）：**

```
1. 模型前向传播，获取 hidden_states
2. 取最后一个非 pad token 的 hidden state → avg_hidden
3. log_z = proj_z(avg_hidden)  # 小 MLP 预测 log partition function
```

### 4.4 配置激活方式

```yaml
actor_rollout_ref:
  actor:
    loss_cal: "flowrl"         # 启用 FlowRL
    clip_ratio: 0.1            # importance weight 的裁剪范围
```

### 4.5 关键指标

| 指标 | 含义 |
|------|------|
| `actor/logpf` | 当前策略对数前向概率均值 |
| `actor/logp_ref` | 参考策略对数概率均值 |
| `actor/log_z` | 对数配分函数均值 |
| `actor/log_reward` | token-level reward 的均值 |
| `actor/tb_loss` | Trajectory Balance 损失 |
| `actor/pos_high_ratio_frac` | reward>0 且 ratio>1+ε 的 token 占比 |
| `actor/pos_low_ratio_frac` | reward>0 且 ratio<1-ε 的 token 占比 |
| `actor/neg_high_ratio_frac` | reward<0 且 ratio>1+ε 的 token 占比 |
| `actor/neg_low_ratio_frac` | reward<0 且 ratio<1-ε 的 token 占比 |

---

## 5. SPPO (Self-Play Preference Optimization)

### 5.1 原理

SPPO 是一种 **Critic-Free、自博弈** 的对齐方法。核心思想是将 RLHF 的 reward maximization 转化为一个简单的回归问题：

- 对每个 prompt 生成 N 个 response
- 使用 softmean 将 response 级别的 reward 转换为 **preference score**
- 训练策略使 `log(p_θ(a|s) / p_old(a|s))` 逼近 `η * preference_score`

### 5.2 数学公式

**SoftMean 偏好分数计算：**

```
s_i = sum(token_level_rewards_i)           # 第 i 个 response 的标量总奖励

SoftMean(s) = (1/β) * log( (1/N) * Σ exp(β * s_j) )  # β > 0 时
SoftMean(s) = mean(s)                                   # β = 0 时（退化为算术平均）

preference_i = s_i - SoftMean(s)           # 零中心化的偏好分数
```

**SPPO Loss：**

```
log_ratios_i = Σ_t log(π_θ(a_t|s_t)) - Σ_t log(π_old(a_t|s_t))  # 序列级别的 log ratio
loss_i = (log_ratios_i - η * preference_i)^2
L_SPPO = mean(loss_i)
```

### 5.3 代码实现

**文件：** `recipe/sppo/dp_actor.py` → `compute_sppo_loss()`

```python
def compute_sppo_loss(old_log_prob, log_prob, rewards, response_mask, eta, loss_agg_mode):
    # 序列级别的 log ratio（对该序列所有有效 token 求和）
    log_prob_sum = (log_prob * response_mask).sum(dim=1)        # (bs,)
    old_log_prob_sum = (old_log_prob * response_mask).sum(dim=1)
    log_ratios = log_prob_sum - old_log_prob_sum

    # SPPO 回归目标
    scaled_rewards = eta * rewards                              # η * preference
    loss_vec = (log_ratios - scaled_rewards) ** 2               # MSE

    loss = masked_mean(loss_vec, sample_mask)
    return loss, log_ratios, scaled_rewards
```

**训练器：** `recipe/sppo/sppo_ray_trainer.py` → `RaySPPOTrainer`

- 不依赖 Critic（`self.use_critic = False`）
- Advantage 计算简化为 `compute_advantage(batch, beta)` → SoftMean 偏好分数
- Actor 更新时使用 `compute_sppo_loss` 而非 `compute_policy_loss`

### 5.4 配置激活方式

SPPO 是独立的 recipe，通过专门的入口运行：

```bash
python -m recipe.sppo.main_sppo
```

关键配置：

```yaml
algorithm:
  sppo_eta: 1.0        # η：reward 放大系数

actor_rollout_ref:
  rollout:
    n: 4               # 每个 prompt 采样 N 个 response
  actor:
    sppo_eta: 1.0      # Actor 侧的 η 参数
```

### 5.5 关键指标

| 指标 | 含义 |
|------|------|
| `actor/loss` | SPPO MSE 损失 |
| `actor/log_ratio_mean` | `log(p_θ / p_ref)` 的序列均值 |
| `actor/preference_mean` | 偏好分数（`η * preference`）的均值 |

---

## 6. ReMax (Reward Maximization)

### 6.1 原理

ReMax 是一种 **Critic-Free** 的方法，发表于论文 [ReMax: A Simple, Effective, and Efficient Method for Aligning Large Language Models](https://arxiv.org/abs/2310.10505)。

**核心思想**：用 **greedy decoding 得到的 reward 作为 baseline**，取代 Critic 网络估计的 value：

```
Advantage = cumulative_reward - reward_baseline
```

其中 `reward_baseline` 是在相同 prompt 上使用 greedy（do_sample=False）生成的响应的 reward。因为 greedy 解码代表模型当前认为"最好"的输出，用它作为 baseline 可以有效地减少方差而不需要训练一个单独的 Critic。

### 6.2 数学公式

```
returns_i = cumsum(reverse(token_level_rewards_i))  # 反向累积和
advantages_i = returns_i - reward_baseline_i        # 减去 baseline
```

### 6.3 代码实现

**Advantage 计算（`core_algos.py` → `compute_remax_outcome_advantage`）：**

```python
def compute_remax_outcome_advantage(token_level_rewards, reward_baselines, response_mask):
    with torch.no_grad():
        # 反向累积和得到 returns
        returns = (token_level_rewards * response_mask).flip([-1]).cumsum(-1).flip([-1])
        # 减去 baseline（greedy 解码的 reward）
        advantages = returns - reward_baselines.unsqueeze(-1) * response_mask
    return advantages, returns
```

**训练流程（`ray_trainer.py`）：**

```
1. 正常生成 N 个 response（do_sample=True）
2. 对同一个 prompt 生成 greedy baseline（do_sample=False）
3. 计算 greedy baseline 的 reward → reward_baselines
4. advantage = returns - reward_baselines
5. 使用标准 PPO loss 更新 Actor
```

### 6.4 配置激活方式

```yaml
algorithm:
  adv_estimator: "remax"  # 启用 ReMax
```

### 6.5 特点

- **不需要 Critic**：节省约 50% 的模型参数和显存
- **需要额外生成**：每个 step 需要两次生成（正常采样 + greedy baseline），计时指标 `timing_s/gen_max` 专门统计 greedy baseline 生成的耗时
- **适用于 Outcome Reward**：通常与仅有序列级别 reward 的任务配合

---

## 7. dNPO (Dynamic Negative Preference Optimization)

### 7.1 原理

dNPO 是一种 **数据过滤 + 多批次累积** 的训练策略。核心特点：

- **在线数据过滤**：在生成阶段实时评估每个 prompt-response 对的质量，保留"合适的"样本（既不太难也不太简单）
- **多批次累积**：通过多次生成累积足够的有效样本（`num_gen_batches`），直到满足 `train_batch_size` 要求
- **难度自适应**：训练不同阶段使用不同的过滤阈值

### 7.2 训练流程

**文件：** `verl/trainer/ppo/dnpo_ray_trainer.py` → `RayDNPOTrainer`

```
for step in range(total_training_steps):
    num_gen_batches = 0
    while num_prompt_in_batch < prompt_bsz:
        batch = next(dataloader)
        num_gen_batches += 1
        gen_output = actor_rollout.generate_sequences(batch)

        # ReMax: 生成 greedy baseline
        if adv_estimator == REMAX:
            baseline_output = actor_rollout.generate_sequences(batch, do_sample=False)
            reward_baselines = reward_fn(baseline_output)

        reward = reward_fn(gen_output)

        # 过滤：按 reward 的"通过率"筛选 prompt
        kept_uids = filter_by_difficulty(reward, global_steps, total_steps)
        # 早期（前 1/3）：保留 0 < pass_count < 8 或单个 response
        # 中期（1/3-2/3）：保留 1 < pass_count < 7
        # 后期（后 1/3）：保留 2 < pass_count < 6

        batch = accumulate_filtered(batch, kept_uids)
        if num_prompt_in_batch >= prompt_bsz:
            break

    # 标准 PPO 更新（使用累积的 batch）
    compute_reference_logprob(batch)
    compute_advantages(batch)
    update_actor(batch)
    update_critic(batch)
```

### 7.3 配置激活方式

```yaml
# 使用专门的 dNPO 入口
# python -m verl.trainer.main_dnpo

algorithm:
  adv_estimator: "remax"      # dNPO 通常配合 ReMax 使用
  filter_groups:
    enable: true               # 启用在线过滤
    metric: "seq_final_reward"  # 过滤依据的指标
    max_num_gen_batches: 10    # 每步最多生成多少批
```

### 7.4 关键指标

| 指标 | 含义 |
|------|------|
| `train/num_gen_batches` | 当前 step 实际生成的批次数 |

---

## 8. GRPO (Group Relative Policy Optimization)

### 8.1 原理

GRPO 是 DeepSeek 提出的一种 Critic-Free 方法。核心思想：对同一个 prompt 生成 N 个 response，在组内（同 prompt 的不同 response）做相对比较：

```
Advantage_i = (score_i - mean(score_group)) / std(score_group)
```

### 8.2 数学公式

```
scores = sum(token_level_rewards, dim=-1)      # 序列级标量分数

# 按 prompt (uid) 分组：
for each prompt group:
    mean_group = mean(scores_in_group)
    std_group = std(scores_in_group)

    for each response in group:
        advantage = (score - mean_group) / (std_group + ε)  # 原始 GRPO
        advantage = score - mean_group                        # Dr.GRPO (不除 std)
```

### 8.3 代码实现

**文件：** `verl/trainer/ppo/core_algos.py` → `compute_grpo_outcome_advantage()`

```python
def compute_grpo_outcome_advantage(token_level_rewards, response_mask, index, epsilon, norm_adv_by_std_in_grpo):
    scores = token_level_rewards.sum(dim=-1)

    # 分组计算每组的 mean/std
    for each uid group:
        if len(group) == 1:
            mean, std = 0.0, 1.0   # 单个 sample 无法标准化
        else:
            mean = torch.mean(group)
            std = torch.std(group)

        # 标准化
        if norm_adv_by_std_in_grpo:
            score = (score - mean) / (std + ε)   # 原始 GRPO
        else:
            score = score - mean                  # Dr.GRPO

    advantages = scores.unsqueeze(-1) * response_mask
    return advantages, advantages
```

### 8.4 配置激活方式

```yaml
algorithm:
  adv_estimator: "grpo"
  norm_adv_by_std_in_grpo: true  # true=GRPO, false=Dr.GRPO

actor_rollout_ref:
  rollout:
    n: 8  # 每个 prompt 生成 N 个 response（建议 >= 4）
```

### 8.5 特点

- **不需要 Critic**
- 需要 per-prompt 生成多个 response（N >= 2 才有效）
- 通过组内标准化，天然消除了不同 prompt 的难度差异

---

## 9. RLOO (REINFORCE Leave-One-Out)

### 9.1 原理

RLOO 发表于 [Back to Basics: Revisiting REINFORCE Style Optimization for Learning from Human Feedback in LLMs](https://arxiv.org/abs/2402.14740)。

核心思想：对同一 prompt 的 N 个 response，用 **留一法** 估计 baseline：

```
baseline_i = mean(scores_excluding_i) = (sum(scores) - score_i) / (N-1)
advantage_i = score_i - baseline_i = (N/(N-1)) * score_i - (N/(N-1)) * mean(scores)
```

### 9.2 数学公式

```
advantage_i = score_i * N/(N-1) - mean_all * N/(N-1)
```

### 9.3 代码实现

**文件：** `verl/trainer/ppo/core_algos.py` → `compute_rloo_outcome_advantage()`

```python
def compute_rloo_outcome_advantage(token_level_rewards, response_mask, index, epsilon):
    scores = token_level_rewards.sum(dim=-1)

    for each group:
        response_num = len(group)
        if response_num > 1:
            # 留一法 baseline
            advantage = score * N/(N-1) - mean_all * N/(N-1)

    advantages = scores.unsqueeze(-1) * response_mask
    return advantages, advantages
```

### 9.4 配置激活方式

```yaml
algorithm:
  adv_estimator: "rloo"

actor_rollout_ref:
  rollout:
    n: 4  # >= 2
```

---

## 10. REINFORCE++ / REINFORCE++-Baseline

### 10.1 原理

REINFORCE++ 发表于 [Revisiting REINFORCE Style Optimization](https://arxiv.org/abs/2501.03262)，是一种极简的 Critic-Free 方法。

**REINFORCE++**：用折扣累积 reward 作为 return，并对 return 做 whiten 标准化得到 advantage。

**REINFORCE++-Baseline**：在 REINFORCE++ 的基础上引入分组 baseline（同 prompt 的 N 个 response 的均值）。

### 10.2 数学公式

**REINFORCE++：**

```
returns[t] = reward[t] + γ * returns[t+1]         # 反向折扣累积
returns[t] = returns[t] * response_mask[t]         # 在 EOS 后重置
advantages = masked_whiten(returns, response_mask)  # whiten 标准化
```

**REINFORCE++-Baseline：**

```
scores = sum(token_level_rewards)
for each prompt group:
    baseline = mean(scores_in_group)
    advantage = score - baseline
advantages = masked_whiten(advantages_broadcasted, response_mask)
```

### 10.3 代码实现

**文件：** `verl/trainer/ppo/core_algos.py`

```python
def compute_reinforce_plus_plus_outcome_advantage(token_level_rewards, response_mask, gamma):
    returns = torch.zeros_like(token_level_rewards)
    running_return = 0
    for t in reversed(range(response_length)):
        running_return = token_level_rewards[:, t] + gamma * running_return
        returns[:, t] = running_return
        running_return = running_return * response_mask[:, t]  # EOS 后重置
    advantages = masked_whiten(returns, response_mask)
    return advantages, returns

def compute_reinforce_plus_plus_baseline_outcome_advantage(token_level_rewards, response_mask, index):
    scores = token_level_rewards.sum(dim=-1)
    # 分组 baseline
    for each group:
        score[i] = score[i] - mean(group)
    # 广播到 token 维度并 whiten
    scores = scores.unsqueeze(-1).tile([1, response_length]) * response_mask
    scores = masked_whiten(scores, response_mask) * response_mask
    return scores, scores
```

### 10.4 配置激活方式

```yaml
algorithm:
  adv_estimator: "reinforce_plus_plus"           # 或 "reinforce_plus_plus_baseline"
  gamma: 1.0

actor_rollout_ref:
  rollout:
    n: 4
```

---

## 11. GDPO (Group Dimension Preference Optimization)

### 11.1 原理

GDPO 是一种维度感知的 Critic-Free 方法。与 GRPO/GDPO 不同，GDPO 处理 **多维 reward** 的场景（每个 response 有多个评分维度，如 relevance、safety、helpfulness 等）。

核心思想：
- 在组内（同 prompt 的不同 response）按**每个维度**做标准化
- 对标准化后的多维向量求和得到一个标量
- 支持维度重要性加权（`dim_weights`）

### 11.2 数学公式

```
# token_level_rewards: 每个 sample 的 L 维评分向量（L 个评分维度）
for each prompt group:
    # 按维度标准化：(rollout_n, L)
    mu = mean(group_scores, dim=0)          # (L,) 每维的组内均值
    std = std(group_scores, dim=0)          # (L,) 每维的组内标准差
    group_norm = (group - mu) / (std + ε)   # 或 (group - mu)（不除 std）

    # 施加维度权重
    if dim_weights is not None:
        group_norm = group_norm * dim_weights  # (L,) 每维的重要性权重

    # 求和得到标量
    advantage_scalar = sum(group_norm, dim=-1)  # (rollout_n,)

# 广播到 token 维度
advantages = advantage_scalar.unsqueeze(-1) * response_mask
```

### 11.3 代码实现

**文件：** `verl/trainer/ppo/core_algos.py` → `compute_gdpo_outcome_advantage()`

```python
def compute_gdpo_outcome_advantage(token_level_rewards, response_mask, index,
                                    epsilon, norm_adv_by_std_in_grpo, dim_weights):
    # token_level_rewards: ragged 2D list，每个样本是一段长度可变的分数向量
    for each group:
        group = stack(scores[inds])                    # (rollout_n, L)
        mu = group.mean(dim=0)                         # (L,)
        sd = group.std(dim=0, unbiased=False)          # (L,)

        if norm_adv_by_std_in_grpo:
            group_norm = (group - mu) / (sd + ε)
        else:
            group_norm = group - mu

        if dim_weights is not None:
            group_norm = group_norm * dim_weights

        group_sum = group_norm.sum(dim=-1)             # (rollout_n,)

    advantages = group_sum.unsqueeze(-1) * response_mask
    advantages = masked_whiten(advantages, response_mask) * response_mask
    return advantages, advantages
```

### 11.4 配置激活方式

```yaml
algorithm:
  adv_estimator: "gdpo"
  norm_adv_by_std_in_grpo: true

actor_rollout_ref:
  rollout:
    n: 8
```

### 11.5 特点

- **需要多维 reward 信号**：每个 response 的 reward 是一个 L 维向量而非标量
- 支持 `dim_weights` 参数对不同评分维度加权
- 通过 whiten 进一步稳定训练

---

## 12. GAE (Generalized Advantage Estimation)

### 12.1 原理

GAE 是这个项目中唯一需要 Critic（价值网络）的 advantage 估计方法，是标准 PPO 的默认选择。它通过 TD-λ 在 bias-variance 之间做权衡。

### 12.2 数学公式

**TD 残差：**

```
δ_t = r_t + γ * V(s_{t+1}) - V(s_t)
```

**GAE Advantage（λ-weighted 累积 TD 残差）：**

```
A_t^GAE(γ, λ) = Σ_{l=0}^{∞} (γλ)^l * δ_{t+l}
              = δ_t + γλ * δ_{t+1} + (γλ)^2 * δ_{t+2} + ...
```

**Returns：**

```
G_t = A_t + V(s_t)
```

**Whiten 标准化：** 最终 advantage 会经过 masked_whiten（去均值，除以标准差）。

### 12.3 代码实现

**文件：** `verl/trainer/ppo/core_algos.py` → `compute_gae_advantage_return()`

```python
def compute_gae_advantage_return(token_level_rewards, values, response_mask, gamma, lam):
    with torch.no_grad():
        lastgaelam = 0
        advantages_reversed = []
        for t in reversed(range(gen_len)):
            nextvalues = values[:, t+1] if t < gen_len-1 else 0.0
            delta = token_level_rewards[:, t] + gamma * nextvalues - values[:, t]
            lastgaelam = delta + gamma * lam * lastgaelam
            advantages_reversed.append(lastgaelam)
        advantages = torch.stack(advantages_reversed[::-1], dim=1)
        returns = advantages + values
        advantages = masked_whiten(advantages, response_mask)
    return advantages, returns
```

### 12.4 配置激活方式

```yaml
algorithm:
  adv_estimator: "gae"
  gamma: 1.0    # 折扣因子
  lam: 0.95     # GAE λ 参数
```

### 12.5 特点

- **需要训练 Critic**：额外增加约 50% 的模型参数
- 通过 λ 参数控制 bias-variance 权衡：λ=0 → TD(0) 低方差高偏差；λ=1 → Monte Carlo 高方差低偏差
- 标配 `actor/critic` 分离架构

---

## 13. 算法对比总结

### 13.1 是否需要 Critic

| 算法 | 需要 Critic | 额外生成 | 适用场景 |
|------|:----------:|:------:|----------|
| **PPO + GAE** | ✅ 是 | ❌ | 标准方法，最稳定 |
| **BAPO** | ✅ 是（同上） | ❌ | PPO 的改进版，自动调 clip |
| **GRPO** | ❌ 否 | ❌ | 需 per-prompt 多样本 |
| **ReMax** | ❌ 否 | ✅ greedy baseline | 简洁高效，适合 outcome reward |
| **dNPO** | 取决于 adv_estimator | ❌ | 在线数据过滤，困难样本自适应 |
| **RLOO** | ❌ 否 | ❌ | REINFORCE 风格的留一法 |
| **REINFORCE++** | ❌ 否 | ❌ | 极简方法，折扣累积 + whiten |
| **REINFORCE++-Baseline** | ❌ 否 | ❌ | 同上 + 分组 baseline |
| **GDPO** | ❌ 否 | ❌ | 多维 reward 评分 |
| **FlowRL** | 不使用标准 Critic | ❌ | GFlowNet 轨迹平衡，需要 log_z 网络 |
| **SPPO** | ❌ 否 | ❌ | 自博弈偏好优化，回归范式 |

### 13.2 损失函数对比

| 算法 | 损失类型 | 核心公式 |
|------|----------|----------|
| PPO | Clipped Surrogate + Dual-Clip | `min(max(-ratio*A, -clip(ratio)*A), -c*A)` |
| BAPO | 同 PPO，clip bound 动态调整 | 同上，`cliprange` 由 BAPO 迭代确定 |
| FlowRL | Trajectory Balance MSE | `importance_weight * (log_z + logpf - 15*reward - logp_ref)^2` |
| SPPO | MSE Regression | `(log_ratio - η*preference)^2` |
| GRPO/ReMax/RLOO/REINFORCE++/GDPO | 同 PPO | 使用 `compute_policy_loss`，仅在 advantage 计算上不同 |

### 13.3 组合矩阵

Advantage Estimator 和 Policy Loss Type 可以 **自由组合**（理论上所有 adv_estimator × 所有 loss_cal）：

|  | PPO Loss | BAPO Loss | FlowRL Loss | SPPO Loss |
|---|---|---|---|---|
| **GAE** | ✅ 经典组合 | ✅ 可用于 BAPO | ✅ | N/A |
| **GRPO** | ✅ DeepSeek-R1 | ✅ | ✅ | N/A |
| **ReMax** | ✅ | ✅ dNPO 默认 | ✅ | N/A |
| **RLOO** | ✅ | ✅ | ✅ | N/A |
| **REINFORCE++** | ✅ | ✅ | ✅ | N/A |
| **GDPO** | ✅ | ✅ | ✅ | N/A |
| **SPPO** | N/A（独立 recipe） | N/A | N/A | ✅ 独立用法 |

> 注：SPPO 作为独立 recipe 运行，有自己的 trainer 和 loss 函数，不与上述 adv_estimator 组合使用。

### 13.4 文件索引

| 算法 | 核心文件 |
|------|----------|
| PPO | `verl/trainer/ppo/core_algos.py` (`compute_policy_loss`, `compute_value_loss`) |
| BAPO | `verl/trainer/ppo/policy_loss.py` (`compute_policy_loss_bapo`) |
|       | `verl/trainer/ppo/ray_trainer_bapo.py` (`RayBAPOTrainer`) |
| FlowRL | `verl/workers/actor/dp_actor.py` (`compute_flowrl_objective`, `_forward_micro_batch` with `return_log_z`) |
| SPPO | `recipe/sppo/dp_actor.py` (`compute_sppo_loss`, `DataParallelSPPOActor`) |
|       | `recipe/sppo/sppo_ray_trainer.py` (`RaySPPOTrainer`) |
| ReMax | `verl/trainer/ppo/core_algos.py` (`compute_remax_outcome_advantage`) |
| dNPO | `verl/trainer/ppo/dnpo_ray_trainer.py` (`RayDNPOTrainer`) |
| GRPO | `verl/trainer/ppo/core_algos.py` (`compute_grpo_outcome_advantage`) |
| RLOO | `verl/trainer/ppo/core_algos.py` (`compute_rloo_outcome_advantage`) |
| REINFORCE++ | `verl/trainer/ppo/core_algos.py` (`compute_reinforce_plus_plus_outcome_advantage`) |
| GDPO | `verl/trainer/ppo/core_algos.py` (`compute_gdpo_outcome_advantage`) |
| GAE | `verl/trainer/ppo/core_algos.py` (`compute_gae_advantage_return`) |
| Actor Worker | `verl/workers/actor/dp_actor.py` (policy loss dispatch, FlowRL) |
| Critic Worker | `verl/workers/critic/dp_critic.py` |
| 主训练器 | `verl/trainer/ppo/ray_trainer.py` (advantage dispatch, training loop) |

---

> **参考论文：**
> - PPO: [Proximal Policy Optimization Algorithms](https://arxiv.org/abs/1707.06347)
> - Dual-Clip PPO: [Mastering atari with discrete world models](https://arxiv.org/abs/1912.09729)
> - GAE: [High-Dimensional Continuous Control Using Generalized Advantage Estimation](https://arxiv.org/abs/1506.02438)
> - ReMax: [A Simple, Effective, and Efficient Method for Aligning LLMs](https://arxiv.org/abs/2310.10505)
> - RLOO: [Back to Basics: Revisiting REINFORCE Style Optimization](https://arxiv.org/abs/2402.14740)
> - REINFORCE++: [Revisiting REINFORCE Style Optimization](https://arxiv.org/abs/2501.03262)
> - GRPO: [DeepSeek-R1](https://arxiv.org/abs/2501.12948)
> - Dr.GRPO: [Understanding R1-Zero-Like Training: A Critical Perspective](https://arxiv.org/abs/2503.20783)
> - SPPO: [Self-Play Preference Optimization for Language Model Alignment](https://arxiv.org/abs/2405.00675)
> - GFlowNet / FlowRL: [Trajectory Balance](https://arxiv.org/abs/2201.13259)
