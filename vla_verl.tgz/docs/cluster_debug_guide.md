# Ray 集群多进程调试指南

## 进程架构

```
                       HEAD_NODE (node[0])
                    ┌──────────────────────────┐
Shell 脚本 ────────→│  python3 main_ppo        │  ← Driver 进程
                    │    ray.init()            │
Port 5678 ─────────│    attach_debugpy(driver) │
                    │    TaskRunner.remote() ───│──→ Ray 调度
                    └──────────────────────────┘

                       HEAD_NODE 或 WORKER_NODE
                    ┌──────────────────────────┐
Port 5679 ─────────│  TaskRunner.run()         │  ← Ray Actor 进程
                    │    ├─ reward_fn()         │     本地调用（可打断点）
                    │    ├─ compute_advantage() │     本地调用（可打断点）
                    │    └─ actor_rollout_wg    │
                    │       .generate_sequences│──→ RPC 远程调用
                    │       .compute_log_prob │──→ RPC 远程调用
                    │       .update_actor     │──→ RPC 远程调用
                    └──────────────────────────┘

                      GPU WORKER_NODE (有 GPU)
                    ┌──────────────────────────┐
Port 5680+ ────────│  ActorRolloutRefWorker    │  ← GPU Worker (FSDP/vLLM)
                    │    ├─ generate_sequences()│     vLLM 推理
                    │    ├─ compute_log_prob()  │     Actor forward
                    │    └─ update_actor()      │     PPO 参数更新
                    └──────────────────────────┘

                      GPU WORKER_NODE (有 GPU)
                    ┌──────────────────────────┐
Port 5690+ ────────│  RefPolicy Worker         │  ← 参考模型 Worker
                    │    └─ compute_ref_log_prob│
                    └──────────────────────────┘
```

---

## 第一步：创建调试注入工具（已完成）

文件 `verl/utils/debug_cluster.py` 已创建，暴露一个入口：

```python
from verl.utils.debug_cluster import attach_debugpy
attach_debugpy("driver")        # Driver 进程
attach_debugpy("task_runner")   # TaskRunner Actor
attach_debugpy("actor_worker")  # GPU Worker
attach_debugpy("ref_worker")    # RefPolicy Worker
```

---

## 第二步：在三个关键位置注入调试代码

### 位置 ①：Driver 进程 — `verl/trainer/main_ppo.py` 的 `run_ppo()`

```python
# 在 run_ppo() 函数开头添加（line 67 之后）
def run_ppo(config) -> None:
    from verl.utils.debug_cluster import attach_debugpy
    attach_debugpy("driver")            # ← 添加这行

    if not ray.is_initialized():
        ray.init(
            runtime_env={
                "env_vars": {
                    "TOKENIZERS_PARALLELISM": "true",
                    "NCCL_DEBUG": "WARN",
                    "VLLM_LOGGING_LEVEL": "WARN",
                    # 将 DEBUGPY 环境变量传播给所有 Ray Actor/Worker
                    "DEBUGPY_ENABLE": os.environ.get("DEBUGPY_ENABLE", ""),
                    "DEBUGPY_BASE_PORT": os.environ.get("DEBUGPY_BASE_PORT", "5678"),
                    "DEBUGPY_WAIT_CLIENT": os.environ.get("DEBUGPY_WAIT_CLIENT", "1"),
                }
            },
            num_cpus=config.ray_init.num_cpus,
        )

    runner = TaskRunner.remote()
    ray.get(runner.run.remote(config))
```

> **关键**: 把 `DEBUGPY_*` 环境变量放入 `runtime_env.env_vars`，Ray 会把它们自动传播到所有通过此 driver 创建的 Actor/Worker 中。无需在每个节点手动设置。

### 位置 ②：TaskRunner Actor — `verl/trainer/main_ppo.py` 的 `TaskRunner.run()`

```python
class TaskRunner:
    def run(self, config):
        from verl.utils.debug_cluster import attach_debugpy
        attach_debugpy("task_runner")     # ← 添加这行

        from pprint import pprint
        from omegaconf import OmegaConf
        from verl.utils.fs import copy_to_local
        # ... 后续代码不变
```

### 位置 ③：GPU Worker — `verl/workers/fsdp_workers.py` 的 `ActorRolloutRefWorker.__init__()`

```python
class ActorRolloutRefWorker(Worker):
    def __init__(self, config: DictConfig, role: str):
        super().__init__()

        from verl.utils.debug_cluster import attach_debugpy
        attach_debugpy(f"{role}_worker")   # ← 添加这行
        # role = "actor_rollout" 或 "ref"
        # ... 后续代码不变
```

---

## 第三步：VS Code 多目标调试配置

在项目根目录创建 `.vscode/launch.json`：

```json
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "Driver (HEAD_NODE)",
            "type": "python",
            "request": "attach",
            "connect": { "host": "HEAD_NODE_IP", "port": 5678 },
            "pathMappings": [
                { "localRoot": "${workspaceFolder}", "remoteRoot": "/home/beijin.zhou/mlm-verl" }
            ],
            "justMyCode": false
        },
        {
            "name": "TaskRunner Actor",
            "type": "python",
            "request": "attach",
            "connect": { "host": "HEAD_NODE_IP", "port": 5679 },
            "pathMappings": [
                { "localRoot": "${workspaceFolder}", "remoteRoot": "/home/beijin.zhou/mlm-verl" }
            ],
            "justMyCode": false
        },
        {
            "name": "GPU Worker (rank 0)",
            "type": "python",
            "request": "attach",
            "connect": { "host": "GPU_NODE_IP", "port": 5682 },
            "pathMappings": [
                { "localRoot": "${workspaceFolder}", "remoteRoot": "/home/beijin.zhou/mlm-verl" }
            ],
            "justMyCode": false
        },
        {
            "name": "ALL - Compound",
            "type": "python",
            "request": "attach",
            "connect": { "host": "HEAD_NODE_IP", "port": 5678 },
            "pathMappings": [
                { "localRoot": "${workspaceFolder}", "remoteRoot": "/home/beijin.zhou/mlm-verl" }
            ],
            "justMyCode": false,
            "processName": "python"
        }
    ],
    "compounds": [
        {
            "name": "ALL - Driver + TaskRunner + GPU Workers",
            "configurations": [
                "Driver (HEAD_NODE)",
                "TaskRunner Actor",
                "GPU Worker (rank 0)"
            ],
            "stopAll": true
        }
    ]
}
```

> 把 `HEAD_NODE_IP` 和 `GPU_NODE_IP` 替换为实际的节点 IP。可通过 `cat /etc/volcano/all.host` 查看集群节点列表。

---

## 第四步：启动调试

### 4.1 在 Shell 脚本中设置环境变量

修改 `user_scripts/no_entry/cot_rl/niovl3_06B_cot-rl_...sh`，在 python 启动行**之前**添加：

```bash
# ========== 调试模式 ==========
export DEBUGPY_ENABLE=1                  # 启用 debugpy
export DEBUGPY_BASE_PORT=5678           # 基础端口
export DEBUGPY_WAIT_CLIENT=1            # 等待 VS Code attach 后再执行
# 如果不想等待（让程序跑起来再 attach），注释掉上一行
# export DEBUGPY_WAIT_CLIENT=0
# ==============================
```

### 4.2 端口分配和网络确认

| 进程 | 默认端口 | 运行节点 |
|------|---------|---------|
| Driver | 5678 | HEAD_NODE |
| TaskRunner | 5679 | 可能 HEAD_NODE 或 WORKER_NODE |
| Actor Worker (RANK=0) | 5682 | GPU_NODE |
| Ref Worker | 5692 | GPU_NODE |

确认 VS Code 机器到集群节点的端口可达：
```bash
# 在 VS Code 所在机器上测试
nc -zv HEAD_NODE_IP 5678
nc -zv GPU_NODE_IP 5682
```

如果端口不通（如跨机房/防火墙），可以用 SSH 隧道：
```bash
# 在 VS Code 终端建立隧道
ssh -L 5678:HEAD_NODE_IP:5678 -L 5679:HEAD_NODE_IP:5679 -L 5682:GPU_NODE_IP:5682 user@跳板机
# 然后把 VS Code launch.json 中的 host 改成 127.0.0.1
```

### 4.3 操作顺序

```
1. VS Code: 在目标代码处设置断点
2. VS Code: 按 F5 启动 "ALL - Compound" 调试配置
   （VS Code 会等待 attach，此时终端显示 waiting）
3. Shell:   运行训练脚本
4. 观察:    终端依次打印:
             [DEBUGPY] role=driver listening on HEAD_NODE:5678 ...
             [DEBUGPY] role=driver waiting for client ...
             [DEBUGPY] role=driver client attached, resuming execution.
             [DEBUGPY] role=task_runner listening on ...:5679 ...
             [DEBUGPY] role=actor_worker listening on GPU_NODE:5682 ...
5. 程序在断点处暂停，开始调试
```

---

## 第五步：针对性调试场景

### 场景 A：只调试 Reward 计算（不需要 GPU Worker）

```bash
# 设置环境变量，但只调试不等待
export DEBUGPY_ENABLE=1
export DEBUGPY_WAIT_CLIENT=0   # ← 不等待，程序正常运行

# 在 NaiveRewardManager.__call__() 中打断点
# 文件: verl/workers/reward_manager/naive.py:77
# score = self.compute_score(...)

# 或在 TaskRunner.run() 中 compute_reward() 处打断点
# 文件: verl/trainer/ppo/ray_trainer.py:979
```

由于 `NaiveRewardManager.__call__()` 和 `compute_reward()` 都在 **TaskRunner 进程中本地运行**（不是 RPC），断点可以直接生效，跟你调试普通 Python 脚本一样。

### 场景 B：调试 Advantage 计算

```bash
# 同样本地执行，直接打断点
# 文件: verl/trainer/ppo/ray_trainer.py:1041
# batch = compute_advantage(batch, ...)
```

### 场景 C：调试 GPU Worker 上的模型 forward

需要在 `ActorRolloutRefWorker` 内部打断点：

```bash
# 确保 DEBUGPY_WAIT_CLIENT=1，等待 attach 到 GPU worker
export DEBUGPY_ENABLE=1
export DEBUGPY_BASE_PORT=5678
export DEBUGPY_WAIT_CLIENT=1

# 启动后等待终端打印 GPU worker 的监听端口，然后 attach
```

---

## 第六步：不等待模式（先跑后 attach）

如果不想让程序卡住等你 attach，可以设置 `DEBUGPY_WAIT_CLIENT=0`：

```bash
export DEBUGPY_ENABLE=1
export DEBUGPY_WAIT_CLIENT=0   # 程序正常跑，不等
```

程序启动后打印端口信息但继续执行。你可以随时在 VS Code 中 attach 到对应端口，在**下次命中时**暂停在断点处。

---

## 第七步：清理

调试完成后，注释掉 Shell 脚本中的 `DEBUGPY_*` 环境变量，或设 `DEBUGPY_ENABLE=0`，即可完全关闭调试注入，不影响正常训练。
