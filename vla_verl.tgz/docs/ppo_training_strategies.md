# VERL PPO 训练策略与技巧详解

> 本文档梳理框架中影响训练效果的各种细致策略，包括动态调度、自适应参数、正则化技巧、batch 平衡等。

---

## 一、温度调度 (Temperature Scheduling)

### 1.1 动态温度调度器

**文件**: `verl/workers/temperature_scheduler.py`  
**类**: `TemperatureScheduler`

根据实测熵动态调节采样温度，防止生成过于确定或过于发散：

```python
# 核心更新公式
factor = np.log(vocab_size) + np.log(np.log(vocab_size))
new_temperature = current_temperature * (target_entropy / current_entropy) ** factor
```

**两阶段工作流程**：

1. **初始化阶段**（前 `init_steps` 步）：累积熵值，计算 `target_entropy` 基线
2. **调节阶段**：根据当前熵与目标的比值调整温度。熵过高 → 降温；熵过低 → 升温

**熵退火 (Entropy Annealing)**：
- 启用 `enable_annealing=True` 后，在 `annealing_step` 之后 `target_entropy` 按 **cosine decay** 向 0 衰减
- 让模型从探索逐步过渡到利用

> **注意**: 温度调度器仅在 `dynamic_fsdp_workers.py` 中使用。标准 `fsdp_workers.py` 使用固定温度。

---

## 二、KL 散度控制

### 2.1 Adaptive KL Controller（in-reward KL 惩罚）

**文件**: `verl/trainer/ppo/core_algos.py` (行 29–44)  
**类**: `AdaptiveKLController`  
**参考论文**: https://arxiv.org/pdf/1909.08593.pdf

自适应调节 KL 惩罚系数 β：

```python
proportional_error = clip(current_kl / target_kl - 1, -0.2, 0.2)
mult = 1 + proportional_error * n_steps / horizon
kl_coef *= mult
```

- KL 过大 → 增大 β，加强对策略变化的惩罚
- KL 过小 → 减小 β，允许更大的策略更新

### 2.2 Fixed KL Controller

**文件**: `verl/trainer/ppo/core_algos.py` (行 47–54)  
**类**: `FixedKLController`

保持恒定的 KL 系数，不做自适应调整。

### 2.3 KL 惩罚类型（5 种）

**文件**: `verl/trainer/ppo/core_algos.py` (行 537–569)  
**函数**: `kl_penalty(logprob, ref_logprob, kl_penalty)`

| 类型 | 公式 | 说明 |
|------|------|------|
| `"kl"` | `logp - ref_logp` | 标准前向 KL |
| `"abs"` | `|logp - ref_logp|` | 绝对值 KL |
| `"mse"` | `0.5 * (logp - ref_logp)^2` | 均方误差形式 |
| `"low_var_kl"` | `clamp(ref_logp - logp - ratio + 1, -10, 10)` | Schulman 低方差估计器 |
| `"full"` | — | 未实现 |

### 2.4 KL Loss（loss 中的 KL 正则）

**文件**: `verl/workers/actor/dp_actor.py` (行 455–463)

当 `use_kl_loss=True`，在 policy loss 中额外加入 KL 散度项：

```python
kld = kl_penalty(log_prob, ref_log_prob, kl_loss_type)
policy_loss = pg_loss + kl_loss_coef * kl_loss
```

- `kl_loss_coef` 默认 0.001
- `kl_loss_type` 默认 `"low_var_kl"`
- 这与 in-reward KL 惩罚互斥或叠加均可配置

### 2.5 In-Reward KL Penalty

**文件**: `verl/trainer/ppo/ray_trainer.py` (行 149–179)  
**函数**: `apply_kl_penalty()`

在 reward 层面扣除 KL 散度：

```python
token_level_rewards = token_level_scores - beta * kld
```

其中 `beta` 由 `AdaptiveKLController` / `FixedKLController` 管理。

---

## 三、学习率调度

**文件**: `verl/utils/torch_functional.py`

支持三种 LR schedule：

### 3.1 Cosine Schedule with Warmup

```
lr = linear_warmup → cosine_decay → min_lr_ratio
```

### 3.2 Constant Schedule with Warmup

```
lr = linear_warmup → constant
```

### 3.3 Warmup-Stable-Decay (WSD)

```
lr = linear_warmup → stable (constant) → cosine_decay
```

- `stable_ratio` 控制稳定阶段占比（相对剩余步数）
- 三阶段设计：先预热，再稳定训练，最后衰减

### 3.4 Total Training Steps 注入

**文件**: `verl/trainer/ppo/ray_trainer.py` (行 522–527)

`total_training_steps` 在运行时注入 optimizer config，保证 LR scheduler 精确知道训练总步数。

---

## 四、PPO 裁剪策略

### 4.1 Standard PPO Clipped Objective

**文件**: `verl/trainer/ppo/core_algos.py` (行 422–489)  
**函数**: `compute_policy_loss()`

```python
ratio = exp(log_prob - old_log_prob)
pg_losses1 = -advantages * ratio                        # 无裁剪
pg_losses2 = -advantages * clip(ratio, 1-ε_low, 1+ε_high)  # 裁剪版
clip_pg = max(pg_losses1, pg_losses2)                   # 悲观估计
```

### 4.2 非对称裁剪 (Asymmetric Clipping)

支持独立的 `clip_ratio_low` 和 `clip_ratio_high`：
- 可以限制策略恶化（低裁剪），同时保留改善空间（高裁剪）

### 4.3 Dual-Clip PPO

```python
# 当 advantage < 0 时，加下界保护
pg_losses3 = -advantages * clip_ratio_c          # c = 3.0
final_loss = min(clip_pg, pg_losses3)             # 仅在 adv < 0 时生效
```

- 参考: https://arxiv.org/pdf/1912.09729
- 防止负 advantage 时 loss 过大导致训练不稳定

### 4.4 BAPO 动态裁剪

**文件**: `verl/trainer/ppo/policy_loss.py` (行 61–176)  
**函数**: `compute_policy_loss_bapo()`

**动态调整 PPO 裁剪边界**以满足正/负 advantage 贡献比目标：

```
while pos_neg_ratio < target_ratio:
    先放宽 clip_lower → 再放宽 clip_upper
    直到达到目标 ratio 或达到最大边界
```

- 记录搜索轨迹（`clip_low`, `clip_high`, `pos_neg_ratio`）用于日志

---

## 五、Advantage 归一化 / 白化

### 5.1 `masked_whiten`

**文件**: `verl/utils/torch_functional.py` (行 146–152)

```python
masked_whiten(values, mask) = (values - mean_mask) / sqrt(var_mask + 1e-8)
```

- 仅在有效 token（mask=1）上计算均值/方差
- GAE、REINFORCE++、RLOO 等方法均使用此函数对 advantage 做白化

### 5.2 GRPO 组归一化

**文件**: `verl/trainer/ppo/core_algos.py` (行 181–233)

同一 prompt 的多个回答归为一组，组内做归一化：

```python
adv = (score - group_mean) / (group_std + epsilon)   # norm_adv_by_std_in_grpo=True
adv =  score - group_mean                             # norm_adv_by_std_in_grpo=False (Dr. GRPO)
```

- 单样本组：adv = 0（均值 = 0, std = 1）

### 5.3 GDPO 多维度组归一化

**文件**: `verl/trainer/ppo/core_algos.py` (行 112–177)

对每个回答的多个 reward 维度分别做组内标准化，再求和为标量 adv。

---

## 六、Batch 平衡与动态 Batching

### 6.1 序列长度平衡（Karmarkar-Karp 算法）

**文件**: `verl/utils/seqlen_balancing.py` (行 23–174)  
**函数**: `get_seqlen_balanced_partitions()`

使用 **Karmarkar-Karp 最大差分法** 将序列分配到各 DP rank，使每个 rank 的总 token 数尽量相等：

```python
# ray_trainer.py 行 965
if self.config.trainer.balance_batch:
    self._balance_batch(batch, metrics=metrics)
```

- 支持 `equal_size`：保证各分区样本数严格相等
- `log_seqlen_unbalance()` 输出 min/max/mean/balanced 统计，用于监控负载均衡

### 6.2 动态 Micro-Batch 拆分

**文件**: `verl/utils/seqlen_balancing.py` (行 215–260)  
**函数**: `rearrange_micro_batches()`

当 `use_dynamic_bsz=True` 时，按 **token 总数**（而非样本数）拆分 micro-batch：

```python
# 每个 micro_batch 包含最多 max_token_len 个有效 token
micro_batches, _ = rearrange_micro_batches(batch=mini_batch, max_token_len=max_token_len)
```

- 跨 DP rank 同步 micro_batch 数量（`all_reduce(MAX)`）
- loss 按动态 batch size 缩放：`loss = policy_loss * (len(data) / ppo_mini_batch_size)`

### 6.3 梯度累积

```python
self.gradient_accumulation = ppo_mini_batch_size // ppo_micro_batch_size_per_gpu
loss = policy_loss / self.gradient_accumulation
loss.backward()
```

---

## 七、梯度裁剪与安全检查

**文件**: `verl/workers/actor/dp_actor.py` (行 261–277)  
**方法**: `_optimizer_step()`

```python
# 1. 梯度裁剪
if grad_norm is finite:
    clip_grad_norm_(max_norm=grad_clip)  # 默认 grad_clip=1.0
    optimizer.step()
else:
    # 2. 安全检查：跳过不安全的梯度
    optimizer.zero_grad()  # 丢弃 NaN/Inf 梯度
```

三种 FSDP 策略对应不同的 clip 方法（FSDP v1 / FSDP v2 / 原始）。

---

## 八、Loss 聚合模式

**文件**: `verl/trainer/ppo/core_algos.py` (行 384–419)  
**函数**: `agg_loss()`

| 模式 | 公式 | 适用场景 |
|------|------|---------|
| `token-mean` (默认) | `mean(loss * mask)` | 标准 PPO |
| `seq-mean-token-sum` | `mean(seq_sum(loss * mask))` | 避免长序列主导 |
| `seq-mean-token-mean` | `mean(seq_mean(loss * mask))` | 每条序列等权 |
| `seq-mean-token-sum-norm` | `sum(loss * mask) / response_len` | Dr. GRPO 论文做法 |

---

## 九、Critic Warmup

**文件**: `verl/trainer/ppo/ray_trainer.py` (行 1060)

```python
if self.config.trainer.critic_warmup <= self.global_steps:
    actor_output = self.actor_rollout_wg.update_actor(batch)
```

- 在 critic 充分训练之前，不更新 actor
- 避免初期价值函数不准导致错误梯度信号

---

## 十、Reward 维度拆分与过长度惩罚

### 10.1 多维度 Reward 拆分

**文件**: `verl/trainer/ppo/reward.py` (行 127–164)

Reward 被拆分为独立维度分别记录：

```python
separate_score = {
    "content_score": ...,     # 内容质量
    "format_score": ...,      # 格式正确性
    "length_factor": ...,     # 长度惩罚因子
    "view_category_score": ..., # 视角分类
    "view_grounding_score": ..., # 视角接地
}
```

各维度独立作为 metric 记录，便于分析每个因素对训练的影响。

### 10.2 DAPO 过长度惩罚

**文件**: `verl/workers/reward_manager/dapo.py` (行 105–114)

```python
exceed_len = response_len - (max_resp_len - overlong_buffer_len)
penalty = exceed_len / overlong_buffer_len * penalty_factor
```

- 超出缓冲区的响应被惩罚，鼓励模型产出简洁回答

---

## 十一、Bootstrap 验证与 Majority Voting

**文件**: `verl/trainer/ppo/metric_utils.py` (行 257–436)

### Bootstrap 估计

对验证指标做 bootstrap resampling（默认 1000 次），得到更稳定的 mean/std 估计。

### 多抽样量评估

对每种抽样数量 N（2 的幂次，最大到 `n_resps`），计算：

| 指标 | 含义 |
|------|------|
| `mean@N` / `std@N` | N 次抽样的均值与标准差 |
| `best@N/mean` / `best@N/std` | 取 N 次中最好结果的均值/标准差 |
| `worst@N/mean` / `worst@N/std` | 取 N 次中最差结果的均值/标准差 |
| `maj@N/mean` | **Majority voting**：取 N 次中最频繁答案的得分 |

---

## 十二、Curriculum Learning：DNPO 动态数据过滤

**文件**: `verl/trainer/ppo/dnpo_ray_trainer.py` (行 180–238)

三阶段难度递进：

```
训练前 1/3: 保留 0 < num_correct < 8 的 prompt（最容易，大量样本可用）
训练中 1/3: 保留 1 < num_correct < 7 的 prompt（中等难度）
训练后 1/3: 保留 2 < num_correct < 6 的 prompt（最难，筛选严苛）
```

- 通过不断生成 + 过滤的循环构建动态 batch
- 直到累积足够的过滤后样本才进行一步训练

---

## 十三、FlowRL：GFlowNet 风格 Loss

**文件**: `verl/workers/actor/dp_actor.py` (行 414–431, 487–527)

当 `loss_cal == "flowrl"` 时启用。核心公式：

```python
delta = log_z + avg_logpf - 15 * seq_log_reward - avg_logp_ref
loss = importance_weight * delta^2
```

- `log_z` 由 `ProjZModule`（3 层 MLP + GELU + LayerNorm + Dropout）从 prompt 隐状态学习
- 目标：让生成轨迹的概率与 reward 匹配（trajectory balance）
- importance weight 做 clip 控制方差

---

## 十四、移除 Padding 与融合 Kernel

**文件**: `verl/workers/actor/dp_actor.py`

### 14.1 Remove Padding

`use_remove_padding=True` 时：
- 前向传播前 unpad 输入，减少无效计算
- 计算完成后 pad 回原形状
- 对长序列分布不均的数据集效果显著

### 14.2 Fused Kernels

`use_fused_kernels=True` 时使用 `FusedLinearForPPO`：
- 单次前向同时输出 `log_probs` + `entropy`
- 减少 GPU kernel launch 开销

### 14.3 torch.compile

```python
# entropy_from_logits 默认启用 torch.compile(dynamic=True)
```

---

## 十五、Ulysses 序列并行

**文件**: `verl/workers/actor/dp_actor.py` (行 60–61, 118–128)

- 在序列维度上切分长序列到多个 GPU
- `ulysses_sequence_parallel_size` 控制并行度
- 对超长序列场景可突破单 GPU 显存限制

---

## 十六、关键配置参数速查表

| 参数 | 默认值 | 位置 | 说明 |
|------|--------|------|------|
| `clip_ratio` | 0.2 | `bapo_config.py:192` | PPO 裁剪范围 |
| `clip_ratio_low` | 0.2 | `bapo_config.py:193` | 非对称裁剪下界 |
| `clip_ratio_high` | 0.2 | `bapo_config.py:194` | 非对称裁剪上界 |
| `clip_ratio_c` | 3.0 | `bapo_config.py:197` | Dual-clip 下界常数 |
| `loss_agg_mode` | `"token-mean"` | `bapo_config.py:198` | Loss 聚合方式 |
| `entropy_coeff` | 0 | `bapo_config.py:199` | 熵正则系数（0=禁用） |
| `use_kl_loss` | False | `bapo_config.py:200` | 是否启用 KL loss |
| `kl_loss_coef` | 0.001 | `bapo_config.py:202` | KL loss 系数 |
| `kl_loss_type` | `"low_var_kl"` | `bapo_config.py:203` | KL 损失类型 |
| `ppo_epochs` | 1 | `bapo_config.py:204` | 每步 PPO epoch 数 |
| `grad_clip` | 1.0 | `bapo_config.py:338` | 梯度裁剪阈值 |
| `use_dynamic_bsz` | False | `bapo_config.py:189` | 动态 micro-batch |
| `ppo_max_token_len_per_gpu` | 16384 | `bapo_config.py:190` | 动态 bsz 的最大 token 数 |
| `ulysses_sequence_parallel_size` | 1 | `bapo_config.py:339` | 序列并行度 |
| `norm_adv_by_std_in_grpo` | True | `ray_trainer.py:1039` | GRPO 是否除以 std |
| `balance_batch` | (config) | `ray_trainer.py:964` | 是否按 token 数均衡 batch |
| `critic_warmup` | (config) | `ray_trainer.py:1060` | Critic 预热步数 |

---

## 十七、策略效果总结

| 策略 | 影响维度 | 效果 |
|------|---------|------|
| 动态温度调节 | 探索/利用平衡 | 自动维持目标熵水平，避免模式坍塌或过度发散 |
| Adaptive KL | 策略更新稳定性 | 自动调节 KL 惩罚强度，在信任域内更新 |
| WSD LR Schedule | 收敛质量 | 稳定阶段让模型充分探索损失景观，再衰减收敛 |
| Dual-Clip PPO | 训练稳定性 | 防止负 advantage 时的梯度爆炸 |
| BAPO 动态裁剪 | 梯度信号平衡 | 自动调整裁剪边界，维持正/负梯度贡献比 |
| Karmarkar-Karp 均衡 | 训练效率 | 减少各 GPU 的 padding 浪费，提高 MFU |
| Dynamic BSZ | 训练效率 + 梯度噪声 | 相似长度序列打包，减少 padding；自适应梯度累积 |
| 熵退火 | 收敛 vs 探索 | 训练后期逐步降温，从探索转向利用 |
| 梯度安全检查 | 训练稳定性 | 自动跳过 NaN/Inf 梯度，防止模型损坏 |
| DNPO Curriculum | 数据效率 | 从易到难递进，避免模型在过难样本上浪费 |
| Majority Voting | 评估可靠性 | 多候选答案投票，更鲁棒的验证指标 |
