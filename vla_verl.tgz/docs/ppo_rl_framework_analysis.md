# VERL PPO 强化学习框架 — 完整架构分析

> 入口文件：`verl/trainer/main_ppo.py`
> 分析侧重 RL 框架整体架构与数据流，忽略 reward 计算、训练配置等细节。

---

## 一、总览：三进程架构

整个 PPO 训练由三个层级协同完成：

```
┌─────────────────────────────────────────────────────────┐
│                   Driver 进程 (CPU)                      │
│  main_ppo.py  →  RayPPOTrainer.fit()                    │
│  负责：调度、Advantage 计算、指标记录                      │
└────────────┬────────────────────────────┬────────────────┘
             │ RPC                        │ RPC
    ┌────────▼────────┐          ┌───────▼────────┐
    │ ActorRolloutRef │          │  Critic Worker  │
    │   Worker (GPU)  │          │    (GPU)        │
    │  混合引擎:        │          │  价值函数估计     │
    │  - Rollout 生成  │          │  - compute_values│
    │  - Actor 更新    │          │  - update_critic │
    │  - Ref 参考策略  │          └────────────────┘
    └─────────────────┘
```

- **Driver 进程**：运行 `RayPPOTrainer`，负责调度各 Worker、计算 advantage、记录指标。
- **ActorRolloutRef Worker**（混合引擎）：同一模型既用于 rollout 生成（vLLM/SGLang 推理），也用于 actor 更新（PPO 训练），还可兼任 reference policy。
- **Critic Worker**：仅在 GAE 模式下需要，提供价值函数估计。

---

## 二、入口：`main_ppo.py` 初始化流程

关键代码路径：`main_ppo.py` 第 69–185 行。

### 2.1 启动步骤

1. **启动 Ray 集群** — `ray.init()`
2. **加载 Tokenizer 和 Processor** — 从模型路径加载
3. **选择并行策略**：
   - FSDP / FSDP2 → `ActorRolloutRefWorker` + `RayWorkerGroup`
   - Megatron → `ActorRolloutRefWorker` + `NVMegatronRayWorkerGroup`
4. **定义角色映射** (`role_worker_mapping`)：

```python
role_worker_mapping = {
    Role.ActorRollout: ray.remote(actor_rollout_cls),   # 混合引擎（必须）
    Role.Critic:        ray.remote(CriticWorker),       # 价值网络（GAE 需要）
}
# 可选角色
Role.RewardModel   # 模型-based reward
Role.RefPolicy     # 参考策略（KL 惩罚时需要）
```

5. **创建 RayPPOTrainer** → 调用 `trainer.init_workers()` 和 `trainer.fit()`

### 2.2 Worker 初始化 (`init_workers`, 第 691 行)

- 为每个 Role 创建对应的 `RayClassWithInitArgs`
- 使用 `create_colocated_worker_cls` 将同资源池的 worker 合并到同一进程
- 调用各 Worker 的 `init_model()` 加载模型权重
- Rollout 最后初始化（让 vLLM 更好地预估 KV cache 内存）

---

## 三、核心训练循环：`RayPPOTrainer.fit()`（第 867 行）

每个 step 完成一次完整的 **Rollout → Evaluate → Learn** 循环：

```
Step N:
  ┌──────────┐   ┌──────────┐   ┌──────────┐   ┌──────────┐   ┌──────────┐
  │ 1.Rollout│ → │2.Reward  │ → │3.Old     │ → │4.Advantage│ → │5.Update  │
  │  生成回答 │   │  计算奖励 │   │  LogProb │   │  计算优势 │   │  Actor   │
  └──────────┘   └──────────┘   └──────────┘   └──────────┘   └──────────┘
                                                     │
                                               ┌──────▼──────┐
                                               │ 6.Update    │ (仅 GAE)
                                               │   Critic    │
                                               └─────────────┘
```

### 3.1 Rollout — 生成回答

```python
# ray_trainer.py 第 931–937 行
gen_batch = batch.pop(["input_ids", "attention_mask", "position_ids"], ...)
gen_batch_output = self.actor_rollout_wg.generate_sequences(gen_batch)
```

- 从 batch 中取出 prompt tokens 作为生成输入
- `ActorRolloutRefWorker.generate_sequences()` → 内部使用 **vLLM / SGLang** 推理引擎
- 每个 prompt 生成 `n` 条回答（`rollout.n`），通过 `batch.repeat(n, interleave=True)` 实现
- 返回 `responses`（生成的 token IDs）

### 3.2 Reward — 计算奖励

```python
# ray_trainer.py 第 970–979 行
reward_tensor, reward_extra_infos_dict = compute_reward(batch, self.reward_fn)
batch.batch["token_level_scores"] = reward_tensor
```

- 支持多种 reward 来源：规则-based、模型-based（RewardModel Worker）、代码 sandbox 等
- `token_level_scores`：shape `(bs, response_length)`，outcome supervision 下每个 token 位置赋相同标量分数
- 可选：应用 **KL 惩罚** (`apply_kl_penalty`)，从 reward 中扣除 `β * KL(π_old || π_ref)`

### 3.3 Old LogProb — 重算采样策略的对数概率

```python
# ray_trainer.py 第 982–991 行
old_log_prob = self.actor_rollout_wg.compute_log_prob(batch)
batch.batch["old_log_probs"] = old_log_prob
```

- 用 **当前 Actor 模型** 重新前向传播，计算已生成回答的 token-level log 概率
- 同时计算熵 `entropys`（用于后续熵正则）
- 若启用 Reference Policy，也在此阶段计算 `ref_log_prob`

### 3.4 Advantage — 计算优势函数（Driver 进程，CPU 端）

这是区分不同 RL 算法的核心。框架在 `core_algos.py` 中实现了 8 种 advantage estimator：

| Estimator | 需要 Critic? | 核心思想 |
|-----------|-------------|---------|
| **GAE** | 是 | 经典 PPO：`A_t = Σ(γλ)^l * δ_{t+l}`，δ 为 TD-error |
| **GRPO** | 否 | 组内归一化：同 prompt 的多个回答，用组 mean/std 标准化 |
| **RLOO** | 否 | Leave-One-Out baseline：`A_i = r_i - mean(r_{j≠i})` |
| **REINFORCE++** | 否 | Discounted return 直接作为 advantage |
| **RF++-Baseline** | 否 | REINFORCE++ + 组内均值 baseline |
| **ReMax** | 否 | Greedy decoding reward 作为 baseline |
| **GDPO** | 否 | 多维度 reward，组内按维度分别标准化后求和 |

```python
# ray_trainer.py 第 1041–1050 行
batch = compute_advantage(batch, adv_estimator, gamma, lam, ...)
```

**优势计算完成后存入**：
- `batch.batch["advantages"]` — token-level 优势值
- `batch.batch["returns"]` — token-level 回报值（用于 critic 训练）

### 3.5 Update Critic（仅 GAE 模式）

```python
# ray_trainer.py 第 1053–1057 行
critic_output = self.critic_wg.update_critic(batch)
```

- `CriticWorker.update_critic()` → `DataParallelPPOCritic.update_critic()`
- 使用 **PPO-style clipped value loss**（`core_algos.py:511`）：

```python
vpred_clipped = clip(vpred, values - ε, values + ε)
vf_loss = 0.5 * mean(max((vpred - returns)², (vpred_clipped - returns)²))
```

### 3.6 Update Actor — 核心 PPO 策略更新

```python
# ray_trainer.py 第 1060–1066 行
actor_output = self.actor_rollout_wg.update_actor(batch)
```

`ActorRolloutRefWorker.update_actor()` → `DataParallelPPOActor.update_policy()`（`workers/actor/dp_actor.py:342`）：

1. 将 batch 切分为 **mini_batch**（`ppo_mini_batch_size`）
2. 对每个 mini_batch 做 **多个 PPO epoch**（`ppo_epochs`）
3. 再切分为 **micro_batch**（用于梯度累积）
4. 对每个 micro_batch：
   - 前向传播得 `log_prob`（新策略的对数概率）
   - 调用 `compute_policy_loss()` 计算 PPO loss
   - `loss.backward()` 累积梯度
5. `optimizer.step()` 更新参数

---

## 四、PPO Policy Loss 数学细节

对应代码：`verl/trainer/ppo/core_algos.py` 第 422 行 `compute_policy_loss()`。

```python
ratio = exp(log_prob - old_log_prob)              # π_new / π_old

# 标准 PPO clipped objective
pg_losses1 = -advantages * ratio                  # 无裁剪
pg_losses2 = -advantages * clip(ratio, 1-ε, 1+ε) # 裁剪版本
clip_loss = max(pg_losses1, pg_losses2)           # 悲观估计

# Dual-clip PPO（当 advantage < 0 时，加下界保护）
# 参考：https://arxiv.org/pdf/1912.09729
pg_losses3 = -advantages * c                      # c = 3.0
final_loss = min(clip_loss, pg_losses3)           # 当 advantage < 0 时生效

# 聚合模式（loss_agg_mode）
pg_loss = agg_loss(final_loss, response_mask)
```

**完整 policy loss**（`dp_actor.py` 第 446–461 行）：

```python
policy_loss = pg_loss                           # PPO clipped loss
            - entropy_coeff * entropy_loss     # 熵正则（可选）
            + kl_loss_coef * kl_loss            # KL 散度正则（可选，与 ref 策略对齐）
```

### 4.1 Loss 聚合模式 (`agg_loss`, 第 384 行)

| 模式 | 含义 |
|------|------|
| `token-mean` | 所有有效 token 的 loss 取平均 |
| `seq-mean-token-sum` | 每条序列 token loss 求和 → 对序列取平均 |
| `seq-mean-token-mean` | 每条序列 token loss 平均 → 对序列取平均 |
| `seq-mean-token-sum-norm` | token loss 求和 / response_length 常数 |

---

## 五、Critic Value Loss

对应代码：`verl/trainer/ppo/core_algos.py` 第 511 行。

```python
vpred_clipped = clip(vpred, values - ε, values + ε)
vf_loss = 0.5 * mean(max((vpred - returns)², (vpred_clipped - returns)²))
```

与 PPO 原始论文一致：对 value prediction 也做 clipped 操作，防止更新幅度过大。

---

## 六、数据载体：`DataProto`

定义：`verl/protocol.py` 第 200 行。

```python
@dataclass
class DataProto:
    batch: TensorDict          # tensor 数据
    non_tensor_batch: dict     # numpy 数据 (uid, data_source, ...)
    meta_info: dict            # 元信息 (temperature, metrics, ...)
```

**这是整个框架中 Worker 之间交换数据的统一协议**。关键操作：

| 方法 | 作用 |
|------|------|
| `union(other)` | 合并两个 DataProto（key 不重叠） |
| `pop(batch_keys, non_tensor_batch_keys)` | 取出指定 key，返回新 DataProto |
| `repeat(n, interleave)` | 复制 n 次（用于 rollout.n） |
| `select(keys)` | 筛选指定 key |
| `chunk(n)` / `split(n)` | 切分为 mini/micro batch |

---

## 七、整体数据流总览

```
                    ┌──────────────┐
                    │  DataLoader  │  从 parquet / JSON 索引读取 prompts
                    └──────┬───────┘
                           │ input_ids, attention_mask, position_ids
                    ┌──────▼───────┐
                    │   Rollout    │  vLLM / SGLang 生成 responses
                    │  (GPU 推理)   │
                    └──────┬───────┘
                           │ responses
                    ┌──────▼───────┐
                    │   Reward     │  规则 / 模型 / sandbox → token_level_scores
                    │  (Driver)    │
                    └──────┬───────┘
                           │ token_level_scores (+ KL penalty)
                    ┌──────▼───────┐
                    │ Old LogProb  │  当前策略 π_old 的 log prob
                    │  (GPU)       │  + ref_log_prob（可选）
                    └──────┬───────┘
                           │ old_log_probs
                    ┌──────▼───────┐
                    │  Advantage   │  GAE / GRPO / RLOO / REINFORCE++ / GDPO / ...
                    │  (Driver)    │
                    └──────┬───────┘
                           │ advantages, returns
              ┌────────────┼────────────┐
              │                         │
     ┌────────▼────────┐     ┌─────────▼────────┐
     │  Update Actor   │     │  Update Critic   │ (仅 GAE)
     │  PPO Clipped    │     │  Clipped Value   │
     │  Loss           │     │  Loss            │
     │  + Entropy Reg  │     └──────────────────┘
     │  + KL Reg (可选) │
     └─────────────────┘
```

---

## 八、核心设计要点

1. **混合引擎 (Hybrid Engine)** — Actor 和 Rollout 共享同一个模型权重（`hybrid_engine=True`）。Rollout 时切换到 vLLM/SGLang 高效推理模式；Actor 更新时切换回 FSDP 训练模式。GPU 显存在两个模式间动态分配。

2. **Driver 端计算 Advantage** — 所有 advantage 估计在 CPU driver 进程完成，避免分布式通信开销。GPU Worker 仅负责模型前向/反向传播。

3. **Ray RPC 通信** — Worker 之间通过 Ray 的 `@register(dispatch_mode=...)` 装饰器实现数据并行分发（`DP_COMPUTE_PROTO`）或广播（`ONE_TO_ALL`）。

4. **On-Policy 数据流** — 每个 step 的数据仅使用一次（生成 → 评估 → 学习），这保证了 PPO 的 on-policy 性质。Rollout 产生的 `old_log_probs` 来自采样时的策略参数。

5. **Advantage Estimator 可插拔** — 通过 `algorithm.adv_estimator` 配置即可切换不同的 RL 算法变体，无需修改 Worker 代码。这使得 GRPO、RLOO、GDPO 等现代变体可以与 GAE 无缝切换。

---

## 九、关键文件索引

| 文件 | 作用 |
|------|------|
| `verl/trainer/main_ppo.py` | 程序入口：启动 Ray、创建 Trainer |
| `verl/trainer/ppo/ray_trainer.py` | `RayPPOTrainer`：主训练循环、advantage 计算 |
| `verl/trainer/ppo/core_algos.py` | PPO 核心算法：GAE、GRPO、RLOO、policy loss、value loss |
| `verl/trainer/ppo/reward.py` | Reward 计算与加载 |
| `verl/workers/fsdp_workers.py` | FSDP Worker 实现：`ActorRolloutRefWorker`、`CriticWorker` |
| `verl/workers/actor/dp_actor.py` | `DataParallelPPOActor`：实际执行 PPO update_policy |
| `verl/workers/critic/dp_critic.py` | `DataParallelPPOCritic`：实际执行 critic update |
| `verl/protocol.py` | `DataProto`：Worker 间数据交换协议 |
| `verl/utils/dataset/rl_dataset.py` | RL 数据集加载与 collate |
