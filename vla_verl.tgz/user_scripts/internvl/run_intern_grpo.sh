source .venv/bin/activate

HOSTFILE=/etc/volcano/all.host
PORT=6379

# 解析 hostfile
hosts=()
while read -r line; do
    host=$(echo "$line" | cut -d' ' -f1)
    hosts+=("$host")
done < "$HOSTFILE"

# Head 节点是第一个
HEAD_NODE=${hosts[0]}

echo "[Ray Cluster] Head node: $HEAD_NODE"
ray start --head --port=$PORT --node-ip-address=$HEAD_NODE

# 启动 Worker 节点
for ((i = 1; i < ${#hosts[@]}; i++)); do
    node=${hosts[i]}
    echo "[Ray Cluster] Starting worker on $node"
    ssh $node "cd $PWD; source .venv/bin/activate; ray start --address=${HEAD_NODE}:${PORT} --node-ip-address=$node"
done

echo "[Ray Cluster] Initiation Successfully Completed. Now running training process..."

sleep 5

export PYTHONPATH=$(pwd)

set -x
ENGINE=${1:-vllm}
# If you are using vllm<=0.6.3, you might need to set the following environment variable to avoid bugs:
# export VLLM_ATTENTION_BACKEND=XFORMERS

TIMESTAMP=$(date "+%Y%m%d_%H%M%S")
PROJECT_NAME="IV3-Post-RL-46k"
EXPERIMENT_NAME="L1-Post-SFT-RL-46k-5e7-test_${TIMESTAMP}"
MODEL_PATH="/perception-hl/xiwen.zhang/mlm-evaluator-work-dirs/exp-poi-charging-v3-portion1-train-and-eval-20250702-rlbase"
TRAIN_DATA="[/perception-hl/xiwen.zhang/mlm-data/poi/multitask/train_charging_v3_portion1_rl.parquet]"

ROLLOUT_IMAGE_LIMIT=20
ROLLOUT_VIDEO_LIMIT=0

python3 -m verl.trainer.main_ppo \
    algorithm.adv_estimator=grpo \
    data.train_files=$TRAIN_DATA \
    data.val_files=/perception-hl/xiwen.zhang/mlm-data/poi/multitask/train_charging_v3_portion1_rl_nodynamic.parquet \
    data.train_batch_size=8 \
    data.max_prompt_length=8192 \
    data.max_response_length=2048 \
    data.filter_overlong_prompts=True \
    data.truncation='error' \
    data.image_key=image \
    actor_rollout_ref.model.path=$MODEL_PATH \
    actor_rollout_ref.actor.optim.lr=1e-6 \
    actor_rollout_ref.model.use_remove_padding=True \
    actor_rollout_ref.actor.ppo_mini_batch_size=1 \
    actor_rollout_ref.actor.ppo_micro_batch_size_per_gpu=1 \
    actor_rollout_ref.actor.use_kl_loss=True \
    actor_rollout_ref.actor.kl_loss_coef=0.01 \
    actor_rollout_ref.actor.kl_loss_type=low_var_kl \
    actor_rollout_ref.actor.entropy_coeff=0 \
    actor_rollout_ref.model.trust_remote_code=True \
    actor_rollout_ref.model.enable_gradient_checkpointing=True \
    actor_rollout_ref.actor.fsdp_config.param_offload=False \
    actor_rollout_ref.actor.fsdp_config.optimizer_offload=False \
    actor_rollout_ref.rollout.log_prob_micro_batch_size_per_gpu=1 \
    actor_rollout_ref.rollout.tensor_model_parallel_size=1 \
    actor_rollout_ref.rollout.name=$ENGINE \
    actor_rollout_ref.rollout.gpu_memory_utilization=0.6 \
    actor_rollout_ref.rollout.enable_chunked_prefill=False \
    actor_rollout_ref.rollout.enforce_eager=False \
    actor_rollout_ref.rollout.free_cache_engine=False \
    actor_rollout_ref.rollout.n=8 \
    +actor_rollout_ref.rollout.limit_images=$ROLLOUT_IMAGE_LIMIT \
    +actor_rollout_ref.rollout.limit_videos=$ROLLOUT_VIDEO_LIMIT \
    actor_rollout_ref.ref.log_prob_micro_batch_size_per_gpu=1 \
    actor_rollout_ref.ref.fsdp_config.param_offload=True \
    algorithm.use_kl_in_reward=False \
    trainer.critic_warmup=0 \
    trainer.val_before_train=False \
    trainer.logger=['console','tensorboard'] \
    trainer.project_name=$PROJECT_NAME \
    trainer.experiment_name=$EXPERIMENT_NAME \
    trainer.n_gpus_per_node=8 \
    trainer.nnodes=1 \
    trainer.save_freq=100 \
    trainer.test_freq=0 \
    trainer.total_epochs=3 

echo "Training is completed. Now merging sharded model..."

cp verl/mlm/*.py ./output/${PROJECT_NAME}/${EXPERIMENT_NAME}/global_step/actor

python3 scripts/model_merger.py merge \
    --backend fsdp \
    --local_dir ./output/${PROJECT_NAME}/${EXPERIMENT_NAME}/global_step/actor \
    --target_dir ./output/${PROJECT_NAME}/${EXPERIMENT_NAME}/hf

cp verl/mlm/*.py ./output/${PROJECT_NAME}/${EXPERIMENT_NAME}/hf
