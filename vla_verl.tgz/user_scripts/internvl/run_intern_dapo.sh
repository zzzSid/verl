source .venv/bin/activate

HOSTFILE=/etc/volcano/all.host
PORT=6379

# 解析 hostfile
hosts=()
while read -r line; do
    host=$(echo "$line" | cut -d' ' -f1)
    hosts+=("$host")
done < "$HOSTFILE"

# Head 节点是第一个
HEAD_NODE=${hosts[0]}

echo "[Ray Cluster] Head node: $HEAD_NODE"
ray start --head --port=$PORT --node-ip-address=$HEAD_NODE

# 启动 Worker 节点
for ((i = 1; i < ${#hosts[@]}; i++)); do
    node=${hosts[i]}
    echo "[Ray Cluster] Starting worker on $node"
    ssh $node "cd $PWD; source .venv/bin/activate; ray start --address=${HEAD_NODE}:${PORT} --node-ip-address=$node"
done

echo "[Ray Cluster] Initiation Successfully Completed. Now running training process..."

sleep 5

export PYTHONPATH=$(pwd)

set -x
ENGINE=${1:-vllm}
# If you are using vllm<=0.6.3, you might need to set the following environment variable to avoid bugs:
# export VLLM_ATTENTION_BACKEND=XFORMERS

TIMESTAMP=$(date "+%Y%m%d_%H%M%S")
PROJECT_NAME="IV3-Post-RL-46k"
EXPERIMENT_NAME="L1-Post-SFT-DAPO-46k-5e7-test_${TIMESTAMP}"
MODEL_PATH="/lustre/zebo.gu/mlm-evaluator-work-dirs/l1_models/exp-0-10-1-2B-IVL3-LDP-l1-40M-20250711release-20250712"
TRAIN_DATA="[/lustre/neos.yan/open_data/Orsta-Data-47k/train/train_chart_virl39k_1657_newbox.parquet]" # ,/lustre/neos.yan/open_data/Orsta-Data-47k/train/train_chart_chartx_2353_newbox.parquet,/lustre/neos.yan/open_data/Orsta-Data-47k/train/train_math_mmk12_5732_newbox.parquet,/lustre/neos.yan/open_data/Orsta-Data-47k/train/train_science_virl39k_2539_newbox.parquet,/lustre/neos.yan/open_data/Orsta-Data-47k/train/train_chart_tablevqa_496_newbox.parquet,/lustre/neos.yan/open_data/Orsta-Data-47k/train/train_puzzle_puzzlevqa_2648_x2_newbox.parquet,/lustre/neos.yan/open_data/Orsta-Data-47k/train/train_ocr_estvqa_2946_newbox.parquet,/lustre/neos.yan/open_data/Orsta-Data-47k/train/train_math_mmmath_3539_newbox.parquet,/lustre/neos.yan/open_data/Orsta-Data-47k/train/train_science_scivqa_1264_newbox.parquet,/lustre/neos.yan/open_data/Orsta-Data-47k/train/train_science_scienceqa_536_newbox.parquet,/lustre/neos.yan/open_data/Orsta-Data-47k/train/train_puzzle_visualpuzzle_342_x2_newbox.parquet,/lustre/neos.yan/open_data/Orsta-Data-47k/train/train_ocr_llavaov_3092_newbox.parquet,/lustre/neos.yan/open_data/Orsta-Data-47k/train/train_chart_chartqapro_498_newbox.parquet,/lustre/neos.yan/open_data/Orsta-Data-47k/train/train_counting_clevr-1725_newbox.parquet,/lustre/neos.yan/open_data/Orsta-Data-47k/train/train_math_geo3k_2983_newbox.parquet,/lustre/neos.yan/open_data/Orsta-Data-47k/train/train_detection_object365_4000_newbox.parquet,/lustre/neos.yan/open_data/Orsta-Data-47k/train/train_detection_v3det_4000_newbox.parquet,/lustre/neos.yan/open_data/Orsta-Data-47k/train/train_grounding_dcube_4870_newbox.parquet]"

ROLLOUT_IMAGE_LIMIT=1
ROLLOUT_VIDEO_LIMIT=0

adv_estimator=grpo

use_kl_in_reward=False
kl_coef=0.0
use_kl_loss=False
kl_loss_coef=0.0

clip_ratio_low=0.2
clip_ratio_high=0.28

max_prompt_length=$((1024 * 4))
max_response_length=$((1024 * 2))
enable_overlong_buffer=True
overlong_buffer_len=$((1024 * 5))
overlong_penalty_factor=1.0

loss_agg_mode="token-mean"

enable_filter_groups=False
filter_groups_metric=reward_model
max_num_gen_batches=10
train_prompt_bsz=32
gen_prompt_bsz=$((train_prompt_bsz * 4))
n_resp_per_prompt=8
train_prompt_mini_bsz=32

# Algorithm
temperature=1.0
top_p=1.0
top_k=-1 # 0 for HF rollout, -1 for vLLM rollout
val_top_p=0.7

# Performance Related Parameter
sp_size=2
use_dynamic_bsz=False
actor_ppo_max_token_len=$((max_prompt_length + max_response_length))
infer_ppo_max_token_len=$((max_prompt_length + max_response_length))
offload=False
gen_tp=2


python3 -m recipe.dapo.main_dapo \
    data.train_files="${TRAIN_DATA}" \
    data.val_files="/perception-hl/xiwen.zhang/mlm-data/poi/multitask/train_charging_v3_portion1_rl_nodynamic.parquet" \
    data.prompt_key=prompt \
    data.image_key=images \
    data.truncation='left' \
    data.max_prompt_length=${max_prompt_length} \
    data.max_response_length=${max_response_length} \
    data.gen_batch_size=${gen_prompt_bsz} \
    data.train_batch_size=${train_prompt_bsz} \
    actor_rollout_ref.rollout.n=${n_resp_per_prompt} \
    algorithm.adv_estimator=${adv_estimator} \
    algorithm.use_kl_in_reward=${use_kl_in_reward} \
    algorithm.kl_ctrl.kl_coef=${kl_coef} \
    actor_rollout_ref.actor.use_kl_loss=${use_kl_loss} \
    actor_rollout_ref.actor.kl_loss_coef=${kl_loss_coef} \
    actor_rollout_ref.actor.clip_ratio_low=${clip_ratio_low} \
    actor_rollout_ref.actor.clip_ratio_high=${clip_ratio_high} \
    actor_rollout_ref.actor.clip_ratio_c=10.0 \
    actor_rollout_ref.actor.ppo_micro_batch_size_per_gpu=8 \
    algorithm.filter_groups.enable=${enable_filter_groups} \
    algorithm.filter_groups.max_num_gen_batches=${max_num_gen_batches} \
    algorithm.filter_groups.metric=${filter_groups_metric} \
    actor_rollout_ref.model.use_remove_padding=True \
    actor_rollout_ref.actor.use_dynamic_bsz=${use_dynamic_bsz} \
    actor_rollout_ref.ref.log_prob_use_dynamic_bsz=${use_dynamic_bsz} \
    actor_rollout_ref.rollout.log_prob_use_dynamic_bsz=${use_dynamic_bsz} \
    actor_rollout_ref.rollout.log_prob_micro_batch_size_per_gpu=16 \
    actor_rollout_ref.actor.ppo_max_token_len_per_gpu=${actor_ppo_max_token_len} \
    actor_rollout_ref.ref.log_prob_max_token_len_per_gpu=${infer_ppo_max_token_len} \
    actor_rollout_ref.rollout.log_prob_max_token_len_per_gpu=${infer_ppo_max_token_len} \
    actor_rollout_ref.ref.log_prob_micro_batch_size_per_gpu=16 \
    actor_rollout_ref.model.path="${MODEL_PATH}" \
    actor_rollout_ref.model.enable_gradient_checkpointing=True \
    actor_rollout_ref.model.trust_remote_code=True \
    actor_rollout_ref.actor.optim.lr=1e-6 \
    actor_rollout_ref.actor.optim.lr_warmup_steps=10 \
    actor_rollout_ref.actor.optim.weight_decay=0.1 \
    actor_rollout_ref.actor.ppo_mini_batch_size=${train_prompt_mini_bsz} \
    actor_rollout_ref.actor.fsdp_config.param_offload=${offload} \
    actor_rollout_ref.actor.fsdp_config.optimizer_offload=${offload} \
    actor_rollout_ref.actor.entropy_coeff=0 \
    actor_rollout_ref.actor.grad_clip=1.0 \
    actor_rollout_ref.actor.loss_agg_mode=${loss_agg_mode} \
    actor_rollout_ref.actor.ulysses_sequence_parallel_size=${sp_size} \
    actor_rollout_ref.rollout.gpu_memory_utilization=0.80 \
    actor_rollout_ref.rollout.tensor_model_parallel_size=${gen_tp} \
    actor_rollout_ref.rollout.enable_chunked_prefill=True \
    actor_rollout_ref.rollout.max_num_batched_tokens=$((max_prompt_length + max_response_length)) \
    actor_rollout_ref.rollout.temperature=${temperature} \
    actor_rollout_ref.rollout.top_p=${top_p} \
    actor_rollout_ref.rollout.top_k="${top_k}" \
    actor_rollout_ref.rollout.val_kwargs.temperature=${temperature} \
    actor_rollout_ref.rollout.val_kwargs.top_p=${val_top_p} \
    actor_rollout_ref.rollout.val_kwargs.top_k=${top_k} \
    actor_rollout_ref.rollout.val_kwargs.do_sample=True \
    actor_rollout_ref.rollout.val_kwargs.n=1 \
    actor_rollout_ref.ref.fsdp_config.param_offload=${offload} \
    actor_rollout_ref.ref.ulysses_sequence_parallel_size=${sp_size} \
    actor_rollout_ref.actor.fsdp_config.fsdp_size=-1 \
    reward_model.reward_manager=vote \
    reward_model.overlong_buffer.enable=${enable_overlong_buffer} \
    reward_model.overlong_buffer.len=${overlong_buffer_len} \
    reward_model.overlong_buffer.penalty_factor=${overlong_penalty_factor} \
    trainer.logger=['console','tensorboard'] \
    trainer.project_name="${PROJECT_NAME}" \
    trainer.experiment_name="${EXPERIMENT_NAME}" \
    trainer.n_gpus_per_node=8 \
    trainer.nnodes=1 \
    trainer.val_before_train=False \
    trainer.test_freq=0 \
    trainer.save_freq=100 \
    trainer.total_epochs=1 \
    trainer.resume_mode=auto
