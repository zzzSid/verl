source .venv/bin/activate
export PYTHONPATH=$(pwd)

INPUT="output/Intern_VL_TEST_GEO3K/intern_vl_20250611_135658"

echo "Training is completed. Now merging sharded model..."

cp verl/mlm/*.py ${INPUT}/global_step/actor

python3 scripts/model_merger.py merge \
    --backend fsdp \
    --local_dir ${INPUT}/global_step/actor \
    --target_dir ${INPUT}/hf

cp verl/mlm/*.py ${INPUT}/hf