source .venv/bin/activate

HOSTFILE=/etc/volcano/all.host
PORT=6379

# 解析 hostfile
hosts=()
while read -r line; do
    host=$(echo "$line" | cut -d' ' -f1)
    hosts+=("$host")
done < "$HOSTFILE"

# Head 节点是第一个
HEAD_NODE=${hosts[0]}

echo "[Ray Cluster] Head node: $HEAD_NODE"
ray start --head --port=$PORT --node-ip-address=$HEAD_NODE

# 启动 Worker 节点
for ((i = 1; i < ${#hosts[@]}; i++)); do
    node=${hosts[i]}
    echo "[Ray Cluster] Starting worker on $node"
    ssh $node "cd $PWD; source .venv/bin/activate; ray start --address=${HEAD_NODE}:${PORT} --node-ip-address=$node"
done

echo "[Ray Cluster] Done"

sleep 60