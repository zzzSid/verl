# !/bin/bash

# submit job on KPT platform will change HOME's permission to world writable.
# it will affect deepspeed to start pdsh. So change HOME's permission if needed.
export WANDB_API_KEY=144c5ca17201ab2efde9071daee5425e0599810c
ray stop --force
WORK_DIR=${WORK_DIR:-$HOME}
echo "WORK_DIR: $WORK_DIR"
CURRENT_PERM=$(stat -c "%a" "$WORK_DIR")
OTHER_PERM=$((CURRENT_PERM % 10))
if (( OTHER_PERM & 2 )); then
    echo "warning: WORK_DIR=$WORK_DIR is world writable, removing it!!"
    chmod o-w "$WORK_DIR"
    NEW_PERM=$(stat -c "%a" "$WORK_DIR")
    if [ $NEW_PERM -ne $CURRENT_PERM ]; then
        echo "world writable is removed"
        echo "new HOME permission: $NEW_PERM"
    else
        echo "Error: can't remove world writable permission."
    fi
else
    echo "WORK_DIR=$WORK_DIR is not world writable."
fi

source .venv/bin/activate

HOSTFILE=/etc/volcano/all.host
PORT=6379

# intervl 模型需要适配不同的测试结果
OBJDIR=.venv/lib/python3.10/site-packages/vllm/model_executor/models
BASE_MODEL_NAME=InternVL3-1B
cp scripts/${BASE_MODEL_NAME}/internvl.py $OBJDIR 

# 解析 hostfile
hosts=()
while read -r line; do
    host=$(echo "$line" | cut -d' ' -f1)
    hosts+=("$host")
done < "$HOSTFILE"

# Head 节点是第一个
HEAD_NODE=${hosts[0]}

echo "[Ray Cluster] Head node: $HEAD_NODE"
ray start --head --port=$PORT --node-ip-address=$HEAD_NODE

# 启动 Worker 节点
for ((i = 1; i < ${#hosts[@]}; i++)); do
    node=${hosts[i]}
    echo "[Ray Cluster] Starting worker on $node"
    ssh $node "cd $PWD; source .venv/bin/activate; ray start --address=${HEAD_NODE}:${PORT} --node-ip-address=$node"
done

echo "[Ray Cluster] Initiation Successfully Completed. Now running training process..."

sleep 5

export PYTHONPATH=$(pwd)
export PYTHONPATH="${PYTHONPATH}:$(pwd)/verl"

set -x
ENGINE=${1:-vllm}
# If you are using vllm<=0.6.3, you might need to set the following environment variable to avoid bugs:
# export VLLM_ATTENTION_BACKEND=XFORMERS

TIMESTAMP=$(date "+%Y%m%d-%H%M%S")
PROJECT_NAME="no-entry_IV3-1B_cot-rl_formal"
EXPERIMENT_NAME="${PROJECT_NAME}_model1116-2_fl5k_da1116-2_new-reward-precB_bs16_${TIMESTAMP}"
MODEL_PATH="/lustre/joeden.zhuang/mlm-evaluator-work-dirs/no-entry-1763304170_1B_1116-2"
# MODEL_PATH="/perception-hl/xiwen.zhang/mlm-evaluator-work-dirs/exp-poi-charging-v3-portion1-train-and-eval-20250702-rlbase"
TRAIN_DATA="[/lustre/joeden.zhuang/projects/vlm_no_entry/output_prod/no_entry_road_train_1116-2-rl_filter_5k.parquet]"

cp -r /perception-hl/xiwen.zhang/tools/mlm_py/* "${MODEL_PATH}/"    # 拷贝模型文件到环境地址

NNODES=1
GPU_PER_NODE=8
ROLLOUT_IMAGE_LIMIT=20
ROLLOUT_VIDEO_LIMIT=0

python3 -m verl.trainer.main_ppo \
    algorithm.adv_estimator=grpo \
    data.train_files=$TRAIN_DATA \
    data.val_files=/lustre/joeden.zhuang/projects/vlm_no_entry/output_prod/no_entry_road_test_1110-1.parquet \
    data.train_batch_size=16 \
    data.max_prompt_length=8192 \
    data.max_response_length=256 \
    data.filter_overlong_prompts=True \
    data.truncation='error' \
    data.image_key=image \
    actor_rollout_ref.model.path=$MODEL_PATH \
    actor_rollout_ref.actor.optim.lr=1e-6 \
    actor_rollout_ref.model.use_remove_padding=True \
    actor_rollout_ref.actor.ppo_mini_batch_size=16 \
    actor_rollout_ref.actor.ppo_micro_batch_size_per_gpu=2 \
    actor_rollout_ref.actor.use_kl_loss=True \
    actor_rollout_ref.actor.kl_loss_coef=0.01 \
    actor_rollout_ref.actor.kl_loss_type=low_var_kl \
    actor_rollout_ref.actor.entropy_coeff=0 \
    actor_rollout_ref.model.trust_remote_code=True \
    actor_rollout_ref.model.enable_gradient_checkpointing=True \
    actor_rollout_ref.actor.fsdp_config.param_offload=False \
    actor_rollout_ref.actor.fsdp_config.optimizer_offload=False \
    actor_rollout_ref.rollout.log_prob_micro_batch_size_per_gpu=2 \
    actor_rollout_ref.rollout.tensor_model_parallel_size=1 \
    actor_rollout_ref.rollout.name=$ENGINE \
    actor_rollout_ref.rollout.gpu_memory_utilization=0.7 \
    actor_rollout_ref.rollout.enable_chunked_prefill=False \
    actor_rollout_ref.rollout.enforce_eager=False \
    actor_rollout_ref.rollout.free_cache_engine=False \
    actor_rollout_ref.rollout.n=6 \
    +actor_rollout_ref.rollout.limit_images=$ROLLOUT_IMAGE_LIMIT \
    +actor_rollout_ref.rollout.limit_videos=$ROLLOUT_VIDEO_LIMIT \
    actor_rollout_ref.ref.log_prob_micro_batch_size_per_gpu=2 \
    actor_rollout_ref.ref.fsdp_config.param_offload=True \
    algorithm.use_kl_in_reward=False \
    trainer.critic_warmup=0 \
    trainer.val_before_train=False \
    trainer.logger=['console','wandb'] \
    trainer.project_name=$PROJECT_NAME \
    trainer.experiment_name=$EXPERIMENT_NAME \
    trainer.n_gpus_per_node=$GPU_PER_NODE \
    trainer.nnodes=$NNODES \
    trainer.save_freq=50 \
    trainer.test_freq=0 \
    trainer.total_epochs=1 \
    custom_reward_function.path=./verl/utils/reward_score/task_no_entry.py \
    custom_reward_function.name=no_entry_reward \
    custom_reward_function.reward_kwargs.reward_version='SimpleCot' \
    custom_reward_function.reward_kwargs.iou_threshold=0.5
    # custom_reward_function.init_kwargs.reward_version='SimpleCot' \
    # custom_reward_function.init_kwargs.iou_threshold=0.5 \


echo "Training is completed. Now merging sharded model..."

# 查找最大的 global_step_x 目录
GLOBAL_STEP_DIR=$(ls ./output/${PROJECT_NAME}/${EXPERIMENT_NAME} | \
    grep -E '^global_step_[0-9]+$' | \
    sed 's/global_step_//' | \
    sort -n | \
    tail -n 1)

if [ -z "$GLOBAL_STEP_DIR" ]; then
    echo "未找到 global_step_x 目录"
    exit 1
fi

GLOBAL_STEP_NAME="global_step_${GLOBAL_STEP_DIR}"
echo "使用的 global_step 目录为: $GLOBAL_STEP_NAME"

# 拷贝权重文件
cp verl/mlm/*.py ./output/${PROJECT_NAME}/${EXPERIMENT_NAME}/${GLOBAL_STEP_NAME}/actor

# 设置合并输出路径
MERGE_OUTPUT_DIR=./output/${PROJECT_NAME}/${EXPERIMENT_NAME}/${EXPERIMENT_NAME}

# 执行合并脚本
python3 scripts/model_merger.py merge \
    --backend fsdp \
    --local_dir ./output/${PROJECT_NAME}/${EXPERIMENT_NAME}/${GLOBAL_STEP_NAME}/actor \
    --target_dir ${MERGE_OUTPUT_DIR}

cp verl/mlm/*.py ${MERGE_OUTPUT_DIR}