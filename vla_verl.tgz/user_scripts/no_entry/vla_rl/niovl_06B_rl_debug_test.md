# NIOVL-06B VLA RL Debug Test 脚本参数文档

> 脚本路径: `user_scripts/no_entry/vla_rl/niovl_06B_rl_debug_test.sh`
>
> 用途: 基于 InternVL3-06B + SiglipVisionModel 的 VLA（Vision-Language-Action）GRPO 强化学习训练，使用 `vla_no_entry_v1` 奖励函数进行轨迹-道路 binding 禁行检测。

---

## 目录

1. [环境变量](#1-环境变量)
2. [命令行参数](#2-命令行参数)
3. [算法配置](#3-算法配置)
4. [数据配置](#4-数据配置)
5. [模型配置](#5-模型配置)
6. [Actor 配置](#6-actor-配置)
7. [FSDP 配置](#7-fsdp-配置)
8. [Rollout 配置](#8-rollout-配置)
9. [Reference Model 配置](#9-reference-model-配置)
10. [Trainer 配置](#10-trainer-配置)
11. [自定义奖励函数配置](#11-自定义奖励函数配置)
12. [脚本内变量](#12-脚本内变量)

---

## 1. 环境变量

| 变量 | 默认值 | 含义 |
|------|--------|------|
| `WANDB_API_KEY` | *(硬编码)* | Weights & Biases API 密钥，用于训练日志上传和实验追踪 |
| `WORK_DIR` | `$HOME` | 工作目录，脚本会检查并修复其 world-writable 权限 |
| `PYTHONPATH` | 自动设置 | Python 模块搜索路径，脚本自动追加项目根目录和 `verl/` 子目录 |

---

## 2. 命令行参数

脚本接受 **1 个** 位置参数:

| 参数 | 位置 | 默认值 | 含义 |
|------|------|--------|------|
| `ENGINE` | `$1` | `vllm` | Rollout 推理引擎名称，对应 `actor_rollout_ref.rollout.name`。可选值: `vllm`（推荐）、`sglang` 等 |

**使用示例:**
```bash
# 使用默认 vllm 引擎
bash niovl_06B_rl_debug_test.sh

# 指定 sglang 引擎
bash niovl_06B_rl_debug_test.sh sglang
```

---

## 3. 算法配置

通过 `python3 -m verl.trainer.main_ppo` 传入，使用 Hydra/OmegaConf 风格的点分隔键:

| 参数 | 值 | 含义 |
|------|-----|------|
| `algorithm.adv_estimator` | `grpo` | 优势估计器类型。`grpo` = Group Relative Policy Optimization |
| `algorithm.use_kl_in_reward` | `False` | 是否将 KL 散度纳入奖励计算。`False` 表示 KL 散度仅作为 loss 项（不混入 reward） |

---

## 4. 数据配置

| 参数 | 值 | 含义 |
|------|-----|------|
| `data.train_files` | `config/idx/260612-no-entry-v1.0_train.json` | 训练数据索引文件路径（JSON 格式，包含 parquet 或图像路径列表） |
| `data.val_files` | `config/idx/260612-no-entry-v1.0_test.json` | 验证数据索引文件路径 |
| `data.train_batch_size` | `1` | 全局 batch size，即每步训练所有 GPU 采样的 prompt 总数（非单卡）。实际训练的 response 总数 = `train_batch_size × rollout.n`。需确保该值 × `rollout.n` 能被总 GPU 数整除 |
| `data.max_prompt_length` | `8192` | prompt 最大 token 长度，超出将被处理（见 `filter_overlong_prompts` 和 `truncation`） |
| `data.max_response_length` | `128` | 模型生成 response 的最大 token 数 |
| `data.filter_overlong_prompts` | `True` | 是否过滤掉超过 `max_prompt_length` 的 prompt |
| `data.truncation` | `'error'` | 截断策略。`'error'` 表示遇到超长序列时抛出错误（而非静默截断） |
| `data.image_key` | `image` | 数据集中图像字段的 key 名称，用于多模态 VLA 任务 |

---

## 5. 模型配置

| 参数 | 值 | 含义 |
|------|-----|------|
| `actor_rollout_ref.model.path` | `/perception-hl/beijin.zhou/ali_data/vla-work-dirs/l2_models/260606_no_entry_repeat_no_cot_pos-20260606-003727` | 预训练模型权重路径（InternVL3-06B 的微调 checkpoint） |
| `actor_rollout_ref.model.use_remove_padding` | `True` | 是否使用 remove-padding（unpadding）优化，将 packed 序列中的 padding 移除以提升吞吐 |
| `actor_rollout_ref.model.trust_remote_code` | `True` | 是否信任模型仓库中的远程代码（HF `trust_remote_code`，加载自定义模型时需要） |
| `actor_rollout_ref.model.enable_gradient_checkpointing` | `True` | 是否启用梯度检查点（gradient checkpointing），以计算换显存 |

---

## 6. Actor 配置

| 参数 | 值 | 含义 |
|------|-----|------|
| `actor_rollout_ref.actor.optim.lr` | `1e-6` | Actor 优化器学习率 |
| `actor_rollout_ref.actor.ppo_mini_batch_size` | `1` | PPO 更新时每个 mini-batch 的样本数。一个 PPO step 内，训练数据会被切分成多个 mini-batch，**每处理完一个 mini-batch 就更新一次参数**（一个 step 内做多次梯度更新） |
| `actor_rollout_ref.actor.ppo_micro_batch_size_per_gpu` | `1` | 单 GPU 上每个 micro-batch 的样本数。当 mini-batch 太大无法一次放入 GPU 显存时，将其切分为更小的 micro-batch，**累积多个 micro-batch 的梯度后再更新参数**。梯度累积步数 = `mini_batch_size / micro_batch_size_per_gpu` |

> **三种 batch size 的层级关系**（数据流）:
>
> ```
> ① data.train_batch_size (全局 prompt 数) × rollout.n
>         = 全局训练样本总数 (response 数)
>           │  分发到各 GPU
>           ▼
> ② 每 GPU 上切分为多个 mini-batch (ppo_mini_batch_size)
>    每处理完一个 mini-batch → 更新一次参数
>           │
>           ▼
> ③ 每个 mini-batch 内部再切分为 micro-batch (ppo_micro_batch_size_per_gpu)
>    累积梯度 → 一个 mini-batch 结束才更新
> ```
>
> 本例中 `train_batch_size=1, rollout.n=2`，总共 2 条 response，单 GPU，三者都是 1，
> 意味着整个 PPO step 只有 1 个 mini-batch、1 个 micro-batch，极度简化——适合 debug。
| `actor_rollout_ref.actor.use_kl_loss` | `True` | 是否在 loss 中使用 KL 散度惩罚项 |
| `actor_rollout_ref.actor.kl_loss_coef` | `0.01` | KL 散度损失系数，控制策略更新幅度约束的强度 |
| `actor_rollout_ref.actor.kl_loss_type` | `low_var_kl` | KL 散度计算类型。`low_var_kl` 使用低方差估计器（如 k3 KL） |
| `actor_rollout_ref.actor.entropy_coeff` | `0` | 熵正则化系数，`0` 表示不添加熵奖励 |

---

## 7. FSDP 配置

| 参数 | 值 | 含义 |
|------|-----|------|
| `actor_rollout_ref.actor.fsdp_config.param_offload` | `False` | Actor 是否将模型参数 offload 到 CPU |
| `actor_rollout_ref.actor.fsdp_config.optimizer_offload` | `False` | Actor 是否将优化器状态 offload 到 CPU |
| `actor_rollout_ref.ref.fsdp_config.param_offload` | `True` | Reference 模型是否将参数 offload 到 CPU（`True` 可节省显存，因为 ref 模型仅做前向推理） |

---

## 8. Rollout 配置

| 参数 | 值 | 含义 |
|------|-----|------|
| `actor_rollout_ref.rollout.log_prob_micro_batch_size_per_gpu` | `1` | Rollout 阶段每 GPU 的 log-prob 计算 micro batch size |
| `actor_rollout_ref.rollout.tensor_model_parallel_size` | `1` | vLLM 张量模型并行度，即几张 GPU 拼在一起跑一个模型实例。`1` = 每张 GPU 独立持有完整模型权重进行推理（不拆分矩阵）。注意：这与 FSDP 数据并行（每 GPU 各有一个模型副本）是两个独立维度，`1` 不是指"只用 1 张 GPU" |
| `actor_rollout_ref.rollout.name` | `$ENGINE`（默认 `vllm`） | Rollout 推理引擎名称 |
| `actor_rollout_ref.rollout.gpu_memory_utilization` | `0.3` | vLLM 的 GPU 显存利用率（`0.3` = 只使用 30%，留给训练显存） |
| `actor_rollout_ref.rollout.enable_chunked_prefill` | `False` | 是否启用 chunked prefill（分块预填充） |
| `actor_rollout_ref.rollout.enforce_eager` | `False` | 是否强制使用 eager 模式（禁用 CUDA graph） |
| `actor_rollout_ref.rollout.free_cache_engine` | `False` | 是否在每次 rollout 后释放 KV cache 引擎 |
| `actor_rollout_ref.rollout.n` | `2` | 每个 prompt 生成多少条 response（GRPO 用于组内相对比较） |
| `+actor_rollout_ref.rollout.limit_images` | `40` | 每次 rollout 最多输入多少张图片（自定义扩展参数，`+` 前缀表示追加到 Hydra config） |
| `+actor_rollout_ref.rollout.limit_videos` | `0` | 每次 rollout 最多输入多少个视频（`0` = 不支持视频输入） |

> **注意**: `limit_images` 和 `limit_videos` 以 `+` 前缀传入，表示这是自定义的配置扩展项，不在 verl 框架的默认 config 中，需要模型代码自行处理。

---

## 9. Reference Model 配置

| 参数 | 值 | 含义 |
|------|-----|------|
| `actor_rollout_ref.ref.log_prob_micro_batch_size_per_gpu` | `1` | Reference 模型每 GPU 的 log-prob 计算 micro batch size |

---

## 10. Trainer 配置

| 参数 | 值 | 含义 |
|------|-----|------|
| `trainer.critic_warmup` | `0` | Critic 模型预热步数（`0` = 无 critic，GRPO 不需要 critic） |
| `trainer.val_before_train` | `False` | 是否在训练开始前先跑一次验证 |
| `trainer.logger` | `['console', 'wandb']` | 日志输出目标列表，同时输出到控制台和 Weights & Biases |
| `trainer.project_name` | `no-entry_VLA-RL-debug` | W&B 项目名称 |
| `trainer.experiment_name` | `NIOVL-06B-vla-no-entry-v1_<timestamp>` | W&B 实验名称（包含时间戳以区分不同运行） |
| `trainer.n_gpus_per_node` | `1` | 每节点使用的 GPU 数量 |
| `trainer.nnodes` | `1` | 节点数量（单机训练） |
| `trainer.save_freq` | `25` | 每隔多少步保存一次 checkpoint |
| `trainer.test_freq` | `0` | 每隔多少步进行一次验证测试（`0` = 不在训练中间进行测试） |
| `trainer.total_epochs` | `1` | 总训练 epoch 数 |

---

## 11. 自定义奖励函数配置

| 参数 | 值 | 含义 |
|------|-----|------|
| `custom_reward_function.path` | `./verl/utils/reward_score/vla_no_entry_v1.py` | 自定义奖励函数 Python 文件路径 |
| `custom_reward_function.name` | `vla_no_entry_reward` | 奖励函数在模块中的函数名 |

### 奖励函数评分规则

该奖励函数进行 **轨迹-道路 binding 禁行检测**，分数 ≤ 0，越高越好:

| 场景 | 分数 | 说明 |
|------|------|------|
| 无禁行路（所有路均可通行） | `0.0` | 场景中不存在禁行道路，跳过评估 |
| 无法解析轨迹（无 `<action>` 标签） | `-4.0` | 模型输出格式错误，无法提取轨迹点 |
| 轨迹过短（< 5 个点） | `-0.5/点` | 轨迹点数不足，按缺少的点数扣分 |
| 正确（未进禁行路、未撞墙） | `0.0` | 轨迹完全合规 |
| 进入禁行路 | `-2.5` | 轨迹段绑定了禁行道路 |
| 撞墙（N 个 unsafe 点） | `-1.0 × N` | 轨迹中存在不安全点（与墙体碰撞） |

---

## 12. 脚本内变量

| 变量 | 值/来源 | 含义 |
|------|---------|------|
| `HOSTFILE` | `/etc/volcano/all.host` | Volcano 调度器写入的集群 host 列表文件 |
| `PORT` | `6379` | Ray 集群通信端口 |
| `HEAD_NODE` | hostfile 第 1 行 | Ray head 节点地址 |
| `NNODES` | `1` | 训练节点数 |
| `GPU_PER_NODE` | `1` | 每节点 GPU 数 |
| `ROLLOUT_IMAGE_LIMIT` | `40` | Rollout 图像数量上限 |
| `ROLLOUT_VIDEO_LIMIT` | `0` | Rollout 视频数量上限 |
| `PROJECT_NAME` | `no-entry_VLA-RL-debug` | W&B 项目名 |
| `EXPERIMENT_NAME` | `NIOVL-06B-vla-no-entry-v1_<timestamp>` | W&B 实验名 |
| `MODEL_PATH` | `/perception-hl/...` | 预训练模型路径 |
| `TRAIN_DATA` | `config/idx/260612-no-entry-v1.0_train.json` | 训练数据索引 |
| `VAL_DATA` | `config/idx/260612-no-entry-v1.0_test.json` | 验证数据索引 |

---

## 集群与运行环境

脚本假定运行在 **Volcano + Ray** 分布式环境中:

1. **Ray 集群初始化**: 从 `/etc/volcano/all.host` 读取所有节点，在 head 节点启动 Ray head，通过 SSH 在 worker 节点启动 Ray worker
2. **Python 环境**: 使用 `.venv2/` 虚拟环境
3. **框架**: verl（基于 Ray + FSDP 的 PPO/GRPO 训练框架）+ vLLM（rollout 推理引擎）

---

## 典型运行流程

```
┌──────────────────────────────────────────────────────┐
│ 1. 环境初始化                                         │
│    - 设置 WANDB_API_KEY、检查 WORK_DIR 权限           │
│    - 激活 Python 虚拟环境                              │
│    - 启动 Ray 集群（head + workers）                   │
│    - 设置 PYTHONPATH                                  │
├──────────────────────────────────────────────────────┤
│ 2. 启动训练 (verl.trainer.main_ppo)                   │
│    - 模型: InternVL3-06B（视觉 + 语言）                │
│    - 算法: GRPO（无需 critic）                         │
│    - 推理: vLLM（gpu_memory_utilization=0.3）          │
│    - 奖励: vla_no_entry_v1（禁行路检测）               │
├──────────────────────────────────────────────────────┤
│ 3. 训练循环                                           │
│    - 采样: 每个 prompt 生成 2 条 response              │
│    - 评分: 自定义奖励函数计算道路合规分数               │
│    - PPO 更新: mini_batch=1, lr=1e-6, KL 约束         │
│    - 保存: 每 25 步 checkpoint                        │
│    - 日志: console + W&B 实时上报                      │
└──────────────────────────────────────────────────────┘
```
