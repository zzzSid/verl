# 消融实验 ↔ 脚本 ↔ 超参数对应关系

> 生成时间: 2026-06-22

---

## 一、共享参数（所有实验固定不变）

以下参数在所有 10 个消融脚本中保持一致，仅列出一份便于查阅。

| 类别 | 参数 | 值 |
|------|------|-----|
| 模型 | 基座模型 | InternVL3-06B + SiglipVisionModel |
| 模型 | 模型路径 (9/10) | `/perception-hl/kai.long/work_dirs/vla_ppu/0612_17w_1Wpseudo_cot_multi-20260612-215425` |
| 模型 | 模型路径 (sft) | `/perception-hl/beijin.zhou/ali_data/vla-work-dirs/l2_models/260616_17w_1Wpseudo_cot_multi_no_entry_repeat_no_cot_pos-20260617-105505` |
| 数据 | 训练数据 | `config/idx/260612-no_entry-rl-v1_train.json` |
| 数据 | 验证数据 | `config/idx/260616-no_entry-easy-test_test.json` |
| 数据 | Train / Val Batch Size | 64 / 64 |
| 数据 | Max Prompt Length | 4096 |
| 数据 | Max Response Length | 32 |
| 硬件 | 节点数 × GPU | 1 node × 8 GPUs (ppu-96g-2t) |
| 硬件 | Image / Video Limit | 35 images, 0 videos |
| 硬件 | Backend | FSDP |
| PPO | Mini / Micro Batch | 32 / 4 per GPU |
| PPO | Entropy Coeff | 0 |
| PPO | KL Loss Type | `low_var_kl` |
| PPO | KL in Reward | False |
| PPO | Critic Warmup | 0 |
| Rollout | n | 8 |
| Rollout | top_k | 20 |
| Rollout | top_p | 0.9 |
| 工程 | Gradient Checkpointing | True |
| 工程 | FSDP Param/Optim Offload | False / False |
| 工程 | Reward Async | True |
| 工程 | Save Freq | 25 |

---

## 二、实验 ↔ 脚本 ↔ 差异化超参数映射

每个实验只有以下 9 个参数 发生变化，其余均为共享参数。

#### 2.1 基本信息

| # | 实验ID | 状态 | 开始时间 | 耗时 | 对应脚本 | 模型初始化 |
|---|--------|------|---------|------|---------|-----------|
| 1 | 810063 | Succeeded | 06-18 10:55 | 9h53m | `-3.sh` | 0612 SFT |
| 2 | 810360 | Succeeded | 06-18 14:50 | 10h15m | `-3-2epoch.sh` (早期版) | 0612 SFT |
| 3 | 810585 | Succeeded | 06-18 17:33 | 10h3m | `-3-gdpo-v2.sh` | 0612 SFT |
| 4 | 810617 | Succeeded | 06-18 17:50 | 1h19m | `-3-gdpo-v2-agg.sh` (早期版) | 0612 SFT |
| 5 | 810763 | Succeeded | 06-18 21:49 | 18h45m | `-3.sh` (重跑) | 0612 SFT |
| 6 | 811039 | Succeeded | 06-19 11:54 | 18h57m | `-3-2epoch.sh` | 0612 SFT |
| 7 | 811045 | Succeeded | 06-19 12:05 | 20h14m | `-3-gdpo-v2-temp0.5.sh` | 0612 SFT |
| 8 | 811050 | Succeeded | 06-19 12:12 | 19h28m | `-3-gdpo-half-agg.sh` | 0612 SFT |
| 9 | 811316 | Succeeded | 06-20 00:50 | 19h51m | `-3-gdpo-v2-kl-agg-2.sh` ⚠️ | 0612 SFT |
| 10 | 811759 | JobInit | 06-21 00:27 | — | `-sft-3-gdpo-half-agg.sh` | 0617 SFT |

#### 2.2 差异化超参数

| # | 实验ID | Algo | Reward | LR | KL Coef | Temp | Epoch | Clip High | Test Freq | Val n |
|---|--------|------|--------|-----|---------|------|-------|-----------|-----------|-------|
| 1 | 810063 | GRPO | v1 | 1e-5 | 0.005 | 0.7 | 1 | 0.3 | 50 | — |
| 2 | 810360 | GRPO | v1 | 1e-6 | 0.01 | 0.7 | 2 | — | 50 | — |
| 3 | 810585 | GDPO | v2 | 1e-6 | 0.01 | 0.7 | 1 | — | 25 | 1 |
| 4 | 810617 | GDPO | v2 | 1e-5 | 0.005 | 0.7 | 2 | 0.3 | 25 | 1 |
| 5 | 810763 | GRPO | v1 | 1e-5 | 0.005 | 0.7 | 1 | 0.3 | 50 | — |
| 6 | 811039 | GRPO | v1 | 1e-6 | 0.01 | 0.7 | 2 | — | 50 | — |
| 7 | 811045 | GDPO | v2 | 1e-6 | 0.01 | 0.5 | 2 | — | 25 | 1 |
| 8 | 811050 | GDPO | v2 | 5e-6 | 0.01 | 0.7 | 2 | — | 25 | 1 |
| 9 | 811316 | GDPO | v2 | 1e-6 | 0.005 | 0.7 | 2 | 0.3 | 25 | 1 |
| 10 | 811759 | GDPO | v2 | 5e-6 | 0.01 | 0.7 | 2 | — | 25 | 1 |

> 标记说明: "—" 表示未显式设置（使用默认值）；"早期版" 表示脚本后被修改用于重跑，当前磁盘版本与实验运行时的参数可能不同。
>
> ⚠️ 811316: 平台实验名为 `kl0_7-agg`（暗示 KL=0.007），但实际对应脚本 `kl-agg-2.sh` 的参数为 KL=0.005, lr=1e-6。前一轮 811223（KL=0.007, lr=1e-5）被取消后，重跑时降低了参数但未更新实验名。

---

## 三、按脚本维度的完整参数矩阵

按脚本文件列出全部差异化参数，每个脚本对应唯一配置。

| 脚本 (简写) | 修改时间 | Algo | Reward | LR | KL | Temp | Epoch | Clip High | Test Freq | Val n | Reward 文件 | 模型路径 |
|-------------|---------|------|--------|-----|-----|------|-------|-----------|-----------|-------|------------|---------|
| `-3.sh` | 06-18 10:54 | GRPO | v1 | 1e-5 | 0.005 | 0.7 | 1 | 0.3 | 50 | — | `vla_no_entry_v1.py` | 0612 SFT |
| `-3-2epoch.sh` | 06-19 11:53 | GRPO | v1 | 1e-6 | 0.01 | 0.7 | 2 | — | 50 | — | `vla_no_entry_v1.py` | 0612 SFT |
| `-3-agg-2epochs.sh` | 06-18 21:48 | GRPO | v1 | 1e-5 | 0.005 | 0.7 | 2 | 0.3 | 25 | — | `vla_no_entry_v1.py` | 0612 SFT |
| `-3-gdpo-v2.sh` | 06-18 16:56 | GDPO | v2 | 1e-6 | 0.01 | 0.7 | 1 | — | 25 | 1 | `vla_no_entry_v2.py` | 0612 SFT |
| `-3-gdpo-v2-agg.sh` | 06-18 21:42 | GDPO | v2 | 1e-5 | 0.005 | 0.7 | 2 | 0.3 | 25 | 1 | `vla_no_entry_v2.py` | 0612 SFT |
| `-3-gdpo-v2-temp0.5.sh` | 06-19 12:04 | GDPO | v2 | 1e-6 | 0.01 | 0.5 | 2 | — | 25 | 1 | `vla_no_entry_v2.py` | 0612 SFT |
| `-3-gdpo-v2-kl-agg.sh` | 06-19 21:35 | GDPO | v2 | 1e-5 | 0.007 | 0.7 | 2 | 0.3 | 25 | 1 | `vla_no_entry_v2.py` | 0612 SFT |
| `-3-gdpo-v2-kl-agg-2.sh` | 06-20 00:49 | GDPO | v2 | 1e-6 | 0.005 | 0.7 | 2 | 0.3 | 25 | 1 | `vla_no_entry_v2.py` | 0612 SFT |
| `-3-gdpo-half-agg.sh` | 06-19 12:11 | GDPO | v2 | 5e-6 | 0.01 | 0.7 | 2 | — | 25 | 1 | `vla_no_entry_v2.py` | 0612 SFT |
| `-sft-3-gdpo-half-agg.sh` | 06-21 00:26 | GDPO | v2 | 5e-6 | 0.01 | 0.7 | 2 | — | 25 | 1 | `vla_no_entry_v2.py` | 0617 SFT |

---

## 四、消融维度对比

### 4.1 按实验维度的差异矩阵

每行是一个实验的实际运行参数，`★` 标记每个维度的最佳实验（基于用户反馈 reward v2 + 高学习率效果最好的结论）。

| 实验ID | 对比维度 | Algo | Reward | LR | KL | Temp | Epoch |
|--------|---------|------|--------|-----|-----|------|-------|
| 810063 | baseline | GRPO | v1 | 1e-5 | 0.005 | 0.7 | 1 |
| 810360 | 降低 LR, 提高 KL, 增加 Epoch | GRPO | v1 | 1e-6 | 0.01 | 0.7 | 2 |
| 810585 | 切换到 GDPO+v2 | GDPO | v2 | 1e-6 | 0.01 | 0.7 | 1 |
| 810617 | 提高 LR, 降低 KL, 增加 Epoch | GDPO | v2 | 1e-5 | 0.005 | 0.7 | 2 |
| 811039 | GRPO+v1 重跑 (降低 LR, 提高 KL) | GRPO | v1 | 1e-6 | 0.01 | 0.7 | 2 |
| 811045 | 降低温度 | GDPO | v2 | 1e-6 | 0.01 | 0.5 | 2 |
| 811050 | 中等学习率 | GDPO | v2 | 5e-6 | 0.01 | 0.7 | 2 |
| 811316 | 低 LR + 低 KL | GDPO | v2 | 1e-6 | 0.005 | 0.7 | 2 |
| 811759 | SFT 初始化 + 中等 LR | GDPO | v2 | 5e-6 | 0.01 | 0.7 | 2 |

### 4.2 被取消的实验（未计入结果）

| 实验ID | 开始时间 | 对应脚本 | Algo | Reward | LR | KL | Temp | Epoch | 取消原因 |
|--------|---------|---------|------|--------|-----|-----|------|-------|---------|
| 810551 | 06-18 17:05 | `-3-gdpo-v2.sh` (早期) | GDPO | v2 | 1e-6 | 0.01 | 0.7 | 1 | 810585 的前序失败尝试 |
| 810746 | 06-18 21:13 | `-3-gdpo-v2-agg.sh` (早期) | GDPO | v2 | — | — | 0.7 | 2 | 810617 后的重跑尝试 |
| 810758 | 06-18 21:42 | `-3-gdpo-v2-agg.sh` | GDPO | v2 | 1e-5 | 0.005 | 0.7 | 2 | 同上 |
| 811223 | 06-19 21:35 | `-3-gdpo-v2-kl-agg.sh` | GDPO | v2 | 1e-5 | 0.007 | 0.7 | 2 | 811316 的前序失败尝试 |

---

## 五、实验演进时间线

```
06-18 10:54  -3.sh 创建
06-18 10:55  ├─ 810063  GRPO+v1+lr1e-5+KL0.005+1epoch ✓ (9h53m)     ← baseline
06-18 14:50  ├─ 810360  GRPO+v1+lr1e-6+KL0.01+2epoch ✓ (10h15m)      ← 降lr增KL增epoch
06-18 16:56  ├─ -3-gdpo-v2.sh 创建
06-18 17:05  ├─ 810551  GDPO+v2+lr1e-6+1epoch ✗ Cancelled
06-18 17:33  ├─ 810585  GDPO+v2+lr1e-6+1epoch ✓ (10h3m)              ← 首次引入 GDPO+v2
06-18 17:50  ├─ 810617  GDPO+v2+lr1e-5+KL0.005+2epoch ✓ (1h19m)      ← 提lr降KL增epoch
06-18 21:13  ├─ 810746  GDPO+v2-agg 重跑 ✗ Cancelled
06-18 21:42  ├─ -3-gdpo-v2-agg.sh 修改
06-18 21:42  ├─ 810758  GDPO+v2-agg 重跑 ✗ Cancelled
06-18 21:48  ├─ -3-agg-2epochs.sh 创建 (未使用)
06-18 21:49  ├─ 810763  GRPO+v1+lr1e-5+KL0.005+1epoch ✓ (18h45m)    ← baseline 重跑
06-19 11:53  ├─ -3-2epoch.sh 修改
06-19 11:54  ├─ 811039  GRPO+v1+lr1e-6+KL0.01+2epoch ✓ (18h57m)      ← 2epoch 重跑
06-19 12:04  ├─ -3-gdpo-v2-temp0.5.sh 创建
06-19 12:05  ├─ 811045  GDPO+v2+lr1e-6+temp0.5+2epoch ✓ (20h14m)     ← 降温度
06-19 12:11  ├─ -3-gdpo-half-agg.sh 创建
06-19 12:12  ├─ 811050  GDPO+v2+lr5e-6+KL0.01+2epoch ✓ (19h28m)      ← 中等lr
06-19 21:35  ├─ -3-gdpo-v2-kl-agg.sh 创建 (KL=0.007, lr=1e-5)
06-19 21:35  ├─ 811223  GDPO+v2+lr1e-5+KL0.007 ✗ Cancelled
06-20 00:49  ├─ -3-gdpo-v2-kl-agg-2.sh 创建 (KL=0.005, lr=1e-6)
06-20 00:50  ├─ 811316  GDPO+v2+lr1e-6+KL0.005+2epoch ✓ (19h51m)     ← 低lr低KL
06-21 00:26  ├─ -sft-3-gdpo-half-agg.sh 创建 (SFT模型)
06-21 00:27  └─ 811759  GDPO+v2+lr5e-6+SFT-init+2epoch ⏳ JobInit    ← 换SFT初始化
```

---

## 六、Reward v1 vs v2 核心差异

Reward 函数是所有实验中最重要的消融维度之一。

| 维度 | v1 (`vla_no_entry_v1.py`) | v2 (`vla_no_entry_v2.py`) |
|------|--------------------------|--------------------------|
| 设计哲学 | 全面惩罚制 (≤0) | 正负奖励混合 (可为正) |
| 无法解析轨迹 | -4.0 | -6.0 (更重) |
| 轨迹过短 | 固定 -3.0 | -(缺失点数)×1.5 (更细粒度) |
| 正确行为 | 0.0 | +2.0 (正激励，仅当碰撞<2) |
| 进入禁行路 | -2.5 | 不直接扣分，但阻断 +2.0 奖励 |
| 撞墙（末端2点） | -1.0/点 | -0.8/点 (更宽容) |
| 撞墙（非末端） | -1.0/点 | -1.0/点 |
| 碰撞≥2 次 | 照常扣分 | 跳过禁行路判断，0.0 (宽恕严重碰撞) |
| 无禁行路场景 | 仅检查撞墙 | 所有分数为 0.0（跳过） |

---

## 七、平台实验名 ↔ 脚本名对应规则

平台实验名格式: `niovl_06B_rl_ablation_{日期}_{配置特征}`

| 实验名片段 | 对应脚本特征 | 含义 |
|-----------|-------------|------|
| `grpo-baseline-3` | `-3.sh` | GRPO baseline (lr=1e-5, KL=0.005, 1epoch) |
| `-2epochs` | `-2epoch.sh` | 训练 2 个 epoch |
| `-gdpo-v2reward` | `-gdpo-v2.sh` | GDPO 算法 + reward v2 |
| `-agg` | `-agg.sh` | 激进配置 (lr=1e-5, 低 KL) |
| `-temp0_5` | `-temp0.5.sh` | 采样温度 0.5 |
| `-half-agg` | `-half-agg.sh` | 半激进 (lr=5e-6) |
| `-kl0_7-agg` | `-kl-agg.sh` | KL=0.007 + 激进 (lr=1e-5) |
| `sft-` | `sft-` | SFT 模型初始化 (0617 SFT) |

---

## 八、未被实验使用的脚本

| 脚本 | 修改时间 | 配置特征 | 说明 |
|------|---------|---------|------|
| `-3-agg-2epochs.sh` | 06-18 21:48 | GRPO+v1+lr1e-5+KL0.005+2epoch+高频验证(test_freq=25) | 无对应 Succeeded 实验 |

该脚本与 `-3.sh` 基线相比：增加 1 个 epoch，提高验证频率（50→25）。可能是为后续对比预留但未提交实验。

---

## 九、关联文档

- [EXPERIMENT_SUMMARY.md](./EXPERIMENT_SUMMARY.md) — 实验设计、结果分析与推荐方向
- 脚本目录: `user_scripts/no_entry/vla_rl/ablation/`
- Reward v1: `verl/utils/reward_score/vla_no_entry_v1.py`
- Reward v2: `verl/utils/reward_score/vla_no_entry_v2.py`
