# NIOVL VLA No-Entry RL Ablation Experiments Summary

> 最后更新: 2026-06-20

## 实验概述

所有实验基于 **NIOVL (InternVL3-06B + SiglipVisionModel)** 在 VLA 禁行检测任务上进行 GRPO/GDPO 强化学习微调。共 9 个实验，系统性地探索了以下维度：

- **Reward 函数**: v1 vs v2
- **算法**: GRPO vs GDPO
- **学习率**: 1e-6 / 5e-6 / 1e-5
- **KL 散度系数**: 0.005 / 0.007 / 0.01
- **训练 Epoch 数**: 1 vs 2
- **采样温度**: 0.5 vs 0.7

---

## 固定配置（所有实验共享）

| 参数 | 值 |
|------|-----|
| 模型路径 | `/perception-hl/kai.long/work_dirs/vla_ppu/0612_17w_1Wpseudo_cot_multi-20260612-215425` |
| 训练数据 | `config/idx/260612-no_entry-rl-v1_train.json` |
| 验证数据 | `config/idx/260616-no_entry-easy-test_test.json` |
| 节点数 / GPU 数 | 1 node × 8 GPUs |
| Image/Video Limit | 35 images, 0 videos |
| Train/Val Batch Size | 64 / 64 |
| Max Prompt Length | 4096 |
| Max Response Length | 32 |
| PPO Mini/Micro Batch | 32 / 4 per GPU |
| Rollout n | 8 |
| Rollout top_k | 20 |
| Rollout top_p | 0.9 |
| Entropy Coeff | 0 |
| KL Loss Type | low_var_kl |
| Gradient Checkpointing | True |
| FSDP Offload | False |
| Critic Warmup | 0 |
| KL in Reward | False |
| Save Freq | 25 |
| Reward Async | True |

---

## 实验对比表

### 关键差异维度

| # | 脚本文件 | Project | Algo | Reward | LR | KL Coef | Clip Ratio | Temp | Epochs | Test Freq | Val n |
|---|---------|---------|------|--------|-----|---------|------------|------|--------|-----------|-------|
| 1 | `niovl_06B_rl_debug_260618-3.sh` | `no-entry_VLA-RL-260618` | **GRPO** | **v1** | **1e-5** | 0.005 | 0.3 | 0.7 | 1 | 50 | - |
| 2 | `niovl_06B_rl_debug_260618-3-2epoch.sh` | `no-entry_VLA-RL-260618` | GRPO | v1 | 1e-6 | 0.01 | - | 0.7 | 2 | 50 | - |
| 3 | `niovl_06B_rl_debug_260618-3-agg-2epochs.sh` | `no-entry_VLA-RL-260618` | GRPO | v1 | 1e-5 | 0.005 | 0.3 | 0.7 | 2 | 25 | - |
| 4 | `niovl_06B_rl_debug_260618-3-gdpo-v2.sh` | `no-entry_VLA-RL-260618_reward_v2` | **GDPO** | **v2** | 1e-6 | 0.01 | - | 0.7 | 1 | 25 | 1 |
| 5 | `niovl_06B_rl_debug_260618-3-gdpo-v2-agg.sh` | `no-entry_VLA-RL-260618_reward_v2` | GDPO | v2 | **1e-5** | 0.005 | 0.3 | 0.7 | 2 | 25 | 1 |
| 6 | `niovl_06B_rl_debug_260618-3-gdpo-v2-temp0.5.sh` | `no-entry_VLA-RL-260618_reward_v2` | GDPO | v2 | 1e-6 | 0.01 | - | **0.5** | 2 | 25 | 1 |
| 7 | `niovl_06B_rl_debug_260618-3-gdpo-v2-kl-agg.sh` | `no-entry_VLA-RL-260618_reward_v2` | GDPO | v2 | 1e-5 | **0.007** | 0.3 | 0.7 | 2 | 25 | 1 |
| 8 | `niovl_06B_rl_debug_260618-3-gdpo-v2-kl-agg-2.sh` | `no-entry_VLA-RL-260618_reward_v2` | GDPO | v2 | 1e-6 | 0.005 | 0.3 | 0.7 | 2 | 25 | 1 |
| 9 | `niovl_06B_rl_debug_260618-3-gdpo-half-agg.sh` | `no-entry_VLA-RL-260618_reward_v2` | GDPO | v2 | **5e-6** | 0.01 | - | 0.7 | 2 | 25 | 1 |

> 注: "-" 表示使用默认值；clip_ratio_high 默认为 0.2，val_kwargs.n 默认为 8（与 rollout n 一致）。

---

## Reward v1 vs v2 核心差异

| 维度 | v1 (惩罚导向) | v2 (奖励导向) |
|------|--------------|--------------|
| 设计哲学 | 全面惩罚制 (≤0) | 正负奖励混合 (可为正) |
| 无法解析轨迹 | -4.0 | **-6.0** (更重) |
| 轨迹过短 | 固定 -3.0 | **-(缺失点数)×1.5** (更细粒度) |
| 正确行为 | 0.0 | **+2.0** (正激励，仅当碰撞<2) |
| 进入禁行路 | -2.5 | 不直接扣分，但阻断 +2.0 奖励 |
| 撞墙（末端2点） | -1.0/点 | **-0.8/点** (更宽容) |
| 撞墙（非末端） | -1.0/点 | -1.0/点 |
| 碰撞≥2 次 | 照常扣分 | **跳过禁行路判断，0.0** (宽恕严重碰撞) |
| 无禁行路场景 | 仅检查撞墙 | 所有分数为 0.0（跳过） |

---

## 实验结果分析（基于现有发现）

### 最佳实验：GDPO + Reward v2 + 高学习率（实验 #5, #7）

用户反馈 **reward v2 + 提高学习率 (1e-5)** 的效果最好。这对应于实验 #5 (`gdpo-v2-agg`) 和 #7 (`gdpo-v2-kl-agg`)。

**关键成功因素**：
1. **Reward v2 的正向激励**：+2.0 的正奖励信号比 v1 的纯惩罚制提供了更强的学习梯度
2. **GDPO 算法**：相比 GRPO，GDPO 在 reward 信号稀疏的场景下更有效
3. **较高学习率 (1e-5)**：在 2 epoch 内提供了足够的更新幅度
4. **适中的 KL 约束 (0.005-0.007)**：防止模型偏离太远，但不至于束缚

### 实验维度对比

| 维度 | 对比 | 趋势 |
|------|------|------|
| Reward | v1 vs v2 | **v2 显著优于 v1** |
| 算法 | GRPO vs GDPO | **GDPO 优于 GRPO**（与 v2 配合） |
| 学习率 | 1e-6 vs 5e-6 vs 1e-5 | **1e-5 效果最好** |
| KL 系数 | 0.005 vs 0.007 vs 0.01 | 0.005-0.007 较好，0.01 偏保守 |
| Epochs | 1 vs 2 | **2 epoch 显著优于 1 epoch** |
| 温度 | 0.5 vs 0.7 | 待进一步对比 |

---

## 实验设计演进路线

```
Baseline (#1) GRPO+v1+lr1e-5+1epoch
  │
  ├─→ (#2) 降低 lr→1e-6, 提高 KL→0.01, 增加 2epochs
  ├─→ (#3) 保持 lr=1e-5, 增加 2epochs + 高测试频率
  │
  └─→ (#4) 切换到 GDPO+v2+lr1e-6+1epoch  ← 首次引入 reward v2
        │
        ├─→ (#5) 提高 lr→1e-5, 降低 KL→0.005, 2epochs ★ 最佳
        ├─→ (#6) 降低 temp→0.5, 2epochs
        ├─→ (#7) KL→0.007 中间值, lr=1e-5, 2epochs ★ 最佳
        ├─→ (#8) 低 lr+低 KL: lr=1e-6, KL=0.005, 2epochs
        └─→ (#9) 中等 lr: lr=5e-6, KL=0.01, 2epochs
```

---

## 推荐新实验

基于以上分析，**当前最佳配置是 GDPO + Reward v2 + lr=1e-5 + KL=0.005-0.007 + 2 epochs**。以下是推荐的后续实验方向：

### 优先级 1：进一步增大学习率 🔥

当前最佳 lr=1e-5，尚未探索更高的学习率。

| 实验 | LR | KL Coef | 理由 |
|------|-----|---------|------|
| **lr=2e-5** | 2e-5 | 0.005 | 在 1e-5 有效的基础上进一步加速收敛 |
| **lr=3e-5** | 3e-5 | 0.01 | 更高 lr 需要更强 KL 约束防止崩溃 |
| **lr=5e-6 + warmup** | 5e-6→1e-5 | 0.005 | 线性 warmup 从 5e-6 到 1e-5 |

### 优先级 2：采样策略消融 🔥

| 实验 | 变更 | 理由 |
|------|------|------|
| **temp=0.3** | temperature=0.3 | 更确定性采样，可能减少噪音 |
| **temp anneal** | temp 0.7→0.3 | 训练中退火温度，前期探索后期利用 |
| **top_k=10** | top_k 从 20→10 | 减少低概率 token 干扰 |
| **n=16** | rollout n=16 | 更多样本可能提供更好的 advantage 估计 |

### 优先级 3：Reward 函数优化 🔥

v2 已经是奖励导向，仍有优化空间：

| 实验 | 变更 | 理由 |
|------|------|------|
| **Reward v3: 分档奖励** | correct: +2.0/+3.0/+5.0 按碰撞次数分档 | 更细粒度的正向激励 |
| **Reward v3: 禁行惩罚回归** | 禁行路也引入小幅负惩罚 (-0.5) | 当前完全不惩罚可能导致边界模糊 |
| **Multi-dim reward weights** | 三个维度加可配置权重 | 灵活调节撞墙 vs 禁行的相对重要性 |

### 优先级 4：训练策略 🔥

| 实验 | 变更 | 理由 |
|------|------|------|
| **3 epochs** | total_epochs=3 | 2 epoch 效果好的情况下看是否能继续提升 |
| **更大的 batch size** | train_batch_size=128 | 更稳定的梯度估计 |
| **clip_ratio 消融** | clip_ratio=0.2 / 0.4 | 当前未系统消融此参数 |
| **启用 entropy bonus** | entropy_coeff=0.001-0.01 | 鼓励模型保持一定的探索多样性 |

### 优先级 5：模型架构与数据

| 实验 | 变更 | 理由 |
|------|------|------|
| **更长的 response** | max_response_length=64 | 当前 32 token 可能限制了轨迹表达 |
| **新验证集评估** | 更难的测试集 | easy-test 可能不能充分区分模型能力 |
| **LoRA 微调** | 使用 LoRA 而非全参数 | 更高效的训练，可能更稳定 |

---

## 建议实验优先级总结

```
强烈推荐（短期）:
  1. lr=2e-5 + KL=0.005 + 2epochs  （对当前最优的进一步加强）
  2. temp annealing 0.7→0.3        （探索→利用的自然过渡）
  3. 3 epochs                      （验证是否还能继续提升）

推荐（中期）:
  4. Reward v3: 分档正奖励          （进一步优化 reward 信号质量）
  5. lr warmup                     （更平滑的训练启动）
  6. n=16 rollout                  （更多采样）

可探索（长期）:
  7. LoRA 微调                     （效率与稳定性）
  8. 更难的验证集                   （评估泛化能力）
  9. 多维度 reward 权重消融         （精细调优）
```
