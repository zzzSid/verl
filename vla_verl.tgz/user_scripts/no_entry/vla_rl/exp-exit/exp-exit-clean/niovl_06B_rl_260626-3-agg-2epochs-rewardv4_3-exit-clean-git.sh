#!/bin/bash

# ============================================================================
# NIOVL (InternVL3-06B with SiglipVisionModel) VLA GRPO — Git Submit 适配版
# Reward: vla_no_entry_v4_3 — 轨迹-道路 binding 禁行检测
#
# 所有重要参数均通过环境变量控制，${VAR:-default} 语法提供默认值。
# 配合 git_submit.sh 使用时，通过 env VAR=value 前缀传入即可覆盖。
#
# 可配置环境变量一览（按类别）：
#
# ── 核心路径 ───────────────────────────────────────────────────────────
#   MODEL_PATH        模型路径
#                     （默认：/perception-hl/kai.long/work_dirs/vla_ppu/0612_17w_1Wpseudo_cot_multi-20260612-215425）
#   TRAIN_DATA_FILES  训练数据，逗号分隔的 JSON 索引文件列表
#                     （默认：config/idx/260626-no_entry-rl_train.json,config/idx/260713-no_entry-exit_mined.json,config/idx/260715-no_entry-exit_mined_pass16.json）
#                     支持本地路径和 s3: 前缀的 NIOFS 路径，s3 文件会自动下载到本地缓存。
#   VAL_DATA_FILES    验证数据，逗号分隔的 JSON 索引文件列表
#                     （默认：config/idx/260626-no_entry-rl_test.json,config/idx/260713-no_entry-exit_mined_test.json）
#                     同样支持 s3: 前缀路径。
#   REWARD_FN_PATH    自定义 reward 函数路径
#                     （默认：./verl/utils/reward_score/vla_no_entry_v4_3.py）
#   REWARD_FN_NAME    自定义 reward 函数名
#                     （默认：vla_no_entry_reward）
#
# ── WandB ───────────────────────────────────────────────────────────────
#   WANDB_API_KEY     WandB API Key（必填，无默认值）
#   PROJECT_NAME      WandB 项目名
#                     （默认：no-entry_VLA-RL-260713）
#   EXP_NAME_PREFIX   WandB 实验名前缀，时间戳自动追加为后缀
#                     （默认：NIOVL-06B-vla-no-entry-260713_reward_v4_3）
#                     最终格式：<EXP_NAME_PREFIX>_<TIMESTAMP>
#
# ── 资源 / 规模 ────────────────────────────────────────────────────────
#   NNODES            节点数（默认：1）
#   GPU_PER_NODE      每节点 GPU 数（默认：16）
#   ENGINE            推理引擎 vllm|sglang（默认：vllm）
#   ROLLOUT_IMAGE_LIMIT  rollout 图片数限制（默认：35）
#   ROLLOUT_VIDEO_LIMIT  rollout 视频数限制（默认：0）
#
# ── 训练超参 ───────────────────────────────────────────────────────────
#   LR                    学习率（默认：1e-5）
#   TRAIN_BATCH_SIZE      训练 batch size（默认：64）
#   VAL_BATCH_SIZE        验证 batch size（默认：64）
#   PPO_MINI_BATCH_SIZE   PPO mini batch size（默认：64）
#   PPO_MICRO_BATCH_GPU   每 GPU micro batch size（默认：4）
#   KL_LOSS_COEF          KL 损失系数（默认：0.005）
#   CLIP_RATIO_HIGH       PPO clip ratio high（默认：0.3）
#   ROLLOUT_N             rollout 采样数 n（默认：8）
#   TEMPERATURE           rollout 温度（默认：0.7）
#   TOP_K                 rollout top_k（默认：20）
#   TOP_P                 rollout top_p（默认：0.9）
#   TOTAL_EPOCHS          训练总 epoch 数（默认：2）
#   SAVE_FREQ             保存频率（默认：50）
#   TEST_FREQ             验证频率（默认：50）
#   MAX_PROMPT_LENGTH     最大 prompt 长度（默认：4096）
#   MAX_RESPONSE_LENGTH   最大 response 长度（默认：32）
#
# ── 运行环境 ───────────────────────────────────────────────────────────
#   WORK_DIR             工作目录（默认：$HOME）
#   HOSTFILE             Ray hostfile 路径（默认：/etc/volcano/all.host）
#   PORT                 Ray 端口（默认：6379）
#   VENV_PATH            Python 虚拟环境路径
#                        （默认：/home/beijin.zhou/mlm-verl/.venv2/bin/activate）
# ============================================================================

set -euo pipefail

# ===========================
# 0. 环境变量默认值
# ===========================

# ── 必填校验 ──
if [[ -z "${WANDB_API_KEY:-}" ]]; then
    echo "❌ 错误：必须设置环境变量 WANDB_API_KEY"
    exit 1
fi

# ── 核心路径 ──
MODEL_PATH="${MODEL_PATH:-/perception-hl/kai.long/work_dirs/vla_ppu/0612_17w_1Wpseudo_cot_multi-20260612-215425}"
TRAIN_DATA_FILES="${TRAIN_DATA_FILES:-config/idx/260626-no_entry-rl_train.json,config/idx/260713-no_entry-exit_mined.json,config/idx/260715-no_entry-exit_mined_pass16.json}"
VAL_DATA_FILES="${VAL_DATA_FILES:-config/idx/260626-no_entry-rl_test.json,config/idx/260713-no_entry-exit_mined_test.json}"
REWARD_FN_PATH="${REWARD_FN_PATH:-./verl/utils/reward_score/vla_no_entry_v4_3.py}"
REWARD_FN_NAME="${REWARD_FN_NAME:-vla_no_entry_reward}"

# ── WandB ──
PROJECT_NAME="${PROJECT_NAME:-no-entry_VLA-RL-260713}"
TIMESTAMP=$(date "+%Y%m%d-%H%M%S")
EXP_NAME_PREFIX="${EXP_NAME_PREFIX:-NIOVL-06B-vla-no-entry-260713_reward_v4_3}"
EXPERIMENT_NAME="${EXP_NAME_PREFIX}_${TIMESTAMP}"

# ── 资源 / 规模 ──
NNODES="${NNODES:-1}"
GPU_PER_NODE="${GPU_PER_NODE:-16}"
ENGINE="${ENGINE:-vllm}"
ROLLOUT_IMAGE_LIMIT="${ROLLOUT_IMAGE_LIMIT:-35}"
ROLLOUT_VIDEO_LIMIT="${ROLLOUT_VIDEO_LIMIT:-0}"

# ── 训练超参 ──
LR="${LR:-1e-5}"
TRAIN_BATCH_SIZE="${TRAIN_BATCH_SIZE:-64}"
VAL_BATCH_SIZE="${VAL_BATCH_SIZE:-64}"
PPO_MINI_BATCH_SIZE="${PPO_MINI_BATCH_SIZE:-64}"
PPO_MICRO_BATCH_GPU="${PPO_MICRO_BATCH_GPU:-4}"
KL_LOSS_COEF="${KL_LOSS_COEF:-0.005}"
CLIP_RATIO_HIGH="${CLIP_RATIO_HIGH:-0.3}"
ROLLOUT_N="${ROLLOUT_N:-8}"
TEMPERATURE="${TEMPERATURE:-0.7}"
TOP_K="${TOP_K:-20}"
TOP_P="${TOP_P:-0.9}"
TOTAL_EPOCHS="${TOTAL_EPOCHS:-2}"
SAVE_FREQ="${SAVE_FREQ:-50}"
TEST_FREQ="${TEST_FREQ:-50}"
MAX_PROMPT_LENGTH="${MAX_PROMPT_LENGTH:-4096}"
MAX_RESPONSE_LENGTH="${MAX_RESPONSE_LENGTH:-32}"

# ── 运行环境 ──
WORK_DIR="${WORK_DIR:-$HOME}"
HOSTFILE="${HOSTFILE:-/etc/volcano/all.host}"
PORT="${PORT:-6379}"
VENV_PATH="${VENV_PATH:-/home/beijin.zhou/mlm-verl/.venv2/bin/activate}"

# ===========================
# 1. 打印配置摘要
# ===========================
echo "=============================================="
echo "🚀 NIOVL VLA RL — Git Submit 适配版"
echo "=============================================="
echo "核心路径："
echo "  MODEL_PATH        = ${MODEL_PATH}"
echo "  TRAIN_DATA_FILES  = ${TRAIN_DATA_FILES}"
echo "  VAL_DATA_FILES    = ${VAL_DATA_FILES}"
echo "  (支持 local / hdfs:// / s3: 路径，s3 文件自动缓存到本地)"
echo "  REWARD_FN_PATH    = ${REWARD_FN_PATH}"
echo "  REWARD_FN_NAME    = ${REWARD_FN_NAME}"
echo "WandB："
echo "  PROJECT_NAME      = ${PROJECT_NAME}"
echo "  EXPERIMENT_NAME   = ${EXPERIMENT_NAME}"
echo "资源："
echo "  NNODES            = ${NNODES}"
echo "  GPU_PER_NODE      = ${GPU_PER_NODE}"
echo "  ENGINE            = ${ENGINE}"
echo "  ROLLOUT_IMAGE_LIMIT = ${ROLLOUT_IMAGE_LIMIT}"
echo "训练超参："
echo "  LR                = ${LR}"
echo "  TRAIN_BATCH_SIZE  = ${TRAIN_BATCH_SIZE}"
echo "  TOTAL_EPOCHS      = ${TOTAL_EPOCHS}"
echo "  KL_LOSS_COEF      = ${KL_LOSS_COEF}"
echo "  ROLLOUT_N         = ${ROLLOUT_N}"
echo "  SAVE_FREQ         = ${SAVE_FREQ}"
echo "  TEST_FREQ         = ${TEST_FREQ}"
echo "=============================================="

# ===========================
# 2. 环境准备
# ===========================
echo "WORK_DIR: $WORK_DIR"
CURRENT_PERM=$(stat -c "%a" "$WORK_DIR")
OTHER_PERM=$((CURRENT_PERM % 10))
if (( OTHER_PERM & 2 )); then
    echo "warning: WORK_DIR=$WORK_DIR is world writable, removing it!!"
    chmod o-w "$WORK_DIR"
    NEW_PERM=$(stat -c "%a" "$WORK_DIR")
    if [ $NEW_PERM -ne $CURRENT_PERM ]; then
        echo "world writable is removed"
        echo "new HOME permission: $NEW_PERM"
    else
        echo "Error: can't remove world writable permission."
    fi
else
    echo "WORK_DIR=$WORK_DIR is not world writable."
fi

source "${VENV_PATH}"
ray stop --force

# ===========================
# 3. Ray 集群启动
# ===========================
hosts=()
while read -r line; do
    host=$(echo "$line" | cut -d' ' -f1)
    hosts+=("$host")
done < "$HOSTFILE"

HEAD_NODE=${hosts[0]}

echo "[Ray Cluster] Head node: $HEAD_NODE"
ray start --head --port=$PORT --node-ip-address=$HEAD_NODE --include-dashboard=false

for ((i = 1; i < ${#hosts[@]}; i++)); do
    node=${hosts[i]}
    echo "[Ray Cluster] Starting worker on $node"
    ssh $node "cd $PWD; source .venv2/bin/activate; ray start --address=${HEAD_NODE}:${PORT} --node-ip-address=$node --include-dashboard=false"
done

echo "[Ray Cluster] Initiation Successfully Completed. Now running training process..."

sleep 5

# ===========================
# 4. 启动训练
# ===========================
export PYTHONPATH=$(pwd)
export PYTHONPATH="${PYTHONPATH}:$(pwd)/verl"

set -x

python3 -m verl.trainer.main_ppo \
    algorithm.adv_estimator=grpo \
    data.train_files="[${TRAIN_DATA_FILES}]" \
    data.val_files="[${VAL_DATA_FILES}]" \
    data.train_batch_size=${TRAIN_BATCH_SIZE} \
    data.val_batch_size=${VAL_BATCH_SIZE} \
    data.max_prompt_length=${MAX_PROMPT_LENGTH} \
    data.max_response_length=${MAX_RESPONSE_LENGTH} \
    data.filter_overlong_prompts=True \
    data.truncation='error' \
    data.image_key=image \
    actor_rollout_ref.model.path=${MODEL_PATH} \
    actor_rollout_ref.actor.optim.lr=${LR} \
    actor_rollout_ref.model.use_remove_padding=True \
    actor_rollout_ref.actor.ppo_mini_batch_size=${PPO_MINI_BATCH_SIZE} \
    actor_rollout_ref.actor.ppo_micro_batch_size_per_gpu=${PPO_MICRO_BATCH_GPU} \
    actor_rollout_ref.actor.use_kl_loss=True \
    actor_rollout_ref.actor.kl_loss_coef=${KL_LOSS_COEF} \
    actor_rollout_ref.actor.kl_loss_type=low_var_kl \
    actor_rollout_ref.actor.entropy_coeff=0 \
    actor_rollout_ref.actor.clip_ratio_high=${CLIP_RATIO_HIGH} \
    actor_rollout_ref.model.trust_remote_code=True \
    actor_rollout_ref.model.enable_gradient_checkpointing=True \
    actor_rollout_ref.actor.fsdp_config.param_offload=False \
    actor_rollout_ref.actor.fsdp_config.optimizer_offload=False \
    actor_rollout_ref.rollout.log_prob_micro_batch_size_per_gpu=${PPO_MICRO_BATCH_GPU} \
    actor_rollout_ref.rollout.tensor_model_parallel_size=1 \
    actor_rollout_ref.rollout.name=${ENGINE} \
    actor_rollout_ref.rollout.gpu_memory_utilization=0.7 \
    actor_rollout_ref.rollout.enable_chunked_prefill=False \
    actor_rollout_ref.rollout.enforce_eager=False \
    actor_rollout_ref.rollout.free_cache_engine=False \
    actor_rollout_ref.rollout.temperature=${TEMPERATURE} \
    actor_rollout_ref.rollout.top_k=${TOP_K} \
    actor_rollout_ref.rollout.top_p=${TOP_P} \
    actor_rollout_ref.rollout.n=${ROLLOUT_N} \
    +actor_rollout_ref.rollout.limit_images=${ROLLOUT_IMAGE_LIMIT} \
    +actor_rollout_ref.rollout.limit_videos=${ROLLOUT_VIDEO_LIMIT} \
    actor_rollout_ref.ref.log_prob_micro_batch_size_per_gpu=${PPO_MICRO_BATCH_GPU} \
    actor_rollout_ref.ref.fsdp_config.param_offload=False \
    algorithm.use_kl_in_reward=False \
    trainer.critic_warmup=0 \
    trainer.val_before_train=True \
    trainer.logger=['console','wandb'] \
    trainer.project_name=${PROJECT_NAME} \
    trainer.experiment_name=${EXPERIMENT_NAME} \
    trainer.n_gpus_per_node=${GPU_PER_NODE} \
    trainer.nnodes=${NNODES} \
    trainer.save_freq=${SAVE_FREQ} \
    trainer.test_freq=${TEST_FREQ} \
    trainer.total_epochs=${TOTAL_EPOCHS} \
    custom_reward_function.path=${REWARD_FN_PATH} \
    custom_reward_function.name=${REWARD_FN_NAME} \
    reward_model.launch_reward_fn_async=True \
    actor_rollout_ref.rollout.val_kwargs.n=1

set +x

# ============================================================
# 5. 合并 FSDP checkpoint 并补全模型文件
# ============================================================
OUTPUT_DIR="./output/${PROJECT_NAME}/${EXPERIMENT_NAME}"
# 获取最新的 global step
GLOBAL_STEP_NAME="global_step_$(cat "${OUTPUT_DIR}/latest_checkpointed_iteration.txt")"
CKPT_DIR="${OUTPUT_DIR}/${GLOBAL_STEP_NAME}/actor"
MERGE_OUTPUT_DIR="${OUTPUT_DIR}/${EXPERIMENT_NAME}"

echo "Latest checkpoint: ${GLOBAL_STEP_NAME}"
echo "Merging from: ${CKPT_DIR}"
echo "Merging to: ${MERGE_OUTPUT_DIR}"

python3 scripts/model_merger.py merge \
    --backend fsdp \
    --local_dir "${CKPT_DIR}" \
    --target_dir "${MERGE_OUTPUT_DIR}"

echo "Copying model Python files to ${MERGE_OUTPUT_DIR}..."
# 拷贝 verl/mlm/niovl 下的 Python 模型文件，与源模型目录保持一致
cp -v verl/mlm/niovl/__init__.py              "${MERGE_OUTPUT_DIR}/"
cp -v verl/mlm/niovl/configuration_niovl.py   "${MERGE_OUTPUT_DIR}/"
cp -v verl/mlm/niovl/modeling_niovl.py        "${MERGE_OUTPUT_DIR}/"
cp -v verl/mlm/conversation.py                "${MERGE_OUTPUT_DIR}/"
cp -rv verl/mlm/niovl/adaptor                 "${MERGE_OUTPUT_DIR}/"
cp -rv verl/mlm/niovl/qwen2                   "${MERGE_OUTPUT_DIR}/"
cp -rv verl/mlm/niovl/siglip                  "${MERGE_OUTPUT_DIR}/"

echo "Merge completed. HuggingFace model saved to: ${MERGE_OUTPUT_DIR}"
ls -la "${MERGE_OUTPUT_DIR}"

echo "Training completed."
