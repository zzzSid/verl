#!/bin/bash

# NIOVL (InternVL3-06B with SiglipVisionModel) VLA GRPO 调试脚本
# Reward: vla_no_entry_v1 — 轨迹-道路 binding 禁行检测

export WANDB_API_KEY=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
ray stop --force
WORK_DIR=${WORK_DIR:-$HOME}
echo "WORK_DIR: $WORK_DIR"
CURRENT_PERM=$(stat -c "%a" "$WORK_DIR")
OTHER_PERM=$((CURRENT_PERM % 10))
if (( OTHER_PERM & 2 )); then
    echo "warning: WORK_DIR=$WORK_DIR is world writable, removing it!!"
    chmod o-w "$WORK_DIR"
    NEW_PERM=$(stat -c "%a" "$WORK_DIR")
    if [ $NEW_PERM -ne $CURRENT_PERM ]; then
        echo "world writable is removed"
        echo "new HOME permission: $NEW_PERM"
    else
        echo "Error: can't remove world writable permission."
    fi
else
    echo "WORK_DIR=$WORK_DIR is not world writable."
fi

source .venv2/bin/activate

HOSTFILE=/etc/volcano/all.host
PORT=6379

# 解析 hostfile
hosts=()
while read -r line; do
    host=$(echo "$line" | cut -d' ' -f1)
    hosts+=("$host")
done < "$HOSTFILE"

HEAD_NODE=${hosts[0]}

echo "[Ray Cluster] Head node: $HEAD_NODE"
ray start --head --port=$PORT --node-ip-address=$HEAD_NODE --include-dashboard=false

for ((i = 1; i < ${#hosts[@]}; i++)); do
    node=${hosts[i]}
    echo "[Ray Cluster] Starting worker on $node"
    ssh $node "cd $PWD; source .venv2/bin/activate; ray start --address=${HEAD_NODE}:${PORT} --node-ip-address=$node --include-dashboard=false"
done

echo "[Ray Cluster] Initiation Successfully Completed. Now running training process..."

sleep 5

export PYTHONPATH=$(pwd)
export PYTHONPATH="${PYTHONPATH}:$(pwd)/verl"

set -x
ENGINE=${1:-vllm}

TIMESTAMP=$(date "+%Y%m%d-%H%M%S")
PROJECT_NAME="no-entry_VLA-RL-260617"
EXPERIMENT_NAME="NIOVL-06B-vla-no-entry-260617_${TIMESTAMP}"

MODEL_PATH="/perception-hl/kai.long/work_dirs/vla_ppu/0612_17w_1Wpseudo_cot_multi-20260612-215425"

TRAIN_DATA="config/idx/260612-no_entry-rl-v1_train.json"
VAL_DATA="config/idx/260616-no_entry-easy-test_test.json"

NNODES=1
GPU_PER_NODE=16
ROLLOUT_IMAGE_LIMIT=35
ROLLOUT_VIDEO_LIMIT=0

python3 -m verl.trainer.main_ppo \
    algorithm.adv_estimator=grpo \
    data.train_files=$TRAIN_DATA \
    data.val_files=$VAL_DATA \
    data.train_batch_size=64 \
    data.val_batch_size=64 \
    data.max_prompt_length=4096 \
    data.max_response_length=32 \
    data.filter_overlong_prompts=True \
    data.truncation='error' \
    data.image_key=image \
    actor_rollout_ref.model.path=$MODEL_PATH \
    actor_rollout_ref.actor.optim.lr=1e-6 \
    actor_rollout_ref.model.use_remove_padding=True \
    actor_rollout_ref.actor.ppo_mini_batch_size=32 \
    actor_rollout_ref.actor.ppo_micro_batch_size_per_gpu=4 \
    actor_rollout_ref.actor.use_kl_loss=True \
    actor_rollout_ref.actor.kl_loss_coef=0.01 \
    actor_rollout_ref.actor.kl_loss_type=low_var_kl \
    actor_rollout_ref.actor.entropy_coeff=0 \
    actor_rollout_ref.model.trust_remote_code=True \
    actor_rollout_ref.model.enable_gradient_checkpointing=True \
    actor_rollout_ref.actor.fsdp_config.param_offload=False \
    actor_rollout_ref.actor.fsdp_config.optimizer_offload=False \
    actor_rollout_ref.rollout.log_prob_micro_batch_size_per_gpu=4 \
    actor_rollout_ref.rollout.tensor_model_parallel_size=1 \
    actor_rollout_ref.rollout.name=$ENGINE \
    actor_rollout_ref.rollout.gpu_memory_utilization=0.7 \
    actor_rollout_ref.rollout.enable_chunked_prefill=False \
    actor_rollout_ref.rollout.enforce_eager=False \
    actor_rollout_ref.rollout.free_cache_engine=False \
    actor_rollout_ref.rollout.temperature=0.7 \
    actor_rollout_ref.rollout.top_k=20 \
    actor_rollout_ref.rollout.top_p=0.9 \
    actor_rollout_ref.rollout.n=8 \
    +actor_rollout_ref.rollout.limit_images=$ROLLOUT_IMAGE_LIMIT \
    +actor_rollout_ref.rollout.limit_videos=$ROLLOUT_VIDEO_LIMIT \
    actor_rollout_ref.ref.log_prob_micro_batch_size_per_gpu=4 \
    actor_rollout_ref.ref.fsdp_config.param_offload=False \
    algorithm.use_kl_in_reward=False \
    trainer.critic_warmup=0 \
    trainer.val_before_train=True \
    trainer.logger=['console','wandb'] \
    trainer.project_name=$PROJECT_NAME \
    trainer.experiment_name=$EXPERIMENT_NAME \
    trainer.n_gpus_per_node=$GPU_PER_NODE \
    trainer.nnodes=$NNODES \
    trainer.save_freq=25 \
    trainer.test_freq=50 \
    trainer.total_epochs=1 \
    custom_reward_function.path=./verl/utils/reward_score/vla_no_entry_v1.py \
    custom_reward_function.name=vla_no_entry_reward\
    reward_model.launch_reward_fn_async=True


# ============================================================
# 合并 FSDP checkpoint 并补全模型文件
# ============================================================
OUTPUT_DIR="./output/${PROJECT_NAME}/${EXPERIMENT_NAME}"
# 获取最新的 global step
GLOBAL_STEP_NAME="global_step_$(cat "${OUTPUT_DIR}/latest_checkpointed_iteration.txt")"
CKPT_DIR="${OUTPUT_DIR}/${GLOBAL_STEP_NAME}/actor"
MERGE_OUTPUT_DIR="${OUTPUT_DIR}/${EXPERIMENT_NAME}"

echo "Latest checkpoint: ${GLOBAL_STEP_NAME}"
echo "Merging from: ${CKPT_DIR}"
echo "Merging to: ${MERGE_OUTPUT_DIR}"

python3 scripts/model_merger.py merge \
    --backend fsdp \
    --local_dir "${CKPT_DIR}" \
    --target_dir "${MERGE_OUTPUT_DIR}"

echo "Copying model Python files to ${MERGE_OUTPUT_DIR}..."
# 拷贝 verl/mlm/niovl 下的 Python 模型文件，与源模型目录保持一致
cp -v verl/mlm/niovl/__init__.py              "${MERGE_OUTPUT_DIR}/"
cp -v verl/mlm/niovl/configuration_niovl.py   "${MERGE_OUTPUT_DIR}/"
cp -v verl/mlm/niovl/modeling_niovl.py        "${MERGE_OUTPUT_DIR}/"
cp -v verl/mlm/conversation.py                "${MERGE_OUTPUT_DIR}/"
cp -rv verl/mlm/niovl/adaptor                 "${MERGE_OUTPUT_DIR}/"
cp -rv verl/mlm/niovl/qwen2                   "${MERGE_OUTPUT_DIR}/"
cp -rv verl/mlm/niovl/siglip                  "${MERGE_OUTPUT_DIR}/"

echo "Merge completed. HuggingFace model saved to: ${MERGE_OUTPUT_DIR}"
ls -la "${MERGE_OUTPUT_DIR}"

echo "Training completed."
