# verl PPO/GRPO 训练日志指标详解

> 适用于 `verl.trainer.main_ppo` 训练时控制台输出的 W&B 风格日志行。

---

## 目录

1. [序列长度与负载均衡](#1-序列长度与负载均衡-global_seqlen)
2. [Actor 训练指标](#2-actor-训练指标)
3. [Critic 与奖励信号](#3-critic-与奖励信号)
4. [Response / Prompt 长度](#4-response--prompt-长度)
5. [各阶段耗时](#5-各阶段耗时-timing)
6. [性能与吞吐](#6-性能与吞吐-perf)
7. [训练全局状态](#7-训练全局状态-training)

---

## 1. 序列长度与负载均衡 (`global_seqlen`)

这些指标反映数据在各 GPU 上的分布是否均匀。训练时会把 batch 内所有样本按 token 数做 balanced partition，让每张卡处理的总 token 数尽量接近。

| 指标 | 含义 |
|------|------|
| `global_seqlen/min` | 所有 GPU 中，处理 token 数最少的 GPU 的 token 总量 |
| `global_seqlen/max` | 所有 GPU 中，处理 token 数最多的 GPU 的 token 总量 |
| `global_seqlen/minmax_diff` | max - min 的差值。越小说明负载越均衡 |
| `global_seqlen/balanced_min` | 经过 sequence balancing 重分配后，最少 GPU 的 token 数 |
| `global_seqlen/balanced_max` | 经过 sequence balancing 重分配后，最多 GPU 的 token 数 |
| `global_seqlen/mean` | 所有 GPU 的平均 token 数 |

**如何判断**：
- `minmax_diff` 越小越好，理想情况趋近于 0
- `balanced_min ≈ balanced_max` 说明负载均衡算法生效
- 如果差异很大（几千～几万），说明样本长度差异悬殊，某些 GPU 会空等

---

## 2. Actor 训练指标

### 2.1 损失函数

| 指标 | 含义 |
|------|------|
| `actor/pg_loss` | Policy Gradient Loss — PPO 的代理目标函数。训练的核心 loss，驱动策略向高 advantage 方向更新。非零即有学习信号 |
| `actor/kl_loss` | KL 散度损失值（未乘系数）。如果是 `low_var_kl`，用的是低方差 KL 估计器（k3 估计器），比原始 KL 更稳定 |
| `actor/kl_coef` | 当前生效的 KL 惩罚系数（对应配置 `kl_loss_coef`，如 0.01） |
| `actor/ppo_kl` | `kl_loss × kl_coef` 的乘积，即实际加到总 loss 中的 KL 惩罚量 |
| `actor/entropy_loss` | 策略熵。越高表示模型输出分布越均匀（探索性强）；越低表示模型越确定（收敛）。训练初期高、逐步下降是正常的 |
| `actor/lr` | 当前 actor 的学习率。注意：日志显示的是浮点数，`1e-6` 会显示为 `0.000`，不代表 lr=0 |

### 2.2 PPO Clip

| 指标 | 含义 |
|------|------|
| `actor/pg_clipfrac` | PPO clip 触发比例。importance sampling ratio `π_new / π_old` 超出 `[1-ε, 1+ε]` 范围被截断的 token 占比。**0 表示 ratio 全在安全范围内**，策略变化温和；**> 0.1~0.2** 说明策略更新幅度大，PPO 的 trust region 在起约束作用 |
| `actor/pg_clipfrac_lower` | 仅统计 ratio 低于 `1-ε`（即新策略概率大幅降低）的 clip 比例。帮助区分 clip 的方向 |

**如何判断**：
- `clipfrac = 0`：第一步正常。如果持续为 0 且 `pg_loss` 也很小，可能是 lr 太小或 advantage 太小
- `clipfrac ∈ [0.01, 0.15]`：健康的 PPO 训练范围
- `clipfrac > 0.2`：策略更新太激进，考虑降低 lr 或增大 `kl_loss_coef`

### 2.3 梯度

| 指标 | 含义 |
|------|------|
| `actor/grad_norm` | 梯度全局范数（所有参数梯度的 L2 范数）。用于监控梯度爆炸/消失。**正常范围 0.1~10**，太大 → 梯度爆炸（考虑 gradient clipping），太小 → 梯度消失 |

---

## 3. Critic 与奖励信号

> 注意：GRPO 没有 critic，这些字段名保留自 PPO。GRPO 中 `critic/score` 实际是 reward，`advantages` 是 group-relative advantage。

### 3.1 Score / Reward

| 指标 | 含义 |
|------|------|
| `critic/score/mean` | 所有 response 的平均奖励分数 |
| `critic/score/max` | 最高奖励分数（本 step 最佳轨迹） |
| `critic/score/min` | 最低奖励分数（本 step 最差轨迹） |
| `critic/rewards/mean` | 与 score 相同，rewards = score 经 KL 惩罚等处理后（`use_kl_in_reward=False` 时两者一致） |
| `critic/rewards/max` | 最大 reward |
| `critic/rewards/min` | 最小 reward |

**如何判断**：
- `score/mean` 应该随训练**逐步上升**（趋近 0 或正值）
- `score/max` 应保持有满分（表明模型有能力产出正确答案）
- `score/min` 如果始终很低，考虑过滤掉 reward 极差的样本或检查数据质量
- 如果均值始终不变，可能是 lr 太小或 reward 函数区分度不够

### 3.2 Advantage / Return

| 指标 | 含义 |
|------|------|
| `critic/advantages/mean` | 优势函数均值。**理论上应 ≈ 0**（GRPO 组内归一化后均值为 0） |
| `critic/advantages/max` | 最大 advantage — 该条 response 比组内平均好多少 |
| `critic/advantages/min` | 最小 advantage — 该条 response 比组内平均差多少 |
| `critic/returns/mean` | Return 的均值。PPO 中 `return = advantage + value`；GRPO 中 return = advantage（无 value baseline） |

**如何判断**：
- `advantages/mean ≈ 0`：GRPO 组内归一化正常工作
- `advantages/max - advantages/min`：组内区分度，越大说明 reward 区分越明显

---

## 4. Response / Prompt 长度

| 指标 | 含义 |
|------|------|
| `response_length/mean` | 模型生成长度的平均值（token 数） |
| `response_length/max` | 最长生成 |
| `response_length/min` | 最短生成 |
| `response_length/clip_ratio` | 生成被 `max_response_length` 截断的比例。**> 0 说明有输出被打断**，可能需要增大 `max_response_length` |
| `prompt_length/mean` | prompt 平均长度 |
| `prompt_length/max` | 最长 prompt |
| `prompt_length/min` | 最短 prompt |
| `prompt_length/clip_ratio` | prompt 被截断的比例。**> 0 说明有 prompt 超长**，检查 `max_prompt_length` 或数据 |

**如何判断**：
- `clip_ratio = 0` → 长度限制合理
- `clip_ratio > 0.05` → 有信息丢失，需调整 `max_*_length`

---

## 5. 各阶段耗时 (`timing`)

每个 PPO step 分为多个阶段，计时可以帮助定位瓶颈。

| 指标 | 含义 | 典型占比建议 |
|------|------|-------------|
| `timing_s/gen` | vLLM 生成 response 的耗时 | 10-40% |
| `timing_s/reward` | 计算奖励函数的耗时。如果用了复杂的 reward（如渲染、路径规划），会很大 | 1-20% |
| `timing_s/old_log_prob` | 用 actor 模型重算生成 token 的 log_prob（得到 `old_log_probs`）。**含 ViT 前向**，多模态模型尤其慢 | 15-40% |
| `timing_s/ref` | 用 reference 模型算 log_prob（用于 KL 惩罚）。如果 ref 做了 CPU offload，额外包含 CPU→GPU 数据传输 | 10-25% |
| `timing_s/adv` | 计算 advantage（GRPO 组内归一化）。纯数学运算，通常很快 | ~0% |
| `timing_s/update_actor` | 所有 mini-batch 的 forward + backward + 参数更新总耗时。**含 ViT 前向** | 20-40% |
| `timing_s/step` | **一个完整 PPO step 的总耗时** = 以上各项之和 | 100% |

### 5.1 每 token 耗时

| 指标 | 含义 |
|------|------|
| `timing_per_token_ms/ref` | ref 模型每 token 处理耗时（毫秒） |
| `timing_per_token_ms/update_actor` | actor 更新阶段每 token 处理耗时 |
| `timing_per_token_ms/gen` | vLLM 生成每 token 耗时 |
| `timing_per_token_ms/adv` | advantage 计算每 token 耗时 |

---

## 6. 性能与吞吐 (`perf`)

| 指标 | 含义 |
|------|------|
| `perf/mfu/actor` | Model FLOPs Utilization — GPU 实际算力利用率。**接近 1.0 说明 GPU 在高效做矩阵乘**；由于 FSDP 通信开销、小 batch 等，通常在 0.3-0.6 |
| `perf/max_memory_allocated_gb` | PyTorch `torch.cuda.max_memory_allocated()` — 实际分配的峰值 GPU 显存（GB） |
| `perf/max_memory_reserved_gb` | PyTorch `torch.cuda.max_memory_reserved()` — CUDA 预留的峰值显存（含缓存池，通常 > allocated） |
| `perf/cpu_memory_used_gb` | 进程使用的 CPU 内存（GB）。ref 模型 offload + 数据加载等 |
| `perf/total_num_tokens` | 本 step 处理的总 token 数（所有 GPU 之和，prompt + response） |
| `perf/time_per_step` | 同上 `timing_s/step`，一个 PPO step 的秒数 |
| `perf/throughput` | 吞吐量 = `total_num_tokens / time_per_step`（token/秒）。衡量整体训练速度的核心指标 |

**如何判断**：
- `throughput` 越高越好。优化方向：增大 batch（显存允许）、减少 `old_log_prob`/`ref` 的 micro batch 切分、提高 `gpu_memory_utilization`
- `max_memory_allocated_gb` 接近 GPU 物理显存 → 有 OOM 风险，需要减小参数
- `mfu` 偏低 (< 0.2) → GPU 大量时间在等通信或数据，可能是 batch 太小或序列太短

---

## 7. 训练全局状态 (`training`)

| 指标 | 含义 |
|------|------|
| `training/global_step` | 当前训练步数（从 0 开始），`step=1` 表示已经完成了 1 步完整的 Rollout + Update |
| `training/epoch` | 当前训练 epoch 数。`epoch = global_step / total_steps_per_epoch`，数值可能为浮点数 |

---

## 速查表：正常 vs. 异常

| 现象 | 可能原因 | 建议 |
|------|---------|------|
| `score/mean` 不上升 | lr 太小、reward 区分度不足、模型已收敛 | 检查 reward 函数，增大 lr |
| `pg_clipfrac` 持续为 0 | lr 太小、advantage 接近 0 | 增大 lr，检查 reward 设计 |
| `pg_clipfrac > 0.3` | 策略更新太激进 | 降低 lr，增大 kl_coef |
| `grad_norm > 100` | 梯度爆炸 | 降低 lr，检查数据是否有异常 |
| `grad_norm < 0.001` | 梯度消失 | 增大 lr |
| `kl_loss` 快速增长 | 策略偏离参考模型严重 | 增大 kl_coef，或降低 lr |
| `entropy_loss` 快速降到 0 | 策略过早收敛，丧失探索 | 增大 entropy_coeff |
| `response_length/clip_ratio > 0` | 模型输出太长 | 增大 `max_response_length` |
| `max_memory_allocated_gb` ≈ GPU 显存 | 面临 OOM 风险 | 减 micro batch，开 offload |
| `global_seqlen/minmax_diff` 很大 | 数据长度差异大，负载不均 | 检查数据预处理，考虑动态 bsz |
| `throughput` 骤降 | 某阶段变慢 | 细化 `timing_s/*` 定位瓶颈 |

---

## 本训练（step 1）关键数值解读

```
score/mean: -2.39     ← 多数轨迹有禁行违规，RL 训练的优化方向正确
entropy: 2.937        ← 第一步，策略还在探索阶段
kl_loss: 0.004        ← 接近参考模型，正常
pg_clipfrac: 0.000    ← 第一步，策略变化很小
grad_norm: 3.17       ← 梯度健康
max_memory: 95GB      ← 高但未 OOM
throughput: 1118 t/s  ← 可作为后续优化 baseline
step 总耗时: 323s     ← ViT 处理 140 张图/样本是主因
```
