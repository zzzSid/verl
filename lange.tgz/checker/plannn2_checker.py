import logging

import torch
from tqdm import tqdm
from torchpilot.utils.cfg_parser import PyConfig
from torchpilot.utils.stopwatch import stopwatch
from torchpilot.utils.registries import DATALOADER
from torchpilot.utils.registries import EVALUATOR
from torchpilot.data.dataloader.tp_dataloader import TPDataLoader
from torchpilot.evaluator.base_evaluator import BaseEvaluator

from tpp_onemodel.data.dataset.plannn2_dataset import Plannn2Dataset, _load_data

logger = logging.getLogger(__name__)

class Plannn2Checker():
    def __init__(
        self,
        cfg: PyConfig,
        skip_exception: bool = False,
        *args,
        **kwargs,

    ):
        self._cfg = cfg
        self.dataset_kwargs = self._cfg['infer_task_flow']['dataset_kwargs']
        # Init dataloader and evaluator
        self._build_dataloader()
        self._build_evaluator()
        self._stopwatch = stopwatch

        self._skip_exception = skip_exception

    def _build_dataloader(self) -> None:
        """Build dataloader."""
        self._dataloader = DATALOADER.build(self._cfg.infer_dataloader)
        if not isinstance(self._dataloader, TPDataLoader):
            raise ValueError(
                f"Expect type(self._dataloader)=TPDataLoader, "
                f"but got {type(self._dataloader)}."
            )
        self._sample_num_per_gpu = self._dataloader.get_sample_num_per_gpu()
        self._sample_per_epoch = self._dataloader.get_sample_per_epoch()
        self._one_epoch_size = self._dataloader.get_one_epoch_step_per_gpu()
        self._bs_per_gpu = self._dataloader.get_batch_size_per_gpu()

    @property
    def one_epoch_size(self):
        return self._one_epoch_size

    def _build_evaluator(self) -> None:
        """Build evaluator."""
        self._evaluator = EVALUATOR.build(self._cfg.evaluator)
        if not isinstance(self._evaluator, BaseEvaluator):
            raise ValueError(
                f"Expect type(self._evaluator)=BaseEvaluator, "
                f"but got {type(self._evaluator)}."
            )

    @staticmethod
    def get_gt_env_closed(v3_ceph,
                       use_timestamps,
                       sim_ts,
                       ego_trans,
                       eval_mode=False,
                       **kwargs):
        data = _load_data(v3_ceph)
        sim_index = kwargs["history_size"] - 1 + sim_ts
        static_idx = use_timestamps[sim_index]
        sim_pose = data[static_idx]["car_pose"]
        item = Plannn2Dataset.get_one_sample_closed(
            data, use_timestamps, sim_ts, sim_pose, ego_trans, eval_mode,
            **kwargs)

        return item
    
    def forward_eval(self, batch_data, task_type, task_name="", tqdm_disable=False):
        if task_type == "highway":
            return self.forward_eval_highway(batch_data, task_name, tqdm_disable)
        elif task_type == "urban":
            return self.forward_eval_urban(batch_data, task_name, tqdm_disable)
        else:
            raise Exception("Unknow task_type in Plannn2Checker.forward_eval")
    
    def forward_eval_highway(self, batch_data, task_name="", tqdm_disable=False):
        self._stopwatch.set_time_cost_prefix(task_name)
        self._stopwatch.tic("ddp_cost")

        history_size = self.dataset_kwargs["history_size"]
        replan_time = self.dataset_kwargs["replan_time"]

        polygon = batch_data["ego_polygon"]
        polyline = batch_data["ego_polyline"]
        polymask = batch_data["ego_polymask"]
        property = batch_data["ego_property"]
        label = batch_data["ego_labels"]
        turnlightsignal = batch_data["turnlightsignal"]
        raw_data = [i[0] for i in batch_data["cpu_data"]["raw_data"]]

        _input_polygon = polygon[:, :history_size]
        _input_polyline = polyline[:, :history_size]
        _input_polymask = polymask[:, :history_size]
        _input_property = property[:, :history_size]

        raw_env_list_gt = []
        raw_env_list_gt.extend([raw_data] * (history_size + replan_time))

        pred_polygons = polygon[:, history_size:]
        pred_propertys = property[:, history_size:]
        pred_label = label[:, history_size:]
        # turnlightsignal_pred = turnlightsignal[:, history_size:]

        max_time = raw_data[0]["max_time"]

        # pred_long_trajs = []
        closedloop_simu_time = (max_time - history_size) // replan_time
        for sim_time in tqdm(
                range(closedloop_simu_time), desc=f"sim_time progress", position=1, leave=False, disable=tqdm_disable):
            # 获取下一帧环境
            kwargs = self.dataset_kwargs
            new_raw_data_gt = []
            for data_idx in range(polygon.shape[0]):
                gt_env = Plannn2Checker.get_gt_env_closed(
                    raw_env_list_gt[0][data_idx]["v3_ceph"],
                    raw_env_list_gt[0][data_idx]["use_timestamps"],
                    (sim_time + 1) * replan_time,
                    raw_env_list_gt[0][data_idx]["ego_trans"],
                    eval_mode=True,
                    **kwargs,
                )
                new_raw_data_gt.append(gt_env[-1])

            if sim_time < closedloop_simu_time - 1:
                raw_env_list_gt.extend([new_raw_data_gt] * replan_time)
        res = dict(
            {
                "pred_label": pred_label,
                "pred_polygons": pred_polygons,
                "pred_propertys": pred_propertys,
                "closedloop_simu_time": closedloop_simu_time,
                "_input_polygon": _input_polygon,
                "_input_polyline": _input_polyline,
                "_input_polymask": _input_polymask,
                "_input_property": _input_property,
                "raw_env_list": list(map(list, zip(*raw_env_list_gt))),
                "raw_env_list_gt": list(map(list, zip(*raw_env_list_gt))),
                # "turnlightsignal_pred": turnlightsignal_pred
            }
        )


        self._stopwatch.record_time_cost("ddp_cost", None)
        self._stopwatch.reset_time_cost_prefix()

        return res

    def forward_eval_urban(self, batch_data, task_name="", tqdm_disable=False):
        self._stopwatch.set_time_cost_prefix(task_name)
        self._stopwatch.tic("ddp_cost")

        history_size = self.dataset_kwargs["history_size"]
        env_block_size = self.dataset_kwargs["env_block_size"]
        history_state_size = self.dataset_kwargs["history_state_size"]
        replan_time = self.dataset_kwargs["replan_time"]

        # for i in range(batch_size):
        polygon = batch_data["polygon"]
        polyline = batch_data["polyline"]
        polymask = batch_data["polymask"]
        property = batch_data["property"]
        label = batch_data["label"]
        # turnlightsignal = batch_data.get("turnlightsignal")
        raw_data = [i[0] for i in batch_data["cpu_data"]["raw_data"]]

        drop_ind = env_block_size + history_state_size  # 360+15*16=600
        _input_polygon = polygon[:, :drop_ind]
        _input_polyline = polyline[:, :drop_ind]
        _input_polymask = polymask[:, :drop_ind]
        _input_property = property[:, :drop_ind]

        raw_env_list_gt = []
        raw_env_list_gt.extend([raw_data] * (history_size + replan_time))

        pred_polygons = polygon[:, drop_ind:]
        pred_propertys = property[:, drop_ind:]
        pred_label = label[:, history_state_size:]
        # turnlightsignal_pred = turnlightsignal[:, history_state_size:] if turnlightsignal is not None else None

        max_time = raw_data[0]["max_time"]

        # pred_long_trajs = []
        closedloop_simu_time = (max_time - history_size) // replan_time
        for sim_time in tqdm(
                range(closedloop_simu_time), desc=f"sim_time progress", position=1, leave=False, disable=tqdm_disable):
            # 获取下一帧环境
            kwargs = self.dataset_kwargs
            new_raw_data_gt = []
            for data_idx in range(polygon.shape[0]):
                gt_env = Plannn2Checker.get_gt_env_closed(
                    raw_env_list_gt[0][data_idx]["v3_ceph"],
                    raw_env_list_gt[0][data_idx]["use_timestamps"],
                    (sim_time + 1) * replan_time,
                    raw_env_list_gt[0][data_idx]["ego_trans"],
                    eval_mode=True,
                    **kwargs,
                )
                new_raw_data_gt.append(gt_env[-1])

            if sim_time < closedloop_simu_time - 1:
                raw_env_list_gt.extend([new_raw_data_gt] * replan_time)
        res = dict(
            {
                "pred_label": pred_label,
                "pred_polygons": pred_polygons,
                "pred_propertys": pred_propertys,
                "closedloop_simu_time": closedloop_simu_time,
                "_input_polygon": _input_polygon,
                "_input_polyline": _input_polyline,
                "_input_polymask": _input_polymask,
                "_input_property": _input_property,
                "raw_env_list": list(map(list, zip(*raw_env_list_gt))),
                "raw_env_list_gt": list(map(list, zip(*raw_env_list_gt))),
                # "turnlightsignal_pred": turnlightsignal_pred
            }
        )


        self._stopwatch.record_time_cost("ddp_cost", None)
        self._stopwatch.reset_time_cost_prefix()

        return res


class Plannn2InferChecker(Plannn2Checker):
    def __init__(
        self,
        cfg: PyConfig,
        skip_exception: bool = False,
        *args,
        **kwargs,

    ):
        super().__init__(cfg, skip_exception, *args, **kwargs)
        self._build_ddp_taskflow()
    
    def _build_ddp_taskflow(self):
        from torchpilot.utils.registries import TASK_FLOW
        from torchpilot.model.task.tp_task_flow import TPTaskFlow
        from torchpilot.runner.inferrer.tp_inferrer import InferType

        self._taskflow = TASK_FLOW.build(self._cfg['infer_task_flow'])
        if not isinstance(self._taskflow, TPTaskFlow):
            raise ValueError(f"Expect type(self._model)=TPTaskFlow, but got {type(self._model)}.")

        cur_device = torch.cuda.current_device()
        self._taskflow = self._taskflow.cuda(device=cur_device)
        # self._model.module = self._model
    
    def load_model_file(
        self,
        ckpt_path: str,
    ) -> None:
        """Load ckpt or resume ckpt.

        Args:
            ckpt_path (str): Path to checkpoint.
        """
        from torchpilot.utils.checkpoint_manager import CheckpointManager
        CheckpointManager(
            model=self._taskflow,
            optimizer=None,
            lr_scheduler=None,
            scaler=None,
            save_dir=None,
            pretrain_model=ckpt_path,
            resume=False,
            to_cuda=self._cfg.infer_ckpt.to_cuda,
            ckpt2model_json=self._cfg.infer_ckpt.ckpt2model_json,
            trace_mode=False,
        ).load_model()

    def forward_eval(self, batch_data, task_type, task_name="", tqdm_disable=False):
        return self._taskflow.forward_model_rl(batch_data)