# MetaActionManager 使用说明

## 概述

`MetaActionManager` 是一个用于检测碰撞风险（快要碰撞）的类，与 `MetaActionManager` 配合使用。

## 功能特点

- **两类分类**：只区分"有碰撞风险"和"无碰撞风险"
- **多维度检测**：同时考虑前方和侧方来车
- **多目标类型**：检测车辆和VRU（易受伤害道路使用者，如行人、骑车人等）
- **基于TTC**：使用碰撞时间（Time To Collision）和安全距离进行判断

## 关键参数

```python
# 检测距离阈值
FRONT_RISK_DISTANCE = 15.0       # 前方风险检测距离（米）
SIDE_RISK_DISTANCE = 12.0        # 侧方风险检测距离（米）

# TTC阈值
TTC_FRONT_THRESHOLD = 5.0        # 前方碰撞时间阈值（秒）
TTC_SIDE_THRESHOLD = 4.0         # 侧方碰撞时间阈值（秒）

# 安全距离
SAFETY_DISTANCE_FRONT = 8.0      # 前方安全距离（米）
SAFETY_DISTANCE_SIDE = 5.0       # 侧方安全距离（米）
```

## 标签定义

```python
LABEL_NO_RISK = 0    # 无碰撞风险
LABEL_RISK = 1       # 有碰撞风险（包含前方和侧方）
```

## 使用方式

### 1. 在 Dataset 中自动处理

修改后的 `Plannn2DatasetMA.__getitem__` 会自动处理碰撞检测：

```python
# 在 __getitem__ 中
meta_action_manager = MetaActionManager(data, clip_id=f"{idx:08d}", enable_viz=False)
clip_motion_status = meta_action_manager.process(dataset_kwargs=self.kwargs)

collision_manager = MetaActionManager(data, clip_id=f"{idx:08d}", enable_viz=False)
clip_collision_status = collision_manager.process(dataset_kwargs=self.kwargs)

# 合并结果
for ts, motion_status, collision_status in zip(timestamps, clip_motion_status, clip_collision_status):
    motion_status["collision"] = collision_status["collision"]
    data[ts]["motion_status"] = motion_status
```

### 2. 获取碰撞标签

在 `get_one_sample` 中，碰撞标签可以通过以下方式获取：

```python
# 获取当前帧的碰撞状态
cur_collision_status = frame_motion_status[origin_idx].get("collision", 0)
collision_label = MetaActionManager.COLLISION_LABELS_MAP.get(cur_collision_status, 0)

# 碰撞标签存储在 raw_env 中
raw_env["collision_label"] = collision_label
raw_env["collision_gt_labels"] = collision_gt_label_list[self.history_size:]
```

### 3. 单独使用

```python
from tpp_onemodel.data.dataset.plannn2_dataset_utils.meta_action_manager import (
    MetaActionManager,
)

# 创建实例
collision_manager = MetaActionManager(data, clip_id="clip_001", enable_viz=False)

# 处理数据
collision_status_list = collision_manager.process()

# 获取结果
for status in collision_status_list:
    ts = status["timestamp"]
    collision_label = status["collision"]  # 0=无风险, 1=有风险
```

## 检测逻辑

### 前方风险检测
1. 障碍物在检测距离内（15米）
2. 相对角度小于30度（正前方范围）
3. TTC小于阈值（5秒）或距离小于安全距离（8米）且正在接近

### 侧方风险检测
1. 障碍物在检测距离内（12米）
2. 相对角度在30-150度范围内（侧方范围）
3. TTC小于阈值（4秒）或距离小于安全距离（5米）且有接近趋势

### 合并逻辑
- 如果检测到前方风险或侧方风险，统一返回 `LABEL_RISK = 1`
- 如果没有检测到任何风险，返回 `LABEL_NO_RISK = 0`

## 与其他标签的关系

碰撞标签的编码方式：
```python
collision_label = collision_label + self.num_classes + MetaActionManager.LONGITUDE_LABEL_NUM + MetaActionManager.LATITUDE_LABEL_NUM
```

这样可以确保碰撞标签与原有的纵向、横向标签不冲突。

## 注意事项

1. **数据格式**：
   - `ego_motion` 格式：`[vx, vy, acc_x, acc_y, yaw, yaw_rate, whlag, whlagspd, vehspd, lgta, chassis_yawrate, gear]`
     - 速度：索引 0-1 (vx, vy)
     - Yaw角：索引 4
   - `dynamic_dets` 格式：`[x, y, z, l, w, h, yaw, class_id, special_class_id, track_id, source, prob]`
     - Yaw角：索引 6
     - 类别ID：索引 7
     - 速度：索引 10-11 (vx, vy)

2. **类别过滤**：检测目标包括：
   - 车辆类别（class_id 在 `VEHICLE_CLASS_IDS` 列表中）
   - VRU类别（class_id 在 `VRU_CLASS_IDS` 列表中，包括行人、骑车人等）

   如需调整VRU类别ID，请修改 `VRU_CLASS_IDS` 列表。

3. **坐标系**：所有计算都在自车坐标系下进行。

4. **角度计算**：使用自车和障碍物的 yaw 角计算相对位置角度，用于判断前方或侧方来车。

## 可配置参数

### 类别ID配置
```python
# 车辆类别
VEHICLE_CLASS_IDS = [0, 1, 2, 3, 4, 5, 6, 7]

# VRU类别（根据实际数据集调整）
VRU_CLASS_IDS = [8, 9, 10, 11, 12]
```

### 检测距离配置
- 前方检测距离：15米
- 侧方检测距离：12米
- 可根据实际需求调整 `FRONT_RISK_DISTANCE` 和 `SIDE_RISK_DISTANCE`

## 修改的文件

1. `tpp_onemodel/data/dataset/plannn2_dataset_utils/meta_action_manager.py`
   - 添加了 `MetaActionManager` 类

2. `tpp_onemodel/data/dataset/plannn2_dataset_meta_action.py`
   - 修改了 `__getitem__` 以集成碰撞检测
   - 修改了 `get_one_sample` 以处理碰撞标签
