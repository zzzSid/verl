# -*- coding: utf-8 -*-
"""Test astra planner data utils."""

import pytest
from torchpilot.utils.cfg_parser import PyConfig

from tpp_onemodel.tools.astra_planner.data.data_utils.astra_planner_dataset_utils import (
    PlannerDatasetUtils,
)


@pytest.mark.skip(reason="data deleted")
def test_astra_data_utils(planner_config_path):
    """Test astra data utils."""
    config = PyConfig.fromfile(planner_config_path)
    data_path_test = config.infer_dataloader.dataset_cfg.datasets_cfg.astra_planner.meta_file.astra_planner.cicd_test
    dataset = PlannerDatasetUtils(data_path_test, load_all_frames=True)

    dataset_length = len(dataset)
    iter_num = 10 if dataset_length > 10 else dataset_length

    for idx in range(iter_num):
        clip = dataset[idx]
        for idx_f, frame in enumerate(clip):
            if idx_f > 50:
                break
            assert frame is not None


if __name__ == "__main__":
    pytest.main([__file__])
