# -*- coding: utf-8 -*-
"""Test ProfileStopwatch."""
import time

import pytest

from tpp_onemodel.utils.stopwatch import ProfileStopwatch


def test_profile_stopwatch():
    """Test profile stopwatch."""
    profile_stopwatch = ProfileStopwatch(
        stopwatch_name="ProfileStopwatch",
        barrier_before_stopwatch=True,
    )

    profile_stopwatch.tic()
    time.sleep(1)
    profile_stopwatch.record_time_cost("Code1")
    time.sleep(2)
    profile_stopwatch.record_time_cost("Code2")
    profile_stopwatch.log_time_cost()
    profile_stopwatch.reset()

    for _ in range(2):
        time.sleep(1)
        profile_stopwatch.record_time_cost("Code1")
        time.sleep(2)
        profile_stopwatch.record_time_cost("Code2")
    profile_stopwatch.log_time_cost()
    profile_stopwatch.reset()


if __name__ == "__main__":
    pytest.main([__file__])
