# -*- coding: utf-8 -*-
"""Unit tests for nn3 history-traj data transform and loss."""

import numpy as np
import pytest
import torch

from tpp_onemodel.data.plannn3.nn3_history_traj_utils import compute_speed_gap_label
from tpp_onemodel.data.plannn3.nn3_history_traj_utils import pack_history_traj_for_clip
from tpp_onemodel.data.transform.plannn3_transform import Plannn3HistoryTrajPackTransform
from tpp_onemodel.model.loss.plannn3_multimodal_loss import Plannn3MultimodalLoss


def test_compute_speed_gap_label():
    assert compute_speed_gap_label(60.0, 80.0) == 4
    assert compute_speed_gap_label(-1.0, 80.0) == -1
    assert compute_speed_gap_label(60.0, -1.0) == -1


def test_history_traj_pack_transform_pads_to_min_four():
    sidecar = {
        "history_traj_pack": {
            "his_traj_next_waypoint": np.zeros((2, 3), dtype=np.float32),
            "egos_his_mask": np.ones((2,), dtype=np.float32),
            "speed_gap": np.array([3], dtype=np.int64),
        }
    }
    data = {"raw_data": [{"nn3_sidecar": sidecar}, {"nn3_sidecar": sidecar}]}
    out = Plannn3HistoryTrajPackTransform(min_waypoints=4)(data)
    assert out["his_traj_next_waypoint"].shape == (2, 4, 3)
    assert out["egos_his_mask"].shape == (2, 4)
    assert out["speed_gap"].tolist() == [3, 3]


def test_history_traj_loss_ignores_invalid_label():
    loss_fn = Plannn3MultimodalLoss(hist_traj_ce_weight=0.1)
    logits = torch.randn(2, 1, 10)
    model_outputs = {
        "logits": torch.randn(2, 3, 1792),
        "history_traj_logits": logits,
    }
    model_inputs = {
        "ego_labels": torch.randint(0, 1792, (2, 3)),
        "speed_gap": torch.tensor([2, -1]),
    }
    loss_dict = loss_fn(model_outputs, model_inputs)
    assert "history_traj_ce_loss" in loss_dict


def test_pack_history_traj_for_clip_empty_poses():
    pack = pack_history_traj_for_clip({}, [1000], 0, 0, 80.0)
    assert pack["his_traj_next_waypoint"].shape[0] >= 4
    assert pack["speed_gap"][0] == -1
