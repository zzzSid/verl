# -*- coding: utf-8 -*-
"""TorchPilot-Plus-OneModel pytest fixture."""

import os

import pytest
import torch
from torchpilot.utils.plus_manager import load_plus


@pytest.fixture(scope="session", autouse=True)
def _session_init():
    """Session init."""
    load_plus()
    torch.distributed.init_process_group(
        backend="nccl",
        init_method="tcp://localhost:9999",
        world_size=1,
        rank=0,
    )
    torch.cuda.empty_cache()


@pytest.fixture()
def planner_config_path() -> str:
    """Generate planner config path."""
    return os.path.join(
        "experiments",
        "task_planner",
        "exp_planner_release",
        "cfg_planner.py",
    )


@pytest.fixture()
def astra_planner_singletask_config_path() -> str:
    """Generate singletask config path of astra planner."""
    return os.path.join(
        "experiments",
        "task_planner",
        "exp_planner_release",
        "cfg_planner_astra_planner_trainval.py",
    )


@pytest.fixture()
def astra_planner_stage2_singletask_config_path() -> str:
    """Generate singletask config path of astra planner."""
    return os.path.join(
        "experiments",
        "task_planner",
        "exp_planner_release",
        "cfg_planner_astra_planner_stage2_trainval.py",
    )


@pytest.fixture()
def goal_point_planner_singletask_config_path() -> str:
    """Generate singletask config path of goal point planner."""
    return os.path.join(
        "experiments",
        "task_planner",
        "exp_planner_release",
        "cfg_planner_goal_point_planner_trainval.py",
    )


@pytest.fixture()
def plannn2_config_path() -> str:
    """Generate plannn2 config path."""
    return os.path.join(
        "experiments",
        "task_planner",
        "exp_plannn2",
        "cfg_plannn2.py",
    )


@pytest.fixture()
def plannn2_rl_config_path() -> str:
    """Generate plannn2 config path."""
    return os.path.join(
        "experiments",
        "task_planner",
        "exp_plannn2",
        "cfg_plannn2_rl.py",
    )


@pytest.fixture()
def prediction_singletask_config_path() -> str:
    """Generate singletask config path of prediction."""
    return os.path.join(
        "experiments",
        "task_planner",
        "exp_planner_release",
        "cfg_planner_prediction_trainval.py",
    )


@pytest.fixture()
def planner_trace_config_path() -> str:
    """Generate planner config path."""
    return os.path.join(
        "experiments",
        "task_planner",
        "exp_planner_release",
        "cfg_planner_trace.py",
    )


@pytest.fixture()
def plannn2_trace_config_path() -> str:
    """Generate planner config path."""
    return os.path.join(
        "experiments",
        "task_planner",
        "exp_plannn2",
        "cfg_plannn2_trace.py",
    )


@pytest.fixture()
def planner_trace_stage2_config_path() -> str:
    """Generate singletask config path of astra planner."""
    return os.path.join(
        "experiments",
        "task_planner",
        "exp_planner_release",
        "cfg_planner_astra_planner_stage2_trace.py",
    )


@pytest.fixture()
def planner_trace_stage2_ar_config_path() -> str:
    """Generate singletask config path of astra planner."""
    return os.path.join(
        "experiments",
        "task_planner",
        "exp_planner_release",
        "cfg_planner_astra_planner_stage2_ar_trace.py",
    )


@pytest.fixture()
def astra_planner_ar_singletask_config_path() -> str:
    """Generate singletask config path of astra planner."""
    return os.path.join(
        "experiments",
        "task_planner",
        "exp_planner_release",
        "cfg_planner_ar_trainval.py",
    )


@pytest.fixture()
def astra_planner_ar_singletask_finetune_config_path() -> str:
    """Generate singletask config path of astra planner."""
    return os.path.join(
        "experiments",
        "task_planner",
        "exp_planner_release",
        "cfg_planner_ar_finetune.py",
    )


@pytest.fixture()
def astra_planner_ar_singletask_close_train_config_path() -> str:
    """Generate singletask config path of astra planner."""
    return os.path.join(
        "experiments",
        "task_planner",
        "exp_planner_release",
        "cfg_planner_ar_close_train.py",
    )


@pytest.fixture()
def plannn2_trace_config_path() -> str:
    """Plannn2 config path."""
    return os.path.join(
        "experiments",
        "task_planner",
        "exp_plannn2",
        "cfg_plannn2_trace.py",
    )


@pytest.fixture()
def plannn2_trace_ckpt_path() -> str:
    """Plannn2 config path."""
    return os.path.join(
        "/share-global",
        "AIP",
        "nioml",
        "ad-cn-hlidc-aip-experiment",
        "Perception-Visual-Dynamic",
        "prod",
        "experiment",
        "745067/task_planner/exp_plannn2/pre_w0408",
        "ckpt/checkpoint_last.pth.tar",
    )


@pytest.fixture()
def plannn2_trace_save_path() -> str:
    """Plannn2 config path."""
    return "./export_models/onnx_model_dynamic_fp16_tmp"
