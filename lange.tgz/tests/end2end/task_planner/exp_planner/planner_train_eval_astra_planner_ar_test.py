# -*- coding: utf-8 -*-
# flake8: noqa
# pylint: disable=line-too-long.
"""Planner train & eval one batch test."""

from copy import deepcopy
from datetime import datetime

import pytest
import torch
from torch.nn.parallel.distributed import DistributedDataParallel
from torchpilot.optimizer.base_optimizer import build_optimizer
from torchpilot.utils.cfg_parser import PyConfig
from torchpilot.utils.file_manager import FileManager
from torchpilot.utils.log_manager import log_file_init
from torchpilot.utils.registries import DATALOADER
from torchpilot.utils.registries import EVALUATOR
from torchpilot.utils.registries import TASK_FLOW


@pytest.mark.skip("No longer support.")
def test_task_astra_planner_ar_dataloader_taskflow_train_forward_backward_one_step(
    astra_planner_ar_singletask_config_path,
):
    """Test dataloader taskflow run one step."""
    cfg = PyConfig.fromfile(astra_planner_ar_singletask_config_path)
    # Init fake config.
    torch.cuda.empty_cache()
    FileManager.init(
        cfg_path=astra_planner_ar_singletask_config_path,
        run_name=f'{datetime.now().strftime("%H_%M_%S")}_planner',
    )

    dataloader_cfg = deepcopy(cfg.dataloader)
    dataloader_cfg["num_workers"] = 1
    dataloader_cfg["batch_size"] = 1
    dataloader_cfg["persistent_workers"] = False
    dataloader_cfg.dataset_cfg.mode = "cicd_train"
    task_flow_cfg = deepcopy(cfg.task_flow)
    dataloader_instance = DATALOADER.build(dataloader_cfg)
    task_flow_instance = TASK_FLOW.build(task_flow_cfg)
    optimizer_cfg = deepcopy(cfg.optimizer)
    optimizer_cfg.params_policy = task_flow_instance.get_optim_policies()
    optimizer_cfg.lr = cfg.trainer["lr_per_sample"] * dataloader_cfg["batch_size"]
    optimizer_instance = build_optimizer(**optimizer_cfg)

    task_flow_instance.cuda()
    task_flow_instance = DistributedDataParallel(task_flow_instance, device_ids=[0], find_unused_parameters=True)

    dataloader_instance.set_state(epoch=0)
    multi_task_batch_data = dataloader_instance.get_batch_data()
    for _, batch_data in multi_task_batch_data.items():
        model_outputs, losses = task_flow_instance(batch_data)
        print(losses)
        loss_vars = {}
        for loss_name, loss_value in losses.items():
            if isinstance(loss_value, torch.Tensor):
                loss_vars[loss_name] = loss_value.mean()
            elif isinstance(loss_value, list):
                loss_vars[loss_name] = sum(_loss.mean() for _loss in loss_value)
            elif isinstance(loss_value, dict):
                loss_vars = {}
                for _loss_n, _loss_v in loss_value.items():
                    loss_vars[f"{loss_name}/{_loss_n}"] = _loss_v.mean()
            else:
                raise TypeError(f"{loss_name}: {type(loss_value)} is not a tensor or list of tensors")
        loss = sum(_value for _key, _value in loss_vars.items() if "loss" in _key)
        loss.backward()

    optimizer_instance.step()
    task_flow_instance.zero_grad()
    optimizer_instance.zero_grad()

    del task_flow_instance
    del dataloader_instance
    del optimizer_instance
    del batch_data
    del model_outputs
    del losses
    del loss_vars
    del loss
    torch.cuda.empty_cache()


@pytest.mark.skip("No longer support.")
def test_task_astra_planner_ar_dataloader_taskflow_evaluator_infer_one_step(
    astra_planner_ar_singletask_config_path,
):
    """Test dataloader taskflow evaluator inter one step."""
    cfg = PyConfig.fromfile(astra_planner_ar_singletask_config_path)
    # Init fake config.
    torch.cuda.empty_cache()
    FileManager.init(
        cfg_path=astra_planner_ar_singletask_config_path,
        run_name=f'{datetime.now().strftime("%H_%M_%S")}_planner',
    )
    log_file_init("torchpilot", 0)

    dataloader_cfg = deepcopy(cfg.infer_dataloader)
    dataloader_cfg["num_workers"] = 1
    dataloader_cfg["batch_size"] = 1
    dataloader_cfg["persistent_workers"] = False
    dataloader_cfg.dataset_cfg.mode = "cicd_test"
    task_flow_cfg = deepcopy(cfg.infer_task_flow)
    evaluator_cfg = deepcopy(cfg.evaluator)
    dataloader_instance = DATALOADER.build(dataloader_cfg)
    task_flow_instance = TASK_FLOW.build(task_flow_cfg)
    evaluator_instance = EVALUATOR.build(evaluator_cfg)
    evaluator_instance.set_zero()

    task_flow_instance.cuda()
    task_flow_instance = DistributedDataParallel(task_flow_instance, device_ids=[0])

    task_flow_instance.eval()
    dataloader_instance.set_state(epoch=0)
    multi_task_batch_data = dataloader_instance.get_batch_data()
    for _, batch_data in multi_task_batch_data.items():
        with torch.no_grad():
            model_outputs = task_flow_instance(batch_data)
        eval_results = evaluator_instance.eval(model_outputs, batch_data)
        evaluator_instance.dist_all_reduce(eval_results)

    del task_flow_instance
    del dataloader_instance
    del batch_data
    del model_outputs
    del evaluator_instance


if __name__ == "__main__":
    pytest.main([__file__])
