#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Convert meta action tags from multiple txt files to a single pkl file.

The txt format is JSON lines, each line contains:
    {"path": "uuid timestamp1 timestamp2", "tags": [{"tag_name": "...", "start_time": ..., "end_time": ...}, ...]}

The pkl format is a TagStorage object.
"""

import json
import pickle
import sys
import os

# Add project root to path to import TagStorage
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../../../../..'))

from tpp_onemodel.data.dataset.plannn2_dataset_utils.meta_action_storge import TagStorage


# ========== 配置区：在此修改输入输出路径 ==========
INPUT_TXT_FILES = [
    "/home/gengda.chen/workspace/melange/0515_hl_v013_all.txt",
    "/home/gengda.chen/workspace/melange/0515_ppu_v013_all.txt",
]

OUTPUT_PKL_FILE = "/home/gengda.chen/workspace/melange/0515_v013_all_v2.pkl"
# ================================================


def extract_minium_uuid(s: str) -> str:
    # 匹配最后一个 '/' 之后、'.pkl' 之前的部分
    return s.rpartition('/')[-1]


def convert_txt_to_pkl(txt_files, pkl_path, log_gap=100000):
    """Convert multiple meta label txt files to a single TagStorage pkl file."""
    storage = TagStorage()
    line_count = 0
    error_count = 0

    for txt_path in txt_files:
        print(f"Processing: {txt_path}")
        with open(txt_path, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    path = data.get('path', '')
                    content = path.split()
                    tags = data.get('tags', [])

                    if len(content) < 2:
                        continue
                    fname = " ".join([content[0], content[1]])
                    uuid = extract_minium_uuid(fname)
                    if uuid:
                        storage.add_clip(uuid, tags)
                        line_count += 1
                        if line_count % log_gap == 0:
                            print(f"  meta label processed: {line_count:>8,} lines")

                except Exception as e:
                    error_count += 1
                    if error_count <= 3:
                        print(f"  Error ({txt_path}, line {line_num}): {e}")

    # Save TagStorage object directly
    with open(pkl_path, 'wb') as pf:
        pickle.dump(storage, pf)

    print(f"\nDone. Total clips: {storage.stats['total_clips']}, lines processed: {line_count}, errors: {error_count}")
    print(f"Output saved to: {pkl_path}")


if __name__ == '__main__':
    convert_txt_to_pkl(INPUT_TXT_FILES, OUTPUT_PKL_FILE)
