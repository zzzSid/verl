# -*- coding: utf-8 -*-
# flake8: noqa
# pylint: disable=line-too-long.
"""Planner train & eval one batch test."""

from copy import deepcopy
from datetime import datetime

import pytest
import torch
from torch.nn.parallel.distributed import DistributedDataParallel
from torchpilot.utils.cfg_parser import PyConfig
from torchpilot.utils.file_manager import FileManager
from torchpilot.utils.log_manager import log_file_init
from torchpilot.utils.registries import DATALOADER
from torchpilot.utils.registries import EVALUATOR
from torchpilot.utils.registries import TASK_FLOW

from tpp_onemodel.tools.astra_planner.visualization.frame_sample import (
    visualization_filter,
)
from tpp_onemodel.tools.astra_planner.visualization.frame_sample import (
    visualize_single_frame_sample,
)


def metric_input_checker(metric_input, metric_config):
    for cfg_name in ["tmp_outputs", "single_metrics"]:
        metric_list = metric_config[cfg_name]

        missing_keys = []
        for metric_name in metric_list:
            input_keys = metric_list[metric_name]["input_keys"]
            for key in input_keys:
                if key not in metric_input:
                    missing_keys.append(key)
        if len(missing_keys) > 0:
            raise KeyError(f"Missing model output key: {list(set(missing_keys))}")


@pytest.mark.skip("Skip.")
def test_astra_planner_close_loop(
    planner_config_path,
):
    """Test dataloader taskflow evaluator inter one step."""
    cfg = PyConfig.fromfile(planner_config_path)
    # Init fake config.
    torch.cuda.empty_cache()
    FileManager.init(
        cfg_path=planner_config_path,
        run_name=f'{datetime.now().strftime("%H_%M_%S")}_planner',
    )
    log_file_init("torchpilot", 0)

    dataloader_cfg = deepcopy(cfg.infer_dataloader)
    dataloader_cfg["num_workers"] = 1
    dataloader_cfg["batch_size"] = 1
    dataloader_cfg["persistent_workers"] = False
    dataloader_cfg.dataset_cfg.mode = "cicd_test"

    task_flow_cfg = deepcopy(cfg.infer_task_flow)
    task_flow_cfg.task_model_cfg["close_loop_cfg"]["model_in_loop_infer_flag"] = True
    task_flow_cfg.task_model_cfg["batch_size"] = 1

    evaluator_cfg = deepcopy(cfg.evaluator)
    dataloader_instance = DATALOADER.build(dataloader_cfg)
    task_flow_instance = TASK_FLOW.build(task_flow_cfg)
    evaluator_instance = EVALUATOR.build(evaluator_cfg)
    evaluator_instance.set_zero()

    task_flow_instance.cuda()
    task_flow_instance = DistributedDataParallel(task_flow_instance, device_ids=[0])

    task_flow_instance.eval()
    dataloader_instance.set_state(epoch=0)
    multi_task_batch_data = dataloader_instance.get_batch_data()
    for _, batch_data in multi_task_batch_data.items():
        with torch.no_grad():
            model_outputs = task_flow_instance(batch_data)
        metric_input = evaluator_instance.metrics_io_adapter(batch_data, model_outputs)
        metric_input_checker(metric_input, evaluator_instance.metrics_cfg)

        batch_sample_for_visualization = visualization_filter(metric_input, model_outputs)
        dump_folder = "./export_images"
        for frame_sample in batch_sample_for_visualization:
            visualize_single_frame_sample(
                dump_folder=dump_folder,
                frame_sample=frame_sample,
            )

    del task_flow_instance
    del dataloader_instance
    del batch_data
    del model_outputs
    del evaluator_instance


@pytest.mark.skip("Skip.")
def test_auto_regressive_planner_close_loop(
    astra_planner_ar_singletask_config_path,
):
    """Test dataloader taskflow evaluator inter one step."""
    cfg = PyConfig.fromfile(astra_planner_ar_singletask_config_path)
    # Init fake config.
    torch.cuda.empty_cache()
    FileManager.init(
        cfg_path=astra_planner_ar_singletask_config_path,
        run_name=f'{datetime.now().strftime("%H_%M_%S")}_planner',
    )
    log_file_init("torchpilot", 0)

    dataloader_cfg = deepcopy(cfg.infer_dataloader)
    dataloader_cfg["num_workers"] = 1
    dataloader_cfg["batch_size"] = 1
    dataloader_cfg["persistent_workers"] = False
    dataloader_cfg.dataset_cfg.mode = "cicd_test"

    task_flow_cfg = deepcopy(cfg.infer_task_flow)
    task_flow_cfg.task_model_cfg["close_loop_cfg"]["model_in_loop_infer_flag"] = True
    task_flow_cfg.task_model_cfg["close_loop_cfg"]["model_in_loop_model"] = "auto_regressive_planner"
    task_flow_cfg.task_model_cfg["batch_size"] = 1

    evaluator_cfg = deepcopy(cfg.evaluator)
    dataloader_instance = DATALOADER.build(dataloader_cfg)
    task_flow_instance = TASK_FLOW.build(task_flow_cfg)
    evaluator_instance = EVALUATOR.build(evaluator_cfg)
    evaluator_instance.set_zero()

    task_flow_instance.cuda()
    task_flow_instance = DistributedDataParallel(task_flow_instance, device_ids=[0])

    task_flow_instance.eval()
    dataloader_instance.set_state(epoch=0)
    multi_task_batch_data = dataloader_instance.get_batch_data()
    for _, batch_data in multi_task_batch_data.items():
        with torch.no_grad():
            model_outputs = task_flow_instance(batch_data)
        metric_input = evaluator_instance.metrics_io_adapter(batch_data, model_outputs)
        # metric_input_checker(metric_input, evaluator_instance.metrics_cfg)

        batch_sample_for_visualization = visualization_filter(metric_input, model_outputs)
        dump_folder = "./export_images"
        for frame_sample in batch_sample_for_visualization:
            visualize_single_frame_sample(
                dump_folder=dump_folder,
                frame_sample=frame_sample,
                draw_keys=evaluator_instance.draw_keys,
            )

    del task_flow_instance
    del dataloader_instance
    del batch_data
    del model_outputs
    del evaluator_instance


if __name__ == "__main__":
    pytest.main([__file__])
