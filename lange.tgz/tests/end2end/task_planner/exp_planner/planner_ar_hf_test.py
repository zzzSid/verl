# -*- coding: utf-8 -*-
# flake8: noqa
# pylint: disable=line-too-long.
"""Planner end-to-end test for autoregressive planning with Hugging Face model."""
import pytest
import torch

from tpp_onemodel.tools.astra_planner.ar_hugging_face.ar_planner_model_infer import (
    load_data,
)
from tpp_onemodel.tools.astra_planner.ar_hugging_face.ar_planner_model_infer import (
    load_hf_model,
)


@pytest.mark.skip("Skip.")
def test_ar_planner_hf_infer():
    auto_regressive_planner_hf_path = get_auto_regressive_planner_hf_path()
    (
        static_scene_tokens_lane,
        static_scene_tokens_current_od,
        static_scene_tokens_navi_path,
        static_scene_tokens_tld,
        static_scene_tokens_control_point,
        dynamic_states_agents,
        dynamic_states_ego,
    ) = load_data(f"{auto_regressive_planner_hf_path}/trace/preprocess/output")

    model = load_hf_model(auto_regressive_planner_hf_path)

    with torch.no_grad():
        dynamic_states_agents, dynamic_states_ego, batch_mapping = model.generate(
            static_scene_tokens_lane,
            static_scene_tokens_current_od,
            static_scene_tokens_navi_path,
            static_scene_tokens_tld,
            static_scene_tokens_control_point,
            dynamic_states_agents,
            dynamic_states_ego,
            max_length=25,
        )


def get_auto_regressive_planner_hf_path():
    """Get the path for the autoregressive planner Hugging Face model."""
    return "/share-global/xiangwei.geng/planner/ar_hf/0715"
