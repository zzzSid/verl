# -*- coding: utf-8 -*-
# flake8: noqa
# pylint: disable=line-too-long.
"""Planner train & eval one batch test."""

from copy import deepcopy
from datetime import datetime

import pytest
import torch
from torch.nn.parallel.distributed import DistributedDataParallel
from collections import defaultdict
from tpp_onemodel.tools.plannn2.plannn2_build_optimizer import build_optimizer
from torchpilot.utils.cfg_parser import PyConfig
from torchpilot.utils.file_manager import FileManager
from torchpilot.utils.log_manager import log_file_init
from torchpilot.utils.registries import DATALOADER
from torchpilot.utils.registries import EVALUATOR
from torchpilot.utils.registries import TASK_FLOW


def test_task_plannn2_rl_dataloader_taskflow_train_forward_backward_one_step(
    plannn2_rl_config_path,
):
    """Test dataloader taskflow run one step."""
    cfg = PyConfig.fromfile(plannn2_rl_config_path)
    # Init fake config.
    torch.cuda.empty_cache()
    FileManager.init(
        cfg_path=plannn2_rl_config_path,
        run_name=f'{datetime.now().strftime("%H_%M_%S_%f")}_planner',
    )

    dataloader_cfg = deepcopy(cfg.dataloader)
    dataloader_cfg["num_workers"] = 1
    dataloader_cfg["batch_size"] = 1
    dataloader_cfg["persistent_workers"] = False
    dataloader_cfg.dataset_cfg.tp_mode = "cicd_train"
    task_flow_cfg = deepcopy(cfg.task_flow)
    dataloader_instance = DATALOADER.build(dataloader_cfg)
    task_flow_instance = TASK_FLOW.build(task_flow_cfg)
    task_flow_instance.cuda()
    optimizer_cfg = deepcopy(cfg.optimizer)


    model_params_policy_ = task_flow_instance.get_optim_policies()
    model_params_policy = [
        {"params": model_params_policy_["decay_params"], "weight_decay": 0.0},
        {"params": model_params_policy_["nodecay_params"], "weight_decay": 0.0},
    ]

    optimizer_cfg.params_policy = model_params_policy

    optimizer_cfg.lr = cfg.trainer["lr_per_sample"] * dataloader_cfg["batch_size"]
    optimizer_instance = build_optimizer(**optimizer_cfg)

    task_flow_instance = DistributedDataParallel(task_flow_instance, device_ids=[0])

    dataloader_instance.set_state(epoch=0)
    batch_data = dataloader_instance.get_batch_data()
    batch_data["iter_num"] = 0
    rollout_res = task_flow_instance.module.rollout_forward(batch_data)
    update_epochs_buffer = defaultdict(list)
    for _ in range(cfg.trainer["rl_update_epochs"]):
        with task_flow_instance.no_sync():
            rollout_res["scaler"] = None
            rollout_res["update_epochs_buffer"] = update_epochs_buffer
            model_outputs = task_flow_instance.module.train_policy_step(rollout_res)

        for param in task_flow_instance.parameters():
            if param.requires_grad and param.grad is not None:
                torch.distributed.all_reduce(
                    param.grad, op=torch.distributed.ReduceOp.SUM
                )
                param.grad /= torch.distributed.get_world_size()

        optimizer_instance.zero_grad(set_to_none=True)
        optimizer_instance.step()

    optimizer_instance.step()
    task_flow_instance.zero_grad()
    optimizer_instance.zero_grad()

    del task_flow_instance
    del dataloader_instance
    del optimizer_instance
    del model_outputs
    del batch_data
    del rollout_res
    del update_epochs_buffer
    torch.cuda.empty_cache()


def test_task_plannn2_rl_dataloader_taskflow_evaluator_infer_one_step(
    plannn2_rl_config_path
):
    """Test dataloader taskflow evaluator inter one step."""
    cfg = PyConfig.fromfile(plannn2_rl_config_path)
    # Init fake config.
    torch.cuda.empty_cache()
    FileManager.init(
        cfg_path=plannn2_rl_config_path,
        run_name=f'{datetime.now().strftime("%H_%M_%S_%f")}_planner',
    )
    log_file_init("torchpilot", 0)

    dataloader_cfg = deepcopy(cfg.infer_dataloader)
    dataloader_cfg["num_workers"] = 1
    dataloader_cfg["batch_size"] = 1
    dataloader_cfg["persistent_workers"] = False
    dataloader_cfg.dataset_cfg.tp_mode = "cicd_test"
    task_flow_cfg = deepcopy(cfg.infer_task_flow)
    evaluator_cfg = deepcopy(cfg.evaluator)
    task_flow_cfg["shmpool_name"] = "rollout_closed_eval"
    dataloader_instance = DATALOADER.build(dataloader_cfg)
    task_flow_instance = TASK_FLOW.build(task_flow_cfg)
    evaluator_instance = EVALUATOR.build(evaluator_cfg)
    evaluator_instance.set_zero()

    task_flow_instance.cuda()
    task_flow_instance = DistributedDataParallel(task_flow_instance, device_ids=[0])

    task_flow_instance.eval()
    dataloader_instance.set_state(epoch=0)
    batch_data = dataloader_instance.get_batch_data()
    with torch.no_grad():
        model_outputs = task_flow_instance.module.forward_model_rl(batch_data)
    eval_results = evaluator_instance.eval(model_outputs, batch_data)
    evaluator_instance.dist_all_reduce(eval_results)

    del task_flow_instance
    del dataloader_instance
    del batch_data
    del model_outputs
    del evaluator_instance


if __name__ == "__main__":
    # pytest.main([__file__])
    from torchpilot.utils.plus_manager import load_plus
    load_plus()
    torch.distributed.init_process_group(
        backend="nccl",
        init_method="tcp://localhost:9999",
        world_size=1,
        rank=0,
    )
    plannn2_rl_config_path = "experiments/task_planner/exp_plannn2/cfg_plannn2_rl.py"
    test_task_plannn2_rl_dataloader_taskflow_train_forward_backward_one_step(plannn2_rl_config_path)
    test_task_plannn2_rl_dataloader_taskflow_evaluator_infer_one_step(plannn2_rl_config_path)
