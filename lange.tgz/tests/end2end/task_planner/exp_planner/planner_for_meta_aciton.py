# -*- coding: utf-8 -*-
import os
import json
import torch
import numpy as np
# from easydict import EasyDict
from torchpilot.utils.plus_manager import load_plus
from torchpilot.utils.registries import DATALOADER
from torchpilot.utils.cfg_parser import PyConfig
from torchpilot.utils.registries import MODULE
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import compute_car_pose
from tpp_onemodel.evaluator.plannn2_evaluator_utils.planner_env import PlannerEnv
from tpp_onemodel.data.dataset.plannn2_dataset import Plannn2Dataset
from shapely.geometry import LineString
import numpy as np
import torch.distributed as dist
from multiprocessing import Process, Pool, Lock
from tpp_onemodel.data.dataset.plannn2_dataset import _load_data as load_data

import matplotlib.pyplot as plt
import numpy as np
import os
from matplotlib import rcParams


import concurrent.futures
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import threading
import time
from multiprocessing import Manager, Queue as MPQueue
import queue

from tpp_onemodel.data.dataset.plannn2_dataset_utils.meta_action_manager import (
    MetaActionManager,
)


from enum import Enum


import json
from multiprocessing import Pool, cpu_count
from itertools import islice


class LatCategory(Enum):
    RIGHT_UTURN = 0
    RIGHT_TURN = 1
    RIGHT_LC = 2
    KEEP = 3
    LEFT_LC = 4
    LEFT_TURN = 5
    LEFT_UTURN = 6

class LonCategory(Enum):
    NO_RISK = 0
    COLLISION = 1
    DECAL = 2

def find_lat_category(value: int) -> LatCategory:
    """
    根据输入数值(0-6)找出对应的枚举变量

    Args:
        value: 输入的数值 (0-6)

    Returns:
        对应的枚举成员

    Raises:
        ValueError: 如果数值不在有效范围内
    """
    if not 0 <= value <= 6:
        raise ValueError(f"无效的数值 {value}，请输入 0-6 之间的整数")
    return LatCategory(value)


def find_lon_category(value: int) -> LonCategory:
    """
    根据输入数值(0-6)找出对应的枚举变量

    Args:
        value: 输入的数值 (0-6)

    Returns:
        对应的枚举成员

    Raises:
        ValueError: 如果数值不在有效范围内
    """
    if not 0 <= value <= 2:
        raise ValueError(f"无效的数值 {value}，请输入 0-2 之间的整数")
    return LonCategory(value)


def extract_timestamp_from_path(path: str) -> str:
    """
    从路径中提取时间戳部分

    Args:
        path: 完整的文件路径

    Returns:
        时间戳字符串
    """
    # 获取文件名（最后一个 / 之后的部分）
    filename = path.split('/')[-1].replace('.pkl', '')
    return filename

class ThreadPoolProcessor:
    def __init__(self, max_workers=4, output_file="result.txt", vis_path = "./vis/", use_multiprocessing=True):
        """
        使用线程池/进程池的处理器

        Args:
            max_workers: 最大工作线程数/进程数
            output_file: 输出文件名
            vis_path: 可视化路径
            use_multiprocessing: 是否使用多进程（默认True，推荐用于CPU密集型任务）
        """
        self.max_workers = max_workers
        self.output_file = output_file
        self.vis_path = vis_path
        self.use_multiprocessing = use_multiprocessing
        os.makedirs(self.vis_path, exist_ok=True)
        self.lock = threading.Lock()
        self.condition_count = 0
        # 多进程相关初始化
        if use_multiprocessing:
            self.manager = Manager()
            self.write_queue = self.manager.Queue()
        else:
            self.manager = None
            self.write_queue = None

    def process_item(self, item):
        """
        处理单个元素（自定义处理逻辑）

        Args:
            item: 如果是字符串则解析为JSON，如果是字典则直接使用
        """
        # 解析输入数据（支持字符串JSON或字典）
        item_data = None
        if isinstance(item, str):
            try:
                item_data = json.loads(item)
            except json.JSONDecodeError as e:
                print(f"JSON解析错误: {e}, item: {item[:200]}...")
                return False, None
        elif isinstance(item, dict):
            item_data = item
        else:
            print(f"不支持的数据类型: {type(item)}")
            return False, None

        # 获取文件路径
        fname = item_data.get('path', '').rpartition(' ')[0]
        if not fname:
            print(f"无法获取文件路径: {item_data}")
            return False, None
        uuid = fname.split('/')[-1].split('.')[0]
        # print(f"fname = {fname}")
        # fname = 'huailai_cos:ad-cn-hlidc-adsim-mojito/train_data_fuzzing/blocker_2_1216/ed3a32fd-147f-4d51-9d49-c0509a03c7be.pkl 20143762'
        data = load_data(fname)
        timestamps = sorted(data["timestamp_list"])


        # pre-process collision risk detection
        action_manager = MetaActionManager(data, clip_id=f"{uuid}", enable_viz=False)
        clip_lable_status = action_manager.process(dataset_kwargs={})

        clip_id = extract_timestamp_from_path(fname)

        # res = {
        #     "path": fname,
        #     "clip_id": clip_id,
        #     "version": "v1.2.3",
        #     "frame_num": len(timestamps),
        #     "clip_start_time": timestamps[0],
        #     "clip_end_time": timestamps[-1],
        #     "tags": []
        # }

        lat_dict = {}
        lon_dict = {}

        # 用于跟踪当前 lateral 段落（只记录非3的）
        current_lat = None
        lat_start_time = None
        lat_segments = []

        # 用于跟踪当前 longitudinal 段落（非0）
        current_lon = None
        lon_start_time = None
        lon_segments = []

        prev_ts = None

        for ts, clip_label in zip(timestamps, clip_lable_status):
            lateral = MetaActionManager.LATITUDE_LABELS_MAP[clip_label["lateral"]]
            longitudinal = MetaActionManager.LONGITUDE_LABELS_MAP[clip_label["longitudinal"]]
            # print(f"lateral = {lateral}")

            # 处理 lateral 段落（只记录非3的）
            if lateral != current_lat:
                # 如果之前有非3的 lateral，保存它
                if current_lat is not None and current_lat != 3 and prev_ts is not None:
                    lat_segments.append({
                        "tag_type": "checker",
                        "tag_name": find_lat_category(current_lat).name,
                        "start_time": lat_start_time,
                        "end_time": prev_ts,
                    })
                # 开始新的段落（只当新的值非3时）
                if lateral != 3:
                    current_lat = lateral
                    lat_start_time = ts
                else:
                    current_lat = None
                    lat_start_time = None

            # 处理 longitudinal 段落（只记录非0的）
            if longitudinal != current_lon:
                # 如果之前有非0的 longitudinal，保存它
                if current_lon is not None and current_lon != 0 and prev_ts is not None:
                    lon_segments.append({
                        "tag_type": "checker",
                        "tag_name": find_lon_category(current_lon).name,
                        "start_time": lon_start_time,
                        "end_time": prev_ts
                    })
                # 开始新的段落（只当新的值非0时）
                if longitudinal != 0:
                    current_lon = longitudinal
                    lon_start_time = ts
                else:
                    current_lon = None
                    lon_start_time = None

            prev_ts = ts

        # 处理最后一个 lateral 段落（如果非3）
        if current_lat is not None and current_lat != 3:
            lat_segments.append({
                "tag_type": "checker",
                "tag_name": find_lat_category(current_lat).name,
                "start_time": lat_start_time,
                "end_time": timestamps[-1]
            })

        # 处理最后一个 longitudinal 段落（如果非0）
        if current_lon is not None and current_lon != 0:
            lon_segments.append({
                "tag_type": "checker",
                "tag_name": find_lon_category(current_lon).name,
                "start_time": lon_start_time,
                "end_time": timestamps[-1]
            })

        # 将 lateral 和 longitudinal 段合并到 item_data['tags']
        if 'tags' not in item_data:
            item_data['tags'] = []
        item_data['tags'] = item_data['tags'] + lat_segments + lon_segments

        return True, item_data

    def write_to_file(self, result_str):
        """线程安全的文件写入"""
        with self.lock:
            with open(self.output_file, 'a', encoding='utf-8') as f:
                f.write(json.dumps(result_str, ensure_ascii=False) + '\n')
            self.condition_count += 1

    def process_with_future(self, item_with_index):
        """供线程池调用的处理函数"""
        index, item = item_with_index
        meets_condition, result_str = self.process_item(item)

        if meets_condition:
            self.write_to_file(result_str)
            return f"元素 {item} (索引:{index}) 满足条件"
        else:
            return f"元素 {item} (索引:{index}) 不满足条件"

    def process_list_generator_fast(self, data_generator):
        """
        超高速多进程版本 - 专为128+ CPU优化
        使用进程池 + 批量处理 + 独立写入进程
        """
        import multiprocessing as mp
        
        workers = min(self.max_workers, mp.cpu_count())
        print(f"[高性能模式] 启动 {workers} 个进程处理数据...")
        print(f"CPU核心数: {mp.cpu_count()}")
        
        # 使用进程池
        with ProcessPoolExecutor(max_workers=workers) as executor:
            # 批量提交任务，减少开销
            batch_size = workers * 4  # 每个进程4个任务
            futures = []
            total_processed = 0
            
            # 先预提交一批任务
            batch = []
            for idx, item in enumerate(data_generator):
                batch.append((idx, item))
                
                if len(batch) >= batch_size:
                    # 提交批量任务
                    for index, data_item in batch:
                        future = executor.submit(_worker_process_item, data_item)
                        futures.append((index, future))
                    batch = []
                    
                    # 处理完成的任务
                    done_futures = []
                    for index, future in list(futures):
                        if future.done():
                            try:
                                meets_condition, result = future.result()
                                if meets_condition and result:
                                    self.write_to_file(result)
                                    self.condition_count += 1
                                total_processed += 1
                                done_futures.append((index, future))
                            except Exception as e:
                                print(f"处理错误: {e}")
                                done_futures.append((index, future))
                    
                    # 移除已完成的
                    for done in done_futures:
                        futures.remove(done)
                    
                    if total_processed % 1000 == 0:
                        print(f"进度: 已处理 {total_processed} 条，队列中: {len(futures)}")
            
            # 提交剩余任务
            if batch:
                for index, data_item in batch:
                    future = executor.submit(_worker_process_item, data_item)
                    futures.append((index, future))
            
            # 等待所有任务完成
            print(f"等待 {len(futures)} 个剩余任务完成...")
            for index, future in futures:
                try:
                    meets_condition, result = future.result(timeout=300)
                    if meets_condition and result:
                        self.write_to_file(result)
                        self.condition_count += 1
                    total_processed += 1
                except Exception as e:
                    print(f"最终处理错误: {e}")
        
        print(f"\n处理完成！总共处理 {total_processed} 条，满足条件: {self.condition_count}")
        return self.condition_count

    def process_list_generator(self, data_generator):
        """
        使用生成器处理大数据，避免内存溢出
        根据配置自动选择线程池或进程池
        """
        if self.use_multiprocessing:
            return self.process_list_generator_fast(data_generator)
        
        # 线程池版本（IO密集型任务）
        print(f"开始处理数据流，使用 {self.max_workers} 个线程...")

        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = set()
            index = 0

            for item in data_generator:
                while len(futures) >= self.max_workers * 2:
                    done, futures = concurrent.futures.wait(
                        futures,
                        return_when=concurrent.futures.FIRST_COMPLETED
                    )
                    for future in done:
                        try:
                            result = future.result()
                            if index % 100 == 0:
                                print(f"进度: 已处理 {index} 条")
                        except Exception as e:
                            print(f"处理出错: {e}")

                future = executor.submit(self.process_with_future, (index, item))
                futures.add(future)
                index += 1

            print(f"等待剩余 {len(futures)} 个任务完成...")
            for future in concurrent.futures.as_completed(futures):
                try:
                    result = future.result()
                except Exception as e:
                    print(f"处理出错: {e}")

        print(f"\n处理完成！总共处理 {index} 条，满足条件: {self.condition_count}")
        return self.condition_count

    def process_list(self, data_list):
        """主处理函数（兼容列表输入）"""
        print(f"开始处理 {len(data_list)} 个元素，使用 {self.max_workers} 个{'进程' if self.use_multiprocessing else '线程'}...")

        items_with_index = list(enumerate(data_list))
        
        # 根据配置选择线程池或进程池
        ExecutorClass = ProcessPoolExecutor if self.use_multiprocessing else ThreadPoolExecutor
        
        with ExecutorClass(max_workers=self.max_workers) as executor:
            futures = [
                executor.submit(self.process_with_future, item)
                for item in items_with_index
            ]

            completed = 0
            for future in concurrent.futures.as_completed(futures):
                result = future.result()
                completed += 1
                if completed % 100 == 0:
                    print(f"进度: {completed}/{len(data_list)}")

        print(f"\n处理完成！满足条件的元素数量: {self.condition_count}")
        return self.condition_count


def _worker_process_item(item):
    """
    独立进程工作函数 - 必须在模块级别定义才能被pickle
    """
    try:
        # 解析JSON
        if isinstance(item, str):
            item_data = json.loads(item)
        elif isinstance(item, dict):
            item_data = item
        else:
            return False, None
        
        # 获取文件路径
        fname = item_data.get('path', '').rpartition(' ')[0]
        if not fname:
            return False, None
        
        uuid = fname.split('/')[-1].split('.')[0]
        
        # 加载数据
        data = load_data(fname)
        timestamps = sorted(data["timestamp_list"])
        
        # 处理
        action_manager = MetaActionManager(data, clip_id=f"{uuid}", enable_viz=False)
        clip_lable_status = action_manager.process(dataset_kwargs={})
        
        # 收集 lateral 和 longitudinal 段落
        lat_segments = []
        lon_segments = []
        current_lat = None
        current_lon = None
        lat_start_time = None
        lon_start_time = None
        prev_ts = None
        
        for ts, clip_label in zip(timestamps, clip_lable_status):
            lateral = MetaActionManager.LATITUDE_LABELS_MAP[clip_label["lateral"]]
            longitudinal = MetaActionManager.LONGITUDE_LABELS_MAP[clip_label["longitudinal"]]
            
            # Lateral (非3)
            if lateral != current_lat:
                if current_lat is not None and current_lat != 3 and prev_ts is not None:
                    lat_segments.append({
                        "tag_type": "checker",
                        "tag_name": LatCategory(current_lat).name,
                        "start_time": lat_start_time,
                        "end_time": prev_ts,
                    })
                if lateral != 3:
                    current_lat = lateral
                    lat_start_time = ts
                else:
                    current_lat = None
                    lat_start_time = None
            
            # Longitudinal (非0)
            if longitudinal != current_lon:
                if current_lon is not None and current_lon != 0 and prev_ts is not None:
                    lon_segments.append({
                        "tag_type": "checker",
                        "tag_name": LonCategory(current_lon).name,
                        "start_time": lon_start_time,
                        "end_time": prev_ts,
                    })
                if longitudinal != 0:
                    current_lon = longitudinal
                    lon_start_time = ts
                else:
                    current_lon = None
                    lon_start_time = None
            
            prev_ts = ts
        
        # 最后一个段落
        if current_lat is not None and current_lat != 3:
            lat_segments.append({
                "tag_type": "checker",
                "tag_name": LatCategory(current_lat).name,
                "start_time": lat_start_time,
                "end_time": timestamps[-1],
            })
        
        if current_lon is not None and current_lon != 0:
            lon_segments.append({
                "tag_type": "checker",
                "tag_name": LonCategory(current_lon).name,
                "start_time": lon_start_time,
                "end_time": timestamps[-1],
            })
        
        # 合并结果
        if 'tags' not in item_data:
            item_data['tags'] = []
        item_data['tags'] = item_data['tags'] + lat_segments + lon_segments
        
        return True, item_data
        
    except Exception as e:
        print(f"工作进程错误: {e}")
        return False, None


def init_distributed():
    dist.init_process_group(backend="nccl")
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    local_rank = int(os.environ["LOCAL_RANK"])
    torch.cuda.set_device(local_rank)
    return rank, world_size, local_rank

def parse_multi_spd_limit(data, timestamps):
    spd_limits = []
    for ts in timestamps:
        spd_limit = data[ts]["speed_limit"]
        spd_limits.append(spd_limit)
    return np.array(spd_limits)

def read_large_file_generator(file_path, chunk_size=8192):
    """
    使用生成器高效读取大文件，避免一次性加载到内存

    Args:
        file_path: 文件路径
        chunk_size: 读取缓冲区大小

    Yields:
        每一行的内容（去除换行符）
    """
    with open(file_path, 'r', encoding='utf-8') as f:
        buffer = ''
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                # 处理最后剩余的内容
                if buffer:
                    yield buffer
                break
            buffer += chunk
            lines = buffer.split('\n')
            # 保留最后不完整的行到下一次读取
            buffer = lines.pop()
            for line in lines:
                if line:  # 跳过空行
                    yield line


def get_file_list_fast(file_lists):
    """
    快速读取多个大文件，使用生成器避免内存溢出

    Args:
        file_lists: 文件路径列表

    Yields:
        每一行的内容
    """
    for file_path in file_lists:
        print(f"正在读取文件: {file_path}")
        line_count = 0
        for line in read_large_file_generator(file_path):
            yield line
            line_count += 1
            if line_count % 100000 == 0:
                print(f"  已读取 {line_count} 行...")
        print(f"  文件读取完成，共 {line_count} 行")


def get_file_list(file_lists):
    """
    兼容旧接口，返回列表形式（小文件使用）
    大文件建议使用 get_file_list_fast 生成器
    """
    file_list_out = []
    for line in get_file_list_fast(file_lists):
        file_list_out.append(line)
    return file_list_out


def create_figure_template():
    """创建可复用的图形模板"""
    fig, ax = plt.subplots(figsize=(10, 6), dpi=100)
    return fig, ax

def plot_two_lists(ax, x_data, list1, list2, label1='曲线1', label2='曲线2',
                   color1=None, color2=None, save_path=None):
    """
    高效绘制两条曲线

    参数：
    ax: matplotlib坐标轴对象
    x_data: X轴数据
    list1, list2: Y轴数据
    label1, label2: 曲线标签
    color1, color2: 曲线颜色（可选）
    save_path: 保存路径（可选）
    """
    # 使用预设颜色或随机颜色
    color1 = colors[0]
    color2 = colors[1]

    # 绘制曲线
    line1 = ax.plot(x_data, list1, color=color1, linewidth=2,
                    label=label1, alpha=0.8)[0]
    line2 = ax.plot(x_data, list2, color=color2, linewidth=2,
                    linestyle='--', label=label2, alpha=0.8)[0]

    return line1, line2

dataloader_file = [
    # "/share-global/timo.li/pkl/train_30000_rl_base_251028_only_hd_navi.txt",
    # "/home/gengda.chen/workspace/melange/test_decal copy.txt",
    "/share-global/nell.dong/data/planner/planner_basedata_20260321_i_4259074.txt"
    # "/home/gengda.chen/workspace/melange/test_loss.txt"
    ]

# 1. 一次性设置全局样式（避免每次循环都设置）
rcParams.update({
    'font.size': 10,
    'axes.labelsize': 12,
    'axes.titlesize': 14,
    'legend.fontsize': 10,
    'figure.titlesize': 16,
})

# 2. 预定义颜色和线型
colors = ['blue', 'red', 'green', 'orange', 'purple', 'brown']
line_styles = ['-', '--', '-.', ':']


# 使用示例
if __name__ == "__main__":
    # 大文件建议使用生成器方式处理，避免内存溢出
    # 高性能模式：使用多进程，充分利用128个CPU核心
    print("=" * 60)
    print("高性能多进程处理模式")
    print("=" * 60)
    
    import multiprocessing as mp
    cpu_count = mp.cpu_count()
    print(f"检测到的CPU核心数: {cpu_count}")
    
    # 配置参数
    # max_workers: 进程数，建议设置为CPU核心数或略低（留出资源给系统）
    # 128个CPU可以设置为 100-120
    MAX_WORKERS = min(120, cpu_count)  # 最多使用120个进程
    
    processor = ThreadPoolProcessor(
        max_workers=MAX_WORKERS,
        output_file="/home/gengda.chen/workspace/melange/0407_output_pm.txt",
        vis_path="./vis/",
        use_multiprocessing=True  # 启用多进程模式
    )
    
    print(f"启动 {MAX_WORKERS} 个进程处理400万行数据...")
    print(f"输出文件: {processor.output_file}")
    print("=" * 60)
    
    start_time = time.time()
    
    # 使用生成器直接处理，不加载全部到内存
    result_count = processor.process_list_generator(get_file_list_fast(dataloader_file))
    
    end_time = time.time()
    elapsed = end_time - start_time
    
    print("=" * 60)
    print(f"处理完成!")
    print(f"总用时: {elapsed:.2f} 秒")
    print(f"处理速度: {result_count / elapsed:.2f} 条/秒" if elapsed > 0 else "N/A")
    print(f"满足条件的记录数: {result_count}")
    print("=" * 60)
    
    # 备用：单进程调试模式（发现问题时使用）
    # print("\n单进程调试模式...")
    # processor = ThreadPoolProcessor(
    #     max_workers=1,
    #     output_file="/home/gengda.chen/workspace/melange/0407_output_pm_debug.txt",
    #     vis_path="./vis/",
    #     use_multiprocessing=False
    # )
    # start_time = time.time()
    # result_count = processor.process_list_generator(get_file_list_fast(dataloader_file))
    # end_time = time.time()
    # print(f"调试模式用时: {end_time - start_time:.2f} 秒")
