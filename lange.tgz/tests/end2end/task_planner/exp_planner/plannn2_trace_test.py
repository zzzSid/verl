# -*- coding: utf-8 -*-
import argparse
import logging
import os
import os.path as osp
import pickle
import shutil
from typing import Dict

import git
import torch
from torchpilot.utils.cfg_parser import PyConfig
from torchpilot.utils.plus_manager import load_plus
from torchpilot.utils.registries import DATALOADER

from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import (
    transform_polygan_torch,
)
from tpp_onemodel.plannn_trace.common import NetConfig
from tpp_onemodel.plannn_trace.net_abc import MyCustomConfig
from tpp_onemodel.plannn_trace.net_abc import NetA
from tpp_onemodel.plannn_trace.net_abc import NetC

from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import (
    get_xyyaw_from_polygon_torch,
)


logger = logging.getLogger(__name__)


def estimate_current_ego_speed( ego_polygons: torch.Tensor, state_range: float) -> torch.Tensor:
    """Estimate current ego rear-axle speed from the latest two ego polygons."""
    cur_xyyaw = get_xyyaw_from_polygon_torch(ego_polygons[:, -1])
    pre_xyyaw = get_xyyaw_from_polygon_torch(ego_polygons[:, -2])
    cur_xy_rear = torch.stack(
        [
            cur_xyyaw[:, 0] * state_range - 1.4 * torch.cos(cur_xyyaw[:, 6]),
            cur_xyyaw[:, 1] * state_range - 1.4 * torch.sin(cur_xyyaw[:, 6]),
        ],
        dim=-1,
    )
    pre_xy_rear = torch.stack(
        [
            pre_xyyaw[:, 0] * state_range - 1.4 * torch.cos(pre_xyyaw[:, 6]),
            pre_xyyaw[:, 1] * state_range - 1.4 * torch.sin(pre_xyyaw[:, 6]),
        ],
        dim=-1,
    )
    delta = cur_xy_rear - pre_xy_rear
    return torch.linalg.norm(delta, dim=-1) / 0.2

# input name is used for pytest donot change
def test_planner_model_trace(plannn2_trace_config_path, plannn2_trace_ckpt_path, plannn2_trace_save_path):
    """Planner Model trace test."""
    torch.backends.__allow_nonbracketed_mutation_flag = True
    torch_fix_precision()

    cfg_path = plannn2_trace_config_path
    ckpt_path = plannn2_trace_ckpt_path
    save_path = plannn2_trace_save_path

    if not osp.exists(ckpt_path):
        raise FileNotFoundError(f"Checkpoint not found under: {ckpt_path}.")

    if osp.exists(osp.dirname(save_path)):
        logger.warning("Existing save path: %s", osp.dirname(save_path))
    os.makedirs(osp.dirname(save_path), exist_ok=True)

    model_ab_dir = os.path.join(save_path, "model/ab")
    model_c_dir = os.path.join(save_path, "model/c")
    onnx_data_dir = os.path.join(save_path, "data")
    os.makedirs(model_ab_dir, exist_ok=True)
    os.makedirs(model_c_dir, exist_ok=True)
    os.makedirs(onnx_data_dir, exist_ok=True)
    print(f"onnx_dir: {save_path}")

    cfg = PyConfig.fromfile(cfg_path)
    print(f"Resuming training from {ckpt_path}")
    # resume training from a checkpoint.
    device = "cuda"
    checkpoint = torch.load(ckpt_path, map_location=device)
    # force these config attributes to be equal otherwise we can't even resume training
    # the rest of the attributes (e.g. dropout) can stay as desired from command line
    # model init
    model_args = dict(
        is_planner=cfg.IS_PLANNER,
        n_layer=cfg.N_LAYER,
        n_head=cfg.N_HEAD,
        n_embd=cfg.N_EMBD,
        env_block_size=cfg.ENV_BLOCK_SIZE,
        state_block_size=cfg.STATE_BLOCK_SIZE,
        output_num=cfg.infer_task_flow.task_model_cfg.sub_module_cfg.output_num + cfg.CLASS_NUM_META_ACTION,
        history_size=cfg.HISTORY_SIZE,
        polyline_size=cfg.POLYLINE_SIZE,
        dropout=cfg.DROPOUT,
        bias=cfg.BIAS,
        use_rmsnorm=cfg.USE_RMSNORM,
        use_kv_cache=cfg.infer_task_flow.task_model_cfg.infer_cfg.use_kv_cache,
        kv_cache_batch_size=1,
        max_token_len=cfg.MAX_TOKEN_LEN,
    )  # start with model_args from command line
    # create the model
    gptconf = NetConfig(**model_args)
    model_a = NetA(gptconf)
    config = MyCustomConfig(**model_args)
    model_c = NetC(config)

    state_dict = checkpoint["model"]
    plannn2_keys = {k.replace("module._task_model.", ""): v for k, v in state_dict.items()}
    # fix the keys of the state dictionary :(
    # honestly no idea how checkpoints sometimes get this prefix, have to debug more
    unwanted_prefix = "_orig_mod."
    for k, v in list(state_dict.items()):
        if k.startswith(unwanted_prefix):
            plannn2_keys[k[len(unwanted_prefix) :]] = plannn2_keys.pop(k)
    model_a.load_state_dict(plannn2_keys, strict=False)
    model_c.load_state_dict(plannn2_keys, strict=False)
    # model_a.to(device)
    model_a.eval()
    # model_b.to(device)
    if device != "cpu":
        model_c.cuda()
    model_c.eval()

    with torch.set_grad_enabled(False):
        data_cfg = cfg.infer_dataloader
        data_cfg.batch_size = 1
        data_cfg.num_workers = 1
        data_cfg.sampler_cfg.shuffle = False
        data_loader = DATALOADER.build(data_cfg)
        samples = next(iter(data_loader))  # start_idx 0.1

        env_polygon = samples["polygon"].to(torch.float32).cuda()
        env_polyline = samples["polyline"].to(torch.float32).cuda()
        env_polymask = samples["polymask"].to(torch.float32).cuda()
        env_property = samples["property"].to(torch.float32).cuda()
        env_padding_index = env_property[..., 0] == 0  # [1, 256]
        env_selected_indices = (~env_padding_index).nonzero(as_tuple=True)[1]  # 提取索引

        env_input_polygon = torch.cat(
            (torch.zeros((1, 1, 4, 2), device=env_polygon.device), env_polygon[:, env_selected_indices]), dim=1
        )
        env_input_polyline = torch.cat(
            (torch.zeros((1, 1, 4, 2), device=env_polyline.device), env_polyline[:, env_selected_indices]), dim=1
        )
        env_input_polymask = torch.cat(
            (torch.zeros((1, 1, 2), device=env_polymask.device), env_polymask[:, env_selected_indices]), dim=1
        )
        env_input_property = torch.cat(
            (torch.zeros((1, 1, 12), device=env_property.device), env_property[:, env_selected_indices]), dim=1
        )

        dyn_polygon = samples["dyn_polygon"].to(torch.float32).cuda()
        dyn_polyline = samples["dyn_polyline"].to(torch.float32).cuda()
        dyn_polymask = samples["dyn_polymask"].to(torch.float32).cuda()
        dyn_property = samples["dyn_property"].to(torch.float32).cuda()
        dyn_padding_index = dyn_property[..., 0] == 0  # [1, 256]
        dyn_selected_indices = (~dyn_padding_index).nonzero(as_tuple=True)[1]  # 提取索引
        dyn_input_polygon = torch.cat(
            (torch.zeros((1, 1, 15, 4, 2), device=dyn_polygon.device), dyn_polygon[:, dyn_selected_indices]), dim=1
        )
        dyn_input_polyline = torch.cat(
            (torch.zeros((1, 1, 4, 2), device=dyn_polyline.device), dyn_polyline[:, dyn_selected_indices]), dim=1
        )
        dyn_input_polymask = torch.cat(
            (torch.zeros((1, 1, 2), device=dyn_polymask.device), dyn_polymask[:, dyn_selected_indices]), dim=1
        )
        dyn_input_property = torch.cat(
            (torch.zeros((1, 1, 12), device=dyn_property.device), dyn_property[:, dyn_selected_indices]), dim=1
        )

        ego_polygon = samples["ego_polygon"].to(torch.float32).cuda()
        ego_v = estimate_current_ego_speed(ego_polygon,state_range =cfg.infer_task_flow.task_model_cfg.infer_cfg.state_range)
        ego_polygon[:,:-1] = 0.0

        ego_polyline = samples["ego_polyline"].to(torch.float32).cuda()
        ego_polymask = samples["ego_polymask"].to(torch.float32).cuda()
        ego_property = samples["ego_property"].to(torch.float32).cuda()
        ego_property[:,-1,10] = ego_v

        property = torch.cat([env_property, dyn_property, ego_property], dim=1)
        padding_index = property[..., 0] == 0  # [1, token_size]
        selected_indices = (~padding_index).nonzero(as_tuple=True)[1]  # 提取索引
        preded_length = 0
        label_next = None
        pred_label = torch.zeros((1, 0)).long().cuda()

        for i in range(cfg.PRED_NUMS):
            # print(f'\n----------- pred idx: {i} ----------')
            if preded_length >= cfg.PRED_NUMS:
                break

            if i == 0:
                # print(f'input of model_a:\n\tpolygan: {input_polygan.shape}\n\tpolyline: {input_polyline.shape}\n
                # \tpolymask: {input_polymask.shape}\n\tproperty: {input_property.shape}')
                pred_a = model_a(
                    env_input_polygon.cpu(),
                    env_input_polyline.cpu(),
                    env_input_polymask.cpu(),
                    env_input_property.cpu(),
                    dyn_input_polygon.cpu(),
                    dyn_input_polyline.cpu(),
                    dyn_input_polymask.cpu(),
                    dyn_input_property.cpu(),
                    ego_polygon.cpu(),
                    ego_polyline.cpu(),
                    ego_polymask.cpu(),
                    ego_property.cpu(),
                ).to(
                    device
                )  # [1, 464, 1536]
                input_c = pred_a.to(torch.float32)
                logits = model_c.prefill(input_c, selected_indices=selected_indices)  # [b, pl, output_num]
            else:
                selected_indices = torch.cat(
                    [
                        selected_indices,
                        torch.tensor([padding_index.shape[1] + i - 1], device=device, dtype=torch.int64),
                    ],
                    dim=0,
                )
                logits = model_c.decode(input_c, pred_label, selected_indices=selected_indices)  # [b, pl, output_num]

            if i == 0:
                with open(f"{onnx_data_dir}/logits_pred{i}.pkl", "wb") as fw:
                    pickle.dump(logits.detach().cpu().numpy(), fw)

                print(f"save logits pred{i}")

            label_next = torch.argmax(logits, dim=-1)

            pred_label = torch.cat((pred_label, label_next), dim=1)
            preded_length += 1

        print(f"pred_label.shape: {pred_label.shape}\n{pred_label}")

        with open(f"{onnx_data_dir}/logits_pred_all.pkl", "wb") as fw:
            pickle.dump(pred_label.detach().cpu().numpy(), fw)

        print(f"save logits pred all")

        # Model A
        inputs_a = (
            env_input_polygon.cpu(),
            env_input_polyline.cpu(),
            env_input_polymask.cpu(),
            env_input_property.cpu(),
            dyn_input_polygon.cpu(),
            dyn_input_polyline.cpu(),
            dyn_input_polymask.cpu(),
            dyn_input_property.cpu(),
            ego_polygon.cpu(),
            ego_polyline.cpu(),
            ego_polymask.cpu(),
            ego_property.cpu(),
        )
        for i, input_tensor in enumerate(inputs_a):
            print(f"Model A input tensor {i}:", input_tensor.shape, input_tensor.dtype)
        print("Model A output tensor:", pred_a.shape)
        torch.onnx.export(
            model_a,  # model being run
            inputs_a,  # model input (or a tuple for multiple inputs)
            os.path.join(model_ab_dir, "model_a.onnx"),  # where to save the model (can be a file or file-like object)
            export_params=True,  # store the trained parameter weights inside the model file
            opset_version=11,
            do_constant_folding=True,  # whether to execute constant folding for optimization
            # input_names=["polygan", "polyline", "mask", "property"],  # the model's input names
            input_names=[
                "env_input_polygon",
                "env_input_polyline",
                "env_input_polymask",
                "env_input_property",
                "dyn_input_polygon",
                "dyn_input_polyline",
                "dyn_input_polymask",
                "dyn_input_property",
                "ego_polygon",
                "ego_polyline",
                "ego_polymask",
                "ego_property",
            ],  # the model's input names
            output_names=["output"],  # the model's output names
            dynamic_axes={
                "env_input_polygon": {1: "env_token_size"},
                "env_input_polyline": {1: "env_token_size"},
                "env_input_polymask": {1: "env_token_size"},
                "env_input_property": {1: "env_token_size"},
                "dyn_input_polygon": {1: "dyn_token_size"},
                "dyn_input_polyline": {1: "dyn_token_size"},
                "dyn_input_polymask": {1: "dyn_token_size"},
                "dyn_input_property": {1: "dyn_token_size"},
                "ego_polygon": {1: "ego_token_size"},
                "ego_polyline": {1: "ego_token_size"},
                "ego_polymask": {1: "ego_token_size"},
                "ego_property": {1: "ego_token_size"},
                "output": {1: "token_size"},
            },
        )
        inputs_a_py = [t.cpu().numpy() for t in inputs_a]
        with open(os.path.join(onnx_data_dir, "input_a.pkl"), "wb") as w:
            pickle.dump(inputs_a_py, w)
        print("modelA done.")

        with open(os.path.join(onnx_data_dir, "selected_indices.pkl"), "wb") as w:
            pickle.dump(
                selected_indices.cpu().numpy()[
                    : env_input_polygon.shape[1] + dyn_input_polygon.shape[1] + ego_polygon.shape[1] - 2
                ],
                w,
            )

        # Model C
        model_c.save_pretrained(model_c_dir, safe_serialization=False)
        print("model C done.")
        # copy file
        shutil.copyfile(cfg.TEMPLATE_SET_FILE, os.path.join(save_path, os.path.basename(cfg.TEMPLATE_SET_FILE)))
        shutil.copytree("tpp_onemodel/data/dataset/plannn2_dataset_utils/utils", os.path.join(save_path, "src/utils"))
        shutil.copyfile("tpp_onemodel/plannn_trace/net_abc.py", os.path.join(save_path, "src", "net.py"))
        # shutil.copyfile("tpp_onemodel/plannn_trace/infer_onnx.py", os.path.join(save_path, "infer.py"))

        repo = git.Repo(search_parent_directories=True)
        trace_commit = repo.head.object.hexsha

        if not os.path.exists(os.path.join(save_path, "version_info")):
            os.makedirs(os.path.join(save_path, "version_info"), exist_ok=True)
        with open(os.path.join(save_path, "version_info/info.txt"), "w") as f:
            f.write(f"commit: {trace_commit}\n")
            f.write(f"ckpt path: {ckpt_path}\n")

        print(save_path)


def torch_fix_precision():
    """Set torch fix_precision for determinsim."""
    torch.backends.cudnn.enabled = False
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    torch.manual_seed(0)
    torch.cuda.manual_seed(0)
    torch.cuda.manual_seed_all(0)
    torch.use_deterministic_algorithms(True, warn_only=True)


if __name__ == "__main__":
    load_plus()
    torch.distributed.init_process_group(
        backend="nccl",
        init_method="tcp://localhost:9995",
        world_size=1,
        rank=0,
    )

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--cfg_path", type=str, default="experiments/task_planner/exp_plannn2/cfg_plannn2_trace.py", help="planner cfg"
    )
    parser.add_argument(
        "--ckpt_path",
        type=str,
        default="/share-global/AIP/nioml/ad-cn-hlidc-aip-experiment/Perception-Visual-Dynamic/prod/experiment/775989/task_planner/exp_plannn2/pre_0513_tl_v2/ckpt/checkpoint_epoch002_step0001.pth.tar",
        help="input ckpt path",
    )
    parser.add_argument(
        "--save_path", type=str, default="/share-global/xin.fu2/plannn2_trace/acc_kappa/pre_0513_tl_v2_epoch002", help="output traced model path"
    )
    args = parser.parse_args()

    test_planner_model_trace(
        os.environ.get("CI_CFG_PATH", args.cfg_path),
        os.environ.get("CI_CKPT_PATH", args.ckpt_path),
        os.environ.get("CI_SAVE_PATH", args.save_path),
    )
