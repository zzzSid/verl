# -*- coding: utf-8 -*-
# flake8: noqa: I001,D103,E501
"""Planner model trace test."""

import argparse
import copy
import logging
import os
import os.path as osp
from typing import Dict
from typing import List

import numpy as np
import pytest
import torch
import torch.nn.functional as func
from prettytable import PrettyTable
from torchpilot.utils.cfg_parser import PyConfig
from torchpilot.utils.plus_manager import load_plus
from torchpilot.utils.registries import DATALOADER
from torchpilot.utils.registries import TASK_MODEL
from torchpilot.utils.settings import settings

from tpp_onemodel.tools.astra_planner.deploy.trace_keys import INPUT_TEMPORAL_KEYS
from tpp_onemodel.tools.astra_planner.deploy.trace_keys import TRACE_INPUT_KEYS
from tpp_onemodel.tools.astra_planner.deploy.trace_keys import TRACE_INPUT_SHAPE
from tpp_onemodel.tools.astra_planner.deploy.trace_keys import TRACE_INPUT_TYPE
from tpp_onemodel.tools.astra_planner.deploy.trace_keys import TRACE_OUTPUT_KEYS
from tpp_onemodel.tools.astra_planner.deploy.trace_keys import TRACE_OUTPUT_SHAPE
from tpp_onemodel.tools.astra_planner.deploy.trace_keys import TRACE_OUTPUT_TYPE
from tpp_onemodel.tools.astra_planner.deploy.trace_keys import TRACE_REWARD_OUTPUT_KEYS


logger = logging.getLogger(__name__)


@pytest.mark.skip("No longer support.")
def test_planner_model_trace(planner_trace_stage2_ar_config_path, ckpt_path=None, save_path=None):
    """Planner Model with reward trace test."""
    torch.backends.__allow_nonbracketed_mutation_flag = True
    torch_fix_precision()

    default_path = gen_ar_default_path()
    cfg_path = (
        planner_trace_stage2_ar_config_path
        if planner_trace_stage2_ar_config_path is not None
        else default_path["cfg_path"]
    )
    ckpt_path = ckpt_path if ckpt_path is not None else default_path["ckpt_path"]
    save_path = save_path if save_path is not None else default_path["save_path"]

    if isinstance(ckpt_path, str) and not osp.exists(ckpt_path):
        raise FileNotFoundError(f"Checkpoint not found under: {ckpt_path}.")

    if osp.exists(osp.dirname(save_path)):
        logger.warning("Existing save path: %s", osp.dirname(save_path))
    os.makedirs(osp.dirname(save_path), exist_ok=True)

    cfg = PyConfig.fromfile(cfg_path)
    with torch.set_grad_enabled(False):
        task_cfg = cfg.infer_task_flow.task_model_cfg
        cfg.evaluator.dump_image = False
        task_cfg.dump_image_2stage = False
        task_cfg.zero_shot_aug_enable = False

        # update TRACE OUTPUT for reward
        trajectory_sample_cfg = task_cfg.sub_module_cfg.astra_planner_stage2_head.decoder_cfg.trajectory_sample_cfg
        num_reward_sample = (
            trajectory_sample_cfg.longtitude.num_sample
            * (trajectory_sample_cfg.latitude.num_sample + 1)  # 1 for origin trajectory
            + 1
        )  # 1 for lane keep trajectory
        settings.enable_compile = False
        planner_infer_pipeline = TASK_MODEL.build(task_cfg)

        def load_ckpt_from_str(ckpt_path):
            """Load ckpt from str."""
            ckpt = torch.load(ckpt_path, map_location=torch.device("cpu"))
            new_state_dict = {}
            for name, weight in ckpt["model"].items():
                new_state_dict.update({name.replace("module._task_model.", ""): weight})
            return new_state_dict

        def load_ckpt_from_dict(ckpt_path):
            """Load ckpt from dict."""
            task_name_list = list(ckpt_path.keys())
            for task_name in task_name_list:
                if task_name.find(",") != -1:
                    ckpt_path.update({key: ckpt_path[task_name] for key in task_name.split(",")})
                    ckpt_path.pop(task_name)

            new_state_dict = {}
            for task_name, ckpt_path in ckpt_path.items():
                ckpt = torch.load(ckpt_path, map_location=torch.device("cpu"))
                task_name = task_name.split(",")
                for name, weight in ckpt["model"].items():
                    for t_n in task_name:
                        if t_n in name:
                            new_state_dict.update({name.replace("module._task_model.", ""): weight})
                            break
            return new_state_dict

        logger.info("Loading ckpt from %s ...", ckpt_path)
        if isinstance(ckpt_path, str):
            state_dict = load_ckpt_from_str(ckpt_path)
        elif isinstance(ckpt_path, dict):
            state_dict = load_ckpt_from_dict(ckpt_path)
        missing_keys, unexpected_keys = planner_infer_pipeline.load_state_dict(state_dict, strict=False)
        logger.info("Missing keys: %s", missing_keys)
        logger.info("Unexpected keys: %s", unexpected_keys)

        planner_infer_pipeline = planner_infer_pipeline.cuda()
        planner_infer_pipeline = planner_infer_pipeline.eval()

        planner_infer_pipeline.infer_forward = planner_infer_pipeline.trace_forward
        # build dataloader
        data_cfg = cfg.infer_dataloader
        data_cfg.batch_size = 1
        data_cfg.num_workers = 1
        data_cfg.sampler_cfg.shuffle = False
        data_loader = DATALOADER.build(data_cfg)
        samples = next(iter(data_loader))

        # planner model
        sample = list(samples.values())[0]
        inputs = prepare_trace_input(sample)
        trace_inputs = copy.deepcopy(inputs)
        for input_val, input_shape, input_type in zip(trace_inputs, TRACE_INPUT_SHAPE, TRACE_INPUT_TYPE):
            if input_val.shape != input_shape:
                raise ValueError(f"Input shape mismatch: {input_val.shape} vs {input_shape}")
            if input_val.dtype != input_type:
                raise ValueError(f"Input type mismatch: {input_val.dtype} vs {input_type}")

        outputs = planner_infer_pipeline(*inputs)

        traced_model = torch.jit.trace(planner_infer_pipeline, inputs).eval()
        torch.jit.save(traced_model, save_path)
        result = traced_model(*trace_inputs)

        with open(save_path.replace(".pt", "_code.txt"), "w") as fw:
            fw.writelines(traced_model.forward.code)

        with open(save_path.replace(".pt", "_graph.txt"), "w") as fw:
            fw.writelines(traced_model.graph.str())

        dump_api_for_tvm(
            save_path.replace(".pt", "_inputs_outputs_info.txt"),
            inputs,
            result,
        )

        diff_info = PrettyTable()
        diff_info.field_names = [
            "Name",
            "Max Diff",
            "Shape",
            "Dtype",
        ]
        no_pass = False
        for key, output_shape, output_type, v1, v2 in zip(
            TRACE_OUTPUT_KEYS, TRACE_OUTPUT_SHAPE, TRACE_OUTPUT_TYPE, outputs, result
        ):
            if key in TRACE_REWARD_OUTPUT_KEYS and output_shape[1] != num_reward_sample:
                output_shape = torch.Size([1, num_reward_sample, *output_shape[2:]])
            diff_str = "Pass!" if torch.allclose(v1, v2, atol=1e-03) else torch.abs(v1 - v2).max()
            diff_info.add_row([key, diff_str, str(output_shape), str(output_type)])

            if (
                (output_type != torch.int64 and torch.abs(v1 - v2).max() > 1e-01)
                or v2.shape != output_shape
                or v2.dtype != output_type
            ):
                no_pass = True
                print(f"Output {key} diff: {diff_str}")
                print(f"Output {key} shape: {v2.shape} vs {output_shape}")
                print(f"Output {key} dtype: {v2.dtype} vs {output_type}")

        logger.info("\n%s", diff_info.get_string())
        if no_pass:
            raise ValueError("Gap found in output of ckpt and trace model.")

        def cuda_device_checker(module_name, traced_module):
            """Check cuda device."""
            try:
                if traced_module.code.find("cuda:") >= 0:
                    raise ValueError(
                        f"Cuda:0 found in module {module_name}. Please use device='cuda' instead of device=tensor.device in module forward."
                    )
            except AttributeError as e:
                if str(e) == "'RecursiveScriptModule' object has no attribute 'code'":
                    pass
                else:
                    raise e

            for name, module in traced_module._modules._python_modules.items():
                cuda_device_checker(name, module)

        cuda_device_checker("top", traced_model)

        logger.info("Trace done.")


def dump_api_for_tvm(save_path, inputs, outputs) -> None:
    """Dump io meta info and data for tvm."""
    input_meta_info = PrettyTable()
    input_meta_info.field_names = [
        "Input Index",
        "Shape",
        "Dtype",
    ]
    for item_index, item in enumerate(inputs):
        input_meta_info.add_row([item_index, item.shape, item.dtype])

    output_meta_info = PrettyTable()
    output_meta_info.field_names = [
        "Output Index",
        "Name",
        "Shape",
        "Dtype",
    ]
    for item_index, item in enumerate(outputs):
        output_meta_info.add_row(
            [
                item_index,
                TRACE_OUTPUT_KEYS[item_index],
                item.shape,
                item.dtype,
            ]
        )

    dump_str = input_meta_info.get_string() + "\n" + output_meta_info.get_string()
    with open(save_path, "w", encoding="utf-8") as fout:
        fout.write(dump_str)

    save_dir = osp.dirname(save_path)
    input_np_dict = {k: v.cpu().numpy() for k, v in zip(TRACE_INPUT_KEYS, inputs)}
    input_dir = osp.join(save_dir, "input")
    os.makedirs(input_dir, exist_ok=True)
    np.save(osp.join(input_dir, "input.npy"), input_np_dict, allow_pickle=True)

    output_np_dict = {k: v.cpu().numpy() for k, v in zip(TRACE_OUTPUT_KEYS, outputs)}
    output_dir = osp.join(save_dir, "output")
    os.makedirs(output_dir, exist_ok=True)
    np.save(osp.join(output_dir, "output.npy"), output_np_dict, allow_pickle=True)


def interpolate_tensor(x: torch.Tensor, target_size: int) -> torch.Tensor:
    """Inerpolate tensors (at least 2D is required, max supporting 4D tensor).

    Args:
        x (torch.Tensor): _description_
        target_size (int): _description_
        mode (str, optional): _description_. Defaults to "linear".

    Returns:
        torch.Tensor: _description_
    """
    dim = x.dim()
    interpolate_mode = {2: "linear", 3: "bilinear", 4: "trilinear"}
    mode = interpolate_mode.get(dim, "linear")
    # relocate T dim to last
    x = x.permute(0, *range(2, dim), 1)
    # added 1 dummy dim to allow using trilinear for 4D tensor
    x = x.unsqueeze(1)
    x_interpolated = func.interpolate(x, size=(*x.shape[2:-1], target_size), mode=mode, align_corners=False)
    # Recovering to original shape
    x_interpolated = x_interpolated.squeeze(1).permute(0, -1, *range(1, dim - 1))

    return x_interpolated


def prepare_trace_input(sample) -> List[torch.Tensor]:
    """Reformat trace_model input from infer dataloader."""
    input_list = []
    for idx, key in enumerate(TRACE_INPUT_KEYS):
        if key in INPUT_TEMPORAL_KEYS:
            data = interpolate_tensor(sample[key], 45)

        else:
            if key not in sample:
                data = torch.zeros(*TRACE_INPUT_SHAPE[idx])
            else:
                data = sample[key]
        input_list.append(data.float().cuda())

    return input_list


def torch_fix_precision():
    """Set torch fix_precision for determinsim."""
    torch.backends.cudnn.enabled = False
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    torch.manual_seed(0)
    torch.cuda.manual_seed(0)
    torch.cuda.manual_seed_all(0)
    torch.use_deterministic_algorithms(True, warn_only=True)


def gen_ar_default_path() -> Dict:
    """Generate ar default path."""
    return {
        "cfg_path": "experiments/task_planner/exp_planner_release/cfg_planner_astra_planner_stage2_ar_trace.py",
        "ckpt_path": {
            "auto_regressive_planner": "/share-global/AIP/nioml/ad-cn-hlidc-aip-experiment/Foundation-Model-Decision-Planning/prod/experiment/592631/task_planner/exp_planner_release/AR_pretrain_0604_fix2/ckpt/checkpoint_last.pth.tar",
            "goal_point_planner,astra_planner_stage2": "/share-global/xin.li25/release/planner/release_20250428_beta3/ckpt/checkpoint_fused.pth.tar",
        },
        "save_path": "./export_models/test/trace/astra_planner_trace_model.pt",
    }


if __name__ == "__main__":
    load_plus()
    torch.distributed.init_process_group(
        backend="nccl",
        init_method="tcp://localhost:9999",
        world_size=1,
        rank=0,
    )

    parser = argparse.ArgumentParser()
    parser.add_argument("--cfg_path", type=str, default=None, help="planner cfg")
    parser.add_argument("--ckpt_path", type=str, default=None, help="input ckpt path")
    parser.add_argument("--save_path", type=str, default=None, help="output traced model path")
    args = parser.parse_args()

    test_planner_model_trace(args.cfg_path, args.ckpt_path, args.save_path)
