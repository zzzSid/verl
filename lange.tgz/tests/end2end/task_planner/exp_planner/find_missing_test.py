import json
import multiprocessing as mp
from functools import partial
from tqdm import tqdm
import time
import os


def extract_path_from_line(line):
    """
    从一行数据中提取 path
    支持两种格式：
    1. JSON格式：{"path": "xxx", ...} -> 提取 path 字段
    2. 纯文本格式：path/to/file.pkl size lineno -> 整行作为 path
    """
    line = line.strip()
    if not line:
        return None

    # 尝试解析为JSON（pretrain格式）
    if line.startswith('{'):
        try:
            data = json.loads(line)
            return data.get('path')
        except json.JSONDecodeError:
            pass

    # 纯文本格式（sft格式）
    # 整行作为 path（包括空格后的 size lineno）
    return line


def extract_paths_from_chunk(lines_chunk):
    """
    从一块数据中提取所有 path
    支持 pretrain (JSON) 和 sft (纯文本) 两种格式
    """
    paths = set()
    for line in lines_chunk:
        path = extract_path_from_line(line)
        if path:
            paths.add(path)
    return paths


def process_a_chunk(lines, paths_b_set, chunk_id=None):
    """
    处理 A 文件的一个数据块，找出缺失的记录
    支持 pretrain (JSON) 和 sft (纯文本) 两种格式
    """
    missing_lines = []
    for line in lines:
        path = extract_path_from_line(line)
        if path and path not in paths_b_set:
            missing_lines.append(line.strip())
    return missing_lines


def read_file_in_chunks(file_path, chunk_size=10000):
    """
    将文件分块读取
    """
    chunks = []
    current_chunk = []

    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            current_chunk.append(line)
            if len(current_chunk) >= chunk_size:
                chunks.append(current_chunk)
                current_chunk = []
        if current_chunk:
            chunks.append(current_chunk)

    return chunks


def read_large_file_generator(file_path, chunk_size=8192):
    """
    使用生成器高效读取大文件，避免一次性加载到内存

    Args:
        file_path: 文件路径
        chunk_size: 读取缓冲区大小

    Yields:
        每一行的内容（去除换行符）
    """
    with open(file_path, 'r', encoding='utf-8') as f:
        buffer = ''
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                # 处理最后剩余的内容
                if buffer:
                    yield buffer
                break
            buffer += chunk
            lines = buffer.split('\n')
            # 保留最后不完整的行到下一次读取
            buffer = lines.pop()
            for line in lines:
                if line:  # 跳过空行
                    yield line


def get_file_list_fast(dataloader_file):
    """
    快速读取多个大文件，使用生成器避免内存溢出。
    支持两种数据格式：
    - pretrain: 文件路径列表，文件内容每行是 JSON
    - sft: 嵌套字典，文件内容每行是 str (路径)

    Args:
        dataloader_file: dict，包含 "pretrain" 和/或 "sft" 键

    Yields:
        每一行的内容（pretrain 为 JSON 字符串，sft 为路径字符串）
    """
    # 处理 pretrain 数据
    if "pretrain" in dataloader_file:
        pretrain_files = dataloader_file["pretrain"]
        if isinstance(pretrain_files, list):
            for file_path in pretrain_files:
                print(f"[Pretrain] 正在读取文件: {file_path}")
                line_count = 0
                for line in read_large_file_generator(file_path):
                    yield line
                    line_count += 1
                    if line_count % 100000 == 0:
                        print(f"  [Pretrain] 已读取 {line_count} 行...")
                print(f"  [Pretrain] 文件读取完成，共 {line_count} 行")

    # 处理 sft 数据
    if "sft" in dataloader_file:
        sft_data = dataloader_file["sft"]
        print("[SFT] 开始处理 sft 数据...")

        def process_sft_value(value, parent_key=""):
            """递归处理 sft 数据的值"""
            if isinstance(value, list):
                # 文件路径列表
                for file_path in value:
                    if isinstance(file_path, str):
                        print(f"[SFT{parent_key}] 正在读取文件: {file_path}")
                        line_count = 0
                        for line in read_large_file_generator(file_path):
                            yield line
                            line_count += 1
                            if line_count % 1000 == 0:
                                print(f"  [SFT{parent_key}] 已读取 {line_count} 行...")
                        print(f"  [SFT{parent_key}] 文件读取完成，共 {line_count} 行")
            elif isinstance(value, dict):
                # 嵌套字典，递归处理
                for key, sub_value in value.items():
                    yield from process_sft_value(sub_value, f"{parent_key}/{key}")

        # 遍历 sft 的各个类别
        if isinstance(sft_data, dict):
            for category, category_data in sft_data.items():
                yield from process_sft_value(category_data, f"/{category}")
        elif isinstance(sft_data, list):
            # sft 直接是列表的情况
            yield from process_sft_value(sft_data, "")

def count_total_lines_from_dataloader(dataloader_file):
    """
    统计 dataloader_file 格式中的所有文件总行数
    """
    total_lines = 0
    for line in get_file_list_fast(dataloader_file):
        total_lines += 1
    return total_lines


def read_dataloader_in_chunks(dataloader_file, chunk_size=10000):
    """
    将 dataloader_file 格式的所有文件内容分块读取
    支持 pretrain 和 sft 格式

    Args:
        dataloader_file: dict，包含 "pretrain" 和/或 "sft" 键
        chunk_size: 每个块的大小

    Returns:
        所有数据块的列表
    """
    chunks = []
    current_chunk = []

    for line in get_file_list_fast(dataloader_file):
        current_chunk.append(line)
        if len(current_chunk) >= chunk_size:
            chunks.append(current_chunk)
            current_chunk = []

    if current_chunk:
        chunks.append(current_chunk)

    return chunks


def find_missing_optimized(files_a, file_b, output_c, num_processes=None, chunk_size=10000):
    """
    多进程处理，B 文件也使用多进程读取

    Args:
        files_a: dict，dataloader_file 格式，包含 "pretrain" 和/或 "sft" 键
        file_b: str，单个文件路径
        output_c: str，输出文件路径
        num_processes: int，进程数
        chunk_size: int，每个块的大小
    """
    if num_processes is None:
        num_processes = mp.cpu_count()

    print("=" * 70)
    print("步骤 1/4: 统计文件行数...")
    print("=" * 70)

    # 统计 A 文件的行数（支持 dataloader_file 格式）
    print("正在统计 A 文件（dataloader_file 格式）总行数...")
    total_lines_a = count_total_lines_from_dataloader(files_a)
    total_lines_b = sum(1 for _ in open(file_b, 'r', encoding='utf-8'))
    print(f"✓ A 文件总行数: {total_lines_a:,}")
    print(f"✓ B 文件总行数: {total_lines_b:,}")

    print("\n" + "=" * 70)
    print(f"步骤 2/4: 使用 {num_processes} 个进程并行读取 B 文件...")
    print("=" * 70)

    # 第一步：将 B 文件分块
    b_start_time = time.time()

    print("正在将 B 文件分块...")
    b_chunks = read_file_in_chunks(file_b, chunk_size)
    total_b_chunks = len(b_chunks)
    print(f"✓ B 文件分块完成，共 {total_b_chunks:,} 个数据块")

    # 多进程提取 B 的所有 path
    print(f"正在使用 {num_processes} 个进程提取 path...")
    with mp.Pool(num_processes) as pool:
        # 使用 tqdm 显示进度
        results = []
        with tqdm(total=total_b_chunks, desc="提取 B 文件 path", unit="块", ncols=100) as pbar:
            for result in pool.imap_unordered(extract_paths_from_chunk, b_chunks):
                results.append(result)
                pbar.update(1)

    # 合并所有 path
    print("正在合并 path...")
    paths_b = set()
    for result_set in results:
        paths_b.update(result_set)

    b_elapsed = time.time() - b_start_time
    print(f"\n✓ B 文件读取完成！")
    print(f"  - 唯一 path 数: {len(paths_b):,}")
    print(f"  - 耗时: {b_elapsed:.2f} 秒")

    print("\n" + "=" * 70)
    print(f"步骤 3/4: 使用 {num_processes} 个进程处理 A 文件...")
    print("=" * 70)

    # 第二步：分块读取 A 文件（支持 dataloader_file 格式）
    a_start_time = time.time()

    print("正在将 A 文件（dataloader_file 格式）分块...")
    a_chunks = read_dataloader_in_chunks(files_a, chunk_size)
    total_a_chunks = len(a_chunks)
    print(f"✓ A 文件分块完成，共 {total_a_chunks:,} 个数据块")

    # 多进程处理 A 文件
    with mp.Pool(num_processes) as pool:
        # 使用 partial 固定 paths_b 参数
        func = partial(process_a_chunk, paths_b_set=paths_b)

        # 使用 tqdm 显示进度
        results = []
        with tqdm(total=total_a_chunks, desc="处理 A 文件", unit="块", ncols=100) as pbar:
            for result in pool.imap_unordered(func, a_chunks):
                results.append(result)
                pbar.update(1)
                pbar.set_postfix({"发现缺失": sum(len(r) for r in results)})

    a_elapsed = time.time() - a_start_time

    # 合并结果
    print("\n" + "=" * 70)
    print("步骤 4/4: 写入结果文件...")
    print("=" * 70)

    write_start_time = time.time()
    missing_count = 0

    with open(output_c, 'w', encoding='utf-8') as f_c:
        for missing_lines in results:
            for line in missing_lines:
                f_c.write(line + '\n')
                missing_count += 1

    write_elapsed = time.time() - write_start_time

    # 输出统计信息
    print("\n" + "=" * 70)
    print("✅ 处理完成！统计信息：")
    print("=" * 70)
    print(f"📊 A 文件总行数: {total_lines_a:,}")
    print(f"📊 B 文件总行数: {total_lines_b:,}")
    print(f"📊 B 文件唯一 path: {len(paths_b):,}")
    print(f"📊 缺失记录数: {missing_count:,}")
    print(f"\n⏱️  耗时统计：")
    print(f"  - 读取 B 文件: {b_elapsed:.2f} 秒")
    print(f"  - 处理 A 文件: {a_elapsed:.2f} 秒")
    print(f"  - 写入结果文件: {write_elapsed:.2f} 秒")
    print(f"  - 总耗时: {b_elapsed + a_elapsed + write_elapsed:.2f} 秒")
    print(f"  - 平均速度: {total_lines_a / (a_elapsed + write_elapsed):.0f} 行/秒")
    print(f"\n💾 结果已保存到: {output_c}")

# 更激进的优化版：使用更快的 JSON 解析器
def find_missing_with_orjson(files_a, file_b, output_c, num_processes=None, chunk_size=10000):
    """
    使用 orjson 加速解析（需要安装：pip install orjson）

    Args:
        files_a: dict，dataloader_file 格式，包含 "pretrain" 和/或 "sft" 键
        file_b: str，单个文件路径
        output_c: str，输出文件路径
        num_processes: int，进程数
        chunk_size: int，每个块的大小
    """
    # 初始化 orjson
    orjson = None
    use_orjson = False

    try:
        import orjson as _orjson
        orjson = _orjson
        use_orjson = True
        print("✓ 检测到 orjson，将使用加速解析")
    except ImportError:
        use_orjson = False
        print("⚠️ 未安装 orjson，使用标准 json 库（建议安装：pip install orjson）")

    if use_orjson and orjson is not None:
        def parse_line(line):
            try:
                return orjson.loads(line)
            except Exception:
                return None
    else:
        def parse_line(line):
            try:
                return json.loads(line)
            except Exception:
                return None

    def extract_path_from_line_fast(line):
        """
        快速从一行数据中提取 path
        支持两种格式：
        1. JSON格式：{"path": "xxx", ...} -> 提取 path 字段
        2. 纯文本格式：path/to/file.pkl size lineno -> 整行作为 path
        """
        line = line.strip()
        if not line:
            return None

        # 尝试解析为JSON（pretrain格式）
        if line.startswith('{'):
            data = parse_line(line)
            if data and isinstance(data, dict):
                return data.get('path')

        # 纯文本格式（sft格式）
        # 整行作为 path（包括空格后的 size lineno）
        return line

    def extract_paths_from_chunk_fast(lines_chunk):
        """快速提取 path - 支持 pretrain (JSON) 和 sft (纯文本) 两种格式"""
        paths = set()
        for line in lines_chunk:
            path = extract_path_from_line_fast(line)
            if path:
                paths.add(path)
        return paths

    def process_a_chunk_fast(lines, paths_b_set):
        """快速处理 A 文件块 - 支持 pretrain (JSON) 和 sft (纯文本) 两种格式"""
        missing_lines = []
        for line in lines:
            path = extract_path_from_line_fast(line)
            if path and path not in paths_b_set:
                missing_lines.append(line.strip())
        return missing_lines

    if num_processes is None:
        num_processes = mp.cpu_count()

    print("=" * 70)
    print("步骤 1/4: 统计文件行数...")
    print("=" * 70)

    print("正在统计 A 文件（dataloader_file 格式）总行数...")
    total_lines_a = count_total_lines_from_dataloader(files_a)
    total_lines_b = sum(1 for _ in open(file_b, 'r', encoding='utf-8'))
    print(f"✓ A 文件总行数: {total_lines_a:,}")
    print(f"✓ B 文件总行数: {total_lines_b:,}")

    print("\n" + "=" * 70)
    print(f"步骤 2/4: 使用 {num_processes} 个进程并行读取 B 文件...")
    print("=" * 70)

    b_start_time = time.time()

    print("正在将 B 文件分块...")
    b_chunks = read_file_in_chunks(file_b, chunk_size)
    total_b_chunks = len(b_chunks)
    print(f"✓ B 文件分块完成，共 {total_b_chunks:,} 个数据块")

    print(f"正在使用 {num_processes} 个进程提取 path...")
    with mp.Pool(num_processes) as pool:
        results = []
        with tqdm(total=total_b_chunks, desc="提取 B 文件 path", unit="块", ncols=100) as pbar:
            for result in pool.imap_unordered(extract_paths_from_chunk_fast, b_chunks):
                results.append(result)
                pbar.update(1)

    print("正在合并 path...")
    paths_b = set()
    for result_set in results:
        paths_b.update(result_set)

    b_elapsed = time.time() - b_start_time
    print(f"\n✓ B 文件读取完成！唯一 path 数: {len(paths_b):,}，耗时: {b_elapsed:.2f} 秒")

    print("\n" + "=" * 70)
    print(f"步骤 3/4: 使用 {num_processes} 个进程处理 A 文件...")
    print("=" * 70)

    a_start_time = time.time()

    print("正在将 A 文件（dataloader_file 格式）分块...")
    a_chunks = read_dataloader_in_chunks(files_a, chunk_size)
    total_a_chunks = len(a_chunks)
    print(f"✓ A 文件分块完成，共 {total_a_chunks:,} 个数据块")

    with mp.Pool(num_processes) as pool:
        func = partial(process_a_chunk_fast, paths_b_set=paths_b)
        results = []
        with tqdm(total=total_a_chunks, desc="处理 A 文件", unit="块", ncols=100) as pbar:
            for result in pool.imap_unordered(func, a_chunks):
                results.append(result)
                pbar.update(1)
                pbar.set_postfix({"发现缺失": sum(len(r) for r in results)})

    a_elapsed = time.time() - a_start_time

    print("\n" + "=" * 70)
    print("步骤 4/4: 写入结果文件...")
    print("=" * 70)

    write_start_time = time.time()
    missing_count = 0

    with open(output_c, 'w', encoding='utf-8') as f_c:
        for missing_lines in results:
            for line in missing_lines:
                f_c.write(line + '\n')
                missing_count += 1

    write_elapsed = time.time() - write_start_time

    print("\n" + "=" * 70)
    print("✅ 处理完成！")
    print("=" * 70)
    print(f"📊 A 文件: {total_lines_a:,} 行")
    print(f"📊 B 文件: {total_lines_b:,} 行")
    print(f"📊 B 唯一 path: {len(paths_b):,}")
    print(f"📊 缺失记录: {missing_count:,}")
    print(f"\n⏱️  耗时: {b_elapsed + a_elapsed + write_elapsed:.2f} 秒")
    print(f"💾 结果: {output_c}")

if __name__ == '__main__':
    # 安装依赖
    # pip install tqdm orjson

    files_a = {
        # "pretrain":["/share-global/nell.dong/data/planner/planner_basedata_20260321_i_4259074.txt"],  # json格式读取
        # "sft": {        # str格式读取，第0元素是pkl addr
        #             # 打灯
        #             "turn_signal": [
        #                 "/share-global/weidong.shi1/data/planner/sft_data_100k.txt",
        #             ],
        #             # 类人性
        #             "humanoid": {
        #                 "humanoid": [
        #                     # 2025年11月底12月初-第1批专家数据-1k
        #                     "/share-global/menghan.pan/st/export_route_1126_1201_1327_mapv5_1_965.txt",
        #                     # 2025年小路1k
        #                     "/share-global/enzo.shu/ppl/humanoid_good_case_1038.txt",
        #                     # 20260113-20260126数采-8.4k 去闸机/自车静止
        #                     "/share-global/sijia.gu/planner/expert_data/0113_0131_all_expert_data_without_static_8411_pkls.txt",
        #                     # 盘桥居中
        #                     "/share-global/qixuan.sun/planner/centralization350/0128_sql_ramp_dig_result_center_pkls.txt",
        #                     # turn
        #                     "/share-global/sijia.gu/planner/expert_data/0202_0210_add_humanoid_turn_expert_data_3383_pkls.txt",
        #                     "/share-global/sijia.gu/planner/expert_data/0211_0213_add_humanoid_turn_expert_data_711_pkls.txt",
        #                     "/share-global/sijia.gu/planner/expert_data/0214_0224_add_humanoid_turn_expert_data_505_pkls.txt",
        #                     "/share-global/sijia.gu/planner/expert_data/0225_0302_add_humanoid_turn_expert_data_1237_pkls.txt",
        #                     # straight
        #                     "/share-global/sijia.gu/planner/expert_data/0123_0201_add_humanoid_straight_expert_data_1373_clips.txt",
        #                     "/share-global/sijia.gu/planner/expert_data/0202_0210_add_humanoid_straight_expert_data_1451_pkls.txt",
        #                     "/share-global/sijia.gu/planner/expert_data/0211_0213_add_humanoid_straight_data_145_pkls.txt",
        #                     "/share-global/sijia.gu/planner/expert_data/0214_0224_add_humanoid_straight_expert_data_78_pkls.txt",
        #                     "/share-global/sijia.gu/planner/expert_data/0225_0302_add_humanoid_straight_expert_data_534_pkls.txt",
        #                     # park
        #                     "/share-global/sijia.gu/planner/expert_data/0123_0201_add_humanoid_park_expert_data_8_clips.txt",
        #                     "/share-global/sijia.gu/planner/expert_data/0202_0210_add_humanoid_park_expert_data_530_pkls.txt",
        #                     "/share-global/sijia.gu/planner/expert_data/0211_0213_add_humanoid_park_data_170_pkls.txt",
        #                     "/share-global/sijia.gu/planner/expert_data/0214_0224_add_humanoid_park_expert_data_95_pkls.txt",
        #                     "/share-global/sijia.gu/planner/expert_data/0225_0302_add_humanoid_park_expert_data_296_pkls.txt",
        #                     # 导航换道
        #                     "/share-global/sijia.gu/planner/expert_data/0113_0131_add_humanoid_navi_expert_data_1481_pkls.txt",
        #                     # 20260113-20260126数采 自车绕行x5
        #                     "/share-global/sijia.gu/planner/expert_data/0113_0126_followstart_x5_expert_data_2465_clips.txt",
        #                 ],
        #             },
        #             # 横向
        #             "lateral": {
        #                 "normal": [
        #                     "/share-global/menghan.pan/rt/CurrentLane_RedWarnSign_Pkl_v6_gt_dataset_1768534370_1_2661_a996c.txt",
        #                     "/share-global/menghan.pan/rt/sod_collision_pkl_1209_2_gt_dataset_1765269030_1_3071_f1df6.txt",
        #                     "/share-global/menghan.pan/rt/sod-0120_gt_dataset_1768877740_1_2454_b172f.txt",
        #                     "/share-global/qi.wang15/dataset/static_scene_god.txt",
        #                     ],
        #                 "center": [
        #                     "/share-global/qixuan.sun/planner/sft_data/original_pkls/0309_ramp_right_turn_lane_with_frame_tag_repeat_minibatch_12401_pkls.txt",
        #                 ],
        #                 "effective_change_lane": [
        #                     "/share-global/chuan.ye/effective_change_lane_keys.txt", # 10883
        #                 ],
        #             },
        #             # 纵向
        #             "longitudinal": {
        #                 "collision": [
        #                     "/share-global/xu.shu/urban/follow_stop_key_10000_sync.txt",
        #                     "/share-global/xu.shu/urban/cross_9223.txt",
        #                     "/share-global/shane.wan/data_mining/vru_cross_32767.txt",
        #                     "/share-global/zhonghao.deng/dataset/data_mining/encounter/narrRoad_encounter_key_9689_no_seg.txt",
        #                     "/share-global/zhonghao.deng/dataset/data_mining/follow_stop/0315/follow_stop_key_0314_1652_no_seg.txt",
        #                 ],
        #                 "tl_start": [
        #                     "/share-global/xin.fu2/planning_data/causal_data/start_data/0119_good_action/tld_start_data_ori.txt"
        #                 ],
        #                 "follow_start": ["/share-global/xu.shu/urban/follow_good_case.txt"],
        #                 "boyi_start": ["/share-global/xu.shu/urban/boyi_start_0130_sel_4833_from_10w.txt"],
        #                 "speed": [
        #                     "/share-global/arise.wu/plannn2/data/gt_speedup_to_limit_11854_train.txt",
        #                 ],
        #             },
        #             # 园区
        #             "campus": [
        #                 "/share-global/bowen.teng/dataset/0313_inner_road_diviation_sft_data_10000.txt",
        #             ],
        #             # 偏航
        #             "deviation": [
        #                 "/share-global/tenglong.xi/data/0315_combined_deviation_sft_data_98237.txt",
        #             ],
        #             # 高速
        #             "highway": {
        #                 "normal": [
        #                     "/share-global/menghan.pan/rt/CurrentLane_RedWarnSign_Pkl_v6_gt_dataset_1768534370_1_2661_a996c.txt",
        #                     "/share-global/menghan.pan/rt/sod_collision_pkl_1209_2_gt_dataset_1765269030_1_3071_f1df6.txt",
        #                     "/share-global/menghan.pan/rt/sod-0120_gt_dataset_1768877740_1_2454_b172f.txt",
        #                     "/share-global/qi.wang15/dataset/static_scene_god.txt",
        #                     "/share-global/timo.li/pkl/cutin_pretrain_good_4868_rep_4_260309.txt",
        #                     "/share-global/barry.xiao/etc_plannn2/data/sft/release/etc_select_sft_0314_7000.txt",
        #                     "/share-global/runlin.he/plannn2/data/hw_cruise_pipeline_779_production_2891.txt",
        #                     "/share-global/runlin.he/plannn2/data/ramp_cruise_pipeline_782_production_992.txt",
        #                 ],
        #                 "hw_general_cutin": [
        #                     "/share-global/timo.li/pkl/cutin_pretrain_good_4868_260309.txt",
        #                 ],
        #             },
        #         }

        "sft": {
                    "test": [
                        "/share-global/charles.qian/data/public/260404_mukuv2/0402_fft_expert_coapp_tag_6925224_training.txt",
                    ],
        }
    }



    find_missing_optimized(
        files_a=files_a,
        file_b="/share-global/nell.dong/data/planner/planner_basedata_20260321_i_4259074.txt",
        output_c="/home/gengda.chen/workspace/melange/missing_012.txt",
        num_processes=120,      # 根据 CPU 核心数调整
        chunk_size=50000      # 每块 2 万行
    )
