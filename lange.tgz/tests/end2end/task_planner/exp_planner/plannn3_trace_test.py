# -*- coding: utf-8 -*-
"""Plannn3 planner trace export test."""

import argparse
import logging
import os
import os.path as osp
import pickle
from typing import Any
from typing import Dict
from typing import List
from typing import Sequence
from typing import Tuple

import git
import numpy as np
import pytest
import torch
import torch.nn.functional as F
from prettytable import PrettyTable
from torch import nn
from torchpilot.utils.cfg_parser import PyConfig
from torchpilot.utils.plus_manager import load_plus
from torchpilot.utils.registries import DATALOADER
from torchpilot.utils.settings import settings

from tpp_onemodel.data.plannn3.nn3_constants import DEFAULT_CROP_SHAPE
from tpp_onemodel.data.plannn3.nn3_constants import DEFAULT_MULTIVIEW_CAMS
from tpp_onemodel.data.plannn3.nn3_constants import DEFAULT_VIDEO_SHAPE
from tpp_onemodel.data.plannn3.nn3_visual_constants import compute_visual_sequence_sizes
from tpp_onemodel.data.plannn3.nn3_image_norm import NN3_IMAGE_NORM_SCALE
from tpp_onemodel.model.module.plannn2_modules import Plannn2LayerNorm
from tpp_onemodel.model.task.plannn3_task_model import Plannn3TaskModel


logger = logging.getLogger(__name__)


RAW_RESIZE_TARGET_SHAPE = {
    "/camera/front/main": [2168, 3848],
    "/camera/front/narrow": [2168, 3848],
    "/camera/side/front/left": [2168, 3848],
    "/camera/side/front/right": [2168, 3848],
    "/camera/side/rear/left": [2168, 3848],
    "/camera/side/rear/right": [2168, 3848],
    "/camera/rear": [2168, 3848],
}

RAW_CROP_TARGET_SHAPE = {
    "/camera/front/main": [2168, 3848, 0, 0],
    "/camera/front/narrow": [2168, 3848, 0, 0],
    "/camera/side/front/left": [2168, 3848, 0, 0],
    "/camera/side/front/right": [2168, 3848, 0, 0],
    "/camera/side/rear/left": [2168, 3848, 0, 0],
    "/camera/side/rear/right": [2168, 3848, 0, 0],
    "/camera/rear": [2168, 3848, 0, 0],
}


@pytest.fixture()
def plannn3_trace_config_path() -> str:
    """Plannn3 trace config path."""
    return os.path.join(
        "experiments",
        "task_planner",
        "exp_plannn3",
        "cfg_plannn3_trace.py",
    )


@pytest.fixture()
def plannn3_trace_ckpt_path() -> str:
    """Plannn3 trace checkpoint path."""
    return os.environ.get(
        "CI_CKPT_PATH",
        os.path.join(
            "/share-global",
            "angie.wang",
            "ckpts",
            "ep_800399_0608_nn3_train_baseline_epoch008_with_hist_traj_v2.pth.tar",
        ),
    )


@pytest.fixture()
def plannn3_trace_save_path() -> str:
    """Plannn3 trace save path."""
    return os.environ.get("CI_SAVE_PATH", "./export_models/plannn3_trace")


class Plannn3TraceWrapper(nn.Module):
    """Trace wrapper aligned with nn3_local export_logits encoder/prefill/decode."""

    def __init__(self, task_model: Plannn3TaskModel):
        super().__init__()
        self.task_model = task_model
        self.state_range = float(task_model.infer_cfg.state_range)
        first_attn = task_model.transfomer["h"][0].attn
        self.n_head = first_attn.n_head
        self.hidden_size = first_attn.n_embd
        self.head_dim = self.hidden_size // self.n_head
        self.max_seq_len = first_attn.kv_cache.k_cache.shape[2]
        self.resize_target_shape = {cam: tuple(DEFAULT_CROP_SHAPE[cam]) for cam in DEFAULT_MULTIVIEW_CAMS}
        visual_encoder = getattr(task_model, "visual_encoder", None)
        visual_video_shape = getattr(visual_encoder, "video_shape", DEFAULT_VIDEO_SHAPE)
        self.crop_target_shape = {cam: tuple(visual_video_shape[cam]) for cam in DEFAULT_MULTIVIEW_CAMS}
        self.llm_dtype = next(task_model.transfomer.parameters()).dtype
        self.visual_dtype = next(task_model.visual_encoder.parameters()).dtype
        self.is_fp16_model = self.llm_dtype == torch.float16

    @staticmethod
    def _resize_crop_image(
        img: torch.Tensor,
        resize_target_size: Tuple[int, int],
        crop_target_size: Tuple[int, ...],
    ) -> torch.Tensor:
        """Resize one ``[C, H, W]`` camera frame and crop to the visual encoder layout."""
        resized_img = F.interpolate(img.unsqueeze(0), size=resize_target_size, mode="nearest").squeeze(0)
        if len(crop_target_size) == 2:
            height, width = crop_target_size
            top = (resize_target_size[0] - crop_target_size[0]) // 2
            left = (resize_target_size[1] - crop_target_size[1]) // 2
        else:
            height, width, top, left = crop_target_size
        return resized_img[:, top: top + height, left: left + width]

    def _image_dict(self, pinhole_raw_img: torch.Tensor) -> Dict[str, torch.Tensor]:
        """Split stacked ``[N, C, H, W]`` raw frames into per-cam normalized 5D tensors."""
        visual_image_data = {}
        for index, cam in enumerate(DEFAULT_MULTIVIEW_CAMS):
            img = self._resize_crop_image(
                pinhole_raw_img[index].float(),
                self.resize_target_shape[cam],
                self.crop_target_shape[cam],
            )
            img = img.to(dtype=self.visual_dtype)
            visual_image_data[f"video:{cam}"] = img.unsqueeze(0).unsqueeze(0) / NN3_IMAGE_NORM_SCALE - 1.0
        return visual_image_data

    def encoder(
        self,
        pinhole_raw_img: torch.Tensor,
        hist_img_feat: torch.Tensor,
        subpath_polylines: torch.Tensor,
        subpath_polylines_mask: torch.Tensor,
        navi_info: torch.Tensor,
        his_traj_next_waypoint: torch.Tensor,
        egos_his_mask: torch.Tensor,
        ego_polygon: torch.Tensor,
        ego_polyline: torch.Tensor,
        ego_polymask: torch.Tensor,
        ego_property: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """Build multimodal prefix plus ego history token embeddings."""
        if self.is_fp16_model:
            subpath_polylines = subpath_polylines.half()
            his_traj_next_waypoint = his_traj_next_waypoint.half()

        prefix_parts = []
        prefill_hist_img_feat = hist_img_feat

        if self.task_model._mm_enable_visual:
            visual_input = {
                "image": self._image_dict(pinhole_raw_img),
                "hist_img_feat": hist_img_feat,
            }
            visual_embeds, _, extra_output = self.task_model.visual_encoder(visual_input)
            prefix_parts.append(visual_embeds)
            if extra_output is not None and extra_output.get("hist_img_feat") is not None:
                prefill_hist_img_feat = extra_output["hist_img_feat"]

        if self.task_model._mm_enable_navi:
            prefix_parts.append(
                self.task_model.navi_encoder(
                    subpath_polylines,
                    subpath_polylines_mask,
                    navi_info,
                )
            )

        if self.task_model._mm_enable_hist_traj:
            prefix_parts.append(
                self.task_model.history_traj_encoder(
                    his_traj_next_waypoint,
                    egos_his_mask,
                )
            )

        poly = {
            "ego": {
                "polygon": ego_polygon,
                "polylines": ego_polyline,
                "polymask": ego_polymask,
                "property": ego_property,
            },
            "state_range": self.state_range,
        }
        ego_embeds, padding_index = self.task_model._encode_ego_from_poly(poly, self.state_range)
        if self.is_fp16_model:
            ego_embeds = ego_embeds.half()

        if prefix_parts:
            prefix_embeds = torch.cat(prefix_parts, dim=1)
            token_embeds = torch.cat([prefix_embeds, ego_embeds], dim=1)
            prefix_padding = torch.zeros(
                (token_embeds.shape[0], prefix_embeds.shape[1]),
                dtype=torch.bool,
                device=token_embeds.device,
            )
            padding_index = torch.cat([prefix_padding, padding_index], dim=1)
        else:
            token_embeds = ego_embeds

        token_embeds = token_embeds.to(dtype=self.llm_dtype)
        position_embeds = torch.zeros_like(token_embeds)
        return token_embeds, position_embeds, padding_index, prefill_hist_img_feat

    def _kv_to_flat(self, k_cache: torch.Tensor, v_cache: torch.Tensor) -> torch.Tensor:
        k_flat = k_cache.transpose(1, 2).reshape(k_cache.shape[0], self.max_seq_len, self.hidden_size)
        v_flat = v_cache.transpose(1, 2).reshape(v_cache.shape[0], self.max_seq_len, self.hidden_size)
        return torch.cat([k_flat, v_flat], dim=2)

    def _flat_to_kv(self, flat_cache: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        k_flat, v_flat = flat_cache.split(self.hidden_size, dim=2)
        batch_size = k_flat.shape[0]
        seq_len = k_flat.shape[1]
        k_cache = k_flat.reshape(batch_size, seq_len, self.n_head, self.head_dim).transpose(1, 2)
        v_cache = v_flat.reshape(batch_size, seq_len, self.n_head, self.head_dim).transpose(1, 2)
        return k_cache, v_cache

    def _pad_padding_index(self, padding_index: torch.Tensor) -> torch.Tensor:
        pad_len = self.max_seq_len - padding_index.shape[1]
        padding_tail = torch.zeros(
            (padding_index.shape[0], pad_len),
            dtype=torch.bool,
            device=padding_index.device,
        )
        return torch.cat([padding_index, padding_tail], dim=1)

    def _pad_kv(
        self,
        k_value: torch.Tensor,
        v_value: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        pad_len = self.max_seq_len - k_value.shape[2]
        pad_shape = (k_value.shape[0], k_value.shape[1], pad_len, k_value.shape[3])
        k_pad = torch.zeros(pad_shape, dtype=k_value.dtype, device=k_value.device)
        v_pad = torch.zeros(pad_shape, dtype=v_value.dtype, device=v_value.device)
        return torch.cat([k_value, k_pad], dim=2), torch.cat([v_value, v_pad], dim=2)

    def _update_one_kv(
        self,
        flat_cache: torch.Tensor,
        input_pos: torch.Tensor,
        k_value: torch.Tensor,
        v_value: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        k_cache, v_cache = self._flat_to_kv(flat_cache)
        positions = torch.arange(self.max_seq_len, device=k_value.device).view(1, 1, self.max_seq_len, 1)
        update_pos = input_pos.view(1, 1, 1, 1)
        update_mask = positions == update_pos
        update_shape = (k_value.shape[0], k_value.shape[1], self.max_seq_len, k_value.shape[3])
        k_update = k_value.expand(update_shape)
        v_update = v_value.expand(update_shape)
        return torch.where(update_mask, k_update, k_cache), torch.where(update_mask, v_update, v_cache)

    def _attention_mask(
        self,
        attn: nn.Module,
        batch_size: int,
        input_pos: torch.Tensor,
        padding_index: torch.Tensor,
        keep_first_env_col: bool,
        mask_dtype: torch.dtype,
    ) -> torch.Tensor:
        bias = attn.bias.expand(batch_size, 1, self.max_seq_len, self.max_seq_len)
        bias = torch.index_select(bias, 2, input_pos)
        padding_mask = padding_index.unsqueeze(1).unsqueeze(2)
        bias = torch.logical_and(bias, torch.logical_not(padding_mask))
        if keep_first_env_col:
            q_positions = input_pos.view(1, 1, input_pos.shape[0], 1)
            k_positions = torch.arange(self.max_seq_len, device=input_pos.device).view(1, 1, 1, self.max_seq_len)
            env_first_col = (q_positions < attn.env_block_size) & (k_positions == 0)
            bias = torch.logical_or(bias, env_first_col)
        bias = bias.to(mask_dtype)
        return (torch.ones_like(bias) - bias) * torch.full_like(bias, -10000.0)

    def _attention_forward(
        self,
        attn: nn.Module,
        hidden_states: torch.Tensor,
        padding_index: torch.Tensor,
        input_pos: torch.Tensor,
        flat_cache: torch.Tensor = None,
        keep_first_env_col: bool = False,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        batch_size, seq_len, hidden_size = hidden_states.size()
        query, key, value = attn.c_attn(hidden_states).split(attn.n_embd, dim=2)
        key = key.view(batch_size, seq_len, attn.n_head, hidden_size // attn.n_head).transpose(1, 2)
        query = query.view(batch_size, seq_len, attn.n_head, hidden_size // attn.n_head).transpose(1, 2)
        value = value.view(batch_size, seq_len, attn.n_head, hidden_size // attn.n_head).transpose(1, 2)

        if flat_cache is None:
            key_full, value_full = self._pad_kv(key, value)
        else:
            key_full, value_full = self._update_one_kv(flat_cache, input_pos, key, value)

        bias = self._attention_mask(attn, batch_size, input_pos, padding_index, keep_first_env_col, query.dtype)
        attn_scores = torch.matmul(query, key_full.transpose(-2, -1))
        attn_scores = attn_scores * torch.full_like(attn_scores, self.head_dim ** -0.5)
        attn_scores = attn_scores + bias
        attn_weights = torch.softmax(attn_scores, dim=-1)
        output = torch.matmul(attn_weights, value_full)
        output = output.transpose(1, 2).contiguous().view(batch_size, seq_len, hidden_size)
        output = attn.resid_dropout(attn.c_proj(output))
        return output, self._kv_to_flat(key_full, value_full)

    def _block_forward(
        self,
        layer: nn.Module,
        hidden_states: torch.Tensor,
        padding_index: torch.Tensor,
        input_pos: torch.Tensor,
        flat_cache: torch.Tensor = None,
        keep_first_env_col: bool = False,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        attn_output, output_kv = self._attention_forward(
            layer.attn,
            layer.ln_1(hidden_states),
            padding_index,
            input_pos,
            flat_cache,
            keep_first_env_col,
        )
        hidden_states = hidden_states + attn_output
        hidden_states = hidden_states + layer.mlp(layer.ln_2(hidden_states))
        return hidden_states, output_kv

    def prefill(
        self,
        token_embeds: torch.Tensor,
        padding_index: torch.Tensor,
        valid_seq_len: torch.Tensor,
    ) -> Tuple[torch.Tensor, ...]:
        """Run prefill and return logits plus flat KV cache tensors."""
        input_pos = torch.arange(token_embeds.shape[1], device=token_embeds.device).long()
        padding_index = self._pad_padding_index(padding_index)
        hidden_states = token_embeds
        output_kvs = []
        for layer in self.task_model.transfomer["h"]:
            hidden_states, output_kv = self._block_forward(
                layer,
                hidden_states,
                padding_index,
                input_pos,
                keep_first_env_col=True,
            )
            output_kvs.append(output_kv)

        index = (valid_seq_len.long() - 1).view(valid_seq_len.shape[0], 1, 1)
        index = index.expand(valid_seq_len.shape[0], 1, self.hidden_size)
        last_hidden = hidden_states.gather(1, index)
        logits = self.task_model.lm_head(self.task_model.transfomer["ln_f"](last_hidden))
        return (logits, *tuple(output_kvs))

    def decode(
        self,
        latest_traj_id: torch.Tensor,
        input_kvs: Sequence[torch.Tensor],
        valid_kv_len: torch.Tensor,
        prefix_ego_padding_index: torch.Tensor,
    ) -> Tuple[torch.Tensor, ...]:
        """Run a one-token decode with explicit flat KV cache inputs."""
        valid_len = valid_kv_len.to(device=latest_traj_id.device, dtype=torch.long)
        input_pos = valid_len
        action_index = torch.clamp(valid_len - prefix_ego_padding_index.shape[1], min=0)
        action_timestamp = self.task_model.history_size + action_index
        hidden_states = self.task_model.action_embedding(latest_traj_id.long())
        timestamp_embed = self.task_model.timestamp_embedding(action_timestamp).view(1, 1, self.hidden_size)
        hidden_states = hidden_states + timestamp_embed.to(hidden_states.dtype)

        padding_index = self._pad_padding_index(prefix_ego_padding_index)

        output_kvs = []
        for layer, flat_cache in zip(self.task_model.transfomer["h"], input_kvs):
            hidden_states, output_kv = self._block_forward(
                layer,
                hidden_states,
                padding_index,
                input_pos,
                flat_cache,
            )
            output_kvs.append(output_kv)

        logits = self.task_model.lm_head(self.task_model.transfomer["ln_f"](hidden_states))
        return (logits, *tuple(output_kvs))

    def forward(
        self,
        pinhole_raw_img: torch.Tensor,
        hist_img_feat: torch.Tensor,
        subpath_polylines: torch.Tensor,
        subpath_polylines_mask: torch.Tensor,
        navi_info: torch.Tensor,
        his_traj_next_waypoint: torch.Tensor,
        egos_his_mask: torch.Tensor,
        ego_polygon: torch.Tensor,
        ego_polyline: torch.Tensor,
        ego_polymask: torch.Tensor,
        ego_property: torch.Tensor,
        valid_seq_len: torch.Tensor,
        latest_traj_id: torch.Tensor,
        *decoder_inputs: torch.Tensor,
    ) -> Tuple[torch.Tensor, ...]:
        """Run encoder, prefill, and one independent decode head."""
        valid_kv_len = decoder_inputs[-1]
        input_kvs = decoder_inputs[:-1]
        token_embeds, _, padding_index, prefill_hist_img_feat = self.encoder(
            pinhole_raw_img,
            hist_img_feat,
            subpath_polylines,
            subpath_polylines_mask,
            navi_info,
            his_traj_next_waypoint,
            egos_his_mask,
            ego_polygon,
            ego_polyline,
            ego_polymask,
            ego_property,
        )
        prefill_outputs = self.prefill(token_embeds, padding_index, valid_seq_len)
        decode_outputs = self.decode(latest_traj_id, input_kvs, valid_kv_len, padding_index)
        return (prefill_hist_img_feat, *prefill_outputs, *decode_outputs)


def test_planner_model_trace(
    plannn3_trace_config_path,
    plannn3_trace_ckpt_path,
    plannn3_trace_save_path,
):
    """Planner Model trace test."""
    torch.backends.__allow_nonbracketed_mutation_flag = True
    torch_fix_precision()

    cfg_path = plannn3_trace_config_path
    save_path = plannn3_trace_save_path
    os.makedirs(save_path, exist_ok=True)

    cfg = PyConfig.fromfile(cfg_path)
    ckpt_path = plannn3_trace_ckpt_path or cfg.INIT_MODEL
    if not osp.exists(ckpt_path):
        raise FileNotFoundError(f"Checkpoint not found under: {ckpt_path}.")

    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required for Plannn3 visual trace export.")

    is_fp16_model = True

    settings.enable_compile = False
    with torch.set_grad_enabled(False):
        task_model = build_task_model(cfg)
        load_checkpoint(task_model, ckpt_path)
        task_model.cuda()
        task_model.eval()
        if is_fp16_model:
            materialize_layer_norm_bias_for_trace(task_model)
            convert_llm_pipeline_to_fp16(task_model)

        data_loader = build_trace_dataloader(cfg)
        samples = next(iter(data_loader))

        wrapper_model = Plannn3TraceWrapper(task_model).cuda().eval()
        dummy_input, input_names = prepare_dummy_input(cfg, wrapper_model, samples)
        output_names = build_output_names(cfg.N_LAYER)

        forward_outputs = wrapper_model(*dummy_input)
        traced_model = export_model_trace(save_path, wrapper_model, dummy_input)
        trace_outputs = traced_model(*dummy_input)
        compare_outputs(trace_outputs, forward_outputs)

        dump_trace_artifacts(
            save_path,
            traced_model,
            dummy_input,
            input_names,
            trace_outputs,
            output_names,
            ckpt_path,
        )

        logger.info("Plannn3 trace export done: %s", save_path)


def convert_llm_pipeline_to_fp16(task_model: Plannn3TaskModel) -> None:
    """Convert the trace-time fp16 modules.

    Ego encoding submodules stay fp32 because ``_encode_ego_from_poly`` upcasts ego_property to
    fp32 internally (``plannn3_task_model.py`` ``ego_property.to(torch.float32)``); converting
    those modules would mismatch with their fp32 inputs. ``timestamp_embedding`` is also kept
    fp32 because it is shared with ``property_embedding``; the wrapper casts its output at the
    LLM-side decode site.
    """
    for module_name in (
        "visual_encoder",
        "navi_encoder",
        "history_traj_encoder",
        "transfomer",
        "lm_head",
        "action_embedding",
    ):
        module = getattr(task_model, module_name, None)
        if module is not None:
            module.to(torch.float16)


def materialize_layer_norm_bias_for_trace(module: nn.Module) -> None:
    """Match nn3_local trace LayerNorm by materializing zero bias parameters."""
    for child in module.modules():
        if isinstance(child, Plannn2LayerNorm) and child.bias is None:
            child.bias = nn.Parameter(torch.zeros_like(child.weight))


def build_task_model(cfg: PyConfig) -> Plannn3TaskModel:
    """Build the Plannn3 task model from infer config."""
    task_cfg = cfg.infer_task_flow.task_model_cfg
    return Plannn3TaskModel(
        sub_module_cfg=task_cfg.sub_module_cfg,
        infer_cfg=task_cfg.infer_cfg,
        train_mode=False,
        multimodal_cfg=task_cfg.multimodal_cfg,
    )


def load_checkpoint(model: nn.Module, ckpt_path: str) -> None:
    """Load a melange Plannn3 checkpoint into the task model."""
    logger.info("Loading ckpt from %s ...", ckpt_path)
    checkpoint = torch.load(ckpt_path, map_location=torch.device("cpu"))
    state_dict = checkpoint.get("model", checkpoint.get("state_dict", checkpoint))

    normalized_state_dict = {}
    for name, weight in state_dict.items():
        normalized_name = name
        for prefix in ("module._task_model.", "_task_model.", "_orig_mod."):
            if normalized_name.startswith(prefix):
                normalized_name = normalized_name[len(prefix) :]
        normalized_state_dict[normalized_name] = weight

    missing_keys, unexpected_keys = model.load_state_dict(normalized_state_dict, strict=False)
    logger.info("Missing keys: %s", missing_keys)
    logger.info("Unexpected keys: %s", unexpected_keys)


def build_trace_dataloader(cfg: PyConfig):
    """Build a deterministic one-sample trace dataloader."""
    data_cfg = cfg.infer_dataloader
    use_raw_visual_trace_inputs(data_cfg)
    data_cfg.batch_size = 1
    data_cfg.num_workers = 0
    data_cfg.sampler_cfg.shuffle = False
    data_cfg.enable_nn3_shared_decoder = False
    data_cfg.pop("prefetch_factor", None)
    data_cfg.pop("multiprocessing_context", None)
    return DATALOADER.build(data_cfg)


def use_raw_visual_trace_inputs(data_cfg: Dict[str, Any]) -> None:
    """Decode raw camera frames and leave visual preprocessing inside the traced graph."""
    dataset_cfg = data_cfg.get("dataset_cfg")
    if not dataset_cfg:
        return

    nn3_visual_cfg = dataset_cfg.get("nn3_visual_cfg")
    if nn3_visual_cfg:
        nn3_visual_cfg["video_shape"] = RAW_CROP_TARGET_SHAPE
        nn3_visual_cfg["crop_shape"] = RAW_RESIZE_TARGET_SHAPE

    for transform in dataset_cfg.get("transforms", []):
        if transform.get("type") != "Plannn3VisualDecodeTransform":
            continue
        transform["video_shape"] = RAW_CROP_TARGET_SHAPE
        transform["crop_shape"] = RAW_RESIZE_TARGET_SHAPE


def prepare_dummy_input(
    cfg: PyConfig,
    wrapper_model: Plannn3TraceWrapper,
    samples: Dict[str, Any],
) -> Tuple[Tuple[torch.Tensor, ...], List[str]]:
    """Prepare trace inputs from one dataloader batch."""
    task_model = wrapper_model.task_model
    device = next(task_model.parameters()).device
    batch_size = samples["ego_polygon"].shape[0]
    pinhole_raw_img = prepare_current_images(samples, device)
    hist_img_feat = prepare_hist_img_feat(cfg, wrapper_model, batch_size, device)

    sequence_size = task_model.env_block_size
    valid_seq_len = torch.tensor([sequence_size], dtype=torch.int32, device=device)
    latest_traj_id = torch.tensor(
        [[min(300, task_model.action_embedding.num_embeddings - 1)]],
        dtype=torch.int64,
        device=device,
    )
    valid_kv_len = torch.tensor([sequence_size], dtype=torch.int32, device=device)
    kv_caches = [
        torch.zeros(
            (batch_size, wrapper_model.max_seq_len, wrapper_model.hidden_size * 2),
            dtype=task_model.transfomer["h"][0].attn.kv_cache.k_cache.dtype,
            device=device,
        )
        for _ in range(cfg.N_LAYER)
    ]

    dummy_input = (
        pinhole_raw_img,
        hist_img_feat,
        samples["subpath_polylines"].to(device),
        samples["subpath_polylines_mask"].to(device),
        samples["navi_info"].to(device),
        samples["his_traj_next_waypoint"].to(device),
        samples["egos_his_mask"].to(device),
        samples["ego_polygon"].to(device),
        samples["ego_polyline"].to(device),
        samples["ego_polymask"].to(device),
        samples["ego_property"].to(device),
        valid_seq_len,
        latest_traj_id,
        *kv_caches,
        valid_kv_len,
    )

    input_names = [
        "pinhole_raw_img",
        "hist_img_feat",
        "subpath_polylines",
        "subpath_polylines_mask",
        "navi_info",
        "his_traj_next_waypoint",
        "egos_his_mask",
        "ego_polygon",
        "ego_polyline",
        "ego_polymask",
        "ego_property",
        "valid_seq_len",
        "latest_traj_id",
        *[f"input_kv_{idx}" for idx in range(cfg.N_LAYER)],
        "valid_kv_len",
    ]
    return dummy_input, input_names


def prepare_current_images(samples: Dict[str, Any], device: torch.device) -> torch.Tensor:
    """Stack the latest frame across cameras into ``pinhole_raw_img: [N_cams, C, H, W]``."""
    nn3_image = samples.get("nn3_image")
    if not isinstance(nn3_image, dict):
        raise KeyError("nn3_image is required for Plannn3 visual trace.")

    images = []
    for cam in DEFAULT_MULTIVIEW_CAMS:
        key = f"video:{cam}"
        if key not in nn3_image:
            raise KeyError(f"{key} not found in nn3_image.")
        images.append(nn3_image[key].to(device)[0, -1].contiguous())
    return torch.stack(images, dim=0)


def prepare_hist_img_feat(
    cfg: PyConfig,
    wrapper_model: Plannn3TraceWrapper,
    batch_size: int,
    device: torch.device,
) -> torch.Tensor:
    """Create the trace-time history image feature input (half when fp16)."""
    visual_encoder = wrapper_model.task_model.visual_encoder
    _, history_visual_seq_len = compute_visual_sequence_sizes(
        visual_encoder.temporal_multiview_configs,
        visual_encoder.video_shape,
        visual_encoder.patch_size,
    )
    hist_img_feat = torch.zeros(
        (batch_size, history_visual_seq_len, cfg.N_EMBD),
        dtype=torch.float32,
        device=device,
    )
    if wrapper_model.is_fp16_model:
        hist_img_feat = hist_img_feat.half()
    return hist_img_feat


def build_output_names(n_layer: int) -> List[Tuple[str, str]]:
    """Build trace output names with deployment head tags."""
    return (
        [("prefill_hist_img_feat", "llm_prefill"), ("prefill_logits", "llm_prefill")]
        + [(f"prefill_output_kv_{idx}", "llm_prefill") for idx in range(n_layer)]
        + [("decode_logits", "llm_decoder")]
        + [(f"decode_output_kv_{idx}", "llm_decoder") for idx in range(n_layer)]
    )


def export_model_trace(export_dir: str, model: nn.Module, dummy_input: Tuple[torch.Tensor, ...]):
    """Trace and save the torchscript model."""
    with torch.no_grad():
        traced_model = torch.jit.trace(model, dummy_input, check_trace=False).eval()
        torch.jit.save(traced_model, osp.join(export_dir, "traced_onemodel.pt"))
    return traced_model


def compare_outputs(
    trace_outputs: Sequence[torch.Tensor],
    golden_outputs: Sequence[torch.Tensor],
    rtol: float = 1e-3,
    atol: float = 1e-3,
    eps: float = 1e-3,
) -> None:
    """Compare traced outputs to eager outputs."""
    if len(trace_outputs) != len(golden_outputs):
        raise ValueError(f"Output length mismatch: trace={len(trace_outputs)} golden={len(golden_outputs)}")

    table = PrettyTable()
    table.field_names = [
        "Output",
        "Shape",
        "Dtype",
        "MaxAbsDiff",
        "MaxRelDiff",
        "CosSim",
        f">{eps}(%)",
        "Pass",
    ]
    has_error = False
    for idx, (trace_out, golden_out) in enumerate(zip(trace_outputs, golden_outputs)):
        trace_np = sanitize_np(to_numpy(trace_out))
        golden_np = sanitize_np(to_numpy(golden_out))
        max_abs, max_rel, cos_sim, percent_exceed = compute_metrics(golden_np, trace_np, eps=eps)
        try:
            torch.testing.assert_close(trace_out, golden_out, rtol=rtol, atol=atol)
            passed = "Yes"
        except AssertionError:
            passed = "No"
            has_error = True
        table.add_row(
            [
                f"output[{idx}]",
                tuple(trace_out.shape),
                str(trace_out.dtype),
                f"{max_abs:.6f}",
                f"{max_rel:.6f}",
                f"{cos_sim:.6f}",
                f"{percent_exceed:.4f}",
                passed,
            ]
        )

    logger.info("\n%s", table.get_string())
    if has_error:
        raise ValueError("Gap found between eager and traced outputs.")


def compute_metrics(golden_np: np.ndarray, output_np: np.ndarray, eps: float = 1e-3):
    """Compute stable comparison metrics."""
    golden = np.nan_to_num(golden_np.astype(np.float32), nan=0.0, posinf=0.0, neginf=0.0)
    output = np.nan_to_num(output_np.astype(np.float32), nan=0.0, posinf=0.0, neginf=0.0)
    abs_diff = np.abs(output - golden)
    max_abs = float(np.max(abs_diff))
    max_rel = float(np.max(abs_diff / np.maximum(np.abs(golden), eps)))
    golden_flat = golden.reshape(-1)
    output_flat = output.reshape(-1)
    golden_norm = np.linalg.norm(golden_flat)
    output_norm = np.linalg.norm(output_flat)
    cos_sim = (
        0.0
        if golden_norm < eps or output_norm < eps
        else float(np.dot(golden_flat, output_flat) / (golden_norm * output_norm))
    )
    percent_exceed = 100.0 * int(np.sum(abs_diff > eps)) / abs_diff.size
    return max_abs, max_rel, cos_sim, percent_exceed


def sanitize_np(value: np.ndarray) -> np.ndarray:
    """Replace nan and inf before metrics."""
    return np.nan_to_num(value, nan=0.0, posinf=0.0, neginf=0.0)


def to_numpy(value: torch.Tensor) -> np.ndarray:
    """Convert a tensor to numpy, handling bf16."""
    tensor = value.detach()
    if tensor.dtype == torch.bfloat16:
        tensor = tensor.float()
    return tensor.cpu().numpy()


def dump_trace_artifacts(
    save_path: str,
    traced_model,
    inputs: Tuple[torch.Tensor, ...],
    input_names: Sequence[str],
    outputs: Sequence[torch.Tensor],
    output_names: Sequence[Tuple[str, str]],
    ckpt_path: str,
) -> None:
    """Dump model IO metadata, input tensors, golden outputs, and version info."""
    with open(osp.join(save_path, "model_input_data.pkl"), "wb") as fw:
        pickle.dump([to_numpy(tensor) for tensor in inputs], fw)

    golden_data = {
        "model_input": {name: to_numpy(tensor) for name, tensor in zip(input_names, inputs)},
        "model_output": {name: to_numpy(tensor) for (name, _), tensor in zip(output_names, outputs)},
    }
    with open(osp.join(save_path, "golden_io_data.pkl"), "wb") as fw:
        pickle.dump(golden_data, fw)

    with open(osp.join(save_path, "traced_onemodel_code.txt"), "w", encoding="utf-8") as fw:
        fw.write(traced_model.forward.code)
    with open(osp.join(save_path, "traced_onemodel_graph.txt"), "w", encoding="utf-8") as fw:
        fw.write(traced_model.graph.str())

    dump_model_io_info(save_path, inputs, input_names, outputs, output_names)
    dump_version_info(save_path, ckpt_path)


def dump_model_io_info(
    save_path: str,
    inputs: Sequence[torch.Tensor],
    input_names: Sequence[str],
    outputs: Sequence[torch.Tensor],
    output_names: Sequence[Tuple[str, str]],
) -> None:
    """Dump input and output metadata tables."""
    if len(inputs) != len(input_names):
        raise ValueError(f"Input length mismatch: inputs={len(inputs)} input_names={len(input_names)}")
    if len(outputs) != len(output_names):
        raise ValueError(f"Output length mismatch: outputs={len(outputs)} output_names={len(output_names)}")

    input_table = PrettyTable()
    input_table.field_names = ["Input Index", "Shape", "Dtype"]
    for idx, tensor in enumerate(inputs):
        input_table.add_row([idx, list(tensor.shape), tensor.dtype])

    output_table = PrettyTable()
    output_table.field_names = ["Output Index", "Name", "Shape", "Dtype", "Head"]
    for idx, (tensor, (name, head)) in enumerate(zip(outputs, output_names)):
        output_table.add_row([idx, name, tuple(tensor.shape), tensor.dtype, head])

    head_names = list(dict.fromkeys(head for _, head in output_names))
    head_table = PrettyTable()
    head_table.field_names = ["Entry Index", "DynamicHead Entry Name", "Contains Heads"]
    for idx, head_name in enumerate(head_names):
        head_table.add_row([idx, head_name, [head_name]])

    with open(osp.join(save_path, "model_io_info.txt"), "w", encoding="utf-8") as fw:
        fw.write(input_table.get_string())
        fw.write("\n")
        fw.write(output_table.get_string())
        fw.write("\n")
        fw.write(head_table.get_string())


def dump_version_info(save_path: str, ckpt_path: str) -> None:
    """Record source version and checkpoint path."""
    version_dir = osp.join(save_path, "version_info")
    os.makedirs(version_dir, exist_ok=True)
    try:
        trace_commit = git.Repo(search_parent_directories=True).head.object.hexsha
    except Exception:  # pylint: disable=broad-except
        trace_commit = "unknown"
    with open(osp.join(version_dir, "info.txt"), "w", encoding="utf-8") as fw:
        fw.write(f"commit: {trace_commit}\n")
        fw.write(f"ckpt path: {ckpt_path}\n")


def torch_fix_precision() -> None:
    """Set torch precision flags for deterministic trace export."""
    torch.backends.cudnn.enabled = False
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    torch.manual_seed(0)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(0)
        torch.cuda.manual_seed_all(0)
    torch.use_deterministic_algorithms(False)


def ensure_distributed_initialized() -> None:
    """Initialize torch distributed for standalone script execution."""
    if torch.distributed.is_available() and not torch.distributed.is_initialized():
        torch.distributed.init_process_group(
            backend="nccl",
            init_method="tcp://localhost:9995",
            world_size=1,
            rank=0,
        )


if __name__ == "__main__":
    load_plus()
    ensure_distributed_initialized()

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--cfg_path",
        type=str,
        default="experiments/task_planner/exp_plannn3/cfg_plannn3_trace.py",
        help="planner cfg",
    )
    parser.add_argument(
        "--ckpt_path",
        type=str,
        default="/share-global/AIP/nioml/ad-cn-hlidc-aip-experiment/Perception-Visual-Dynamic/prod/experiment/802846/task_planner/exp_plannn3/ep_802846_0611_nn3_train_baseline_with_nn2_meta_action_wo_env/ckpt/checkpoint_epoch002_step2001.pth.tar",
        help="input ckpt path",
    )
    parser.add_argument(
        "--save_path",
        type=str,
        default="/share-global/ken.yang2/ckpts/nn3_trace_ret/0611/plannn3_trace/",
        help="output traced model path",
    )
    args = parser.parse_args()

    test_planner_model_trace(
        os.environ.get("CI_CFG_PATH", args.cfg_path),
        os.environ.get("CI_CKPT_PATH", args.ckpt_path),
        os.environ.get("CI_SAVE_PATH", args.save_path),
    )
