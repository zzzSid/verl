# -*- coding: utf-8 -*-
import os
import json
import torch
import numpy as np
# from easydict import EasyDict
from torchpilot.utils.plus_manager import load_plus
from torchpilot.utils.registries import DATALOADER
from torchpilot.utils.cfg_parser import PyConfig
from torchpilot.utils.registries import MODULE
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import compute_car_pose
from tpp_onemodel.evaluator.plannn2_evaluator_utils.planner_env import PlannerEnv
from tpp_onemodel.data.dataset.plannn2_dataset import Plannn2Dataset
from shapely.geometry import LineString
import numpy as np
import torch.distributed as dist
from multiprocessing import Process, Pool, Lock
from tpp_onemodel.data.dataset.plannn2_dataset import _load_data as load_data

import matplotlib.pyplot as plt
import numpy as np
import os


import concurrent.futures
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import threading
import time
from multiprocessing import Manager, Queue as MPQueue
import queue

from tpp_onemodel.data.dataset.plannn2_dataset_utils.meta_action_manager import (
    MetaActionManager,
)


from enum import Enum


import json
from multiprocessing import Pool, cpu_count
from itertools import islice


class LatCategory(Enum):
    RIGHT_UTURN = 0
    RIGHT_TURN = 1
    RIGHT_LC = 2
    KEEP = 3
    LEFT_LC = 4
    LEFT_TURN = 5
    LEFT_UTURN = 6
    CENTERING = 7


class LonCategory(Enum):
    NO_RISK = 0
    COLLISION = 1
    DECAL = 2
    ONCOMING_RISK = 3
    CUTIN_COLLISION = 4
    CROSS_RISK = 5

def find_lat_category(value: int) -> LatCategory:
    """
    根据输入数值(0-6)找出对应的枚举变量

    Args:
        value: 输入的数值 (0-6)

    Returns:
        对应的枚举成员

    Raises:
        ValueError: 如果数值不在有效范围内
    """
    if not 0 <= value <= 6:
        raise ValueError(f"无效的数值 {value}，请输入 0-6 之间的整数")
    return LatCategory(value)


def find_lon_category(value: int) -> LonCategory:
    """
    根据输入数值(0-6)找出对应的枚举变量

    Args:
        value: 输入的数值 (0-6)

    Returns:
        对应的枚举成员

    Raises:
        ValueError: 如果数值不在有效范围内
    """
    if not 0 <= value <= 2:
        raise ValueError(f"无效的数值 {value}，请输入 0-2 之间的整数")
    return LonCategory(value)


def extract_timestamp_from_path(path: str) -> str:
    """
    从路径中提取时间戳部分

    Args:
        path: 完整的文件路径

    Returns:
        时间戳字符串
    """
    # 获取文件名（最后一个 / 之后的部分）
    filename = path.split('/')[-1].replace('.pkl', '')
    return filename

class ThreadPoolProcessor:
    def __init__(self, max_workers=4, output_file="result.txt", vis_path = "./vis/", use_multiprocessing=True):
        """
        使用线程池/进程池的处理器

        Args:
            max_workers: 最大工作线程数/进程数
            output_file: 输出文件名
            vis_path: 可视化路径
            use_multiprocessing: 是否使用多进程（默认True，推荐用于CPU密集型任务）
        """
        self.max_workers = max_workers
        self.output_file = output_file
        self.vis_path = vis_path
        self.use_multiprocessing = use_multiprocessing
        os.makedirs(self.vis_path, exist_ok=True)
        self.lock = threading.Lock()
        self.condition_count = 0
        # 多进程相关初始化
        if use_multiprocessing:
            self.manager = Manager()
            self.write_queue = self.manager.Queue()
        else:
            self.manager = None
            self.write_queue = None

    def process_item(self, item):
        """
        处理单个元素（自定义处理逻辑）

        Args:
            item: 如果是JSON字符串则解析为dict，如果是纯路径字符串则直接使用，
                  如果是字典则直接使用
        """
        # 解析输入数据（支持JSON字符串、纯路径字符串或字典）
        item_data = None
        if isinstance(item, str):
            item = item.strip()
            try:
                # 尝试解析为JSON
                item_data = json.loads(item)
            except json.JSONDecodeError:
                # 如果不是JSON，则视为纯路径字符串
                # SFT格式: "path/to/file.pkl size lineno"
                # 保留完整字符串（包含空格和数字），供load_data判断使用
                item_data = {'path': item}
        elif isinstance(item, dict):
            item_data = item
        else:
            print(f"不支持的数据类型: {type(item)}")
            return False, None

        # 获取文件路径（保留完整字符串，包括空格和后面的数字）
        # _load_data_impl 会根据空格判断使用 COS 读取还是本地文件读取
        fname = item_data.get('path', '')
        if not fname:
            print(f"无法获取文件路径: {item_data}")
            return False, None
        uuid = fname.split('/')[-1].split('.')[0]
        # print(f"fname = {fname}")
        # fname = 'huailai_cos:ad-cn-hlidc-adsim-mojito/train_data_fuzzing/blocker_2_1216/ed3a32fd-147f-4d51-9d49-c0509a03c7be.pkl 20143762'
        data = load_data(fname)
        timestamps = sorted(data["timestamp_list"])


        # pre-process collision risk detection
        action_manager = MetaActionManager(data, clip_id=f"{uuid}", enable_viz=False)
        clip_lable_status = action_manager.process(dataset_kwargs={})

        clip_id = extract_timestamp_from_path(fname)

        # res = {
        #     "path": fname,
        #     "clip_id": clip_id,
        #     "version": "v1.2.3",
        #     "frame_num": len(timestamps),
        #     "clip_start_time": timestamps[0],
        #     "clip_end_time": timestamps[-1],
        #     "tags": []
        # }

        lat_dict = {}
        lon_dict = {}

        # 用于跟踪当前 lateral 段落（只记录非3的）
        current_lat = None
        lat_start_time = None
        lat_segments = []

        # 用于跟踪当前 longitudinal 段落（非0）
        current_lon = None
        lon_start_time = None
        lon_segments = []

        prev_ts = None

        for ts, clip_label in zip(timestamps, clip_lable_status):
            lateral = MetaActionManager.LATITUDE_LABELS_MAP[clip_label["lateral"]]
            longitudinal = MetaActionManager.LONGITUDE_LABELS_MAP[clip_label["longitudinal"]]
            # print(f"lateral = {lateral}")

            # 处理 lateral 段落（只记录非3的）
            if lateral != current_lat:
                # 如果之前有非3的 lateral，保存它
                if current_lat is not None and current_lat != 3 and prev_ts is not None:
                    lat_segments.append({
                        "tag_type": "checker",
                        "tag_name": find_lat_category(current_lat).name,
                        "start_time": lat_start_time,
                        "end_time": prev_ts,
                    })
                # 开始新的段落（只当新的值非3时）
                if lateral != 3:
                    current_lat = lateral
                    lat_start_time = ts
                else:
                    current_lat = None
                    lat_start_time = None

            # 处理 longitudinal 段落（只记录非0的）
            if longitudinal != current_lon:
                # 如果之前有非0的 longitudinal，保存它
                if current_lon is not None and current_lon != 0 and prev_ts is not None:
                    lon_segments.append({
                        "tag_type": "checker",
                        "tag_name": find_lon_category(current_lon).name,
                        "start_time": lon_start_time,
                        "end_time": prev_ts
                    })
                # 开始新的段落（只当新的值非0时）
                if longitudinal != 0:
                    current_lon = longitudinal
                    lon_start_time = ts
                else:
                    current_lon = None
                    lon_start_time = None

            prev_ts = ts

        # 处理最后一个 lateral 段落（如果非3）
        if current_lat is not None and current_lat != 3:
            lat_segments.append({
                "tag_type": "checker",
                "tag_name": find_lat_category(current_lat).name,
                "start_time": lat_start_time,
                "end_time": timestamps[-1]
            })

        # 处理最后一个 longitudinal 段落（如果非0）
        if current_lon is not None and current_lon != 0:
            lon_segments.append({
                "tag_type": "checker",
                "tag_name": find_lon_category(current_lon).name,
                "start_time": lon_start_time,
                "end_time": timestamps[-1]
            })

        # 将 lateral 和 longitudinal 段合并到 item_data['tags']
        if 'tags' not in item_data:
            item_data['tags'] = []
        item_data['tags'] = item_data['tags'] + lat_segments + lon_segments

        return True, item_data

    def write_to_file(self, result_str):
        """线程安全的文件写入"""
        with self.lock:
            with open(self.output_file, 'a', encoding='utf-8') as f:
                f.write(json.dumps(result_str, ensure_ascii=False) + '\n')
            self.condition_count += 1

    def process_with_future(self, item_with_index):
        """供线程池调用的处理函数"""
        index, item = item_with_index
        meets_condition, result_str = self.process_item(item)

        if meets_condition:
            self.write_to_file(result_str)
            return f"元素 {item} (索引:{index}) 满足条件"
        else:
            return f"元素 {item} (索引:{index}) 不满足条件"

    def process_list_generator_fast(self, data_generator):
        """
        超高速多进程版本 - 专为128+ CPU优化
        使用进程池 + 批量处理 + 独立写入进程
        """
        import multiprocessing as mp

        workers = min(self.max_workers, mp.cpu_count())
        print(f"[高性能模式] 启动 {workers} 个进程处理数据...")
        print(f"CPU核心数: {mp.cpu_count()}")

        # 使用进程池
        with ProcessPoolExecutor(max_workers=workers) as executor:
            # 批量提交任务，减少开销
            batch_size = workers * 4  # 每个进程4个任务
            futures = []
            total_processed = 0

            # 先预提交一批任务
            batch = []
            for idx, item in enumerate(data_generator):
                batch.append((idx, item))

                if len(batch) >= batch_size:
                    # 提交批量任务
                    for index, data_item in batch:
                        future = executor.submit(_worker_process_item, data_item)
                        futures.append((index, future))
                    batch = []

                    # 处理完成的任务
                    done_futures = []
                    for index, future in list(futures):
                        if future.done():
                            try:
                                meets_condition, result = future.result()
                                if meets_condition and result:
                                    self.write_to_file(result)
                                    # condition_count 已在 write_to_file 中递增，无需重复
                                total_processed += 1
                                done_futures.append((index, future))
                            except Exception as e:
                                print(f"处理错误: {e}")
                                done_futures.append((index, future))

                    # 移除已完成的
                    for done in done_futures:
                        futures.remove(done)

                    if total_processed % 1000 == 0:
                        print(f"进度: 已处理 {total_processed} 条，队列中: {len(futures)}")

            # 提交剩余任务
            if batch:
                for index, data_item in batch:
                    future = executor.submit(_worker_process_item, data_item)
                    futures.append((index, future))

            # 等待所有任务完成
            print(f"等待 {len(futures)} 个剩余任务完成...")
            for index, future in futures:
                try:
                    meets_condition, result = future.result(timeout=300)
                    if meets_condition and result:
                        self.write_to_file(result)
                        # condition_count 已在 write_to_file 中递增，无需重复
                    total_processed += 1
                except Exception as e:
                    print(f"最终处理错误: {e}")

        print(f"\n处理完成！总共处理 {total_processed} 条，满足条件: {self.condition_count}")
        return self.condition_count

    def process_list_generator(self, data_generator):
        """
        使用生成器处理大数据，避免内存溢出
        根据配置自动选择线程池或进程池
        """
        if self.use_multiprocessing:
            return self.process_list_generator_fast(data_generator)

        # 线程池版本（IO密集型任务）
        print(f"开始处理数据流，使用 {self.max_workers} 个线程...")

        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = set()
            index = 0

            for item in data_generator:
                while len(futures) >= self.max_workers * 2:
                    done, futures = concurrent.futures.wait(
                        futures,
                        return_when=concurrent.futures.FIRST_COMPLETED
                    )
                    for future in done:
                        try:
                            result = future.result()
                            if index % 100 == 0:
                                print(f"进度: 已处理 {index} 条")
                        except Exception as e:
                            print(f"处理出错: {e}")

                future = executor.submit(self.process_with_future, (index, item))
                futures.add(future)
                index += 1

            print(f"等待剩余 {len(futures)} 个任务完成...")
            for future in concurrent.futures.as_completed(futures):
                try:
                    result = future.result()
                except Exception as e:
                    print(f"处理出错: {e}")

        print(f"\n处理完成！总共处理 {index} 条，满足条件: {self.condition_count}")
        return self.condition_count

    def process_list(self, data_list):
        """主处理函数（兼容列表输入）"""
        print(f"开始处理 {len(data_list)} 个元素，使用 {self.max_workers} 个{'进程' if self.use_multiprocessing else '线程'}...")

        items_with_index = list(enumerate(data_list))

        # 根据配置选择线程池或进程池
        ExecutorClass = ProcessPoolExecutor if self.use_multiprocessing else ThreadPoolExecutor

        with ExecutorClass(max_workers=self.max_workers) as executor:
            futures = [
                executor.submit(self.process_with_future, item)
                for item in items_with_index
            ]

            completed = 0
            for future in concurrent.futures.as_completed(futures):
                result = future.result()
                completed += 1
                if completed % 100 == 0:
                    print(f"进度: {completed}/{len(data_list)}")

        print(f"\n处理完成！满足条件的元素数量: {self.condition_count}")
        return self.condition_count


def _worker_process_item(item):
    """
    独立进程工作函数 - 必须在模块级别定义才能被pickle
    支持 JSON 字符串、纯路径字符串或字典
    """
    try:
        # 解析输入数据（支持JSON字符串、纯路径字符串或字典）
        item_data = None
        if isinstance(item, str):
            item = item.strip()
            try:
                # 尝试解析为JSON
                item_data = json.loads(item)
            except json.JSONDecodeError:
                # 如果不是JSON，则视为纯路径字符串
                # SFT格式: "path/to/file.pkl size lineno"
                # 保留完整字符串（包含空格和数字），供load_data判断使用
                item_data = {'path': item}
        elif isinstance(item, dict):
            item_data = item
        else:
            return False, None

        # 获取文件路径（保留完整字符串，包括空格和后面的数字）
        # _load_data_impl 会根据空格判断使用 COS 读取还是本地文件读取
        # fname = item_data.get('path', '').rpartition(' ')[0]
        path = item_data.get('path', '')
        space_count = path.count(' ')
        if space_count >= 2:
            fname = path.rpartition(' ')[0]
        else:
            fname = path
        # print(f"fname = {fname}")
        if not fname:
            return False, None

        uuid = fname.split('/')[-1].split('.')[0]

        # 加载数据
        try:
            data = load_data(fname)
        except Exception as e:
            print(f"[ERROR] Failed to load data from {repr(fname)}: {e}")
            return False, None
        timestamps = sorted(data["timestamp_list"])

        # 处理
        action_manager = MetaActionManager(data, clip_id=f"{uuid}", enable_viz=False)
        clip_lable_status = action_manager.process(dataset_kwargs={})

        # 收集 lateral 和 longitudinal 段落
        lat_segments = []
        lon_segments = []
        current_lat = None
        current_lon = None
        lat_start_time = None
        lon_start_time = None
        prev_ts = None

        for ts, clip_label in zip(timestamps, clip_lable_status):
            lateral = MetaActionManager.LATITUDE_LABELS_MAP[clip_label["lateral"]]
            longitudinal = MetaActionManager.LONGITUDE_LABELS_MAP[clip_label["longitudinal"]]

            # Lateral (非3)
            if lateral != current_lat:
                if current_lat is not None and current_lat != 3 and prev_ts is not None:
                    lat_segments.append({
                        "tag_type": "checker",
                        "tag_name": LatCategory(current_lat).name,
                        "start_time": lat_start_time,
                        "end_time": prev_ts,
                    })
                if lateral != 3:
                    current_lat = lateral
                    lat_start_time = ts
                else:
                    current_lat = None
                    lat_start_time = None

            # Longitudinal (非0)
            if longitudinal != current_lon:
                if current_lon is not None and current_lon != 0 and prev_ts is not None:
                    lon_segments.append({
                        "tag_type": "checker",
                        "tag_name": LonCategory(current_lon).name,
                        "start_time": lon_start_time,
                        "end_time": prev_ts,
                    })
                if longitudinal != 0:
                    current_lon = longitudinal
                    lon_start_time = ts
                else:
                    current_lon = None
                    lon_start_time = None

            prev_ts = ts

        # 最后一个段落
        if current_lat is not None and current_lat != 3:
            lat_segments.append({
                "tag_type": "checker",
                "tag_name": LatCategory(current_lat).name,
                "start_time": lat_start_time,
                "end_time": timestamps[-1],
            })

        if current_lon is not None and current_lon != 0:
            lon_segments.append({
                "tag_type": "checker",
                "tag_name": LonCategory(current_lon).name,
                "start_time": lon_start_time,
                "end_time": timestamps[-1],
            })

        # # 合并结果
        # if 'tags' not in item_data:
        item_data['tags'] = []
        item_data['tags'] = item_data['tags'] + lat_segments + lon_segments
        item_data['version'] = "0.0.3"

        return True, item_data

    except Exception as e:
        print(f"工作进程错误: {e}")
        return False, None


def init_distributed():
    dist.init_process_group(backend="nccl")
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    local_rank = int(os.environ["LOCAL_RANK"])
    torch.cuda.set_device(local_rank)
    return rank, world_size, local_rank

def parse_multi_spd_limit(data, timestamps):
    spd_limits = []
    for ts in timestamps:
        spd_limit = data[ts]["speed_limit"]
        spd_limits.append(spd_limit)
    return np.array(spd_limits)

def read_large_file_generator(file_path, chunk_size=8192):
    """
    使用生成器高效读取大文件，避免一次性加载到内存

    Args:
        file_path: 文件路径
        chunk_size: 读取缓冲区大小

    Yields:
        每一行的内容（去除换行符）
    """
    with open(file_path, 'r', encoding='utf-8') as f:
        buffer = ''
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                # 处理最后剩余的内容
                if buffer:
                    yield buffer
                break
            buffer += chunk
            lines = buffer.split('\n')
            # 保留最后不完整的行到下一次读取
            buffer = lines.pop()
            for line in lines:
                if line:  # 跳过空行
                    yield line


def get_file_list_fast(dataloader_file):
    """
    快速读取多个大文件，使用生成器避免内存溢出。
    支持两种数据格式：
    - pretrain: 文件路径列表，文件内容每行是 JSON
    - sft: 嵌套字典，文件内容每行是 str (路径)

    Args:
        dataloader_file: dict，包含 "pretrain" 和/或 "sft" 键

    Yields:
        每一行的内容（pretrain 为 JSON 字符串，sft 为路径字符串）
    """
    # 处理 pretrain 数据
    if "pretrain" in dataloader_file:
        pretrain_files = dataloader_file["pretrain"]
        if isinstance(pretrain_files, list):
            for file_path in pretrain_files:
                print(f"[Pretrain] 正在读取文件: {file_path}")
                line_count = 0
                for line in read_large_file_generator(file_path):
                    yield line
                    line_count += 1
                    if line_count % 100000 == 0:
                        print(f"  [Pretrain] 已读取 {line_count} 行...")
                print(f"  [Pretrain] 文件读取完成，共 {line_count} 行")

    # 处理 sft 数据
    if "sft" in dataloader_file:
        sft_data = dataloader_file["sft"]
        print("[SFT] 开始处理 sft 数据...")

        def process_sft_value(value, parent_key=""):
            """递归处理 sft 数据的值"""
            if isinstance(value, list):
                # 文件路径列表
                for file_path in value:
                    if isinstance(file_path, str):
                        print(f"[SFT{parent_key}] 正在读取文件: {file_path}")
                        line_count = 0
                        for line in read_large_file_generator(file_path):
                            yield line
                            line_count += 1
                            if line_count % 1000 == 0:
                                print(f"  [SFT{parent_key}] 已读取 {line_count} 行...")
                        print(f"  [SFT{parent_key}] 文件读取完成，共 {line_count} 行")
            elif isinstance(value, dict):
                # 嵌套字典，递归处理
                for key, sub_value in value.items():
                    yield from process_sft_value(sub_value, f"{parent_key}/{key}")

        # 遍历 sft 的各个类别
        if isinstance(sft_data, dict):
            for category, category_data in sft_data.items():
                yield from process_sft_value(category_data, f"/{category}")
        elif isinstance(sft_data, list):
            # sft 直接是列表的情况
            yield from process_sft_value(sft_data, "")


dataloader_file = {
    # "pretrain":["/home/gengda.chen/workspace/melange/missing_0417_pretrain_5.txt"],  # json格式读取


    # "pretrain":["/share-global/charles.qian/data/public/260404_mukuv2/0402_fft_expert_coapp_tag_6925224_training.txt"],  # json格式读取
    "sft": {        # str格式读取，第0元素是pkl addr
        # "test":["/home/gengda.chen/workspace/melange/missing_0417_sft.txt"]
    #             # 打灯
                # "turn_signal": [
                #     "/share-global/weidong.shi1/data/planner/sft_data_100k.txt",
                # ],
                # # 类人性
                # "humanoid": {
                #     "humanoid": [
                #         # 2025年11月底12月初-第1批专家数据-1k
                #         "/share-global/menghan.pan/st/export_route_1126_1201_1327_mapv5_1_965.txt",
                #         # 2025年小路1k
                #         "/share-global/enzo.shu/ppl/humanoid_good_case_1038.txt",
                #         # 20260113-20260126数采-8.4k 去闸机/自车静止
                #         "/share-global/sijia.gu/planner/expert_data/0113_0131_all_expert_data_without_static_8411_pkls.txt",
                #         # 盘桥居中
                #         "/share-global/qixuan.sun/planner/centralization350/0128_sql_ramp_dig_result_center_pkls.txt",
                #         # turn
                #         "/share-global/sijia.gu/planner/expert_data/0202_0210_add_humanoid_turn_expert_data_3383_pkls.txt",
                #         "/share-global/sijia.gu/planner/expert_data/0211_0213_add_humanoid_turn_expert_data_711_pkls.txt",
                #         "/share-global/sijia.gu/planner/expert_data/0214_0224_add_humanoid_turn_expert_data_505_pkls.txt",
                #         "/share-global/sijia.gu/planner/expert_data/0225_0302_add_humanoid_turn_expert_data_1237_pkls.txt",
                #         # straight
                #         "/share-global/sijia.gu/planner/expert_data/0123_0201_add_humanoid_straight_expert_data_1373_clips.txt",
                #         "/share-global/sijia.gu/planner/expert_data/0202_0210_add_humanoid_straight_expert_data_1451_pkls.txt",
                #         "/share-global/sijia.gu/planner/expert_data/0211_0213_add_humanoid_straight_data_145_pkls.txt",
                #         "/share-global/sijia.gu/planner/expert_data/0214_0224_add_humanoid_straight_expert_data_78_pkls.txt",
                #         "/share-global/sijia.gu/planner/expert_data/0225_0302_add_humanoid_straight_expert_data_534_pkls.txt",
                #         # park
                #         "/share-global/sijia.gu/planner/expert_data/0123_0201_add_humanoid_park_expert_data_8_clips.txt",
                #         "/share-global/sijia.gu/planner/expert_data/0202_0210_add_humanoid_park_expert_data_530_pkls.txt",
                #         "/share-global/sijia.gu/planner/expert_data/0211_0213_add_humanoid_park_data_170_pkls.txt",
                #         "/share-global/sijia.gu/planner/expert_data/0214_0224_add_humanoid_park_expert_data_95_pkls.txt",
                #         "/share-global/sijia.gu/planner/expert_data/0225_0302_add_humanoid_park_expert_data_296_pkls.txt",
                #         # 导航换道
                #         "/share-global/sijia.gu/planner/expert_data/0113_0131_add_humanoid_navi_expert_data_1481_pkls.txt",
                #         # 20260113-20260126数采 自车绕行x5
                #         "/share-global/sijia.gu/planner/expert_data/0113_0126_followstart_x5_expert_data_2465_clips.txt",
                #     ],
                # },
                # # 横向
                # "lateral": {
                #     "normal": [
                #         "/share-global/menghan.pan/rt/CurrentLane_RedWarnSign_Pkl_v6_gt_dataset_1768534370_1_2661_a996c.txt",
                #         "/share-global/menghan.pan/rt/sod_collision_pkl_1209_2_gt_dataset_1765269030_1_3071_f1df6.txt",
                #         "/share-global/menghan.pan/rt/sod-0120_gt_dataset_1768877740_1_2454_b172f.txt",
                #         "/share-global/qi.wang15/dataset/static_scene_god.txt",
                #         ],
                #     "center": [
                #         "/share-global/qixuan.sun/planner/sft_data/original_pkls/0309_ramp_right_turn_lane_with_frame_tag_repeat_minibatch_12401_pkls.txt",
                #     ],
                #     "effective_change_lane": [
                #         "/share-global/chuan.ye/effective_change_lane_keys.txt", # 10883
                #     ],
                # },
                # # 纵向
                # "longitudinal": {
                #     "collision": [
                #         "/share-global/xu.shu/urban/follow_stop_key_10000_sync.txt",
                #         "/share-global/xu.shu/urban/cross_9223.txt",
                #         "/share-global/shane.wan/data_mining/vru_cross_32767.txt",
                #         "/share-global/zhonghao.deng/dataset/data_mining/encounter/narrRoad_encounter_key_9689_no_seg.txt",
                #         "/share-global/zhonghao.deng/dataset/data_mining/follow_stop/0315/follow_stop_key_0314_1652_no_seg.txt",
                #     ],
                #     "tl_start": [
                #         "/share-global/xin.fu2/planning_data/causal_data/start_data/0119_good_action/tld_start_data_ori.txt"
                #     ],
                #     "follow_start": ["/share-global/xu.shu/urban/follow_good_case.txt"],
                #     "boyi_start": ["/share-global/xu.shu/urban/boyi_start_0130_sel_4833_from_10w.txt"],
                #     "speed": [
                #         "/share-global/arise.wu/plannn2/data/gt_speedup_to_limit_11854_train.txt",
                #     ],
                # },
                # # 园区
                # "campus": [
                #     "/share-global/bowen.teng/dataset/0313_inner_road_diviation_sft_data_10000.txt",
                # ],
                # # 偏航
                # "deviation": [
                #     "/share-global/tenglong.xi/data/0315_combined_deviation_sft_data_98237.txt",
                # ],
                # # 高速
                # "highway": {
                #     "normal": [
                #         "/share-global/menghan.pan/rt/CurrentLane_RedWarnSign_Pkl_v6_gt_dataset_1768534370_1_2661_a996c.txt",
                #         "/share-global/menghan.pan/rt/sod_collision_pkl_1209_2_gt_dataset_1765269030_1_3071_f1df6.txt",
                #         "/share-global/menghan.pan/rt/sod-0120_gt_dataset_1768877740_1_2454_b172f.txt",
                #         "/share-global/qi.wang15/dataset/static_scene_god.txt",
                #         "/share-global/timo.li/pkl/cutin_pretrain_good_4868_rep_4_260309.txt",
                #         "/share-global/barry.xiao/etc_plannn2/data/sft/release/etc_select_sft_0314_7000.txt",
                #         "/share-global/runlin.he/plannn2/data/hw_cruise_pipeline_779_production_2891.txt",
                #         "/share-global/runlin.he/plannn2/data/ramp_cruise_pipeline_782_production_992.txt",
                #     ],
                #     "hw_general_cutin": [
                #         "/share-global/timo.li/pkl/cutin_pretrain_good_4868_260309.txt",
                #     ],
                # },

                "test": [
                    "/home/gengda.chen/workspace/melange/missing_012.txt",
                    # "/share-global/gengda.chen/data/planner/planner_basedata_20260321_i_4259074_sample_500000.txt"
                ],
            }
    }


# 使用示例
if __name__ == "__main__":
    # 大文件建议使用生成器方式处理，避免内存溢出
    # 高性能模式：使用多进程，充分利用128个CPU核心
    print("=" * 60)
    print("高性能多进程处理模式")
    print("=" * 60)

    import multiprocessing as mp
    cpu_count = mp.cpu_count()
    print(f"检测到的CPU核心数: {cpu_count}")

    # 配置参数
    # max_workers: 线程数/进程数，建议设置为CPU核心数或略低
    # 128个CPU可以设置为 100-120
    MAX_WORKERS = min(120, cpu_count)  # 使用32个线程

    processor = ThreadPoolProcessor(
        max_workers=MAX_WORKERS,
        output_file="/home/gengda.chen/workspace/melange/0421_pretrain_012_left.txt",
        # output_file="/home/gengda.chen/workspace/melange/0421_pretrain_500000.txt",
        vis_path="./vis/",
        use_multiprocessing=True  # 使用线程池（而非进程池）
    )

    print(f"启动 {MAX_WORKERS} 个进程处理400万行数据...")
    print(f"输出文件: {processor.output_file}")
    print("=" * 60)

    start_time = time.time()

    # 使用生成器直接处理，不加载全部到内存
    result_count = processor.process_list_generator(get_file_list_fast(dataloader_file))

    end_time = time.time()
    elapsed = end_time - start_time

    print("=" * 60)
    print(f"处理完成!")
    print(f"总用时: {elapsed:.2f} 秒")
    print(f"处理速度: {result_count / elapsed:.2f} 条/秒" if elapsed > 0 else "N/A")
    print(f"满足条件的记录数: {result_count}")
    print("=" * 60)
