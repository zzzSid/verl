import json
import time
import psutil
import os
from array import array
from typing import Dict, List, Tuple
from collections import defaultdict

def get_memory_usage() -> float:
    """获取当前进程的内存使用（MB）"""
    process = psutil.Process(os.getpid())
    return process.memory_info().rss / 1024 / 1024

class HighSpeedCompactStorage:
    """高速压缩存储 - 优化访问速度"""

    def __init__(self):
        # 字符串池
        self.string_pool = {}
        self.string_list = []

        # 使用数组存储数据
        self.clip_ids = array('I')
        self.clip_start_idx = array('I')
        self.tag_types = array('I')
        self.tag_names = array('I')
        self.start_times = array('d')
        self.end_times = array('d')

        # 【关键优化1】添加反向索引：clip_id -> 位置（O(1)查找）
        self.clip_id_to_pos = {}  # clip_id字符串 -> 在数组中的位置

        # 【关键优化2】缓存常用的tag_name查询
        self.tag_name_cache = {}  # tag_name -> [(clip_id, start_time, end_time), ...]

        self.stats = {
            'total_clips': 0,
            'total_tags': 0,
            'unique_strings': 0
        }

    def _get_string_id(self, s: str) -> int:
        """获取字符串ID（自动去重）"""
        if s not in self.string_pool:
            self.string_pool[s] = len(self.string_list)
            self.string_list.append(s)
            self.stats['unique_strings'] = len(self.string_list)
        return self.string_pool[s]

    def add_clip(self, clip_id: str, tags: list):
        """添加一个clip的所有tags"""
        # 记录起始位置
        current_pos = len(self.clip_ids)
        self.clip_start_idx.append(len(self.start_times))

        # 存储clip_id
        clip_id_idx = self._get_string_id(clip_id)
        self.clip_ids.append(clip_id_idx)

        # 【关键优化】建立反向索引
        self.clip_id_to_pos[clip_id] = current_pos

        # 存储所有tags
        for tag in tags:
            tag_type = tag.get('tag_type', '')
            tag_name = tag.get('tag_name', '')
            start_time = tag.get('start_time', 0)
            end_time = tag.get('end_time', 0)

            self.tag_types.append(self._get_string_id(tag_type))
            self.tag_names.append(self._get_string_id(tag_name))
            self.start_times.append(float(start_time))
            self.end_times.append(float(end_time))

            self.stats['total_tags'] += 1

        self.stats['total_clips'] += 1

    def get_tags(self, clip_id: str) -> List[Tuple]:
        """【高速】获取tags - O(1)时间复杂度"""
        # 【关键优化】直接通过字典查找位置，O(1)
        pos = self.clip_id_to_pos.get(clip_id)
        if pos is None:
            return []

        start_idx = self.clip_start_idx[pos]
        end_idx = self.clip_start_idx[pos+1] if pos+1 < len(self.clip_start_idx) else len(self.start_times)

        # 批量构建结果（优化循环）
        tags = []
        string_list = self.string_list  # 本地变量加速访问
        tag_types = self.tag_types
        tag_names = self.tag_names
        start_times = self.start_times
        end_times = self.end_times

        for i in range(start_idx, end_idx):
            tags.append((
                string_list[tag_types[i]],
                string_list[tag_names[i]],
                start_times[i],
                end_times[i]
            ))

        return tags


    def search_by_tag_name(self, tag_name: str, use_cache: bool = True) -> List[Tuple[str, float, float]]:
        """【带缓存】搜索包含特定tag_name的所有clip"""

        # 【关键优化】使用缓存
        if use_cache and tag_name in self.tag_name_cache:
            return self.tag_name_cache[tag_name][:]  # 返回副本

        tag_name_idx = self.string_pool.get(tag_name)
        if tag_name_idx is None:
            return []

        results = []
        # 预计算所有clip的边界
        clip_boundaries = []
        for i in range(len(self.clip_ids)):
            start = self.clip_start_idx[i]
            end = self.clip_start_idx[i+1] if i+1 < len(self.clip_start_idx) else len(self.start_times)
            clip_boundaries.append((start, end, self.string_list[self.clip_ids[i]]))

        # 搜索所有tags
        for i in range(len(self.tag_names)):
            if self.tag_names[i] == tag_name_idx:
                # 找到包含这个tag的clip
                for start, end, clip_id in clip_boundaries:
                    if start <= i < end:
                        results.append((clip_id, self.start_times[i], self.end_times[i]))
                        break

        # 缓存结果
        if use_cache:
            self.tag_name_cache[tag_name] = results

        return results

    def precompute_tag_index(self, tag_names: List[str]):
        """【预计算】预先建立常用tag的索引，大幅提升搜索速度"""
        print(f"\n预计算 {len(tag_names)} 个tag的索引...")
        start_time = time.time()

        for tag_name in tag_names:
            self.search_by_tag_name(tag_name, use_cache=True)

        elapsed = time.time() - start_time
        print(f"预计算完成! 耗时: {elapsed:.2f}s, 缓存了{len(self.tag_name_cache)}个tag")

    def get_statistics(self) -> dict:
        """获取存储统计信息"""
        arrays_memory = (
            self.clip_ids.buffer_info()[1] * self.clip_ids.itemsize +
            self.clip_start_idx.buffer_info()[1] * self.clip_start_idx.itemsize +
            self.tag_types.buffer_info()[1] * self.tag_types.itemsize +
            self.tag_names.buffer_info()[1] * self.tag_names.itemsize +
            self.start_times.buffer_info()[1] * self.start_times.itemsize +
            self.end_times.buffer_info()[1] * self.end_times.itemsize
        ) / 1024 / 1024

        # 索引内存
        index_memory = 0
        for key, value in self.clip_id_to_pos.items():
            index_memory += len(key) + 28  # key字符串 + dict entry
        index_memory = index_memory / 1024 / 1024

        string_pool_mb = sum(len(s) for s in self.string_list) / 1024 / 1024

        return {
            'total_clips': self.stats['total_clips'],
            'total_tags': self.stats['total_tags'],
            'unique_strings': self.stats['unique_strings'],
            'avg_tags_per_clip': self.stats['total_tags'] / self.stats['total_clips'] if self.stats['total_clips'] > 0 else 0,
            'arrays_memory_mb': arrays_memory,
            'index_memory_mb': index_memory,
            'string_pool_memory_mb': string_pool_mb,
            'total_memory_mb': arrays_memory + index_memory + string_pool_mb
        }

    def save(self, filepath: str):
        """保存数据"""
        print(f"\n保存数据到: {filepath}")
        start_time = time.time()

        # 注意：tag_name_cache不保存，下次重建
        data = {
            'string_list': self.string_list,
            'clip_ids': self.clip_ids.tolist(),
            'clip_start_idx': self.clip_start_idx.tolist(),
            'tag_types': self.tag_types.tolist(),
            'tag_names': self.tag_names.tolist(),
            'start_times': self.start_times.tolist(),
            'end_times': self.end_times.tolist(),
            'clip_id_to_pos': self.clip_id_to_pos,  # 保存索引
            'stats': self.stats
        }

        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f)

        file_size = os.path.getsize(filepath) / 1024 / 1024
        elapsed = time.time() - start_time
        print(f"保存完成! 文件大小: {file_size:.2f} MB, 耗时: {elapsed:.2f}s")

    def load(self, filepath: str):
        """加载数据"""
        print(f"\n加载数据从: {filepath}")
        start_time = time.time()

        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)

        self.string_list = data['string_list']
        self.clip_ids = array('I', data['clip_ids'])
        self.clip_start_idx = array('I', data['clip_start_idx'])
        self.tag_types = array('I', data['tag_types'])
        self.tag_names = array('I', data['tag_names'])
        self.start_times = array('d', data['start_times'])
        self.end_times = array('d', data['end_times'])
        self.clip_id_to_pos = data['clip_id_to_pos']
        self.stats = data['stats']

        # 重建字符串池
        self.string_pool = {s: i for i, s in enumerate(self.string_list)}

        elapsed = time.time() - start_time
        print(f"加载完成! 耗时: {elapsed:.2f}s")

        stats = self.get_statistics()
        print(f"加载后内存: {get_memory_usage():.2f} MB")

def build_high_speed_storage(filepath: str, save_path: str = None):
    """构建高速压缩存储"""
    storage = HighSpeedCompactStorage()

    start_time = time.time()
    start_memory = get_memory_usage()

    line_count = 0
    error_count = 0

    print(f"{'='*80}")
    print(f"高速压缩模式 - 数组+字符串池+反向索引")
    print(f"目标文件: {filepath}")
    print(f"开始内存: {start_memory:.2f} MB")
    print(f"{'='*80}\n")

    with open(filepath, 'r', encoding='utf-8') as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue

            try:
                data = json.loads(line)
                clip_id = data.get('clip_id')
                tags = data.get('tags', [])

                if clip_id:
                    storage.add_clip(clip_id, tags)
                    line_count += 1

                    if line_count % 100000 == 0:
                        current_memory = get_memory_usage()
                        elapsed = time.time() - start_time
                        stats = storage.get_statistics()

                        print(f"已处理: {line_count:>8,} 行 | "
                              f"内存: {current_memory:>7.2f} MB | "
                              f"增长: {current_memory-start_memory:>7.2f} MB | "
                              f"总tags: {stats['total_tags']:>9,} | "
                              f"速度: {line_count/elapsed:>6.0f}行/s")

            except Exception as e:
                error_count += 1
                if error_count <= 3:
                    print(f"错误 (行 {line_num}): {e}")

    end_time = time.time()
    end_memory = get_memory_usage()
    stats = storage.get_statistics()

    print(f"\n{'='*80}")
    print(f"构建完成!")
    print(f"总行数: {line_count:,}")
    print(f"错误数: {error_count:,}")
    print(f"总clip数: {stats['total_clips']:,}")
    print(f"总tag数: {stats['total_tags']:,}")
    print(f"平均tags/clip: {stats['avg_tags_per_clip']:.2f}")
    print(f"\n内存详细:")
    print(f"  数组内存: {stats['arrays_memory_mb']:.2f} MB")
    print(f"  索引内存: {stats['index_memory_mb']:.2f} MB")
    print(f"  字符串池: {stats['string_pool_memory_mb']:.2f} MB")
    print(f"  总内存: {stats['total_memory_mb']:.2f} MB")
    print(f"  实际进程: {end_memory:.2f} MB")
    print(f"总耗时: {end_time - start_time:.2f} 秒")
    print(f"处理速度: {line_count/(end_time-start_time):.0f} 行/秒")
    print(f"{'='*80}\n")

    # if save_path:
    #     storage.save(save_path)

    return storage

def benchmark_performance(storage: HighSpeedCompactStorage):
    """全面性能测试"""
    print("\n" + "="*80)
    print("性能基准测试")
    print("="*80)

    # 获取所有clip_id
    all_clip_ids = list(storage.clip_id_to_pos.keys())
    test_count = min(100000, len(all_clip_ids))
    print(f"测试样本: {test_count:,} 个clip")

    import random
    random.seed(42)
    test_clip_ids = random.sample(all_clip_ids, test_count)

    # 1. 单次访问测试
    print("\n1. 单次访问性能:")

    # 测试get_tags
    start = time.time()
    for clip_id in test_clip_ids[:10000]:
        tags = storage.get_tags(clip_id)
    time1 = time.time() - start
    print(f"   get_tags (10,000次): {time1:.4f}s, 平均: {time1/10000*1000:.4f}ms")

    # 顺序访问
    start = time.time()
    for i in range(min(100000, len(all_clip_ids))):
        tags = storage.get_tags(all_clip_ids[i])
    sequential_time = time.time() - start
    print(f"   顺序访问100,000次: {sequential_time:.4f}s")

    # 随机访问
    random_clips = random.sample(all_clip_ids, 100000)
    start = time.time()
    for clip_id in random_clips:
        tags = storage.get_tags(clip_id)
    random_time = time.time() - start
    print(f"   随机访问100,000次: {random_time:.4f}s")
    print(f"   顺序/随机比: {random_time/sequential_time:.2f}x")

    # 5. 吞吐量测试
    print("\n5. 吞吐量测试:")

    # 模拟真实业务场景：访问并处理
    start = time.time()
    collision_count = 0
    for clip_id in test_clip_ids[:10000]:
        tags = storage.get_tags(clip_id)
        for tag in tags:
            if tag[1] == 'COLLISION':  # tag_name
                collision_count += 1
    time1 = time.time() - start
    print(f"   处理10,000个clip (查找COLLISION): {time1:.4f}s")
    print(f"   吞吐量: {10000/time1:.0f} clips/s")
    print(f"   找到COLLISION次数: {collision_count}")

    return {
        'single_access_ms': time1/10000*1000,
        'batch_1000_ms': None,  # 占位
        'search_time_s': time1,
        'throughput_clips_s': 10000/time1
    }

def main():
    """主函数"""
    filepath = "/share-global/gengda.chen/data/planner/planner_basedata_200260407_4226498.txt"  # 替换为实际路径

    if not os.path.exists(filepath):
        print(f"错误: 文件不存在 {filepath}")
        return

    compressed_path = filepath.replace('.txt', '_highspeed.json')

    if os.path.exists(compressed_path):
        print(f"发现已压缩数据: {compressed_path}")
        choice = input("是否加载？(y/n): ")
        if choice.lower() == 'y':
            storage = HighSpeedCompactStorage()
            storage.load(compressed_path)
        else:
            storage = build_high_speed_storage(filepath, compressed_path)
    else:
        storage = build_high_speed_storage(filepath, compressed_path)

    if storage.stats['total_clips'] == 0:
        print("没有数据！")
        return

    # 性能测试
    benchmark_performance(storage)

    # 可选：预计算常用tag索引
    print("\n是否预计算常用tag索引？(可提升搜索速度10-100倍)")
    choice = input("输入要预计算的tag名称(用逗号分隔，如: COLLISION,LEFT_TURN) 或按enter跳过: ")
    if choice.strip():
        tag_names = [t.strip() for t in choice.split(',')]
        storage.precompute_tag_index(tag_names)

    # 使用示例
    print("\n" + "="*80)
    print("使用示例:")
    print("="*80)

    # 获取第一个clip
    sample_clip = list(storage.clip_id_to_pos.keys())[0]
    print(f"\n示例clip_id: {sample_clip[:80]}...")

    # 测试不同访问方式
    print("\n方式1 - get_tags (返回完整tuple列表):")
    tags = storage.get_tags(sample_clip)
    print(f"  前3个tag: {tags[:3]}")

    return storage

if __name__ == "__main__":
    storage = main()
