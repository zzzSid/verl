# -*- coding: utf-8 -*-
"""Test for kpts transform function."""
import random

import torch

from tpp_onemodel.data.transform.functional.kpts import clip_kpts
from tpp_onemodel.data.transform.functional.kpts import filter_kpts
from tpp_onemodel.data.transform.functional.kpts import flip_kpts
from tpp_onemodel.data.transform.functional.kpts import offset_kpts
from tpp_onemodel.data.transform.functional.kpts import scale_kpts


def test_clip_kpts() -> None:
    """Test for clip_kpts."""
    height = random.SystemRandom().randint(100, 1000)
    width = random.SystemRandom().randint(100, 1000)
    num_kpts = random.SystemRandom().randint(100, 1000)
    kpts = torch.randint(0, 1000, (num_kpts, 2))

    kpts[..., 0] += width
    kpts[..., 1] += height
    flipped_kpts = clip_kpts(kpts, height, width)

    assert torch.all(flipped_kpts <= kpts)
    assert torch.all(flipped_kpts[..., 0] == width)
    assert torch.all(flipped_kpts[..., 1] == height)


def test_filter_kpts() -> None:
    """Test for filter_kpts."""
    height = random.SystemRandom().randint(100, 1000)
    width = random.SystemRandom().randint(100, 1000)
    num_kpts = random.SystemRandom().randint(100, 1000)
    kpts = torch.randint(0, 1000, (num_kpts, 2))

    filtered_kpts = filter_kpts(kpts, height, width)

    assert filtered_kpts.shape[0] < num_kpts
    assert torch.min(filtered_kpts) >= 0
    assert torch.all(filtered_kpts[:, 0] < width)
    assert torch.all(filtered_kpts[:, 1] < height)


def test_flip_kpts() -> None:
    """Test for flip_kpts."""
    width = random.SystemRandom().randint(100, 1000)
    num_kpts = random.SystemRandom().randint(100, 1000)
    kpts = torch.randint(0, 1000, (num_kpts, 2))
    origin_kpts = kpts.clone()

    flipped_kpts = flip_kpts(kpts, width)

    assert torch.all(flipped_kpts[:, 0] + origin_kpts[:, 0] == width)


def test_offset_kpts() -> None:
    """Test for offset_kpts."""
    offset_height = random.SystemRandom().randint(100, 1000)
    offset_width = random.SystemRandom().randint(100, 1000)
    num_kpts = random.SystemRandom().randint(100, 1000)
    kpts = torch.randint(0, 1000, (num_kpts, 2))
    origin_kpts = kpts.clone()

    kpts_after_offset = offset_kpts(kpts, offset_height, offset_width)

    assert torch.all(origin_kpts - kpts_after_offset == torch.tensor([offset_width, offset_height]))


def test_scale_kpts() -> None:
    """Test for scale_kpts."""
    num_kpts = random.SystemRandom().randint(100, 1000)
    kpts = torch.randint(1, 1000, (num_kpts, 2))
    origin_kpts = kpts.clone()
    scale_height = random.SystemRandom().random()
    scale_width = random.SystemRandom().random()

    scaled_kpts = scale_kpts(kpts, scale_height, scale_width)

    assert torch.all(scaled_kpts < origin_kpts)
