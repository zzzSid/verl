# -*- coding: utf-8 -*-
"""Test for rotation bboxes transform function."""
import numpy as np

from tpp_onemodel.data.transform.functional.rotation_bboxes import points_in_rbbox


def test_points_in_rbbox() -> None:
    """Test for points_in_rbbox."""
    rbbox = np.array(
        [
            [1.0, 2.0, 0.0, 4.0, 4.0, 6.0, np.pi / 6],
            [1.0, 2.0, 0.0, 4.0, 4.0, 6.0, np.pi / 2],
            [1.0, 2.0, 0.0, 4.0, 4.0, 6.0, 7 * np.pi / 6],
            [1.0, 2.0, 0.0, 4.0, 4.0, 6.0, -np.pi / 6],
        ]
    )

    lidar_pts = np.array(
        [
            [1.0, 4.3, 0.1],
            [1.0, 4.4, 0.1],
            [1.1, 4.3, 0.1],
            [0.9, 4.3, 0.1],
            [1.0, -0.3, 0.1],
            [1.0, -0.4, 0.1],
            [2.9, 0.1, 2.0],
            [-0.9, 3.9, 2.0],
        ]
    )

    point_indices = points_in_rbbox(lidar_pts, rbbox, origin=(0.5, 0.5, 0.5))

    expected_point_indices = np.array(
        [
            [1, 0, 1, 1],
            [0, 0, 0, 0],
            [1, 0, 1, 0],
            [0, 0, 0, 1],
            [1, 0, 1, 1],
            [0, 0, 0, 0],
            [0, 1, 0, 0],
            [0, 1, 0, 0],
        ],
        dtype=np.int32,
    )

    assert point_indices.shape == (8, 4)
    assert (point_indices * 1 == expected_point_indices).all()
