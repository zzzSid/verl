# -*- coding: utf-8 -*-
"""Test for StampDataLoader and PlannerMultiDataset."""

import logging
import random
from copy import deepcopy

import numpy as np
import pytest
import torch
from torchpilot.utils.cfg_parser import PyConfig
from torchpilot.utils.plus_manager import load_plus
from torchpilot.utils.registries import DATALOADER
from tqdm import tqdm  # noqa: F401


logger = logging.getLogger(__name__)


@pytest.mark.skip(reason="data deleted")
def test_planner_dataset(planner_config_path, return_obj=False):
    """Test for StampDataLoader and PlannerMultiDataset."""
    cfg = PyConfig.fromfile(planner_config_path)
    dataloader_cfg = deepcopy(cfg.dataloader)

    dataloader_cfg["num_workers"] = 0
    dataloader_cfg["multiprocessing_context"] = None
    dataloader_cfg["prefetch_factor"] = 2
    dataloader_cfg["persistent_workers"] = False
    dataloader_cfg.dataset_cfg.mode = "cicd_train"

    random.seed(0)
    np.random.seed(0)
    torch.manual_seed(0)
    torch.cuda.manual_seed(0)
    dataloader = DATALOADER.build(dataloader_cfg)
    dataloader.reset()

    logger.info("Dataset Len: %d", len(dataloader.dataset))

    if return_obj:
        return dataloader

    batch_list = []
    for _ in range(3):
        batch_data = dataloader.get_batch_data()
        batch_list.append(batch_data)

    del dataloader
    del batch_list


if __name__ == "__main__":
    load_plus()
    torch.distributed.init_process_group(
        backend="nccl",
        init_method="tcp://localhost:9999",
        world_size=1,
        rank=0,
    )
    torch.cuda.empty_cache()

    dataloader = test_planner_dataset("experiments/task_planner/exp_planner_release/cfg_planner.py", return_obj=True)

    # for i_sample, sample in tqdm(enumerate(dataloader.dataset._task_datasets["astra_planner"])):
    #     import pdb

    #     pdb.set_trace()

    # for i_batch, batch_data in tqdm(enumerate(dataloader)):
    #     import pdb

    #     pdb.set_trace()
