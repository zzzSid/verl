# -*- coding: utf-8 -*-
"""Tests for the low-memory NN3 visual decode path."""

from concurrent.futures import ThreadPoolExecutor
from typing import Any
from typing import Dict
from typing import List
from typing import Optional

import torch

from tpp_onemodel.data.dataloader.plannn3_dataloader import _tp_worker_init_override
from tpp_onemodel.data.plannn3.nn3_ceph_io import merge_vt_paths
from tpp_onemodel.data.plannn3.nn3_image_filler import _exception_summary
from tpp_onemodel.data.plannn3.nn3_image_filler import _requires_parser_reset
from tpp_onemodel.data.plannn3.nn3_image_norm import normalize_nn3_image_u8
from tpp_onemodel.data.plannn3.nn3_shared_decoder import Nn3SharedDecoderService
from tpp_onemodel.model.module.nn3_dinov3_encoder import Dinov3Encoder
from tpp_onemodel.model.module.plannn3_visual_tokenizer import Plannn3VisualTokenizer


def _fake_decoder_worker(
    worker_id: int,
    device_id: int,
    job_queue: Any,
    result_queues: List[Any],
    ready_queue: Any,
    alive_counter: Any,
    video_shape: Optional[Dict],
    crop_shape: Optional[Dict],
    multiview_cams: Optional[list],
    inner_resize_crop: bool,
    job_started_time: Any = None,
) -> None:
    """Return a tiny tensor while preserving the production queue contract."""
    del device_id
    del video_shape
    del crop_shape
    del multiview_cams
    del inner_resize_crop
    del job_started_time
    ready_queue.put((worker_id, None))
    try:
        while True:
            item = job_queue.get()
            if isinstance(item, tuple) and item and item[0] == "__nn3_decoder_shutdown__":
                break
            client_id, job_id, visual_meta = item
            result = {
                "video:test": torch.tensor(
                    [visual_meta["value"]],
                    dtype=torch.uint8,
                )
            }
            result_queues[client_id].put((job_id, result))
    finally:
        with alive_counter.get_lock():
            alive_counter.value -= 1


def test_shared_decoder_routes_results_per_client() -> None:
    """Concurrent clients must not consume each other's decoder response."""
    Nn3SharedDecoderService.shutdown()
    owner = Nn3SharedDecoderService.start(
        device_id=0,
        decoder_worker_num=2,
        num_result_queues=2,
        worker_target=_fake_decoder_worker,
    )
    client = Nn3SharedDecoderService(
        job_queue=owner.job_queue,
        result_queues=owner.result_queues,
        alive_counter=owner.alive_counter,
        client_id=1,
    )
    try:
        with ThreadPoolExecutor(max_workers=2) as executor:
            first = executor.submit(owner.decode, {"value": 17})
            second = executor.submit(client.decode, {"value": 29})
            assert first.result()["video:test"].item() == 17
            assert second.result()["video:test"].item() == 29
    finally:
        Nn3SharedDecoderService.shutdown()


def test_uint8_normalization_and_merged_vt_ranges() -> None:
    """Uint8 placeholders and merged reads preserve the expected contracts."""
    normalized = normalize_nn3_image_u8(torch.tensor([0, 255], dtype=torch.uint8))
    assert torch.equal(normalized, torch.tensor([-1.0, 1.0]))

    paths = [
        "/video/example.h265 1000 100 50",
        "/video/example.h265 1000 200 75",
    ]
    assert merge_vt_paths(paths) == ["/video/example.h265 1000 100 175"]


def test_decoder_failure_classification_preserves_empty_exception_type() -> None:
    """Timeouts and native decoder failures must rebuild the parser with useful logs."""
    timeout = TimeoutError()
    assert _exception_summary(timeout) == "TimeoutError"
    assert _requires_parser_reset(timeout)
    assert _requires_parser_reset(RuntimeError("HW decoder faced error. Re-create instance."))
    assert not _requires_parser_reset(ValueError("bad sample metadata"))


def test_worker_init_uses_actual_workers_per_gpu() -> None:
    """Worker seeds must use the real worker count to avoid cross-rank collisions."""
    import torchpilot.data.dataloader.tp_dataloader as tp_dataloader_module

    original = tp_dataloader_module._init_worker_funcion
    captured = {}

    def fake_init_worker(**kwargs: Any) -> Any:
        captured.update(kwargs)
        return lambda _worker_id: None

    tp_dataloader_module._init_worker_funcion = fake_init_worker
    try:
        with _tp_worker_init_override(lambda _worker_id: None, {"num_workers": 4, "seed": 666}):
            worker_init = tp_dataloader_module._init_worker_funcion()
            worker_init(3)
    finally:
        tp_dataloader_module._init_worker_funcion = original

    assert captured["workers_per_gpu"] == 4


def test_visual_backbone_uses_larger_micro_batches() -> None:
    """The visual backbone should preserve order while reducing DINO calls."""
    tokenizer = Plannn3VisualTokenizer.__new__(Plannn3VisualTokenizer)
    torch.nn.Module.__init__(tokenizer)
    tokenizer.backbone_batch_size = 32
    batch_sizes = []

    def fake_vqgan(batch_img: torch.Tensor) -> torch.Tensor:
        batch_sizes.append(batch_img.shape[0])
        return batch_img

    tokenizer._run_vqgan = fake_vqgan
    batch_img = torch.arange(162).reshape(162, 1)
    output = tokenizer._run_vqgan_batched(batch_img)

    assert batch_sizes == [32, 32, 32, 32, 32, 2]
    assert torch.equal(output, batch_img)


def test_dinov3_encoder_only_materializes_last_intermediate() -> None:
    """The visual encoder should not reshape unused DINO block outputs."""

    class FakeDino(torch.nn.Module):
        def __init__(self) -> None:
            super().__init__()
            self.kwargs = {}

        def forward_intermediates(self, tensor: torch.Tensor, **kwargs: Any) -> List[torch.Tensor]:
            self.kwargs = kwargs
            return [tensor + 1]

    encoder = Dinov3Encoder.__new__(Dinov3Encoder)
    torch.nn.Module.__init__(encoder)
    encoder.patchify = torch.nn.Identity()
    encoder.downsample = torch.nn.Identity()
    encoder.dinov3 = FakeDino()
    encoder.expand = torch.nn.Identity()

    input_tensor = torch.zeros(2, 3, 4, 4)
    output = encoder(input_tensor)

    assert torch.equal(output, input_tensor + 1)
    assert encoder.dinov3.kwargs == {"indices": 1, "intermediates_only": True}
