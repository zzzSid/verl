# -*- coding: utf-8 -*-
"""Tests for nn3 min-distance aux label (aligned with plannn3 IL gen_mindist_label)."""

import numpy as np
import pytest

from tpp_onemodel.data.plannn3.nn3_mindist_label import _frame_env_from_raw_env
from tpp_onemodel.data.plannn3.nn3_mindist_label import _mindist_to_label
from tpp_onemodel.data.plannn3.nn3_mindist_label import gen_traj_min_dist_label
from tpp_onemodel.data.plannn3.nn3_mindist_label import gen_traj_min_dist_label_from_raw_env


def _box_at(x: float, y: float, half_l: float = 2.0, half_w: float = 1.0) -> np.ndarray:
    return np.array(
        [
            [x + half_l, y + half_w],
            [x + half_l, y - half_w],
            [x - half_l, y - half_w],
            [x - half_l, y + half_w],
        ],
        dtype=np.float64,
    )


def test_frame_env_selects_current_frame_dobjs():
    """Dynamic polygons must come from curr_frame_idx, not all frames."""
    far_frame = np.stack([_box_at(50.0, 0.0)], axis=0)
    near_frame = np.stack([_box_at(1.5, 0.0, half_l=0.5, half_w=0.5)], axis=0)
    raw_env = {
        "dobjs_polygon": [far_frame, near_frame],
        "sobjs_polygon": np.empty((0, 4, 2), dtype=np.float64),
        "road_edge": [],
    }
    label_far = gen_traj_min_dist_label_from_raw_env(raw_env, curr_frame_idx=0)
    label_near = gen_traj_min_dist_label_from_raw_env(raw_env, curr_frame_idx=1)
    assert label_far == 10
    assert label_near < 10


def test_frame_env_expands_multi_object_dobjs():
    """Each dynamic object polygon is used (nn3 MultiPolygon over objects)."""
    dobjs = np.stack([_box_at(50.0, 0.0), _box_at(1.5, 0.0, half_l=0.5, half_w=0.5)], axis=0)
    frame_env = _frame_env_from_raw_env({"dobjs_polygon": [dobjs]}, curr_frame_idx=0)
    assert len(frame_env["dobjs_polygon"]) == 2
    label = gen_traj_min_dist_label(frame_env)
    assert label < 10


def test_legacy_single_frame_dobjs_still_works():
    """Single-frame [N, 4, 2] array without curr_frame_idx remains valid."""
    dobjs = np.stack([_box_at(1.5, 0.0, half_l=0.5, half_w=0.5)], axis=0)
    raw_env = {
        "dobjs_polygon": dobjs,
        "sobjs_polygon": np.empty((0, 4, 2), dtype=np.float64),
        "road_edge": [],
    }
    label = gen_traj_min_dist_label_from_raw_env(raw_env)
    assert label < 10


@pytest.mark.parametrize(
    "min_d, expected",
    [
        (0.05, 0),
        (0.1, 0),
        (0.1001, 1),
        (0.2, 1),
        (0.9, 8),
        (1.0, 9),
        (1.0001, 10),
    ],
)
def test_mindist_bin_boundaries_match_nn3(min_d, expected):
    """Bin edges follow nn3 IL intervals (0.1m belongs to label 0, not 1)."""
    assert _mindist_to_label(min_d) == expected
