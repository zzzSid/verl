# -*- coding: utf-8 -*-
"""Trainer for onemodel."""

import logging

import torch


logger = logging.getLogger(__name__)


class MultiTaskModelToy(torch.nn.Module):
    """MultiTaskModelToy."""

    def __init__(self, **kwargs):
        """Init."""
        super().__init__(**kwargs)
        self.shared = torch.nn.Linear(3, 1)
        self.head1 = torch.nn.Linear(1, 1)
        self.head2 = torch.nn.Linear(1, 1)
        self.flatten = torch.nn.Flatten(0, 1)

    def forward(self, inputs):
        """Forward."""
        use_head1 = inputs["use_head1"]
        _data = inputs["data"]
        if use_head1:
            feat = self.shared(_data)
            feat = self.head1(feat)
        else:
            feat = self.shared(_data)
            feat = self.head2(feat)
        return self.flatten(feat)


def test_loss_backward_triggered_multiple_at_shared_model():
    """Function name as doc."""
    model = MultiTaskModelToy()
    loss_fn = torch.nn.MSELoss(reduction="sum")

    attr_name_list = ["shared", "head1", "head2"]

    data = torch.randn((100, 3), dtype=torch.float)
    gt = torch.randn((100), dtype=torch.float)
    inputs = {
        "data": data,
        "use_head1": True,
    }

    pred = model(inputs)
    loss = loss_fn(pred, gt)
    loss.backward()

    logger.warning("Step one, forward model.shared and head1.")
    first_step_grad = {}
    for attr_name in attr_name_list:
        attr_grad_str = str(getattr(model, attr_name).weight.grad)
        first_step_grad[attr_name] = attr_grad_str
        logger.warning("Grad of weight of %s is %s.", attr_name, attr_grad_str)

    inputs["use_head1"] = False
    pred = model(inputs)
    loss = loss_fn(pred, gt)
    loss.backward()

    logger.warning("Step one, forward model.shared and head2.")
    second_step_grad = {}
    for attr_name in attr_name_list:
        attr_grad_str = str(getattr(model, attr_name).weight.grad)
        second_step_grad[attr_name] = attr_grad_str
        logger.warning("Grad of weight of %s is %s.", attr_name, attr_grad_str)

    assert first_step_grad["shared"] != second_step_grad["shared"]
    assert first_step_grad["head1"] == second_step_grad["head1"]
    assert first_step_grad["head2"] == "None"
    assert second_step_grad["head2"] != "None"


if __name__ == "__main__":
    test_loss_backward_triggered_multiple_at_shared_model()
