#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Unit tests for pkg."""

import tpp_onemodel


def test_pkg() -> None:
    """Unit test for pkg."""
    assert tpp_onemodel.__package__ == "tpp_onemodel"
