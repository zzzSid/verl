# -*- coding: utf-8 -*-
"""Test for Conv2d."""

import os
import pickle

import numpy as np
import pytest
import torch

from tpp_onemodel.model.layer.conv2d import Conv2d


OLD_LAYERS_DUMP_DIR = "/share-global/zhe.wang2/share/torch_migration/layer_test_data"


def test_conv2d():
    """Test for Conv2d."""
    in_channels, out_channels, kernel_size, strides = 64, 64, (3, 3), 1
    params = dict(
        in_channels=in_channels,
        out_channels=out_channels,
        kernel_size=kernel_size,
        strides=strides,
    )

    def prepare_data():
        """Prepare inputs, kernel, bias, outputs."""
        with open(os.path.join(OLD_LAYERS_DUMP_DIR, "conv2d_k3s1d1c64_input.pkl"), "rb") as fin:
            inputs = pickle.load(fin)
        with open(os.path.join(OLD_LAYERS_DUMP_DIR, "conv2d_k3s1d1c64_kernel.pkl"), "rb") as fin:
            kernel = pickle.load(fin)
        with open(os.path.join(OLD_LAYERS_DUMP_DIR, "conv2d_k3s1d1c64_bias.pkl"), "rb") as fin:
            bias = pickle.load(fin)
        with open(os.path.join(OLD_LAYERS_DUMP_DIR, "conv2d_k3s1d1c64_output.pkl"), "rb") as fin:
            outputs = pickle.load(fin)
        return inputs, kernel, bias, outputs

    inputs, kernel, bias, outputs = prepare_data()
    inputs = torch.from_numpy(inputs).cuda()
    layer = (
        Conv2d(**params, kernel_initializer=torch.from_numpy(kernel), bias_initializer=torch.from_numpy(bias))
        .type(inputs.dtype)
        .cuda()
    )
    layer_outputs = layer(inputs)
    assert np.allclose(layer_outputs.detach().cpu().numpy(), outputs)


if __name__ == "__main__":
    pytest.main([__file__])
