# -*- coding: utf-8 -*-
"""Test for Conv2d."""

import os
import pickle

import numpy as np
import pytest
import torch

from tpp_onemodel.model.layer.pool2d import MaxPool2D


OLD_LAYERS_DUMP_DIR = "/share-global/zhe.wang2/share/torch_migration/layer_test_data"


def test_maxpooling2d():
    """Test for MaxPool2D."""
    kernel_size, strides = 2, 2
    params = dict(
        pool_size=kernel_size,
        strides=strides,
    )

    def prepare_data():
        """Prepare inputs, output."""
        with open(os.path.join(OLD_LAYERS_DUMP_DIR, "maxpool2d_k2s2c64_input.pkl"), "rb") as fin:
            inputs = pickle.load(fin)
        with open(os.path.join(OLD_LAYERS_DUMP_DIR, "maxpool2d_k2s2c64_output.pkl"), "rb") as fin:
            outputs = pickle.load(fin)
        return inputs, outputs

    inputs, outputs = prepare_data()
    inputs = torch.from_numpy(inputs).cuda()
    layer = (
        MaxPool2D(
            **params,
        )
        .type(inputs.dtype)
        .cuda()
    )
    layer_outputs = layer(inputs)
    assert np.allclose(layer_outputs.detach().cpu().numpy(), outputs)


if __name__ == "__main__":
    pytest.main([__file__])
