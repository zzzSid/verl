#!/usr/bin/env bash
# run.sh - Unified launcher for both ncard (CUDA) and ppu environments.
#
# Usage:
#   TARGET=ncard bash run.sh <num_devices> <torchpilot args...>
#   TARGET=ppu   bash run.sh <num_devices> <torchpilot args...>
#
# TARGET defaults to "ncard" when unset.
set -euo pipefail

# ---------------------------------------------------------------------------
# Activate project virtualenv when available.
# Respects VENV_DIR override (must match what was used in make dev).
# ---------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="${VENV_DIR:-.venv}"
if [ -f "${SCRIPT_DIR}/${VENV_DIR}/bin/activate" ]; then
  # shellcheck disable=SC1091
  source "${SCRIPT_DIR}/${VENV_DIR}/bin/activate"
elif [ -f "${SCRIPT_DIR}/venv/bin/activate" ]; then
  # Backward-compatible fallback for the old "venv" directory name.
  # shellcheck disable=SC1091
  source "${SCRIPT_DIR}/venv/bin/activate"
fi

# ---------------------------------------------------------------------------
# Common environment variables (both ncard and ppu).
# ---------------------------------------------------------------------------
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1

export KMP_AFFINITY=disabled
export TORCHPILOT_ENABLE_COMPILE=False
export CACHE_URI=tcp://10.60.75.215:2022
export NIOFS_ACCESS_KEY="bfcf9d13f0405469"
export NIOFS_SECRET_KEY="3ac0cc7bd85b4888a6f11cd922ea8724"

# ---------------------------------------------------------------------------
# Validate required argument.
# ---------------------------------------------------------------------------
DEVICE_NUM="${1:-}"
if [ -z "$DEVICE_NUM" ]; then
  echo "Error: device count is required." >&2
  echo "Usage: TARGET=<ncard|ppu> $0 <num_devices> [torchpilot args...]" >&2
  exit 1
fi
echo "Device count: ${DEVICE_NUM}"
shift

if [ "$#" -lt 1 ]; then
  echo "Error: config path is required." >&2
  echo "Usage: TARGET=<ncard|ppu> $0 <num_devices> <config> [torchpilot args...]" >&2
  exit 1
fi

# ---------------------------------------------------------------------------
# Resolve TARGET from NTS_GPU_TYPE when not explicitly set.
# NTS_GPU_TYPE starting with "ppu" (e.g. "ppu-v1") → ppu.
# Anything else or unset                            → ncard.
# TARGET can still be overridden by the caller: TARGET=ppu bash run.sh ...
# ---------------------------------------------------------------------------
if [ -z "${TARGET:-}" ]; then
  case "${NTS_GPU_TYPE:-}" in
    ppu*) TARGET=ppu ;;
    *)    TARGET=ncard ;;
  esac
fi

echo "Resolved target: ${TARGET} (NTS_GPU_TYPE=${NTS_GPU_TYPE:-unset})"

# Keep these variables defined to avoid mpirun -x warnings.
: "${CUBLAS_WORKSPACE_CONFIG:=}"
: "${TORCHPILOT_OUTPUT_DIR:=}"
export CUBLAS_WORKSPACE_CONFIG
export TORCHPILOT_OUTPUT_DIR

if [ "${TARGET}" = "ppu" ]; then
  # PPU-specific environment.
  export OMPI_ALLOW_RUN_AS_ROOT=1
  export OMPI_ALLOW_RUN_AS_ROOT_CONFIRM=1
  export VC_MASTER_HOSTS="${NTS_JOB_NAME}-master-0.${NTS_JOB_NAME}"
  export PYTHONPATH="${SCRIPT_DIR}:${PYTHONPATH:-}"

  LAUNCHER=(
    mpirun
    -bind-to none -map-by slot
    --hostfile /tmp/all.host
    -x VC_MASTER_HOSTS
    -x PPU_SDK=/usr/local/PPU_SDK
    -x PPU_HOME=/usr/local/PPU_SDK
    -x NCCL_ALGO=RING
    -x NCCL_IB_DISABLE=1
    -x NCCL_IB_HCA=
    -x NCCL_SOCKET_IFNAME=eth0
    -x NCCL_DEBUG=INFO
    -x OMPI_ALLOW_RUN_AS_ROOT
    -x OMPI_ALLOW_RUN_AS_ROOT_CONFIRM
    -x NIOFS_ACCESS_KEY
    -x NIOFS_SECRET_KEY
    -x LUSTRE_ACCESS_KEY
    -x LUSTRE_SECRET_KEY
    -x READ_CACHE_OP_PY_REGION
    -x GPFS_MOUNT_POINT
    -x OMP_NUM_THREADS
    -x MKL_NUM_THREADS
    -x NUMEXPR_NUM_THREADS
    -x KMP_AFFINITY
    -x LD_LIBRARY_PATH
    -x PYTHONPATH
    -x PATH
    -x CACHE_URI
    -x CUBLAS_WORKSPACE_CONFIG
    -x TORCHPILOT_ENABLE_COMPILE
    -x TORCHPILOT_OUTPUT_DIR
    --mca pml ob1
    --mca oob_tcp_if_include eth0
    --mca btl_tcp_if_include eth0
    --mca btl ^openib
  )

elif [ "${TARGET}" = "ncard" ]; then
  LAUNCHER=(
    mpirun
    -bind-to none -map-by slot
    --hostfile /etc/volcano/all.host
    -x OMP_NUM_THREADS
    -x MKL_NUM_THREADS
    -x NUMEXPR_NUM_THREADS
    -x KMP_AFFINITY
    -x LD_LIBRARY_PATH
    -x PATH
    -x CACHE_URI
    -x CUBLAS_WORKSPACE_CONFIG
    -x TORCHPILOT_ENABLE_COMPILE
    -x TORCHPILOT_OUTPUT_DIR
    --mca pml ob1
    --mca btl ^openib
  )

else
  echo "Error: unknown TARGET '${TARGET}'. Expected 'ncard' or 'ppu'." >&2
  exit 1
fi

# ---------------------------------------------------------------------------
# Launch.
# ---------------------------------------------------------------------------
echo "Running: ${LAUNCHER[*]} -np ${DEVICE_NUM} .venv/bin/torchpilot run ${DEVICE_NUM} $*"
exec "${LAUNCHER[@]}" -np "${DEVICE_NUM}" .venv/bin/torchpilot run "${DEVICE_NUM}" "$@"
