# -*- coding: utf-8 -*-
"""Goal point planner model config."""
from tpp_onemodel.model.module.traj_encoder import TrajectoryEncoder


def create_goal_point_planner_encoder(train_mode, dim_model, num_head, num_pad_box, attn_hardtanh_val=None):
    """Create goal point planner encoder."""
    goal_point_planner_encoder_cfg = dict(
        type="GoalPointPlannerSceneEncoder",
        traj_encoder_cfg=dict(
            input_dim=18,
            hidden_dim=256,
            output_dim=256,
            num_layers=1,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        traj_t_cross_cfg=dict(
            type=TrajectoryEncoder,
            embed_dim=dim_model,
            num_heads=num_head,
            is_encoder=False,
            attn_hardtanh_val=attn_hardtanh_val,
            dropout=0.1,
            use_ffn=False,
            use_hpc_nn_ops=False,
            use_tvm_supported_sdpa=not train_mode,
        ),
        sod_encoder_cfg=dict(
            input_dim=len([0, 1, 2, 3, 4, 5, 6]),
            select_dims=[0, 1, 2, 3, 4, 5, 6],
            hidden_dim=256,
            output_dim=256,
            num_layers=3,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        sod_polyg_encoder_cfg=dict(
            input_dim=256,
            hidden_dim=256,
            output_dim=256,
            num_layers=3,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        sod_fuse_cfg=None,
        god_attr_encoder_cfg=dict(
            input_dim=4,
            select_dims=[0, 2, 3, 4],
            hidden_dim=256,
            output_dim=256,
            num_layers=3,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        god_poly_encoder_cfg=dict(
            input_dim=32,
            hidden_dim=256,
            output_dim=256,
            num_layers=3,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        tld_encoder_cfg={
            "type": "StampChannelMatcher",
            "in_channel": 12,
            "out_channel": 256,
            "activation": "relu",
            "relu_max_value": None,
        },
        ego_traj_encoder_cfg=dict(
            input_dim=17,
            hidden_dim=256,
            output_dim=256,
            num_layers=3,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        lane_encoder_cfg={
            "type": "LaneEncoder",
            "subencoder_cfg": {
                "type": "GoalVectorNet",
                "in_channel": 32,
                "hidden_channel": 256,
                "activation": "relu",
                "relu_max_value": None,
                "num_layers": 3,
                "dropout": 0.0,
                "reduce_mode": "mean",
            },
            "norm_val": [-100, 150, -50, 50],
            "lane_type_num": 4,
            "lane_attr_type_num": 14,  # should be 13, use 14 for encoder channel to be 32
            "lane_attr_color_num": 9,
        },
        atlas_encoder_cfg={
            "in_channel": 3,
            "hidden_channel": 256,
            "activation": "relu",
            "relu_max_value": None,
            "num_layers": 3,
            "dropout": 0.0,
        },
        sdmap_encoder_cfg={
            "type": "VectorNet",
            "in_channel": 2,
            "hidden_channel": 256,
            "activation": "relu",
            "relu_max_value": None,
            "num_layers": 3,
            "dropout": 0.0,
        },
        navi_path_encoder_cfg={
            "type": "NaviPathEncoder",
            "subencoder_cfg": {
                "type": "GoalVectorNet",
                "in_channel": 11,
                "hidden_channel": 256,
                "activation": "leaky_relu",
                "relu_max_value": None,
                "num_layers": 3,
                "dropout": 0.0,
                "reduce_mode": "mean",
            },
            "norm_val": [-50, 150, -50, 50],
        },
        control_point_encoder_cfg={
            "type": "ControlPointEncoder",
            "pos_norm_val": [-50, 200, -50, 50],
            "vel_max_val": 40,
            "input_size": 8,
            "hidden_size": 256,
        },
        input_sensors=[
            "dynamic_dets",
            "meta",
            "static_dets",
            "dynamic_gods",
            "lane",
            "atlas",
            # "navi_line",
            "navi_path",
            "control_points",
        ],
        norm_value=[200.0, 50.0, 2.0, 3.0, 1.0, 2.0, 1.0],
        dim_model=256,
        num_head=8,
        num_frame=15,
        num_pad_box=num_pad_box,
        dim_feedforward=256,
        relu_max_value=None,
        num_encoder_layers=4,
        dropout=0.0,
        activation="relu",
        attn_hardtanh_val=None,
        normalize_before=False,
        norm=True,
        no_encoder_ffn=False,
        no_encoder_self_att=False,
        use_hpc_nn_ops=False,
        use_tvm_supported_sdpa=not train_mode,
        box_class_dims=7,
    )
    return {"goal_point_planner_encoder": goal_point_planner_encoder_cfg}


def create_goal_point_planner_head(
    train_mode,
    embed_dim,
    layer_num,
    head_num,
    close_loop_cfg=None,
    attn_hardtanh_val=None,
    ego_future_frames_num=35,
    num_pad_box=64,
):
    """Create goal point planner decoder."""
    operation_layer = ["self_attn", "norm", "full_cross_attn", "norm", "ffn", "norm"]
    operation_order = []
    predict_stride = [1, 1]

    for layer_index in predict_stride:
        operation_order.extend(operation_layer * layer_index + ["output"])

    operation_dict = dict(
        self_attn=dict(
            type="StampMultiheadAttention",
            embed_dim=embed_dim,
            num_heads=head_num,
            is_encoder=False,
            attn_hardtanh_val=attn_hardtanh_val,
            dropout=0.0,
            use_hpc_nn_ops=False,
            use_tvm_supported_sdpa=not train_mode,
        ),
        full_cross_attn=dict(
            type="PlannerCrossAttention",
            key_list=["ego", "agent", "navi_path", "lane", "sod", "god_poly", "control_points"],
            embed_dim=embed_dim,
            num_heads=head_num,
            is_encoder=False,
            attn_hardtanh_val=attn_hardtanh_val,
            dropout=0.0,
            use_hpc_nn_ops=False,
            num_query=1,
            num_query_agent=6,
            bs_agent=num_pad_box,
            use_tvm_supported_sdpa=not train_mode,
            trace_model_in_loop_flag=close_loop_cfg["trace_model_in_loop_flag"],
        ),
    )

    goal_point_planner_head_cfg = dict(
        type="GoalPointPlannerHead",
        decoder_cfg=dict(
            type="GoalPointPlannerEgoDecoder",
            embed_dim=embed_dim,
            layer_num=layer_num,
            head_num=head_num,
            marginal_prediction_decoder_cfg=dict(
                type="TransformerDecoder",
                dim_model=embed_dim,
                operation_order=operation_order,
                operation_dict=operation_dict,
                dim_feedforward=256,
                dropout=0.0,
                return_intermediate=True,
            ),
            traj_predictor_cfg=dict(
                type="StampPredictionPredictor",
                feature_dim=embed_dim,
                output_dim=ego_future_frames_num * 2 + 1,
                num_layers=2,
                dropout=0.0,
                activation="relu",
                relu_max_value=None,
                pred_vel=True,
                pred_frequency=5,
                num_pred_frames=ego_future_frames_num,
                with_vm=True,
                vm_wheel_steer_ratio=0.1,
                # vm_steer_cmd="front_wheel",
                module_flag="planner",
            ),
            train_mode=train_mode,
        ),
    )
    return {"goal_point_planner_head": goal_point_planner_head_cfg}


def create_goal_point_planner_loss():
    """Create astra planner loss."""
    loss_cfg = dict(
        type="GoalPointPlannerLoss",
        loss_cfg=[
            dict(type="GoalPointPlannerL2Loss"),
            dict(type="ControlPointLoss"),
        ],
        loss_weight={"l2_loss": 1.0, "control_point_loss": 2.0},
    )
    return {
        "goal_point_planner": loss_cfg,
    }


def create_goal_point_planner_evaluator(
    infer_batch_size,
    ego_k_traj_num,
    scene_modality,
    ego_future_frames_num,
):
    """Create goal point planner evaluator."""
    goal_point_planner_evaluator_cfg = dict(
        type="AstraPlannerSceneEvaluator",
        enable_task="goal_point_planner",
        config={"type": "EvaluationBaseConfig"},
        adapter_cfg=dict(
            ego_num_pred_frames=ego_future_frames_num,
            agent_num_pred_frames=35,
            ego_k_traj_num=ego_k_traj_num,
            k_traj_num=6,
            pred_dim=2,
            num_pad_box=191,
            num_frame=15,
            max_guesses=6,
            scene_modality=scene_modality,
        ),
        eval_common_cfg=dict(
            batch_size=infer_batch_size,
        ),
        dump_image=False,
        draw_keys=[
            "goal_point_ego_traj_pred",
            "ego_traj_gt",
            "ego_box",
            "agent_box",
            "atlas",
            "navi_path",
            "laneline",
            "curb",
            "stopline",
            "ego_vel",
            "tld",
            "navi_path_tld",
            "control_point",
        ],
        use_gpu=False,
    )
    return {"goal_point_planner": goal_point_planner_evaluator_cfg}
