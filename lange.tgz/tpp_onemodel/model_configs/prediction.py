# -*- coding: utf-8 -*-
"""Prediction model config."""
import itertools

from tpp_onemodel.model.module.traj_encoder import TrajectoryEncoder


def create_prediction_encoder(train_mode, dim_model, num_head, num_pad_box, attn_hardtanh_val=None):
    """Create prediction encoder."""
    prediction_encoder_cfg = dict(
        type="PlannerSceneEncoder",
        traj_encoder_cfg=dict(
            input_dim=18,
            hidden_dim=256,
            output_dim=256,
            num_layers=1,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        traj_t_cross_cfg=dict(
            type=TrajectoryEncoder,
            embed_dim=dim_model,
            num_heads=num_head,
            is_encoder=False,
            attn_hardtanh_val=attn_hardtanh_val,
            dropout=0.1,
            use_ffn=False,
            use_hpc_nn_ops=False,
            use_tvm_supported_sdpa=not train_mode,
        ),
        local_traj_encoder_cfg=dict(
            input_dim=16,
            hidden_dim=256,
            output_dim=256,
            num_layers=1,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        sod_encoder_cfg=dict(
            input_dim=len([0, 1, 2, 3, 4, 5, 6]),
            select_dims=[0, 1, 2, 3, 4, 5, 6],
            hidden_dim=256,
            output_dim=256,
            num_layers=3,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        sod_polyg_encoder_cfg=dict(
            input_dim=256,
            hidden_dim=256,
            output_dim=256,
            num_layers=3,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        sod_fuse_cfg=None,
        god_attr_encoder_cfg=dict(
            input_dim=4,
            select_dims=[0, 2, 3, 4],
            hidden_dim=256,
            output_dim=256,
            num_layers=3,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        god_poly_encoder_cfg=dict(
            input_dim=32,
            hidden_dim=256,
            output_dim=256,
            num_layers=3,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        tld_encoder_cfg={
            "type": "StampChannelMatcher",
            "in_channel": 12,
            "out_channel": 256,
            "activation": "relu",
            "relu_max_value": None,
        },
        ego_traj_encoder_cfg=dict(
            input_dim=17,
            hidden_dim=256,
            output_dim=256,
            num_layers=3,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        lane_encoder_cfg={
            "type": "LaneEncoder",
            "subencoder_cfg": {
                "type": "VectorNet",
                "in_channel": 32,
                "hidden_channel": 256,
                "activation": "relu",
                "relu_max_value": None,
                "num_layers": 3,
                "dropout": 0.0,
            },
            "norm_val": [-100, 150, -50, 50],
            "lane_type_num": 4,
            "lane_attr_type_num": 14,  # should be 13, use 14 for encoder channel to be 32
            "lane_attr_color_num": 9,
            "use_local_feature": True,
        },
        atlas_encoder_cfg={
            "in_channel": 3,
            "hidden_channel": 256,
            "activation": "relu",
            "relu_max_value": None,
            "num_layers": 3,
            "dropout": 0.0,
        },
        sdmap_encoder_cfg={
            "type": "VectorNet",
            "in_channel": 2,
            "hidden_channel": 256,
            "activation": "relu",
            "relu_max_value": None,
            "num_layers": 3,
            "dropout": 0.0,
        },
        # navi_path_encoder_cfg={
        #     "type": "NaviPathEncoder",
        #     "subencoder_cfg": {
        #         "type": "GoalVectorNet",
        #         "in_channel": 11,
        #         "hidden_channel": 256,
        #         "activation": "leaky_relu",
        #         "relu_max_value": None,
        #         "num_layers": 3,
        #         "dropout": 0.0,
        #         "reduce_mode": "mean",
        #     },
        #     "norm_val": [-50, 150, -50, 50],
        # },
        navi_path_encoder_cfg=dict(
            input_dim=352,
            hidden_dim=256,
            output_dim=256,
            num_layers=3,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        navi_path_reduce_cfg=[
            dict(
                input_dim=200,
                hidden_dim=64,
                output_dim=64,
                num_layers=2,
                dropout=0.0,
                activation="relu",
                relu_max_value=None,
            ),
            dict(
                input_dim=64,
                hidden_dim=32,
                output_dim=32,
                num_layers=2,
                dropout=0.0,
                activation="relu",
                relu_max_value=None,
            ),
        ],
        input_sensors=[
            "dynamic_dets",
            "meta",
            "static_dets",
            "dynamic_gods",
            "lane",
            "atlas",
            # "navi_line",
            "navi_path",
        ],
        norm_value=[200.0, 50.0, 2.0, 3.0, 1.0, 2.0, 1.0],
        dim_model=256,
        num_head=8,
        num_frame=15,
        num_pad_box=num_pad_box,
        dim_feedforward=256,
        relu_max_value=None,
        num_encoder_layers=4,
        dropout=0.0,
        activation="relu",
        attn_hardtanh_val=None,
        normalize_before=False,
        norm=True,
        no_encoder_ffn=False,
        no_encoder_self_att=False,
        use_hpc_nn_ops=False,
        use_tvm_supported_sdpa=not train_mode,
        box_class_dims=7,
    )
    return {"prediction_encoder": prediction_encoder_cfg}


def create_prediction_head(
    train_mode,
    dim_model=256,
    num_head=8,
    num_pad_box=None,
    predict_stride=None,
    trackable_predict_stride=None,
    ego_k_traj_num=None,
    select_scenes=None,
    scene_modality=None,
    isolate_static_agent=None,
    attn_hardtanh_val=None,
    close_loop_cfg=None,
    ego_future_frames_num=35,
):
    """Create prediction head."""
    operation_layer = ["self_attn", "norm", "full_cross_attn", "norm", "ffn", "norm"]
    operation_order = []
    for layer_num in predict_stride:
        operation_order.extend(operation_layer * layer_num + ["output"])

    # 构造跟车部分的网络
    trackable_operation_layer = ["self_attn", "norm", "full_cross_attn", "norm", "ffn", "norm"]
    trackable_operation_order = []
    for layer_num in trackable_predict_stride:
        trackable_operation_order.extend(trackable_operation_layer * layer_num + ["output"])

    operation_dict = dict(
        self_attn=dict(
            type="StampMultiheadAttention",
            embed_dim=dim_model,
            num_heads=num_head,
            is_encoder=False,
            attn_hardtanh_val=attn_hardtanh_val,
            dropout=0.0,
            use_hpc_nn_ops=False,
            use_tvm_supported_sdpa=not train_mode,
        ),
        full_cross_attn=dict(
            type="PlannerCrossAttention",
            key_list=["ego", "agent", "lane"],
            embed_dim=dim_model,
            num_heads=num_head,
            is_encoder=False,
            attn_hardtanh_val=attn_hardtanh_val,
            dropout=0.0,
            use_hpc_nn_ops=False,
            num_query=72,
            num_query_agent=6,
            bs_agent=num_pad_box,
            use_tvm_supported_sdpa=not train_mode,
            trace_model_in_loop_flag=close_loop_cfg["trace_model_in_loop_flag"],
        ),
    )
    trackable_agent_operation_dict = dict(
        self_attn=dict(
            type="StampMultiheadAttention",
            embed_dim=dim_model,
            num_heads=num_head,
            is_encoder=False,
            attn_hardtanh_val=attn_hardtanh_val,
            dropout=0.0,
            use_hpc_nn_ops=False,
            use_tvm_supported_sdpa=not train_mode,
        ),
        full_cross_attn=dict(
            type="PlannerCrossAttention",
            key_list=["ego", "navi_path"],
            embed_dim=dim_model,
            num_heads=num_head,
            is_encoder=False,
            attn_hardtanh_val=attn_hardtanh_val,
            dropout=0.0,
            use_hpc_nn_ops=False,
            num_query=64,
            num_query_agent=1,
            bs_agent=num_pad_box,
            use_tvm_supported_sdpa=not train_mode,
            trace_model_in_loop_flag=close_loop_cfg["trace_model_in_loop_flag"],
        ),
    )

    prediction_head_cfg = dict(
        type="PredictionHead",
        isolate_static_agent=isolate_static_agent,
        visualize_match_result=False,
        decoder_cfg=dict(
            type="AstraPlannerAgentDecoder",
            dim_model=dim_model,
            num_head=num_head,
            num_frame=15,
            num_pad_box=num_pad_box,
            k_traj_num=6,
            ego_k_traj_num=ego_k_traj_num,
            activation="relu",
            relu_max_value=None,
            use_hpc_nn_ops=False,
            marginal_prediction_decoder_cfg=dict(
                type="TransformerDecoder",
                dim_model=dim_model,
                operation_order=operation_order,
                operation_dict=operation_dict,
                dim_feedforward=256,
                dropout=0.0,
                return_intermediate=True,
            ),
            pred_traj_decoder_cfg=dict(
                type="StampPredictionPredictor",
                feature_dim=dim_model,
                output_dim=71,
                num_layers=2,
                dropout=0.0,
                activation="relu",
                relu_max_value=None,
                pred_vel=True,
                pred_frequency=5,
                num_pred_frames=35,
                with_vm=False,
                module_flag="prediction",
            ),
            ego_traj_decoder_cfg=dict(
                type="StampPredictionPredictor",
                feature_dim=dim_model,
                output_dim=ego_future_frames_num * 2 + 1,
                num_layers=2,
                dropout=0.0,
                activation="relu",
                relu_max_value=None,
                pred_vel=True,
                pred_frequency=5,
                num_pred_frames=ego_future_frames_num,
                with_vm=False,
                vm_wheel_steer_ratio=0.1,
                # vm_steer_cmd="front_wheel",
                module_flag="planner",
            ),
            navi_scene_decoder_cfg=dict(
                type="BaseMLP",
                feature_dim=256,
                output_dim=len(select_scenes),
                num_layers=2,
                dropout=0.1,
                activation="relu",
                relu_max_value=None,
            ),
            od_prior_head_cfg=dict(
                type="ODPriorHead",
                embed_dim=64,
                bbox_keep_dim=[0, 1, 3, 4, 6, 10, 11],
                bbox_input_dim=7 * 15,
                layer_num=2,
                lane_input_dim=256,
                lane_feat_dim=64,
                lane_feat_extractor_cfg=dict(type="ODPriorLaneFeatExtractor", dim=64, query_num=10, head_num=4),
                train_mode=train_mode,
            ),
            trackable_agent_decoder_cfg=dict(
                type="TransformerDecoder",
                dim_model=dim_model,
                operation_order=trackable_operation_order,
                operation_dict=trackable_agent_operation_dict,
                dim_feedforward=256,
                dropout=0.0,
                return_intermediate=False,
            ),
            scene_modality=scene_modality,
            mask_mod_score_wo_navi=True,
            select_scenes=select_scenes,
            intention_point_file="/share-global/enze.chen/debug/0715_len70_n_clusters6_mainclass.pkl",
        ),
    )
    return {"prediction_head": prediction_head_cfg}


def create_prediction_loss(
    select_scenes,
    num_pad_box,
    agent_predict_stride,
    ego_k_traj_num,
    scene_modality,
):
    """Create prediction loss."""
    # ego_layer_loss_weights = [
    #     0.8 ** (sum(predict_stride) - layer_id) for layer_id in list(itertools.accumulate(predict_stride))
    # ]
    agent_layer_loss_weights = [
        0.8 ** (sum(agent_predict_stride) - layer_id) for layer_id in list(itertools.accumulate(agent_predict_stride))
    ]
    loss_cfg = dict(
        type="AstraPlannerIntegratedLossV2",
        ego_layer_loss_weights=None,
        agent_layer_loss_weights=agent_layer_loss_weights,
        ego_loss_func_cfg={},
        agent_loss_func_cfg=dict(
            pred_loss_cfg=dict(
                type="MarginalPredictionLoss",
                stamp_loss_cfg=dict(
                    type="PlannerAgentPredictionLoss",
                    k_traj_num=6,
                    ego_k_traj_num=ego_k_traj_num,
                    scene_modality=scene_modality,
                    pred_dim=2,
                    num_pred_frames=35,
                    num_pad_box=num_pad_box,
                    norm_traj_output=True,
                    trainable_cov=False,
                    option="NormL2MultiLogLikelihoodLoss",
                    disable_confidence=False,
                    use_intention_query=True,
                    only_intention_query=False,
                    select_scenes=select_scenes,
                    hist_frame_thresh=3,
                ),
            ),
            od_prior_loss_cfg=dict(
                type="ODPriorLoss",
            ),
            trackable_cls_loss_cfg=dict(
                type="FocalLoss",
                gamma=2.0,
                alpha=0.25,
            ),
        ),
        loss_scale_cfg={
            "pred_loss_scale": {
                "pred_l2_loss": 1.0,
                "pred_confidence_loss": 1.0,
                "ego_l2_loss": 3.0,
                "navi_scene_pred_loss": 1.0,
                "modality_confidence_loss": 1.0,
                "navi_confidence_loss": 1.0,
                "ego_confidence_loss": 1.0,
                "ego_vel_l2_loss": 1.0,
                "ego_jerk_loss": 0.0,
            },
            "lane_collision_loss_scale": {"lane_collision_loss": 1.0},
            "navi_missing_loss_scale": {"navi_missing_loss": 1.0},
            "lateral_loss_scale": {"lateral_loss": 1.0},
            "od_collision_loss_scale": {"ego_collision_loss": 1.0, "ego_sod_collision_loss": 1.0},
            "extra_imitation_loss_scale": {"extra_imitation_loss": 1.0},
            "od_prior_loss_scale": {"od_prior_loss": 10.0},
        },
    )
    return {
        "prediction": loss_cfg,
    }


def create_prediction_evaluator(
    infer_batch_size,
    ego_k_traj_num,
    scene_modality,
    ego_future_frames_num,
):
    """Create prediction evaluator."""
    prediction_evaluator_cfg = dict(
        type="AstraPlannerSceneEvaluator",
        enable_task="prediction",
        config={"type": "EvaluationBaseConfig"},
        adapter_cfg=dict(
            ego_num_pred_frames=ego_future_frames_num,
            agent_num_pred_frames=35,
            ego_k_traj_num=ego_k_traj_num,
            k_traj_num=6,
            pred_dim=2,
            num_pad_box=191,
            num_frame=15,
            max_guesses=6,
            scene_modality=scene_modality,
        ),
        eval_common_cfg=dict(
            batch_size=infer_batch_size,
        ),
        dump_image=False,
        draw_keys=[
            "ego_box",
            "agent_box",
            "atlas",
            "navi_path",
            "laneline",
            "curb",
            "stopline",
            "ego_vel",
            "tld",
            "navi_path_tld",
            "control_point",
            "od_prior_gt",
            "od_prior_pred",
            "ego_traj_gt",
        ],
        use_gpu=False,
    )
    return {"prediction": prediction_evaluator_cfg}
