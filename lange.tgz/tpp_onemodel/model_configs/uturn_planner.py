# -*- coding: utf-8 -*-
"""Astra planner model config."""
import itertools

from tpp_onemodel.model.module.traj_encoder import TrajectoryEncoder


# same as astra planner encoder
def create_uturn_planner_encoder(
    train_mode,
    dim_model,
    num_head,
    num_pad_box,
    attn_hardtanh_val=None,
    ego_traj_encoder_input_dim=17,
    enable_control_ppoints: bool = False,
):
    """Create astra planner encoder."""
    uturn_planner_encoder_cfg = dict(
        type="UTurnPlannerSceneEncoder",
        traj_encoder_cfg=dict(
            input_dim=18,
            hidden_dim=256,
            output_dim=256,
            num_layers=1,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        traj_t_cross_cfg=dict(
            type=TrajectoryEncoder,
            # type=StampMultiheadAttention,
            embed_dim=dim_model,
            num_heads=num_head,
            is_encoder=False,
            attn_hardtanh_val=attn_hardtanh_val,
            dropout=0.1,
            use_hpc_nn_ops=False,
            use_tvm_supported_sdpa=not train_mode,
            use_ffn=False,
        ),
        sod_encoder_cfg=dict(
            input_dim=len([0, 1, 2, 3, 4, 5, 6]),
            select_dims=[0, 1, 2, 3, 4, 5, 6],
            hidden_dim=256,
            output_dim=256,
            num_layers=3,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        sod_polyg_encoder_cfg=dict(
            input_dim=256,
            hidden_dim=256,
            output_dim=256,
            num_layers=3,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        sod_fuse_cfg=None,
        god_attr_encoder_cfg=dict(
            input_dim=4,
            select_dims=[0, 2, 3, 4],
            hidden_dim=256,
            output_dim=256,
            num_layers=3,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        god_poly_encoder_cfg=dict(
            input_dim=32,
            hidden_dim=256,
            output_dim=256,
            num_layers=3,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        tld_encoder_cfg={
            "type": "StampChannelMatcher",
            "in_channel": 12,
            "out_channel": 256,
            "activation": "relu",
            "relu_max_value": None,
        },
        ego_traj_encoder_cfg=dict(
            input_dim=ego_traj_encoder_input_dim,
            hidden_dim=256,
            output_dim=256,
            num_layers=3,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        lane_encoder_cfg={
            "type": "LaneEncoder",
            "subencoder_cfg": {
                "type": "GoalVectorNet",
                "in_channel": 32,
                "hidden_channel": 256,
                "activation": "relu",
                "relu_max_value": None,
                "num_layers": 3,
                "dropout": 0.0,
                "reduce_mode": "mean",
            },
            "norm_val": [-100, 150, -50, 50],
            "lane_type_num": 4,
            "lane_attr_type_num": 14,  # should be 13, use 14 for encoder channel to be 32
            "lane_attr_color_num": 9,
        },
        atlas_encoder_cfg={
            "in_channel": 3,
            "hidden_channel": 256,
            "activation": "relu",
            "relu_max_value": None,
            "num_layers": 3,
            "dropout": 0.0,
        },
        sdmap_encoder_cfg={
            "type": "VectorNet",
            "in_channel": 2,
            "hidden_channel": 256,
            "activation": "relu",
            "relu_max_value": None,
            "num_layers": 3,
            "dropout": 0.0,
        },
        navi_path_encoder_cfg={
            "type": "NaviPathEncoder",
            "subencoder_cfg": {
                "type": "GoalVectorNet",
                "in_channel": 11,
                "hidden_channel": 256,
                "activation": "leaky_relu",
                "relu_max_value": None,
                "num_layers": 3,
                "dropout": 0.0,
                "reduce_mode": "mean",
            },
            "norm_val": [-50, 150, -50, 50],
        },
        input_sensors=[
            "dynamic_dets",
            "meta",
            "static_dets",
            "dynamic_gods",
            "lane",
            "atlas",
            # "navi_line",
            "navi_path",
        ],
        norm_value=[200.0, 50.0, 2.0, 3.0, 1.0, 2.0, 1.0],
        dim_model=256,
        num_head=8,
        num_frame=15,
        num_pad_box=num_pad_box,
        dim_feedforward=256,
        relu_max_value=None,
        num_encoder_layers=4,
        dropout=0.0,
        activation="relu",
        attn_hardtanh_val=None,
        normalize_before=False,
        norm=True,
        no_encoder_ffn=False,
        no_encoder_self_att=False,
        use_hpc_nn_ops=False,
        use_tvm_supported_sdpa=not train_mode,
        box_class_dims=7,
    )
    if enable_control_ppoints:
        uturn_planner_encoder_cfg["input_sensors"]
        uturn_planner_encoder_cfg["control_point_encoder_cfg"] = dict(
            type="ControlPointEncoder",
            pos_norm_val=[-50, 200, -50, 50],
            vel_max_val=40,
            input_size=8,
            hidden_size=256,
        )

    return {"uturn_planner_encoder": uturn_planner_encoder_cfg}


def create_uturn_planner_head(
    train_mode,
    embed_dim,
    layer_num,
    head_num,
    ego_future_frames_num,
    close_loop_cfg=None,
):
    """Create goal point planner decoder."""
    uturn_planner_head_cfg = dict(
        type="UTurnPlannerHead",
        decoder_cfg=dict(
            type="UTurnPlannerEgoDecoder",
            embed_dim=embed_dim,
            layer_num=layer_num,
            head_num=head_num,
            traj_predictor_cfg=dict(
                type="StampPredictionPredictor",
                feature_dim=embed_dim,
                output_dim=ego_future_frames_num * 2 + 1,
                num_layers=2,
                dropout=0.0,
                activation="relu",
                relu_max_value=None,
                pred_vel=True,
                pred_frequency=5,
                num_pred_frames=ego_future_frames_num,
                with_vm=True,
                vm_wheel_steer_ratio=0.1,
                # vm_steer_cmd="front_wheel",
                module_flag="planner",
                output_gears=True,
            ),
            train_mode=train_mode,
        ),
    )
    return {"uturn_planner_head": uturn_planner_head_cfg}


def create_uturn_planner_head_xfrm_decoder(
    train_mode,
    embed_dim,
    layer_num,
    head_num,
    ego_future_frames_num,
    close_loop_cfg=None,
    num_pad_box=None,
    predict_stride=None,
    attn_hardtanh_val=None,
    output_gears=False,
):
    """Create goal point planner decoder."""
    operation_layer = ["self_attn", "norm", "full_cross_attn", "norm", "ffn", "norm"]
    operation_order = []
    for layer_num in predict_stride:
        operation_order.extend(operation_layer * layer_num + ["output"])

    operation_dict = dict(
        self_attn=dict(
            type="StampMultiheadAttention",
            embed_dim=embed_dim,
            num_heads=head_num,
            is_encoder=False,
            attn_hardtanh_val=attn_hardtanh_val,
            dropout=0.0,
            use_hpc_nn_ops=False,
            use_tvm_supported_sdpa=not train_mode,
        ),
        full_cross_attn=dict(
            type="PlannerCrossAttention",
            key_list=["ego", "agent", "navi_path", "lane"],
            embed_dim=embed_dim,
            num_heads=head_num,
            is_encoder=False,
            attn_hardtanh_val=attn_hardtanh_val,
            dropout=0.0,
            use_hpc_nn_ops=False,
            num_query=1,
            num_query_agent=6,
            bs_agent=num_pad_box,
            use_tvm_supported_sdpa=not train_mode,
            trace_model_in_loop_flag=close_loop_cfg["trace_model_in_loop_flag"],
        ),
    )
    uturn_planner_head_cfg = dict(
        type="UTurnPlannerHead",
        decoder_cfg=dict(
            type="UTurnPlannerEgoDecoder",
            embed_dim=embed_dim,
            layer_num=layer_num,
            head_num=head_num,
            traj_predictor_cfg=dict(
                type="StampPredictionPredictor",
                feature_dim=embed_dim,
                output_dim=ego_future_frames_num * 2 + 1,
                num_layers=2,
                dropout=0.0,
                activation="relu",
                relu_max_value=None,
                pred_vel=True,
                pred_frequency=5,
                num_pred_frames=ego_future_frames_num,
                with_vm=True,
                vm_wheel_steer_ratio=0.1,
                module_flag="planner",
                output_gears=output_gears,
            ),
            decoder_cfg=dict(
                type="TransformerDecoder",
                dim_model=embed_dim,
                operation_order=operation_order,
                operation_dict=operation_dict,
                dim_feedforward=256,
                dropout=0.0,
                return_intermediate=True,
            ),
            train_mode=train_mode,
        ),
    )
    return {"uturn_planner_head": uturn_planner_head_cfg}


def create_uturn_planner_loss(
    predict_stride,
):
    """Create astra planner loss."""
    layer_loss_weights = [
        0.8 ** (sum(predict_stride) - layer_id) for layer_id in list(itertools.accumulate(predict_stride))
    ]
    multi_layer_loss_cfg = dict(
        type="MultiLayerLoss",
        loss_cfg=[
            dict(type="GoalPointPlannerL2Loss"),
            dict(
                type="CELoss",
                loss_func_cfg=dict(
                    target_key_path=["input", "egos_gt_gear"],
                    logits_key_path=["output", "marginal_output", "ego_pred_gear"],
                    mask_key_path=["input", "egos_pred_mask"],
                    mode="top1_logtis_traj",
                    output_loss_key="ego_gear_class_loss",
                ),
            ),
        ],
        loss_weight=dict(l2_loss=1.0, lane_collision_loss=1.0, ego_gear_class_loss=1.0),
        task_output_key="uturn_planner_pred_output",
        layer_loss_weights=layer_loss_weights,
    )
    return {
        "uturn_planner": multi_layer_loss_cfg,
    }


def create_uturn_planner_evaluator(
    infer_batch_size,
    ego_k_traj_num,
    scene_modality,
    ego_future_frames_num,
):
    """Create goal point planner evaluator."""
    uturn_planner_evaluator_cfg = dict(
        type="AstraPlannerSceneEvaluator",
        enable_task="uturn_planner",
        config={"type": "EvaluationBaseConfig"},
        adapter_cfg=dict(
            ego_num_pred_frames=ego_future_frames_num,
            agent_num_pred_frames=35,
            ego_k_traj_num=ego_k_traj_num,
            k_traj_num=6,
            pred_dim=2,
            num_pad_box=191,
            num_frame=15,
            max_guesses=6,
            scene_modality=scene_modality,
        ),
        eval_common_cfg=dict(
            batch_size=infer_batch_size,
        ),
        dump_image=False,
        draw_keys=[
            "uturn_ego_traj_pred",
            "ego_traj_gt",
            "ego_box",
            "agent_box",
            "atlas",
            "navi_path",
            "laneline",
            "curb",
            "stopline",
            "ego_vel",
            "tld",
            "navi_path_tld",
            "control_point",
        ],
        use_gpu=False,
    )
    return {"uturn_planner": uturn_planner_evaluator_cfg}
