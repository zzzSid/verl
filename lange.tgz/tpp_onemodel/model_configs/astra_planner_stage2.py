# -*- coding: utf-8 -*-
"""Astra planner model config."""
import copy
import itertools

from tpp_onemodel.model.loss.astraplanner_loss import AgentCollisionReward
from tpp_onemodel.model.loss.astraplanner_loss import LaneCollisionReward
from tpp_onemodel.model.loss.astraplanner_loss import TrajectoryRewardLoss
from tpp_onemodel.model.module.astraplanner_stage2_decoder import AstraPlannerEgoRefiner
from tpp_onemodel.model.module.stamp_transformer import MLP
from tpp_onemodel.model.module.stamp_transformer import MLPnorm
from tpp_onemodel.model.module.traj_encoder import TrajectoryEncoder


def create_astra_planner_stage2_encoder(
    train_mode, dim_model, num_head, num_pad_box, attn_hardtanh_val=None, ego_traj_encoder_input_dim=17
):
    """Create astra planner encoder."""
    astra_planner_stage2_encoder_cfg = dict(
        type="PlannerSceneEncoder",
        traj_encoder_cfg=dict(
            input_dim=18,
            hidden_dim=256,
            output_dim=256,
            num_layers=1,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        traj_t_cross_cfg=dict(
            type=TrajectoryEncoder,
            embed_dim=dim_model,
            num_heads=num_head,
            is_encoder=False,
            attn_hardtanh_val=attn_hardtanh_val,
            dropout=0.1,
            use_ffn=False,
            use_hpc_nn_ops=False,
            use_tvm_supported_sdpa=not train_mode,
        ),
        sod_encoder_cfg=dict(
            input_dim=len([0, 1, 2, 3, 4, 5, 6]),
            select_dims=[0, 1, 2, 3, 4, 5, 6],
            hidden_dim=256,
            output_dim=256,
            num_layers=3,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        sod_polyg_encoder_cfg=dict(
            input_dim=256,
            hidden_dim=256,
            output_dim=256,
            num_layers=3,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        sod_fuse_cfg=None,
        god_attr_encoder_cfg=dict(
            input_dim=4,
            select_dims=[0, 2, 3, 4],
            hidden_dim=256,
            output_dim=256,
            num_layers=3,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        god_poly_encoder_cfg=dict(
            input_dim=32,
            hidden_dim=256,
            output_dim=256,
            num_layers=3,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        tld_encoder_cfg={
            "type": "StampChannelMatcher",
            "in_channel": 12,
            "out_channel": 256,
            "activation": "relu",
            "relu_max_value": None,
        },
        ego_traj_encoder_cfg=dict(
            input_dim=ego_traj_encoder_input_dim,
            hidden_dim=256,
            output_dim=256,
            num_layers=3,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        lane_encoder_cfg={
            "type": "LaneEncoder",
            "subencoder_cfg": {
                "type": "GoalVectorNet",
                "in_channel": 32,
                "hidden_channel": 256,
                "activation": "leaky_relu",
                "relu_max_value": None,
                "num_layers": 3,
                "dropout": 0.0,
                "reduce_mode": "mean",
            },
            "norm_val": [-100, 150, -50, 50],
            "lane_type_num": 4,
            "lane_attr_type_num": 14,  # should be 13, use 14 for encoder channel to be 32
            "lane_attr_color_num": 9,
        },
        atlas_encoder_cfg={
            "in_channel": 3,
            "hidden_channel": 256,
            "activation": "relu",
            "relu_max_value": None,
            "num_layers": 3,
            "dropout": 0.0,
        },
        sdmap_encoder_cfg={
            "type": "VectorNet",
            "in_channel": 2,
            "hidden_channel": 256,
            "activation": "relu",
            "relu_max_value": None,
            "num_layers": 3,
            "dropout": 0.0,
        },
        # navi_path_encoder_cfg={
        #     "type": "NaviPathEncoder",
        #     "subencoder_cfg": {
        #         "type": "GoalVectorNet",
        #         "in_channel": 11,
        #         "hidden_channel": 256,
        #         "activation": "leaky_relu",
        #         "relu_max_value": None,
        #         "num_layers": 3,
        #         "dropout": 0.0,
        #         "reduce_mode": "mean",
        #     },
        #     "norm_val": [-50, 150, -50, 50],
        # },
        navi_path_encoder_cfg=dict(
            input_dim=352,
            hidden_dim=256,
            output_dim=256,
            num_layers=3,
            dropout=0.0,
            activation="relu",
            relu_max_value=None,
        ),
        navi_path_reduce_cfg=[
            dict(
                input_dim=200,
                hidden_dim=64,
                output_dim=64,
                num_layers=2,
                dropout=0.0,
                activation="relu",
                relu_max_value=None,
            ),
            dict(
                input_dim=64,
                hidden_dim=32,
                output_dim=32,
                num_layers=2,
                dropout=0.0,
                activation="relu",
                relu_max_value=None,
            ),
        ],
        control_point_encoder_cfg={
            "type": "ControlPointEncoder",
            "pos_norm_val": [-50, 200, -50, 50],
            "vel_max_val": 40,
            "input_size": 8,
            "hidden_size": 256,
        },
        input_sensors=[
            "dynamic_dets",
            "meta",
            "static_dets",
            "dynamic_gods",
            "lane",
            "atlas",
            # "navi_line",
            "navi_path",
            "control_points",
        ],
        norm_value=[200.0, 50.0, 2.0, 3.0, 1.0, 2.0, 1.0],
        dim_model=256,
        num_head=8,
        num_frame=15,
        num_pad_box=num_pad_box,
        dim_feedforward=256,
        relu_max_value=None,
        num_encoder_layers=4,
        dropout=0.0,
        activation="relu",
        attn_hardtanh_val=None,
        normalize_before=False,
        norm=True,
        no_encoder_ffn=False,
        no_encoder_self_att=False,
        use_hpc_nn_ops=False,
        use_tvm_supported_sdpa=not train_mode,
        box_class_dims=7,
    )
    return {"astra_planner_stage2_encoder": astra_planner_stage2_encoder_cfg}


def create_astra_planner_stage2_head(
    train_mode,
    dim_model=256,
    num_head=8,
    num_pad_box=None,
    predict_stride=None,
    ego_k_traj_num=None,
    select_scenes=None,
    scene_modality=None,
    navi_lateral_dist_mask_threshold=None,
    remove_wo_navilane_data=None,
    attn_hardtanh_val=None,
    aug_navi_line_with_navi_path=True,
    close_loop_cfg=None,
    ego_future_frames_num=35,
    predict_stride_traj_class=None,
):
    """Create astra planner decoder."""
    operation_layer = ["full_cross_attn", "norm", "ffn", "norm"]
    stage2_operation_layer = ["full_cross_attn", "norm", "ffn", "norm"]
    operation_order = []
    for layer_num in predict_stride:
        operation_order.extend(operation_layer * layer_num + ["output"])
    operation_order_traj_class = []
    for layer_num in predict_stride_traj_class:
        operation_order_traj_class.extend(stage2_operation_layer * layer_num + ["output"])
    operation_dict = dict(
        self_attn=dict(
            type="StampMultiheadAttention",
            embed_dim=dim_model,
            num_heads=num_head,
            is_encoder=False,
            attn_hardtanh_val=attn_hardtanh_val,
            dropout=0.0,
            use_hpc_nn_ops=False,
            use_tvm_supported_sdpa=not train_mode,
        ),
        full_cross_attn=dict(
            type="PlannerCrossAttention",
            key_list=["ego", "agent", "navi_path", "lane", "control_points"],
            embed_dim=dim_model,
            num_heads=num_head,
            is_encoder=False,
            attn_hardtanh_val=attn_hardtanh_val,
            dropout=0.0,
            use_hpc_nn_ops=False,
            num_query=ego_k_traj_num * scene_modality,
            num_query_agent=6,
            bs_agent=num_pad_box,
            use_tvm_supported_sdpa=not train_mode,
            trace_model_in_loop_flag=close_loop_cfg["trace_model_in_loop_flag"],
        ),
    )
    refine_static_operation_dict = copy.deepcopy(operation_dict)
    refine_static_operation_dict["full_cross_attn"]["key_list"] = ["ego", "lane"]
    refine_dynamic_operation_dict = copy.deepcopy(operation_dict)
    refine_dynamic_operation_dict["full_cross_attn"]["key_list"] = ["ego", "agent"]
    astra_planner_stage2_head_cfg = dict(
        type="AstraPlannerStage2Head",
        ego_future_frames_num=ego_future_frames_num,
        ego_k_traj_num=ego_k_traj_num,
        scene_modality=scene_modality,
        select_scenes=select_scenes,
        navi_lateral_dist_mask_threshold=navi_lateral_dist_mask_threshold,
        remove_wo_navilane_data=remove_wo_navilane_data,
        aug_navi_line_with_navi_path=aug_navi_line_with_navi_path,
        visualize_match_result=False,
        decoder_cfg=dict(
            type="AstraPlannerStage2Decoder",
            trajectory_sample_cfg=dict(
                longtitude=dict(
                    num_sample=10,
                    accelerate_ratio=1.5,
                ),
                latitude=dict(
                    num_sample=12 if train_mode else 18,
                    time_to_converge=2.0,
                    start_time=0.0,
                    max_dis_to_top1=1.8 if train_mode else 0.9,
                ),
            ),
            trajectory_refiner_cfg=dict(
                type=AstraPlannerEgoRefiner,
                train_mode=train_mode,
                ego_future_frames_num=ego_future_frames_num,
                traj_encoder_cfg=dict(
                    type=MLPnorm,
                    input_dim=5,
                    hidden_dim=256,
                    output_dim=256,
                    num_layers=3,
                ),
                static_traj_decoder_cfg=dict(
                    type="TransformerDecoder",
                    dim_model=dim_model,
                    operation_order=operation_order_traj_class,
                    operation_dict=refine_static_operation_dict,
                    dim_feedforward=256,
                    dropout=0.0,
                    return_intermediate=True,
                ),
                dynamic_traj_decoder_cfg=dict(
                    type="TransformerDecoder",
                    dim_model=dim_model,
                    operation_order=operation_order_traj_class,
                    operation_dict=refine_dynamic_operation_dict,
                    dim_feedforward=256,
                    dropout=0.0,
                    return_intermediate=True,
                ),
                traj_head_cfg_dict=dict(
                    agent_collision=dict(
                        type=MLP,
                        input_dim=256,
                        hidden_dim=256,
                        output_dim=1,
                        num_layers=3,
                        dropout=0.0,
                        activation="relu",
                        relu_max_value=None,
                    ),
                    lane_collision=dict(
                        type=MLP,
                        input_dim=256,
                        hidden_dim=256,
                        output_dim=1,
                        num_layers=3,
                        dropout=0.0,
                        activation="relu",
                        relu_max_value=None,
                    ),
                ),
                ego_traj_sample_gt_pred_vis_reshape=False,
            ),
        ),
        reward_post_cfg=dict(collision_thresh=0.5, collision_judge_time=5, collision_num_thresh=5),
    )
    return {
        "astra_planner_stage2_head": astra_planner_stage2_head_cfg,
    }


def create_astra_planner_stage2_loss(
    select_scenes,
    num_pad_box,
    predict_stride,
    ego_k_traj_num,
    scene_modality,
    ego_future_frames_num=35,
    planner_training_mode=None,
):
    """Create astra planner loss."""
    ego_layer_loss_weights = [
        0.8 ** (sum(predict_stride) - layer_id) for layer_id in list(itertools.accumulate(predict_stride))
    ]
    loss_cfg = dict(
        type="AstraPlannerIntegratedLossV2",
        ego_layer_loss_weights=ego_layer_loss_weights,
        agent_layer_loss_weights=None,
        ego_loss_func_cfg=dict(
            # traj_refine_loss_cfg=dict(
            #     type=TrajectoryRefineLoss,
            #     loss_scale=500.0,
            #     num_future_frames=35,
            # ),
            traj_classifer_loss_cfg=dict(
                type=TrajectoryRewardLoss,
                num_future_frames=35,
                reward_funcs_cfg=dict(
                    agent_collision_reward=dict(
                        type=AgentCollisionReward,
                        ignore_collision_afterwards=False,
                    ),
                    lane_collision_reward=dict(
                        type=LaneCollisionReward,
                        ignore_collision_afterwards=False,
                    ),
                    # navi_follow_reward=dict(
                    #     type=NaviFollowReward,
                    # ),
                    # ego_jerk_reward=dict(
                    #     type=EgoJerkReward,
                    # ),
                ),
                loss_scales=dict(
                    agent_collision_reward=10,
                    lane_collision_reward=10,
                ),
            ),
        ),
        agent_loss_func_cfg={},
        loss_scale_cfg={
            "traj_refine_scale": {
                "traj_od_collision_loss": 1.0,
                "traj_lane_collision_loss": 1.0,
            },
        },
    )

    return {
        "astra_planner_stage2": loss_cfg,
    }


def create_astra_planner_stage2_evaluator(
    infer_batch_size,
    ego_k_traj_num,
    scene_modality,
    ego_future_frames_num,
):
    """Create astra planner evaluator."""
    astra_planner_stage2_evaluator_cfg = dict(
        type="AstraPlannerSceneEvaluator",
        enable_task="astra_planner_stage2",
        config={"type": "EvaluationBaseConfig"},
        adapter_cfg=dict(
            ego_num_pred_frames=ego_future_frames_num,
            agent_num_pred_frames=35,
            ego_k_traj_num=ego_k_traj_num,
            k_traj_num=6,
            pred_dim=2,
            num_pad_box=191,
            num_frame=15,
            max_guesses=6,
            scene_modality=scene_modality,
        ),
        eval_common_cfg=dict(
            batch_size=infer_batch_size,
        ),
        dump_image=False,
        draw_keys=[
            "goal_point_ego_traj_pred",
            "ego_traj_pred",
            "ego_traj_pred_all",
            "ego_traj_gt",
            "ego_box",
            "agent_box",
            "atlas",
            "navi_path",
            "laneline",
            "curb",
            "stopline",
            "ego_vel",
            "tld",
            "navi_path_tld",
            "ego_pred_info",
            "control_point",
            "od_prior_gt",
            "od_prior_pred",
        ],
        use_gpu=False,
    )
    return {"astra_planner_stage2": astra_planner_stage2_evaluator_cfg}
