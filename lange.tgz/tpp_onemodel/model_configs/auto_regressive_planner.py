# -*- coding: utf-8 -*-
"""Auto regressive planner model config."""

from tpp_onemodel.evaluator.auto_regressive_planner_evaluator import (
    AutoRegressivePlannerEvaluator,
)


VOCAB_PATH = "/share-global/xiangwei.geng/planner/planner_vocab/0410/ar_action_vocab_5000_512.pkl"
# VOCAB_PATH = "/share-global/mccree.zhao/planning_data/cluster/250514/ar_action_vocab_50000_512_kdisk+faiss.pkl"


def create_auto_regressive_evaluator(
    infer_batch_size,
    ego_k_traj_num,
    scene_modality,
    ego_future_frames_num,
):
    """Create goal point planner evaluator."""
    auto_regressive_evaluator_cfg = dict(
        type=AutoRegressivePlannerEvaluator,
        adapter_cfg=dict(
            ego_num_pred_frames=ego_future_frames_num,
            agent_num_pred_frames=35,
            ego_k_traj_num=ego_k_traj_num,
            k_traj_num=6,
            pred_dim=2,
            num_pad_box=191,
            num_frame=15,
            max_guesses=6,
            scene_modality=scene_modality,
        ),
        dump_image=False,
        draw_keys=[
            # "uturn_ego_traj_pred",
            "ego_traj_gt",
            "ego_traj_pred",
            "ego_box",
            "agent_box",
            "atlas",
            "navi_path",
            "laneline",
            "curb",
            "stopline",
            # "ego_vel",
            "tld",
            # "navi_path_tld",
            "control_point",
            "ar_ego_pos_pred",
            "ar_agents_pos_pred",
            "ar_drive_path_pred",
        ],
        use_gpu=False,
    )
    return {"auto_regressive_planner": auto_regressive_evaluator_cfg}


def create_auto_regressive_planner_loss(close_loop_finetune_mode=False, use_focal=False, use_soft=False):
    """Create goal point planner loss."""
    auto_regressive_planner_loss_cfg = dict(
        type="AutoRegressivePlannerLoss",
        loss_cfg=[
            dict(
                type="AutoRegressiveEgoActionLoss",
                vocab_path=VOCAB_PATH,
                use_focal=use_focal,
                use_soft=use_soft,
                history_num=14,
            ),
            dict(type="AutoRegressiveAgentsActionLoss", history_num=14),
            dict(type="AutoRegressiveDrivePathLoss"),
            dict(
                type="AutoRegressiveEgoFinetuneLoss",
                vocab_path=VOCAB_PATH,
                history_num=14,
                use_focal=use_focal,
                use_soft=use_soft,
            ),
            dict(type="AutoRegressiveAgentsFinetuneLoss", history_num=14),
            dict(type="AutoRegressiveCloseTrainEgoActionLoss", vocab_path=VOCAB_PATH, history_num=14),
            dict(type="AutoRegressiveCloseTrainAgentsActionLoss", history_num=14),
        ],
        loss_weight={
            "ego_action_loss": 1.0,
            "agents_action_loss_x": 10.0,
            "agents_action_loss_y": 10.0,
            "agents_exist_loss": 10.0,
            "drive_path_loss": 1.0,
            "drive_navi_near_lateral_loss": 1.0,
            "ego_action_finetune_loss": 1.0,
            "agents_action_finetune_loss_x": 10.0,
            "agents_action_finetune_loss_y": 10.0,
            "ego_close_train_action_loss": 1.0,
            "agents_ct_action_x_loss": 10.0,
            "agents_ct_action_y_loss": 10.0,
            "agents_ct_exist_loss": 0.0,
            "agents_ct_traj_loss": 1.0,
        },
    )
    return {"auto_regressive_planner": auto_regressive_planner_loss_cfg}


def create_auto_regressive_planner(
    train_mode=True,
    close_loop_mode=False,
    close_loop_finetune_mode=False,
    infer_step_num=25,
    ego_drive_path_num=100,
    ego_future_num=35,
    mask_ego_future_history=True,
    soft_label_sigma=0.01,
    close_perfect_agent=False,
):
    """Create auto regressive planner model."""
    auto_regressive_planner_cfg = dict(
        type="AutoRegressivePlanner",
        train_mode=train_mode,
        close_loop_mode=close_loop_mode,
        close_loop_finetune_mode=close_loop_finetune_mode,
        cat_topk=1,
        infer_step_num=infer_step_num,
        selected_sensor_list=["lane", "navi_path", "current_od", "tld", "control_point"],
        static_scene_tokenizer_cfg=create_static_scene_tokenizer_cfg(train_mode),
        dynamic_state_tokenizer_cfg=create_dynamic_state_tokenizer_cfg(train_mode),
        action_model_cfg=create_action_model_cfg(train_mode, mask_ego_future_history=mask_ego_future_history),
        sampler_cfg=create_auto_regressive_sampler_cfg(),
        close_train_sampler_cfg=create_close_train_sampler_cfg(),
        state_updater_cfg=create_auto_regressive_state_updater_cfg(),
        ar_add_on_module_cfg=create_auto_regressive_add_on_module_cfg(
            ego_future_num=ego_future_num, ego_drive_path_num=ego_drive_path_num, train_mode=train_mode
        ),
        soft_label_sigma=soft_label_sigma,
        close_perfect_agent=close_perfect_agent,
    )
    return {"auto_regressive_planner": auto_regressive_planner_cfg}


def create_auto_regressive_sampler_cfg():
    """Create auto regressive sampler config."""
    sampler_cfg = dict(
        type="AutoRegressiveSampler",
        sample_module_cfg=(
            dict(
                type="ARTopkToppTempSampleModule",
                topk=20,
                topp=1.0,
                temperature=1.0,
                step_sample_num={
                    0: 5,
                },
            )
        ),
        token_decoder_cfg=(
            dict(
                type="ARTokenDecoderAccOmegaMultiStep",
                vocab_path=VOCAB_PATH,
                step=2,
            )
        ),
    )
    return sampler_cfg


def create_close_train_sampler_cfg():
    """Create close train sampler config."""
    close_train_sampler_cfg = dict(
        type="AutoRegressiveSampler",
        sample_module_cfg=(
            dict(
                type="ARCloseLoopTopkToppTempSampleModule",
                # topk=10, # random sample 1 from topk
                topk=1,  # deterministic top1
                topp=1.0,
                temperature=1.0,
            )
        ),
        token_decoder_cfg=(
            dict(
                type="ARTokenDecoderAccOmegaCloseLoop",
                vocab_path=VOCAB_PATH,
                step_num=2,
            )
        ),
    )
    return close_train_sampler_cfg


def create_auto_regressive_state_updater_cfg():
    """Create auto regressive state updater config."""
    state_updater_cfg = dict(
        type="ARStateUpdaterV2",
    )
    return state_updater_cfg


def create_static_scene_tokenizer_cfg(train_mode):
    """Create static scene tokenizer config."""
    static_scene_cfg = dict(
        type="StaticSceneTokenizer",
        static_sensor_tokenizer_cfg=dict(
            type="StaticSensorTokenizer",
            train_mode=train_mode,
            static_sensor_tokenizer_cfg_dict=dict(
                lane=dict(
                    type="StaticLaneTokenizer",
                    embedding_cfg=dict(type="EmbeddingMLP", input_dim=128, embedding_dim=256, train_mode=train_mode),
                    points_attn_cfg=dict(
                        type="StaticSceneCrossAttn", attn_dim=256, num_heads_num=4, train_mode=train_mode
                    ),
                    lane_feat_attn_cfg=dict(
                        type="StaticSceneCrossAttn", attn_dim=256, num_heads_num=4, train_mode=train_mode
                    ),
                    norm_range=[-100, 200, -50, 50],  # [x_min, x_max, y_min, y_max]
                    lane_type_num=3,
                    lane_attr_num=20,
                    type_embed_dim=42,
                    attn_dim=256,
                    points_attn_layer=2,
                    lane_feat_attn_layer=2,
                    lane_feat_num=50,
                    train_mode=train_mode,
                ),
                current_od=dict(
                    type="StaticCurrentODTokenizer",
                    norm_range=[
                        -100,
                        200,
                        -50,
                        50,
                        0,
                        10,
                        0,
                        5,
                        0,
                        5,
                        -40,
                        40,
                    ],  # x min, x max, y min, y max, length min, length max, width min, width max, height min, height max, vmin, vmax
                    embedding_cfg=dict(type="EmbeddingMLP", input_dim=8, embedding_dim=256, train_mode=train_mode),
                    cur_od_feat_num=24,
                    cur_od_feat_dim=256,
                    attn_layer_num=2,
                    attn_layer_cfg=dict(
                        type="StaticSceneCrossAttn", attn_dim=256, num_heads_num=4, train_mode=train_mode
                    ),
                ),
            ),
        ),
        command_tokenizer_cfg=dict(
            type="CommandSensorTokenizer",
            train_mode=train_mode,
            command_sensor_tokenizer_cfg_dict=dict(
                navi_path=dict(
                    type="CommandNaviPathTokenizer",
                    norm_range=[-100, 200, -50, 50],
                    points_attn_cfg=dict(
                        type="StaticSceneCrossAttn", attn_dim=256, num_heads_num=4, train_mode=train_mode
                    ),
                    points_attn_layer=2,
                    input_dim=2,
                    train_mode=train_mode,
                ),
                tld=dict(
                    type="CommandTLDTokenizer",
                    norm_range=[-50, 200, -50, 50],
                    color_num=5,
                    color_embed_dim=10,
                    status_num=5,
                    status_embed_dim=10,
                    input_dim=80,
                    hidden_dim=256,
                    embed_dim=256,
                    train_mode=train_mode,
                ),
                control_point=dict(
                    type="CommandControlPointTokenizer",
                    pos_norm_val=[-50, 200, -50, 50],
                    vel_max_val=40,
                    input_size=8,
                    hidden_size=256,
                    train_mode=train_mode,
                ),
            ),
        ),
        sensor_embedding_dim=256,
        sensor_index_dict=dict(
            lane=0,
            navi_path=1,
            current_od=2,
            tld=3,
            control_point=4,
        ),
        train_mode=train_mode,
    )
    return static_scene_cfg


def create_action_model_cfg(train_mode, mask_ego_future_history=True):
    """Create action model config."""
    action_model_cfg = dict(
        type="AutoRegressiveActionModel",
        action_model_cfg=dict(
            type="ARActionModelV1",
            history_ts_num=14,
            max_ts_num=100,
            t_attn_layer_num=2,
            attn_layer_num=2,
            ego_cross_attn_key_list=["lane", "navi_path", "tld", "control_point"],
            agent_cross_attn_key_list=["lane", "current_od"],
            feat_dim=256,
            mask_ego_future_history=mask_ego_future_history,
            t_attn_block_cfg=dict(
                type="ARActionV1TAttnBlock",
                feat_dim=256,
                attn_ego_agent_cfg=dict(
                    type="ActionModelV1TAttn", feat_dim=256, head_num=8, dropout=0.0, train_mode=train_mode
                ),
                train_mode=train_mode,
            ),
            attn_block_cfg=(
                dict(
                    type="ActionModelV1AttnBlock",
                    feat_dim=256,
                    self_attn_cfg=dict(
                        type="ActionModelV1EgoAgentSelfAttn",
                        feat_dim=256,
                        head_num=8,
                        dropout=0.0,
                        train_mode=train_mode,
                    ),
                    ego_cross_attn_cfg=dict(
                        type="ActionModelV1EgoAgentCrossAttn",
                        feat_dim=256,
                        head_num=8,
                        dropout=0.0,
                        train_mode=train_mode,
                    ),
                    agent_cross_attn_cfg=dict(
                        type="ActionModelV1EgoAgentCrossAttn",
                        feat_dim=256,
                        head_num=8,
                        dropout=0.0,
                        train_mode=train_mode,
                    ),
                    train_mode=train_mode,
                )
            ),
            # ego_action_decode_ffn_cfg=dict(
            #     type="ARDecodeMLP", input_dim=256, hidden_dim=256, output_dim=512, train_mode=train_mode
            # ),
            # agent_action_decode_ffn_cfg=dict(
            #     type="ARDecodeMLP", input_dim=256, hidden_dim=128, output_dim=3, train_mode=train_mode
            # ),
            ego_action_decode_ffn_cfg=dict(
                type="ARDecodeMLP",
                input_dim=256,
                hidden_dim=256,
                output_dim=512,
                train_mode=train_mode,
            ),
            agent_action_decode_ffn_cfg=dict(
                type="ARDecodeMLP",
                input_dim=256,
                hidden_dim=128,
                output_dim=3,
                train_mode=train_mode,
            ),
            train_mode=train_mode,
        ),
        train_mode=train_mode,
    )
    return action_model_cfg


def create_dynamic_state_tokenizer_cfg(train_mode):
    """Create dynamic state tokenizer config."""
    dynamic_tokenizer_cfg = dict(
        type="DynamicStateTokenizer",
        ego_state_tokenizer_cfg=dict(
            type="EgoStateTokenizer",
            norm_range=[-120, 280, -120, 280, -3, 40],  # x min, x max, y min, y max, vel min, vel max
            token_embedding_cfg=dict(type="EmbeddingMLP", input_dim=5, embedding_dim=256, train_mode=train_mode),
            train_mode=train_mode,
        ),
        agent_state_tokenizer_cfg=dict(
            type="AgentStateTokenizer",
            norm_range=[
                -100,
                200,
                -50,
                50,
                0,
                10,
                0,
                5,
                0,
                5,
            ],  # x min, x max, y min, y max, length min, length max, width min, width max, height min, height max
            embedding_cfg=dict(type="EmbeddingMLP", input_dim=5, embedding_dim=256, train_mode=train_mode),
            train_mode=train_mode,
        ),
        train_mode=train_mode,
    )
    return dynamic_tokenizer_cfg


def create_auto_regressive_add_on_module_cfg(
    ego_future_num=35,
    ego_drive_path_num=100,
    train_mode=True,
):
    """Create auto regressive add on module config."""
    ar_add_on_module_cfg = dict(
        type="ARAddOnModule",
        model_cfg_dict=dict(
            drive_path=dict(
                type="ARAddOnDrivePath",
                navi_path_embedding_cfg=dict(
                    type="NaviPathAggregationLayer",
                    train_mode=train_mode,
                    attn_config=dict(type="StaticSceneCrossAttn", attn_dim=256, num_heads_num=4, train_mode=train_mode),
                ),
                # navi_path_embedding_cfg=dict(
                #     type="EmbeddingMLP", input_dim=256, embedding_dim=256, train_mode=train_mode
                # ),
                ego_traj_embedding_cfg=dict(
                    type="EmbeddingMLP", input_dim=ego_future_num * 2, embedding_dim=256, train_mode=train_mode
                ),
                drive_path_embedding_cfg=dict(
                    type="EmbeddingMLP", input_dim=256 * 2, embedding_dim=ego_drive_path_num * 2, train_mode=train_mode
                ),
                norm_range=[-100, 100, -100, 100],
                ego_drive_path_num=ego_drive_path_num,
                num_pred_frames=ego_future_num,
                train_mode=train_mode,
            )
        ),
        train_mode=train_mode,
    )
    return ar_add_on_module_cfg
