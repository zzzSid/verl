# -*- coding: utf-8 -*-
"""Common model config."""
from tpp_onemodel.data.transform.astra_planner_transform import DrivePathGen
from tpp_onemodel.model_configs.auto_regressive_planner import VOCAB_PATH


def create_planner_dataset(
    meta_file,
    task_name,
    all_task_names,
    mode="train",
    trace_mode=False,
    interval=1,
    ego_future_frame_num=35,
    ego_drive_path_points_num=150,
    ego_drive_path_interval=1,
    select_scenes=None,
    scene_tag_to_id=None,
    ego_k_traj_num=None,
    gen_gear=False,
    disable_delta_vel=False,
    cp_min=0,
    cp_max=3,
    prob_0=[1.0, 0.0, 0.0, 0.0],  # 0->2s
    prob_1=[1.0, 0.0, 0.0, 0.0],  # 2s->5s
    prob_2=[1.0, 0.0, 0.0, 0.0],  # 5s->8s
    prob_3=[1.0, 0.0, 0.0, 0.0],  # 8s->12s
    fake_lane_aug=True,
    with_cp_tld_stop_point=False,
):
    """Create planner dataset."""
    planner_dataset_cfg = dict(
        type="AstraPlannerDataset",
        mode=mode,
        meta_file=meta_file,
        scene_tag_to_id=scene_tag_to_id,
        interval=interval,
        task_name=task_name,
        all_task_names=all_task_names,
        history_meta_key=["dynamic_dets", "meta"],
        future_meta_frame_num=60,
        current_meta_key=[
            "dynamic_dets",
            "meta",
            "static_dets",
            "dynamic_gods",
            "manner_lane",
            # "atlas",
            "navi_path",
            "car_pose",
            "agent_prediction",
        ],
        future_meta_key=["meta", "dynamic_dets"],
        transforms=[
            dict(type="Convert2PlannerOldVersionFormat"),
            dict(type="MannerLane2LaneKey"),
            dict(type="LaneRemoveStopline"),
            dict(type="LaneRemoveMarker"),
            dict(
                type="PlannerAlignToRef",
                align=True,
                states=["history", "current", "future"],
                obj_keys=["dynamic_dets", "static_dets", "tld_panels"],
                velocity_transform_keys=["dynamic_dets"],
                yaw_transform_keys=["dynamic_dets", "static_dets"],
            ),
            dict(
                type="PlannerAlignEgoToRef",
                align=False,
                use_future=True,
            ),
            dict(
                type="PlannerShufflePadBox",
                box_key="dynamic_dets",
                num_pad_box=191,
                shuffle=False,
            ),
            dict(
                type="PlannerPadTLD",
                tld_dim=12,
            ),
            dict(
                type="StampGeneratePredLabel",
                box_key="dynamic_dets",
                num_future=ego_future_frame_num,
                mask_odd=False,
            ),
            dict(
                type="StampGenerateEgoPredLabel",
                num_future=ego_future_frame_num,
            ),
            dict(
                type="StampGenerateEgoPredVelLabel",
                num_future=ego_future_frame_num,
            ),
            dict(
                type="StampGenerateEgoPredSteeringWheelLabel",
                num_future=ego_future_frame_num,
            ),
            dict(
                type="StampGenerateEgoPreAccLabel",
                num_future=ego_future_frame_num,
            ),
            dict(
                type="StampGenerateEgoPreYawRateLabel",
                num_future=ego_future_frame_num,
            ),
            dict(
                type="PlannerShufflePadPolyline2DLane",
                padded_length=50,
                padded_num=100,
                shuffle=False,
                fake_lane_aug=fake_lane_aug,
                mode=mode,
            ),
            dict(
                type="PlannerShufflePadPolyline2DAtlas",
                padded_length=30,
                padded_num=50,
                keys_used=("main_ground", "unsafe_area", "foreground"),
                shuffle=False,
            ),
            dict(
                type="PlannerShufflePadPolyline2DSdmap",
                padded_length=30,
                padded_num=50,
                key_used="sdmap_geo",
                shuffle=False,
            ),
            dict(
                type="PlannerGenerateTracklet",
                keys=("dynamic_dets",),
                track_id_idxes=(9,),
            ),
            dict(
                type="PlannerStaticDetsPadBox",
                sod_dim=(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22),
                sod_poly_len=128,
                num_pad_box=128,
            ),
            dict(
                type="PlannerShufflePadPolyline2DNaviLine",
                padded_length=200,
                padded_num=ego_k_traj_num,
                shuffle=False,
                trace_mode=trace_mode,  # align to trace inputs
            ),
            dict(
                type="PlannerShufflePadPolyline2DNaviPath",
                padded_length=30,
                padded_num=1,
                point_intervals=-1,
                shuffle=False,
            ),
            dict(
                type="PlannerShufflePadPolyline2DDynamicGod",
                god_select_dim=(32, 33, 31, 29, 30, 35, 36, 37),
                god_poly_len=16,
                num_pad_box=32,
            ),
            dict(
                type="PlannerGenStaticTransMat",
                static_keys=("road_detection", "atlas", "road_post"),
            ),
            dict(
                type="PlannerGenerateAlignedGT",
                ego_box_feat_dims=(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14),
            ),
            dict(
                type="PlannerEgoDeltaSpeedAug",
                min_v_aug=0.5,
                max_v_aug=0.3,
                train=(mode == "train"),
            ),
            dict(
                type="ControlPointGen",
                cp_type_list=["pos_heading_vel"],
            ),
            dict(
                type="ControlPointAug",
                aug_func=dict(
                    pos_heading_vel=[
                        dict(
                            name="random_sample",
                            cp_min=cp_min,
                            cp_max=cp_max,
                            prob_0=prob_0,  # 0->2s
                            prob_1=prob_1,  # 2s->5s
                            prob_2=prob_2,  # 5s->8s
                            prob_3=prob_3,  # 8s->12s
                        ),
                        dict(name="random_drop_vel", drop_prob=0.5),
                        dict(name="random_drop_heading", drop_prob=0.5),
                        dict(name="random_drop_time", drop_prob=0.5),
                        dict(name="add_onehot_type", cp_type_idx=1, cp_type_num=2),
                        dict(name="padding", length_pad=cp_max, dim_pad=8, default_val=-1.0),
                    ],
                ),
                train=(mode == "train"),
            ),
            dict(
                type=DrivePathGen,
                num_points=ego_drive_path_points_num,
                interval=ego_drive_path_interval,
            ),
            dict(
                type="PlannerAlignAgentPrediction",
            ),
            dict(
                type="GetTrackableAgentPrediction",
                use_logical_rule=True,
                selected_agent_dis_thres=1000,
            ),
            dict(type="ODPriorMaskGen"),
        ],
        window=list(range(-14, ego_future_frame_num + 1)),  # 36 = future + current
        load_tags=True,
        clip_padding_length=30,
        tld_data_aug=(mode == "train"),
        select_scenes=select_scenes,
        zero_shot_aug_enable=False,
        zero_shot_aug_state=None,
    )
    if with_cp_tld_stop_point:
        idx_control_point_gen = [
            i
            for i in range(len(planner_dataset_cfg["transforms"]))
            if planner_dataset_cfg["transforms"][i]["type"] == "ControlPointGen"
        ][0]

        idx_control_point_aug = [
            i
            for i in range(len(planner_dataset_cfg["transforms"]))
            if planner_dataset_cfg["transforms"][i]["type"] == "ControlPointAug"
        ][0]

        planner_dataset_cfg["transforms"][idx_control_point_gen]["cp_type_list"].append("tld_stop_point")
        planner_dataset_cfg["transforms"][idx_control_point_aug]["aug_func"].update(
            tld_stop_point=[
                dict(name="default_time"),
                dict(name="add_onehot_type", cp_type_idx=1, cp_type_num=2),
                dict(name="padding", length_pad=1, dim_pad=8, default_val=-1.0),
            ]
        )

    if planner_dataset_cfg["mode"] == "train":
        planner_dataset_cfg["transforms"].append(
            dict(
                type="StampTLDDataAug",
                ego_future_frame_num=ego_future_frame_num,
                dis_to_stopline=[25, 50],
            )
        )
    if gen_gear:
        planner_dataset_cfg["transforms"].append(
            dict(
                type="EgoGearGen",
                clamp_gt_by_gear_shift_point=True,
            )
        )
    planner_dataset_cfg["transforms"].append(
        dict(
            type="PlannerEgoFutureTruncate",
            ego_future_frame_num=ego_future_frame_num,
        ),
    )
    return {task_name: planner_dataset_cfg}


def create_planner_infer_dataset(
    meta_file,
    task_name,
    all_task_names,
    mode="test",
    trace_mode=False,
    interval=1,
    ego_future_frame_num=35,
    ego_drive_path_points_num=150,
    ego_drive_path_interval=1,
    select_scenes=None,
    scene_tag_to_id=None,
    ego_k_traj_num=None,
    gen_gear=False,
    cp_min=0,
    cp_max=3,
    prob_0=[1.0, 0.0, 0.0, 0.0],  # 0->2s
    prob_1=[1.0, 0.0, 0.0, 0.0],  # 2s->5s
    prob_2=[1.0, 0.0, 0.0, 0.0],  # 5s->8s
    prob_3=[1.0, 0.0, 0.0, 0.0],  # 8s->12s
    with_cp_tld_stop_point=False,
):
    """Create planner dataset."""
    cfg = create_planner_dataset(
        meta_file=meta_file,
        task_name=task_name,
        all_task_names=all_task_names,
        mode=mode,
        trace_mode=trace_mode,
        interval=interval,
        ego_future_frame_num=ego_future_frame_num,
        ego_drive_path_points_num=ego_drive_path_points_num,
        ego_drive_path_interval=ego_drive_path_interval,
        select_scenes=select_scenes,
        scene_tag_to_id=scene_tag_to_id,
        ego_k_traj_num=ego_k_traj_num,
        cp_min=cp_min,
        cp_max=cp_max,
        prob_0=prob_0,  # 0->2s
        prob_1=prob_1,  # 2s->5s
        prob_2=prob_2,  # 5s->8s
        prob_3=prob_3,  # 8s->12s
        gen_gear=gen_gear,
        with_cp_tld_stop_point=with_cp_tld_stop_point,
    )
    for idx in range(len(cfg[task_name]["transforms"])):
        if cfg[task_name]["transforms"][idx]["type"] == "ControlPointAug":
            cfg[task_name]["transforms"][idx]["aug_func"]["pos_heading_vel"].append(
                dict(name="batch_repeat", repeat_num=10),
            )
            if with_cp_tld_stop_point:
                cfg[task_name]["transforms"][idx]["aug_func"]["tld_stop_point"].append(
                    dict(name="batch_repeat", repeat_num=10),
                )

    return cfg


def create_astra_planner_dataset(meta_file, **kwargs):
    """Create astra planner dataset."""
    cfg = create_planner_dataset(meta_file=meta_file, task_name="astra_planner", **kwargs)
    cfg["astra_planner"]["load_wb"] = True
    cfg["astra_planner"]["wb_version"] = "agent_v1-Data_V13_0207"
    cfg["astra_planner"]["transforms"].append(
        dict(
            type="ODPriorFormat",
        )
    )

    return cfg


def create_auto_regressive_planner_dataset(meta_file, soft_label_sigma=0.01, **kwargs):
    """Create auto regressive planner dataset."""
    cfg = create_planner_dataset(meta_file=meta_file, task_name="auto_regressive_planner", **kwargs)
    cfg["auto_regressive_planner"]["transforms"].append(
        dict(
            type="EgoStateTransform",
        )
    )
    cfg["auto_regressive_planner"]["transforms"].append(
        dict(
            type="EgoActionTransform",
            kmeans_path=VOCAB_PATH,
            soft_label_sigma=soft_label_sigma,
        )
    )
    cfg["auto_regressive_planner"]["transforms"].insert(0, dict(type="SaveDynamicDets4AR"))
    cfg["auto_regressive_planner"]["transforms"].append(
        dict(
            type="AgentsStateTransform",
            dis_keep_num=64,
        )
    )
    cfg["auto_regressive_planner"]["transforms"].append(
        dict(
            type="AgentsActionTransform",
        )
    )
    return cfg


def create_auto_regressive_planner_infer_dataset(meta_file, soft_label_sigma=0.01, **kwargs):
    """Create auto regressive planner dataset."""
    cfg = create_planner_infer_dataset(meta_file=meta_file, task_name="auto_regressive_planner", **kwargs)
    cfg["auto_regressive_planner"]["transforms"].append(
        dict(
            type="EgoStateTransform",
        )
    )
    cfg["auto_regressive_planner"]["transforms"].append(
        dict(
            type="EgoActionTransform",
            kmeans_path=VOCAB_PATH,
            soft_label_sigma=soft_label_sigma,
        )
    )
    cfg["auto_regressive_planner"]["transforms"].insert(0, dict(type="SaveDynamicDets4AR"))
    cfg["auto_regressive_planner"]["transforms"].append(
        dict(
            type="AgentsStateTransform",
            dis_keep_num=64,
        )
    )
    cfg["auto_regressive_planner"]["transforms"].append(
        dict(
            type="AgentsActionTransform",
        )
    )

    return cfg


def create_astra_planner_infer_dataset(meta_file, **kwargs):
    """Create astra planner infer dataset."""
    cfg = create_planner_infer_dataset(meta_file=meta_file, task_name="astra_planner", **kwargs)
    cfg["astra_planner"]["load_wb"] = True
    cfg["astra_planner"]["wb_version"] = "agent_v1-Data_V13_0207"
    cfg["astra_planner"]["transforms"].append(
        dict(
            type="ODPriorFormat",
        )
    )
    return cfg


def create_goal_point_planner_dataset(meta_file, **kwargs):
    """Create goal point planner dataset."""
    return create_planner_dataset(meta_file=meta_file, task_name="goal_point_planner", **kwargs)


def create_goal_point_planner_infer_dataset(meta_file, **kwargs):
    """Create goal point planner infer dataset."""
    return create_planner_infer_dataset(meta_file=meta_file, task_name="goal_point_planner", **kwargs)


def create_uturn_planner_dataset(meta_file, **kwargs):
    """Create goal point planner dataset."""
    return create_planner_dataset(meta_file=meta_file, task_name="uturn_planner", **kwargs)


def create_uturn_planner_infer_dataset(meta_file, **kwargs):
    """Create goal point planner infer dataset."""
    return create_planner_infer_dataset(meta_file=meta_file, task_name="uturn_planner", **kwargs)


def create_prediction_dataset(meta_file, **kwargs):
    """Create prediction dataset."""
    cfg = create_planner_dataset(meta_file=meta_file, task_name="prediction", **kwargs)
    cfg["prediction"]["load_wb"] = True
    cfg["prediction"]["wb_version"] = "agent_v1-Data_V13_0207"
    cfg["prediction"]["transforms"].append(
        dict(
            type="ODPriorFormat",
        )
    )

    return cfg


def create_prediction_infer_dataset(meta_file, **kwargs):
    """Create prediction infer dataset."""
    cfg = create_planner_infer_dataset(meta_file=meta_file, task_name="prediction", **kwargs)
    cfg["prediction"]["load_wb"] = True
    cfg["prediction"]["wb_version"] = "agent_v1-Data_V13_0207"
    cfg["prediction"]["transforms"].append(
        dict(
            type="ODPriorFormat",
        )
    )
    return cfg
