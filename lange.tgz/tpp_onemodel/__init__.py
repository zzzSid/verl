# -*- coding: utf-8 -*-
"""Torchpilot Plus OneModel."""
from torchpilot.utils.file_manager import FileManager
from torchpilot.utils.log_manager import log_file_init
from torchpilot.utils.log_manager import log_init


log_init(__name__)
if FileManager.initialized:
    log_file_init(__name__)
