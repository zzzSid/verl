# -*- coding: utf-8 -*-
"""Box utilities."""
import numpy as np


def compute_ious(gts: np.ndarray, pds: np.ndarray) -> np.ndarray:
    """Compute the ious.

    Args:
      gts (np.array): the numpy array for gts.
      pds (np.array): the numpy array for pds.

    Returns:
      ious of gts and pds.
    """
    if isinstance(gts, (list, tuple)):
        gts = np.array(gts)
    if isinstance(pds, (list, tuple)):
        pds = np.array(pds)

    gts_x1 = gts[..., 0]
    gts_y1 = gts[..., 1]
    gts_x2 = gts[..., 2]
    gts_y2 = gts[..., 3]

    pds_x1 = pds[..., 0]
    pds_y1 = pds[..., 1]
    pds_x2 = pds[..., 2]
    pds_y2 = pds[..., 3]

    min_x2 = np.minimum(gts_x2[:, None], pds_x2[None])
    max_x1 = np.maximum(gts_x1[:, None], pds_x1[None])

    min_y2 = np.minimum(gts_y2[:, None], pds_y2[None])
    max_y1 = np.maximum(gts_y1[:, None], pds_y1[None])

    widths = np.maximum(min_x2 - max_x1, 0)
    heights = np.maximum(min_y2 - max_y1, 0)

    intersections = widths * heights
    gts_areas = (gts_x2 - gts_x1) * (gts_y2 - gts_y1)
    pds_areas = (pds_x2 - pds_x1) * (pds_y2 - pds_y1)
    unions = gts_areas[:, None] + pds_areas[None] - intersections

    ious = intersections / unions
    return ious
