# -*- coding: utf-8 -*-
""" Define the basic configs for detector. """

# pylint: skip-file.

import types
from copy import deepcopy


class BaseConfig(dict):
    """The `BaseConfig` is modified from the `EasyDict`."""

    # pylint: disable=super-init-not-called
    def __init__(self, d=None, **kwargs):
        if d is None:
            d = {}
        if kwargs:
            d.update(**kwargs)
        for k, v in d.items():
            setattr(self, k, v)

        # Class attributes
        for k, v in self.__class__.__dict__.items():
            if (
                not (k.startswith("__") and k.endswith("__"))
                and k not in ("update", "pop")
                and not isinstance(v, (property, types.FunctionType))
            ):

                setattr(self, k, getattr(self, k))

    def __setattr__(self, name, value):
        # copy the value, or if the user create two same configs, there will be
        # cross-reference between two objects.
        value = deepcopy(value)
        if isinstance(value, (list, tuple)):
            value = [BaseConfig(x) if isinstance(x, dict) else x for x in value]
        elif isinstance(value, dict) and not isinstance(value, BaseConfig):
            value = BaseConfig(value)

        super().__setattr__(name, value)
        super().__setitem__(name, value)

    __setitem__ = __setattr__

    def update(self, e=None, **f):
        d = e or dict()
        d.update(f)
        for k in d:
            setattr(self, k, d[k])

    def pop(self, k, d=None):
        delattr(self, k)
        return super().pop(k, d)


class AnchorConfig(BaseConfig):
    """The anchor configuration."""

    # size for each edge of anchor.
    sizes = (32, 64, 128, 256, 512)
    # height / width of anchors.
    aspect_ratios = (0.5, 1.0, 2.0)
    # strides for feature map.
    strides = 16


class OverlapConfig(BaseConfig):
    """The config for objects overlap, e.g. bbox_iou."""

    # the type of overlap
    # the iou_type
    iou_type = "iou"
    # the pair type
    pair_type = "cartesian"


class MatcherConfig(BaseConfig):
    """The config for matcher."""

    # the type of matcher
    # the positive threshold
    positive_thresh = 0.7
    # the negative threshold
    negative_thresh = 0.3
    # low quality matching
    low_quality_match = True
    # the low quality matching threshold
    low_quality_thresh = None
    # in atss matcher, it is used to select the top anchors to compute the
    # adaptive iou threshold.
    num_cloest_anchors = 9


class SamplerConfig(BaseConfig):
    """The configuration for sampler."""

    # the type of sampler.
    # number of objects to sample.
    num_samples = 256
    # positive fraction of samples.
    positive_fraction = 0.5


class CoderConfig(BaseConfig):
    """The configuration for coder."""

    # the type of coder
    # the weights for bbox
    weights = (1.0, 1.0, 1.0, 1.0)
    # the max wh ratio
    max_wh_ratio = 16.0 / 1000.0


class AssignerConfig(BaseConfig):
    """The config for assigner."""

    # The type of assigner
    # the objectness of assigner
    objectness = True
    # whether use the gt as proposals, only valid when assigner == 'roi'
    use_gt = True
    # whether within the sampled and matched gt_indices.
    with_gt_indices = False


class NMSConfig(BaseConfig):
    """The configuration for nms."""

    # the type of nms
    # the threshold for nms
    thresh = 0.7
    # the parallel number of nms reduce kernel
    nms_parallel_reduce = 1


class PredictorConfig(BaseConfig):
    """The configuration for predictor."""

    # the type of predictor.
    # the maximum number of boxes per_image
    num_per_image = 100
    # the maximum number of boxes per_class
    num_per_class = 1000
    # the threshold for score
    score_thresh = 0.0
    # whether clip the boxes into the area of image.
    clip_box = True
    # the minimum size of boxes. if a box is smaller than min_size, filter it out.
    min_size = 0.0
    # whether use the tf.RaggedTensor to wrap the outputs.
    use_ragged_tensor = False
    # the class offset for the classification prediction.
    class_offset = 1
    # the key for other_preds, used in MultiBranchROIPredictor
    key_for_other_preds = None
    # run nms among classes or not
    inter_class_nms = False


# The composite configs
class RPNAssignerConfig(BaseConfig):
    """The composite config for rpn_assigner."""

    # the overlap config
    overlap = OverlapConfig()
    # the matcher config
    matcher = MatcherConfig()
    # the sampler config
    sampler = SamplerConfig()
    # the coder config
    coder = CoderConfig()
    # the assigner config
    assigner = AssignerConfig()


class RetinaAssignerConfig(BaseConfig):
    """The composite config for retina_assigner."""

    # the overlap config
    overlap = OverlapConfig()
    # the matcher config
    matcher = MatcherConfig()
    matcher.positive_thresh = 0.5
    matcher.negative_thresh = 0.4
    # the sampler config
    sampler = SamplerConfig()
    # the coder config
    coder = CoderConfig()
    # the assigner config
    assigner = AssignerConfig()
    assigner.objectness = False


class RCNNAssignerConfig(BaseConfig):
    """The composite config for rcnn_assigner."""

    # the overlap config
    overlap = OverlapConfig()
    # the matcher config
    matcher = MatcherConfig()
    matcher.positive_thresh = 0.5
    matcher.negative_thresh = 0.5
    matcher.low_quality_match = False

    # the sampler config
    sampler = SamplerConfig()
    sampler.num_samples = 512
    sampler.positive_fraction = 0.25

    # the coder config
    coder = CoderConfig()
    coder.weights = (10.0, 10.0, 5.0, 5.0)

    # the assigner config
    assigner = AssignerConfig()
    assigner.objectness = False


class ProposalGeneratorConfig(BaseConfig):
    """The composite config for proposal_generator."""

    # name of ProposalGenrator, default is tf
    # the coder for proposal_generator.
    coder = CoderConfig()
    # the nms for proposal_generator.
    nms = NMSConfig()
    # the maximum instance count before nms, for each pyramid during training.
    # train_prev_topk = 2500
    train_prev_topk = 12000
    # the maximum instance count after nms, for each pyramid during training.
    # train_post_topk = 512
    train_post_topk = 2000
    # the maximum instance count before nms, for each pyramid during testing.
    test_prev_topk = 6000
    # the maximum instance count after nms, for each pyramid during testing.
    test_post_topk = 1000
    # whether clip the boxes into the area of image.
    clip_box = True
    # the minimum size of boxes. if a box is smaller than min_size, filter it out.
    min_size = 0.0
    # the minimum score of boxes.
    score_thresh = 0.01


class ROIPredictorConfig(BaseConfig):
    """configuration to create the roi predictor."""

    # the coder
    coder = CoderConfig()
    coder.weights = (10.0, 10.0, 5.0, 5.0)
    # the nms
    nms = NMSConfig()
    nms.thresh = 0.5
    # the predictor config
    predictor = PredictorConfig()


class DensePredictorConfig(BaseConfig):
    """configuration to create the dense predictor."""

    # the coder
    coder = CoderConfig()
    # the nms
    nms = NMSConfig()
    nms.thresh = 0.5
    # the predictor config
    predictor = PredictorConfig()
    # setup the score_thresh for dense predictor to 0.05, or there are too many
    # bboxes.
    predictor.score_thresh = 0.05


class KPTSPredictorConfig(BaseConfig):
    """The configuration for predictor."""

    # the type of predictor output, support 'kpts' or 'kpts_unify'.
    kpts_name = "kpts"
    # pooling size then predictor, size = x * 6 + 3;
    # Detail: tensorpilot/models/keypoints/gts/heatmap_generator.py
    test_nms_kernel = 3

    # score threshold of keypoints. Valid in save phase.
    score_thresh = 0.01

    # results number of points for each class. Valid in non-save phase.
    max_num_points = 100

    # upsample ratio for prediction
    upsample_ratio = 1

    # pad the images into mutiple of this value.
    size_divisor = 32

    kpt_heatmap_downsample = 8
