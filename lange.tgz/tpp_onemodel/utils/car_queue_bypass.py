from typing import Dict, Tuple, List, Any, Optional
from collections import defaultdict
from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import get_map_cls_to_3cls
from tpp_onemodel.utils.reward_utils import determine_path_turn_type, determine_path_turn_end_ts_type
from tpp_onemodel.utils.reward_utils import Turntype, judge_intersection_and_maneuver
import numpy as np


class CarQueueBypassDetector:
    """
    死车绕行识别器（Stopped Vehicle Overtake Detector）。

    目标：用 ego 轨迹 + agent 轨迹，识别“绕行死车”的 episode：
        ego 在死车后方排队 / 等待 -> 横向绕过去 -> 超到死车前方。

    关键约束：
        1. 只在 ego 直行段上做识别：
           - 通过 yaw_rate 判断自车是否直行；
           - 自车非直行（例如左/右转、掉头）时不做“前方死车绕行”的判定。
        2. 死车定义：
           - 出现时间至少 min_track_duration 秒；
           - 从首次出现到整个轨迹结束，其空间位移最大值不超过
             stopped_displacement_thresh（米）；
           - 速度中位数不高于 stopped_speed_thresh；
           => 只把“出现后基本不挪窝的车/VRU”视为死车候选。

    输入数据约定：
        - ego_traj[T,3] : ego 的 GT 轨迹 (x, y, yaw)
        - ego_length, ego_width : ego 尺寸（当前未直接用，可用于后续调阈值）
        - agent_dict : Dict[int, (ids, states)]
            * key: t_idx (0..T-1，对齐 ego 时间步)
            * value:
                ids:    np.ndarray[N]            -> agent_id 列表（车辆、VRU 都算 agent）
                states: np.ndarray[N,5]          -> (x, y, yaw, length, width)
        - timestamps[T] : 每个 t_idx 对应的时间戳（秒）

    输出：
        - overtake_flags[T] : bool
              每个时刻是否处于“死车绕行”过程之中
        - target_agent_ids[T] : int
              若处于死车绕行，则为被绕行的死车 agent_id；否则为 -1
        - episodes : List[dict]
              每个 episode 对应一次死车绕行：
              {
                  "agent_id": int,
                  "start_idx": int,          # 全局时间索引，包含 start_idx
                  "end_idx": int,            # 全局时间索引，包含 end_idx
                  "start_time": float,       # 对应 timestamps[start_idx]
                  "end_time": float,         # 对应 timestamps[end_idx]
                  "min_longitudinal_gap": float,   # 绕行过程中的最小纵向距离 (沿 ego heading)
                  "min_lateral_offset": float,     # 绕行过程中的最小横向偏移 (abs)
                  "max_lateral_offset": float,     # 绕行过程中的最大横向偏移 (abs)
              }
    """

    def __init__(
        self,
        *,
        # 死车判断相关参数
        stopped_displacement_thresh: float = 5.0,
        #  ↑ 从首次出现到整个轨迹结束，空间位移不超过该距离（米），视为“几乎没动”
        stopped_speed_thresh: float = 4.0,
        #  ↑ 速度的辅助阈值，用于排除明显在路上跑的对象
        min_track_duration: float = 2.0,      # agent 轨迹至少存在这么久（秒）才考虑为死车候选

        # 相对几何模式参数（绕行模式识别）
        approach_min_gap: float = 5.0,        # 接近死车时，纵向距离下限 (m)
        approach_max_gap: float = 30.0,       # 接近死车时，纵向距离上限 (m)
        lane_center_thresh: float = 1.0,      # 认为“在死车后方同车道中间”的横向偏移阈值 (m)
        lateral_overtake_offset: float = 1.5, # 认为“已经绕到旁边”的横向偏移阈值 (m)
        pass_ahead_gap: float = 2.0,          # 认为“已经明显超到前方”的领先距离 (m) 5m 默认

        # 时间约束（可选）
        max_overtake_duration: Optional[float] = 40.0,  # 单次绕行最长持续时间 (秒)，None 表示不限制

        # 直行判断参数
        yaw_rate_straight_thresh_deg: float = 5.0,  # |yaw_rate| 小于该阈值时认为直行（度/秒）
    ) -> None:
        # 死车定义参数
        self.stopped_displacement_thresh = stopped_displacement_thresh
        self.stopped_speed_thresh = stopped_speed_thresh
        self.min_track_duration = min_track_duration

        # 几何模式参数
        self.approach_min_gap = approach_min_gap
        self.approach_max_gap = approach_max_gap
        self.lane_center_thresh = lane_center_thresh
        self.lateral_overtake_offset = lateral_overtake_offset
        self.pass_ahead_gap = pass_ahead_gap

        # 时间约束
        self.max_overtake_duration = max_overtake_duration

        # 直行判断：yaw_rate 阈值（弧度/秒）
        self.yaw_rate_straight_thresh = np.deg2rad(yaw_rate_straight_thresh_deg)

    # ===================== 对外主接口 =====================

    def detect(
        self,
        ego_traj: np.ndarray,
        agent_dict: Dict[int, Tuple[np.ndarray, np.ndarray]],
        is_before_junction_array: np.ndarray,
        lane_centerlines: Dict[int, List[np.ndarray]],
        navi_centerlines: Dict[int, List[Tuple[np.ndarray, int]]],
        road_edges: Dict[int, List[Tuple[np.ndarray, int]]],
        solid_lanes: Dict[int, List[np.ndarray]],
        timestamps: np.ndarray,
    ) -> Tuple[np.ndarray, np.ndarray, List[Dict[str, Any]]]:
        """
        识别整条轨迹中的“死车绕行”时刻和 episode。
        """
        T = ego_traj.shape[0]
        assert ego_traj.shape[1] == 3
        assert timestamps.shape[0] == T

        ego_xy = ego_traj[:, :2]
        ego_yaw = ego_traj[:, 2]

        ego_speeds = self._compute_speeds_xy(ego_xy, timestamps)
        ego_yaw_rate = self._compute_yaw_rate(ego_yaw, timestamps)
        ego_is_straight = np.abs(ego_yaw_rate) < self.yaw_rate_straight_thresh

        # 1) 构建每个 agent 的轨迹和速度
        agent_tracks = self._build_agent_tracks(agent_dict, timestamps)
        turn_start_ts, turn_end_ts = self._get_turn_ts(ego_traj, ego_is_straight)

        # 3) 针对每个“死车候选”单独跑绕行模式识别（只在直行段上）
        episodes: List[Dict[str, Any]] = []
        dead_agents_dict = dict()

        for aid, info in agent_tracks.items():
            t_indices = info["t_idx"]
            if t_indices.size < 2:
                continue
            # 只看车，不看vru
            if info.get('type',None) in ['bicycle','pedestrian']:
                continue
            ts_agent = timestamps[t_indices]
            duration = float(ts_agent[-1] - ts_agent[0])
            # 出现时间太短，不认为是“死车”
            if duration < self.min_track_duration:
                continue

            xy_agent = info["xy"]
            yaw_agent = info["yaw"]

            # 计算该死车在每个 t_indices 时刻相对于 ego 的 s(t)/d(t)
            # 向量化计算：一次性取出 ego 的位置与偏航，批量计算 rel, s, d
            M = t_indices.shape[0]
            if M == 0:
                continue

            ego_xy_sel = ego_xy[t_indices]            # (M,2)
            ego_yaw_sel = ego_yaw[t_indices]          # (M,)
            headings = np.column_stack((np.cos(ego_yaw_sel), np.sin(ego_yaw_sel)))  # (M,2)

            # agent xy/yaw arrays
            xy_agent_arr = np.asarray(xy_agent, dtype=float)  # (M,2)
            yaw_agent_arr = np.asarray(yaw_agent, dtype=float)  # (M,)

            rel = xy_agent_arr - ego_xy_sel  # (M,2)
            s_arr = np.sum(rel * headings, axis=1).astype(float)
            d_arr = (headings[:, 0] * rel[:, 1] - headings[:, 1] * rel[:, 0]).astype(float)
            v_ego_arr = ego_speeds[t_indices].astype(float)

            # agent_xyyaw_list 保留为列表供后续使用
            agent_xyyaw_list = [(float(x), float(y), float(yaw)) for (x, y), yaw in zip(xy_agent_arr, yaw_agent_arr)]

            # 找到每个 agent 离的最近的车道线编号和距离（保留原逻辑，逐时刻调用）
            agent_lane_dist = []
            agent_lane_idxs = []
            for j, t_idx in enumerate(t_indices):
                ax, ay, a_yaw = agent_xyyaw_list[j]
                t = int(t_idx)
                y_center = None
                line_idx = None
                if t in navi_centerlines and navi_centerlines[t]:
                    lines = [cl for (cl, _) in navi_centerlines[t]]
                    y_center, line_idx = self._estimate_ego_lane_center_offset((ax, ay, a_yaw), lines)
                elif t in lane_centerlines and lane_centerlines[t]:
                    y_center, line_idx = self._estimate_ego_lane_center_offset((ax, ay, a_yaw), lane_centerlines[t])
                if y_center is not None and line_idx is not None:
                    if abs(y_center) > 3:
                        y_center = None
                        line_idx = None
                agent_lane_dist.append(y_center)
                agent_lane_idxs.append(line_idx)

            dead_timing_list = self._get_dead_timing_list(info, t_indices, turn_start_ts, turn_end_ts, sd_ego_speed = None)
            total_dead_timing = []
            for dead_timing in dead_timing_list:
                total_dead_timing.extend(dead_timing)
            # 将待选死车记录在dead_agents_dict里
            if len(dead_timing_list):
                dead_agents_dict[aid] = dict()
                dead_agents_dict[aid]['ts_agent']= ts_agent
                dead_agents_dict[aid]['t_indices'] = t_indices
                dead_agents_dict[aid]['s_arr'] = s_arr
                dead_agents_dict[aid]['d_arr'] = d_arr
                dead_agents_dict[aid]['v_ego_arr'] = v_ego_arr
                dead_agents_dict[aid]['dead_timing_list'] = dead_timing_list
                dead_agents_dict[aid]['agent_lane_dist'] = agent_lane_dist
                dead_agents_dict[aid]['agent_lane_idxs'] = agent_lane_idxs
                dead_agents_dict[aid]['total_dead_timing'] = total_dead_timing
                dead_agents_dict[aid]['agent_xyyaw_list'] = agent_xyyaw_list
                dead_agents_dict[aid]['speed'] = info['speed']

        # 判断是否有前前车，若有，则打标签
        dead_agents_dict = self._get_dead_agents_front_car(dead_agents_dict)

        # 动转静或者静止期间，该车前方是否还存在车辆
        aids = dead_agents_dict.keys()
        for aid in aids:
            # if aid == 27:
            #     print()
            aid_t_indices = dead_agents_dict[aid]['t_indices']
            aid_ts_agent = dead_agents_dict[aid]['ts_agent']
            aid_s_arr = dead_agents_dict[aid]['s_arr']
            aid_d_arr = dead_agents_dict[aid]['d_arr']
            aid_v_ego_arr = dead_agents_dict[aid]['v_ego_arr']
            aid_dead_timing_list = dead_agents_dict[aid]['dead_timing_list']
            # 关键, 是否存在前车标志位
            aid_is_front_car_exist = dead_agents_dict[aid]['is_front_car_exist']

            if len(aid_dead_timing_list):
                episode_local_list = self._detect_overtake_pattern_for_stopped_agent_with_timing_and_front_car(
                    agent_id=aid,
                    t_indices=aid_t_indices,
                    timestamps_agent=aid_ts_agent,
                    s_arr=aid_s_arr,
                    d_arr=aid_d_arr,
                    v_ego_arr=aid_v_ego_arr,
                    ego_is_straight=ego_is_straight,
                    is_before_junction_array=is_before_junction_array,
                    timing_list = aid_dead_timing_list,
                    is_front_car_exist = aid_is_front_car_exist,
                )
                if len(episode_local_list):
                    episodes.extend(episode_local_list)

        # 4) 将 episode 映射回全局时间轴，生成 per-timestep 标记
        overtake_flags = np.zeros(T, dtype=bool)

        for ep in episodes:
            aid = ep["agent_id"]
            start_idx = ep["start_idx"]
            end_idx = ep["end_idx"]
            for t_idx in range(start_idx, end_idx + 1):
                overtake_flags[t_idx] = True

        return overtake_flags, episodes

    def _get_dead_agents_front_car(self, dead_agents_dict):
        """
        计算每个死车所占车道的车离它本身的距离，若它的前方车道存在车辆，则认为是排队车，这时给予排队车属性标签
        """
        # 更进一步：按 (t_idx, lane_idx) 分组，并把每组转换为 NumPy 数组，以便向量化计算 s
        tmp = defaultdict(list)
        for aid, info in dead_agents_dict.items():
            t_indices = info['t_indices']
            agent_lane_idxs = info['agent_lane_idxs']
            agent_xyyaw_list = info['agent_xyyaw_list']
            for j, t_idx in enumerate(t_indices):
                lane_idx = agent_lane_idxs[j]
                if lane_idx is None:
                    continue
                ax, ay, ayaw = agent_xyyaw_list[j]
                tmp[(int(t_idx), int(lane_idx))].append((int(aid), float(ax), float(ay)))

        # 将 tmp 中的列表转换为便于向量化的结构： (aids_np, xs_np, ys_np)
        time_lane_to_arrays = {}
        for key, lst in tmp.items():
            arr = np.array(lst, dtype=float)  # shape (N,3) but aids are floats; we'll cast aids to int separately
            if arr.size == 0:
                continue
            aids_np = arr[:, 0].astype(int)
            xs_np = arr[:, 1]
            ys_np = arr[:, 2]
            time_lane_to_arrays[key] = (aids_np, xs_np, ys_np)

        # 对每个 dead agent，在对应时间点只检查同一时间点/车道上的车辆（向量化）
        for aid, info in dead_agents_dict.items():
            t_indices = info['t_indices']
            agent_lane_idxs = info['agent_lane_idxs']
            agent_xyyaw_list = info['agent_xyyaw_list']
            total_dead_timing = info['total_dead_timing']
            is_front_car_exist = np.zeros(len(total_dead_timing))

            for i, dead_timing in enumerate(total_dead_timing):
                t_idx = int(t_indices[dead_timing])
                agent_lane_id = agent_lane_idxs[dead_timing]
                if agent_lane_id is None:
                    continue

                key = (t_idx, int(agent_lane_id))
                if key not in time_lane_to_arrays:
                    continue

                aids_np, xs_np, ys_np = time_lane_to_arrays[key]
                aid_x, aid_y, aid_yaw = agent_xyyaw_list[dead_timing]
                heading_x = float(np.cos(aid_yaw))
                heading_y = float(np.sin(aid_yaw))

                rel_x = xs_np - float(aid_x)
                rel_y = ys_np - float(aid_y)
                s_vec = rel_x * heading_x + rel_y * heading_y

                # 排除自身并检测是否存在 0 < s < 15 的其它车辆
                mask = (s_vec > 0.0) & (s_vec < 15.0) & (aids_np != int(aid))
                if np.any(mask):
                    is_front_car_exist[i] = True

            dead_agents_dict[aid]['is_front_car_exist'] = is_front_car_exist
        return dead_agents_dict


    # 获取到每车道中心线最近的车辆
    def _estimate_ego_lane_center_offset(
        self,
        ego_state: np.ndarray,
        lines: List[np.ndarray],
    ) -> Optional[float]:
        ex, ey, eyaw = ego_state
        best_y_rel = None
        best_dist2 = None
        best_dix = None

        cy = np.cos(-eyaw)
        sy = np.sin(-eyaw)

        for pts_idx, pts in enumerate(lines):
            pts = np.asarray(pts, dtype=float)
            if pts.shape[0] == 0:
                continue

            dx = pts[:, 0] - ex
            dy = pts[:, 1] - ey
            x_rel = cy * dx - sy * dy
            y_rel = sy * dx + cy * dy
            dist2 = x_rel * x_rel + y_rel * y_rel

            idx = int(np.argmin(dist2))
            d2 = dist2[idx]
            if (best_dist2 is None) or (d2 < best_dist2):
                best_dist2 = d2
                best_y_rel = float(y_rel[idx])
                best_dix = pts_idx

        return best_y_rel, best_dix

    def _get_dead_timing_list(self, info, t_indices, turn_start_ts, turn_end_ts, sd_ego_speed):
        """
        # 目的： 1. 转弯的时刻不需要考虑是绕行;
        # 2. 如果是vru目标且横向速度比纵向要大, 不考虑是绕行场景
        # 返回速度小于阈值且帧间连续的时刻（绕行时刻）
        """
        v_agent = info["speed"]
        record_list = [] # 临时储存列表
        dead_timing_list = []

        for t_speed_index in range(len(t_indices)):
            if sd_ego_speed is not None:
                if sd_ego_speed[t_speed_index] is False:
                    if len(record_list) >= 5:
                        dead_timing_list.append(record_list)
                    record_list = []
                    continue
            if turn_end_ts is not None:
                # 处于自车转弯时刻时，若之前累计了5条数据则存进dead_timing_list
                if turn_start_ts < t_indices[t_speed_index] < turn_end_ts:
                    if len(record_list) >= 5:
                        dead_timing_list.append(record_list)
                    record_list = []
                    continue
            if t_speed_index +1 < len(t_indices):
                # 若t_indeices 不连续，则目标位置可能不可信，默认超过2帧则需要重新选择
                if t_indices[t_speed_index+1] - t_indices[t_speed_index] > 2:
                    record_list = []
                    continue
            # 大于阈值速度的不考虑，小于时如果之前累计了5帧以上，则存进dead_timing_list
            if v_agent[t_speed_index] < self.stopped_speed_thresh:
                record_list.append(t_speed_index)
            else:
                if len(record_list) >= 5:
                    dead_timing_list.append(record_list)
                record_list = []
            # 到最后一帧的时候，如果累计了5帧以上，则存进dead_timing_list
            if t_speed_index + 1 == len(t_indices) and len(record_list) >= 5:
                dead_timing_list.append(record_list)
        return dead_timing_list

    def _get_turn_ts(self, ego_traj, ego_is_straight):
        """
        判断是否转弯，如果转弯返回转弯前ts和转弯后ts
        """
        # 判断轨迹直行还是转弯
        turn_start_ts, turn_end_ts = None, None
        path_turn_type = determine_path_turn_type(ego_traj,threshold_degree=50, fuzzy_threshold_degree=30)

        turn_check_times = 10
        if path_turn_type != {Turntype.STRAIGHT}:
            turn_end_ts = determine_path_turn_end_ts_type(ego_traj, path_turn_type, threshold_degree=50, fuzzy_threshold_degree=30)
            # turn_type_end_ts *=1
            # 往后推， 找到连续10帧还是都是转弯的时刻作为转弯最后ts
            for turn_ts in range(turn_end_ts,len(ego_traj)):
                if ego_is_straight[turn_ts] == True:
                    turn_end_ts = turn_ts
                    break

            for turn_ts in range(turn_end_ts,0,-1):
                # 连续帧False的时候，选择第一个是True的时机
                if turn_ts <= turn_check_times:
                    while ego_is_straight[turn_ts] == False:
                        turn_ts -=1
                        if turn_ts == 0:
                            break
                    turn_start_ts = turn_ts
                    break
                if ego_is_straight[turn_ts] == False and np.sum(ego_is_straight[turn_ts - turn_check_times +1:turn_ts]) == turn_check_times -1:
                # if np.sum(ego_is_straight[turn_ts-turn_check_times:turn_ts]) < turn_check_times:
                    # 找最近的一个True
                    turn_start_ts = turn_ts
                    break

            if turn_start_ts is None:
                turn_end_ts = None
            # else:
            #     print(turn_start_ts-15, turn_end_ts-15)
        return turn_start_ts, turn_end_ts
    # ===================== 单个“死车候选”的绕行模式识别 =====================

    def _detect_overtake_pattern_for_stopped_agent(
        self,
        agent_id: int,
        t_indices: np.ndarray,
        timestamps_agent: np.ndarray,
        s_arr: np.ndarray,
        d_arr: np.ndarray,
        v_ego_arr: np.ndarray,
        ego_is_straight: np.ndarray,
    ) -> Optional[Dict[str, Any]]:
        """
        在单个“死车候选” agent 的时间序列上识别一次死车绕行 episode。

        几何模式（允许中途 ego 停车等待） + 直行约束：
            1. 在某一段时间 [k1, k2] 内（且这些时刻 ego_is_straight 为 True）：
               - 死车在 ego 前方，纵向距离 s 处于 [approach_min_gap, approach_max_gap] 左右；
               - ego 与死车横向偏移 |d| < lane_center_thresh；
               => ego 一直排在死车后面（包含接近 + 刹停 + 等待）。

            2. 在 k2 之后的某个直行时刻 k_over：
               - |d[k_over]| > lateral_overtake_offset；
               => ego 明显绕到一侧。

            3. 在 k_over 之后的某个直行时刻 k_pass：
               - s[k_pass] < -pass_ahead_gap；
               => ego 已经超到死车前方，并领先一定距离。

        只有在这些关键阶段对应的全局时刻 t_indices[*] 都处于直行段
        (ego_is_straight == True) 时，才认为发生了“死车绕行”。
        """
        M = t_indices.shape[0]
        if M < 3:
            return None

        # ---------- 1. 找“在死车后方直行排队/等待”的区间 [k1, k2] ----------
        k1 = None
        for k in range(M):
            t_idx = int(t_indices[k])
            if not ego_is_straight[t_idx]:
                continue  # 非直行段不考虑

            s = s_arr[k]
            d = d_arr[k]
            if (
                self.approach_min_gap <= s <= self.approach_max_gap
                and abs(d) < self.lane_center_thresh
            ):
                k1 = k
                break

        if k1 is None:
            # 从未在直行段里、以合适距离排在死车后方
            return None

        # 从 k1 往后扩展等待区间，直到离得太远或横向偏移太大、或者进入非直行段
        k2 = k1
        for k in range(k1 + 1, M):
            t_idx = int(t_indices[k])
            if not ego_is_straight[t_idx]:
                break  # 离开直行段，结束等待区

            s = s_arr[k]
            d = d_arr[k]
            if (
                self.approach_min_gap <= s <= (self.approach_max_gap + 5.0)
                and abs(d) < (self.lane_center_thresh + 0.5)
            ):
                k2 = k
            else:
                break

        if k2 <= k1:
            # 等待区间太短，可以认为不是稳定地排在后面
            return None

        # 时间约束：接近 + 等待到这儿的时间不能离谱
        if self.max_overtake_duration is not None:
            if (timestamps_agent[k2] - timestamps_agent[k1]) > self.max_overtake_duration:
                return None

        # ---------- 2. 在直行段的等待区之后，寻找横向绕行的开始点 k_over ----------
        k_over = None
        for k in range(k2 + 1, M):
            t_idx = int(t_indices[k])
            if not ego_is_straight[t_idx]:
                continue  # 非直行不认为是有效绕行

            d = d_arr[k]
            if abs(d) > self.lateral_overtake_offset:
                k_over = k
                break

        if k_over is None:
            # 一直排在后面，但在直行段从未真正绕到侧向
            return None

        # ---------- 3. 在直行段的横向绕行之后，寻找完成超车的时刻 k_pass ----------
        k_pass = None
        for k in range(k_over + 1, M):
            t_idx = int(t_indices[k])
            if not ego_is_straight[t_idx]:
                continue  # 非直行不认为完成了正常直行绕行

            s = s_arr[k]
            if s < -self.pass_ahead_gap:
                k_pass = k
                break

        if k_pass is None:
            # 绕到侧向了，但在直行段内从未明显超到前面
            return None

        # 时间约束：整个绕行过程不能离谱地长
        if self.max_overtake_duration is not None:
            duration = float(timestamps_agent[k_pass] - timestamps_agent[k1])
            if duration > self.max_overtake_duration:
                return None

        # 生成 episode（local index -> 全局 t_idx）
        start_idx = int(t_indices[k1])
        end_idx = int(t_indices[k_pass])

        s_seg = s_arr[k1 : k_pass + 1]
        d_seg = np.abs(d_arr[k1 : k_pass + 1])

        return {
            "agent_id": int(agent_id),
            "start_idx": start_idx,
            "end_idx": end_idx,
            "start_time": float(timestamps_agent[k1]),
            "end_time": float(timestamps_agent[k_pass]),
            "min_longitudinal_gap": float(np.min(s_seg)),
            "min_lateral_offset": float(np.min(d_seg)),
            "max_lateral_offset": float(np.max(d_seg)),
        }

    def _detect_overtake_pattern_for_stopped_agent_with_timing(
        self,
        agent_id: int,
        t_indices: np.ndarray,
        timestamps_agent: np.ndarray,
        s_arr: np.ndarray,
        d_arr: np.ndarray,
        v_ego_arr: np.ndarray,
        ego_is_straight: np.ndarray,
        is_before_junction_array:np.ndarray,
        timing_list: List[List],
    ) -> Optional[Dict[str, Any]]:
        """
        在单个“死车候选” agent 的时间序列上识别一次死车绕行 episode。

        几何模式（允许中途 ego 停车等待） + 直行约束：
            1. 在某一段时间 [k1, k2] 内（且这些时刻 ego_is_straight 为 True）：
               - 死车在 ego 前方，纵向距离 s 处于 [approach_min_gap, approach_max_gap] 左右；
               - ego 与死车横向偏移 |d| < lane_center_thresh；
               => ego 一直排在死车后面（包含接近 + 刹停 + 等待）。

            2. 在 k2 之后的某个直行时刻 k_over：
               - |d[k_over]| > lateral_overtake_offset；
               => ego 明显绕到一侧。

            3. 在 k_over 之后的某个直行时刻 k_pass：
               - s[k_pass] < -pass_ahead_gap；
               => ego 已经超到死车前方，并领先一定距离。

        只有在这些关键阶段对应的全局时刻 t_indices[*] 都处于直行段
        (ego_is_straight == True) 时，才认为发生了“死车绕行”。
        """
        episode_local_list = []
        for timing in timing_list:
            M = len(timing)
            if M < 3:
                # return None
                continue

            # ---------- 1. 找“在死车后方直行排队/等待”的区间 [k1, k2] ----------
            k1 = None
            for k in range(M):
                t_idx = int(t_indices[timing[k]])
                # 非接近路口直接过滤
                if not is_before_junction_array[t_idx]:
                    continue
                if not ego_is_straight[t_idx]:
                    continue  # 非直行段不考虑

                lane_center_thresh = self.lane_center_thresh

                s = s_arr[timing[k]]
                d = d_arr[timing[k]]
                if (
                    self.approach_min_gap <= s <= self.approach_max_gap
                    and abs(d) < lane_center_thresh
                ):
                    k1 = k
                    break

            if k1 is None:
                # 从未在直行段里、以合适距离排在死车后方
                continue

            # 从 k1 往后扩展等待区间，直到离得太远或横向偏移太大、或者进入非直行段
            k2 = k1
            for k in range(k1 + 1, M):
                t_idx = int(t_indices[timing[k]])
                # 非接近路口直接过滤
                if not is_before_junction_array[t_idx]:
                    continue

                if not ego_is_straight[t_idx]:
                    break  # 离开直行段，结束等待区

                lane_center_thresh = self.lane_center_thresh

                s = s_arr[timing[k]]
                d = d_arr[timing[k]]
                if (
                    self.approach_min_gap <= s <= (self.approach_max_gap + 5.0)
                    and abs(d) < (lane_center_thresh + 0.5)
                ):
                    k2 = k
                else:
                    break

            if k2 <= k1:
                # 等待区间太短，可以认为不是稳定地排在后面
                continue

            # 时间约束：接近 + 等待到这儿的时间不能离谱
            if self.max_overtake_duration is not None:
                if (timestamps_agent[timing[k2]] - timestamps_agent[timing[k1]]) > self.max_overtake_duration:
                    continue

            # ---------- 2. 在直行段的等待区之后，寻找横向绕行的开始点 k_over ----------
            k_over = None
            for k in range(k2 + 1, M):
                t_idx = int(t_indices[timing[k]])
                # 非接近路口直接过滤
                # if not is_before_junction_array[t_idx]:
                #     continue
                if not ego_is_straight[t_idx]:
                    continue  # 非直行不认为是有效绕行

                d = d_arr[timing[k]]
                if abs(d) > self.lateral_overtake_offset:
                    k_over = k
                    break

            if k_over is None:
                # 一直排在后面，但在直行段从未真正绕到侧向
                continue

            # ---------- 3. 在直行段的横向绕行之后，寻找完成超车的时刻 k_pass ----------
            k_pass = None
            for k in range(k_over + 1, M):
                t_idx = int(t_indices[timing[k]])
                # 非接近路口直接过滤
                # if not is_before_junction_array[t_idx]:
                #     continue
                # if not ego_is_straight[t_idx]:
                #     continue  # 非直行不认为完成了正常直行绕行

                s = s_arr[timing[k]]
                if s < -self.pass_ahead_gap:
                    k_pass = k
                    break

            if k_pass is None:
                # 绕到侧向了，但在直行段内从未明显超到前面
                continue

            # 时间约束：整个绕行过程不能离谱地长
            if self.max_overtake_duration is not None:
                duration = float(timestamps_agent[timing[k_pass]] - timestamps_agent[timing[k1]])
                if duration > self.max_overtake_duration:
                    continue

            # 生成 episode（local index -> 全局 t_idx）
            start_idx = int(t_indices[timing[k1]])
            end_idx = int(t_indices[timing[k_pass]])

            s_seg = s_arr[timing[k1] : timing[k_pass] + 1]
            d_seg = np.abs(d_arr[timing[k1] : timing[k_pass] + 1])
            res = {
                "agent_id": int(agent_id),
                "start_idx": start_idx,
                "end_idx": end_idx,
                "start_time": float(timestamps_agent[timing[k1]]),
                "end_time": float(timestamps_agent[timing[k_pass]]),
                "min_longitudinal_gap": float(np.min(s_seg)),
                "min_lateral_offset": float(np.min(d_seg)),
                "max_lateral_offset": float(np.max(d_seg)),
            }
            episode_local_list.append(res)
        return episode_local_list
    def _detect_overtake_pattern_for_stopped_agent_with_timing_and_front_car(
        self,
        agent_id: int,
        t_indices: np.ndarray,
        timestamps_agent: np.ndarray,
        s_arr: np.ndarray,
        d_arr: np.ndarray,
        v_ego_arr: np.ndarray,
        ego_is_straight: np.ndarray,
        is_before_junction_array:np.ndarray,
        timing_list: List[List],
        is_front_car_exist: np.ndarray,
    ) -> Optional[Dict[str, Any]]:
        """
        在单个“死车候选” agent 的时间序列上识别一次死车绕行 episode。

        几何模式（允许中途 ego 停车等待） + 直行约束：
            1. 在某一段时间 [k1, k2] 内（且这些时刻 ego_is_straight 为 True）：
               - 死车在 ego 前方，纵向距离 s 处于 [approach_min_gap, approach_max_gap] 左右；
               - ego 与死车横向偏移 |d| < lane_center_thresh；
               => ego 一直排在死车后面（包含接近 + 刹停 + 等待）。

            2. 在 k2 之后的某个直行时刻 k_over：
               - |d[k_over]| > lateral_overtake_offset；
               => ego 明显绕到一侧。

            3. 在 k_over 之后的某个直行时刻 k_pass：
               - s[k_pass] < -pass_ahead_gap；
               => ego 已经超到死车前方，并领先一定距离。

        只有在这些关键阶段对应的全局时刻 t_indices[*] 都处于直行段
        (ego_is_straight == True) 时，才认为发生了“死车绕行”。
        """
        episode_local_list = []
        for timing in timing_list:
            M = len(timing)
            if M < 3:
                # return None
                continue

            # ---------- 1. 找“在死车后方直行排队/等待”的区间 [k1, k2] ----------
            k1 = None
            for k in range(M):
                t_idx = int(t_indices[timing[k]])
                # 非接近路口直接过滤
                if not is_before_junction_array[t_idx]:
                    continue
                if not ego_is_straight[t_idx]:
                    continue  # 非直行段不考虑

                lane_center_thresh = self.lane_center_thresh

                s = s_arr[timing[k]]
                d = d_arr[timing[k]]
                if (
                    self.approach_min_gap <= s <= self.approach_max_gap
                    and abs(d) < lane_center_thresh
                ):
                    k1 = k
                    break

            if k1 is None:
                # 从未在直行段里、以合适距离排在死车后方
                continue

            # 从 k1 往后扩展等待区间，直到离得太远或横向偏移太大、或者进入非直行段
            k2 = k1
            for k in range(k1 + 1, M):
                t_idx = int(t_indices[timing[k]])
                # 非接近路口直接过滤
                if not is_before_junction_array[t_idx]:
                    continue

                if not ego_is_straight[t_idx]:
                    break  # 离开直行段，结束等待区

                lane_center_thresh = self.lane_center_thresh

                s = s_arr[timing[k]]
                d = d_arr[timing[k]]
                if (
                    self.approach_min_gap <= s <= (self.approach_max_gap + 5.0)
                    and abs(d) < (lane_center_thresh + 0.5)
                ):
                    k2 = k
                else:
                    break

            if k2 <= k1:
                # 等待区间太短，可以认为不是稳定地排在后面
                continue

            # 时间约束：接近 + 等待到这儿的时间不能离谱
            if self.max_overtake_duration is not None:
                if (timestamps_agent[timing[k2]] - timestamps_agent[timing[k1]]) > self.max_overtake_duration:
                    continue

            # ---------- 2. 在直行段的等待区之后，寻找横向绕行的开始点 k_over ----------
            k_over = None
            for k in range(k2 + 1, M):
                t_idx = int(t_indices[timing[k]])
                # 非接近路口直接过滤
                # if not is_before_junction_array[t_idx]:
                #     continue
                if not ego_is_straight[t_idx]:
                    continue  # 非直行不认为是有效绕行

                d = d_arr[timing[k]]
                if abs(d) > self.lateral_overtake_offset:
                    k_over = k
                    break

            if k_over is None:
                # 一直排在后面，但在直行段从未真正绕到侧向
                continue

            # ---------- 3. 在直行段的横向绕行之后，寻找完成超车的时刻 k_pass ----------
            k_pass = None
            for k in range(k_over + 1, M):
                t_idx = int(t_indices[timing[k]])
                # 非接近路口直接过滤
                # if not is_before_junction_array[t_idx]:
                #     continue
                # if not ego_is_straight[t_idx]:
                #     continue  # 非直行不认为完成了正常直行绕行

                s = s_arr[timing[k]]
                if s < -self.pass_ahead_gap:
                    k_pass = k
                    break

            if k_pass is None:
                # 绕到侧向了，但在直行段内从未明显超到前面
                continue

            # 时间约束：整个绕行过程不能离谱地长
            if self.max_overtake_duration is not None:
                duration = float(timestamps_agent[timing[k_pass]] - timestamps_agent[timing[k1]])
                if duration > self.max_overtake_duration:
                    continue

            # 生成 episode（local index -> 全局 t_idx）
            start_idx = int(t_indices[timing[k1]])
            end_idx = int(t_indices[timing[k_pass]])
            start_side_pass_idx = int(t_indices[timing[k_over]])

            # front car 额外逻辑: 若从开始时间段，到开始有绕行行为，绕行车前方有车，则认为属于排队车
            # 排队车的则加进去
            if np.sum(is_front_car_exist[timing[k1]:timing[k_over]])>0:
                s_seg = s_arr[timing[k1] : timing[k_pass] + 1]
                d_seg = np.abs(d_arr[timing[k1] : timing[k_pass] + 1])
                res = {
                    "agent_id": int(agent_id),
                    "start_idx": start_idx,
                    "end_idx": end_idx,
                    "start_time": float(timestamps_agent[timing[k1]]),
                    "end_time": float(timestamps_agent[timing[k_pass]]),
                    "min_longitudinal_gap": float(np.min(s_seg)),
                    "min_lateral_offset": float(np.min(d_seg)),
                    "max_lateral_offset": float(np.max(d_seg)),
                }
                episode_local_list.append(res)
        return episode_local_list

    # ===================== 基础工具函数 =====================

    @staticmethod
    def _compute_speeds_xy(
        xy: np.ndarray,
        timestamps: np.ndarray,
    ) -> np.ndarray:
        """
        根据 (x,y) 轨迹 + 时间戳计算标量速度 (m/s)。
        简单相邻差分，首点复用第二个点的速度。
        """
        T = xy.shape[0]
        speeds = np.zeros(T, dtype=float)
        if T <= 1:
            return speeds

        dx = np.diff(xy[:, 0])
        dy = np.diff(xy[:, 1])
        dt = np.diff(timestamps)
        dt_safe = np.where(dt == 0.0, 1e-6, dt)

        v = np.sqrt(dx * dx + dy * dy) / dt_safe

        speeds[1:] = v
        speeds[0] = speeds[1]
        return speeds

    @staticmethod
    def _compute_speeds_x_y(
        xy: np.ndarray,
        timestamps: np.ndarray,
    ) -> np.ndarray:
        """
        根据 (x,y) 轨迹 + 时间戳计算标量速度 (m/s)。
        简单相邻差分，首点复用第二个点的速度。
        """
        T = xy.shape[0]
        speeds = np.zeros((T,2), dtype=float)
        if T <= 1:
            return speeds

        dx = np.diff(xy[:, 0])
        dy = np.diff(xy[:, 1])
        dt = np.diff(timestamps)
        dt_safe = np.where(dt == 0.0, 1e-6, dt)

        vx, vy = dx/dt_safe, dy/dt_safe

        speeds[1:] = np.stack((vx, vy),1)
        speeds[0] = speeds[1]
        return speeds

    @staticmethod
    def _compute_speeds_ego_xy(
        xy: np.ndarray,
        yaw_rate: np.ndarray,
        timestamps: np.ndarray,
    ) -> np.ndarray:
        """
        根据 (x,y) 轨迹 + 时间戳计算标量速度 (m/s)。
        简单相邻差分，首点复用第二个点的速度。
        """
        T = xy.shape[0]
        speeds = np.zeros((T,2), dtype=float)
        if T <= 1:
            return speeds

        dx = np.diff(xy[:, 0])
        dy = np.diff(xy[:, 1])
        dt = np.diff(timestamps)
        dt_safe = np.where(dt == 0.0, 1e-6, dt)
        v = np.sqrt(dx * dx + dy * dy) / dt_safe


        vx, vy = dx/dt_safe, dy/dt_safe
        # heading = np.array([np.cos(yaw_rate), np.sin(yaw_rate)], dtype=float)
        # x 为正向
        ego_vy = vy * np.cos(yaw_rate[1:]) - vx * np.sin(yaw_rate[1:])
        ego_vx = vx * np.cos(yaw_rate[1:]) + vy * np.sin(yaw_rate[1:])

        speeds[1:] = np.stack((ego_vx, ego_vy),1)
        speeds[0] = speeds[1]
        return speeds


    @staticmethod
    def _compute_yaw_rate(
        yaw: np.ndarray,
        timestamps: np.ndarray,
    ) -> np.ndarray:
        """
        根据 yaw 序列和时间戳计算 yaw_rate (rad/s)，并做 unwrap 处理。
        """
        T = yaw.shape[0]
        yaw_unwrap = np.unwrap(yaw)  # 避免 2π 跳变
        yaw_rate = np.zeros(T, dtype=float)
        if T <= 1:
            return yaw_rate

        dyaw = np.diff(yaw_unwrap)
        dt = np.diff(timestamps)
        dt_safe = np.where(dt == 0.0, 1e-6, dt)

        r = dyaw / dt_safe
        yaw_rate[1:] = r
        yaw_rate[0] = yaw_rate[1]
        return yaw_rate

    @staticmethod
    def _build_agent_tracks(
        agent_dict: Dict[int, Tuple[np.ndarray, np.ndarray]],
        timestamps: np.ndarray,
    ) -> Dict[int, Dict[str, Any]]:
        """
        从按时间索引组织的 agent_dict 构建每个 agent 的轨迹与速度。

        返回：
            tracks[agent_id] = {
                "t_idx": np.ndarray[M],      # 该 agent 出现的时间索引列表
                "xy":    np.ndarray[M,2],    # 对应的 (x,y)
                "speed": np.ndarray[M],      # 对应的速度标量 (m/s)
            }
        """
        grouped = defaultdict(list)  # agent_id -> list[(t_idx, x, y)]

        for t_idx, (ids, states) in agent_dict.items():
            xs = states[:, 0]
            ys = states[:, 1]
            yaws = states[:, 2]
            cls = states[:, -1]
            for j, aid in enumerate(ids):
                grouped[int(aid)].append((t_idx, xs[j], ys[j], cls[j], yaws[j]))

        tracks: Dict[int, Dict[str, Any]] = {}
        for aid, samples in grouped.items():
            samples.sort(key=lambda x: x[0])  # 按时间排序
            t_indices = np.array([s[0] for s in samples], dtype=int)
            xy = np.array([[s[1], s[2]] for s in samples], dtype=float)
            cls = np.array([s[3] for s in samples], dtype=int)[0]
            yaw = np.array([s[4] for s in samples], dtype=float)
            ts_agent = timestamps[t_indices]
            speed = CarQueueBypassDetector._compute_speeds_xy(xy, ts_agent)

            tracks[aid] = {
                "t_idx": t_indices,
                "xy": xy,
                'yaw': yaw,
                "speed": speed,
                "type": get_map_cls_to_3cls(cls)
            }

        return tracks

def check_clip(clip_idx):
    # info = pkl.load(open(f"./tmp2/{clip_idx}.pkl", "rb"))
    info = pkl.load(open(f"/home/charlie.cheng1/ws/melange-rl/tmp_deadcar/{clip_idx}.pkl", "rb"))

    detector = CarQueueBypassDetector()

    input_dct = info["input"]
    obj_dct = info["input"]['agent_dict']
    # if 'ego_length' not in input_dct:
    #     input_dct['ego_length'] = 4.5
    # if 'ego_width' not in input_dct:
    #     input_dct['ego_width'] = 2.0

    max_len = min(len(input_dct['ego_traj']), len(obj_dct))
    input_dct['ego_traj'] = input_dct['ego_traj'][:max_len]
    if len(obj_dct)>max_len:
        for i in range(max_len, len(obj_dct)):
            obj_dct.pop(i)

    overtake_flags, target_agent_ids, episodes = detector.detect(**input_dct)
    # print(f"[{clip_idx}]is_deadcar_scene:{np.any(overtake_flags)}")
    # for seg in enumerate(episodes):
    #     print(f"\t{seg}")
    return overtake_flags, target_agent_ids, episodes




# ===================== 使用示例 =====================
if __name__ == "__main__":
    # 假设你已有以下变量：
    # ego_traj: np.ndarray[T,3]
    # ego_length, ego_width: float
    # agent_dict: Dict[int, (ids, states)]
    # timestamps: np.ndarray[T]

    import pickle as pkl

    check_clip(0)

    # detector = DeadCarBypassDetectorV3(
    #     stopped_speed_thresh=2.0,
    #     approach_min_gap=5.0,
    #     approach_max_gap=30.0,
    #     lane_center_thresh=1.0,
    #     lateral_overtake_offset=1.5,
    #     pass_ahead_gap=5.0,
    #     rel_speed_min=1.0,
    #     max_overtake_duration=20.0,
    # )
    #
    # overtake_flags, target_ids, episodes = detector.detect(
    #     ego_traj, ego_length, ego_width, agent_dict, timestamps
    # )
    #
    # 之后你可以用 overtake_flags 在时间轴上画出“死车绕行区间”，
    # 用 target_ids 做可视化高亮被绕行的死车，
    # episodes 则可以做统计或 Golden Suite 的标签。

    pass
