from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional

import sys
import logging
import numpy as np

from tpp_onemodel.utils.slow_follow_detector_v3_2 import SlowFollowSegment

def setup_logging_simple(log_file="./tmp/app.log"):
    """
    基础版本：简单的无前缀日志设置
    """
    # 创建logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)  # 设置最低日志级别

    # 清除所有已有的handler，避免重复
    logger.handlers.clear()

    # 自定义格式化器（完全空格式）
    formatter = logging.Formatter("%(message)s")

    # 文件处理器
    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(formatter)

    # 控制台处理器
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)  # 控制台只显示INFO及以上级别
    console_handler.setFormatter(formatter)

    # 添加处理器到logger
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger


# @dataclass
# class SlowFollowSegment:
#     """一段本车道慢速跟随时间片段（索引形式）."""
#
#     start_idx: int
#     end_idx: int
#     is_vehicle_block: bool
#     is_vru_block: bool
#     has_vehicle: bool
#     has_vru: bool
#

class SlowFollowDetectorV3_1:
    """
    本车道“慢速跟随”场景识别（含路口过滤 + 直行过滤 + 旁车道可用性）。

    逻辑总览：
      0) 前提：只关注直行、非路口、明显低于限速的时刻。
      1) 先排除“慢车流”（前方多车慢速巡航，不算局部慢随 issue）。
      2) 在非慢车流 + 直行 + 非路口前提下：
         - 机动车（宽目标）：
             * 本车道前方有挡路机动车（headway + 低于限速）；
             * 且旁车道（含对向）在 side_window_time 内 TTC 足够安全；
             => 本车道慢速跟随（reason="vehicle_block"）。
         - VRU / 小目标（窄目标）：
             * 前向窗口内组合占道后，本车道走廊不足以通过 ego；
             * 且 headway + 低于限速；
             => 本车道慢速跟随（reason="vru_block"）。

    输入约定：
      - ego_traj: [T,3] -> (x, y, yaw)
      - ego_length, ego_width: 自车尺寸（米）
      - agent_dict: dict[t -> (ids[N], states[N,5])]
            states: (x, y, yaw, length, width)
      - speed_limit_kph: [T]
      - lane_centerlines: dict[t -> List[np.ndarray[P,3]]]
      - navi_centerlines: dict[t -> List[Tuple[np.ndarray[P,3], int]]]
      - timestamps: [T] (秒)
    """

    def __init__(
        self,
        ego_length: float,
        ego_width: float,
        *,
        # 基本慢速条件
        min_ego_speed_ms: float = 2.78,  # ~10 kph
        slow_ratio: float = 0.5,  # v_ego < slow_ratio * v_limit => 明显低于限速
        # 车道几何
        lane_width_est: float = 3.5,
        lane_offset_max: float = 1.0,
        lateral_margin: float = 0.3,
        # 机动车 / VRU 区分
        vehicle_width_thresh: float = 1.8,
        # 慢车流判定
        flow_front_dist_max: float = 80.0,
        flow_min_vehicles: int = 3,
        flow_speed_ratio_min: float = 0.7,
        flow_speed_diff_max: float = 5.0,
        # 机动车挡路判定（本车道）
        veh_block_front_dist_max: float = 60.0,
        veh_min_headway: float = 5.0,
        veh_max_headway: float = 60.0,
        # VRU 组合挡路判定（本车道）
        vru_front_dist_max: float = 50.0,
        vru_block_window_len: float = 20.0,
        vru_min_headway: float = 3.0,
        vru_max_headway: float = 50.0,
        # 旁车道安全判定（含对向）
        side_window_time: float = 3.0,
        side_front_dist: float = 40.0,
        side_back_dist: float = 15.0,
        adj_lane_min_factor: float = 0.5,
        adj_lane_max_factor: float = 1.8,
        # 直行判定
        lane_yaw_diff_thresh_deg: float = 15.0,  # ego yaw 与车道切线的最大夹角
        yaw_rate_thresh_rad: float = 0.1,  # 无车道线时的 yaw_rate 阈值（rad/s）
        # 路口判定（距 navi 最晚变道点的弧长距离）
        min_junction_dist: float = 100.0,  # 距最晚变道点 >= 100m 才允许换道（视为非路口）
        # 段落提取
        min_segment_duration: float = 5.0,
        longitudinal_margin: float = 1.0,
        history_num: int = 15,
    ):
        self.ego_length = float(ego_length)
        self.ego_width = float(ego_width)

        self.min_ego_speed_ms = min_ego_speed_ms
        self.slow_ratio = slow_ratio

        self.lane_width_est = lane_width_est
        self.lane_offset_max = lane_offset_max
        self.lateral_margin = lateral_margin

        self.vehicle_width_thresh = vehicle_width_thresh

        self.flow_front_dist_max = flow_front_dist_max
        self.flow_min_vehicles = flow_min_vehicles
        self.flow_speed_ratio_min = flow_speed_ratio_min
        self.flow_speed_diff_max = flow_speed_diff_max

        self.veh_block_front_dist_max = veh_block_front_dist_max
        self.veh_min_headway = veh_min_headway
        self.veh_max_headway = veh_max_headway

        self.vru_front_dist_max = vru_front_dist_max
        self.vru_block_window_len = vru_block_window_len
        self.vru_min_headway = vru_min_headway
        self.vru_max_headway = vru_max_headway

        self.side_window_time = side_window_time
        self.side_front_dist = side_front_dist
        self.side_back_dist = side_back_dist
        self.adj_lane_min_factor = adj_lane_min_factor
        self.adj_lane_max_factor = adj_lane_max_factor

        self.lane_yaw_diff_thresh = np.deg2rad(lane_yaw_diff_thresh_deg)
        self.yaw_rate_thresh = yaw_rate_thresh_rad
        self.min_junction_dist = min_junction_dist

        self.min_segment_duration = min_segment_duration

        self.longitudinal_margin = longitudinal_margin

        self.history_num = history_num

    # ======================
    #   Public API
    # ======================

    def detect(
        self,
        ego_traj: np.ndarray,
        agent_dict: Dict[int, Tuple[np.ndarray, np.ndarray]],
        speed_limit_kph: np.ndarray,
        lane_centerlines: Dict[int, List[np.ndarray]],
        navi_centerlines: Dict[int, List[Tuple[np.ndarray, int]]],
        solid_lanes: Dict[int, List[np.ndarray]],
        timestamps: np.ndarray,
    ) -> Tuple[bool, List[SlowFollowSegment]]:
        """
        返回：
          inlane_slow_follow_mask: [T]，是否处于本车道慢速跟随；
          segments: 段列表（附 reason: "vehicle_block" / "vru_block"）。
        """
        ego_traj = np.asarray(ego_traj, dtype=float)
        speed_limit_kph = np.asarray(speed_limit_kph, dtype=float)
        timestamps = np.asarray(timestamps, dtype=float)

        max_len = min(ego_traj.shape[0], speed_limit_kph.shape[0], timestamps.shape[0])
        ego_traj = ego_traj[:max_len]
        speed_limit_kph = speed_limit_kph[:max_len]
        timestamps = timestamps[:max_len]
        for lines_dct in (lane_centerlines, navi_centerlines):
            if len(lane_centerlines) > max_len:
                keys_to_remove = [k for k in lines_dct.keys() if k >= max_len]
                for k in keys_to_remove:
                    del lines_dct[k]

        T = ego_traj.shape[0]
        assert ego_traj.shape[1] == 3
        assert speed_limit_kph.shape[0] == T
        assert timestamps.shape[0] == T

        # 时间步长
        dt_array = self._compute_dt_array(timestamps)

        # ego 基础量
        v_ego = self._compute_speed(ego_traj[:, 0], ego_traj[:, 1], dt_array)
        speed_limit_ms = speed_limit_kph / 3.6
        yaw_rate = self._compute_yaw_rate(ego_traj[:, 2], dt_array)

        # ego 速度向量（世界系）
        ego_vel_world = np.zeros((T, 2), dtype=float)
        ego_vel_world[:, 0] = v_ego * np.cos(ego_traj[:, 2])
        ego_vel_world[:, 1] = v_ego * np.sin(ego_traj[:, 2])

        # agent 速度
        agent_vel_dict = self._precompute_agent_velocity(agent_dict, timestamps, T)

        # 本车道带（ego 坐标系）
        lane_band = self._compute_lane_band_series(ego_traj, lane_centerlines, navi_centerlines)

        # 基本低速
        slow_basic_mask = self._compute_basic_slow_mask(v_ego, speed_limit_ms)

        # 慢车流过滤
        slow_flow_mask = self._compute_slow_flow_mask(
            ego_traj,
            v_ego,
            speed_limit_ms,
            lane_band,
            agent_dict,
            agent_vel_dict,
        )

        # 直行过滤
        straight_mask = self._compute_straight_mask(
            ego_traj,
            yaw_rate,
            lane_centerlines,
            navi_centerlines,
        )

        # 非路口过滤
        non_junction_mask = self._compute_non_junction_mask(
            ego_traj,
            navi_centerlines,
        )

        # 大车挡路（本车道）
        veh_block_mask_raw, veh_block_dist, veh_exist_mask = self._compute_vehicle_block_mask(
            ego_traj, lane_band, v_ego, speed_limit_ms, agent_dict
        )

        # VRU 完全挡路（本车道）
        vru_full_block_mask, vru_block_dist, vru_exist_mask = self._compute_vru_block_mask(
            ego_traj, lane_band, v_ego, speed_limit_ms, agent_dict
        )

        # 旁车道是否有空间
        free_side_mask, safe_side_mask = self._compute_free_side_mask_with_lanes(
            ego_traj,
            v_ego,
            ego_vel_world,
            agent_dict,
            agent_vel_dict,
            timestamps,
            lane_centerlines,
            navi_centerlines,
            solid_lanes,
        )

        base_mask = slow_basic_mask & (~slow_flow_mask) & non_junction_mask & straight_mask

        # 本车道是否被挡住（不管是车还是 VRU，只要“车道内不可通过”就算被挡）
        blocked_in_lane = veh_block_mask_raw | vru_full_block_mask

        # 初始“效率换道型跟随”候选（尚未考虑加速收益）
        lc_candidate_mask = base_mask & blocked_in_lane & free_side_mask
        # ---- “加速是否有意义”的掩码（只对换道型慢随生效） -------------------
        overtake_benefit_mask = self._compute_overtake_benefit_mask(
            ego_traj=ego_traj,
            v_ego=v_ego,
            speed_limit_ms=speed_limit_ms,
            lane_band=lane_band,
            agent_dict=agent_dict,
            agent_vel_dict=agent_vel_dict,
            candidate_mask=lc_candidate_mask,
        )

        # 目标：慢速跟车 + 可通过“换道”解决（效率换道场景）
        lc_slow_follow_mask = lc_candidate_mask & overtake_benefit_mask
        lc_slow_follow_mask[: self.history_num] = False

        safe_drive_mask = self.is_safe_drive_with_safe_lane(ego_traj = ego_traj,
                                          candidate_mask = lc_slow_follow_mask,
                                          safe_side_mask = safe_side_mask,
                                          lane_centerlines = lane_centerlines,
                                        navi_centerlines = navi_centerlines,
                                        future_t = 5,
                                        safe_proportion = 0.6,
        )

        inlane_vru_bypass_mask = base_mask & vru_exist_mask & (~vru_full_block_mask) & (~veh_block_mask_raw)
        inlane_vru_bypass_mask[: self.history_num] = False

        # segments 的 reason 仍可按谁挡住来区分
        raw_segments = self._extract_segments(lc_slow_follow_mask, dt_array, self.min_segment_duration)
        lc_segments = self._gen_segments(
            raw_segments=raw_segments,
            veh_block_mask_raw=veh_block_mask_raw,
            vru_full_block_mask=vru_full_block_mask,
            veh_exist_mask=veh_exist_mask,
            vru_exist_mask=vru_exist_mask,
        )
        lc_bypass = len(lc_segments) > 0

        raw_segments = self._extract_segments(inlane_vru_bypass_mask, dt_array, self.min_segment_duration)
        inlane_segments: List[SlowFollowSegment] = self._gen_segments(
            raw_segments=raw_segments,
            veh_block_mask_raw=veh_block_mask_raw,
            vru_full_block_mask=vru_full_block_mask,
            veh_exist_mask=veh_exist_mask,
            vru_exist_mask=vru_exist_mask,
        )

        inlane_bypass = len(inlane_segments) > 0

        is_follow_slow_scene = inlane_bypass or lc_bypass
        # self._debug_print(
        #     dict(
        #         ego_slow=slow_basic_mask.astype(int),
        #         slow_flow=slow_flow_mask.astype(int),
        #         non_junc=non_junction_mask.astype(int),
        #         straight=straight_mask.astype(int),
        #         side=free_side_mask.astype(int),
        #         veh=veh_block_mask_raw.astype(int),
        #         vru_blk=vru_full_block_mask.astype(int),
        #         has_vru=vru_front_exist_mask.astype(int),
        #         lc=lc_slow_follow_mask.astype(int),
        #         sidepass=inlane_vru_bypass_mask.astype(int),
        #     )
        # )
        # print(f"inlane_bypass {inlane_bypass}  lc_bypass {lc_bypass} -> is_follow_slow_scene {is_follow_slow_scene}")

        # penalty = self.compute_reward(ego_traj=ego_traj, speed_limits_kph=speed_limit_kph)
        # print(f"penalty {penalty}")

        return is_follow_slow_scene, lc_segments + inlane_segments, safe_drive_mask

    def _debug_print(self, tensor_dct: dict):
        import pandas as pd

        # 设置最大显示行数（None表示不限制）
        pd.set_option("display.max_rows", None)

        # 设置最大显示列数（None表示不限制）
        pd.set_option("display.max_columns", None)

        # 设置每列的最大宽度（防止自动换行）
        pd.set_option("display.width", None)

        # 设置最大列宽（防止截断内容）
        pd.set_option("display.max_colwidth", None)

        df = pd.DataFrame(data=tensor_dct)
        print(df)

    def _gen_segments(
        self,
        raw_segments: List[Tuple[int, int]],
        veh_block_mask_raw: np.ndarray,
        vru_full_block_mask: np.ndarray,
        veh_exist_mask,
        vru_exist_mask,
    ) -> List[SlowFollowSegment]:
        lc_segments: List[SlowFollowSegment] = []
        for s, e in raw_segments:
            veh_ratio = np.mean(veh_block_mask_raw[s : e + 1]) if e >= s else 0.0
            vru_ratio = np.mean(vru_full_block_mask[s : e + 1]) if e >= s else 0.0
            is_vehicle_block = is_vru_block = False
            if veh_ratio >= vru_ratio:
                is_vehicle_block = True
            else:
                is_vru_block = False
            has_vehicle = bool(np.any(veh_exist_mask[s : e + 1]))
            has_vru = bool(np.any(vru_exist_mask[s : e + 1]))
            lc_segments.append(
                SlowFollowSegment(
                    start_idx=s,
                    end_idx=e,
                    is_vehicle_block=is_vehicle_block,
                    is_vru_block=is_vru_block,
                    has_vehicle=has_vehicle,
                    has_vru=has_vru,
                )
            )
        return lc_segments

    # ======================
    #   基础工具
    # ======================

    def _compute_dt_array(self, timestamps: np.ndarray) -> np.ndarray:
        dt_array = np.diff(timestamps, prepend=timestamps[0])
        if len(dt_array) > 1:
            dt_array[0] = dt_array[1]
        else:
            dt_array[0] = 0.1
        dt_array = np.where(dt_array <= 1e-3, 1e-3, dt_array)
        return dt_array

    def _compute_speed(
        self,
        x: np.ndarray,
        y: np.ndarray,
        dt_array: np.ndarray,
    ) -> np.ndarray:
        dx = np.diff(x, prepend=x[0])
        dy = np.diff(y, prepend=y[0])
        v = np.sqrt(dx * dx + dy * dy) / dt_array
        return v

    def _angle_wrap(self, ang: np.ndarray) -> np.ndarray:
        return (ang + np.pi) % (2 * np.pi) - np.pi

    def _compute_yaw_rate(
        self,
        yaw: np.ndarray,
        dt_array: np.ndarray,
    ) -> np.ndarray:
        yaw_unwrapped = np.unwrap(yaw)
        dyaw = np.diff(yaw_unwrapped, prepend=yaw_unwrapped[0])
        yr = dyaw / dt_array
        return yr

    def _precompute_agent_velocity(
        self,
        agent_dict: Dict[int, Tuple[np.ndarray, np.ndarray]],
        timestamps: np.ndarray,
        T: int,
    ) -> Dict[int, Tuple[np.ndarray, np.ndarray]]:
        agent_vel_dict: Dict[int, Tuple[np.ndarray, np.ndarray]] = {}
        prev_state_by_id: Dict[int, Tuple[float, float, int]] = {}

        for t in range(T):
            if t not in agent_dict:
                continue
            ids_t, states_t = agent_dict[t]
            positions = states_t[:, :2]
            N = positions.shape[0]
            v = np.zeros((N, 2), dtype=float)

            for i, agent_id in enumerate(ids_t):
                x, y = positions[i]
                if agent_id in prev_state_by_id:
                    x_prev, y_prev, t_prev = prev_state_by_id[agent_id]
                    dt = timestamps[t] - timestamps[t_prev]
                    if dt > 1e-3:
                        v[i, 0] = (x - x_prev) / dt
                        v[i, 1] = (y - y_prev) / dt
                prev_state_by_id[int(agent_id)] = (float(x), float(y), int(t))

            agent_vel_dict[t] = (ids_t.copy(), v)

        return agent_vel_dict

    # ======================
    #   车道带 + 车道切线
    # ======================

    def _estimate_ego_lane_center_offset(
        self,
        ego_state: np.ndarray,
        lines: List[np.ndarray],
    ) -> Optional[float]:
        ex, ey, eyaw = ego_state
        best_y_rel = None
        best_dist2 = None

        cy = np.cos(-eyaw)
        sy = np.sin(-eyaw)

        for pts in lines:
            pts = np.asarray(pts, dtype=float)
            if pts.shape[0] == 0:
                continue

            dx = pts[:, 0] - ex
            dy = pts[:, 1] - ey
            x_rel = cy * dx - sy * dy
            y_rel = sy * dx + cy * dy
            dist2 = x_rel * x_rel + y_rel * y_rel

            idx = int(np.argmin(dist2))
            d2 = dist2[idx]
            if (best_dist2 is None) or (d2 < best_dist2):
                best_dist2 = d2
                best_y_rel = float(y_rel[idx])

        return best_y_rel

    def _estimate_lane_tangent_yaw(
        self,
        ego_state: np.ndarray,
        line: np.ndarray,
    ) -> Optional[float]:
        """
        给定一条中心线和 ego 状态，返回最近点处的车道切线 yaw（世界系）, 无法估计则返回 None.
        """
        ex, ey, _ = ego_state
        pts = np.asarray(line, dtype=float)
        if pts.shape[0] < 2:
            return None

        dx = pts[:, 0] - ex
        dy = pts[:, 1] - ey
        dist2 = dx * dx + dy * dy
        idx = int(np.argmin(dist2))

        if idx == 0:
            v = pts[1] - pts[0]
        elif idx == pts.shape[0] - 1:
            v = pts[-1] - pts[-2]
        else:
            v = pts[idx + 1] - pts[idx - 1]

        vx, vy = float(v[0]), float(v[1])
        if vx * vx + vy * vy < 1e-6:
            return None

        yaw_lane = np.arctan2(vy, vx)
        return yaw_lane

    def _compute_lane_band_series(
        self,
        ego_traj: np.ndarray,
        lane_centerlines: Dict[int, List[np.ndarray]],
        navi_centerlines: Dict[int, List[Tuple[np.ndarray, int]]],
    ) -> List[Tuple[float, float]]:
        T = ego_traj.shape[0]
        bands: List[Tuple[float, float]] = []

        for t in range(T):
            ego_state = ego_traj[t]
            y_center: Optional[float] = None

            if t in navi_centerlines and navi_centerlines[t]:
                lines = [cl for (cl, _) in navi_centerlines[t]]
                y_center = self._estimate_ego_lane_center_offset(ego_state, lines)
            elif t in lane_centerlines and lane_centerlines[t]:
                y_center = self._estimate_ego_lane_center_offset(ego_state, lane_centerlines[t])

            if y_center is None:
                y_center = 0.0

            y_min = y_center - self.lane_width_est / 2.0
            y_max = y_center + self.lane_width_est / 2.0
            bands.append((y_min, y_max))

        return bands

    # ======================
    #   基本慢速 & 慢车流
    # ======================

    def _compute_basic_slow_mask(
        self,
        v_ego: np.ndarray,
        speed_limit_ms: np.ndarray,
    ) -> np.ndarray:
        T = v_ego.shape[0]
        mask = np.zeros(T, dtype=bool)

        for t in range(T):
            v = v_ego[t]
            limit = speed_limit_ms[t]
            if v < self.min_ego_speed_ms:
                continue
            if limit <= 1e-3:
                continue
            if v < self.slow_ratio * limit:
                mask[t] = True
        return mask

    def _compute_slow_flow_mask(
        self,
        ego_traj: np.ndarray,
        v_ego: np.ndarray,
        speed_limit_ms: np.ndarray,
        lane_band: List[Tuple[float, float]],
        agent_dict: Dict[int, Tuple[np.ndarray, np.ndarray]],
        agent_vel_dict: Dict[int, Tuple[np.ndarray, np.ndarray]],
    ) -> np.ndarray:
        """
        慢车流判定（True 表示“慢车流，不算局部慢随 issue”）.
        """
        T = ego_traj.shape[0]
        mask = np.zeros(T, dtype=bool)

        for t in range(T):
            if t not in agent_dict or t not in agent_vel_dict:
                continue
            ids_t, states_t = agent_dict[t]
            _, vel_t = agent_vel_dict[t]
            if len(ids_t) == 0:
                continue

            ex, ey, eyaw = ego_traj[t]
            y_min, y_max = lane_band[t]

            x_a = states_t[:, 0]
            y_a = states_t[:, 1]
            w_a = states_t[:, 4]

            dx = x_a - ex
            dy = y_a - ey
            cy = np.cos(-eyaw)
            sy = np.sin(-eyaw)
            x_rel = cy * dx - sy * dy
            y_rel = sy * dx + cy * dy

            is_vehicle = w_a >= self.vehicle_width_thresh

            in_front = (x_rel > 0.0) & (x_rel < self.flow_front_dist_max)
            in_lane = (y_rel >= y_min - self.lateral_margin) & (y_rel <= y_max + self.lateral_margin)
            mask_candidates = is_vehicle & in_front & in_lane
            if not np.any(mask_candidates):
                continue

            idxs = np.where(mask_candidates)[0]
            v_agents = np.linalg.norm(vel_t[idxs, :], axis=1)
            if idxs.size < self.flow_min_vehicles:
                continue

            v_flow = float(np.mean(v_agents))
            v_e = float(v_ego[t])
            limit = float(speed_limit_ms[t])
            if limit <= 1e-3:
                continue

            if abs(v_flow - v_e) > self.flow_speed_diff_max:
                continue
            if v_flow / limit < self.flow_speed_ratio_min:
                continue

            x_sorted = np.sort(x_rel[idxs])
            gaps = np.diff(x_sorted)
            if gaps.size > 0 and np.max(gaps) > 50.0:
                continue

            mask[t] = True

        return mask

    # ======================
    #   直行 / 路口 过滤
    # ======================

    def _compute_straight_mask(
        self,
        ego_traj: np.ndarray,
        yaw_rate: np.ndarray,
        lane_centerlines: Dict[int, List[np.ndarray]],
        navi_centerlines: Dict[int, List[Tuple[np.ndarray, int]]],
    ) -> np.ndarray:
        """
        大体直行：

        - 优先：用“最近”的车道中心线（navi 优先，其次 lane），
          在该线最近点处算切线方向 yaw_lane，要求
              |yaw_ego - yaw_lane| < lane_yaw_diff_thresh
        - 若该帧没有任何车道线，则退化为 |yaw_rate| < yaw_rate_thresh.
        """
        T = ego_traj.shape[0]
        mask = np.zeros(T, dtype=bool)

        for t in range(T):
            ego_state = ego_traj[t]
            yaw_ego = ego_state[2]

            # 1. 取这一帧的所有候选车道线（navi 优先）
            candidate_lines: List[np.ndarray] = []
            if t in navi_centerlines and navi_centerlines[t]:
                candidate_lines = [cl for (cl, _) in navi_centerlines[t]]
            elif t in lane_centerlines and lane_centerlines[t]:
                candidate_lines = lane_centerlines[t]

            # 2. 选“最近”的那条线作为 ego 所在车道线
            best_line = None
            best_dist2 = None
            ex, ey, _ = ego_state

            for cl in candidate_lines:
                pts = np.asarray(cl, dtype=float)
                if pts.shape[0] == 0:
                    continue
                dx = pts[:, 0] - ex
                dy = pts[:, 1] - ey
                dist2 = dx * dx + dy * dy
                d2_min = float(np.min(dist2))
                if (best_dist2 is None) or (d2_min < best_dist2):
                    best_dist2 = d2_min
                    best_line = pts

            if best_line is not None:
                # 3. 在最近车道线上算切线 yaw
                yaw_lane = self._estimate_lane_tangent_yaw(ego_state, best_line)
                if yaw_lane is not None:
                    d = abs(self._angle_wrap(np.array([yaw_ego - yaw_lane]))[0])
                    if d < self.lane_yaw_diff_thresh:
                        mask[t] = True
                    # 若 d 太大，则认为不是沿本车道直行，mask[t] 保持 False
                    continue  # 不再走 yaw_rate fallback

            # 4. 没有可用车道线（或切线无效）时，用 yaw_rate 退化判定
            elif abs(yaw_rate[t]) < self.yaw_rate_thresh:
                mask[t] = True

        return mask

    def _compute_non_junction_mask(
        self,
        ego_traj: np.ndarray,
        navi_centerlines: Dict[int, List[Tuple[np.ndarray, int]]],
    ) -> np.ndarray:
        """
        非路口 mask：
          - 若有 navi 车道线：计算 ego 到各条线“最晚变道点”的弧长距离，
              只要有一条线的距离 >= min_junction_dist => 非路口（允许换道）。
              全部 < min_junction_dist => 视为接近路口，不允许换道。
          - 若无 navi 车道线：按需求，认为可变道 => 非路口(True)。
        """
        T = ego_traj.shape[0]
        mask = np.zeros(T, dtype=bool)

        for t in range(T):
            ego_state = ego_traj[t]
            if t not in navi_centerlines or not navi_centerlines[t]:
                # 无 navi，暂视为非路口（允许变道）
                mask[t] = True
                continue

            ex, ey, _ = ego_state
            is_non_junction = False

            for centerline, latest_idx in navi_centerlines[t]:
                pts = np.asarray(centerline, dtype=float)
                if pts.shape[0] < 2:
                    continue
                if latest_idx is None:
                    latest_idx = 0
                latest_idx = int(np.clip(latest_idx, 0, pts.shape[0] - 1))

                # 弧长 s
                seg = np.diff(pts[:, :2], axis=0)
                seg_len = np.linalg.norm(seg, axis=1)
                s = np.concatenate([[0.0], np.cumsum(seg_len)])

                # 找 ego 在该线上的最近点索引
                dx = pts[:, 0] - ex
                dy = pts[:, 1] - ey
                dist2 = dx * dx + dy * dy
                idx = int(np.argmin(dist2))

                s_ego = s[idx]
                s_latest = s[latest_idx]

                # ego 到“最晚变道点”的距离（若已过最晚变道点，视为 0）
                if s_latest <= s_ego:
                    dist_to_latest = 0.0
                else:
                    dist_to_latest = s_latest - s_ego

                if dist_to_latest >= self.min_junction_dist:
                    is_non_junction = True
                    break

            mask[t] = is_non_junction

        return mask

    def _compute_overtake_benefit_mask(
        self,
        ego_traj: np.ndarray,
        v_ego: np.ndarray,
        speed_limit_ms: np.ndarray,
        lane_band: List[Tuple[float, float]],
        agent_dict: Dict[int, Tuple[np.ndarray, np.ndarray]],
        agent_vel_dict: Dict[int, Tuple[np.ndarray, np.ndarray]],
        candidate_mask: np.ndarray,  # 只在 True 的帧上检查“加速收益”
    ) -> np.ndarray:
        """
        计算“加速是否有价值”的掩码（True 表示：加速/变道是值得的）。

        条件同时满足才返回 True：
          1）在本车道前方找到挡路目标（车或 VRU），速度为 v_front；
          2）假定自车未来 side_window_time 内可跑到限速 v_limit，
             前车保持 v_front，则：
                 gain = (v_limit - v_front) * side_window_time >= ego_length
             即：在这段时间内至少能领先前车一个车身；
          3）在旁车道区域中，不存在“与前车纵向位置大体相同”的车辆：
                 |x_side - x_front| <= ego_length
             否则认为即便变道，最多也只能并排，超不过去 → 没有加速价值。

        没有通过上述条件的帧，本函数返回 False。
        其他帧（candidate_mask=False 或信息不足）返回 True，不额外限制。
        """
        T = ego_traj.shape[0]
        mask = np.ones(T, dtype=bool)  # 默认不限制

        for t in range(T):
            if not candidate_mask[t]:
                continue

            if t not in agent_dict or t not in agent_vel_dict:
                # 没有社会车，就不要在这一层再否决
                continue

            ids_t, states_t = agent_dict[t]
            _, vel_t = agent_vel_dict[t]
            if len(ids_t) == 0:
                continue

            ex, ey, eyaw = ego_traj[t]
            y_min, y_max = lane_band[t]
            v_limit = float(speed_limit_ms[t])
            if v_limit <= 1e-3:
                # 限速几乎为 0，没有加速空间
                mask[t] = False
                continue

            # ego 坐标系下的相对位置
            x_a = states_t[:, 0]
            y_a = states_t[:, 1]
            dx = x_a - ex
            dy = y_a - ey
            cy = np.cos(-eyaw)
            sy = np.sin(-eyaw)
            x_rel = cy * dx - sy * dy  # >0 在前
            y_rel = sy * dx + cy * dy

            # ------------------------------
            # 1) 找“本车道前方挡路目标”的 x_front, v_front
            # ------------------------------
            in_front_lane = (
                (x_rel > 0.0) & (y_rel >= y_min - self.lateral_margin) & (y_rel <= y_max + self.lateral_margin)
            )
            idx_lane = np.where(in_front_lane)[0]
            if idx_lane.size == 0:
                # 理论上 candidate_mask=True 时不应发生，但保守起见当成“无收益”
                mask[t] = False
                continue

            # 取本车道前方最近的目标
            x_front_all = x_rel[idx_lane]
            i_near = idx_lane[np.argmin(x_front_all)]
            x_front = float(x_rel[i_near])
            v_front = float(np.linalg.norm(vel_t[i_near, :]))

            # ------------------------------
            # 2) 检查旁车道是否有“纵向位置相近”的车
            # ------------------------------
            y_center = 0.5 * (y_min + y_max)
            half_width = 0.5 * (y_max - y_min)  # 理论上 ≈ lane_width_est / 2

            # 旁车道区域：在当前车道带外，且不超过 1.5 个车道宽
            side_mask = (
                (x_rel > 0.0)
                & (np.abs(y_rel - y_center) >= (half_width + self.lateral_margin))
                & (np.abs(y_rel - y_center) <= (1.5 * self.lane_width_est + self.lateral_margin))
            )
            idx_side = np.where(side_mask)[0]

            if idx_side.size > 0:
                x_side = x_rel[idx_side]
                # 纵向位置与前车“差不多”：|Δx| <= 1 个自车车长
                near_parallel = np.abs(x_side - x_front) <= self.ego_length
                if np.any(near_parallel):
                    # 旁车道有与前车几乎并排的车 → 变道也无法在窗口内超过前车
                    mask[t] = False
                    continue

        return mask

    # ======================
    #   机动车挡路（本车道）
    # ======================

    def _compute_vehicle_block_mask(
        self,
        ego_traj: np.ndarray,
        lane_band: List[Tuple[float, float]],
        v_ego: np.ndarray,
        speed_limit_ms: np.ndarray,
        agent_dict: Dict[int, Tuple[np.ndarray, np.ndarray]],
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        T = ego_traj.shape[0]
        veh_block_mask = np.zeros(T, dtype=bool)
        veh_block_dist = np.full(T, np.nan, dtype=float)
        veh_exist_mask = np.zeros(T, dtype=bool)

        for t in range(T):
            if 35 == t:
                a = 0
            if t not in agent_dict:
                continue
            ids_t, states_t = agent_dict[t]
            if len(ids_t) == 0:
                continue

            ex, ey, eyaw = ego_traj[t]
            y_min, y_max = lane_band[t]

            x_a = states_t[:, 0]
            y_a = states_t[:, 1]
            w_a = states_t[:, 4]

            dx = x_a - ex
            dy = y_a - ey
            cy = np.cos(-eyaw)
            sy = np.sin(-eyaw)
            x_rel = cy * dx - sy * dy
            y_rel = sy * dx + cy * dy

            is_vehicle = w_a >= self.vehicle_width_thresh

            in_front = (x_rel > 0.0) & (x_rel < self.veh_block_front_dist_max)
            in_lane = (y_rel >= y_min - self.lateral_margin) & (y_rel <= y_max + self.lateral_margin)

            candidates = np.where(is_vehicle & in_front & in_lane)[0]
            if candidates.size == 0:
                continue
            veh_exist_mask[t] = True

            idx_min = candidates[np.argmin(x_rel[candidates])]
            d = float(x_rel[idx_min])

            if not (self.veh_min_headway <= d <= self.veh_max_headway):
                continue

            v = float(v_ego[t])
            limit = float(speed_limit_ms[t])
            if v < self.min_ego_speed_ms or limit <= 1e-3 or v >= self.slow_ratio * limit:
                continue

            veh_block_mask[t] = True
            veh_block_dist[t] = d

        return veh_block_mask, veh_block_dist, veh_exist_mask

    # ======================
    #   VRU 组合挡路（本车道）
    # ======================
    def _compute_vru_block_mask(
        self,
        ego_traj: np.ndarray,
        lane_band: List[Tuple[float, float]],
        v_ego: np.ndarray,
        speed_limit_ms: np.ndarray,
        agent_dict: Dict[int, Tuple[np.ndarray, np.ndarray]],
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        VRU 组合挡路（本车道）：

        vru_full_block_mask[t] = True   表示 VRU 组合在本车道前方
                                    “完全挡死车道，车道内不可通过”；
        dist[t] = 最近这段“被挡死”的起始距离（x_rel）；
        vru_front_exist_mask[t] = True  表示前方本车道区域内存在 VRU
                                        （不管是否挡死）。
        """
        T = ego_traj.shape[0]
        vru_full_block_mask = np.zeros(T, dtype=bool)
        dist = np.full(T, np.nan, dtype=float)
        vru_front_exist_mask = np.zeros(T, dtype=bool)

        for t in range(T):
            if 35 == t:
                a = 0
            if t not in agent_dict:
                continue
            ids_t, states_t = agent_dict[t]
            if len(ids_t) == 0:
                continue

            ex, ey, eyaw = ego_traj[t]
            y_min, y_max = lane_band[t]

            x_a = states_t[:, 0]
            y_a = states_t[:, 1]
            w_a = states_t[:, 4]

            dx = x_a - ex
            dy = y_a - ey
            cy = np.cos(-eyaw)
            sy = np.sin(-eyaw)
            x_rel = cy * dx - sy * dy
            y_rel = sy * dx + cy * dy

            # 只看小目标（VRU 等）
            is_vru = w_a < self.vehicle_width_thresh

            in_front = (x_rel > 0.0) & (x_rel < self.vru_front_dist_max)
            in_lane_loose = (y_rel >= y_min - self.lateral_margin) & (y_rel <= y_max + self.lateral_margin)

            idxs = np.where(is_vru & in_front & in_lane_loose)[0]
            if idxs.size == 0:
                continue

            # 说明前方车道里确实有 VRU
            vru_front_exist_mask[t] = True

            x_rel_v = x_rel[idxs]
            y_rel_v = y_rel[idxs]
            w_v = w_a[idxs]

            order = np.argsort(x_rel_v)
            x_rel_v = x_rel_v[order]
            y_rel_v = y_rel_v[order]
            w_v = w_v[order]

            lane_y_min = y_min
            lane_y_max = y_max

            best_block_dist = None

            for i in range(len(x_rel_v)):
                x_start = x_rel_v[i]
                x_end = x_start + self.vru_block_window_len

                in_window = (x_rel_v >= x_start) & (x_rel_v <= x_end)
                if not np.any(in_window):
                    continue

                y_cluster = y_rel_v[in_window]
                w_cluster = w_v[in_window]

                # 合并 VRU 横向占用区间
                intervals = []
                for y_c, w_c in zip(y_cluster, w_cluster):
                    half_w = w_c / 2.0
                    y_obj_min = y_c - half_w - self.lateral_margin
                    y_obj_max = y_c + half_w + self.lateral_margin
                    y_obj_min = max(y_obj_min, lane_y_min)
                    y_obj_max = min(y_obj_max, lane_y_max)
                    if y_obj_min >= y_obj_max:
                        continue
                    intervals.append((y_obj_min, y_obj_max))

                if not intervals:
                    continue

                intervals.sort(key=lambda x: x[0])
                cur_s, cur_e = intervals[0]
                merged = []
                for s_i, e_i in intervals[1:]:
                    if s_i <= cur_e:
                        cur_e = max(cur_e, e_i)
                    else:
                        merged.append((cur_s, cur_e))
                        cur_s, cur_e = s_i, e_i
                merged.append((cur_s, cur_e))

                # 计算车道内剩余最大走廊宽度
                gap_max = 0.0
                if merged[0][0] > lane_y_min:
                    gap_max = max(gap_max, merged[0][0] - lane_y_min)
                for j in range(len(merged) - 1):
                    gap = merged[j + 1][0] - merged[j][1]
                    if gap > gap_max:
                        gap_max = gap
                if merged[-1][1] < lane_y_max:
                    gap_max = max(gap_max, lane_y_max - merged[-1][1])

                required_gap = self.ego_width + self.lateral_margin

                # ⭐ 关键：gap_max < required_gap => 车道内被 VRU 完全挡死
                if gap_max < required_gap:
                    if (best_block_dist is None) or (x_start < best_block_dist):
                        best_block_dist = float(x_start)

            # 如果没有任何窗口把车道“挡死”，说明 VRU 虽在前方但可从车道内绕过
            if best_block_dist is None:
                continue

            d_block = best_block_dist
            if not (self.vru_min_headway <= d_block <= self.vru_max_headway):
                continue

            v = float(v_ego[t])
            limit = float(speed_limit_ms[t])
            if v < self.min_ego_speed_ms or limit <= 1e-3 or v >= self.slow_ratio * limit:
                continue

            vru_full_block_mask[t] = True
            dist[t] = d_block

        return vru_full_block_mask, dist, vru_front_exist_mask

    # ======================
    #   是否按预期的一样，自车未来5帧偏向空余的旁车道
    # ======================
    def is_safe_drive_with_safe_lane(self,
        ego_traj: np.ndarray,
        candidate_mask: np.ndarray,
        safe_side_mask: np.ndarray, # 只在 True 的帧上检查“加速收益”
        lane_centerlines: Dict[int, List[np.ndarray]],
        navi_centerlines: Dict[int, List[Tuple[np.ndarray, int]]],
        future_t = 5, # 看未来5s自车轨迹行驶趋势判断是否里正道越来越近
        safe_proportion = 0.6,
        ):

        T = ego_traj.shape[0]
        mask = np.ones(T, dtype=bool)  # 默认不限制, False就是换错了道(只有右侧可以但换了左侧车道，或者只有左可以换了右侧车道)，需要加倍惩罚

        for t in range(T):
            if candidate_mask[t] is False:
                continue
            # 不可能发生，因为free_side_mask已经滤过一遍了
            if safe_side_mask[t] == [False, False]:
                continue

            safe_left_drive,  safe_right_drive= safe_side_mask[t]

            if safe_left_drive and safe_right_drive:
                mask[t] = True
                continue
            elif safe_left_drive is False and safe_right_drive is False:
                mask[t] = True
                continue

            lines_use: List[np.ndarray] = []

            # 1) 取这一帧候选车道线（navi 优先）
            if t in navi_centerlines and navi_centerlines[t]:
                for centerline, _ in navi_centerlines[t]:
                    lines_use.append(centerline)
            elif t in lane_centerlines and lane_centerlines[t]:
                lines_use.extend(lane_centerlines[t])
            else:
                # 不搞虚拟车道这些东西
                continue

            offsets = self._compute_lane_offsets(ego_traj[t], lines_use)
            # 全是nan则跳过
            if np.sum(np.isnan(offsets)) == len(offsets):
                continue
            ego_idx = int(np.nanargmin(np.abs(offsets)))

            # 2) 有车道线时，先算各条线相对 ego 的横向 offset
            offsets_future_records = []

            t_future_end = min(T,t+future_t)
            for t_future in range(t,t_future_end):
                offsets_future = self._compute_lane_offsets(ego_traj[t_future], lines_use)
                offsets_future_records.append(offsets_future[ego_idx])

            offsets_future_records = np.array(offsets_future_records)
            cur2fur_offset = offsets_future_records[-1] - offsets_future_records[0]

            if safe_left_drive is True:
                if cur2fur_offset >= 0:
                    if np.sum(np.diff(offsets_future_records) > 0) >= safe_proportion * future_t:
                        mask[t] = True
                    else:
                        mask[t] = False
                else:
                    mask[t] = False
                continue

            if safe_right_drive is True:
                if cur2fur_offset <= 0:
                    if np.sum(np.diff(offsets_future_records) < 0) >= safe_proportion * future_t:
                        mask[t] = True
                    else:
                        mask[t] = False
                else:
                    mask[t] = False
                continue

        return mask

    # ======================
    #   旁车道安全判定（含对向）
    # ======================

    def _project_ego_to_centerline(
        self,
        ego_state: np.ndarray,
        centerline: np.ndarray,
    ) -> Optional[float]:
        """
        将 ego 在世界系的位置“纵向投影”到某条车道中心线上：

        - 若存在某个线段 p0->p1，使得 ego 到该线段的垂足落在段内 (t∈[0,1])，
            则找所有这样的垂足中距离 ego 最近的一个；
        - 用该线段的切线方向构造 Frenet 坐标系，返回 ego 相对中心线的横向偏移 lateral；
        - 若无法找到有效垂足，或 |lateral| > 0.5*lane_width_est，则返回 None。
        """
        ex, ey, _ = ego_state
        pts = np.asarray(centerline, dtype=float)
        if pts.shape[0] < 2:
            return None

        best_dist2 = None
        best_lateral = None

        for i in range(pts.shape[0] - 1):
            x0, y0 = pts[i, 0], pts[i, 1]
            x1, y1 = pts[i + 1, 0], pts[i + 1, 1]

            vx = x1 - x0
            vy = y1 - y0
            seg_len2 = vx * vx + vy * vy
            if seg_len2 < 1e-6:
                continue

            # ego 到线段的投影参数 t（在无限长直线上）
            wx = ex - x0
            wy = ey - y0
            t = (wx * vx + wy * vy) / seg_len2

            # 只接受 t∈[0,1] 的垂足，保证是真正投影到线段上
            if t < 0.0 or t > 1.0:
                continue

            # 垂足坐标
            fx = x0 + t * vx
            fy = y0 + t * vy

            dx = ex - fx
            dy = ey - fy
            dist2 = dx * dx + dy * dy

            # 局部 Frenet：切线 t_vec，法向 n_vec
            seg_len = np.sqrt(seg_len2)
            tx = vx / seg_len
            ty = vy / seg_len
            nx = -ty
            ny = tx

            lateral = dx * nx + dy * ny  # ego 相对车道中心线的横向偏移，左正右负（沿车道方向）

            if (best_dist2 is None) or (dist2 < best_dist2):
                best_dist2 = dist2
                best_lateral = lateral

        if best_dist2 is None:
            return None

        # 限制 ego 必须在这条车道“附近”，横向距离小于半个车道宽
        if abs(best_lateral) > 0.5 * self.lane_width_est:
            return None

        return float(best_lateral)

    def _compute_lane_offsets(
        self,
        ego_state: np.ndarray,
        lines: List[np.ndarray],
    ) -> np.ndarray:
        """
        对一组车道线，分别尝试“纵向投影 ego 到车道线上”，返回各自 lateral offset：

        - 若该条车道线无法找到有效垂足，或横向距离超过 0.5*lane_width_est，
            则对应 offset 设为 np.nan；
        - 否则为 ego 相对该车道中心线的横向偏移（Frenet l）。
        """
        offsets: list[float] = []

        for cl in lines:
            off = self._project_ego_to_centerline(ego_state, cl)
            if off is None:
                offsets.append(np.nan)
            else:
                offsets.append(off)

        return np.asarray(offsets, dtype=float)

    def _is_side_lane_safe(
        self,
        ego_traj: np.ndarray,
        v_ego: np.ndarray,
        ego_vel_world: np.ndarray,
        agent_dict: Dict[int, Tuple[np.ndarray, np.ndarray]],
        agent_vel_dict: Dict[int, Tuple[np.ndarray, np.ndarray]],
        timestamps: np.ndarray,
        t_idx: int,
        lane_y_offset: float,
    ) -> bool:
        """
        改进版：检查某一侧相邻车道是否安全

        新增：时序一致性检查 - 不仅看当前帧，还要看前后几帧
        """
        # 多帧检查提高鲁棒性
        check_frames = [t_idx]
        # 向前看2帧，向后看1帧（如果存在）
        if t_idx > 0:
            check_frames.insert(0, t_idx - 1)
        if t_idx > 1:
            check_frames.insert(0, t_idx - 2)
        if t_idx < len(ego_traj) - 1:
            check_frames.append(t_idx + 1)

        # 所有检查帧都必须安全
        for t in check_frames:
            if t < 0 or t >= len(ego_traj):
                continue

            if t not in agent_dict or t not in agent_vel_dict:
                continue

            ids_t, states_t = agent_dict[t]
            if len(ids_t) == 0:
                continue

            _, vel_t = agent_vel_dict[t]
            ego_state = ego_traj[t]
            v_ego_world_t = ego_vel_world[t]
            v_now = float(v_ego[t])

            band_y_min = lane_y_offset - 0.5 * self.lane_width_est
            band_y_max = lane_y_offset + 0.5 * self.lane_width_est

            is_safe = self._check_side_band_safe(
                ego_state=ego_state,
                ego_vel_world=v_ego_world_t,
                agents_state=states_t,
                agents_vel=vel_t,
                band_y_min=band_y_min,
                band_y_max=band_y_max,
                v_ego=v_now,
            )

            if not is_safe:
                return False  # 任何一帧不安全就返回False

        return True

    def _check_side_band_safe(
        self,
        ego_state: np.ndarray,
        ego_vel_world: np.ndarray,
        agents_state: np.ndarray,  # [N, 5] x,y,yaw,len,width
        agents_vel: np.ndarray,  # [N, 2] vx, vy
        band_y_min: float,
        band_y_max: float,
        v_ego: float,
    ) -> bool:
        """
        优化版：更严格的侧向车道安全判定

        改进点：
        1. 增加静态占用检查（车辆当前位置）
        2. 更严格的纵向重叠判定
        3. 考虑车辆宽度的横向侵占
        4. 改进TTC计算，考虑减速场景
        5. 增加密度检查，避免车流密集时误判
        """
        if agents_state.size == 0:
            return True

        ex, ey, eyaw = ego_state
        v_ego_world = ego_vel_world

        # 1) 相对位置（ego 坐标系）
        dx = agents_state[:, 0] - ex
        dy = agents_state[:, 1] - ey
        cy = np.cos(-eyaw)
        sy = np.sin(-eyaw)
        x_rel_agent = cy * dx - sy * dy  # >0 在前，<0 在后
        y_rel_agent = sy * dx + cy * dy

        # 获取车辆宽度
        width_agent = agents_state[:, 4]
        length_agent = agents_state[:, 3]

        # 车辆实际占据的横向范围：[y_center - width/2, y_center + width/2]
        agent_y_min = y_rel_agent - width_agent / 2.0 - self.lateral_margin
        agent_y_max = y_rel_agent + width_agent / 2.0 + self.lateral_margin

        # 检查是否与目标车道带有横向重叠
        lateral_overlap = (agent_y_max >= band_y_min) & (agent_y_min <= band_y_max)

        if not np.any(lateral_overlap):
            return True  # 没有车辆横向侵占这个车道带

        # 只看有横向重叠的车辆
        x_rel_agent = x_rel_agent[lateral_overlap]
        y_rel_agent = y_rel_agent[lateral_overlap]
        vel_agent = agents_vel[lateral_overlap]
        length_agent = length_agent[lateral_overlap]
        width_agent = width_agent[lateral_overlap]

        # 2) 相对速度（投到 ego 前向轴）
        v_rel_world = vel_agent - v_ego_world[None, :]
        v_rel_x_agent = cy * v_rel_world[:, 0] - sy * v_rel_world[:, 1]

        # 3) 动态范围 - 更保守的估计
        v_now = float(v_ego)
        safety_factor = 1.5  # 安全系数
        front_range = max(self.side_front_dist, v_now * self.side_window_time * safety_factor)
        back_range = max(self.side_back_dist, v_now * self.side_window_time * safety_factor)

        # 只看纵向距离在可关注范围内的车
        range_mask = (x_rel_agent > -back_range) & (x_rel_agent < front_range)
        if not np.any(range_mask):
            return True

        x_rel_agent = x_rel_agent[range_mask]
        v_rel_x_agent = v_rel_x_agent[range_mask]
        length_agent = length_agent[range_mask]
        width_agent = width_agent[range_mask]

        # 车流密度检查
        # 如果侧向车道上车辆过于密集，认为不安全
        num_vehicles_in_range = len(x_rel_agent)
        if num_vehicles_in_range >= 3:  # 窗口内有3辆或以上车辆
            # 检查车辆间距
            x_sorted = np.sort(x_rel_agent)
            if len(x_sorted) > 1:
                gaps = np.diff(x_sorted)
                avg_gap = np.mean(gaps)
                # 平均间距小于15米，认为车流密集
                if avg_gap < 15.0:
                    return False

        # 4) 纵向安全距离 - 更保守的计算
        ego_L = float(self.ego_length)
        # 增加车辆尺寸的完整考虑
        safe_gap = self.longitudinal_margin * 2.0  # 增加安全裕度
        half_combined = 0.5 * (ego_L + length_agent) + safe_gap

        # 4.1 更严格的静态重叠检查
        # 当前纵向距离过近（考虑更大的安全距离）
        static_safe_dist = half_combined * 1.2  # 静态安全距离增加20%
        if np.any(np.abs(x_rel_agent) <= static_safe_dist):
            return False

        # 4.2 更严格的动态冲突检查
        # 分别检查前方和后方车辆
        front_mask = x_rel_agent > 0
        rear_mask = x_rel_agent < 0

        # 前方车辆检查
        if np.any(front_mask):
            front_x = x_rel_agent[front_mask]
            front_v = v_rel_x_agent[front_mask]
            front_h = half_combined[front_mask]

            # 前车相对速度为负（前车在远离或速度较慢）
            approaching_front = front_v < -0.5  # 至少0.5m/s的接近速度才考虑
            if np.any(approaching_front):
                fx = front_x[approaching_front]
                fv = front_v[approaching_front]
                fh = front_h[approaching_front]

                # TTC计算 - 考虑制动能力
                rel_speed = -fv  # 接近速度（正值）
                # 从当前位置到接触的时间
                time_to_contact = (fx - fh) / rel_speed

                # 考虑ego可能的加速
                # 假设ego会加速到限速，需要更长的安全时间
                extended_window = self.side_window_time * 1.5

                unsafe = (time_to_contact >= 0) & (time_to_contact <= extended_window)
                if np.any(unsafe):
                    return False

        # 后方车辆检查
        if np.any(rear_mask):
            rear_x = x_rel_agent[rear_mask]
            rear_v = v_rel_x_agent[rear_mask]
            rear_h = half_combined[rear_mask]

            # 后车在追赶（相对速度为正）
            catching_rear = rear_v > 0.5  # 至少0.5m/s的追赶速度
            if np.any(catching_rear):
                rx = rear_x[catching_rear]
                rv = rear_v[catching_rear]
                rh = rear_h[catching_rear]

                # TTC计算
                rel_speed = rv
                time_to_contact = (-rx - rh) / rel_speed

                # 后车追赶需要更严格的判定
                extended_window = self.side_window_time * 1.8  # 后车留更多时间

                unsafe = (time_to_contact >= 0) & (time_to_contact <= extended_window)
                if np.any(unsafe):
                    return False

        # 速度一致性检查
        # 如果侧向车道车辆平均速度显著低于ego，可能是拥堵
        if len(vel_agent) > 0:
            agent_speeds = np.linalg.norm(vel_agent, axis=1)
            avg_agent_speed = np.mean(agent_speeds)
            ego_speed = np.linalg.norm(v_ego_world)

            # 如果侧向车道平均速度低于ego的60%，认为可能拥堵
            if avg_agent_speed < ego_speed * 0.6 and ego_speed > 5.0:
                # 进一步检查是否有多辆慢车
                slow_cars = agent_speeds < ego_speed * 0.7
                if np.sum(slow_cars) >= 2:
                    return False

        return True

    def _compute_free_side_mask_with_lanes(
        self,
        ego_traj: np.ndarray,
        v_ego: np.ndarray,
        ego_vel_world: np.ndarray,
        agent_dict: Dict[int, Tuple[np.ndarray, np.ndarray]],
        agent_vel_dict: Dict[int, Tuple[np.ndarray, np.ndarray]],
        timestamps: np.ndarray,
        lane_centerlines: Dict[int, List[np.ndarray]],
        navi_centerlines: Dict[int, List[Tuple[np.ndarray, int]]],
        solid_lanes: Dict[int, List[np.ndarray]],
    ) -> np.ndarray:
        """
        侧向车道安全判定（含对向）：

        - 若有 navi_centerlines：优先用 navi 的车道线；
        - 否则用 lane_centerlines；
        - 选 ego “横向最近”的那条线作为 ego 所在车道线，
          但要求 ego 到该车道中心线的横向距离 |offset| < 0.5 * lane_width_est，
          否则认为 ego 不在任何已知车道附近，退化为 use_mode="ego"（用虚拟车道）。
        - 在已有 ego 车道线的前提下，根据 lane_width_est 找左/右相邻车道，
          再用 _is_side_lane_safe 判侧向车道安全。
        """
        T = ego_traj.shape[0]
        mask = np.zeros(T, dtype=bool)
        safe_side_list = [[False, False]] * T
        half_lane_width = 0.5 * self.lane_width_est

        lat_window = max(4.0 * self.lane_width_est, 20.0)
        long_window = 30.0

        for t in range(T):
            if t == 20:
                a = 0
            lines_use: List[np.ndarray] = []

            # 1) 取这一帧候选车道线（navi 优先）
            if t in navi_centerlines and navi_centerlines[t]:
                for centerline, _ in navi_centerlines[t]:
                    lines_use.append(centerline)
            elif t in lane_centerlines and lane_centerlines[t]:
                lines_use.extend(lane_centerlines[t])
            else:
                # 没有任何车道线，直接用 ego-level 虚拟车道
                mask[t] = self._compute_free_side_without_lanes(
                    ego_traj, v_ego, ego_vel_world, agent_dict, agent_vel_dict, timestamps, t
                )
                continue

            # 2) 有车道线时，先算各条线相对 ego 的横向 offset
            offsets = self._compute_lane_offsets(ego_traj[t], lines_use)
            if offsets.size == 0 or np.all(np.isnan(offsets)):
                # 所有线都投影失败，退化为 ego 模式
                mask[t] = self._compute_free_side_without_lanes(
                    ego_traj, v_ego, ego_vel_world, agent_dict, agent_vel_dict, timestamps, t
                )
                continue

            # 3) 选“横向最近”的那条线作为候选 ego 车道线
            abs_offsets = np.abs(offsets)
            ego_idx = int(np.nanargmin(abs_offsets))
            ego_offset = float(offsets[ego_idx])

            #  关键更新：ego 必须在这条线附近（横向距离 < 半个车道宽）
            if abs(ego_offset) > half_lane_width:
                # ego 距离最近的中心线也太远，认为 ego 不在已知车道上，退化为 ego 模式
                mask[t] = self._compute_free_side_without_lanes(
                    ego_traj, v_ego, ego_vel_world, agent_dict, agent_vel_dict, timestamps, t
                )
                continue

            # 4) 在 lane 模式下，根据 ego 所在车道线的 offset 找左右相邻车道线
            left_min = self.adj_lane_min_factor * self.lane_width_est
            left_max = self.adj_lane_max_factor * self.lane_width_est
            right_min = -left_max
            right_max = -left_min

            x_solid, y_solid = self._project_polylines_once(
                ego_traj[t], solid_lanes.get(t, []), long_window=long_window, lat_window=lat_window
            )
            left_solid_y, right_solid_y = self._nearest_left_right_from_y(y_solid)

            left_max_with_solidline = min(left_solid_y, ego_offset + left_max) if left_solid_y is not None else ego_offset + left_max
            right_min_with_solidline = max(right_solid_y, ego_offset+right_min) if right_solid_y is not None else  ego_offset+right_min

            left_side_offset: Optional[float] = None
            right_side_offset: Optional[float] = None

            # 左侧车道：offset 大于 ego_offset，且在 [ego_offset + left_min, ego_offset + left_max] 附近
            left_candidates = np.where((offsets > ego_offset + left_min) & (offsets < left_max_with_solidline))[0]
            if left_candidates.size > 0:
                idx = left_candidates[np.argmin(np.abs(offsets[left_candidates] - (ego_offset + self.lane_width_est)))]
                left_side_offset = float(offsets[idx])

            # 右侧车道：offset 小于 ego_offset，且在 [ego_offset + right_min, ego_offset + right_max] 附近
            right_candidates = np.where((offsets < ego_offset + right_max) & (offsets > right_min_with_solidline))[0]
            if right_candidates.size > 0:
                idx = right_candidates[
                    np.argmin(np.abs(offsets[right_candidates] - (ego_offset - self.lane_width_est)))
                ]
                right_side_offset = float(offsets[idx])

            lane_safe_any = False

            if left_side_offset is not None:
                if self._is_side_lane_safe(
                    ego_traj, v_ego, ego_vel_world, agent_dict, agent_vel_dict, timestamps, t, left_side_offset
                ):
                    lane_safe_any = True
                    safe_side_list[t][0] = True

            if right_side_offset is not None:
                if self._is_side_lane_safe(
                    ego_traj, v_ego, ego_vel_world, agent_dict, agent_vel_dict, timestamps, t, right_side_offset
                ):
                    lane_safe_any = True
                    safe_side_list[t][1] = True

            # 如果找不到左右车道线，那就退化为 ego-level 虚拟车道判定
            if (left_side_offset is None) and (right_side_offset is None):
                lane_safe_any = self._compute_free_side_without_lanes(
                    ego_traj, v_ego, ego_vel_world, agent_dict, agent_vel_dict, timestamps, t
                )

            mask[t] = lane_safe_any

        return mask, safe_side_list


    # ======================
    #   Road-edge / Solid projection（带 bbox 过滤）
    # ======================

    def _project_polylines_once(
        self,
        ego_state: np.ndarray,
        polylines_t: List[np.ndarray],
        *,
        long_window: float,
        lat_window: float,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        通用：对当前时刻 t 的每一条 polyline，计算其到 ego 最近投影点，
        并返回投影点在 ego 坐标系下的 (x_rel, y_rel)。

        先 bbox 粗过滤，再点到折线投影 early_stop=True。
        仅保留 |x_rel| <= long_window 的投影点。
        """
        if not polylines_t:
            return np.zeros(0, dtype=float), np.zeros(0, dtype=float)

        ex, ey, eyaw = ego_state
        cy = np.cos(-eyaw)
        sy = np.sin(-eyaw)

        x_list: List[float] = []
        y_list: List[float] = []

        for pl in polylines_t:
            pts = np.asarray(pl, dtype=float)
            if pts.shape[0] < 2:
                continue

            # bbox 过滤：若 ego 在 bbox 外较远（含 margin），直接跳过
            x_min, y_min = np.min(pts[:, :2], axis=0)
            x_max, y_max = np.max(pts[:, :2], axis=0)
            if (
                (ex < x_min - long_window)
                or (ex > x_max + long_window)
                or (ey < y_min - lat_window)
                or (ey > y_max + lat_window)
            ):
                continue

            d2, fx, fy, _ = self._project_point_to_polyline(ex, ey, pts[:, :2], early_stop=True)
            dx = fx - ex
            dy = fy - ey
            x_rel = cy * dx - sy * dy
            y_rel = sy * dx + cy * dy

            if abs(x_rel) > long_window:
                continue
            x_list.append(float(x_rel))
            y_list.append(float(y_rel))

        if not x_list:
            return np.zeros(0, dtype=float), np.zeros(0, dtype=float)
        return np.asarray(x_list, dtype=float), np.asarray(y_list, dtype=float)

    def _nearest_left_right_from_y(self, y_arr: np.ndarray) -> Tuple[Optional[float], Optional[float]]:
        left_y: Optional[float] = None
        right_y: Optional[float] = None
        if y_arr.size == 0:
            return left_y, right_y
        mask_left = y_arr > 0.0
        if np.any(mask_left):
            left_y = float(np.min(y_arr[mask_left]))
        mask_right = y_arr < 0.0
        if np.any(mask_right):
            right_y = float(np.max(y_arr[mask_right]))
        return left_y, right_y

    # ---------- 通用：点到折线投影（统一入口） ----------

    def _project_point_to_polyline(
        self,
        px: float,
        py: float,
        polyline_xy: np.ndarray,
        *,
        early_stop: bool = False,
    ) -> Tuple[float, float, float, int]:
        """
        统一的“点到折线投影”函数（世界坐标系）.

        参数：
          px, py: 点坐标
          polyline_xy: np.ndarray[P,2]，折线的所有点
          early_stop: 若为 True，则在找到“垂足落在段内（未 clamped t0∈(0,1)）”
                      的线段后立即返回（折线近似长直线或圆弧的启发式）。

        返回：
          dist2:   最近点的距离平方
          fx, fy:  最近投影点坐标
          seg_t:   最近投影点所在段的参数 t（clamp 后，∈[0,1]）
          seg_idx: 该线段的起点索引 i（段为 [i, i+1]）
        """
        pts = np.asarray(polyline_xy, dtype=float)
        assert pts.shape[0] >= 2

        best_d2 = float("inf")
        best_fx, best_fy = float(px), float(py)
        best_idx = 0

        for i in range(pts.shape[0] - 1):
            x0, y0 = pts[i]
            x1, y1 = pts[i + 1]
            vx = x1 - x0
            vy = y1 - y0
            seg_len2 = vx * vx + vy * vy
            if seg_len2 < 1e-6:
                continue

            wx = px - x0
            wy = py - y0
            t0 = (wx * vx + wy * vy) / seg_len2  # unclamped

            if early_stop and (0.0 < t0 < 1.0):
                # 垂足落在线段内，直接投影并立即返回
                fx = x0 + t0 * vx
                fy = y0 + t0 * vy
                dx = fx - px
                dy = fy - py
                d2 = dx * dx + dy * dy
                return d2, fx, fy, i

            t = float(np.clip(t0, 0.0, 1.0))
            fx = x0 + t * vx
            fy = y0 + t * vy
            dx = fx - px
            dy = fy - py
            d2 = dx * dx + dy * dy
            if d2 < best_d2:
                best_d2 = d2
                best_fx, best_fy = fx, fy
                best_idx = i

        # 这里返回的 seg_t 没被上层使用，保留 0.0
        return best_d2, best_fx, best_fy, best_idx

    def _compute_free_side_without_lanes(
        self,
        ego_traj: np.ndarray,
        v_ego: np.ndarray,
        ego_vel_world: np.ndarray,
        agent_dict: Dict[int, Tuple[np.ndarray, np.ndarray]],
        agent_vel_dict: Dict[int, Tuple[np.ndarray, np.ndarray]],
        timestamps: np.ndarray,
        t_idx: int,
    ) -> bool:
        """
        无车道线时：左右各构造一个“虚拟车道带”，分别检查是否安全。
        左右任一侧安全，就认为“旁车道有空间”。
        """
        if t_idx not in agent_dict or t_idx not in agent_vel_dict:
            return True

        ids_t, states_t = agent_dict[t_idx]
        if len(ids_t) == 0:
            return True

        _, vel_t = agent_vel_dict[t_idx]

        ego_state = ego_traj[t_idx]
        v_ego_world = ego_vel_world[t_idx]
        v_now = float(v_ego[t_idx])

        # ego 左右的虚拟车道带：以 ego y=0 为中心
        ego_half_w = 0.5 * self.ego_width
        side_inner = ego_half_w + self.lateral_margin
        side_outer = ego_half_w + 1.5 * self.lane_width_est

        # 左侧带： y ∈ [+side_inner, +side_outer]
        left_safe = self._check_side_band_safe(
            ego_state=ego_state,
            ego_vel_world=v_ego_world,
            agents_state=states_t,
            agents_vel=vel_t,
            band_y_min=side_inner,
            band_y_max=side_outer,
            v_ego=v_now,
        )

        # 无车道时，认为是小路，仅检查左侧，不检查右侧
        # 右侧带： y ∈ [-side_outer, -side_inner]
        # right_safe = self._check_side_band_safe(
        #     ego_state=ego_state,
        #     ego_vel_world=v_ego_world,
        #     agents_state=states_t,
        #     agents_vel=vel_t,
        #     band_y_min=-side_outer,
        #     band_y_max=-side_inner,
        #     v_ego=v_now,
        # )

        # return left_safe or right_safe
        return left_safe

    # ======================
    #   segment 提取
    # ======================

    def _extract_segments(
        self,
        mask: np.ndarray,
        dt_array: np.ndarray,
        min_duration: float,
    ) -> List[Tuple[int, int]]:
        T = mask.shape[0]
        segments: List[Tuple[int, int]] = []

        in_seg = False
        seg_start = 0

        for t in range(T):
            if mask[t]:
                if not in_seg:
                    in_seg = True
                    seg_start = t
            else:
                if in_seg:
                    seg_end = t - 1
                    duration = float(np.sum(dt_array[seg_start : seg_end + 1]))
                    if duration >= min_duration:
                        segments.append((seg_start, seg_end))
                    in_seg = False

        if in_seg:
            seg_end = T - 1
            duration = float(np.sum(dt_array[seg_start : seg_end + 1]))
            if duration >= min_duration:
                segments.append((seg_start, seg_end))

        return segments

    def compute_reward(
        self,
        ego_traj: np.ndarray,
        speed_limits_kph: np.ndarray,
        min_active_speed_mps: float = 1.0,
        max_penalty: float = 4,
        ratio_thres: float = 0.9,
    ):
        speed_limits_mps = speed_limits_kph / 3.6
        speeds = np.diff(ego_traj[:, :2], axis=0)
        speeds = np.concatenate([speeds, speeds[[-1]]], axis=0)
        speeds = np.linalg.norm(speeds, axis=1) * 5  # 5hz
        ratio = speeds / (speed_limits_mps + 1e-3)
        penalty = np.clip((ratio_thres - ratio) / (ratio_thres), a_min=0, a_max=1.0) * max_penalty
        penalty[(speed_limits_mps < 1e-3) | (speeds < min_active_speed_mps)] = 0
        return penalty


def check_clip(clip_idx):
    # info = pkl.load(open(f"./tmp2/{clip_idx}.pkl", "rb"))
    info = pkl.load(open(f"/home/charlie.cheng1/ws/melange-rl/tmp3/{clip_idx}.pkl", "rb"))

    detector = SlowFollowDetectorV3(
        ego_length=4.5,
        ego_width=2.0,
        min_ego_speed_ms=1.38,  # ~5kph #2.78,  # ~10 kph
        slow_ratio=0.9,  # 低于 0.5 * 限速算“慢”
        min_segment_duration=4.0,  # 满足条件至少 10 秒算跟慢车场景
        min_junction_dist=50.0,  # 距 navi 最晚变道点大于此值才算“非路口”（m）
    )
    is_slow_scene, segments = detector.detect(**info["input"])
    print(f"[{clip_idx}]is_slow_scene:{is_slow_scene}")
    for seg in enumerate(segments):
        print(f"\t{seg}")
    return is_slow_scene, segments


if "__main__" == __name__:
    import pickle as pkl

    setup_logging_simple()

    check_clip(12)
    exit(0)
    for i in range(29):
        is_slow_scene, segments = check_clip(i)
        # print(f"[{i}]is_slow_scene:{is_slow_scene}")
        # for seg in enumerate(segments):
        #     print(f"\t{seg}")

    exit(0)

    info = pkl.load(open("./tmp2/0.pkl", "rb"))

    detector = SlowFollowDetectorV3(
        ego_length=4.5,
        ego_width=2.0,
        min_ego_speed_ms=1.38,  # ~5kph #2.78,  # ~10 kph
        slow_ratio=0.9,  # 低于 0.5 * 限速算“慢”
        min_segment_duration=4.0,  # 满足条件至少 10 秒算跟慢车场景
        min_junction_dist=50.0,  # 距 navi 最晚变道点大于此值才算“非路口”（m）
    )
    is_slow_scene, segments = detector.detect(**info["input"])

    print(f"is_slow_scene:{is_slow_scene}")
    for i, seg in enumerate(segments):
        print(f"[{i: 2d}] :slow segment: {seg}")
