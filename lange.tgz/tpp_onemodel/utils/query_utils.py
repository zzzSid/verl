# -*- coding: utf-8 -*-
from typing import Any
from typing import Dict

import torch

from tpp_onemodel.utils.planner_constants import PlannerConstants


_planner_consts = PlannerConstants()


def modify_lane_types(lane_types, mask):
    """
    将 `lane_types` 张量中满足条件的元素替换为 -1。

    参数：
    - lane_types: torch.Tensor，形状为 (batch_size, 30, 50)
    - mask: torch.Tensor，形状为 (batch_size,)，元素为布尔类型

    返回：
    - 修改后的 lane_types（原地修改）
    """
    batch_size = lane_types.size(0)

    # 确保 mask 是布尔类型
    mask = ~mask.bool()

    # 将 mask 形状调整为 (batch_size, 1, 1)，以便广播
    batch_mask = mask.view(batch_size, 1, 1)

    # 创建一个掩码，标记 lane_types 中等于 2 的位置
    type_mask = lane_types == 2

    # 合并掩码，在批次维度和类型维度上同时满足条件
    combined_mask = batch_mask & type_mask

    # 将满足条件的位置替换为 -1
    lane_types[combined_mask] = -1

    return lane_types


def find_closest_stop_points(navi_lane_stoppoints, navi_lane_tld, default_point=[500, 0]):
    # 获取形状信息
    batch_size, num_lanes, points_num, _ = navi_lane_stoppoints.shape

    # 创建掩码
    tld_red_mask = (navi_lane_tld[..., 0] == 1) | (
        (navi_lane_tld[..., 0] == 2) & (navi_lane_tld[..., 1] != 1)
    )  # 形状：(batch_size, num_lanes)
    x_positive_mask = navi_lane_stoppoints[..., 0] > 0  # 形状：(batch_size, num_lanes, points_num)
    mask = x_positive_mask & tld_red_mask.unsqueeze(2)  # 形状：(batch_size, num_lanes, points_num)

    # 计算沿 points_num 维度的累计和
    # import pdb; pdb.set_trace()
    cumsum_mask = mask.int().cumsum(dim=2)

    # 获取第一个满足条件的点的掩码（累计和为 1 的位置）
    first_valid_mask = cumsum_mask == 1  # 形状：(batch_size, num_lanes, points_num)

    # 获取 x 和 y 坐标
    x_coords = navi_lane_stoppoints[..., 0]  # 形状：(batch_size, num_lanes, points_num)
    y_coords = navi_lane_stoppoints[..., 1]  # 形状：(batch_size, num_lanes, points_num)

    # 使用 first_valid_mask 选择第一个满足条件的 x 和 y 值
    # 由于 first_valid_mask 在满足条件的位置为 1，其余为 0
    # 我们可以通过乘积和求和来获取第一个满足条件的坐标
    selected_x = (x_coords * first_valid_mask.float()).sum(dim=2)  # 形状：(batch_size, num_lanes)
    selected_y = (y_coords * first_valid_mask.float()).sum(dim=2)  # 形状：(batch_size, num_lanes)

    # 修改这里，使用 sum 代替 any
    mask_sum = mask.float().sum(dim=2)  # 形状：(batch_size, num_lanes)
    has_valid_point = mask_sum > 0  # 形状：(batch_size, num_lanes)

    # 创建默认值张量
    default_x = torch.full_like(selected_x, default_point[0])
    default_y = torch.full_like(selected_y, default_point[1])

    # 使用 torch.where 选择有有效点的坐标，否则使用默认值
    final_x = torch.where(has_valid_point, selected_x, default_x)
    final_y = torch.where(has_valid_point, selected_y, default_y)

    # 将 x 和 y 坐标组合
    min_values = torch.stack([final_x, final_y], dim=-1)  # 形状：(batch_size, num_lanes, 2)

    return min_values, tld_red_mask.int().sum(dim=1)


# flake8: noqa # pylint: disable=C0103 disable=no-self-use
def gen_ego_closest_index(inputs: Dict[str, Any], intention_points: Dict[int, Any], batch_size: int):
    """
    generate the best one index of intention query, by L2 distance to ego.

    Args:
        inputs (Dict[str, Any]): Inputs of batchdata,

    Returns:
        mask(Torch.Tensor[bool]): [B,32]
        gt_traj_mask_end(Torch.Tensor[float32]): [B,1]
    """
    gt_traj_end = inputs["egos_pred_gt"][:, :, -1, :2]
    gt_traj_mask_end = inputs["egos_pred_mask"][:, :, -1]
    ego_points = intention_points[1].unsqueeze(0).repeat(batch_size, 1, 1)
    sum_squared_diff = torch.sum((ego_points - gt_traj_end) ** 2, dim=2)
    min_indices = sum_squared_diff.argmin(dim=1)
    mask = torch.zeros_like(sum_squared_diff)
    mask = mask.scatter_(1, min_indices.unsqueeze(1).long(), 1)
    mask = mask.bool()
    return mask, gt_traj_mask_end


def gen_navi_line_closest_index(
    inputs: Dict[str, Any],
    traj,
    use_fde: bool,
    navi_lateral_dist_mask_threshold: float = -1,
    use_lateral_dist: bool = False,
    route_type="navi_line",
    select_scenes=None,
    only_return_dist=False,
    ego_future_frames_num=35,
):
    """
    generate the best one index of navi line query, by L2 distance to ego future final point.
    Args:
        inputs (Dict[str, Any]): Inputs of batchdata,
        traj (Torch.Tensor[float32]): [B,1,T,D] # maybe [B,K,T,D]
        use_fde (bool): whether use final distance error
    Returns:
        min_index(Torch.Tensor[int]): [B]
        navi_line_mask(Torch.Tensor[bool]): [B,M]
        dist_s(Torch.Tensor[float32]): [B,M,T]
        dist_l(Torch.Tensor[float32]): [B,M,T]
        nearest_point_mask(Torch.Tensor[bool]): [B,M,T]
    """

    navi_line_points = inputs["navi_line_points"]  # B M L D
    navi_line_types = inputs["navi_line_types"]  # B M L

    # traj_mask = inputs["egos_pred_mask"]  # B 1 T
    traj_mask = inputs["egos_pred_mask"][..., :ego_future_frames_num]
    multi_mode_traj_flag = traj.shape[1] != 1
    if multi_mode_traj_flag:
        k_mod = traj.shape[1]
        traj = traj.reshape(-1, 1, traj.shape[2], traj.shape[3])  # [B*NS,1,T,D]
        traj_mask = traj_mask.repeat(1, k_mod, 1).reshape(-1, 1, traj_mask.shape[2])  # [B*NS,1,T]
        navi_line_points = (
            navi_line_points.unsqueeze(1)
            .repeat(1, k_mod, 1, 1, 1)
            .reshape(-1, navi_line_points.shape[1], navi_line_points.shape[2], navi_line_points.shape[3])
        )  # [B*NS,M,L,D]
        navi_line_types = (
            navi_line_types.unsqueeze(1)
            .repeat(1, k_mod, 1, 1)
            .reshape(-1, navi_line_types.shape[1], navi_line_types.shape[2])
        )  # [B*NS,M,L]

    b, _, t, _ = traj.shape

    # navi_line_points = inputs["navi_line_points"]  # B M L D
    # navi_line_types = inputs["navi_line_types"]  # B M L

    navi_line_point_mask = navi_line_types != -1  # [B, M, L], valid = 1.0
    navi_line_mask = navi_line_point_mask[:, :, 0]
    scene_num = len(select_scenes)
    batch_size = navi_line_mask.shape[0]
    query_num = navi_line_mask.shape[1] // scene_num
    navi_scene_mask = navi_line_mask.new_zeros((batch_size, scene_num))
    navilane_scene_idx = inputs["navilane_scene_idx"]  # [B]
    navilane_scene_idx = torch.clamp(navilane_scene_idx, 0)
    if multi_mode_traj_flag:
        navilane_scene_idx = navilane_scene_idx.unsqueeze(1).repeat(1, k_mod).flatten(0, 1)  # [B*NS]
    navi_scene_mask.scatter_(1, navilane_scene_idx.unsqueeze(1), True)
    navi_line_mask = navi_line_mask.reshape(batch_size, scene_num, query_num)
    navi_line_mask = navi_line_mask * navi_scene_mask.unsqueeze(2)  # [B, M]
    navi_line_mask = navi_line_mask.reshape(batch_size, scene_num * query_num)
    navi_line_point_mask = navi_line_point_mask * navi_line_mask.unsqueeze(2)  # [B, M, L]

    b, m, l, _ = navi_line_points.shape

    # Get the distance between each trajectory and each navigation line
    # Cal navigation line heading
    # First: get navi_line_points_diff
    navi_line_points_diff = navi_line_points[:, :, 1:] - navi_line_points[:, :, :-1]  # (B, M, L-1, D)
    navi_line_points_diff = torch.cat(
        [navi_line_points_diff, navi_line_points_diff[:, :, -1:, :]], dim=-2
    )  # (B, M, L, D)

    # Second: use cdist to calculate the distance between traj and navi_line_points
    traj_expanded = traj.expand(-1, m, -1, -1)  # (B, M, T, D) navi_line_points (B, M, L, D)
    distances = torch.cdist(traj_expanded, navi_line_points, p=2.0)  # (B, M, T, L)

    # Third: find nearest distance and index and lane point heading
    navi_line_point_mask_expanded = navi_line_point_mask.unsqueeze(2)  # (B, M, L) ->  (B, M, 1, L)
    combined_mask = traj_mask.unsqueeze(3) * navi_line_point_mask_expanded  # (B, M, T, L)
    masked_distances = distances.masked_fill(~combined_mask.bool(), 1e6)  # (B, M, T, L)
    nearest_dist_index = masked_distances.argmin(dim=-1)  # (B, M, T)
    nearest_point_mask = (
        torch.gather(combined_mask, 3, nearest_dist_index.unsqueeze(-1)).squeeze(-1).float()
    )  # (B, M, T)

    # Decompose the distance into S and L direction
    nearest_dist_index_expanded = nearest_dist_index.unsqueeze(-1).expand(-1, -1, -1, 2)
    nearest_lane_points = torch.gather(navi_line_points, dim=2, index=nearest_dist_index_expanded)  # => (B, M, T, 2)
    nearest_traj_navilane_diff = traj_expanded - nearest_lane_points  # (B, M, T, 2)

    nearest_navilane_points_diff = torch.gather(
        navi_line_points_diff, dim=2, index=nearest_dist_index_expanded
    ).squeeze(3)
    dist_s = torch.sum(nearest_traj_navilane_diff * nearest_navilane_points_diff, dim=-1) / (
        torch.norm(nearest_navilane_points_diff, dim=-1) + 1e-6
    )
    dist_s = torch.abs(dist_s + ((1 - nearest_point_mask) * _planner_consts.MAX_VAL))  # (B, M, T)
    dist_l = (
        nearest_traj_navilane_diff[..., 0] * nearest_navilane_points_diff[..., 1]
        - nearest_traj_navilane_diff[..., 1] * nearest_navilane_points_diff[..., 0]
    )
    dist_l = dist_l / (torch.norm(nearest_navilane_points_diff, dim=-1) + 1e-6)
    dist_l = torch.abs(dist_l * nearest_point_mask + ((1 - nearest_point_mask) * _planner_consts.MAX_VAL))  # (B, M, T)

    if only_return_dist or multi_mode_traj_flag:
        if multi_mode_traj_flag:
            dist_s = dist_s.reshape(b // k_mod, k_mod, m, t)  # [B, M, T] -> [B//K, K, M, T]
            dist_l = dist_l.reshape(b // k_mod, k_mod, m, t)  # [B, M, T] -> [B//K, K, M, T]
        return None, None, dist_s, dist_l, None

    if use_lateral_dist:
        # find closest points in line and get ade for every line
        # if (traj_mask[:, 0, -1] == 0).any():
        #     print(1)
        if use_fde:
            mask_valid = torch.abs(dist_l - _planner_consts.MAX_VAL) > _planner_consts.EPSILON  # (B, M, T)
            dist_l_reversed = torch.flip(dist_l, dims=[-1])  # (B, M, T)
            mask_valid_reversed = torch.flip(mask_valid, dims=[-1])  # (B, M, T)
            mask_valid_reversed_int = mask_valid_reversed.long()  # (B, M, T)
            first_valid_indices = torch.argmax(mask_valid_reversed_int, dim=-1)  # (B, M)
            no_valid_distance = mask_valid_reversed_int.sum(dim=-1) == 0  # (B, M)
            indices = first_valid_indices.unsqueeze(-1)  # (B, M, 1)
            valid_distance = torch.gather(dist_l_reversed, -1, indices).squeeze(-1)  # (B, M)
            max_val_tensor = torch.full((1,), _planner_consts.MAX_VAL, device="cuda")
            valid_distance = torch.where(no_valid_distance, max_val_tensor, valid_distance)
        else:
            valid_distance = dist_l.sum(-1)  # B M T L -> B M T -> B M
    else:
        valid_distance = masked_distances.min(dim=-1)[0]  # B M T L -> B M T
        if use_fde:
            valid_distance = valid_distance[..., -1]
        else:
            valid_distance = valid_distance.sum(-1)  # B M T L -> B M T -> B M

    _, min_index = valid_distance.min(dim=1)  # (B, L) -> B

    if navi_lateral_dist_mask_threshold != -1:
        # if all navi_lines are invalid, mask them all
        # 1 for masked, 0 for unmasked
        invalid_mask = (valid_distance.min(-1)[0] > navi_lateral_dist_mask_threshold)[:, None].expand(
            (-1, navi_line_points.shape[1])
        )  # [B,M]
        # 1 for valid, 0 for invalid
        navi_line_mask = navi_line_mask * (1 - invalid_mask.float())  # [B,M]*[B,M] -> [B,M]
    return min_index, navi_line_mask, dist_s, dist_l, nearest_point_mask


def parallel_searchsorted(cumulative_distances, target_distances):
    # Expand dimensions for broadcasting
    target_distances_expanded = target_distances.unsqueeze(-1)  # [B*M, N, 1]
    cumulative_distances_expanded = cumulative_distances.unsqueeze(1)  # [B*M, 1, N]

    # Create a mask where cumulative_distances are greater than or equal to target_distances
    mask = cumulative_distances_expanded > target_distances_expanded  # [B*M, N, N]

    # Find the first occurrence where the mask is True along the last dimension
    segment_indices = torch.argmax(mask.int(), dim=-1) - 1  # [B*M, N]

    # Handle cases where no valid index is found
    no_valid_index_mask = mask.sum(dim=-1) == 0  # [B*M, N]
    # segment_indices[no_valid_index_mask] = cumulative_distances.size(1) - 1
    zero_mask = segment_indices >= 0
    segment_indices_mask_zero = segment_indices * zero_mask
    segment_indices_mask_invalid = (
        segment_indices_mask_zero * no_valid_index_mask.logical_not()
        + (segment_indices_mask_zero * 0 + cumulative_distances.shape[-1] - 1) * no_valid_index_mask
    )

    return segment_indices_mask_invalid


def sample_navi_points(navi_line_points, navi_line_types, sample_intervel, sample_point_num, pad_non_valid=True):
    # Compute segment lengths and cumulative distances
    reshaped_points = navi_line_points.reshape(-1, navi_line_points.size(-2), navi_line_points.size(-1))  # [B*M, N, 2]
    reshaped_points_valid_mask = (navi_line_types != -1).reshape(-1, navi_line_types.size(-1))  # [B*M,N] valid=1

    segment_lengths = torch.sqrt(
        torch.sum((reshaped_points[:, 1:] - reshaped_points[:, 0:-1]) ** 2, dim=2)
    )  # [B*M, N-1]
    segment_lengths = segment_lengths * reshaped_points_valid_mask[:, 1:]  # [B*M, N-1]
    cumulative_distances = torch.cat(
        [
            torch.zeros((reshaped_points.size(0), 1), device="cuda"),
            torch.cumsum(segment_lengths, dim=1),
        ],
        dim=1,
    )  # [B*M,N]

    # generate target target_distances
    target_len = sample_intervel * sample_point_num  # 400m
    target_distances = (
        # torch.linspace(0, target_len, sample_point_num + 1, device=reshaped_points.device)
        torch.arange(0, target_len, sample_intervel, device="cuda")
        .float()
        .unsqueeze(0)
        .repeat(reshaped_points.size(0), 1)
    )  # [B*M, N]
    # target_distances_valid_mask = target_distances < cumulative_distances[:,-1:]
    # target_distances = target_distances*target_distances_valid_mask + cumulative_distances[:,-1:]*target_distances_valid_mask.logical_not()
    # target_distances = torch.clamp(target_distances, target_distances * 0, cumulative_distances[:, -1:].int())
    target_distances_min = torch.clamp(target_distances, min=0)

    # find the closest index
    # segment_indices = (
    #     torch.searchsorted(cumulative_distances, target_distances, right=True) - 1
    # ).contiguous()  # [B*M, N]
    segment_indices = parallel_searchsorted(cumulative_distances, target_distances)  # [B*M, N]
    segment_indices_invalid_mask = ((segment_indices) < 0).logical_or(
        (segment_indices >= segment_lengths.size(1))
    )  # [B*M, N]
    # Ensure segment_indices are within valid range
    segment_indices = torch.clamp(segment_indices, 0, segment_lengths.size(1) - 1)

    segment_lengths_at_indices = torch.clamp(segment_lengths.gather(1, segment_indices), min=1e-10)  # [B*M, N]
    # Compute proportions between left and right points
    segment_start_distances = cumulative_distances.gather(1, segment_indices)  # [B*M, N]
    proportions = (target_distances - segment_start_distances) / (segment_lengths_at_indices + 1e-6)
    proportions = torch.clamp(proportions, 0, 1)  # [B*M, N]
    # Interpolate between left and right points
    left_points = reshaped_points.gather(1, segment_indices.unsqueeze(-1).expand(-1, -1, reshaped_points.size(2)))
    right_points = reshaped_points.gather(
        1, (segment_indices + 1).unsqueeze(-1).expand(-1, -1, reshaped_points.size(2))
    )
    sampled_points = left_points + proportions.unsqueeze(-1) * (right_points - left_points)

    # Padding with last point value
    reversed_mask = torch.flip(segment_indices_invalid_mask, dims=[1])
    last_false_positions = (reversed_mask < 1).int().argmax(dim=1)
    last_false_positions = segment_indices_invalid_mask.size(1) - 1 - last_false_positions
    last_false_positions = torch.clamp(last_false_positions, 0, sampled_points.size(1) - 1)
    index = last_false_positions.unsqueeze(-1).unsqueeze(-1).expand(-1, 1, sampled_points.size(2))
    sampled_last_points = torch.gather(sampled_points, 1, index).squeeze(1)  # [B*M,2]

    if pad_non_valid:
        sampled_points = (
            sampled_points * segment_indices_invalid_mask[..., None].logical_not()
            + sampled_last_points[:, None, :] * segment_indices_invalid_mask[..., None]
        )
    else:
        sampled_points = (
            sampled_points * segment_indices_invalid_mask[..., None].logical_not()
            - segment_indices_invalid_mask[..., None].float()
        )

    # Generate sampled types
    navi_invalid_mask = (reshaped_points_valid_mask == 0).all(-1)  # [B*M]
    segment_indices_invalid_mask = segment_indices_invalid_mask.logical_or(navi_invalid_mask[:, None])  # [B*M,N]
    sampled_types = (
        -1 * segment_indices_invalid_mask + navi_line_types.max() * segment_indices_invalid_mask.logical_not()
    )
    return sampled_points.reshape(
        navi_line_points.size(0), navi_line_points.size(1), -1, navi_line_points.size(3)
    ), sampled_types.reshape(navi_line_points.size(0), navi_line_points.size(1), -1)
    # import numpy as np
    # path = "/home/mccree.zhao/project/offline/2024/melange_all/2024_08/melange_navi_0807"
    # points_cmp = torch.Tensor(np.load(f"{path}/points.npy")).to(navi_line_points.device)
    # segment_lengths_cmp = torch.Tensor(np.load(f"{path}/segment_lengths.npy")).to(navi_line_points.device)
    # cumulative_distances_cmp = torch.Tensor(np.load(f"{path}/cumulative_distances.npy")).to(navi_line_points.device)
    # target_distances_cmp = torch.Tensor(np.load(f"{path}/target_distances.npy")).to(navi_line_points.device)
    # segment_indices_cmp = torch.Tensor(np.load(f"{path}/segment_indices.npy")).to(navi_line_points.device)
    # assert torch.abs(navi_line_points[0, 0, 0 : points_cmp.shape[0]] - points_cmp).max() < 1e-2
    # assert torch.abs(segment_lengths[0, 0 : segment_lengths_cmp.shape[0]] - segment_lengths_cmp).max() < 1e-2
    # assert (
    #     torch.abs(cumulative_distances_cmp - cumulative_distances[0, 0 : cumulative_distances_cmp.shape[0]]).max()
    #     < 1e-2
    # )
    # assert torch.abs(target_distances[0, 0 : target_distances_cmp.shape[0]] - target_distances_cmp).max() < 1e-2


def gen_navi_path_closest_index(
    egos_pred_mask,
    navi_path_points,
    navi_path_types,
    traj,
    use_fde: bool,
    navi_lateral_dist_mask_threshold: float = -1,
    use_lateral_dist: bool = False,
):
    """
    generate the best one index of navi line query, by L2 distance to ego future final point.
    Args:
        inputs (Dict[str, Any]): Inputs of batchdata,
        traj (Torch.Tensor[float32]): [B,1,T,D] # maybe [B,K,T,D]
        use_fde (bool): whether use final distance error
    Returns:
        min_index(Torch.Tensor[int]): [B]
        navi_line_mask(Torch.Tensor[bool]): [B,M]
        dist_s(Torch.Tensor[float32]): [B,M,T]
        dist_l(Torch.Tensor[float32]): [B,M,T]
        nearest_point_mask(Torch.Tensor[bool]): [B,M,T]
    """

    # navi_line_points = inputs["navi_line_points"]  # B M L D
    # navi_line_types = inputs["navi_line_types"]  # B M L
    navi_path_points
    navi_path_types

    traj_mask = egos_pred_mask  # B 1 T
    multi_mode_traj_flag = traj.shape[1] != 1
    if multi_mode_traj_flag:
        k_mod = traj.shape[1]
        traj = traj.reshape(-1, 1, traj.shape[2], traj.shape[3])  # [B*NS,1,T,D]
        traj_mask = traj_mask.repeat(1, k_mod, 1).reshape(-1, 1, traj_mask.shape[2])  # [B*NS,1,T]
        navi_path_points = (
            navi_path_points.unsqueeze(1)
            .repeat(1, k_mod, 1, 1, 1)
            .reshape(-1, navi_path_points.shape[1], navi_path_points.shape[2], navi_path_points.shape[3])
        )  # [B*NS,M,L,D]
        navi_path_types = (
            navi_path_types.unsqueeze(1)
            .repeat(1, k_mod, 1, 1)
            .reshape(-1, navi_path_types.shape[1], navi_path_types.shape[2])
        )  # [B*NS,M,L]

    b, _, t, _ = traj.shape

    # navi_path_points = inputs["navi_path_points"]  # B M L D
    # navi_path_types = inputs["navi_path_types"]  # B M L
    navi_path_point_mask = (navi_path_types != -1).float()  # [B, M, L], valid = 1.0
    navi_path_mask = navi_path_point_mask[..., 0]  # [B, M_s]
    b, m, l, _ = navi_path_points.shape

    # Get the distance between each trajectory and each navigation line
    # Cal navigation line heading
    traj_expanded = traj.unsqueeze(3)  #  (B, 1, T, D) -> (B, 1, T, 1, D)
    navi_path_points_expanded = navi_path_points.unsqueeze(2).expand(
        -1, -1, t, -1, -1
    )  # (B, M, L, D) -> (B, M, T, L, D)
    navi_path_points_diff = navi_path_points[:, :, 1:] - navi_path_points[:, :, :-1]  # (B, M, L-1, D)
    navi_path_points_diff = torch.cat(
        [navi_path_points_diff, navi_path_points_diff[:, :, -1:, :]], dim=-2
    )  # (B, M,  L, D)
    navi_path_point_mask_expanded = navi_path_point_mask.unsqueeze(2)  #  (B, M, L) ->  (B, M, 1, L)
    traj_navilane_diff = traj_expanded - navi_path_points_expanded  # (B, M, T, L, 2)
    distances = torch.norm(traj_navilane_diff, dim=-1)  # (B, M, T, L)

    # Find nearest distance and index and lane point heading
    combined_mask = traj_mask.unsqueeze(3) * navi_path_point_mask_expanded  # (B, M, T, L)
    masked_distances = distances * combined_mask + ((1 - combined_mask) * 1e6)  # (B, M, T, L)
    nearest_dist_index = masked_distances.argmin(dim=-1)  # (B, M, T)
    nearest_point_mask = torch.gather(combined_mask, 3, nearest_dist_index.unsqueeze(-1)).squeeze(-1)  # (B, M, T)

    # Decompose the distance into S and L direction
    nearest_dist_index_expanded = nearest_dist_index.unsqueeze(-1).unsqueeze(-1).expand(-1, -1, -1, -1, 2)
    nearest_traj_navilane_diff = torch.gather(traj_navilane_diff, dim=3, index=nearest_dist_index_expanded).squeeze(3)
    navi_path_points_diff_expanded = navi_path_points_diff.unsqueeze(2).expand(-1, -1, t, -1, -1)
    nearest_navilane_points_diff = torch.gather(
        navi_path_points_diff_expanded, dim=3, index=nearest_dist_index_expanded
    ).squeeze(3)
    dist_s = torch.sum(nearest_traj_navilane_diff * nearest_navilane_points_diff, dim=-1) / (
        torch.norm(nearest_navilane_points_diff, dim=-1) + 1e-6
    )
    dist_s = torch.abs(dist_s + ((1 - nearest_point_mask) * _planner_consts.MAX_VAL))  # (B, M, T)
    dist_l = (
        nearest_traj_navilane_diff[..., 0] * nearest_navilane_points_diff[..., 1]
        - nearest_traj_navilane_diff[..., 1] * nearest_navilane_points_diff[..., 0]
    )
    dist_l = dist_l / (torch.norm(nearest_navilane_points_diff, dim=-1) + 1e-6)
    dist_l = torch.abs(dist_l * nearest_point_mask + ((1 - nearest_point_mask) * _planner_consts.MAX_VAL))  # (B, M, T)

    if multi_mode_traj_flag:
        dist_s = dist_s.reshape(b // k_mod, k_mod, m, t)  # [B, M, T] -> [B//K, K, M, T]
        dist_l = dist_l.reshape(b // k_mod, k_mod, m, t)  # [B, M, T] -> [B//K, K, M, T]
        return None, None, dist_s, dist_l, None

    if use_lateral_dist:
        # find closest points in line and get ade for every line
        # if (traj_mask[:, 0, -1] == 0).any():
        #     print(1)
        if use_fde:
            mask_valid = torch.abs(dist_l - _planner_consts.MAX_VAL) > _planner_consts.EPSILON  # (B, M, T)
            dist_l_reversed = torch.flip(dist_l, dims=[-1])  # (B, M, T)
            mask_valid_reversed = torch.flip(mask_valid, dims=[-1])  # (B, M, T)
            mask_valid_reversed_int = mask_valid_reversed.long()  # (B, M, T)
            first_valid_indices = torch.argmax(mask_valid_reversed_int, dim=-1)  # (B, M)
            no_valid_distance = mask_valid_reversed_int.sum(dim=-1) == 0  # (B, M)
            indices = first_valid_indices.unsqueeze(-1)  # (B, M, 1)
            valid_distance = torch.gather(dist_l_reversed, -1, indices).squeeze(-1)  # (B, M)
            valid_distance = torch.where(
                no_valid_distance, torch.tensor(_planner_consts.MAX_VAL, device="cuda"), valid_distance
            )
        else:
            valid_distance = dist_l.sum(-1)  # B M T L -> B M T -> B M
    else:
        valid_distance = masked_distances.min(dim=-1)[0]  # B M T L -> B M T
        if use_fde:
            valid_distance = valid_distance[..., -1]
        else:
            valid_distance = valid_distance.sum(-1)  # B M T L -> B M T -> B M

    _, min_index = valid_distance.min(dim=1)  # (B, L) -> B

    if navi_lateral_dist_mask_threshold != -1:
        # if all navi_paths are invalid, mask them all
        # 1 for masked, 0 for unmasked
        invalid_mask = (valid_distance.min(-1)[0] > navi_lateral_dist_mask_threshold)[:, None].expand(
            (-1, navi_path_points.shape[1])
        )  # [B,M]
        # 1 for valid, 0 for invalid
        navi_path_mask = navi_path_mask * (1 - invalid_mask.float())  # [B,M]*[B,M] -> [B,M]
    return min_index, navi_path_mask, dist_s, dist_l, nearest_point_mask


def generate_roi_point_mask(
    points, types, navi_path_points, navi_path_types, ego_range=[-10.0, 30.0, -10.0, 10.0], navi_radius=10.0
):
    """Generate the mask of points in the region of interest.

    Args:
        points (torch.Tensor): the points of interest. Shape: (B, N, M, 2).
        types (torch.Tensor): the types of points. Shape: (B, N, M).
        navi_path_points (torch.Tensor): the list of navigation path points. Shape: (B, 1, K, 2).
        navi_path_types (torch.Tensor): the list of navigation path types. Shape: (B, 1, K).
        ego_range (float): the range of ego.
        navi_radius (float): the radius of navigation.

    Returns:
        Whether the points are in the region of interest.
    """
    point_mask = types != -1  # [B,N,M]
    navi_mask = navi_path_types != -1  # [B,1,K]
    point_navi_mask = point_mask.unsqueeze(-1) & navi_mask.unsqueeze(1)  # [B,N,M,K]

    ego_x1, ego_x2, ego_y1, ego_y2 = ego_range

    # check if the points are in the ego region of interest
    in_ego_roi = (
        (points[:, :, :, 0] >= ego_x1)
        & (points[:, :, :, 0] <= ego_x2)
        & (points[:, :, :, 1] >= ego_y1)
        & (points[:, :, :, 1] <= ego_y2)
    )

    # check if the points are in the navigation path region of interest
    unsqueezed_navi_path_points = navi_path_points.unsqueeze(1)
    unsqueeze_points = points.unsqueeze(-2)
    points_navi_dist = torch.norm(unsqueezed_navi_path_points - unsqueeze_points, dim=-1)  # [B,N,M,K]
    points_navi_dist = points_navi_dist + (1 - point_navi_mask.float()) * 1e6  # [B,N,M,K]
    points_nearest_navi_dist = torch.min(points_navi_dist, dim=-1)[0]  # [B,N,M]
    in_navi_path_roi = points_nearest_navi_dist <= navi_radius  # [B,N,M]
    return in_ego_roi | in_navi_path_roi
