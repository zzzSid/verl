# -*- coding: utf-8 -*-
"""Utility functions for niofs."""
import os
import re
from dataclasses import dataclass
from pathlib import Path

# from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import yaml
from niofs import Client as NiofsClient
from niofs.niofs import MAX_POOL_CONNECTIONS
from read_cache_op_py import read_cache_op_py
from torchpilot import logger

from tpp_onemodel.utils.constant_utils import get_env_or_constant
from tpp_onemodel.utils.constant_utils import load_constants
from tpp_onemodel.utils.constant_utils import retry
from tpp_onemodel.utils.niofs.constants import CACHE_URI
from tpp_onemodel.utils.niofs.constants import NIOFS_ACCESS_KEY
from tpp_onemodel.utils.niofs.constants import NIOFS_CONF_YAML
from tpp_onemodel.utils.niofs.constants import NIOFS_CONF_YAML_DEFAULT
from tpp_onemodel.utils.niofs.constants import NIOFS_SECRET_KEY


_consts = load_constants("tpp_onemodel.utils.niofs.constants")
_UPLOAD_NUM_RETRIES = 3
_NIOFS_CLIENT_LIST_MAX = 1000


def set_envs_from_yaml(yaml_path: Optional[Path] = None) -> bool:
    """Set niofs access and secret keys from yaml file."""
    if not yaml_path:
        yaml_path = Path(
            get_env_or_constant(constants=_consts, attr=NIOFS_CONF_YAML, default=NIOFS_CONF_YAML_DEFAULT)
        ).expanduser()

    if not yaml_path.exists():
        logger.warning("No %s was found, cant set", str(yaml_path))
        return False

    with yaml_path.open("r") as f:
        cfg = yaml.safe_load(f)

    # Set envs
    logger.info("Setting envs from yaml")
    os.environ[NIOFS_ACCESS_KEY] = cfg["access_key"]
    os.environ[NIOFS_SECRET_KEY] = cfg["secret_key"]
    logger.info("Envs set: %s %s", NIOFS_ACCESS_KEY, NIOFS_SECRET_KEY)
    return True


def _make_env_setter():
    if_set = False

    def set_vars(yaml_path: Optional[Path] = None):
        nonlocal if_set
        if not if_set:
            if set_envs_from_yaml(yaml_path):
                if_set = True

    return set_vars


_set_vars = _make_env_setter()


def get_niofs_client(
    set_envs: bool = True, yaml_path: Optional[Path] = None, max_pool_connections: Optional[int] = MAX_POOL_CONNECTIONS
) -> NiofsClient:
    """Get niofs client, set environment variables if required."""
    if set_envs:
        _set_vars(yaml_path)

    return NiofsClient(
        access_key=get_env_or_constant(constants=_consts, attr=NIOFS_ACCESS_KEY),
        secrete_key=get_env_or_constant(constants=_consts, attr=NIOFS_SECRET_KEY),
        max_pool_connections=max_pool_connections,
    )


def parse_niofs_url(url: str, client: NiofsClient = None) -> Tuple[str, str]:
    """Parse bucket:folder/path to bucket and folder/path."""
    url = re.sub(r"//+", "/", url)
    if not client:
        # Only support bucket:/path/to/file format
        if ":" not in url:
            raise ValueError(f"Invalid niofs url: {url}")
        bucket, key = url.split(":", 1)
        if key.startswith("/"):
            key = key[1:]
        return bucket, key
    # Supports multiple formats
    return client.divide_niofs_path(url)


@retry(_UPLOAD_NUM_RETRIES)
def upload(
    src: Path,
    bucket: str,
    folder: str,
    client: NiofsClient = None,
    config: Optional[str] = None,
) -> None:
    """Upload file to niofs cloud storage, folder is the path in the bucket."""
    if not src.exists():
        raise FileNotFoundError(f"File not found: {src}")
    if not src.is_absolute():
        raise ValueError(f"Path must be absolute: {src}")
    src = src.expanduser()
    logger.info("Uploading: %s => %s:/%s", src, bucket, folder)
    if client is None:
        client = get_niofs_client()
    if (
        result := client.upload_file(
            Filename=src.as_posix(),
            Bucket=bucket,
            Key=f"{folder}/{src.name}",
            Config=config,
        )
    ) is not None:
        logger.error("Failed to upload %s => %s:/%s, %s", src, bucket, folder, result)
        raise Exception(f"Failed to upload {src} => {bucket}:/{folder}, {result}")


@dataclass
class FileInfo:
    """File meta."""

    bucket: str
    path: str
    size: int
    # last_modified: datetime.datetime


def niofs_head_object(path: str, client: NiofsClient = None):
    """Client head object."""
    if client is None:
        client = get_niofs_client()
    bucket, key = parse_niofs_url(path, client=client)
    ret = client.head_object(Bucket=bucket, Key=key)
    return FileInfo(
        bucket=bucket,
        path=key,
        size=ret["ContentLength"],
    )


def list_files(
    path: str,
    client: NiofsClient = None,
    max_files: int = _NIOFS_CLIENT_LIST_MAX,
) -> List[FileInfo]:
    """List files in niofs folder."""
    if client is None:
        client = get_niofs_client()
    bucket, key = parse_niofs_url(path, client=client)
    # Format like: [{'Key': 'datasets_open/2021-09-01/2021-09-01_00-00-00_UTC', 'Size': 0,
    # 'LastModified': datetime.datetime(2021, 9, 1, 0, 0, tzinfo=tzutc())}]
    obj_to_finifo = lambda obj: FileInfo(  # noqa: E731
        bucket=bucket,
        path=obj["Key"],
        size=obj["Size"],
        # last_modified=obj["LastModified"],
    )
    out = []
    if max_files <= _NIOFS_CLIENT_LIST_MAX:
        # Should be faster than using paginator, suitable for small number of files
        ret = client.list_objects_v2(Bucket=bucket, Prefix=key)
        if not ret:
            return []
        for obj in ret["Contents"]:
            out.append(obj_to_finifo(obj))
            if len(out) >= max_files:
                break
    else:
        # https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/s3/paginator/ListObjectsV2.html#
        logger.info("Using paginator to list files: %s, may take a while.", path)
        paginator = client.get_paginator("list_objects_v2")
        pages = paginator.paginate(Bucket=bucket, Prefix=key)

        for page in pages:
            for obj in page["Contents"]:
                out.append(obj_to_finifo(obj))
                if len(out) >= max_files:
                    break

    return out


# TODO: local version
def load_file_with_tag_from_cache(bucket, paths):
    """Load files in batch."""
    try:
        get_env_or_constant(constants=_consts, attr=CACHE_URI)
    except ValueError:
        logger.error("Failed to get CACHE_URI environment variable, are we using training platform?")
    # https://nio.feishu.cn/docs/doccn8EX5FHT3NdPtuxLLoiH7Rf
    # Format: /[bucket]/path/to/file file_size
    # Split into batches
    cached_gen = []
    for clip_file, clip_tag in paths:
        path_with_size = [f"/{bucket}/{clip_file.path} {clip_file.size}"]
        file_content = read_cache_op_py(path_with_size)[0]
        if clip_tag is not None:
            path_with_size = [f"/{bucket}/{clip_tag.path} {clip_tag.size}"]
            tag_content = read_cache_op_py(path_with_size)[0]
        else:
            tag_content = None
        cached_gen.append([(clip_file, file_content), (clip_tag, tag_content)])
    return cached_gen
