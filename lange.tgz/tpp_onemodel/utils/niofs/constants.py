# -*- coding: utf-8 -*-
"""Constants for niofs."""
from enum import Enum
from enum import auto


class CacheType(Enum):
    """Cache types."""

    LOCAL = auto()
    # Only can be used in train system, requires IB RDMA networking
    # Also requires installation of C++ dependecies: read_cache_op_py. See README.
    TRAIN_SYS = auto()


# Niofs yaml file (may be absent, then set envs)
# File should look like
# access_key: ""
# secret_key: ""
# export NIOFS_CONF_YAML="/path/to/niofs.yaml"
NIOFS_CONF_YAML = "NIOFS_CONF_YAML"
NIOFS_CONF_YAML_DEFAULT = "~/.niofs/niofs.yaml"

# Set from environment variables
NIOFS_ACCESS_KEY = "NIOFS_ACCESS_KEY"
NIOFS_SECRET_KEY = "NIOFS_SECRET_KEY"  # noqa: S105

# Cache URI, for storing downloaded files, train system only
CACHE_URI = "CACHE_URI"
