# -*- coding: utf-8 -*-
# flake8: noqa
"""path utils."""

import os
import os.path as osp
from pathlib import Path


def is_str(filepath):
    """Whether the input is an string instance.

    Note: This method is deprecated since python 2 is no longer supported.
    """
    return isinstance(filepath, str)


def is_filepath(filepath):
    """Check if is filepath."""
    return is_str(filepath) or isinstance(filepath, Path)


def fopen(filepath, *args, **kwargs):
    """Open File."""
    if is_str(filepath):
        return open(filepath, *args, **kwargs)  # pylint: disable=unspecified-encoding

    if isinstance(filepath, Path):
        return filepath.open(*args, **kwargs)

    raise ValueError("`filepath` should be a string or a Path")


def check_file_exist(filename, msg_tmpl='file "{}" does not exist'):
    """Check file exist."""
    if not osp.isfile(filename):
        raise FileNotFoundError(msg_tmpl.format(filename))


def mkdir_or_exist(dir_name, mode=0o777):
    """mkdir or exist."""
    if dir_name == "":
        return
    dir_name = osp.expanduser(dir_name)
    os.makedirs(dir_name, mode=mode, exist_ok=True)
