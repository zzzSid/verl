# -*- coding: utf-8 -*-
# flake8: noqa
# mypy: ignore-errors
"""Close loop utils."""
import logging

import numpy as np
import torch


logger = logging.getLogger(__name__)


def compute_transform_matrix_t0_to_t1(pos, yaw):
    """
    输入:
        pos: 形状 [B, 2] ，表示批量中的 B 个 (x, y) 平移量
        yaw: 形状 [B, 1] ，表示批量中的 B 个偏航角(弧度)
    返回:
        M_t0_to_t1: 形状 [B, 4, 4] 的批量齐次变换矩阵
    """
    # batch size
    B = pos.shape[0]

    # 提取 x, y, yaw
    x = pos[:, 0]  # [B]
    y = pos[:, 1]  # [B]
    yaw_val = yaw[:, 0]  # [B]

    cos_yaw = torch.cos(yaw_val)
    sin_yaw = torch.sin(yaw_val)

    # 一些常用的张量
    zero = torch.zeros_like(x)  # shape [B]
    one = torch.ones_like(x)  # shape [B]

    # 构造每一行
    # 注意 stack 之后的 shape 为 [B, 4]，再把这几行 stack 到一起就成了 [B, 4, 4]
    row0 = torch.stack([cos_yaw, sin_yaw, zero, -(x * cos_yaw + y * sin_yaw)], dim=-1)  # [B, 4]

    row1 = torch.stack([-sin_yaw, cos_yaw, zero, x * sin_yaw - y * cos_yaw], dim=-1)  # [B, 4]

    row2 = torch.stack([zero, zero, one, zero], dim=-1)  # [B, 4]

    row3 = torch.stack([zero, zero, zero, one], dim=-1)  # [B, 4]

    # 合并为 [B, 4, 4]
    M = torch.stack([row0, row1, row2, row3], dim=1)  # [B, 4, 4]

    return M.cuda()


def average_yaw(angle1, angle2):
    # 对两帧航向分别求 sin 和 cos
    sin_sum = torch.sin(angle1) + torch.sin(angle2)
    cos_sum = torch.cos(angle1) + torch.cos(angle2)

    # 对两个向量求平均后，用 atan2 恢复出平均角度
    avg_angle = torch.atan2(sin_sum, cos_sum)

    return avg_angle


def replace_ego_velocity(egos, ego_pred_long_vel):
    # 取出最后一帧（time 维度上取 -1）并且只取第 0 号 agent 的所有特征
    last_feat = egos[:, -1, 0, :]  # 形状 [batch_size, feat_dim]

    # 在新的张量中替换第 10 号位置的速度值
    new_last_feat = torch.cat(
        [last_feat[..., :10], ego_pred_long_vel.unsqueeze(-1), last_feat[..., 11:]], dim=-1  # unsqueeze 保持维度对齐
    )  # 形状仍为 [batch_size, feat_dim]

    # 将除最后一帧外的部分取出
    egos_without_last = egos[:, :-1, :, :]  # 形状 [batch_size, time-1, agent_num, feat_dim]

    # 扩展新最后帧的维度，使之与原 egos 对齐
    new_last_feat = new_last_feat.unsqueeze(1).unsqueeze(2)  # 形状 [batch_size, 1, 1, feat_dim]

    # 在 time 维度上拼回去，得到更新后的 egos
    egos_updated = torch.cat([egos_without_last, new_last_feat], dim=1)  # 形状 [batch_size, time, agent_num, feat_dim]

    return egos_updated


def recursively_slice(obj, model_sync_flag):
    """
    递归地遍历 obj，如果是 Tensor，则切取后半部分；
    如果是 dict 或 list，继续向下遍历。
    """
    if isinstance(obj, dict):
        for k, v in obj.items():
            obj[k] = recursively_slice(v, model_sync_flag)
        return obj

    elif isinstance(obj, list):
        for i in range(len(obj)):
            obj[i] = recursively_slice(obj[i], model_sync_flag)
        return obj

    elif isinstance(obj, torch.Tensor):
        B = torch.tensor(obj.shape[0], device="cuda")
        indices = (
            torch.arange(B // 2, B, device="cuda") * torch.logical_not(model_sync_flag)
            + torch.arange(0, B // 2, device="cuda") * model_sync_flag
        )
        return torch.index_select(obj, 0, indices)  # 保留后半部分

    else:
        # 其他类型直接返回
        return obj


def get_theta_from_trans(real_to_sim):
    N = real_to_sim.size(0)  # 等于 2
    index_0 = torch.tensor([0], device="cuda")  # 用于在某一维取下标 0
    index_1 = torch.tensor([1], device="cuda")  # 用于在某一维取下标 1
    index_last = torch.tensor([N - 1], device="cuda")  # 用于在 batch 维（dim=0）取最后一个元素

    # -----------------------------
    # 先实现 real_to_sim[:, 0, 1]
    # -----------------------------
    # 第一步：在 dim=1 上选 index=0 => real_to_sim[:, [0], :]
    tmp_01 = torch.index_select(real_to_sim, 1, index_0)
    # 结果形状 [2, 1, 4]

    # 第二步：在 dim=2 上选 index=1 => tmp_01[:, :, [1]]
    tmp_01 = torch.index_select(tmp_01, 2, index_1)
    # 结果形状 [2, 1, 1]

    # 压缩掉多余的维度 => [2]
    tmp_01 = tmp_01.squeeze(-1).squeeze(-1)

    # 然后取它的最后一个元素，即 tmp_01[-1]
    val_01_last = torch.index_select(tmp_01, 0, index_last)
    # 形状 [1]

    # -----------------------------
    # 再实现 real_to_sim[:, 0, 0]
    # -----------------------------
    tmp_00 = torch.index_select(real_to_sim, 1, index_0)
    # 形状 [2, 1, 4]
    tmp_00 = torch.index_select(tmp_00, 2, index_0)
    # 形状 [2, 1, 1]
    tmp_00 = tmp_00.squeeze(-1).squeeze(-1)
    # 形状 [2]

    val_00_last = torch.index_select(tmp_00, 0, index_last)
    # 形状 [1]

    # -----------------------------
    # 最终计算 rotation_theta
    # -----------------------------
    rotation_theta = torch.atan2(val_01_last, val_00_last)
    return rotation_theta


def get_translation_from_trans(real_to_sim):
    N = real_to_sim.size(0)  # 等于 2
    index_last_dim1 = torch.tensor([real_to_sim.size(1) - 1], device="cuda")

    # 第二维( dim=2 )上我们要取 [0, 1] => 相当于切片 0:2
    index_0_1 = torch.tensor([0, 1], device="cuda")

    # 第一步，在 dim=1 上选取下标 3 (原先的 -1)
    tmp = torch.index_select(real_to_sim, 1, index_last_dim1)
    # tmp 形状 [N, 1, 4]

    # 第二步，在 dim=2 上选取下标 [0, 1] (原先的 0:2)
    tmp = torch.index_select(tmp, 2, index_0_1)
    # tmp 形状 [N, 1, 2]

    # 如果希望最终得到 [N, 2] 而不是 [N, 1, 2]，可以去掉多余的维度
    translation = tmp.squeeze(1)
    # translation 形状 [N, 2]

    index_last = torch.tensor([N - 1], device="cuda")  # 用于在 batch 维（dim=0）取最后一个元素
    translation_last = torch.index_select(translation, 0, index_last)
    return translation_last.squeeze(0)


def is_real_sim_pred_close(
    top1_ego_pred_pos_real,  # [1, T, 2]
    top1_ego_pred_pos_sim,  # [1, T, 2]
    top1_ego_pred_yaw_real,  # [1, T]
    cur_ego_vel,  # [2]
    trace_mode=False,
    verbose=False,
):
    """
    判断两条轨迹在 3s 和 5s 时刻是否都接近。
    返回值:
        True/False (Python 布尔值)，表示是否接近。
    """

    # 时间步长和总步数 (题目给定, 这里可写死)
    dt = 0.2

    # 计算 3s、5s 时对应的索引（防越界）
    idx_3s = int(3.0 / dt) - 1  # 3s -> 14
    idx_5s = int(5.0 / dt) - 1  # 5s -> 24
    # idx_7s = int(7.0 / dt) - 1  # 7s -> 34

    # 计算当前速度标量 v
    # cur_ego_vel 是 [vx, vy], 其速度标量为 sqrt(vx^2 + vy^2)
    v = torch.max(
        torch.tensor(3, device="cuda"), torch.sqrt(cur_ego_vel[0] * cur_ego_vel[0] + cur_ego_vel[1] * cur_ego_vel[1])
    )

    # ---------------------------
    #   计算 3s 阈值
    # ---------------------------
    # 纵向阈值: v * (3s) / 5, 最大不超过 10
    lon_thr_3s_raw = v * (3.0 / 3.0)
    lon_thr_3s = torch.minimum(torch.tensor(lon_thr_3s_raw, device="cuda"), torch.tensor(10.0, device="cuda"))
    # 横向阈值: v * (3s) / 20, 最大不超过 1.5
    lat_thr_3s_raw = v * (3.0 / 20.0)
    lat_thr_3s = torch.minimum(torch.tensor(lat_thr_3s_raw, device="cuda"), torch.tensor(1.5, device="cuda"))

    # ---------------------------
    #   计算 5s 阈值
    # ---------------------------
    # 纵向阈值: v * (5s) / 3, 最大不超过 30
    lon_thr_5s_raw = v * (5.0 / 2.0)
    lon_thr_5s = torch.minimum(torch.tensor(lon_thr_5s_raw, device="cuda"), torch.tensor(30.0, device="cuda"))
    # 横向阈值: v * (5s) / 15, 最大不超过 3
    lat_thr_5s_raw = v * (5.0 / 15.0)
    lat_thr_5s = torch.minimum(torch.tensor(lat_thr_5s_raw, device="cuda"), torch.tensor(3, device="cuda"))

    # ---------------------------
    #   计算 3s 误差
    # ---------------------------
    # Δx, Δy
    dx_3s = top1_ego_pred_pos_sim[0, idx_3s, 0] - top1_ego_pred_pos_real[0, idx_3s, 0]
    dy_3s = top1_ego_pred_pos_sim[0, idx_3s, 1] - top1_ego_pred_pos_real[0, idx_3s, 1]
    # 真实 heading
    yaw_3s = top1_ego_pred_yaw_real[0, idx_3s]

    # 按 heading 分解纵横误差
    # lon_err = dx*cos(yaw) + dy*sin(yaw)
    # lat_err = -dx*sin(yaw) + dy*cos(yaw)
    lon_err_3s = dx_3s * torch.cos(yaw_3s) + dy_3s * torch.sin(yaw_3s)
    lat_err_3s = -dx_3s * torch.sin(yaw_3s) + dy_3s * torch.cos(yaw_3s)

    # 条件 1：3s 内的纵横误差都不超过阈值
    cond_3s = (torch.abs(lon_err_3s) <= lon_thr_3s).float() * (torch.abs(lat_err_3s) <= lat_thr_3s).float()

    # ---------------------------
    #   计算 5s 误差
    # ---------------------------
    dx_5s = top1_ego_pred_pos_sim[0, idx_5s, 0] - top1_ego_pred_pos_real[0, idx_5s, 0]
    dy_5s = top1_ego_pred_pos_sim[0, idx_5s, 1] - top1_ego_pred_pos_real[0, idx_5s, 1]
    yaw_5s = top1_ego_pred_yaw_real[0, idx_5s]

    lon_err_5s = dx_5s * torch.cos(yaw_5s) + dy_5s * torch.sin(yaw_5s)
    lat_err_5s = -dx_5s * torch.sin(yaw_5s) + dy_5s * torch.cos(yaw_5s)

    # 条件 2：5s 内的纵横误差都不超过阈值
    cond_5s = (torch.abs(lon_err_5s) <= lon_thr_5s).float() * (torch.abs(lat_err_5s) <= lat_thr_5s).float()

    # 只有 3s 和 5s 的条件都满足才返回 True
    is_close = cond_3s * cond_5s

    if not trace_mode and verbose:
        print(f"3s: {cond_3s.item()}, 5s: {cond_5s.item()}, is_close: {is_close.item()}")
        print(
            f"lon_err_3s: {lon_err_3s.item()}, lat_err_3s: {lat_err_3s.item()}, lon_thr_3s: {lon_thr_3s.item()}, lat_thr_3s: {lat_thr_3s.item()}"
        )
        print(
            f"lon_err_5s: {lon_err_5s.item()}, lat_err_5s: {lat_err_5s.item()}, lon_thr_5s: {lon_thr_5s.item()}, lat_thr_5s: {lat_thr_5s.item()}"
        )

    # 若需要返回 Python bool，可用下面语句
    return is_close


def align_general_boxes(
    bboxes,
    hist2curr_trans,
    bboxes_padding_mask,
    xyz_range_idx=None,  # (0,3),
    yaw_idx=None,  # 6,
    vel_idx=None,  # (10, 12),
    acc_idx=None,
    default_value=0.0,
):
    """Align box from history to current."""
    # flatten bboxes to [B * T, n_t, F]
    batch_size = bboxes.shape[0]
    n_t = bboxes.shape[2]
    f_dim = bboxes.shape[-1]

    bboxes = bboxes.reshape(-1, bboxes.shape[-2], bboxes.shape[-1])
    bboxes_padding_mask = bboxes_padding_mask.reshape(-1, bboxes_padding_mask.shape[-1])

    if f_dim < 3 or (xyz_range_idx[1] - xyz_range_idx[0]) < 3:
        bboxes_xyz_homo = torch.concat(
            (
                bboxes[:, :, xyz_range_idx[0] : xyz_range_idx[1]],
                bboxes.new_zeros((bboxes.shape[0], bboxes.shape[1], 1)),
                bboxes.new_ones((bboxes.shape[0], bboxes.shape[1], 1)),
            ),
            dim=2,
        )
    else:
        bboxes_xyz_homo = torch.concat(
            (
                bboxes[:, :, xyz_range_idx[0] : xyz_range_idx[1]],
                bboxes.new_ones((bboxes.shape[0], bboxes.shape[1], 1)),
            ),
            dim=2,
        )

    # flatten hist2curr to [B * T, 4, 4]
    hist2curr_trans = hist2curr_trans.reshape(-1, hist2curr_trans.shape[-2], hist2curr_trans.shape[-1])
    hist2curr_trans_transpose = hist2curr_trans.transpose(1, 2)
    bboxes_xyz_homo = torch.bmm(bboxes_xyz_homo, hist2curr_trans_transpose)

    bboxes_padding_mask_bool = torch.abs(bboxes_padding_mask) > 0
    bboxes_padding_mask_bool = bboxes_padding_mask_bool.unsqueeze(2)
    bboxes_xyz_homo = torch.where(
        bboxes_padding_mask_bool,
        torch.full((1,), default_value, device="cuda", dtype=bboxes_xyz_homo.dtype),
        bboxes_xyz_homo,
    )

    if yaw_idx is not None:
        aligned_yaw = bboxes[:, :, yaw_idx : yaw_idx + 1] + torch.atan2(
            hist2curr_trans[:, 1, 0:1], hist2curr_trans[:, 0, 0:1]
        ).unsqueeze(1)
        aligned_yaw = torch.where(
            bboxes_padding_mask_bool,
            torch.zeros((1,), device="cuda", dtype=aligned_yaw.dtype),
            aligned_yaw,
        )

    if vel_idx is not None:
        aligned_vel = torch.bmm(bboxes[:, :, vel_idx[0] : vel_idx[1]], hist2curr_trans_transpose[:, 0:2, 0:2])
        aligned_vel = torch.where(
            bboxes_padding_mask_bool,
            torch.zeros((1,), device="cuda", dtype=aligned_vel.dtype),
            aligned_vel,
        )

    if acc_idx is not None:
        aligned_acc = torch.bmm(bboxes[:, :, 12:14], hist2curr_trans_transpose[:, 0:2, 0:2])
        aligned_acc = torch.where(
            bboxes_padding_mask_bool,
            torch.zeros((1,), device="cuda", dtype=aligned_acc.dtype),
            aligned_acc,
        )

    if f_dim < 3:  #
        xyz_end_idx = 2
    else:
        xyz_end_idx = xyz_range_idx[1]

    bboxes = torch.cat(
        [
            bboxes[:, :, : xyz_range_idx[0]],
            bboxes_xyz_homo[:, :, xyz_range_idx[0] : xyz_end_idx],  # xyz
            bboxes[:, :, xyz_end_idx:f_dim],
        ],
        dim=2,
    )

    if yaw_idx is not None:
        bboxes = torch.cat(
            [
                bboxes[:, :, :yaw_idx],
                aligned_yaw,
                bboxes[:, :, yaw_idx + 1 : f_dim],
            ],
            dim=2,
        )
    if vel_idx is not None:
        bboxes = torch.cat(
            [
                bboxes[:, :, : vel_idx[0]],
                aligned_vel,
                bboxes[:, :, vel_idx[1] : f_dim],
            ],
            dim=2,
        )

    if acc_idx is not None:
        bboxes = torch.cat(
            [
                bboxes[:, :, : acc_idx[0]],
                aligned_acc,
                bboxes[:, :, acc_idx[1] : f_dim],
            ],
            dim=2,
        )
    bboxes = bboxes.reshape(batch_size, -1, n_t, f_dim)
    return bboxes


def transform_percetion_to_sim_coord(
    real_to_sim,
    hist_len,
    ego_pred_long_vel,
    bboxes,
    bboxes_padding_mask,
    egos,
    egos_padding_mask,
    lane_points,
    lane_types,
    sod_poly_boxes,
    sod_poly_boxes_padding_mask,
    sod_poly_pts,
    sod_poly_pts_padding_mask,
    god_poly_pts,
    god_poly_pts_padding_mask,
    tld,
    tld_padding_mask,
    atlas,
    navi_line_points,
    navi_line_types,
    navi_path_points,
    navi_path_types,
    control_points,
    ar_ego_state,
    ar_ego_action_vocab,
    ar_ego_action_norm,
    ar_agents_state,
    ar_agents_action,
    trace_mode,
    model_inputs,
    future_msg={},
):
    """Transform percetion to sim coord."""
    # egos[:, -1, 0, 10] = ego_pred_long_vel
    egos_updated = replace_ego_velocity(egos, ego_pred_long_vel)
    egos = egos_updated

    if ar_ego_state is not None:
        ar_ego_state[:, :, 14, 3] = ego_pred_long_vel

    bboxes = align_general_boxes(
        bboxes,
        real_to_sim.transpose(1, 2).unsqueeze(1).expand(-1, hist_len, -1, -1),
        bboxes_padding_mask,
        xyz_range_idx=(0, 3),
        yaw_idx=6,
        # vel_idx=(10, 12),
    )

    if ar_agents_state is not None:
        ar_agents_state = ar_agents_state.transpose(1, 2)
        ar_agents_state_padding_mask = torch.abs(ar_agents_state.sum(dim=-1, keepdim=False)) < 1e-6
        ar_agents_state = align_general_boxes(
            ar_agents_state,
            real_to_sim.transpose(1, 2).unsqueeze(1).expand(-1, ar_agents_state.shape[1], -1, -1),
            ar_agents_state_padding_mask,
            xyz_range_idx=(0, 2),
            yaw_idx=5,
        )
        ar_agents_state = ar_agents_state.transpose(1, 2)

    lane_points = align_general_boxes(
        lane_points,
        real_to_sim.transpose(1, 2).unsqueeze(1).expand(-1, lane_points.shape[1], -1, -1),
        lane_types == -1,
        xyz_range_idx=(0, 3),
        default_value=-1,
    )
    sod_poly_boxes = (  # TODO(congq): use current only, remove later
        align_general_boxes(
            sod_poly_boxes.unsqueeze(2),
            real_to_sim.transpose(1, 2).unsqueeze(1).expand(-1, sod_poly_boxes.shape[1], -1, -1),
            sod_poly_boxes_padding_mask.unsqueeze(2),
            xyz_range_idx=(0, 3),
            yaw_idx=6,
            vel_idx=None,
        ).squeeze(2)
        if sod_poly_boxes is not None
        else None
    )
    sod_poly_pts = (  # TODO(congq): use current only, remove later
        align_general_boxes(
            sod_poly_pts,
            real_to_sim.transpose(1, 2).unsqueeze(1).expand(-1, sod_poly_pts.shape[1], -1, -1),
            sod_poly_pts_padding_mask,
            xyz_range_idx=(0, 3),
        )
        if sod_poly_pts is not None
        else None
    )
    god_poly_pts = (  # TODO(congq): use current only, remove later
        align_general_boxes(
            god_poly_pts,
            real_to_sim.transpose(1, 2).unsqueeze(1).expand(-1, god_poly_pts.shape[1], -1, -1),
            god_poly_pts_padding_mask,
            xyz_range_idx=(0, 3),
        )
        if god_poly_pts is not None
        else None
    )
    navi_line_points = (  # TODO(congq): use current only, remove later
        align_general_boxes(
            navi_line_points,
            real_to_sim.transpose(1, 2).unsqueeze(1).expand(-1, navi_line_points.shape[1], -1, -1),
            navi_line_types == -1,
            xyz_range_idx=(0, 3),
        )
        if navi_line_points is not None
        else None
    )
    navi_path_points = (  # TODO(congq): use current only, remove later
        align_general_boxes(
            navi_path_points,
            real_to_sim.transpose(1, 2).unsqueeze(1).expand(-1, navi_path_points.shape[1], -1, -1),
            navi_path_types == -1,
            xyz_range_idx=(0, 3),
        )
        if navi_path_points is not None
        else None
    )

    atlas_pts = atlas[..., :2] if atlas is not None else None
    atlas_pts_padding_mask = atlas[..., 2] == -1
    atlas_pts = (  # TODO(congq): use current only, remove later
        align_general_boxes(
            atlas_pts,
            real_to_sim.transpose(1, 2).unsqueeze(1).expand(-1, atlas_pts.shape[1], -1, -1),
            atlas_pts_padding_mask,
            xyz_range_idx=(0, 3),
            default_value=-1,
        )
        if atlas is not None
        else None
    )
    atlas = torch.cat((atlas_pts, atlas[..., 2].unsqueeze(-1)), dim=-1)

    control_points = model_inputs["control_points"]
    control_points_bs, control_points_group, control_points_num = control_points.shape[:3]

    control_points_mask = torch.all(control_points == -1, dim=-1)
    control_vel_mask = torch.all(control_points[..., 2:4] == -1, dim=-1)

    control_points_x_y_homo = torch.cat(
        (
            control_points[..., :2],
            torch.zeros((control_points_bs, control_points_group, control_points_num, 1), device=control_points.device),
            torch.ones((control_points_bs, control_points_group, control_points_num, 1), device=control_points.device),
        ),
        dim=3,
    )
    control_points_x_y_trans = (control_points_x_y_homo @ real_to_sim[:, None])[..., :2]

    control_points_x_y_trans[control_points_mask] = -1.0

    control_points_heading_trans = control_points[..., 2:4] @ real_to_sim[..., None, :2, :2]
    control_points_heading_trans[control_vel_mask] = -1.0

    control_points_trans = torch.cat(
        (control_points_x_y_trans, control_points_heading_trans, control_points[..., 4:]), dim=3
    )

    if not trace_mode:
        bboxes_pred_gt = model_inputs["bboxes_pred_gt"]  # [B,A,T,2]
        bboxes_pred_mask = model_inputs["bboxes_pred_mask"]  # [B,A,T]
        bboxes_pred_gt = align_general_boxes(
            bboxes_pred_gt,
            real_to_sim.transpose(1, 2).unsqueeze(1).expand(-1, bboxes_pred_gt.shape[1], -1, -1),
            torch.logical_not(bboxes_pred_mask),
            xyz_range_idx=(0, 3),
        )

        egos_pred_gt = model_inputs["egos_pred_gt"]  # [B, 1, T, 2]
        ego_gt_mask = model_inputs["egos_pred_mask"]  # [B, 1, T]
        egos_pred_gt = align_general_boxes(
            egos_pred_gt,
            real_to_sim.transpose(1, 2).unsqueeze(1).expand(-1, egos_pred_gt.shape[1], -1, -1),
            torch.logical_not(ego_gt_mask),
            xyz_range_idx=(0, 3),
        )
        future_msg.update(
            {
                "bboxes_pred_gt": bboxes_pred_gt,
                "egos_pred_gt": egos_pred_gt,
            }
        )
    return (
        bboxes,
        bboxes_padding_mask,
        egos,
        egos_padding_mask,
        lane_points,
        sod_poly_boxes,
        sod_poly_boxes_padding_mask,
        sod_poly_pts,
        sod_poly_pts_padding_mask,
        god_poly_pts,
        god_poly_pts_padding_mask,
        tld,
        tld_padding_mask,
        atlas,
        navi_line_points,
        navi_path_points,
        control_points_trans,
        ar_ego_state,
        ar_ego_action_vocab,
        ar_ego_action_norm,
        ar_agents_state,
        ar_agents_action,
        real_to_sim,
        future_msg,
    )


def transform_in_loop(
    data_save_dict,
    batch_size,
    hist2curr_trans,
    bboxes,
    bboxes_padding_mask,
    egos,
    egos_padding_mask,
    lane_points,
    lane_types,
    sod_poly_boxes,
    sod_poly_boxes_padding_mask,
    sod_poly_pts,
    sod_poly_pts_padding_mask,
    god_poly_pts,
    god_poly_pts_padding_mask,
    tld,
    tld_padding_mask,
    atlas,
    navi_line_points,
    navi_line_types,
    navi_path_points,
    navi_path_types,
    control_points,
    ar_ego_state,
    ar_ego_action_vocab,
    ar_ego_action_norm,
    ar_agents_state,
    ar_agents_action,
    trace_mode,
    train_mode,
    model_inputs,
    # hist_pred_pos=None,  # [B,2]
    # hist_pred_yaw=None,  # [B,1]
    # real_to_sim_last=None,  # [B,4,4]
    # ego_pred_long_vel=None,  # [B]
    hist_pred_info=None,  # [B,4], [x,y,yaw,vx,vy]
    real_to_sim=None,  # [B,4,4]
    sync_cmd=None,
    close_model_name=None,
):
    """
    Transform real observation to sim coord system.
    Details in https://nio.feishu.cn/wiki/UrVBwEaqYiTjwMkEwWQckgrBnWg
    """
    future_msg = {}
    hist_len = egos.shape[1]

    # Get real_to_sim matrix; ego_pred_long_vel
    if trace_mode:
        # hist_pred_pos = torch.index_select(hist_pred_info, dim=1, index=torch.tensor([0, 1]).cuda())  # [B,2]
        # hist_pred_yaw = torch.index_select(hist_pred_info, dim=1, index=torch.tensor([2]).cuda())  # [B,1]
        hist_pred_long_vel = torch.index_select(hist_pred_info, dim=1, index=torch.tensor([3]).cuda())  # [B,1]

        # t0_to_t1 = compute_transform_matrix_t0_to_t1(hist_pred_pos, hist_pred_yaw).transpose(1, 2)  # [B,4,4]
        # t0_to_t1x = hist2curr_trans[:, -2].transpose(1, 2)  # [B,4,4]
        # t1x_to_t0 = torch.linalg.inv(t0_to_t1x)
        # real_to_sim_last = real_to_sim_last  # [B,4,4]
        # real_to_sim = torch.matmul(t1x_to_t0, torch.matmul(real_to_sim_last, t0_to_t1))  # t1x to t1 [B,4,4]
        ego_pred_long_vel = hist_pred_long_vel[:, 0]  # [B]
    else:
        fut_index = 0  # hist pred first point
        if data_save_dict["model_output"] is None:
            real_to_sim = torch.ones(4, 4).unsqueeze(0).repeat(batch_size, 1, 1).cuda()
            ego_pred_long_vel = egos[:, -1, 0, 10]
            sync_cmd = torch.ones_like(sync_cmd)
        else:
            if train_mode:
                save_data = data_save_dict["model_output"]["model_output_dict"][-1]
            else:
                save_data = data_save_dict["model_output"]["model_output_dict"]
            ego_pred_score = save_data["marginal_output"]["ego_pred_score"]  # [B,1,K]
            ego_pred_pos = save_data["marginal_output"]["ego_pred_pos"]  # [B,1,K,T*2]
            ego_pred_yaw = save_data["marginal_output"]["ego_pred_yaw"][..., 0]  # [B,1,K,T]
            ego_pred_long_vel = save_data["marginal_output"]["ego_pred_long_vel"][..., 0]  # [B,1,K,T]
            ego_pred_vel = save_data["marginal_output"]["ego_pred_vel"]  # [B,1,K,T,2]
            max_index = torch.argmax(ego_pred_score[0, 0])

            hist_pred_pos = ego_pred_pos[:, 0, max_index].reshape(batch_size, -1, 2)  # [0]
            hist_pred_yaw = ego_pred_yaw[:, 0, max_index].reshape(batch_size, -1, 1)  # [0]
            hist_pred_vel = ego_pred_vel[:, 0, max_index].reshape(batch_size, -1, 2)  # [0]
            # ego_cur_speed = egos[0, -1, 0, 10]
            ego_cur_speed = ego_pred_long_vel[:, 0, max_index, fut_index]
            lookahead_dist = torch.max(
                torch.tensor(
                    1,
                    device="cuda",
                ),
                ego_cur_speed * 3,
            )
            refined_pos, refined_vel, refined_vel_mag, refined_yaw = pure_pursuit_refine(
                hist_pred_pos,
                hist_pred_vel,
                hist_pred_yaw,
                lookahead_dist=lookahead_dist,
                # lookahead_dist=torch.tensor(10, device="cuda"),
                wheelbase=torch.tensor(2.888, device="cuda"),
            )

            hist_pred_pos = ego_pred_pos[:, 0, max_index].reshape(batch_size, -1, 2)[:, fut_index]
            yaw_t1 = ego_pred_yaw[:, 0, max_index].reshape(batch_size, -1)[:, fut_index].unsqueeze(1)
            yaw_t2 = ego_pred_yaw[:, 0, max_index].reshape(batch_size, -1)[:, fut_index + 1].unsqueeze(1)
            # hist_pred_yaw = average_yaw(yaw_t1, yaw_t2)  # [B,1]
            if close_model_name == "auto_regressive_planner":
                hist_pred_yaw = yaw_t1
            else:
                if torch.abs(yaw_t1) > 0.7:
                    hist_pred_yaw = refined_yaw.unsqueeze(0)
                else:
                    hist_pred_yaw = refined_yaw.unsqueeze(0) * 0.65 + yaw_t1 * 0.35

            t0_to_t1 = compute_transform_matrix_t0_to_t1(hist_pred_pos, hist_pred_yaw).transpose(1, 2)  # [B,4,4]
            # # pred = torch.matmul(hist_pred,t0_to_t1)
            t0_to_t1x = hist2curr_trans[:, -2].transpose(1, 2)  # [B,4,4]
            t1x_to_t0 = torch.linalg.inv(t0_to_t1x)
            real_to_sim_last = data_save_dict.get(
                "real_to_sim", torch.eye(4).unsqueeze(0).repeat(batch_size, 1, 1).cuda()
            )
            real_to_sim = torch.matmul(t1x_to_t0, torch.matmul(real_to_sim_last, t0_to_t1))  # t1x to t1
            data_save_dict["real_to_sim"] = real_to_sim
            # torch.matmul(hist_coord,real_to_sim)
            if close_model_name == "auto_regressive_planner":
                ego_pred_long_vel = ego_pred_long_vel[:, 0, max_index, fut_index]
            else:
                ego_pred_long_vel = ego_pred_long_vel[:, 0, max_index, fut_index] * 0.5 + torch.norm(refined_vel) * 0.5

    ego_pred_long_vel = ego_pred_long_vel * (1 - sync_cmd[:, 0]) + egos[:, -1, 0, 10] * sync_cmd[:, 0]
    real_to_sim = torch.eye(4).unsqueeze(0).repeat(batch_size, 1, 1).cuda() * sync_cmd.unsqueeze(1) + real_to_sim * (
        1 - sync_cmd.unsqueeze(1)
    )

    return transform_percetion_to_sim_coord(
        real_to_sim,
        hist_len,
        ego_pred_long_vel[0:1],
        bboxes,
        bboxes_padding_mask,
        egos,
        egos_padding_mask,
        lane_points,
        lane_types,
        sod_poly_boxes,
        sod_poly_boxes_padding_mask,
        sod_poly_pts,
        sod_poly_pts_padding_mask,
        god_poly_pts,
        god_poly_pts_padding_mask,
        tld,
        tld_padding_mask,
        atlas,
        navi_line_points,
        navi_line_types,
        navi_path_points,
        navi_path_types,
        control_points,
        ar_ego_state,
        ar_ego_action_vocab,
        ar_ego_action_norm,
        ar_agents_state,
        ar_agents_action,
        trace_mode,
        model_inputs,
        future_msg,
    )


def reset_close_loop(
    data_save_dict,
    # batch_size,
    # close_loop_cfg,
):
    data_save_dict["subclip_ids"] = ""
    data_save_dict["close_loop_flag"] = False
    data_save_dict["real_to_sim"] = torch.eye(4).unsqueeze(0).repeat(data_save_dict["batch_size"], 1, 1).cuda()
    data_save_dict["model_output"] = None

    return data_save_dict


def construct_close_loop_input(
    model_inputs=None,
    train_mode=False,
    trace_mode=False,
    close_loop_cfg=None,
    # batch_size=None,
    data_save_dict=None,
):
    """Construct close loop input"""
    if trace_mode and close_loop_cfg["trace_model_in_loop_flag"]:
        hist2curr_trans = model_inputs["hist2curr_trans"]
        hist_pred_info = model_inputs["hist_pred_info"]
        real_to_sim = model_inputs["real_to_sim"]
        sync_cmd = model_inputs["sync_cmd"]
        (
            sim_bboxes,
            sim_bboxes_padding_mask,
            sim_egos,
            sim_egos_padding_mask,
            sim_lane_points,
            sim_sod_poly_boxes,
            sim_sod_poly_boxes_padding_mask,
            sim_sod_poly_pts,
            sim_sod_poly_pts_padding_mask,
            sim_god_poly_pts,
            sim_god_poly_pts_padding_mask,
            sim_tld,
            sim_tld_padding_mask,
            sim_atlas,
            sim_navi_line_points,
            sim_navi_path_points,
            sim_control_points,
            real_to_sim,
            future_msg,
        ), data_save_dict = transform_in_loop(
            data_save_dict,
            data_save_dict["batch_size"],
            hist2curr_trans,
            model_inputs["bboxes"],
            model_inputs["bboxes_padding_mask"],
            model_inputs["egos"],
            model_inputs["egos_padding_mask"],
            model_inputs["lane_points"],
            model_inputs["lane_types"],
            model_inputs.get("sod_poly_boxes", None),
            model_inputs.get("sod_poly_boxes_padding_mask", None),
            model_inputs.get("sod_poly_pts", None),
            model_inputs.get("sod_poly_pts_padding_mask", None),
            model_inputs.get("god_poly_pts", None),
            model_inputs.get("god_poly_pts_padding_mask", None),
            model_inputs.get("tld", None),
            model_inputs.get("tld_padding_mask", None),
            model_inputs.get("atlas", None),
            model_inputs.get("navi_line_points", None),
            model_inputs.get("navi_line_types", None),
            model_inputs.get("navi_path_points", None),  # (1, 1, 30, 2)
            model_inputs.get("navi_path_types", None),  # (1, 1, 30)
            model_inputs.get("control_points", None),
            trace_mode,
            train_mode,
            model_inputs,
            # hist_pred_pos,
            # hist_pred_yaw,
            # real_to_sim_last,
            # ego_pred_long_vel,
            hist_pred_info,  # [B,4], [x,y,yaw,vx,vy]
            real_to_sim,  # [B,4,4]
            sync_cmd,  # [B,1]6q
            close_model_name=close_loop_cfg["model_in_loop_model"],
        )
        for key, val in model_inputs.items():
            if key in [
                "egos",
                "bboxes",
                "lane_points",
                "sod_poly_boxes",
                "sod_poly_pts",
                "god_poly_pts",
                "atlas",
                "navi_line_points",
                "navi_path_points",
                "bboxes_pred_gt",
                "egos_pred_gt",
                "control_points",
            ]:
                pass
            elif type(val) == torch.Tensor:
                model_inputs[key] = torch.cat([val, val], dim=0)
            elif type(val) == list:
                model_inputs[key] = val + val
            elif type(val) == np.ndarray:
                model_inputs[key] = np.concatenate([val, val], axis=0)

        model_inputs["egos"] = torch.cat([model_inputs["egos"], sim_egos], dim=0)
        model_inputs["bboxes"] = torch.cat([model_inputs["bboxes"], sim_bboxes], dim=0)
        model_inputs["lane_points"] = torch.cat([model_inputs["lane_points"], sim_lane_points], dim=0)
        model_inputs["sod_poly_boxes"] = torch.cat([model_inputs["sod_poly_boxes"], sim_sod_poly_boxes], dim=0)
        model_inputs["sod_poly_pts"] = torch.cat([model_inputs["sod_poly_pts"], sim_sod_poly_pts], dim=0)
        model_inputs["god_poly_pts"] = torch.cat([model_inputs["god_poly_pts"], sim_god_poly_pts], dim=0)

        model_inputs["atlas"] = torch.cat([model_inputs["atlas"], sim_atlas], dim=0)
        model_inputs["navi_line_points"] = torch.cat([model_inputs["navi_line_points"], sim_navi_line_points], dim=0)
        model_inputs["navi_path_points"] = torch.cat([model_inputs["navi_path_points"], sim_navi_path_points], dim=0)
        model_inputs["control_points"] = torch.cat([model_inputs["control_points"], sim_control_points], dim=0)

    elif close_loop_cfg["model_in_loop_infer_flag"]:
        # hist2curr_trans = model_inputs["hist2curr_trans"]

        cur_timestamp = model_inputs["timestamp"][0, -1]  # (1)
        target_timestamp_list = close_loop_cfg["model_in_loop_start_timestamp_dict"].get(
            model_inputs["subclip_ids"][0], []
        )
        close_loop_control_by_timestamp = False if target_timestamp_list == [] else True
        cur_timestamp_start = False
        sync_cmd = torch.tensor([[0]], device="cuda")
        if close_loop_control_by_timestamp:
            for target_timestamp in target_timestamp_list:
                if abs(cur_timestamp - target_timestamp) < 0.05:
                    cur_timestamp_start = True
                    close_loop_cfg["model_in_loop_start_timestamp_dict"].pop(model_inputs["subclip_ids"][0])
                    break
        else:
            cur_timestamp_start = True

        sync_timestamp_list = close_loop_cfg["model_in_loop_sync_timestamp_dict"].get(
            model_inputs["subclip_ids"][0], []
        )
        for sync_timestamp in sync_timestamp_list:
            if abs(cur_timestamp - sync_timestamp) < 0.05:
                sync_cmd = torch.tensor([[1]], device="cuda")
                reset_close_loop(data_save_dict)
                break
        if (
            data_save_dict["close_loop_flag"]
            and cur_timestamp_start
            and set(data_save_dict["subclip_ids"]) & set(model_inputs["subclip_ids"])
        ):
            hist2curr_trans = model_inputs["hist2curr_trans"]
        else:
            hist2curr_trans = (
                torch.eye(4)
                .unsqueeze(0)
                .unsqueeze(0)
                .repeat(data_save_dict["batch_size"], model_inputs["hist2curr_trans"].shape[1], 1, 1)
                .cuda()
            )
        if not set(data_save_dict["subclip_ids"]) & set(model_inputs["subclip_ids"]):
            reset_close_loop(data_save_dict)
        (
            sim_bboxes,
            sim_bboxes_padding_mask,
            sim_egos,
            sim_egos_padding_mask,
            sim_lane_points,
            sim_sod_poly_boxes,
            sim_sod_poly_boxes_padding_mask,
            sim_sod_poly_pts,
            sim_sod_poly_pts_padding_mask,
            sim_god_poly_pts,
            sim_god_poly_pts_padding_mask,
            sim_tld,
            sim_tld_padding_mask,
            sim_atlas,
            sim_navi_line_points,
            sim_navi_path_points,
            sim_control_points,
            sim_ar_ego_state,
            sim_ar_ego_action_vocab,
            sim_ar_ego_action_norm,
            sim_ar_agents_state,
            sim_ar_agents_action,
            real_to_sim,
            future_msg,
        ) = transform_in_loop(
            data_save_dict,
            data_save_dict["batch_size"],
            hist2curr_trans,
            model_inputs["bboxes"],
            model_inputs["bboxes_padding_mask"],
            model_inputs["egos"],
            model_inputs["egos_padding_mask"],
            model_inputs["lane_points"],
            model_inputs["lane_types"],
            model_inputs.get("sod_poly_boxes", None),
            model_inputs.get("sod_poly_boxes_padding_mask", None),
            model_inputs.get("sod_poly_pts", None),
            model_inputs.get("sod_poly_pts_padding_mask", None),
            model_inputs.get("god_poly_pts", None),
            model_inputs.get("god_poly_pts_padding_mask", None),
            model_inputs.get("tld", None),
            model_inputs.get("tld_padding_mask", None),
            model_inputs.get("atlas", None),
            model_inputs.get("navi_line_points", None),
            model_inputs.get("navi_line_types", None),
            model_inputs.get("navi_path_points", None),  # (1, 1, 30, 2)
            model_inputs.get("navi_path_types", None),  # (1, 1, 30)
            model_inputs.get("control_points", None),
            model_inputs.get("ar_ego_state", None),
            model_inputs.get("ar_ego_action_vocab", None),
            model_inputs.get("ar_ego_action_norm", None),
            model_inputs.get("ar_agents_state", None),
            model_inputs.get("ar_agents_action", None),
            trace_mode,
            train_mode,
            model_inputs,
            sync_cmd=sync_cmd,
            close_model_name=close_loop_cfg["model_in_loop_model"],
        )
        model_inputs.pop("aligned_trajectory")
        for key, val in model_inputs.items():
            if key in [
                "egos",
                "bboxes",
                "lane_points",
                "sod_poly_boxes",
                "sod_poly_pts",
                "god_poly_pts",
                "atlas",
                "navi_line_points",
                "navi_path_points",
                "bboxes_pred_gt",
                "egos_pred_gt",
                "control_points",
                "ar_ego_state",
                "ar_ego_action_vocab",
                "ar_ego_action_norm",
                "ar_agents_state",
                "ar_agents_action",
            ]:
                pass
            elif type(val) == torch.Tensor:
                model_inputs[key] = torch.cat([val, val], dim=0)
            elif type(val) == list:
                model_inputs[key] = val + val
            elif type(val) == np.ndarray:
                model_inputs[key] = np.concatenate([val, val], axis=0)
        model_inputs["egos"] = torch.cat([model_inputs["egos"], sim_egos], dim=0)
        model_inputs["bboxes"] = torch.cat([model_inputs["bboxes"], sim_bboxes], dim=0)
        model_inputs["lane_points"] = torch.cat([model_inputs["lane_points"], sim_lane_points], dim=0)
        model_inputs["sod_poly_boxes"] = torch.cat([model_inputs["sod_poly_boxes"], sim_sod_poly_boxes], dim=0)
        model_inputs["sod_poly_pts"] = torch.cat([model_inputs["sod_poly_pts"], sim_sod_poly_pts], dim=0)
        model_inputs["god_poly_pts"] = torch.cat([model_inputs["god_poly_pts"], sim_god_poly_pts], dim=0)
        # model_inputs["tld"] = torch.cat([model_inputs["tld"], sim_tld], dim=0)
        # model_inputs["tld_padding_mask"] = torch.cat(
        #     [model_inputs["tld_padding_mask"], sim_tld_padding_mask], dim=0
        # )
        model_inputs["atlas"] = torch.cat([model_inputs["atlas"], sim_atlas], dim=0)
        model_inputs["navi_line_points"] = torch.cat([model_inputs["navi_line_points"], sim_navi_line_points], dim=0)
        model_inputs["navi_path_points"] = torch.cat([model_inputs["navi_path_points"], sim_navi_path_points], dim=0)
        model_inputs["control_points"] = torch.cat([model_inputs["control_points"], sim_control_points], dim=0)
        if "ar_ego_state" in model_inputs:
            model_inputs["ar_ego_state"] = torch.cat([model_inputs["ar_ego_state"], sim_ar_ego_state], dim=0)
            model_inputs["ar_ego_action_vocab"] = torch.cat(
                [model_inputs["ar_ego_action_vocab"], sim_ar_ego_action_vocab], dim=0
            )
            model_inputs["ar_ego_action_norm"] = torch.cat(
                [model_inputs["ar_ego_action_norm"], sim_ar_ego_action_norm], dim=0
            )
            model_inputs["ar_agents_state"] = torch.cat([model_inputs["ar_agents_state"], sim_ar_agents_state], dim=0)
            model_inputs["ar_agents_action"] = torch.cat(
                [model_inputs["ar_agents_action"], sim_ar_agents_action], dim=0
            )
        if not trace_mode:
            model_inputs["bboxes_pred_gt"] = torch.cat(
                [model_inputs["bboxes_pred_gt"], future_msg["bboxes_pred_gt"]], dim=0
            )
            model_inputs["egos_pred_gt"] = torch.cat([model_inputs["egos_pred_gt"], future_msg["egos_pred_gt"]], dim=0)

        if not cur_timestamp_start:
            reset_close_loop(data_save_dict)
        else:
            if data_save_dict["subclip_ids"] != model_inputs["subclip_ids"]:  # clip切换
                reset_close_loop(data_save_dict)
                data_save_dict["subclip_ids"] = model_inputs["subclip_ids"]
                data_save_dict["close_loop_flag"] = True
        model_inputs["real_to_sim"] = torch.cat([real_to_sim, real_to_sim], dim=0)
    model_inputs["model_sync_cmd"] = torch.zeros((2, 1), device="cuda")


def forward_close_loop(
    output_dict,
    model_inputs,
    train_mode,
    trace_mode,
    close_loop_cfg,
    data_save_dict,
    encoder_output,
):
    """Forward close loop."""
    if close_loop_cfg["model_in_loop_infer_flag"]:
        real_to_sim = model_inputs["real_to_sim"]
        # rotation_theta = torch.atan2(real_to_sim[:, 0, 1], real_to_sim[:, 0, 0])[-1]
        rotation_theta = torch.abs(get_theta_from_trans(real_to_sim))  # [1]
        # translation = real_to_sim[:, -1, 0:2]
        translation = torch.abs(get_translation_from_trans(real_to_sim))  # [2]

        if close_loop_cfg["model_in_loop_model"] == "goal_point_planner":
            goal_point_output = (
                output_dict["goal_point_planner_pred_output"][-1]["marginal_output"]
                if train_mode
                else output_dict["goal_point_planner_pred_output"]["marginal_output"]
            )
            target_index = 0 if not train_mode else slice(None)
            ego_pred_pos = goal_point_output["ego_pred_pos"][:, target_index]  # [B,1,K,T*2]
            ego_pred_score = goal_point_output["ego_pred_score"][:, target_index]  # [B,1,K]
            ego_pred_yaw = goal_point_output["ego_pred_yaw"][:, target_index]  # [B,1,K,T,1]
        elif close_loop_cfg["model_in_loop_model"] == "astra_planner":
            if train_mode:
                ego_pred_pos = output_dict["astra_planner_pred_output"][-1]["marginal_output"][
                    "ego_pred_pos"
                ]  # [B,1,K,T*2]
                ego_pred_score = output_dict["astra_planner_pred_output"][-1]["marginal_output"][
                    "ego_pred_score"
                ]  # [B,1,K]
                ego_pred_yaw = output_dict["astra_planner_pred_output"][-1]["marginal_output"][
                    "ego_pred_yaw"
                ]  # [B,1,K,T,1]
            else:
                ego_pred_pos = output_dict["astra_planner_pred_output"]["marginal_output"][
                    "ego_pred_pos"
                ]  # [B,1,K,T*2]
                ego_pred_score = output_dict["astra_planner_pred_output"]["marginal_output"][
                    "ego_pred_score"
                ]  # [B,1,K]
                ego_pred_yaw = output_dict["astra_planner_pred_output"]["marginal_output"][
                    "ego_pred_yaw"
                ]  # [B,1,K,T,1]
        elif close_loop_cfg["model_in_loop_model"] == "auto_regressive_planner":
            ego_pred_pos = output_dict["auto_regressive_planner_output"]["dynamic_states"][
                "ego"
            ]  # [B*sample,1,T_all,4]
            sample_size = ego_pred_pos.shape[0] // 2
            ego_pred_pos = ego_pred_pos[[0, sample_size], :, 15:]  # [B,1,T,2]
            ego_pred_yaw = ego_pred_pos[..., 2:3].reshape(2, 1, 1, -1, 1)  # [B,1,K,T,1]
            ego_pred_pos = ego_pred_pos[..., 0:2].reshape(2, 1, 1, -1)  # [B,1,1,T*2]
            ego_pred_score = (ego_pred_pos * 0 + 1)[..., 0]  # [B,1,1]
        else:
            raise ValueError("model_in_loop_model not supported: ", close_loop_cfg["model_in_loop_model"])
        max_index = torch.argmax(ego_pred_score[-1, 0])
        batch_size = model_inputs["egos"].shape[0]

        egos = model_inputs["egos"]  # [B,T,1,15]
        time_index = torch.tensor([egos.shape[1] - 1], device="cuda")
        egos_t = torch.index_select(egos, dim=1, index=time_index)  # [B, 1,1,15]
        vel_index = torch.tensor([10, 11], device="cuda")
        cur_ego_vel = torch.index_select(egos_t, dim=3, index=vel_index).squeeze()[0]  # [2]

        top1_ego_pred_pos = (
            torch.index_select(ego_pred_pos, 2, max_index).squeeze().reshape(batch_size, -1, 2)
        )  # [B,T,2]
        top1_ego_pred_yaw = torch.index_select(ego_pred_yaw, 2, max_index).squeeze()  # [B,T]

        top1_ego_pred_pos_real = top1_ego_pred_pos[0:1]  # [B//2,T,2]
        top1_ego_pred_pos_sim = top1_ego_pred_pos[1:]  # [B//2,T,2]
        top1_ego_pred_yaw_real = top1_ego_pred_yaw[0:1]  # [B//2,T,1]

        real_sim_pred_close = is_real_sim_pred_close(
            top1_ego_pred_pos_real,
            top1_ego_pred_pos_sim,
            top1_ego_pred_yaw_real,
            cur_ego_vel,
            trace_mode=trace_mode,
            verbose=True,
        )

        model_sync_flag = (
            (
                rotation_theta
                > torch.tensor(close_loop_cfg["close_loop_sync_msg"]["rotation_theta_threshold"], device="cuda")
            )
            + (
                translation[0]
                > torch.tensor(close_loop_cfg["close_loop_sync_msg"]["translation_threshold"][0], device="cuda")
            )
            + (
                translation[1]
                > torch.tensor(close_loop_cfg["close_loop_sync_msg"]["translation_threshold"][0], device="cuda")
            )
            + (1 - real_sim_pred_close)
        ).float() > 0
        model_sync_flag = (
            torch.tensor(close_loop_cfg["close_loop_sync_msg"]["close_loop_enable_sync"], device="cuda")
            * model_sync_flag
        )
        if not trace_mode:
            logger.info(
                "Timestamp: %s, Translation: %s, Rotation Theta: %s",
                model_inputs["timestamp"][0, -1],
                translation.detach().cpu().numpy().tolist(),
                rotation_theta.detach().cpu().numpy(),
            )
            if model_sync_flag:
                reset_close_loop(data_save_dict)
                logger.info("sync in %s", model_inputs["timestamp"][0, -1])
        else:
            model_inputs["model_sync_cmd"] = (
                model_sync_flag * torch.ones((2, 1), device="cuda")
                + torch.logical_not(model_sync_flag) * model_inputs["model_sync_cmd"]
            )
        output_dict = recursively_slice(output_dict, model_sync_flag)
        model_inputs = recursively_slice(model_inputs, model_sync_flag)
        if not model_sync_flag:
            if close_loop_cfg["model_in_loop_model"] == "goal_point_planner":
                goal_output = (
                    output_dict["goal_point_planner_pred_output"][-1]["marginal_output"]
                    if train_mode
                    else output_dict["goal_point_planner_pred_output"]["marginal_output"]
                )
                target_index = 0 if not train_mode else slice(None)
                fake_planner_pred_output = {}
                marginal_output = {}
                marginal_output["ego_pred_pos"] = goal_output["ego_pred_pos"][:, target_index]  # [1,1,1,T*2]
                marginal_output["ego_pred_yaw"] = goal_output["ego_pred_yaw"][:, target_index]  # [1,1,1,T,1]
                marginal_output["ego_pred_score"] = goal_output["ego_pred_score"][:, target_index]  # [1,1,1]
                marginal_output["ego_pred_long_vel"] = goal_output["ego_pred_long_vel"][:, target_index]  # [1,1,1,T,1]
                marginal_output["ego_pred_vel"] = goal_output["ego_pred_vel"][:, target_index]  # [1,1,1,T,2]
                fake_planner_pred_output["marginal_output"] = marginal_output
                fake_planner_pred_output = [fake_planner_pred_output] if train_mode else fake_planner_pred_output
                one_step_dict = {
                    "model_output_dict": fake_planner_pred_output,
                }
            elif close_loop_cfg["model_in_loop_model"] == "auto_regressive_planner":
                ego_output = output_dict["auto_regressive_planner_output"]["dynamic_states"]["ego"]  # [B,1,T_all,4]
                ego_output_future = ego_output[:, :, 15:, :]  # [B,1,T,4]
                bs, _, t_fut, _ = ego_output_future.shape
                fake_planner_pred_output = {}
                marginal_output = {}
                marginal_output["ego_pred_pos"] = ego_output_future[:, :, :, 0:2].reshape(
                    bs, 1, 1, t_fut * 2
                )  # [B,1,1,T*2]
                marginal_output["ego_pred_yaw"] = ego_output_future[:, :, :, 2:3].reshape(
                    bs, 1, 1, t_fut, 1
                )  # [B,1,1,T,1]
                marginal_output["ego_pred_score"] = torch.ones_like(
                    marginal_output["ego_pred_pos"][:, :, :, 0]
                )  # [B,1,1]
                marginal_output["ego_pred_long_vel"] = ego_output_future[:, :, :, 3:4].reshape(
                    bs, 1, 1, t_fut, 1
                )  # [B,1,1,T,1]
                # decompose long_vel into vel with yaw_rate
                sin_yaw = torch.sin(marginal_output["ego_pred_yaw"])
                cos_yaw = torch.cos(marginal_output["ego_pred_yaw"])
                marginal_output["ego_pred_vel"] = torch.stack(
                    [sin_yaw * marginal_output["ego_pred_long_vel"], cos_yaw * marginal_output["ego_pred_long_vel"]],
                    dim=-1,
                )  # [B,1,1,T,2]
                fake_planner_pred_output["marginal_output"] = marginal_output
                fake_planner_pred_output = [fake_planner_pred_output] if train_mode else fake_planner_pred_output
                one_step_dict = {
                    "model_output_dict": fake_planner_pred_output,
                }
            else:
                one_step_dict = {
                    "model_output_dict": output_dict["astra_planner_pred_output"],
                }
            data_save_dict["model_output"] = one_step_dict

    if not trace_mode:
        if "egos_pred_gt" in model_inputs:
            output_dict["transformed_input"] = dict()
            output_dict["transformed_input"]["bboxes"] = model_inputs["bboxes"]
            output_dict["transformed_input"]["egos"] = model_inputs["egos"]
            output_dict["transformed_input"]["bboxes_pred_gt"] = model_inputs["bboxes_pred_gt"]
            output_dict["transformed_input"]["bboxes_padding_mask"] = encoder_output["bboxes_padding_mask"].transpose(
                1, 2
            )
            output_dict["transformed_input"]["egos_pred_gt"] = model_inputs["egos_pred_gt"]
            output_dict["transformed_input"]["lane_points"] = (
                model_inputs["lane_points"] if "lane_points" in model_inputs else model_inputs["manner_lane_points"]
            )
            # output_dict["transformed_input"]["navi_line_points"] = model_inputs["navi_line_points"]
            output_dict["transformed_input"]["navi_path_points"] = model_inputs["navi_path_points"]
            output_dict["transformed_input"]["atlas"] = model_inputs["atlas"]

            if close_loop_cfg["model_in_loop_infer_flag"]:
                output_dict["trans_in_loop"] = model_inputs

    output_dict["model_sync_cmd"] = (
        model_inputs["model_sync_cmd"] if "model_sync_cmd" in model_inputs else close_loop_cfg["model_sync_cmd"][0:1]
    )


def pure_pursuit_refine(
    pred_pos: torch.Tensor,  # [B, T, 2]
    pred_vel: torch.Tensor,  # [B, T, 2]
    pred_yaw: torch.Tensor,  # [B, T, 1]
    lookahead_dist: torch.Tensor,  # [B], 每个轨迹单独的 lookahead 距离
    wheelbase: float = 2.5,
    t_target: float = 0.2,
    dt: float = 0.2,
):
    """
    Refines the Ego vehicle state at t_target for a batch of predicted trajectories
    using a Pure Pursuit + constant acceleration assumption.

    Args:
        pred_pos (torch.Tensor):  [B, T, 2], predicted positions (x, y)
        pred_vel (torch.Tensor):  [B, T, 2], predicted velocities (vx, vy)
        pred_yaw (torch.Tensor):  [B, T, 1], predicted yaw angles
        lookahead_dist (torch.Tensor): [B],  look-ahead distances for each trajectory
        wheelbase (float): vehicle wheelbase (default=2.5 meters)
        t_target (float): target time (default=0.2s)
        dt (float): time step for discrete integration in this refine process (default=0.2s)

    Returns:
        refined_pos (torch.Tensor):     [B, 2], refined positions at t_target
        refined_vel (torch.Tensor):     [B, 2], refined velocities at t_target
        refined_vel_mag (torch.Tensor): [B],    refined velocity magnitudes
        refined_yaw (torch.Tensor):     [B],    refined yaw angles at t_target
    """
    device = pred_pos.device
    B, T, _ = pred_pos.shape  # pred_pos.shape=[B,T,2]

    # ==================== (1) Ego 初始状态 ====================
    # ego_pos: [B, 2]
    ego_pos = pred_pos[:, 0, :] * 0
    # ego_vel_mag: [B]
    ego_vel_mag = torch.norm(pred_vel[:, 0, :], dim=-1)
    # ego_yaw: [B]
    ego_yaw = pred_yaw[:, 0, 0] * 0

    # ==================== (2) 找各自 look-ahead 索引 ====================
    # 计算各轨迹从 ego_pos 到各时刻的距离 => shape [B, T]
    # pred_pos.shape=[B,T,2], ego_pos.shape=[B,2] => 需要对 ego_pos 扩展维度进行广播
    distances = torch.norm(pred_pos - ego_pos.unsqueeze(1), dim=-1)  # [B, T]

    # 对每条轨迹分别比较:  distance >= lookahead_dist[b]
    # 这里 lookahead_dist.shape=[B], 需要在 T 维度上广播 => unsqueeze(-1)
    # mask.shape=[B,T]
    mask = distances >= lookahead_dist.unsqueeze(-1)

    # 判断哪些轨迹全程都没有 >= lookahead_dist
    any_valid = mask.any(dim=1)  # [B], 有无至少一个True

    # 第一个 True 的位置，若找不到则 argmax 返回0，需要后面处理
    first_true_indices = mask.float().argmax(dim=1)  # [B]

    # 若整条轨迹都不满足 => 用最后一个时刻 T-1
    target_idx = first_true_indices.clone()
    target_idx[~any_valid] = T - 1

    # 确保 target_idx >= 1
    target_idx = torch.clamp(target_idx, min=1, max=T - 1)

    # ==================== (3) 目标点与目标速度 ====================
    # target_pos: [B, 2]
    target_pos = pred_pos[torch.arange(B, device=device), target_idx, :]
    # target_vel_mag: [B]
    target_vel_mag = torch.norm(pred_vel[torch.arange(B, device=device), target_idx, :], dim=-1)
    # target_yaw: [B]
    target_yaw = pred_yaw[torch.arange(B, device=device), target_idx, 0]

    # t_total: [B], 从 idx=0 ~ target_idx 对应的时间间隔 (pred step假设=0.2s)
    t_total = target_idx.float() * 0.2
    epsilon = 1e-6
    # a = (v_target - v0) / t_total
    acceleration = torch.where(
        t_total < epsilon, torch.zeros_like(t_total, device=device), (target_vel_mag - ego_vel_mag) / t_total
    )  # [B]

    # ==================== (4) 离散积分(纯追踪+匀加速) ====================
    steps = int(t_target / dt)

    v = ego_vel_mag.clone()
    x = ego_pos[:, 0].clone()
    y = ego_pos[:, 1].clone()
    yaw = ego_yaw.clone()

    # steering_angle (固定值): alpha = target_angle - yaw
    dx = target_pos[:, 0] - x
    dy = target_pos[:, 1] - y
    target_angle = torch.atan2(dy, dx)  # [B]
    alpha = target_angle - yaw
    alpha = torch.atan2(torch.sin(alpha), torch.cos(alpha))  # 归一化到[-pi,pi]

    # steering_angle: [B], 逐元素 / 不同的 lookahead_dist
    steering_angle = torch.atan2(2.0 * wheelbase * torch.sin(alpha), lookahead_dist)  # [B]

    for _ in range(steps):
        # v += a*dt
        v = v + acceleration * dt
        # x, y
        x = x + v * torch.cos(yaw) * dt
        y = y + v * torch.sin(yaw) * dt
        # yaw => yaw + (v / wheelbase)*tan(steering)*dt
        yaw = yaw + (v / wheelbase) * torch.tan(steering_angle) * dt
        yaw = torch.atan2(torch.sin(yaw), torch.cos(yaw))  # 归一化到[-pi,pi]

    # ==================== (5) 打包输出 ====================
    # refined_pos: [B, 2]
    refined_pos = torch.stack([x, y], dim=-1)
    # refined_vel_mag: [B]
    refined_vel_mag = v
    # refined_vel: 与 yaw 对齐
    refined_vel = refined_vel_mag.unsqueeze(-1) * torch.stack([torch.cos(yaw), torch.sin(yaw)], dim=-1)
    refined_yaw = yaw

    return refined_pos, refined_vel, refined_vel_mag, refined_yaw
