# -*- coding: utf-8 -*-
import argparse
from pathlib import Path
from typing import Optional

from torchpilot import logger

from tpp_onemodel.utils.nts.ntsctl import NtsCtlConstants


_nts_ctl_consts = NtsCtlConstants()


def get_last_modified_checkpoint(
    checkpoint_dir: Path, checkpoint_suffix: str = _nts_ctl_consts.CKPT_SUFFIX
) -> Optional[str]:
    """Get last modified checkpoint."""
    if not checkpoint_dir.exists():
        logger.error("Checkpoint directory does not exist: %s", checkpoint_dir)
        return None

    checkpoints = list(checkpoint_dir.glob(f"*{checkpoint_suffix}"))
    if not checkpoints:
        logger.error("No checkpoints found in directory: %s", checkpoint_dir)
        return None
    last_checkpoint = max(checkpoints, key=lambda x: x.stat().st_mtime)
    return last_checkpoint.as_posix()


def main() -> None:
    """Define main function."""
    parser = argparse.ArgumentParser(description="Get last modified checkpoint.")
    parser.add_argument("checkpoint_dir", type=Path, help="Path to checkpoint directory.")
    parser.add_argument(
        "--checkpoint_suffix",
        type=str,
        default=_nts_ctl_consts.CKPT_SUFFIX,
        help="Suffix of checkpoint files.",
    )
    args = parser.parse_args()
    logger.info(
        "Last modified checkpoint: %s", get_last_modified_checkpoint(args.checkpoint_dir, args.checkpoint_suffix)
    )


if __name__ == "__main__":
    main()
