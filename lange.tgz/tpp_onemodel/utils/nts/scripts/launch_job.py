# -*- coding: utf-8 -*-
import argparse
import json
import tempfile
import time
from pathlib import Path
from subprocess import check_call  # noqa: S404
from typing import Dict
from typing import List
from typing import Optional

from torchpilot import logger

from tpp_onemodel.configs.planner.planner_configs import DecoderExpParams
from tpp_onemodel.configs.planner.planner_configs import PlannerParams
from tpp_onemodel.utils.nts.ntsctl import GPUType
from tpp_onemodel.utils.nts.ntsctl import NtsCtlCommands
from tpp_onemodel.utils.nts.ntsctl import NtsCtlConstants
from tpp_onemodel.utils.nts.ntsctl import NtsCtlJobTemplate
from tpp_onemodel.utils.nts.ntsctl import NtsCtlResourceTemplate
from tpp_onemodel.utils.nts.ntsctl import NtsInstanceType
from tpp_onemodel.utils.nts.ntsctl import NtsJobPriorities
from tpp_onemodel.utils.nts.scripts import get_run_last_ckpt
from tpp_onemodel.utils.nts.scripts.get_run_last_ckpt import (
    get_last_modified_checkpoint,
)
from tpp_onemodel.utils.params_utils import Params  # type: ignore[attr-defined]


_nts_ctl_consts = NtsCtlConstants()


class ParamsTypes(Params):
    """Define parameters clases."""

    # Planner parameters sets
    planner_params: PlannerParams = PlannerParams()  # type: ignore
    planner_decoder: DecoderExpParams = DecoderExpParams()  # type: ignore

    @property
    def params_names_paths(self) -> Dict[str, Path]:
        """Return dict of params names and paths."""
        params: List[Dict[str, Path]] = [params.available_params() for _, params in self if isinstance(params, Params)]
        return {name: path for param in params for name, path in param.items()}

    @property
    def params_names(self) -> List[str]:
        """Return list of params names."""
        return list(self.params_names_paths.keys())


def _parse_args() -> argparse.Namespace:
    """Parse arguments for job launcher."""
    arguments_parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    arguments_parser.add_argument(
        "-s", "--params_name", help="Name of params to use", choices=ParamsTypes().params_names, type=str, default=None
    )
    arguments_parser.add_argument("-p", "--params_path", help="Path to params file", type=Path, default=None)
    arguments_parser.add_argument("-n", "--run_name", help="Name of the run", type=str, required=True)
    # Resources
    arguments_parser.add_argument("-g", "--num_gpus", help="Number of GPUs to use", type=int, default=1)
    arguments_parser.add_argument("--infer_only", help="Run inference only", action="store_true", default=False)
    arguments_parser.add_argument(
        "--train_with_infer",
        help="Run training and after run with inference during the same job",
        action="store_true",
    )
    arguments_parser.add_argument(
        "--checkpoint",
        help="Path to checkpoint to use for inference",
        type=Path,
        default=None,
    )
    arguments_parser.add_argument(
        "--torchpilot_out_dir",
        help="Override of the default path to torchpilot output directory",
        type=Path,
        default=None,
    )
    arguments_parser.add_argument(
        "-l",
        "--log_level",
        default="INFO",
        type=str,
        choices=["INFO", "WARNING", "ERROR", "DEBUG"],
        help="Logging level for the script (default: %(default)s)",
    )
    return arguments_parser.parse_args()


def _get_params_path(params_name: str, params_path: Optional[Path] = None) -> Path:
    if params_path:
        return params_path
    return ParamsTypes().params_names_paths[params_name]


def _get_experiment_out_dir(run_name: str, params_name: str, params_path: Optional[Path] = None) -> Path:
    params_path = _get_params_path(params_name, params_path)
    run_path_name = params_path.parts[-3:]
    assert "experiments" not in run_path_name, f"params_path should not contain 'experiments' in path: {params_path}"
    return _nts_ctl_consts.TORCHPILOT_OUTPUT_DIR / Path(*run_path_name).parent / Path(run_name)


def _run_job(
    params_name: str,
    run_name: str,
    num_gpus: int,
    params_path: Optional[Path] = None,
    checkpoint: Optional[str] = None,
    infer_after: bool = True,
) -> None:
    params_path = _get_params_path(params_name, params_path)

    run_cmd = f"bash run.sh {num_gpus} {params_path} -n {run_name}"
    if checkpoint:
        # -it - inference type, see torchpilot run for more details
        run_cmd += f" -it torch -c {checkpoint}"

    # Check if run_name folder exists in torchpilot_output
    run_output_dir = _get_experiment_out_dir(run_name=run_name, params_name=params_name, params_path=params_path)
    if _nts_ctl_consts.TORCHPILOT_OUTPUT_DIR.joinpath(run_output_dir).exists() and not checkpoint:
        logger.error("Run output directory already exists: %s, please choose another name for the run.", run_output_dir)
        exit(1)

    job_template = NtsCtlJobTemplate(
        NumNodes=_nts_ctl_consts.get_num_nodes(num_gpus),
        Resource=NtsCtlResourceTemplate(
            CPU=_nts_ctl_consts.get_max_cpus_per_node(num_gpus),
            GPUs={str(GPUType.A100_15C): _nts_ctl_consts.get_gpus_per_node(num_gpus)},
            Memory=_nts_ctl_consts.get_max_memory_per_node(num_gpus),
        ),
        Priority=NtsJobPriorities.NORMAL,
        Type=NtsInstanceType.JOB,
        Image=_nts_ctl_consts.IMAGE_NAME,
        WorkingDir=list(Path(__file__).absolute().parents)[-5],
        Command=run_cmd,
        as_root=False,
        Env={"TORCHPILOT_output_dir": _nts_ctl_consts.TORCHPILOT_OUTPUT_DIR.as_posix()},
    )
    with tempfile.NamedTemporaryFile("w", delete=False) as f:
        if not checkpoint and infer_after:
            last_ckpt_script = get_run_last_ckpt.__file__
            last_ckpt_cmd = f"pipenv run python {last_ckpt_script} {run_output_dir / _nts_ctl_consts.CKPT_DIR_NAME}"
            job_template.Command += (
                f" && bash run.sh {num_gpus} {params_path} -n {run_name} -it torch -c `{last_ckpt_cmd}`"
            )

        json.dump(json.loads(job_template.json()), f, indent=4)
        f.close()
        logger.info("Job template: ")
        check_call(f"cat {f.name}", shell=True)  # noqa: S602
        job_cmd: str = f"{NtsCtlCommands.run_job_with_template} {f.name}"  # type: ignore
        logger.info("Running job with command: %s", job_cmd)
        # Actually run the job on the NTS cluster
        check_call(job_cmd, shell=True)  # noqa: S602
        time.sleep(1)


def main() -> None:
    """Define a main function for the job launcher."""
    args = _parse_args()
    if not args.params_name and not args.params_path:
        raise ValueError("Either params_name or params_path must be provided")
    logger.setLevel(args.log_level)
    if args.torchpilot_out_dir:
        _nts_ctl_consts.set_torchpilot_output_dir(args.torchpilot_out_dir)

    if not args.infer_only:
        # Run training job
        _run_job(
            args.params_name,
            args.run_name,
            args.num_gpus,
            params_path=args.params_path,
            infer_after=args.train_with_infer,
        )
    else:
        # Run inference job
        logger.info("Inference job started")
        output_dir: Path = _get_experiment_out_dir(
            run_name=args.run_name, params_name=args.params_name, params_path=args.params_path
        )
        if args.checkpoint and args.checkpoint.exists():
            checkpoint_path = args.checkpoint
        elif not (checkpoint_path := get_last_modified_checkpoint(output_dir / _nts_ctl_consts.CKPT_DIR_NAME)):
            logger.error("No checkpoint found for inference")
            return

        _run_job(
            args.params_name, args.run_name, args.num_gpus, params_path=args.params_path, checkpoint=checkpoint_path
        )


if __name__ == "__main__":
    main()
