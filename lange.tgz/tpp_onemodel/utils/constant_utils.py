# -*- coding: utf-8 -*-
"""utility functions for constants."""
import functools
import importlib
import logging
import os
import time
from typing import Any
from typing import Dict
from typing import Optional


def load_constants(module_name: str) -> Dict[str, Any]:
    """Load constants from a module, constants in format CONSTANT_ONE."""
    try:
        module = importlib.import_module(module_name)
        constants = {attr: value for attr, value in module.__dict__.items() if attr.isupper()}
        return constants
    except ImportError:
        raise ImportError(f"Module '{module_name}' not found.")


def get_env_or_constant(*, constants: Dict[str, Any], attr: str, default: Optional[str] = None) -> Any:
    """Get the value of an environment variable."""
    if attr not in constants:
        raise ValueError(f"{attr} is not a constant.")

    if (constant := os.environ.get(attr, constants[attr])) == attr:
        if not default:
            raise ValueError(f"{attr} environment variable is not set.")
        return default
    return constant


def print_all_constants(constants) -> None:
    """Print all constants and their values."""
    for attr in dir(constants):
        if attr.isupper():  # Assuming constants are uppercase
            value = get_env_or_constant(constants=constants, attr=attr)
            print(f"{attr}: {value}")  # noqa: T201


def get_all_constants(constants) -> Dict[str, Any]:
    """Get a dictionary of all constants and their values."""
    return {attr: get_env_or_constant(constants=constants, attr=attr) for attr in dir(constants) if attr.isupper()}


def retry(n: int, sleep_time=2, logger=logging.error):
    """Add a decorator to retry a function n times with a sleep time between retries."""

    def _w(fn):
        @functools.wraps(fn)
        def _f(*args, **kargs):
            for _ in range(n):
                try:
                    return fn(*args, **kargs)
                except Exception as e:
                    logger(str(e))
                    logger("Error with args: %s, kargs: %s", str(args), str(kargs))
                    time.sleep(sleep_time)

        return _f

    return _w
