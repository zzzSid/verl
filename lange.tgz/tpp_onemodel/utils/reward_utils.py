# -*- coding: utf-8 -*-
# flake8: noqa
from enum import Enum
import math
import numpy as np
import math
import statistics
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation as R
from shapely.geometry import LineString
from shapely.geometry import MultiLineString
from shapely.geometry import MultiPolygon
from shapely.geometry import Polygon
from shapely.geometry import Point
from shapely.ops import nearest_points

from scipy.spatial.transform import Rotation as R
from tpp_onemodel.constant import LANE_DIRECTION_TO_TLD_ID_MAPPING
from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import ScenarioEnum


class Turntype(Enum):
    UNKNOWN = 0
    STRAIGHT = 1
    LEFT = 2
    RIGHT = 3
    UTURN = 4


road_arrow_to_lane_direction_mapping = {
    201: 0b01000,  # RoadSignClass_RoadArrow_Left
    202: 0b00010,  # RoadSignClass_RoadArrow_Right
    203: 0b01010,  # RoadSignClass_RoadArrow_Left_Right
    204: 0b00100,  # RoadSignClass_RoadArrow_Straight
    205: 0b00110,  # RoadSignClass_RoadArrow_Straight_Right
    206: 0b01100,  # RoadSignClass_RoadArrow_Straight_Left
    207: 0b10000,  # RoadSignClass_RoadArrow_Only_Turn
    208: 0b11000,  # RoadSignClass_RoadArrow_Left_Turn
    209: 0b10100,  # RoadSignClass_RoadArrow_Straight_Turn
    210: 0b00100,  # RoadSignClass_RoadArrow_Left_Merge
    211: 0b00100,  # RoadSignClass_RoadArrow_Right_Merge
    213: 0b00000,  # RoadSignClass_RoadArrow_Forbid_Only_Sign
    214: 0b10110,  # RoadSignClass_RoadArrow_Forbid_Left_Sign
    215: 0b11100,  # RoadSignClass_RoadArrow_Forbid_Right_Sign
    216: 0b11010,  # RoadSignClass_RoadArrow_Forbid_Straight_Sign
    217: 0b01110,  # RoadSignClass_RoadArrow_Forbid_Turn_Sign
    220: 0b00110,  # RoadSignClass_RoadArrow_Forbid_Left_And_Turn_Sign
}


def normalize_angle(angle):
    return (angle + math.pi) % (2 * math.pi) - math.pi


def get_vector_angle(v1, v2):
    dot_product = v1[0] * v2[0] + v1[1] * v2[1]
    norm_v1 = math.sqrt(v1[0] ** 2 + v1[1] ** 2)
    norm_v2 = math.sqrt(v2[0] ** 2 + v2[1] ** 2)

    # 处理零向量
    if norm_v1 == 0 or norm_v2 == 0:
        return 0.0  # 零向量的夹角定义为0

    cos_theta = dot_product / (norm_v1 * norm_v2)
    # 处理浮点数精度问题
    cos_theta = max(-1.0, min(1.0, cos_theta))
    theta = math.acos(cos_theta)
    return normalize_angle(theta)


def distance_point_to_segment(x, y, x1, y1, x2, y2):

    if x1 == x2 and y1 == y2:
        return ((x - x1) ** 2 + (y - y1) ** 2) ** 0.5
    dx = x2 - x1
    dy = y2 - y1
    ax = x - x1
    ay = y - y1

    t_n = ax * dx + ay * dy
    t_d = dx * dx + dy * dy
    t = t_n / t_d
    if t < 0.0:
        closest_x = x1
        closest_y = y1
    elif t > 1.0:
        closest_x = x2
        closest_y = y2
    else:
        closest_x = x1 + t * dx
        closest_y = y1 + t * dy
    distance = ((x - closest_x) ** 2 + (y - closest_y) ** 2) ** 0.5
    return distance


def calc_path_length(path_points):
    # distance between the start point and end point
    start_points = path_points[:-1]
    end_points = path_points[1:]
    norm_vec = np.linalg.norm(end_points - start_points, axis=1)
    return np.sum(norm_vec)


def direction(p1, p2, p3):
    return (p2[0] - p1[0]) * (p3[1] - p1[1]) - (p2[1] - p1[1]) * (p3[0] - p1[0])


def polygon_to_segments(polygon):
    return [(polygon[i], polygon[(i + 1) % 4]) for i in range(4)]


def get_relative_pose_from_obj(obj1, obj2):
    """
    obj1, obj2: at least 7 dim, x, y, z, l, w, h, yaw, ....
    """
    obj1_pose = np.eye(4)
    obj1_pose[:3, :3] = R.from_euler("z", obj1[6]).as_matrix()
    obj1_pose[:3, 3] = obj1[:3]
    obj2_pose = np.eye(4)
    obj2_pose[:3, :3] = R.from_euler("z", obj2[6]).as_matrix()
    obj2_pose[:3, 3] = obj2[:3]
    return np.linalg.inv(obj1_pose) @ obj2_pose


def get_lines_distance(lines, pt):
    # lines: n * 2
    # return sorted index and distance
    lines_distance = dict()
    for i, poly_line in enumerate(lines):
        dist = distance_point_to_segment(
            pt[0], pt[1], poly_line[0, 0], poly_line[0, 1], poly_line[1, 0], poly_line[1, 1]
        )
        lines_distance[i] = dist
    sorted_lines_distance = dict(sorted(lines_distance.items(), key=lambda item: item[1]))
    sorted_lines_index = list(sorted_lines_distance.keys())

    return sorted_lines_index, sorted_lines_distance


def segment_intersect(a1, a2, b1, b2):
    d1 = direction(b1, b2, a1)
    d2 = direction(b1, b2, a2)
    d3 = direction(a1, a2, b1)
    d4 = direction(a1, a2, b2)

    if (d1 * d2 < 0) and (d3 * d4 < 0):
        return True

    if d1 == 0 and on_segment(a1, b1, b2):
        return True
    if d2 == 0 and on_segment(a2, b1, b2):
        return True
    if d3 == 0 and on_segment(b1, a1, a2):
        return True
    if d4 == 0 and on_segment(b2, a1, a2):
        return True
    return False


def line_intersection_point(a1, a2, b1, b2):

    d = (a2[0] - a1[0]) * (b2[1] - b1[1]) - (a2[1] - a1[1]) * (b2[0] - b1[0])
    if d == 0:
        return np.array([])  # 线段平行或重合

    t = ((b1[0] - a1[0]) * (b2[1] - b1[1]) - (b1[1] - a1[1]) * (b2[0] - b1[0])) / d
    s = ((b1[0] - a1[0]) * (a2[1] - a1[1]) - (b1[1] - a1[1]) * (a2[0] - a1[0])) / d
    if 0 <= t <= 1 and 0 <= s <= 1:
        return np.array((a1[0] + t * (a2[0] - a1[0]), a1[1] + t * (a2[1] - a1[1])))

    return np.array([])  # 线段不相交


def get_projection_on_segment(x, y, x1, y1, x2, y2):
    if x1 == x2 and y1 == y2:
        return np.array([])
    dx = x2 - x1
    dy = y2 - y1
    ax = x - x1
    ay = y - y1

    t_n = ax * dx + ay * dy
    t_d = dx * dx + dy * dy
    t = t_n / t_d
    if t < 0.0 or t > 1.0:
        return np.array([])

    return np.array((x1 + t * dx, y1 + t * dy))


def calc_nearest_dist_from_path(ego_polygon, point):
    ego_traj = ego_polygon.mean(axis=1)  # n x 2
    if len(ego_traj) < 1:
        return -1.0
    min_dist = math.hypot(ego_traj[0][0] - point[0], ego_traj[0][1] - point[1])
    for i in range(1, len(ego_traj) - 1):
        min_dist = min(min_dist, math.hypot(ego_traj[i][0] - point[0], ego_traj[i][1] - point[1]))
    return min_dist


def filter_roadsign_after_stop_pos(ego_polygon, stopline_pos, roadsign_pos):
    ego_traj = ego_polygon.mean(axis=1)
    ego_stop_vec = stopline_pos - ego_traj[0]
    roadsign_stop_vec = stopline_pos - roadsign_pos
    angle = get_vector_angle(ego_stop_vec, roadsign_stop_vec)
    return angle > math.pi / 2


def get_lane_direction(lane_direction):
    lane_direction_set = set()
    if lane_direction & 0x1:
        lane_direction_set.add(Turntype.UTURN)
    if (lane_direction >> 1) & 0x1:
        lane_direction_set.add(Turntype.RIGHT)
    if (lane_direction >> 2) & 0x1:
        lane_direction_set.add(Turntype.STRAIGHT)
    if (lane_direction >> 3) & 0x1:
        lane_direction_set.add(Turntype.LEFT)
    if (lane_direction >> 4) & 0x1:
        lane_direction_set.add(Turntype.UTURN)
    return lane_direction_set


def determine_path_turn_type(points, threshold_degree: float = 30, fuzzy_threshold_degree: float = 20):
    total_angle = 0.0
    threshold = math.radians(threshold_degree)
    fuzzy_threshold = math.radians(fuzzy_threshold_degree)

    for i in range(1, len(points) - 1):
        # 前一个向量 (i-1 到 i)
        x_prev = points[i][0] - points[i - 1][0]
        y_prev = points[i][1] - points[i - 1][1]

        # 后一个向量 (i 到 i+1)
        x_next = points[i + 1][0] - points[i][0]
        y_next = points[i + 1][1] - points[i][1]

        # 计算向量模长
        mod_prev = math.hypot(x_prev, y_prev)
        mod_next = math.hypot(x_next, y_next)

        if mod_prev == 0 or mod_next == 0:
            continue  # 忽略零向量

        # 计算点积和叉积
        dot = x_prev * x_next + y_prev * y_next
        cross = x_prev * y_next - y_prev * x_next

        # 计算夹角
        cos_theta = dot / (mod_prev * mod_next)
        cos_theta = max(-1.0, min(1.0, cos_theta))
        sin_theta = cross / (mod_prev * mod_next)
        sin_theta = max(-1.0, min(1.0, sin_theta))
        delta_theta = math.atan2(sin_theta, cos_theta)

        if abs(delta_theta) > math.pi / 2:
            continue

        total_angle += delta_theta

    # 判断转向类型
    if abs(total_angle) < fuzzy_threshold:
        return {Turntype.STRAIGHT}
    elif total_angle > threshold:
        return {Turntype.LEFT}
    elif total_angle > fuzzy_threshold:
        return {Turntype.LEFT, Turntype.STRAIGHT}
    elif total_angle < -threshold:
        return {Turntype.RIGHT}
    else:
        return {Turntype.RIGHT, Turntype.STRAIGHT}


def determine_path_turn_end_ts_type(points, path_turn_type, threshold_degree: float = 30, fuzzy_threshold_degree: float = 20):
    total_angle = 0.0
    threshold = math.radians(threshold_degree)
    fuzzy_threshold = math.radians(fuzzy_threshold_degree)

    for i in range(1, len(points) - 1):
        # 前一个向量 (i-1 到 i)
        x_prev = points[i][0] - points[i - 1][0]
        y_prev = points[i][1] - points[i - 1][1]

        # 后一个向量 (i 到 i+1)
        x_next = points[i + 1][0] - points[i][0]
        y_next = points[i + 1][1] - points[i][1]

        # 计算向量模长
        mod_prev = math.hypot(x_prev, y_prev)
        mod_next = math.hypot(x_next, y_next)

        if mod_prev == 0 or mod_next == 0:
            continue  # 忽略零向量

        # 计算点积和叉积
        dot = x_prev * x_next + y_prev * y_next
        cross = x_prev * y_next - y_prev * x_next

        # 计算夹角
        cos_theta = dot / (mod_prev * mod_next)
        cos_theta = max(-1.0, min(1.0, cos_theta))
        sin_theta = cross / (mod_prev * mod_next)
        sin_theta = max(-1.0, min(1.0, sin_theta))
        delta_theta = math.atan2(sin_theta, cos_theta)

        if abs(delta_theta) > math.pi / 2:
            continue

        total_angle += delta_theta

        # 根据转向得到
        if Turntype.LEFT in path_turn_type:
        #     if total_angle > threshold:
        #         return i
        # elif path_turn_type == {Turntype.LEFT, Turntype.STRAIGHT}:
            if total_angle > fuzzy_threshold:
                return i
        elif Turntype.RIGHT in path_turn_type:
            if  total_angle < -fuzzy_threshold:
                return i
        # elif path_turn_type == {Turntype.RIGHT, Turntype.STRAIGHT}:
            # if -threshold < total_angle < 0:
            #     return i
    return None

def match_road_sign_from_path(ego_polygon, stopline_pos, raw_env):
    stopline_dist_thres = 55.0
    road_sign_dist_thres = 1.5
    road_sign_list = []
    crosswalk_dist_thres = 12.0
    crosswalk_nearby = False

    for p, ptype in raw_env["road_sign"]:
        if ptype != 300:
            continue
        cx, cy = p.mean(axis=0)[:2]
        # filter the road sign after the stop pos
        road_sign_pos = np.array([cx, cy])
        dist_from_stop_pos = math.hypot(stopline_pos[0] - cx, stopline_pos[1] - cy)
        # print(f"road sign: {ptype}, dist from stop pos: {dist_from_stop_pos}")
        if dist_from_stop_pos < crosswalk_dist_thres:
            crosswalk_nearby = True

    if not crosswalk_nearby:
        return road_sign_list

    for p, ptype in raw_env["road_sign"]:
        if ptype >= 300 and ptype not in [905, 909]:
            continue
        # print(f"road sign: {ptype}")
        cx, cy = p.mean(axis=0)[:2]
        # filter the road sign after the stop pos
        road_sign_pos = np.array([cx, cy])
        if filter_roadsign_after_stop_pos(ego_polygon, stopline_pos, road_sign_pos):
            continue
        # calc dist from stop pos, if within threshold,
        dist_from_stop_pos = math.hypot(stopline_pos[0] - cx, stopline_pos[1] - cy)
        if dist_from_stop_pos < stopline_dist_thres:
            dist_from_road_sign = calc_nearest_dist_from_path(ego_polygon, road_sign_pos)
            # print(f"road sign: {ptype}, dist from stop pos: {dist_from_stop_pos}, dist from road sign: {dist_from_road_sign}")
            if dist_from_road_sign < road_sign_dist_thres:
                road_sign_list.append((ptype, dist_from_stop_pos))
    road_sign_list = sorted(road_sign_list, key=lambda x: x[1], reverse=True)
    return road_sign_list


def on_segment(p, seg_p1, seg_p2):
    return min(seg_p1[0], seg_p2[0]) <= p[0] <= max(seg_p1[0], seg_p2[0]) and min(seg_p1[1], seg_p2[1]) <= p[1] <= max(
        seg_p1[1], seg_p2[1]
    )


def calc_path_length_from_point(polygons, point):
    """Calc path length from point."""
    idx = 0
    path = polygons.mean(axis=1)
    for i in range(1, len(path)):
        if on_segment(point, path[i - 1], path[i]):
            idx = i
            break
    if idx != 0:
        new_path = np.concatenate((point.reshape(1, 2), path[idx:]), axis=0)
        return calc_path_length(new_path)
    else:
        base_pt = path[-1]
        base_polygon = polygons[-1]
        theta = get_vector_angle(base_polygon[1:3, :].mean(axis=0) - base_pt, point - base_pt)
        if abs(theta) < 1.57:  # 在stopline的左侧
            return -(((base_pt[0] - point[0]) ** 2 + (base_pt[1] - point[1]) ** 2) ** 0.5)
        else:  # 在stopline的右侧
            return ((base_pt[0] - point[0]) ** 2 + (base_pt[1] - point[1]) ** 2) ** 0.5


def calc_path_point_heading(path_points):
    """
    计算path点的朝向

    Args:
        path_points: path point n*2, [x, y]

    Returns:
        path point n*3, [x, y, heading]
    """
    yaw_list = []
    for min_index in range(len(path_points)):
        yaw_d = 0.0
        if min_index == 0:
            yaw_d = np.arctan2(
                path_points[min_index + 1][1] - path_points[min_index][1],
                path_points[min_index + 1][0] - path_points[min_index][0],
            )
        elif min_index == len(path_points) - 1:
            yaw_d = np.arctan2(
                path_points[min_index][1] - path_points[min_index - 1][1],
                path_points[min_index][0] - path_points[min_index - 1][0],
            )
        else:
            yaw_d = np.arctan2(
                path_points[min_index + 1][1] - path_points[min_index - 1][1],
                path_points[min_index + 1][0] - path_points[min_index - 1][0],
            )
        yaw_list.append(yaw_d)

    yaw_list = np.array(yaw_list).reshape(-1, 1)

    return np.concatenate((path_points, yaw_list), axis=1)


def find_nearest_point(pos, points, angle_diff=None, search_start=None, search_end=None, max_search_dist=50.0):
    """
    暴力遍历, 使用search range优化计算负载

    Args:
        pos: x, y, yaw
        points: n*3  x, y, heading
        search_start: start index in points
        search_end: end index in points

     Returns:
        min_index: 最近点的索引
        min_distance: 距离最近点的欧式距离
    """
    if search_start is not None and search_end is not None:
        segment = points[search_start : search_end + 1, :]
    elif search_start is not None:
        segment = points[search_start:, :]
    elif search_end is not None:
        segment = points[:search_end, :]
    else:
        segment = points

    min_index_seg = -1
    min_distance = 1e6
    for index_seg, point in enumerate(segment):
        l2_dist = np.linalg.norm(pos[:2] - point[:2])

        if l2_dist > max_search_dist:
            continue

        if (angle_diff is not None and l2_dist < min_distance and abs(pos[2] - point[2]) < angle_diff) or (
            angle_diff is None and l2_dist < min_distance
        ):
            min_distance = l2_dist
            min_index_seg = index_seg

    min_index = -1
    if min_index_seg > -1:
        min_index = min_index_seg + search_start if search_start is not None else min_index_seg

    return min_index, min_distance


def get_lat_distance(pos, point):
    """
    计算点pos到点point的投影距离， 左正右负

    Args:
        point: [x, y, heading]
        pos: [x, y, yaw]

    Returns:
        dist: 投影距离
    """
    dist = 0.0

    # projection
    dx = pos[0] - point[0]
    dy = pos[1] - point[1]

    dist = dy * np.cos(point[2]) - dx * np.sin(point[2])

    return dist


def get_lon_lat_distance(pos, point):
    dx = pos[0] - point[0]
    dy = pos[1] - point[1]
    # 沿 heading 切线方向投影
    lon_dist = dx * np.cos(point[2]) + dy * np.sin(point[2])
    lat_dist = dy * np.cos(point[2]) - dx * np.sin(point[2])
    return lon_dist, lat_dist

def polygon_rear_padding(polygon, padding_len):
    """
                ^
                │
            2———│———1
            │   │   │
    <——————————ego————————————
            │   │   │
            3———│———0
                │
    polygon: 4 * 2
    """
    direction = polygon[0, :] - polygon[1, :]
    obs_len = np.linalg.norm(direction)
    if obs_len < 1e-3:
        return polygon
    unit_direct = direction / obs_len
    polygon[0] = polygon[0] + unit_direct * padding_len
    polygon[3] = polygon[3] + unit_direct * padding_len
    return polygon

def signed_distance(point: Point, polyline: LineString) -> float:
    """
    计算点到折线的带符号距离
    :param point: 目标点 (shapely Point)
    :param polyline: 折线 (shapely LineString)
    :return: 带符号距离 (点在左侧为正，右侧为负)
    """
    # Step 1: 找到折线上距离point最近的点
    nearest_pt = nearest_points(polyline, point)[0]

    # Step 2: 计算欧氏距离
    distance_val = point.distance(nearest_pt)

    # 如果点在折线上，距离为0
    if distance_val < 1e-10:
        return 0.0

    # Step 3: 获取折线坐标点
    coords = list(polyline.coords)

    # Step 4: 确定最近点在折线上的位置
    if nearest_pt.equals(Point(coords[0])):  # 最近点是起点
        segment_start = coords[0]
        segment_end = coords[1]
    elif nearest_pt.equals(Point(coords[-1])):  # 最近点是终点
        segment_start = coords[-2]
        segment_end = coords[-1]
    else:  # 最近点在线段中间
        # 遍历所有线段找到包含最近点的线段
        for i in range(len(coords) - 1):
            seg_start = Point(coords[i])
            seg_end = Point(coords[i + 1])
            if seg_start.distance(nearest_pt) + seg_end.distance(nearest_pt) - seg_start.distance(seg_end) < 1e-8:
                segment_start, segment_end = coords[i], coords[i + 1]
                break

    # Step 5: 计算方向向量和位置向量
    vec_line = (segment_end[0] - segment_start[0], segment_end[1] - segment_start[1])
    vec_point = (point.x - segment_start[0], point.y - segment_start[1])

    # Step 6: 计算叉积确定左右
    cross_product = vec_line[0] * vec_point[1] - vec_line[1] * vec_point[0]

    # Step 7: 根据叉积符号返回带符号距离
    return distance_val if cross_product > 0 else -distance_val


def get_xyyaw_from_polygon(corners):
    """
    corners: n x 4 x 2
    return: n x 7
    """
    xy = corners.mean(axis=1)
    x = xy[:, 0]
    y = xy[:, 1]
    z = np.zeros_like(x)
    pxpy = corners[:, 1:3].mean(axis=1)
    px = pxpy[:, 0]
    py = pxpy[:, 1]
    yaw = np.arctan2(py - y, px - x)  # n
    l = np.linalg.norm(corners[:, 0] - corners[:, 1], axis=1)
    w = np.linalg.norm(corners[:, 1] - corners[:, 2], axis=1)
    h = np.zeros_like(l) + 2
    return np.stack([x, y, z, l, w, h, yaw], axis=1)


def is_segments_intersection(a_point1, a_point2, b_point1, b_point2, bias=0.1):
    a_line = LineString([a_point1, a_point2])
    b_line = LineString([b_point1, b_point2])
    return a_line.distance(b_line) < bias


def check_intersection_with_lines(pred_ego_polygon, lane_lines):
    """
    Args:
        pred_ego_polygon: n x 4 x 2  自车预测位置polygon
        lane_lines
    Returns:
        indecies: 与车道线有交互的自车polygon的索引, list
        attr: 交互的车道线属性, map {indecies: attr}
    """
    indecies = []
    attr = {}

    for i, polygon in enumerate(pred_ego_polygon):
        filter_lines = []
        ego_center_pt = polygon.mean(axis=0).reshape(1, 2)

        for p, a in lane_lines:
            mask = np.linalg.norm(p[:, :2] - ego_center_pt, axis=1) < 5.0
            filter_pt = p[mask, :]
            filter_lines.append([p[mask, :], a[mask, :]])

        for filter_pt, filter_attr in filter_lines:
            if filter_pt.shape[0] < 2:
                continue
            polyline = LineString(filter_pt[:, :2])
            ego_polygon = Polygon(polygon)
            if polyline.intersects(ego_polygon):
                indecies.append(i)
                attr.update({i: filter_attr[filter_attr.shape[0] // 2, :]})  # 取中点
                break

    return indecies, attr


def check_corss_laneline(laneline_penalties, check_seconds=2):
    check_ts = check_seconds // 0.2
    return np.any(laneline_penalties[-min(check_ts, len(laneline_penalties)) :] < 0)


def get_distance(geo1, geo2, target_range=200):
    return geo1.distance(geo2) if len(geo2.geoms) > 0 else target_range

def get_distance_with_index(geo1, geo2, target_range=200):
    """计算geo1与geo2中所有线段的距离，并返回最小距离及对应的索引"""
    if len(geo2.geoms) == 0:
        return target_range, -1

    min_distance = float('inf')
    min_index = -1

    for idx, line in enumerate(geo2.geoms):
        distance = geo1.distance(line)
        if distance < min_distance:
            min_distance = distance
            min_index = idx
    return min_distance if min_distance < target_range else target_range, min_index

def get_min_distance_line_details(geo1, geo2, target_range=200):
    """
    获取最小距离对应的线段详细信息
    """
    if len(geo2.geoms) == 0:
        return target_range, -1, None, None, None

    min_distance = float('inf')
    min_index = -1
    closest_point_on_min_line = None
    closest_point_on_geo1 = None
    min_line_coords = None

    for idx, line in enumerate(geo2.geoms):
        distance = geo1.distance(line)

        if distance < min_distance:
            min_distance = distance
            min_index = idx
            # 计算最近点
            closest_point_on_min_line = line.interpolate(line.project(geo1))
            closest_point_on_geo1 = geo1.interpolate(geo1.project(line))
            min_line_coords = list(line.coords)

    # 应用距离阈值
    if min_distance >= target_range:
        min_distance = target_range

    return min_distance, min_index, (closest_point_on_min_line.x, closest_point_on_min_line.y) if closest_point_on_min_line else None, (closest_point_on_geo1.x, closest_point_on_geo1.y) if closest_point_on_geo1 else None, min_line_coords

def get_all_distances_with_indices(geo1, geo2, target_range=200):
    """计算geo1与geo2中所有线段的距离，返回所有距离和对应的索引"""
    if len(geo2.geoms) == 0:
        return [], []

    distances = []
    indices = []

    for idx, line in enumerate(geo2.geoms):
        distance = geo1.distance(line)
        distances.append(distance if distance < target_range else target_range)
        indices.append(idx)

    return distances, indices

def check_rear_collision(ego_box, ego_yaw, dynamic_boxes, dynamic_yaws, dynamic_cids):
    """
    判断哪些动态物体追尾了 ego 车。
    :param ego_box: shape (4, 2)  -> ego 车的四边形坐标, 顺序为: [(-y, -x), (-y, x), (y, x), (y, -x)]
    :param ego_yaw: shape (1,)       -> ego 车的朝向（弧度）
    :param dynamic_boxes: shape (n, 4, 2)  -> n 个动态物体的四边形坐标
    :param dynamic_yaws: shape (n,)       -> n 个动态物体的朝向（弧度）
    :return: 形状为 (n,) 的布尔张量，表示是否发生追尾
    """
    # 只保留角度差值在 ±30°（±pi/6）范围内的动态物体
    angle_diff = dynamic_yaws - ego_yaw
    angle_diff = (angle_diff + np.pi) % (2 * np.pi) - np.pi
    angle_condition = (np.abs(angle_diff) <= np.pi / 6) | (
        np.array([get_map_cls_to_3cls(cid) for cid in dynamic_cids]) == "pedestrian"
    )

    # 计算 ego 车后半区域
    rear_box = ego_box.copy()
    rear_box[1] = (rear_box[1] + rear_box[0]) / 2
    rear_box[2] = (rear_box[2] + rear_box[3]) / 2
    rear_poly = Polygon(rear_box)

    # 计算 ego 车前半区域
    front_box = ego_box.copy()
    front_box[0] = (front_box[1] + front_box[0]) / 2
    front_box[3] = (front_box[2] + front_box[3]) / 2
    front_poly = Polygon(front_box)

    # 计算相交情况和相交位置
    rear_collision_mask = np.zeros(dynamic_boxes.shape[0], dtype=np.bool_)
    for i, dyn_box in enumerate(dynamic_boxes):
        if angle_condition[i]:
            dyn_poly = Polygon(dyn_box)
            if rear_poly.intersects(dyn_poly) and not front_poly.intersects(dyn_poly):
                rear_collision_mask[i] = True

    return rear_collision_mask


def get_map_cls_to_3cls(od_cls_id):
    if od_cls_id < 300:
        return "vehicle"
    elif od_cls_id < 500:
        return "bicycle"
    else:
        return "pedestrian"


def compute_center_distance(pred_polygons_pose0, gt_polygons):
    # pred_polygons_pose0, gt_polygons: shape [4, 2]
    pred_center = pred_polygons_pose0.mean(axis=0)  # shape [2]
    gt_center = gt_polygons.mean(axis=0)  # shape [2]
    dist = np.linalg.norm(pred_center - gt_center, axis=-1)  # scalar
    return dist


def interpolate_points(points, step=0.1):
    if len(points) == 0:
        return points

    result = [list(points[0])]  # 初始时包含第一个点，转换为列表形式

    for i in range(len(points) - 1):
        current = points[i]
        next_point = points[i + 1]
        dx = next_point[0] - current[0]
        dy = next_point[1] - current[1]
        distance = math.hypot(dx, dy)

        if distance == 0:
            continue  # 跳过重合的点

        num_segments = math.ceil(distance / step)
        dx_per_segment = dx / num_segments
        dy_per_segment = dy / num_segments

        # 生成插值点，包括next_point，但排除current点
        for seg in range(1, num_segments + 1):
            x = current[0] + seg * dx_per_segment
            y = current[1] + seg * dy_per_segment
            result.append([x, y])

    return np.array(result)


def find_local_minima(a):
    """
    找到 1D ndarray 中的局部极小值。对于平坦极小区间，返回该区间最后一个位置的索引。

    参数
    ----
    a : ndarray
        输入的一维数组

    返回
    ----
    minima_indices : list of int
        局部极小值的索引
    minima_values : list
        对应的极小值
    """
    a = np.asarray(a)
    n = a.size
    if n == 0:
        return [], []

    # 计算相邻元素差异，定位相等值区间的边界
    diffs = np.diff(a)
    run_breaks = np.where(diffs != 0)[0]
    run_starts = np.concatenate(([0], run_breaks + 1))
    run_ends = np.concatenate((run_breaks, [n - 1]))  # 区间结束（包含）

    minima_indices = []

    for start, end in zip(run_starts, run_ends):
        val = a[start]
        # 边界处用 +inf 填充，保证边缘元素也可成为极小值
        left = a[start - 1] if start > 0 else np.inf
        right = a[end + 1] if end < n - 1 else np.inf

        # 严格小于两侧邻居
        if val < left and val < right:
            minima_indices.append(end)

    minima_values = a[minima_indices]
    return minima_indices, minima_values


def cut_sub_path(sub_path, center, max_distance=150.0):
    """
    sub_path: n x 2 ndarray
    """
    distance = np.linalg.norm(sub_path - center, axis=1)
    minima_indices, minima_values = find_local_minima(distance)
    center_index = minima_indices[0]
    sub_path = sub_path[center_index:]
    cum_distance = np.linalg.norm(sub_path[1:] - sub_path[:-1], axis=1).cumsum()
    index = np.where(cum_distance > max_distance)[0]
    if len(index) > 0:
        return sub_path[: index[0]]
    else:
        return sub_path


def split_points_to_segments(points):
    if len(points) < 2:
        return []
    return [(points[i], points[i + 1]) for i in range(len(points) - 1)]

def cross_stopline_pos(ego_polygon, stop_lines):
    """
    Args:
        ego_traj: n x 4 x 2
        stop_lines: n x 2
    Returns:
        pos: (x, y)  base on ego cooridinate
    """
    ego_traj = ego_polygon.mean(axis=1)  # n x 2
    indeices, _ = get_lines_distance(stop_lines, ego_traj[0])
    # check intersection
    find_flag = False
    for index in indeices:
        nearest_stop_line = stop_lines[index]
        ego_traj_segments = split_points_to_segments(ego_traj)
        for i, segment in enumerate(ego_traj_segments):
            if segment_intersect(segment[0], segment[1], nearest_stop_line[0], nearest_stop_line[1]):
                find_flag = True
                break
        if find_flag:
            return True
    return False

def infer_maneuver_from_lane_infos(raw_env):
    """
    从导航 lane_infos 推断当前路口的目标机动。
    0、1、2、3、4： 掉头、左转、直行、右转、无灯
    """
    lane_infos = raw_env.get("navi_infos", {}).get("lane_infos", [])
    if len(lane_infos) > 0:
        dirs = [info[1] for info in lane_infos if info[1]]
        if dirs:
            direct_light = LANE_DIRECTION_TO_TLD_ID_MAPPING[dirs[0]]
            return direct_light
    return np.nan

def in_intersection(ego_polygon, raw_env):
    """
    判断自车是否跨过停止线
    """
    egopath_stoplines_points = []
    wm_stoplines = raw_env.get("egopath_stoplines", [])
    for wm_stopline_junc in wm_stoplines:
        if len(wm_stopline_junc) == 0:
            continue
        p = wm_stopline_junc[0]
        egopath_stoplines_points.append(p)

    if len(egopath_stoplines_points) > 0:
        cross_flag = cross_stopline_pos(ego_polygon, egopath_stoplines_points)
    else:
        cross_flag = cross_stopline_pos(ego_polygon, raw_env["stop_line"])

    # 仅当越过停止线算进入路口
    return bool(cross_flag)

def judge_intersection_and_maneuver(ego_polygon, raw_env, ts):
    # 传入轨迹片段，返回是否跨过有灯路口停止线与对应路口行为
    if not in_intersection(ego_polygon, raw_env[ts]):
        return np.nan

    return infer_maneuver_from_lane_infos(raw_env[ts])

def trim_nonzero_runs(arr: np.ndarray, min_len: int = 5, edge_zero: int = 2) -> np.ndarray:
    """
    将数组中所有连续非零段按规则处理：
      - 段长 < min_len  -> 整段置 0
      - 段长 >= min_len -> 段首/段尾各 edge_zero 个元素置 0
    """
    x = np.asarray(arr, dtype=float).copy()
    if not np.any(x != 0):
        return x

    nz = (x != 0).astype(int)
    d = np.diff(np.r_[0, nz, 0])
    starts = np.where(d == 1)[0]
    ends   = np.where(d == -1)[0] - 1
    lengths = ends - starts + 1

    for s, e, L in zip(starts, ends, lengths):
        if L < min_len:
            x[s:e+1] = 0
        else:
            if edge_zero > 0:
                x[s:s+edge_zero] = 0
                x[e-edge_zero+1:e+1] = 0
    return x

def calc_emperical_following_distance(speed):
    EGO_V_LIST = [0.0, 5.0, 10.0, 15.0, 20.0, 25.0, 30.0, 40.0, 60.0, 80.0, 100.0, 120.0, 140.0, 160.0, 200.0]
    FOLLOWING_DIST_LIST = [3.0, 6.0, 7.0, 8.5, 11.0, 13.0, 15.0, 19.0, 27.0, 35.0, 44.0, 53.0, 62.0, 72.0, 89.0]

    return np.interp(speed, EGO_V_LIST, FOLLOWING_DIST_LIST)


def check_obstacles_nearby(ego_pos, ego_speed, obs_pos):
    ego_info = get_xyyaw_from_polygon(ego_pos[None, :, :])[0]
    ego_heading = ego_info[6]

    ego_center = np.mean(ego_pos, axis=0)  # shape (2,)

    n_obstacles = obs_pos.shape[0]
    obs_centers = np.mean(obs_pos, axis=1)  # shape (n,2)

    front_distance = calc_emperical_following_distance(ego_speed)

    # 1. 检查2米范围内的障碍物
    for i in range(n_obstacles):
        distance = np.linalg.norm(ego_center - obs_centers[i])

        if distance < 2.0:
            return True

    # 2. 检查正前方60度扇形区域内的障碍物
    for i in range(n_obstacles):
        relative_vector = obs_centers[i] - ego_center

        distance = np.linalg.norm(relative_vector)

        if distance > front_distance:
            continue

        relative_angle = math.atan2(relative_vector[1], relative_vector[0])

        angle_diff = relative_angle - ego_heading
        angle_diff = (angle_diff + math.pi) % (2 * math.pi) - math.pi

        if abs(angle_diff) <= math.radians(30):
            return True

    return False


def target_progress_scenario_include_condition(ego_polygon, raw_env, ts):
    return False

def target_progress_scenario_exclude_condition(ego_polygon, raw_env, pred_ts, ts, speeds, spd_limit_list, gt_max_speed):
    # set speed related exclude conditions
    speed_limit_mode = statistics.mode(spd_limit_list)
    if speed_limit_mode < 45:
        return True
    if gt_max_speed < 0.9 * speed_limit_mode:
        return True
    if speeds[pred_ts] <= 20:
        return True

    # junction scene exclude conditions
    is_junction_scenario = False
    is_main_to_aux_scenario = False
    manner_scene_list = raw_env[ts].get("manner_scene_info", None)
    if manner_scene_list is not None:
        manner_scene_list.sort(key=lambda x: x["distance_to_entry"])
        for scene in manner_scene_list:
            distance_to_entry = scene["distance_to_entry"]
            distance_to_exit = scene["distance_to_exit"]
            type = scene["scene_type"]

            if type == 2 and distance_to_entry < 150.0 and distance_to_exit > -50.0:
                is_junction_scenario = True
                break

            if type == 5 and distance_to_entry < 150.0 and distance_to_exit > -50.0:
                is_main_to_aux_scenario = True
                break

    if is_junction_scenario or is_main_to_aux_scenario:
        return True

    # od exclude conditions
    dobjs_polygon = raw_env[0]["dobjs_polygon"][ts]
    sobjs_polygon = raw_env[ts]["sobjs_polygon"]
    all_polygon = np.concatenate((dobjs_polygon, sobjs_polygon), axis=0)
    has_front_obs = check_obstacles_nearby(
        ego_polygon[pred_ts],
        speeds[pred_ts] / 3.6,
        all_polygon,
    )
    if has_front_obs:
        return True;

    return False

def is_slow_scene(scenario_id:ScenarioEnum):
    return scenario_id in (ScenarioEnum.kFollowSlow, ScenarioEnum.kFollowSlowByHuman)
