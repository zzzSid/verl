from typing import Dict, Tuple, List, Any, Optional
from collections import defaultdict

import numpy as np


class DeadCarBypassDetector:
    """
    死车绕行识别器（Stopped Vehicle Overtake Detector）。

    目标：用 ego 轨迹 + agent 轨迹，识别“绕行死车”的 episode：
        ego 在死车后方排队 / 等待 -> 横向绕过去 -> 超到死车前方。

    关键约束：
        1. 只在 ego 直行段上做识别：
           - 通过 yaw_rate 判断自车是否直行；
           - 自车非直行（例如左/右转、掉头）时不做“前方死车绕行”的判定。
        2. 死车定义：
           - 出现时间至少 min_track_duration 秒；
           - 从首次出现到整个轨迹结束，其空间位移最大值不超过
             stopped_displacement_thresh（米）；
           - 速度中位数不高于 stopped_speed_thresh；
           => 只把“出现后基本不挪窝的车/VRU”视为死车候选。

    输入数据约定：
        - ego_traj[T,3] : ego 的 GT 轨迹 (x, y, yaw)
        - ego_length, ego_width : ego 尺寸（当前未直接用，可用于后续调阈值）
        - agent_dict : Dict[int, (ids, states)]
            * key: t_idx (0..T-1，对齐 ego 时间步)
            * value:
                ids:    np.ndarray[N]            -> agent_id 列表（车辆、VRU 都算 agent）
                states: np.ndarray[N,5]          -> (x, y, yaw, length, width)
        - timestamps[T] : 每个 t_idx 对应的时间戳（秒）

    输出：
        - overtake_flags[T] : bool
              每个时刻是否处于“死车绕行”过程之中
        - target_agent_ids[T] : int
              若处于死车绕行，则为被绕行的死车 agent_id；否则为 -1
        - episodes : List[dict]
              每个 episode 对应一次死车绕行：
              {
                  "agent_id": int,
                  "start_idx": int,          # 全局时间索引，包含 start_idx
                  "end_idx": int,            # 全局时间索引，包含 end_idx
                  "start_time": float,       # 对应 timestamps[start_idx]
                  "end_time": float,         # 对应 timestamps[end_idx]
                  "min_longitudinal_gap": float,   # 绕行过程中的最小纵向距离 (沿 ego heading)
                  "min_lateral_offset": float,     # 绕行过程中的最小横向偏移 (abs)
                  "max_lateral_offset": float,     # 绕行过程中的最大横向偏移 (abs)
              }
    """

    def __init__(
        self,
        *,
        # 死车判断相关参数
        stopped_displacement_thresh: float = 5.0,
        #  ↑ 从首次出现到整个轨迹结束，空间位移不超过该距离（米），视为“几乎没动”
        stopped_speed_thresh: float = 2.0,
        #  ↑ 速度的辅助阈值，用于排除明显在路上跑的对象
        min_track_duration: float = 2.0,      # agent 轨迹至少存在这么久（秒）才考虑为死车候选

        # 相对几何模式参数（绕行模式识别）
        approach_min_gap: float = 5.0,        # 接近死车时，纵向距离下限 (m)
        approach_max_gap: float = 30.0,       # 接近死车时，纵向距离上限 (m)
        lane_center_thresh: float = 1.0,      # 认为“在死车后方同车道中间”的横向偏移阈值 (m)
        lateral_overtake_offset: float = 1.5, # 认为“已经绕到旁边”的横向偏移阈值 (m)
        pass_ahead_gap: float = 5.0,          # 认为“已经明显超到前方”的领先距离 (m)

        # 时间约束（可选）
        max_overtake_duration: Optional[float] = 40.0,  # 单次绕行最长持续时间 (秒)，None 表示不限制

        # 直行判断参数
        yaw_rate_straight_thresh_deg: float = 3.0,  # |yaw_rate| 小于该阈值时认为直行（度/秒）
    ) -> None:
        # 死车定义参数
        self.stopped_displacement_thresh = stopped_displacement_thresh
        self.stopped_speed_thresh = stopped_speed_thresh
        self.min_track_duration = min_track_duration

        # 几何模式参数
        self.approach_min_gap = approach_min_gap
        self.approach_max_gap = approach_max_gap
        self.lane_center_thresh = lane_center_thresh
        self.lateral_overtake_offset = lateral_overtake_offset
        self.pass_ahead_gap = pass_ahead_gap

        # 时间约束
        self.max_overtake_duration = max_overtake_duration

        # 直行判断：yaw_rate 阈值（弧度/秒）
        self.yaw_rate_straight_thresh = np.deg2rad(yaw_rate_straight_thresh_deg)

    # ===================== 对外主接口 =====================

    def detect(
        self,
        ego_traj: np.ndarray,
        agent_dict: Dict[int, Tuple[np.ndarray, np.ndarray]],
        timestamps: np.ndarray,
    ) -> Tuple[np.ndarray, np.ndarray, List[Dict[str, Any]]]:
        """
        识别整条轨迹中的“死车绕行”时刻和 episode。
        """
        T = ego_traj.shape[0]
        assert ego_traj.shape[1] == 3
        assert timestamps.shape[0] == T

        ego_xy = ego_traj[:, :2]
        ego_yaw = ego_traj[:, 2]

        ego_speeds = self._compute_speeds_xy(ego_xy, timestamps)
        ego_yaw_rate = self._compute_yaw_rate(ego_yaw, timestamps)
        ego_is_straight = np.abs(ego_yaw_rate) < self.yaw_rate_straight_thresh

        # 1) 构建每个 agent 的轨迹和速度
        agent_tracks = self._build_agent_tracks(agent_dict, timestamps)

        # 2) (agent_id, t_idx) -> pos / speed 索引，方便后续 episode 汇总
        agent_pos_idx: Dict[Tuple[int, int], Tuple[float, float]] = {}
        agent_speed_idx: Dict[Tuple[int, int], float] = {}

        for aid, info in agent_tracks.items():
            t_indices = info["t_idx"]
            xy = info["xy"]
            spd = info["speed"]
            for k in range(t_indices.shape[0]):
                key = (aid, int(t_indices[k]))
                agent_pos_idx[key] = (float(xy[k, 0]), float(xy[k, 1]))
                agent_speed_idx[key] = float(spd[k])

        # 3) 针对每个“死车候选”单独跑绕行模式识别（只在直行段上）
        episodes: List[Dict[str, Any]] = []

        for aid, info in agent_tracks.items():
            t_indices = info["t_idx"]
            if t_indices.size < 2:
                continue

            ts_agent = timestamps[t_indices]
            duration = float(ts_agent[-1] - ts_agent[0])
            if duration < self.min_track_duration:
                # 出现时间太短，不认为是“死车”
                continue

            xy_agent = info["xy"]

            # ==== 死车判定：出现后几乎不挪窝 ====
            origin = xy_agent[0]
            disp = np.linalg.norm(xy_agent - origin, axis=1)
            max_disp = float(np.max(disp))

            if max_disp > self.stopped_displacement_thresh:
                # 移动距离太大，属于正常行驶/行走，不视为死车
                continue

            # 速度作为辅助过滤
            v_agent = info["speed"]
            median_speed = float(np.nanmedian(v_agent))
            if median_speed > self.stopped_speed_thresh:
                continue

            # 计算该死车在每个 t_indices 时刻相对于 ego 的 s(t)/d(t)
            s_list: List[float] = []
            d_list: List[float] = []
            v_ego_list: List[float] = []

            for idx, t_idx in enumerate(t_indices):
                ego_x, ego_y = ego_xy[t_idx]
                yaw = ego_yaw[t_idx]
                heading = np.array([np.cos(yaw), np.sin(yaw)], dtype=float)

                ax, ay = xy_agent[idx]
                rel = np.array([ax - ego_x, ay - ego_y], dtype=float)

                s = float(np.dot(rel, heading))                      # 纵向（沿 ego heading）
                d = float(heading[0] * rel[1] - heading[1] * rel[0]) # 横向（2D 叉积）

                s_list.append(s)
                d_list.append(d)
                v_ego_list.append(ego_speeds[t_idx])

            s_arr = np.array(s_list, dtype=float)
            d_arr = np.array(d_list, dtype=float)
            v_ego_arr = np.array(v_ego_list, dtype=float)

            episode_local = self._detect_overtake_pattern_for_stopped_agent(
                agent_id=aid,
                t_indices=t_indices,
                timestamps_agent=ts_agent,
                s_arr=s_arr,
                d_arr=d_arr,
                v_ego_arr=v_ego_arr,
                ego_is_straight=ego_is_straight,
            )

            if episode_local is not None:
                episodes.append(episode_local)

        # 4) 将 episode 映射回全局时间轴，生成 per-timestep 标记
        overtake_flags = np.zeros(T, dtype=bool)
        target_agent_ids = -np.ones(T, dtype=int)

        for ep in episodes:
            aid = ep["agent_id"]
            start_idx = ep["start_idx"]
            end_idx = ep["end_idx"]
            for t_idx in range(start_idx, end_idx + 1):
                overtake_flags[t_idx] = True
                target_agent_ids[t_idx] = aid

        return overtake_flags, target_agent_ids, episodes

    # ===================== 单个“死车候选”的绕行模式识别 =====================

    def _detect_overtake_pattern_for_stopped_agent(
        self,
        agent_id: int,
        t_indices: np.ndarray,
        timestamps_agent: np.ndarray,
        s_arr: np.ndarray,
        d_arr: np.ndarray,
        v_ego_arr: np.ndarray,
        ego_is_straight: np.ndarray,
    ) -> Optional[Dict[str, Any]]:
        """
        在单个“死车候选” agent 的时间序列上识别一次死车绕行 episode。

        几何模式（允许中途 ego 停车等待） + 直行约束：
            1. 在某一段时间 [k1, k2] 内（且这些时刻 ego_is_straight 为 True）：
               - 死车在 ego 前方，纵向距离 s 处于 [approach_min_gap, approach_max_gap] 左右；
               - ego 与死车横向偏移 |d| < lane_center_thresh；
               => ego 一直排在死车后面（包含接近 + 刹停 + 等待）。

            2. 在 k2 之后的某个直行时刻 k_over：
               - |d[k_over]| > lateral_overtake_offset；
               => ego 明显绕到一侧。

            3. 在 k_over 之后的某个直行时刻 k_pass：
               - s[k_pass] < -pass_ahead_gap；
               => ego 已经超到死车前方，并领先一定距离。

        只有在这些关键阶段对应的全局时刻 t_indices[*] 都处于直行段
        (ego_is_straight == True) 时，才认为发生了“死车绕行”。
        """
        M = t_indices.shape[0]
        if M < 3:
            return None

        # ---------- 1. 找“在死车后方直行排队/等待”的区间 [k1, k2] ----------
        k1 = None
        for k in range(M):
            t_idx = int(t_indices[k])
            if not ego_is_straight[t_idx]:
                continue  # 非直行段不考虑

            s = s_arr[k]
            d = d_arr[k]
            if (
                self.approach_min_gap <= s <= self.approach_max_gap
                and abs(d) < self.lane_center_thresh
            ):
                k1 = k
                break

        if k1 is None:
            # 从未在直行段里、以合适距离排在死车后方
            return None

        # 从 k1 往后扩展等待区间，直到离得太远或横向偏移太大、或者进入非直行段
        k2 = k1
        for k in range(k1 + 1, M):
            t_idx = int(t_indices[k])
            if not ego_is_straight[t_idx]:
                break  # 离开直行段，结束等待区

            s = s_arr[k]
            d = d_arr[k]
            if (
                self.approach_min_gap <= s <= (self.approach_max_gap + 5.0)
                and abs(d) < (self.lane_center_thresh + 0.5)
            ):
                k2 = k
            else:
                break

        if k2 <= k1:
            # 等待区间太短，可以认为不是稳定地排在后面
            return None

        # 时间约束：接近 + 等待到这儿的时间不能离谱
        if self.max_overtake_duration is not None:
            if (timestamps_agent[k2] - timestamps_agent[k1]) > self.max_overtake_duration:
                return None

        # ---------- 2. 在直行段的等待区之后，寻找横向绕行的开始点 k_over ----------
        k_over = None
        for k in range(k2 + 1, M):
            t_idx = int(t_indices[k])
            if not ego_is_straight[t_idx]:
                continue  # 非直行不认为是有效绕行

            d = d_arr[k]
            if abs(d) > self.lateral_overtake_offset:
                k_over = k
                break

        if k_over is None:
            # 一直排在后面，但在直行段从未真正绕到侧向
            return None

        # ---------- 3. 在直行段的横向绕行之后，寻找完成超车的时刻 k_pass ----------
        k_pass = None
        for k in range(k_over + 1, M):
            t_idx = int(t_indices[k])
            if not ego_is_straight[t_idx]:
                continue  # 非直行不认为完成了正常直行绕行

            s = s_arr[k]
            if s < -self.pass_ahead_gap:
                k_pass = k
                break

        if k_pass is None:
            # 绕到侧向了，但在直行段内从未明显超到前面
            return None

        # 时间约束：整个绕行过程不能离谱地长
        if self.max_overtake_duration is not None:
            duration = float(timestamps_agent[k_pass] - timestamps_agent[k1])
            if duration > self.max_overtake_duration:
                return None

        # 生成 episode（local index -> 全局 t_idx）
        start_idx = int(t_indices[k1])
        end_idx = int(t_indices[k_pass])

        s_seg = s_arr[k1 : k_pass + 1]
        d_seg = np.abs(d_arr[k1 : k_pass + 1])

        return {
            "agent_id": int(agent_id),
            "start_idx": start_idx,
            "end_idx": end_idx,
            "start_time": float(timestamps_agent[k1]),
            "end_time": float(timestamps_agent[k_pass]),
            "min_longitudinal_gap": float(np.min(s_seg)),
            "min_lateral_offset": float(np.min(d_seg)),
            "max_lateral_offset": float(np.max(d_seg)),
        }

    # ===================== 基础工具函数 =====================

    @staticmethod
    def _compute_speeds_xy(
        xy: np.ndarray,
        timestamps: np.ndarray,
    ) -> np.ndarray:
        """
        根据 (x,y) 轨迹 + 时间戳计算标量速度 (m/s)。
        简单相邻差分，首点复用第二个点的速度。
        """
        T = xy.shape[0]
        speeds = np.zeros(T, dtype=float)
        if T <= 1:
            return speeds

        dx = np.diff(xy[:, 0])
        dy = np.diff(xy[:, 1])
        dt = np.diff(timestamps)
        dt_safe = np.where(dt == 0.0, 1e-6, dt)

        v = np.sqrt(dx * dx + dy * dy) / dt_safe

        speeds[1:] = v
        speeds[0] = speeds[1]
        return speeds

    @staticmethod
    def _compute_yaw_rate(
        yaw: np.ndarray,
        timestamps: np.ndarray,
    ) -> np.ndarray:
        """
        根据 yaw 序列和时间戳计算 yaw_rate (rad/s)，并做 unwrap 处理。
        """
        T = yaw.shape[0]
        yaw_unwrap = np.unwrap(yaw)  # 避免 2π 跳变
        yaw_rate = np.zeros(T, dtype=float)
        if T <= 1:
            return yaw_rate

        dyaw = np.diff(yaw_unwrap)
        dt = np.diff(timestamps)
        dt_safe = np.where(dt == 0.0, 1e-6, dt)

        r = dyaw / dt_safe
        yaw_rate[1:] = r
        yaw_rate[0] = yaw_rate[1]
        return yaw_rate

    @staticmethod
    def _build_agent_tracks(
        agent_dict: Dict[int, Tuple[np.ndarray, np.ndarray]],
        timestamps: np.ndarray,
    ) -> Dict[int, Dict[str, Any]]:
        """
        从按时间索引组织的 agent_dict 构建每个 agent 的轨迹与速度。

        返回：
            tracks[agent_id] = {
                "t_idx": np.ndarray[M],      # 该 agent 出现的时间索引列表
                "xy":    np.ndarray[M,2],    # 对应的 (x,y)
                "speed": np.ndarray[M],      # 对应的速度标量 (m/s)
            }
        """
        grouped = defaultdict(list)  # agent_id -> list[(t_idx, x, y)]

        for t_idx, (ids, states) in agent_dict.items():
            xs = states[:, 0]
            ys = states[:, 1]
            for j, aid in enumerate(ids):
                grouped[int(aid)].append((t_idx, xs[j], ys[j]))

        tracks: Dict[int, Dict[str, Any]] = {}
        for aid, samples in grouped.items():
            samples.sort(key=lambda x: x[0])  # 按时间排序
            t_indices = np.array([s[0] for s in samples], dtype=int)
            xy = np.array([[s[1], s[2]] for s in samples], dtype=float)

            ts_agent = timestamps[t_indices]
            speed = DeadCarBypassDetector._compute_speeds_xy(xy, ts_agent)

            tracks[aid] = {
                "t_idx": t_indices,
                "xy": xy,
                "speed": speed,
            }

        return tracks

def check_clip(clip_idx):
    # info = pkl.load(open(f"./tmp2/{clip_idx}.pkl", "rb"))
    info = pkl.load(open(f"/home/charlie.cheng1/ws/melange-rl/tmp_deadcar/{clip_idx}.pkl", "rb"))

    detector = DeadCarBypassDetector()

    input_dct = info["input"]
    obj_dct = info["input"]['agent_dict']
    # if 'ego_length' not in input_dct:
    #     input_dct['ego_length'] = 4.5
    # if 'ego_width' not in input_dct:
    #     input_dct['ego_width'] = 2.0

    max_len = min(len(input_dct['ego_traj']), len(obj_dct))
    input_dct['ego_traj'] = input_dct['ego_traj'][:max_len]
    if len(obj_dct)>max_len:
        for i in range(max_len, len(obj_dct)):
            obj_dct.pop(i)

    overtake_flags, target_agent_ids, episodes = detector.detect(**input_dct)
    print(f"[{clip_idx}]is_deadcar_scene:{np.any(overtake_flags)}")
    for seg in enumerate(episodes):
        print(f"\t{seg}")
    return overtake_flags, target_agent_ids, episodes




# ===================== 使用示例 =====================
if __name__ == "__main__":
    # 假设你已有以下变量：
    # ego_traj: np.ndarray[T,3]
    # ego_length, ego_width: float
    # agent_dict: Dict[int, (ids, states)]
    # timestamps: np.ndarray[T]

    import pickle as pkl

    check_clip(0)

    # detector = DeadCarBypassDetector(
    #     stopped_speed_thresh=2.0,
    #     approach_min_gap=5.0,
    #     approach_max_gap=30.0,
    #     lane_center_thresh=1.0,
    #     lateral_overtake_offset=1.5,
    #     pass_ahead_gap=5.0,
    #     rel_speed_min=1.0,
    #     max_overtake_duration=20.0,
    # )
    #
    # overtake_flags, target_ids, episodes = detector.detect(
    #     ego_traj, ego_length, ego_width, agent_dict, timestamps
    # )
    #
    # 之后你可以用 overtake_flags 在时间轴上画出“死车绕行区间”，
    # 用 target_ids 做可视化高亮被绕行的死车，
    # episodes 则可以做统计或 Golden Suite 的标签。

    pass

