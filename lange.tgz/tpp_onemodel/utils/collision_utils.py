# -*- coding: utf-8 -*-
from typing import Optional

import torch
from torch.nn.utils.rnn import pad_sequence

from tpp_onemodel.utils import vehicle_param


DEFAULT_VEHICLE_PADDING_CFG = dict(
    front={"lambda_0": 0.2, "lambda_1": 0.4},
    back={"lambda_1": 0.1},
    left={"lambda_1": 0.01, "lambda_2": 0.05, "max_value": 0.3},
    right={"lambda_1": 0.01, "lambda_2": 0.05, "max_value": 0.3},
)

DEFAULT_VRU_PADDING_CFG = dict(
    front={"lambda_0": 0.1, "lambda_1": 1, "max_value": 1.5},
    back={"lambda_0": 0.1, "lambda_1": 0.6, "max_value": 0.6},
    left={"lambda_0": 0.1},
    right={"lambda_0": 0.1},
)


def _line_seg_intersects(line_set1, line_set2):
    """Check if two line segments intersect."""
    # line_set1: [N, Pt(2), xy],
    # line_set2: [M, Pt(2), xy]
    # return [N, M]
    line_set1 = line_set1.unsqueeze(1)
    line_set2 = line_set2.unsqueeze(0)
    x_a_1, y_a_1 = line_set1[:, :, 0, 0], line_set1[:, :, 0, 1]
    x_a_2, y_a_2 = line_set1[:, :, 1, 0], line_set1[:, :, 1, 1]

    x_b_1, y_b_1 = line_set2[:, :, 0, 0], line_set2[:, :, 0, 1]
    x_b_2, y_b_2 = line_set2[:, :, 1, 0], line_set2[:, :, 1, 1]

    orien_a_1 = (x_b_2 - x_b_1) * (y_a_1 - y_b_1) - (y_b_2 - y_b_1) * (x_a_1 - x_b_1)
    orien_a_2 = (x_b_2 - x_b_1) * (y_a_2 - y_b_1) - (y_b_2 - y_b_1) * (x_a_2 - x_b_1)

    orien_b_1 = (x_a_2 - x_a_1) * (y_b_1 - y_a_1) - (y_a_2 - y_a_1) * (x_b_1 - x_a_1)
    orien_b_2 = (x_a_2 - x_a_1) * (y_b_2 - y_a_1) - (y_a_2 - y_a_1) * (x_b_2 - x_a_1)

    colinear = (
        (1 - torch.sign(orien_a_1 * orien_a_1))
        * (1 - torch.sign(orien_a_2 * orien_a_2))
        * (1 - torch.sign(orien_b_1 * orien_b_1))
        * (1 - torch.sign(orien_b_2 * orien_b_2))
    )

    # colinear = (orien_a_1 == 0) & (orien_a_2 == 0) & (orien_b_1 == 0) & (orien_b_2 == 0)

    intersect = (
        (1 - torch.sign(orien_a_1 * orien_a_2))
        * (1 - torch.sign(orien_b_1 * orien_b_2))
        * (1 - colinear.type(torch.float))
    )
    # intersect = (orien_a_1 * orien_a_2 <= 0) & (orien_b_1 * orien_b_2 <= 0) & ~colinear

    return intersect


def _multi_polygon_intersects(poly_list_1, polygon_list, split):
    """Check if two polygons intersect."""
    # polygon1: [N * 4, xy],
    # polygon2: [M, xy]
    # split: k
    # reutrn [k]
    poly_from_pt = poly_list_1
    poly_to_pt = poly_list_1.reshape(-1, 4, 2).roll(1, dims=1).reshape(-1, 2)
    # poly_to_pt = poly_from_pt.roll(1, dims=0)

    poly_list_from_pt = polygon_list
    split = split[split.nonzero()].squeeze()  # TODO(congq): use bbox instead

    split_sum = split.cumsum(dim=0)
    if not split_sum.shape:
        split_sum = split_sum.unsqueeze(0)
    split_sum = torch.cat([split.new_zeros((1)), split_sum], dim=0)

    rolled_poly = []

    for i in range(1, len(split_sum)):
        rolled_poly.append(poly_list_from_pt[split_sum[i - 1] : split_sum[i]].roll(1, dims=0))

    rolled_poly = torch.cat(rolled_poly, dim=0)

    intersect = _line_seg_intersects(
        torch.stack([poly_from_pt, poly_to_pt], dim=1), torch.stack([poly_list_from_pt, rolled_poly], dim=1)
    )
    return intersect


def sod_collision(
    sod_padding_mask,
    ego_pred_traj_output,
    sod_corners,
    sod_corners_padding_mask,
    marginal_ego_best_traj,
    egos,
    time_step,
    min=False,
):
    """Sod collision."""
    # model_inputs, model_outputs, batch_size):
    # sod_padding_mask = model_inputs["sod_poly_boxes_padding_mask"]
    # ego_pred_traj_output = model_outputs["ego_pred_traj_output"][..., :-1]  # [B,1,K,T,2]
    # sod_corners = model_inputs["sod_poly_pts"]
    # sod_corners_padding_mask = model_inputs["sod_poly_pts_padding_mask"]
    if min:
        ego_pred_shape = ego_pred_traj_output.shape
        ego_pred_traj_output = ego_pred_traj_output.reshape(
            ego_pred_shape[0], -1, ego_pred_shape[-2], ego_pred_shape[-1]
        )
        batch, mode_num, _, _ = ego_pred_traj_output.shape
        ego_pred_traj_output = ego_pred_traj_output.reshape(batch, mode_num, -1)

    else:
        batch, mode_num, _, _ = marginal_ego_best_traj.shape
        ego_pred_traj_output = marginal_ego_best_traj.reshape(batch, mode_num, -1)
    batch_size, mode_num, _ = ego_pred_traj_output.shape

    ego_xys = ego_pred_traj_output.reshape(batch_size, mode_num, -1, 2)

    ego_xys = ego_xys[:, :, :time_step, :]  # [B, K, T, 2]
    delta = ego_xys[:, :, 1:, :] - ego_xys[:, :, :-1, :]
    ego_heading = torch.atan2(delta[..., 1], delta[..., 0])  # [B, K, T-1]
    ego_heading_cos = torch.cos(ego_heading)
    ego_heading_sin = torch.sin(ego_heading)

    ego_xys = ego_xys[:, :, :-1, :]  # [B, K, T-1, 2]

    ego_half_len = 2.5 * torch.ones_like(ego_heading)
    ego_half_width = 1.0 * torch.ones_like(ego_heading)

    front_offset = torch.stack((ego_half_len * ego_heading_cos, ego_half_len * ego_heading_sin), dim=-1)
    left_offset = torch.stack((ego_half_width * ego_heading_sin, -ego_half_width * ego_heading_cos), dim=-1)

    ego_top_left = ego_xys + front_offset + left_offset
    ego_bottom_left = ego_xys - front_offset + left_offset
    ego_bottom_right = ego_xys - front_offset - left_offset
    ego_top_right = ego_xys + front_offset - left_offset

    ego_corners = torch.stack(
        [
            ego_top_left,
            ego_bottom_left,
            ego_bottom_right,
            ego_top_right,
        ],
        dim=-2,
    )

    results = []
    for i in range(batch_size):
        ego_corner = ego_corners[i]
        sod_corner = sod_corners[i]

        sod_corner = sod_corner[sod_padding_mask[i] == 0]
        sod_corner_padding_mask = sod_corners_padding_mask[i][sod_padding_mask[i] == 0]
        valid_sod_corner = sod_corner[sod_corner_padding_mask == 0]
        valid_sod_split = torch.count_nonzero(~sod_corner_padding_mask.bool(), dim=1)
        if valid_sod_split.any():
            collision = _multi_polygon_intersects(
                ego_corner.reshape(-1, 2), valid_sod_corner.reshape(-1, 2), valid_sod_split
            )
            results.append(collision.reshape(mode_num, -1).sum(dim=1))
        else:
            results.append(torch.zeros(mode_num).to(valid_sod_split.device))  # no backpropagation

    # to [B, mod]
    if min:
        collision_mat = torch.stack(results).min(dim=-1)[0].unsqueeze(1)
    else:
        collision_mat = torch.stack(results).sum(dim=-1).unsqueeze(1)
    return torch.sign(collision_mat), torch.ones_like(collision_mat)  # TODO(congq): ignore conditional mask for now


def cal_ego_multi_points(
    ego_traj: torch.Tensor,
    ego_heading_pred: torch.Tensor,
    ego_bbox_info: torch.Tensor,
) -> torch.Tensor:
    """Cal ego multi points."""
    # ego_traj = ego_traj.squeeze(1)[:, 0].reshape(ego_traj.shape[0], -1, 2)
    batch_size, _, ego_mode, _ = ego_traj.shape
    ego_traj = ego_traj.reshape(batch_size, ego_mode, -1, 2)
    batch_size, ego_mode, future_step, dim = ego_traj.shape

    circle_step = ego_bbox_info.squeeze(1)[:, 0] - ego_bbox_info.squeeze(1)[:, 1]  # length - width
    ego_traj = torch.reshape(ego_traj, (batch_size, ego_mode, future_step, dim))
    ego_headings = ego_heading_pred.squeeze(1)[:, :, 1:, 0]

    circle_step = circle_step.reshape(batch_size, 1, 1).repeat(1, ego_mode, future_step - 1)
    # use 3 circles to represent ego bounding box
    ego_traj = ego_traj[:, :, 1:]
    rear_offset = vehicle_param.ET5_length / 2.0 - vehicle_param.ET5_rear_overhang

    points_offset = torch.concat(
        [
            (rear_offset / 2 * torch.cos(ego_headings)).unsqueeze(-1),
            (rear_offset / 2 * torch.sin(ego_headings)).unsqueeze(-1),
        ],
        dim=-1,
    )

    ego_half_length_points = torch.concat(
        [
            (circle_step / 2 * torch.cos(ego_headings)).unsqueeze(-1),
            (circle_step / 2 * torch.sin(ego_headings)).unsqueeze(-1),
        ],
        dim=-1,
    )
    first_ego_points = ego_traj + ego_half_length_points
    third_ego_points = ego_traj - ego_half_length_points
    # multi_ego_points = torch.concat([first_ego_points, ego_traj, third_ego_points], dim=2)
    multi_ego_points = torch.stack(
        [first_ego_points + points_offset, ego_traj + points_offset, third_ego_points + points_offset], dim=3
    )
    return multi_ego_points  # batch, ego_mode, future_step, ego_circle, xy


def cal_multi_obs_multi_points(trajs: torch.Tensor, bbox_infos: torch.Tensor, min_width_only: bool) -> torch.Tensor:
    """Cal multi obs multi points."""
    batch_size, agent_num, future_step, dim = trajs.shape
    if min_width_only:
        circle_step = torch.zeros_like(bbox_infos[:, :, 1:, 3])
    else:
        circle_step = bbox_infos[:, :, 1:, 3] - bbox_infos[:, :, 1:, 4]  # length - width
    trajs = torch.reshape(trajs, (batch_size, agent_num, future_step, 1, dim))
    obj_headings = bbox_infos[:, :, 1:, 6]
    obj_headings = torch.reshape(obj_headings, (batch_size, agent_num, future_step - 1, 1, 1))
    # use 5 circles to represent obs bounding box
    trajs = trajs[:, :, 1:]
    circle_step = torch.reshape(circle_step, (batch_size, agent_num, future_step - 1, 1, 1))
    obs_half_length_points = torch.concat(
        [circle_step / 2 * torch.cos(obj_headings), circle_step / 2 * torch.sin(obj_headings)], dim=-1
    )
    obs_quarter_length_points = torch.concat(
        [circle_step / 4 * torch.cos(obj_headings), circle_step / 4 * torch.sin(obj_headings)], dim=-1
    )
    first_obs_points = trajs + obs_half_length_points
    second_obs_points = trajs + obs_quarter_length_points
    fourth_obs_points = trajs - obs_half_length_points
    fifth_obs_points = trajs - obs_quarter_length_points

    multi_obs_points = torch.concat(
        [first_obs_points, second_obs_points, trajs, fourth_obs_points, fifth_obs_points], dim=3
    )
    # multi_obs_points = multi_obs_points.repeat(1, 1, 1, 3, 1)

    return multi_obs_points


def agent_collision_check(
    ego_motion_preds: torch.Tensor,
    ego_heading_preds: torch.Tensor,
    ego_motion_gt_masks: torch.Tensor,
    ego_bbox_info: torch.Tensor,
    agent_gts: torch.Tensor,
    agent_gt_masks: torch.Tensor,
    agent_bbox_infos: torch.Tensor,
    min_width_only: bool = False,
    collision_threshold: float = 0.5,
    ego_circle_num: int = 3,
    agent_circle_num: int = 5,
    ego_pred_vel: Optional[torch.Tensor] = None,
    low_speed_filter_thres: float = 0.0,
    rear_end_filter: bool = False,
):
    """Calculate whether ego has collision with any agent in the future."""
    ego_future_step = ego_heading_preds.shape[-2]
    agent_gts = agent_gts[..., :ego_future_step, :]
    agent_gt_masks = agent_gt_masks[..., :ego_future_step]
    agent_bbox_infos = agent_bbox_infos[..., :ego_future_step, :]
    batch_size, agent_num, future_step, dim = agent_gts.shape
    _, _, ego_mode, _ = ego_motion_preds.shape

    if min_width_only:
        # min of width and length
        obj_widths = agent_bbox_infos[:, :, 1:, 3].min(agent_bbox_infos[:, :, 1:, 4])
    else:
        obj_widths = agent_bbox_infos[:, :, 1:, 4]
    ego_widths = torch.full(
        (batch_size, agent_num, future_step - 1),
        vehicle_param.ET5_width_w_mirror,
        device=agent_bbox_infos.device,
        dtype=agent_bbox_infos.dtype,
    )  # [B, A, T-1]
    safe_distance = (obj_widths + ego_widths) / 2 + collision_threshold
    safe_distance = torch.reshape(safe_distance, (batch_size, agent_num, future_step - 1, 1))
    safe_distance = safe_distance.repeat(1, 1, 1, ego_circle_num * agent_circle_num)

    ego_motion_gt_masks = torch.reshape(ego_motion_gt_masks.squeeze(1)[:, 1:], (batch_size, 1, future_step - 1, 1))
    ego_motion_gt_masks = ego_motion_gt_masks.repeat(1, agent_num, 1, ego_circle_num)

    agent_gt_masks = torch.reshape(agent_gt_masks[:, :, 1:], (batch_size, agent_num, future_step - 1, 1))
    agent_gt_masks = agent_gt_masks.repeat(1, 1, 1, agent_circle_num)

    valid_mask = ego_motion_gt_masks.unsqueeze(-1) * agent_gt_masks.unsqueeze(-2)

    # batch, agent_num, future_step, agent_circle, xy
    multi_obs_points = cal_multi_obs_multi_points(agent_gts, agent_bbox_infos, min_width_only)
    # batch, ego_num, future_step, ego_circle, xy
    multi_ego_points = cal_ego_multi_points(ego_motion_preds, ego_heading_preds, ego_bbox_info)

    multi_obs_points_reshape = multi_obs_points.transpose(1, 2).reshape(
        batch_size, future_step - 1, agent_num * agent_circle_num, 2
    )
    multi_ego_points_reshape = multi_ego_points.transpose(1, 2).reshape(
        batch_size, future_step - 1, ego_mode * ego_circle_num, 2
    )
    # batch, future_step, ego_mode * ego_circle_num, agent_num * agent_circle_num
    multi_points_de = torch.cdist(multi_ego_points_reshape, multi_obs_points_reshape, p=2).pow(2)
    multi_points_de = multi_points_de.view(
        batch_size, future_step - 1, ego_mode, ego_circle_num, agent_num, agent_circle_num
    ).permute(0, 4, 2, 1, 3, 5)

    # safe_distance = safe_distance.unsqueeze(2).repeat(1, 1, ego_mode, 1, 1)
    safe_distance = safe_distance.pow(2)
    # valid_mask = valid_mask.unsqueeze(2).repeat(1, 1, ego_mode, 1, 1, 1)

    if rear_end_filter:
        valid_mask[:, :, :, ego_circle_num - 1, 0] = 0

    if ego_pred_vel is not None and low_speed_filter_thres > 0.0:
        valid_mask[:, :, :, 2, :] *= (torch.norm(ego_pred_vel, dim=-1) >= low_speed_filter_thres)[
            :, :, : future_step - 1
        ].unsqueeze(-1)

    points_collision_distance_check = torch.nn.functional.relu(
        (
            safe_distance.reshape(batch_size, agent_num, future_step - 1, ego_circle_num, agent_circle_num).unsqueeze(2)
            - multi_points_de
        )
        * valid_mask.unsqueeze(2)
    )

    points_collision_distance_check, _ = torch.max(
        points_collision_distance_check.reshape(batch_size, agent_num, ego_mode, future_step - 1, -1), dim=-1
    )  # [B, A, mode, T]

    agent_collision_distance_check, max_index_ = torch.max(points_collision_distance_check, dim=1)  # [B, M, T]
    return agent_collision_distance_check, max_index_


def get_ego_corners(
    ego_positions,
    ego_headings,
    ego_vels,
    ego_sizes,
    max_acc=4,
    collision_threshold=0,
    speed_aware_padding=True,
    x_steps=9,
    y_steps=5,
):
    """Get ego corners."""
    # 根据 heading 旋转速度方向，heading方向为正x轴
    headings_cos = torch.cos(ego_headings).squeeze(-1)
    ego_headings_sin = torch.sin(ego_headings).squeeze(-1)
    heading_rot_mat = torch.stack(
        [
            torch.stack([headings_cos, -ego_headings_sin], dim=-1),
            torch.stack([ego_headings_sin, headings_cos], dim=-1),
        ],
        dim=-2,
    )  # [batch, num_vehicles, 2, 2]
    if speed_aware_padding:
        # 旋转速度向量至 ego 坐标系
        rot_vels = torch.matmul(heading_rot_mat.transpose(-1, -2), ego_vels.unsqueeze(-1)).squeeze(-1)
        # dists = (rot_vels * rot_vels) / (2 * max_acc)  # [batch, num_vehicles, 2]
        dists = torch.clamp(rot_vels * 1, min=2.0)
        dists_x = dists[..., 0]
        dists_y = dists[..., 1]
        sizes_pad_front = torch.where(dists_x > collision_threshold, dists_x, collision_threshold)
        sizes_pad_back = torch.where(dists_x < 0, dists_x, 0)
        sizes_pad_left = torch.where(dists_y > collision_threshold, dists_y, collision_threshold)
        sizes_pad_right = torch.where(dists_y < -collision_threshold, dists_y, -collision_threshold)

        half_w = ego_sizes[..., 1] / 2
        back_l = -vehicle_param.ET5_rear_overhang + sizes_pad_back
        front_l = ego_sizes[..., 0] - vehicle_param.ET5_rear_overhang + sizes_pad_front
        left_w = half_w + sizes_pad_left
        right_w = -half_w + sizes_pad_right
    else:
        collision_threshold = torch.full_like(ego_sizes[..., 0], collision_threshold)
        half_w = ego_sizes[..., 1] / 2
        back_l = -vehicle_param.ET5_rear_overhang - collision_threshold
        front_l = ego_sizes[..., 0] - vehicle_param.ET5_rear_overhang + collision_threshold
        left_w = half_w + collision_threshold
        right_w = -half_w - collision_threshold

    # 生成5x9网格点（x为前后方向，y为左右方向）
    x_ratios = torch.linspace(0, 1, steps=x_steps, device=ego_positions.device)
    y_ratios = torch.linspace(0, 1, steps=y_steps, device=ego_positions.device)
    # 删除重复采样的顶点
    if y_ratios.shape[0] >= 3:
        y_ratios = y_ratios[1:-1]
    grid_x = back_l.unsqueeze(-1) + (front_l - back_l).unsqueeze(-1) * x_ratios  # [batch, num_vehicles, 5]
    grid_y = right_w.unsqueeze(-1) + (left_w - right_w).unsqueeze(-1) * y_ratios  # [batch, num_vehicles, 9]

    local_corners_w = torch.stack(
        [
            grid_x.repeat(1, 1, 1, 1, 2),
            torch.cat(
                [
                    # torch.full_like(grid_x, left_w.item()),
                    # torch.full_like(grid_x, right_w.item()),
                    left_w.unsqueeze(-1).repeat(1, 1, 1, 1, x_ratios.shape[0]),
                    right_w.unsqueeze(-1).repeat(1, 1, 1, 1, x_ratios.shape[0]),
                ],
                dim=-1,
            ),
        ],
        dim=-1,
    )
    local_corners_h = torch.stack(
        [
            torch.cat(
                [
                    # torch.full_like(grid_y, front_l.item()),
                    # torch.full_like(grid_y, back_l.item()),
                    front_l.unsqueeze(-1).repeat(1, 1, 1, 1, y_ratios.shape[0]),
                    back_l.unsqueeze(-1).repeat(1, 1, 1, 1, y_ratios.shape[0]),
                ],
                dim=-1,
            ),
            grid_y.repeat(1, 1, 1, 1, 2),
        ],
        dim=-1,
    )
    local_corners = torch.cat([local_corners_w, local_corners_h], dim=-2)  # [batch, num_vehicles, 26, 2]

    batch_size, agent_num, ego_num, future_step, _, dim = local_corners.shape
    local_corners = local_corners.reshape(
        batch_size, agent_num, ego_num, future_step, -1, dim
    )  # [batch, num_vehicles, 25, 2]

    # 旋转并平移到全局坐标系
    corners = torch.matmul(heading_rot_mat.unsqueeze(-3), local_corners.unsqueeze(-1)).squeeze(
        -1
    ) + ego_positions.unsqueeze(-2)

    return corners


def get_raw_ego_corners(ego_positions, ego_headings, ego_sizes):
    """Get raw ego corners."""
    headings_cos = torch.cos(ego_headings).squeeze(-1)
    headings_sin = torch.sin(ego_headings).squeeze(-1)
    heading_rot_mat = torch.stack(
        [
            torch.stack([headings_cos, -headings_sin], dim=-1),
            torch.stack([headings_sin, headings_cos], dim=-1),
        ],
        dim=-2,
    )  # [4, 1, 2, 2]
    # rot_vels_x = ego_vels[..., 0] * headings_cos + ego_vels[..., 1] * ego_headings_sin
    # ([4, 1, 2]) to torch.Size([4, 1, 72, 35,2])
    #         front_l
    # left_w  center   right_w
    #         back_l
    half_w = ego_sizes[..., 1] / 2
    back_l = torch.ones_like(half_w) * -vehicle_param.ET5_rear_overhang
    front_l = ego_sizes[..., 0] - vehicle_param.ET5_rear_overhang
    left_w = half_w
    right_w = -half_w

    # 计算bbox的4个角点坐标
    local_corners = torch.stack(
        [
            torch.stack([front_l, left_w], dim=-1),
            torch.stack([front_l, right_w], dim=-1),
            torch.stack([back_l, right_w], dim=-1),
            torch.stack([back_l, left_w], dim=-1),
        ],
        dim=-2,
    )  # torch.Size([4, 1, 72, 35, 4, 2])
    corners = torch.matmul(heading_rot_mat.unsqueeze(-3), local_corners.unsqueeze(-1)).squeeze(
        -1
    ) + ego_positions.unsqueeze(
        -2
    )  # [4, 1, 72, 35, 4, 2]
    return corners


def get_agent_corners(agent_points, agent_headings, agent_vels, agent_sizes, max_acc=4, collision_threshold=0.5):
    """计算 agent 的四个角点坐标."""
    headings_cos = torch.cos(agent_headings).squeeze(-1)
    headings_sin = torch.sin(agent_headings).squeeze(-1)
    heading_rot_mat = torch.stack(
        [
            torch.stack([headings_cos, -headings_sin], dim=-1),
            torch.stack([headings_sin, headings_cos], dim=-1),
        ],
        dim=-2,
    )
    # ego to local
    rot_vels = torch.matmul(heading_rot_mat.transpose(-1, -2), agent_vels.unsqueeze(-1)).squeeze(-1)  # [4, 64, 35, 2]
    # 计算安全刹车距离,假设最大刹车减速度为max_acc
    dists = (rot_vels * rot_vels) / (2 * max_acc)
    # 用安全刹车距离来膨胀车辆size, 最小安全刹车距离为collision_threshold
    dists_x = dists[..., 0]
    dists_y = dists[..., 1]
    sizes_pad_front = torch.where(dists_x > collision_threshold, dists_x, collision_threshold)
    sizes_pad_back = torch.where(dists_x < -collision_threshold, dists_x, -collision_threshold)
    sizes_pad_left = torch.where(dists_y > collision_threshold, dists_y, collision_threshold)
    sizes_pad_right = torch.where(dists_y < -collision_threshold, dists_y, -collision_threshold)
    # 获取长和宽并pading
    #         front_l
    # left_w  center   right_w
    #         back_l
    half_l = agent_sizes[..., 0] / 2
    half_w = agent_sizes[..., 1] / 2
    front_l = half_l + sizes_pad_front
    back_l = -half_l + sizes_pad_back
    left_w = half_w + sizes_pad_left
    right_w = -half_w + sizes_pad_right
    local_corners = torch.stack(
        [
            torch.stack([front_l, left_w], dim=-1),
            torch.stack([front_l, right_w], dim=-1),
            torch.stack([back_l, right_w], dim=-1),
            torch.stack([back_l, left_w], dim=-1),
        ],
        dim=-2,
    )  # torch.Size([4, 1, 72, 35, 4, 2])

    # rotation and shift corners
    # local to ego
    corners = torch.matmul(heading_rot_mat.unsqueeze(-3), local_corners.unsqueeze(-1)).squeeze(
        -1
    ) + agent_points.unsqueeze(
        -2
    )  # torch.Size([4, 64, 35, 4, 2])
    return corners


def calculate_agent_gaussian_kernel(
    agent_points,
    agent_headings,
    agent_vels,
    agent_sizes,
    max_acc=4,
    collision_threshold=0.5,
    speed_aware_padding=True,
    size_aware_padding=True,
    size_aware_base=1,
):
    """计算agent 的高斯hernel参数."""
    headings_cos = torch.cos(agent_headings).squeeze(-1)
    headings_sin = torch.sin(agent_headings).squeeze(-1)
    # ego to local
    # rot_vels = torch.matmul(heading_rot_mat.transpose(-1, -2), agent_vels.unsqueeze(-1)).squeeze(-1)  # [4, 64, 35, 2]
    agent_sizes = torch.where(agent_sizes > 0, agent_sizes, 0.5)  # for padding agent
    if size_aware_padding:
        collision_threshold_l = size_aware_base * collision_threshold / agent_sizes[..., 0]
        collision_threshold_w = size_aware_base * collision_threshold / agent_sizes[..., 1]
    else:
        collision_threshold_l = collision_threshold
        collision_threshold_w = collision_threshold
    if speed_aware_padding:
        rot_vels_x = agent_vels[..., 0] * headings_cos + agent_vels[..., 1] * headings_sin
        rot_vels_y = -agent_vels[..., 0] * headings_sin + agent_vels[..., 1] * headings_cos
        # rot_vels = torch.einsum('...ji,...j->...i', heading_rot_mat, agent_vels).to(torch.float32)  # [4, 64, 35, 2]
        # 计算安全刹车距离,假设最大刹车减速度为max_acc
        # dists = (rot_vels * rot_vels) / (2 * max_acc)
        # # 用安全刹车距离来膨胀车辆size, 最小安全刹车距离为collision_threshold
        # dists_x = dists[..., 0]
        # dists_y = dists[..., 1]
        dists_x = rot_vels_x * rot_vels_x / (2 * max_acc)
        dists_y = rot_vels_y * rot_vels_y / (2 * max_acc)

        sizes_pad_front = torch.where(dists_x > collision_threshold_l, dists_x, collision_threshold_l)
        sizes_pad_back = torch.where(dists_x < -collision_threshold_l, dists_x, -collision_threshold_l)
        sizes_pad_left = torch.where(dists_y > collision_threshold_w, dists_y, collision_threshold_w)
        sizes_pad_right = torch.where(dists_y < -collision_threshold_w, dists_y, -collision_threshold_w)
        # 计算padding后的中心点
        local_offset_x = (sizes_pad_front + sizes_pad_back) / 2
        local_offset_y = (sizes_pad_left + sizes_pad_right) / 2
        local_rot_offset_x = headings_cos * local_offset_x - headings_sin * local_offset_y
        local_rot_offset_y = headings_sin * local_offset_x + headings_cos * local_offset_y
        local_rot_offsets = torch.stack([local_rot_offset_x, local_rot_offset_y], dim=-1)
        gaussion_mus = agent_points + local_rot_offsets
        # 计算padding后的旋转协方差矩阵及其逆矩阵
        pad_l = agent_sizes[..., 0] + sizes_pad_front - sizes_pad_back
        pad_w = agent_sizes[..., 1] + sizes_pad_left - sizes_pad_right
    else:
        gaussion_mus = agent_points
        pad_l = agent_sizes[..., 0] + 2 * collision_threshold_l
        pad_w = agent_sizes[..., 1] + 2 * collision_threshold_w
    # NOTE: 由于开启了混合精度训练，用matmul,enisum都会导致精度问题. 会默认切换到bfloat16导致协方差矩阵矩阵奇异无法求逆
    #       所以手动计算旋转的协方差矩阵
    sigma_xx = (pad_l / 2) ** 2
    sigma_yy = (pad_w / 2) ** 2
    headings_cos_cos = headings_cos**2
    headings_sin_sin = headings_sin**2
    headings_sin_cos = headings_sin * headings_cos
    sigma_00 = sigma_xx * headings_cos_cos + sigma_yy * headings_sin_sin
    sigma_11 = sigma_xx * headings_sin_sin + sigma_yy * headings_cos_cos
    sigma_01 = (sigma_xx - sigma_yy) * headings_sin_cos
    rot_sigmas = torch.stack(
        [
            torch.stack([sigma_00, sigma_01], dim=-1),
            torch.stack([sigma_01, sigma_11], dim=-1),
        ],
        dim=-2,
    )  # [4, 64, 35, 4, 2]
    inv_sigmas = torch.linalg.inv(rot_sigmas)

    return gaussion_mus, rot_sigmas, inv_sigmas


def get_raw_agent_corners(agent_points, agent_headings, agent_sizes):
    """Get agent corners in ego frame."""
    headings_cos = torch.cos(agent_headings).squeeze(-1)
    headings_sin = torch.sin(agent_headings).squeeze(-1)
    heading_rot_mat = torch.stack(
        [
            torch.stack([headings_cos, -headings_sin], dim=-1),
            torch.stack([headings_sin, headings_cos], dim=-1),
        ],
        dim=-2,
    )
    half_l = agent_sizes[..., 0] / 2
    half_w = agent_sizes[..., 1] / 2
    front_l = half_l
    back_l = -half_l
    left_w = half_w
    right_w = -half_w

    # 计算bbox的4个角点坐标
    local_corners = torch.stack(
        [
            torch.stack([front_l, left_w], dim=-1),
            torch.stack([front_l, right_w], dim=-1),
            torch.stack([back_l, right_w], dim=-1),
            torch.stack([back_l, left_w], dim=-1),
        ],
        dim=-2,
    )  # torch.Size([4, 64, 35, 4, 2])
    # rotation and shift corners
    # local to ego
    corners = torch.matmul(heading_rot_mat.unsqueeze(-3), local_corners.unsqueeze(-1)).squeeze(
        -1
    ) + agent_points.unsqueeze(
        -2
    )  # torch.Size([4, 64, 35, 4, 2])
    return corners


def agent_gaussian_collision_check(
    ego_motion_preds: torch.Tensor,
    ego_heading_preds: torch.Tensor,
    ego_motion_gt_masks: torch.Tensor,
    ego_bbox_info: torch.Tensor,
    agent_gts: torch.Tensor,
    agent_gt_masks: torch.Tensor,
    agent_bbox_infos: torch.Tensor,
    ego_pred_vel: Optional[torch.Tensor] = None,
    max_acc=4,
    ego_base_padding=0.0,
    agent_base_padding=0.1,
    size_aware_padding=False,
    size_aware_base=1,
    ego_x_steps=9,
    ego_y_steps=5,
    ego_speed_aware_padding: bool = True,
    agent_speed_aware_padding: bool = True,
    guassian_thr=0.0,
    soft_constraint=False,
    ego_position_gts=None,
    ego_heading_gts=None,
    ego_vel_gts=None,
    vis=False,
    agent_class_scale_dict=None,
):
    """Calculate agent collision check."""
    ego_future_step = ego_pred_vel.shape[-2]
    agent_gts = agent_gts[..., :ego_future_step, :]
    agent_gt_masks = agent_gt_masks[..., :ego_future_step]
    agent_bbox_infos = agent_bbox_infos[..., :ego_future_step, :]
    batch_size, agent_num, future_step, dim = agent_gts.shape
    _, _, ego_mode, _ = ego_motion_preds.shape
    ego_sizes = ego_bbox_info  # .unsqueeze(1).repeat(1, agent_num, future_step, 1)
    ego_sizes[..., 1] = vehicle_param.ET5_width_w_mirror  # torch.Size([4, 64, 35, 2])
    ego_sizes = ego_sizes.unsqueeze(-2).unsqueeze(-2).repeat(1, 1, ego_mode, future_step, 1)
    ego_pred_positions = ego_motion_preds.reshape(batch_size, 1, ego_mode, future_step, dim)
    # ego_cornes [B, 1, 72, 35, 4, 2]
    ego_corners = get_ego_corners(
        ego_pred_positions,
        ego_heading_preds,
        ego_pred_vel,
        ego_sizes,
        max_acc=max_acc,
        collision_threshold=ego_base_padding,
        speed_aware_padding=ego_speed_aware_padding,
        x_steps=ego_x_steps,
        y_steps=ego_y_steps,
    )

    # NOTE: agent future from agent gt
    agent_headings = agent_bbox_infos[..., 6:7]  # torch.Size([4, 64, 35, 1])
    agent_sizes = agent_bbox_infos[..., 3:5]  # torch.Size([4, 64, 35, 2])
    agent_vels = agent_bbox_infos[..., 10:12]  # torch.Size([4, 64, 35, 2])
    # agent_corners [B, 64, 35, 4, 2]
    agent_mus, agent_sigmas, agent_inv_sigmas = calculate_agent_gaussian_kernel(
        agent_gts,
        agent_headings,
        agent_vels,
        agent_sizes,
        max_acc=max_acc,
        collision_threshold=agent_base_padding,
        speed_aware_padding=agent_speed_aware_padding,
        size_aware_padding=size_aware_padding,
        size_aware_base=size_aware_base,
    )
    # ego_corners = ego_corners.repeat(1, agent_num, 1, 1, 1, 1)  # torch.Size([4, 64, 72, 35, 15, 2])
    agent_mus = agent_mus.unsqueeze(2).unsqueeze(-2)
    ego_agent_diff = ego_corners - agent_mus
    agent_inv_sigmas = agent_inv_sigmas.unsqueeze(2).unsqueeze(-3)
    gaussian_values = torch.exp(
        torch.clamp(
            -0.5 * torch.einsum("...i,...ij,...j", ego_agent_diff, agent_inv_sigmas, ego_agent_diff), min=-88, max=88
        )
    )
    # gaussian_values = gaussian_values.sum(-1)
    # NOTE: dont use ego_motion_gt_masks
    ego_motion_gt_masks = torch.reshape(ego_motion_gt_masks, (batch_size, 1, 1, future_step, 1))
    agent_gt_masks = torch.reshape(agent_gt_masks, (batch_size, agent_num, 1, future_step, 1))
    guassian_masks = gaussian_values > guassian_thr
    gaussian_values = gaussian_values * agent_gt_masks * ego_motion_gt_masks * guassian_masks
    gaussian_values_gt = None
    ego_corners_gt = None
    if soft_constraint:
        ego_corners_gt = get_ego_corners(
            ego_position_gts,
            ego_heading_gts,
            ego_vel_gts,
            ego_sizes,
            max_acc=max_acc,
            collision_threshold=ego_base_padding,
            speed_aware_padding=ego_speed_aware_padding,
            x_steps=ego_x_steps,
            y_steps=ego_y_steps,
        )
        ego_agent_diff_gt = ego_corners_gt - agent_mus
        gaussian_values_gt = torch.exp(
            torch.clamp(
                -0.5 * torch.einsum("...i,...ij,...j", ego_agent_diff_gt, agent_inv_sigmas, ego_agent_diff_gt),
                min=-88,
                max=88,
            )
        )
        guassian_masks_gt = gaussian_values_gt > guassian_thr
        gaussian_values_gt = gaussian_values_gt * agent_gt_masks * ego_motion_gt_masks * guassian_masks_gt

    # gaussian_values = gaussian_values.sum(1)  # [B, T]
    result = {
        "ego_corners": ego_corners,
        "agent_mus": agent_mus,
        "agent_inv_sigmas": agent_inv_sigmas,
    }
    if vis:
        result.update(
            {
                "raw_agent_corners": get_raw_agent_corners(agent_gts, agent_headings, agent_sizes),
                "raw_ego_corners": get_raw_ego_corners(ego_pred_positions, ego_heading_preds, ego_sizes),
            }
        )
    gaussian_values = torch.clamp(gaussian_values, 0, 1)
    if agent_class_scale_dict is not None:
        agent_class_type = torch.gather(
            agent_bbox_infos[..., 7], -1, agent_gt_masks.squeeze(2).squeeze(-1).argmax(dim=-1)[:, :, None]
        ).squeeze(-1)
        agent_class_type = torch.clamp(agent_class_type // 100, 0)
        agent_gaussian_scale = torch.ones_like(gaussian_values)
        for class_type, class_scale in agent_class_scale_dict.items():
            agent_gaussian_scale[class_type == agent_class_type] *= class_scale
        gaussian_values = gaussian_values * agent_gaussian_scale
        gaussian_values_gt = gaussian_values_gt * agent_gaussian_scale
    return ego_corners, ego_corners_gt, gaussian_values, gaussian_values_gt, result


def lane_guassian_collision_check(
    ego_corners,
    ego_corners_gt,
    ego_motion_preds,
    ego_position_gts,
    ego_motion_gt_masks,
    lane_points,
    lane_types,
    lane_attr,
    road_edge_sigma=0.2,
    line_sigma=0.5,
    road_edge_scale=1.0,
    line_scale=0.2,
    soft_constraint=False,
    near_lane_thr=20,
):
    """Calculate lane collision check."""
    # ego_corners: torch.Size([32, 1, 1, 35, 45, 2])
    # lane_points: torch.Size([32, 100, 50, 2])
    # lane_types: torch.Size([32, 100, 50])
    # lane_attr:  torch.Size([32, 100, 50, 2])
    # construct new lane points and types for speed up
    batch_size, lane_num, lane_points_num, _ = lane_points.shape
    valid_mask = (lane_types == 0) | (lane_types == 1)
    dist_scale = 100 + valid_mask * -99
    # lane_ego_diff = lane_points.unsqueeze(-2) - ego_position_gts  # * dist_scale.unsqueeze(-1).unsqueeze(-1)
    # lane_ego_diff_gt = lane_points.unsqueeze(-2) - ego_motion_preds.reshape(*ego_motion_preds.shape[:-1], -1, 2)
    # lane_ego_dist_pred = torch.norm(lane_ego_diff, dim=-1)
    # lane_ego_dist_gt = torch.norm(lane_ego_diff_gt, dim=-1)
    lane_ego_dist_pred = torch.norm(lane_points.unsqueeze(-2) - ego_position_gts, dim=-1)
    lane_ego_dist_gt = torch.norm(
        lane_points.unsqueeze(-2) - ego_motion_preds.reshape(*ego_motion_preds.shape[:-1], -1, 2), dim=-1
    )
    lane_ego_dist = torch.minimum(lane_ego_dist_pred, lane_ego_dist_gt) * dist_scale.unsqueeze(-1)
    lane_ego_dist = lane_ego_dist.reshape(batch_size, lane_num * lane_points_num, -1)
    lane_ego_dist_min, _ = lane_ego_dist.reshape(batch_size, lane_num * lane_points_num, -1).min(-1)
    lane_ego_dist_min_mask = lane_ego_dist_min < near_lane_thr
    (
        lane_select_i,
        lane_select_j,
    ) = torch.where(lane_ego_dist_min_mask)
    lane_counts = (lane_ego_dist_min_mask).sum(-1)
    max_lane = lane_counts.max()
    target_indices = torch.cat([torch.arange(count, device=lane_points.device) for count in lane_counts])
    new_lane_points = torch.zeros((batch_size, max_lane, 2), device=lane_points.device)
    new_lane_types = torch.full((batch_size, max_lane), -1, device=lane_types.device, dtype=lane_types.dtype)
    new_lane_points[lane_select_i, target_indices] = lane_points.reshape(batch_size, lane_num * lane_points_num, 2)[
        lane_select_i, lane_select_j
    ]
    new_lane_types[lane_select_i, target_indices] = lane_types.reshape(batch_size, lane_num * lane_points_num)[
        lane_select_i, lane_select_j
    ]
    # calculate gaussian
    road_edge_mask = new_lane_types == 1
    lane_sigmas = (line_sigma + road_edge_mask * (road_edge_sigma - line_sigma)) ** 2
    lane_scales = line_scale + road_edge_mask * (road_edge_scale - line_scale)
    lane_covs = torch.stack(
        [
            torch.stack([lane_sigmas, torch.zeros_like(lane_sigmas)], dim=-1),
            torch.stack([torch.zeros_like(lane_sigmas), lane_sigmas], dim=-1),
        ],
        dim=-2,
    )
    lane_inv_covs = torch.linalg.inv(lane_covs)
    lane_inv_covs = lane_inv_covs.reshape(batch_size, -1, 1, 1, 1, 2, 2)  # .unsqueeze(2).unsqueeze(2).unsqueeze(2)
    lane_mus = new_lane_points.reshape(batch_size, -1, 1, 1, 1, 2)  # .unsqueeze(2).unsqueeze(2).unsqueeze(2)
    lane_scales = lane_scales.reshape(batch_size, -1, 1, 1, 1)  # .unsqueeze(2).unsqueeze(2).unsqueeze(2)
    new_valid_mask = (new_lane_types == 0) | (new_lane_types == 1)
    valid_mask = new_valid_mask.reshape(batch_size, -1, 1, 1, 1)  # .unsqueeze(2).unsqueeze(2).unsqueeze(2)
    lane_scales = lane_scales * valid_mask * ego_motion_gt_masks.reshape(batch_size, 1, 1, -1, 1)
    ego_lane_diff = ego_corners - lane_mus

    num_frames, num_points = ego_corners.shape[-3], ego_corners.shape[-2]
    ego_lane_diff_norm = torch.norm(ego_lane_diff, dim=-1)
    if ego_lane_diff_norm.shape[1] > 1:
        min_dist_index = ego_lane_diff_norm.min(1)[1]  # agent dim -> 1
        expand_min_dist_index = (
            min_dist_index.unsqueeze(1).unsqueeze(-1).expand(batch_size, 1, 1, num_frames, num_points, 2)
        )
        ego_lane_diff = torch.gather(ego_lane_diff, 1, expand_min_dist_index)

        lane_inv_covs_pred = lane_inv_covs.expand(batch_size, -1, 1, num_frames, num_points, 2, 2)
        expand_min_dist_index = (
            min_dist_index.unsqueeze(1)
            .unsqueeze(-1)
            .unsqueeze(-1)
            .expand(batch_size, 1, 1, num_frames, num_points, 2, 2)
        )
        lane_inv_covs_pred = torch.gather(lane_inv_covs_pred, 1, expand_min_dist_index)
    else:
        lane_inv_covs_pred = lane_inv_covs
    # gaussian_values = torch.exp(-0.5 * torch.einsum("...i,...ij,...j", ego_lane_diff, lane_inv_covs, ego_lane_diff))
    intermediate = torch.einsum("...i,...ij,...j", ego_lane_diff, lane_inv_covs_pred, ego_lane_diff)
    intermediate.mul_(-0.5)
    gaussian_values = torch.exp(torch.clamp(intermediate), min=-88, max=88)
    gaussian_values = gaussian_values * lane_scales  # * valid_mask

    gaussian_values_gt = None
    if soft_constraint:
        ego_lane_diff_gt = ego_corners_gt - lane_mus
        ego_lane_diff_gt_norm = torch.norm(ego_lane_diff_gt, dim=-1)
        if ego_lane_diff_gt_norm.shape[1] > 1:
            min_dist_index = ego_lane_diff_gt_norm.min(1)[1]  # agent dim -> 1
            expand_min_dist_index = (
                min_dist_index.unsqueeze(1).unsqueeze(-1).expand(batch_size, 1, 1, num_frames, num_points, 2)
            )
            ego_lane_diff_gt = torch.gather(ego_lane_diff_gt, 1, expand_min_dist_index)
            lane_inv_covs_gt = lane_inv_covs.expand(batch_size, -1, 1, num_frames, num_points, 2, 2)
            expand_min_dist_index = (
                min_dist_index.unsqueeze(1)
                .unsqueeze(-1)
                .unsqueeze(-1)
                .expand(batch_size, 1, 1, num_frames, num_points, 2, 2)
            )
            lane_inv_covs_gt = torch.gather(lane_inv_covs_gt, 1, expand_min_dist_index)
        else:
            lane_inv_covs_gt = lane_inv_covs
        # ego_lane_diff_gt = ego_lane_diff_gt.to(torch.float16)
        # lane_inv_covs_gt = lane_inv_covs_gt.to(torch.float16)
        intermediate = torch.einsum("...i,...ij,...j", ego_lane_diff_gt, lane_inv_covs_gt, ego_lane_diff_gt)
        intermediate.mul_(-0.5)
        gaussian_values_gt = torch.exp(torch.clamp(intermediate), min=-88, max=88)
        gaussian_values_gt = gaussian_values_gt * lane_scales  # * valid_mask
    lane_collision_infos = {
        "lane_mus": lane_mus,
        "lane_inv_sigmas": lane_inv_covs,
        "lane_scales": lane_scales,
    }

    return gaussian_values, gaussian_values_gt, lane_collision_infos


def get_ego_corners_v2(
    ego_pos,
    ego_yaw,
    ego_vels,
    ego_sizes,
    speed_aware_padding=True,
    y_buffer=0,
):
    """Get ego corners."""
    # 根据 heading 旋转速度方向，heading方向为正x轴
    headings_cos = torch.cos(ego_yaw).squeeze(-1)  # [B, N, 35]
    ego_yaw_sin = torch.sin(ego_yaw).squeeze(-1)  # [B, N, 35]
    heading_rot_mat = torch.stack(
        [
            torch.stack([headings_cos, -ego_yaw_sin], dim=-1),
            torch.stack([ego_yaw_sin, headings_cos], dim=-1),
        ],
        dim=-2,
    )  # [B, N, 35, 2, 2]

    if speed_aware_padding:
        # 旋转速度向量至 ego 坐标系
        rot_vels = torch.matmul(heading_rot_mat.transpose(-1, -2), ego_vels.unsqueeze(-1)).squeeze(-1)
        dists_x = rot_vels[..., 0].abs() * 0.01 * torch.sign(rot_vels[..., 0])
        dists_y = rot_vels[..., 1].abs() * 0.01 * torch.sign(rot_vels[..., 1])
        sizes_pad_front = torch.clamp(dists_x, min=0.0)
        sizes_pad_back = torch.clamp(dists_x, max=-0.0)
        sizes_pad_left = torch.clamp(dists_y, min=y_buffer)
        sizes_pad_right = torch.clamp(dists_y, max=-y_buffer)
    else:
        sizes_pad_front = 0
        sizes_pad_back = 0
        sizes_pad_left = 0
        sizes_pad_right = 0

    half_w = ego_sizes[..., 1] / 2
    back_l = torch.ones_like(half_w) * (-vehicle_param.ET5_rear_overhang) + sizes_pad_back  # expected negative value
    front_l = ego_sizes[..., 0] - vehicle_param.ET5_rear_overhang + sizes_pad_front  # expected positive value
    left_w = half_w + sizes_pad_left  # expected positive value
    right_w = -half_w + sizes_pad_right  # expected negative value

    # 计算bbox的4个角点坐标
    local_corners = torch.stack(
        [
            torch.stack([front_l, left_w], dim=-1),
            torch.stack([front_l, right_w], dim=-1),
            torch.stack([back_l, right_w], dim=-1),
            torch.stack([back_l, left_w], dim=-1),
        ],
        dim=-2,
    )  # torch.Size([B, N, 35, 4, 2])

    # 旋转并平移到全局坐标系
    corners = torch.matmul(heading_rot_mat.unsqueeze(-3), local_corners.unsqueeze(-1)).squeeze(-1)  # [B, N, 35, 4, 2]
    corners = corners + ego_pos.unsqueeze(-2)  # [B, N, 35, 1, 2]

    return corners


def calc_padding_size(vels, yaws, padding_cfg=None, pad_type="ego", ego_pos=None):
    """Calculate padding size based on velocity and yaw rate.

    For each direction, padding_size = min(lambda_0 + lambda_1 * speed + lambda_2 * yaw_rate * speed, max_value)
    lambda_0, lambda_1 and lambda_2 are the parameters in padding_cfg.
    """
    if padding_cfg is None:
        return 0, 0, 0, 0
    agent_to_ego = None
    speed = torch.norm(vels, dim=-1).abs()  # [B, N, T]
    if pad_type == "vru" and ego_pos is not None:
        ego_pos_dir = ego_pos[:, :, 1:] - ego_pos[:, :, :-1]
        ego_pos_dir = torch.cat([ego_pos_dir, ego_pos_dir[:, :, -2:-1]], dim=2)
        ego_pos_dir_norm = (ego_pos_dir / (1e-6 + torch.norm(ego_pos_dir, dim=-1).unsqueeze(-1))).transpose(
            1, 2
        )  # [4,25,1,2]
        agent_yaw_norm = torch.cat([torch.cos(yaws), torch.sin(yaws)], dim=-1).transpose(1, 2)  # [4,25,64,2]
        agent_to_ego = torch.abs(torch.matmul(ego_pos_dir_norm, agent_yaw_norm.transpose(-2, -1))) < 3**0.5 / 2
        agent_to_ego = agent_to_ego.squeeze(-2).transpose(-2, -1)

        short_mask = torch.norm(ego_pos_dir, dim=-1).sum(-1) > 1
        # add speed mask
        speed_mask = speed[..., 0] > 0.3
        agent_to_ego = agent_to_ego * short_mask.unsqueeze(-1) * speed_mask.unsqueeze(-1)
    ego_lk_mask = None
    if pad_type == "ego" and ego_pos is not None:
        ego_lk_mask = torch.abs(ego_pos[..., 1].mean(-1)) < 0.4

    # calculate speed(scalar not vector) & yaw_rate

    # yaws = yaws.squeeze().abs()
    yaw_rate = (
        torch.cat([torch.zeros_like(yaws[:, :, :1]), yaws[:, :, 1:] - yaws[:, :, :-1]], dim=2).squeeze(-1).abs()
    )  # [B, N, T-1]

    # calculate padding size for each direction
    padding_sizes = []
    for direction in ["front", "back", "left", "right"]:
        direction_pad_cfg = padding_cfg.get(direction, {})
        lambda_0 = direction_pad_cfg.get("lambda_0", 0)
        lambda_1 = direction_pad_cfg.get("lambda_1", 0)
        lambda_2 = direction_pad_cfg.get("lambda_2", 0)
        max_value = direction_pad_cfg.get("max_value", None)
        pad_size = lambda_0 + lambda_1 * speed + lambda_2 * yaw_rate * speed
        if agent_to_ego is not None:
            if direction in ["left", "right"]:
                pad_size_cross = 1.5 + lambda_1 * speed + lambda_2 * yaw_rate * speed
                pad_size = torch.where(agent_to_ego, pad_size_cross, pad_size)
            else:
                pad_size = torch.where(agent_to_ego, pad_size * 1.5, pad_size)

        if ego_lk_mask is not None and direction in ["front"]:
            pad_size_lk = 1.5 + lambda_1 * speed + lambda_2 * yaw_rate * speed
            pad_size = torch.where(ego_lk_mask.unsqueeze(-1).expand(*pad_size.shape), pad_size_lk, pad_size)

        if max_value is not None:
            pad_size = torch.clamp(pad_size, min=0, max=max_value)
        padding_sizes.append(pad_size)
    return padding_sizes


def get_box_corners(
    box_centers,
    box_headings,
    box_vels,
    box_sizes,
    dynamic_padding=False,
    dynamic_padding_cfg=DEFAULT_VEHICLE_PADDING_CFG,
    pad_type="ego",
    ego_pos=None,
):
    """Calculate corner coordinates of 3D bounding boxes."""
    headings_cos = torch.cos(box_headings).squeeze(-1)
    headings_sin = torch.sin(box_headings).squeeze(-1)
    heading_rot_mat = torch.stack(
        [
            torch.stack([headings_cos, -headings_sin], dim=-1),
            torch.stack([headings_sin, headings_cos], dim=-1),
        ],
        dim=-2,
    )

    if dynamic_padding:
        sizes_pad_front, sizes_pad_back, sizes_pad_left, sizes_pad_right = calc_padding_size(
            box_vels, box_headings, dynamic_padding_cfg, pad_type, ego_pos
        )
    else:
        sizes_pad_front = 0
        sizes_pad_back = 0
        sizes_pad_left = 0
        sizes_pad_right = 0

    # 获取长和宽并pading
    #         front_l
    # left_w  center   right_w
    #         back_l
    half_l = box_sizes[..., 0] / 2
    half_w = box_sizes[..., 1] / 2
    front_l = half_l + sizes_pad_front
    back_l = -(half_l + sizes_pad_back)
    left_w = half_w + sizes_pad_left
    right_w = -(half_w + sizes_pad_right)
    local_corners = torch.stack(
        [
            torch.stack([front_l, left_w], dim=-1),
            torch.stack([front_l, right_w], dim=-1),
            torch.stack([back_l, right_w], dim=-1),
            torch.stack([back_l, left_w], dim=-1),
        ],
        dim=-2,
    )  # [B, N, T, 4, 2]

    # rotation (local to ego) and shift corners
    corners = torch.matmul(heading_rot_mat.unsqueeze(-3), local_corners.unsqueeze(-1)).squeeze(-1)
    corners = corners + box_centers.unsqueeze(-2)  # [B, N, T, 4, 2]

    return corners


def calc_vel_padding_size(agent_vels, coeff=0.5, max_value=None):
    """Calculate padding size based on velocity."""
    pad_size = agent_vels.abs() * coeff
    if max_value is not None:
        pad_size = torch.clamp(pad_size, max=max_value)
    return pad_size


def get_agent_corners_v2(
    agent_points,
    agent_headings,
    agent_vels,
    agent_sizes,
    speed_aware_padding=True,
    padding_coeffs={
        "back": {"max_value": 0.0},
        "left": {"coeff": 0.01, "max_value": 0.1},
        "right": {"coeff": 0.01, "max_value": 0.1},
    },
):
    """计算 agent 的四个角点坐标."""
    headings_cos = torch.cos(agent_headings).squeeze(-1)
    headings_sin = torch.sin(agent_headings).squeeze(-1)
    heading_rot_mat = torch.stack(
        [
            torch.stack([headings_cos, -headings_sin], dim=-1),
            torch.stack([headings_sin, headings_cos], dim=-1),
        ],
        dim=-2,
    )

    if speed_aware_padding:
        # ego to local
        # rot_vels = torch.matmul(heading_rot_mat.transpose(-1, -2), agent_vels.unsqueeze(-1)).squeeze(
        #     -1
        # )  # [4, 64, 35, 2]
        vels = torch.norm(agent_vels, dim=-1)
        # 计算安全刹车距离,假设最大刹车减速度为max_acc
        # dists = (rot_vels * rot_vels) / (2 * max_acc)
        # 用安全刹车距离来膨胀车辆size, 最小安全刹车距离为collision_threshold
        # dists_x = rot_vels[..., 0].abs() * 0.5 * torch.sign(rot_vels[..., 0])  # TODO need to rethink, keep the sign
        # dists_y = rot_vels[..., 1].abs() * 0.5 * torch.sign(rot_vels[..., 1])  # TODO need to rethink, keep the sign
        # sizes_pad_front = torch.clamp(dists_x, min=0.0)
        # sizes_pad_back = torch.clamp(dists_x, max=-0.0)
        # sizes_pad_left = torch.clamp(dists_y, min=0.0)
        # sizes_pad_right = torch.clamp(dists_y, max=-0.0)
        sizes_pad_front = calc_vel_padding_size(vels, **padding_coeffs.get("front", {}))
        sizes_pad_back = calc_vel_padding_size(vels, **padding_coeffs.get("back", {})) * -1
        sizes_pad_left = calc_vel_padding_size(vels, **padding_coeffs.get("left", {}))
        sizes_pad_right = calc_vel_padding_size(vels, **padding_coeffs.get("right", {})) * -1
    else:
        sizes_pad_front = 0
        sizes_pad_back = 0
        sizes_pad_left = 0
        sizes_pad_right = 0
    # 获取长和宽并pading
    #         front_l
    # left_w  center   right_w
    #         back_l
    half_l = agent_sizes[..., 0] / 2
    half_w = agent_sizes[..., 1] / 2
    front_l = half_l + sizes_pad_front
    back_l = -half_l + sizes_pad_back
    left_w = half_w + sizes_pad_left
    right_w = -half_w + sizes_pad_right
    local_corners = torch.stack(
        [
            torch.stack([front_l, left_w], dim=-1),
            torch.stack([front_l, right_w], dim=-1),
            torch.stack([back_l, right_w], dim=-1),
            torch.stack([back_l, left_w], dim=-1),
        ],
        dim=-2,
    )  # [B, 64, 35, 4, 2]

    # rotation (local to ego) and shift corners
    corners = torch.matmul(heading_rot_mat.unsqueeze(-3), local_corners.unsqueeze(-1)).squeeze(-1)
    corners = corners + agent_points.unsqueeze(-2)  # [B, 64, 35, 4, 2]
    return corners


def get_lane_corners(lane_points, lane_types):
    """计算 lane 的四个角点坐标."""
    batch_size, num_lines, num_points, _ = lane_points.shape
    lane_points_start = lane_points[:, :, :-1]  # [B, 100, 49, 2]
    lane_points_end = lane_points[:, :, 1:]  # [B, 100, 49, 2]

    lane_corners = torch.stack(
        [
            lane_points_start,
            lane_points_end,
            lane_points_end,
            lane_points_start,
        ],
        dim=-2,
    )  # [B, 100, 49, 4, 2]

    road_edge_valid = lane_types == 1  # [B, 100, 50] 1 for road edge
    road_edge_valid = road_edge_valid.view(-1, num_points)
    end_point_index = road_edge_valid.sum(-1) - 1
    road_edge_valid[torch.arange(len(end_point_index)), end_point_index] = False
    road_edge_valid = road_edge_valid[:, :-1]  # [B*100, 49] drop the last point
    road_edge_valid = road_edge_valid.reshape(batch_size, -1)  # [B, 100*49]

    lane_corners = lane_corners.view(batch_size, -1, 4, 2)  # [B, 100*49, 4, 2]
    lane_corners_valid = [corners[idx] for corners, idx in zip(lane_corners, road_edge_valid)]
    lane_corners_valid = pad_sequence(lane_corners_valid, batch_first=True, padding_value=-1.0)  # [B, max_num, 4, 2]

    lane_corners_mask = [valid[idx] for valid, idx in zip(road_edge_valid, road_edge_valid)]
    lane_corners_mask = pad_sequence(lane_corners_mask, batch_first=True, padding_value=False)  # [B, max_num]

    return lane_corners_valid, lane_corners_mask


def agent_reward_collision_check(
    ego_pred_pos: torch.Tensor,
    ego_pred_yaw: torch.Tensor,
    ego_pred_vel: torch.Tensor,
    ego_bbox_info: torch.Tensor,
    agent_gts: torch.Tensor,
    agent_bbox_infos: torch.Tensor,
    model_inputs=None,
):
    """Calculate agent collision check."""
    batch_size, agent_num, future_step, dim = agent_gts.shape  # [B, 64, 35, 2]

    _, num_trajs, _, _ = ego_pred_pos.shape  # [B, 1, 96, 70]
    ego_sizes = ego_bbox_info  # [B, 1, 2]
    ego_sizes[..., 1] = vehicle_param.ET5_width_w_mirror  # torch.Size([4, 64, 35, 2])
    ego_sizes = ego_sizes.unsqueeze(-2).repeat(1, num_trajs, future_step, 1)  # [B, 81, 35, 2]

    # ego_corners = get_ego_corners_v2(
    #     ego_pred_pos,
    #     ego_pred_yaw,
    #     ego_pred_vel,
    #     ego_sizes,
    #     speed_aware_padding=True,
    #     y_buffer=0.0,
    # )  # [B, 81, 35, 4, 2]
    ego_corners = get_box_corners(
        ego_pred_pos,
        ego_pred_yaw,
        ego_pred_vel,
        ego_sizes,
        dynamic_padding=True,
        pad_type="ego",
        ego_pos=model_inputs["egos_pred_gt"],
    )

    ego_corners = ego_corners.unsqueeze(1)
    ego_corners_list = [ego_corners]
    ego_pred_pos_list = [ego_pred_pos]
    ego_pred_vel_list = [ego_pred_vel]
    future_step_check_num = 2
    if future_step_check_num:
        ego_corners_padding = torch.cat([ego_corners] + [ego_corners[..., -1:, :, :]] * future_step_check_num, dim=-3)
        ego_pred_pos_padding = torch.cat([ego_pred_pos] + [ego_pred_pos[..., -1:, :]] * future_step_check_num, dim=-2)
        ego_pred_vel_padding = torch.cat([ego_pred_vel] + [ego_pred_vel[..., -1:, :]] * future_step_check_num, dim=-2)
        for idx in range(1, future_step_check_num + 1):
            ego_corners_list.append(ego_corners_padding[..., idx : idx + future_step, :, :])
            ego_pred_pos_list.append(ego_pred_pos_padding[..., idx : idx + future_step, :])
            ego_pred_vel_list.append(ego_pred_vel_padding[..., idx : idx + future_step, :])

    agent_headings = agent_bbox_infos[..., 6:7]  # torch.Size([4, 64, 35, 1])
    agent_sizes = agent_bbox_infos[..., 3:5]  # torch.Size([4, 64, 35, 2])
    agent_vels = agent_bbox_infos[..., 10:12]  # torch.Size([4, 64, 35, 2])
    agent_classes = agent_bbox_infos[..., 7:8]  # torch.Size([4, 64, 35, 1])

    vru_mask = agent_classes > 300
    # calculate vehicle corners
    vehicle_corners = get_box_corners(
        agent_gts,
        agent_headings,
        agent_vels,
        agent_sizes,
        dynamic_padding=True,
        pad_type="vehicle",
    )
    vru_corners = get_box_corners(
        agent_gts,
        agent_headings,
        agent_vels,
        agent_sizes,
        dynamic_padding=True,
        dynamic_padding_cfg=DEFAULT_VRU_PADDING_CFG,
        pad_type="vru",
        ego_pos=model_inputs["egos_pred_gt"],
    )
    vru_mask = vru_mask.unsqueeze(-1).expand_as(vru_corners)
    agent_corners = torch.where(vru_mask, vru_corners, vehicle_corners)
    agent_corners = agent_corners.unsqueeze(2)  # [B, 64, 1, 35, 4, 2]

    # DEBUG: plot
    # import matplotlib
    # import matplotlib.pyplot as plt

    # orig_agent_corners = get_box_corners(
    #     agent_gts,
    #     agent_headings,
    #     agent_vels,
    #     agent_sizes,
    #     dynamic_padding=False,
    # )

    # for i in range(batch_size):
    #     valid_agent = (agent_sizes[i].reshape(agent_num, -1) != 0).all(dim=-1)
    #     orig_agent_box = orig_agent_corners[i, valid_agent].cpu().numpy()  # [64, 25, 4, 2]
    #     padded_agent_box = agent_corners[i, valid_agent, 0].cpu().numpy()  # [64, 25, 4, 2]
    #     agent_traj = agent_gts[i, valid_agent].cpu().numpy()
    #     valid_vru_mask = vru_mask[i, valid_agent, 0, 0, 0].cpu().numpy()
    #     plt.figure(figsize=(60, 40), dpi=100)
    #     ax = plt.gca()
    #     plt.xlim(-40, 80)
    #     plt.ylim(-40, 40)
    #     plt.grid()
    #     for j in range(valid_agent.sum()):
    #         # plot agent init box
    #         rect = matplotlib.patches.Polygon(orig_agent_box[j, 0], closed=True, facecolor='none', edgecolor='blue', lw=3)
    #         ax.add_patch(rect)
    #         # plot agent trajectory
    #         ax.plot(agent_traj[j, :, 0], agent_traj[j, :, 1], c='blue', lw=3)
    #         # plot vru padded box on each timestep
    #         if valid_vru_mask[j]:
    #             for k in range(1, 25):
    #                 rect = matplotlib.patches.Polygon(padded_agent_box[j, k], closed=True, facecolor='none', edgecolor='red', lw=2)
    #                 ax.add_patch(rect)
    #     # save
    #     subclip_id = model_inputs['subclip_ids'][i]
    #     frame_id = int(model_inputs['ids'][i].split('_')[-1])
    #     plt.savefig(f'/tmp/test_vru_pad/{subclip_id}_{frame_id}.png')
    #     print(f'/tmp/test_vru_pad/{subclip_id}_{frame_id}.png')

    collision_check_list = []
    for ego_corners, ego_pred_vel, ego_pred_pos in zip(ego_corners_list, ego_pred_vel_list, ego_pred_pos_list):
        collision_check = obb_is_intersect_batch(ego_corners, agent_corners)  # [B, 64, 81, 35]

        ego_pose = ego_pred_pos.permute(0, 2, 1, 3).reshape(-1, 1, num_trajs, dim)
        agent_pose = agent_gts.permute(0, 2, 1, 3).reshape(-1, agent_num, 1, dim)
        agent_to_ego = agent_pose - ego_pose
        agent_to_ego_norm = agent_to_ego / (torch.norm(agent_to_ego, dim=-1, keepdim=True) + 1e-6)
        ego_vel = ego_pred_vel.permute(0, 2, 1, 3).reshape(-1, num_trajs, dim)
        ego_vel = ego_vel.unsqueeze(1).expand(*agent_to_ego_norm.shape)
        ego_vel_norm = ego_vel / (torch.norm(ego_vel, dim=-1, keepdim=True) + 1e-6)
        agent_to_ego_range = (agent_to_ego_norm * ego_vel_norm).sum(dim=-1)
        front_mask = (agent_to_ego_range > 0).view(batch_size, future_step, agent_num, num_trajs).permute(0, 2, 3, 1)

        # 针对每一个时刻，计算该时刻下每个agent距离自车速度向量的垂直距离（换道/转弯时，目标侧1m外的碰撞agent保留）
        # agent_to_ego_vel_distance = torch.abs(
        #     agent_to_ego[..., 0] * ego_vel_norm[..., 1] - agent_to_ego[..., 1] * ego_vel_norm[..., 0]
        # )  # [4*25, 64, 240]
        # agent_to_ego_vel_distance_mask = (
        #     (agent_to_ego_vel_distance > 1).reshape(batch_size, future_step, agent_num, num_trajs).permute(0, 2, 3, 1)
        # )

        # 针对每一个时刻，计算该时刻下每个agent是在自车的左侧还是右侧（通过向量叉积）
        agent_to_ego_left_or_right = (
            ego_vel[..., 0] * agent_to_ego[..., 1] - ego_vel[..., 1] * agent_to_ego[..., 0]
        ) > 0
        agent_to_ego_left_or_right = agent_to_ego_left_or_right.reshape(
            batch_size, future_step, agent_num, num_trajs
        ).permute(0, 2, 3, 1)

        # 针对所有采样轨迹，判断换道的方向是自车的左侧还是右侧（通过向量叉积）
        center_line = ego_pred_pos.new_tensor([1, 0]).reshape(1, 1, 1, 2).expand(*ego_pred_pos.shape)
        ego_to_ego_0 = ego_pred_pos - ego_pred_pos[:, :, 0:1, :].expand(*ego_pred_pos.shape)
        left_or_right = (
            center_line[:, :, 0, 0] * ego_to_ego_0[:, :, -1, 1] - center_line[:, :, 0, 1] * ego_to_ego_0[:, :, -1, 0]
        ) > 0  # [4,240]
        left_or_right = left_or_right[:, None, :, None].expand(*agent_to_ego_left_or_right.shape)

        # 针对所有轨迹，判断是否为换道轨迹 (对每一条轨迹，计算距离中心线的最大距离和最小距离之差是否大于1m)
        ego_to_centerline_distance = torch.abs(
            ego_to_ego_0[..., 0] * center_line[..., 1] - ego_to_ego_0[..., 1] * center_line[..., 0]
        )  # [4,240,25]
        change_lane = (ego_to_centerline_distance.max(-1)[0] - ego_to_centerline_distance.min(-1)[0]) > 1  # [4,240]
        change_lane = change_lane[:, None, :, None].expand(*agent_to_ego_left_or_right.shape)

        # side_mask = change_lane & agent_to_ego_vel_distance_mask & (agent_to_ego_left_or_right == left_or_right)

        collision_check = collision_check.int()
        collision_check[~front_mask] = 0
        # collision_check[(~front_mask) & (~side_mask)] = 0

        collision_check_list.append(collision_check)
    if len(collision_check_list) > 1:
        collision_check = torch.stack(collision_check_list, dim=0).any(dim=0)
    else:
        collision_check = collision_check_list[0]

    return collision_check


def lane_reward_collision_check(
    ego_pred_pos,
    ego_pred_yaw,
    ego_pred_vel,
    ego_bbox_info,
    lane_points,
    lane_types,
    lane_attr,
):
    """Calculate lane collision check."""
    batch_size, ego_mode, future_step, dim = ego_pred_vel.shape  # [B, 81, 35, 2], [1,20,25,2]

    _, ego_mode, future_step, _ = ego_pred_pos.shape  # [B, 1, 81, 70]
    ego_sizes = ego_bbox_info  # [B, 1, 2]
    ego_sizes[..., 1] = vehicle_param.ET5_width_w_mirror  # torch.Size([4, 64, 35, 2])
    ego_sizes = ego_sizes.unsqueeze(-2).repeat(1, ego_mode, future_step, 1)  # [B, 81, 35, 2]

    ego_corners = get_ego_corners_v2(
        ego_pred_pos,
        ego_pred_yaw,
        ego_pred_vel,
        ego_sizes,
        speed_aware_padding=False,
        y_buffer=0.0,
    )  # [B, 81, 35, 4, 2]
    ego_corners = ego_corners.unsqueeze(1)  # [B, 1, 81, 35, 4, 2]

    lane_corners, lane_corners_mask = get_lane_corners(
        lane_points,
        lane_types,
    )  # [B, N, 4, 2]
    lane_corners = lane_corners.unsqueeze(2)  # [B, N, 1, 4, 2]

    # For each ego position, find the closest lane points for checking collision (reduce memory)
    top_num = 4
    ego_points = ego_pred_pos.reshape(batch_size, 1, -1, 2)  # [10, 1, 81*35, 2]
    lane_corners_points = lane_corners[:, :, :, 0]  # [10, N, 1, 2]
    if lane_corners_points.shape[1] > 0:
        dists = torch.norm(ego_points - lane_corners_points, dim=-1)  # [10, N, 81*35]
        closest_idx = dists.topk(k=top_num, dim=1, largest=False)[1]  # [10, top_num, 81*35]
        closest_idx_mask = closest_idx.reshape(batch_size, -1)
        closest_lane_corners_mask = torch.gather(lane_corners_mask, 1, closest_idx_mask)  # [10, top_num*96*35]
        closest_lane_corners_mask = closest_lane_corners_mask.view(
            batch_size, top_num, ego_mode, future_step
        )  # [B, 4, 81, 35]
        closest_idx_corners = closest_idx.view(batch_size, -1, 1, 1, 1).expand(
            -1, -1, -1, 4, 2
        )  # [10, top_num*81*35, 1, 4, 2]
        closest_lane_corners = torch.gather(lane_corners, 1, closest_idx_corners)  # [10, top_num*81*35, 1, 4, 2]
        closest_lane_corners = closest_lane_corners.view(
            batch_size, top_num, ego_mode, future_step, 4, 2
        )  # [B, 4, 81, 35, 4, 2]

        collision_check = obb_is_intersect_batch(ego_corners, closest_lane_corners)  # [B, 4, 81, 35]
        collision_check[~closest_lane_corners_mask] = False  # just in case, remove invalid points.
        # collision_check = collision_check.max(dim=1)[0]  # [B, 81, 35]

        collision_check, collision_check_idx = collision_check.max(dim=1)  # [B, 81, 35]
        closest_lane_corners = torch.gather(
            closest_lane_corners, 1, collision_check_idx[:, None, :, :, None, None].repeat(1, 1, 1, 1, 4, 2)
        ).squeeze(1)
    else:
        collision_check = torch.zeros(batch_size, ego_mode, future_step, dtype=torch.bool).cuda()
        closest_lane_corners = torch.zeros(batch_size, ego_mode, future_step, top_num, 2, dtype=torch.float32).cuda()

    return collision_check, closest_lane_corners


def obb_is_intersect_batch(
    corners_a: torch.Tensor,
    corners_b: torch.Tensor,
    eps: float = 1e-6,
) -> torch.Tensor:
    """
    Determine whether two sets of 2D oriented bounding boxes (OBBs) intersect using the Separating Axis Theorem (SAT).

    The input tensors must have shape [..., 4, 2], where the last two dimensions represent the 4 corner points and (x, y) coordinates.
    The preceding dimensions can be arbitrary (e.g., batch dimensions, candidate numbers, time steps, etc.) as long as
    corners_a and corners_b are broadcastable. The returned tensor has the broadcasted shape (excluding the last two dimensions).

    For example:
        If ego_corners has shape [B, N, M, 4, 2] and lane_corners has shape [B, N, M, 4, 2],
        then the returned collision_check will have shape [B, N, M].

    Args:
        corners_a (torch.Tensor): Tensor of shape [..., 4, 2] representing the corners of a set of OBBs.
        corners_b (torch.Tensor): Tensor of shape [..., 4, 2] representing the corners of another set of OBBs.
        eps (float): A small value for numerical stability, default is 1e-6.

    Returns:
        torch.Tensor: A Boolean tensor with shape [...] (i.e., the broadcasted shape excluding the last two dimensions),
        where each element indicates whether the corresponding pair of OBBs intersect.
    """
    # Broadcast corners_a and corners_b to a common shape
    corners_a, corners_b = torch.broadcast_tensors(corners_a, corners_b)

    def get_normals(corners: torch.Tensor) -> torch.Tensor:
        """Compute the unit normals for each edge of the OBB.

        Args:
            corners (torch.Tensor): Tensor of shape [..., 4, 2].

        Returns:
            torch.Tensor: Tensor of shape [..., 4, 2] containing the unit normals for each edge (computed as (-dy, dx)).
        """
        # Roll the corners along the second-to-last dimension to compute edge vectors
        c_next = torch.roll(corners, shifts=-1, dims=-2)  # [..., 4, 2]
        edges = c_next - corners  # [..., 4, 2]
        # Compute normals as (-dy, dx)
        normals = torch.stack([-edges[..., 1], edges[..., 0]], dim=-1)  # [..., 4, 2]
        # Normalize the normals to avoid division by zero
        norm = torch.clamp(torch.norm(normals, dim=-1, keepdim=True), min=eps)
        return normals / norm

    def compute_proj_min_max(candidate_axes: torch.Tensor, corners: torch.Tensor):
        """Compute the minimum and maximum projections of OBB corners onto candidate axes.

        Args:
            candidate_axes (torch.Tensor): Tensor of shape [..., 8, 2].
            corners (torch.Tensor): Tensor of shape [..., 4, 2].

        Returns:
            proj_min, proj_max (torch.Tensor, torch.Tensor): Both tensors have shape [..., 8],
                containing the minimum and maximum projection values along each candidate axis.
        """
        # Initialize proj_min and proj_max with the projection of the first corner.
        # Compute dot product along the last dimension.
        # corners[..., 0, :] has shape [..., 2]; unsqueeze to get [..., 1, 2] to broadcast with candidate_axes ([..., 8, 2])
        proj = torch.sum(candidate_axes * corners[..., 0, :].unsqueeze(-2), dim=-1)  # shape: [..., 8]
        proj_min = proj
        proj_max = proj

        # Iterate over the remaining 3 corners and update proj_min and proj_max
        for i in range(1, 4):
            proj = torch.sum(candidate_axes * corners[..., i, :].unsqueeze(-2), dim=-1)  # shape: [..., 8]
            proj_min = torch.minimum(proj_min, proj)
            proj_max = torch.maximum(proj_max, proj)

        return proj_min, proj_max

    # Compute the unit normals for each set of OBBs.
    normals_a = get_normals(corners_a)  # shape: [..., 4, 2]
    normals_b = get_normals(corners_b)  # shape: [..., 4, 2]

    # Candidate separating axes: concatenation of both sets' normals (8 axes in total).
    # This results in a tensor of shape [..., 8, 2].
    candidate_axes = torch.cat([normals_a, normals_b], dim=-2)

    # Compute the minimum and maximum projection values for both sets without allocating
    # the full projection matrix.
    a_min, a_max = compute_proj_min_max(candidate_axes, corners_a)  # shape: [..., 8]
    b_min, b_max = compute_proj_min_max(candidate_axes, corners_b)  # shape: [..., 8]

    # Determine whether there is a gap along any candidate axis.
    no_overlap = (a_max < b_min - eps) | (b_max < a_min - eps)  # shape: [..., 8]

    # The OBBs intersect if there is no gap along any of the candidate axes.
    intersect = ~no_overlap.any(dim=-1)  # shape: [...] (e.g., [B, N, M])
    return intersect


def point_to_trajectory_distance(points: torch.Tensor, trajectories: torch.Tensor) -> torch.Tensor:
    """
    Compute the shortest distance from each point to each trajectory for a batch.

    Args:
        points (torch.Tensor): Tensor of shape [B, N, 2] representing B batches of N 2D points.
        trajectories (torch.Tensor): Tensor of shape [B, M, T, 2] representing B batches of M trajectories,
            each defined by T 2D points (thus T-1 segments).

    Returns:
        torch.Tensor: A tensor of shape [B, N, M] where the (b, i, j)-th element is the shortest distance
            from points[b, i, :] to trajectory[b, j, :, :].
    """
    batch_size, _, _ = points.shape
    batch_size2, _, time_step, _ = trajectories.shape
    assert batch_size == batch_size2, "The batch dimensions of points and trajectories must match."

    # If a trajectory has fewer than 2 points, use the distance to the single point.
    if time_step < 2:
        # trajectories: [B, M, 1, 2] -> squeeze to [B, M, 2]
        traj_single = trajectories.squeeze(2)
        # Expand points: [B, N, 2] -> [B, N, M, 2] and compute Euclidean distances.
        diff = points.unsqueeze(2) - traj_single.unsqueeze(1)
        return torch.norm(diff, dim=-1)

    # For each trajectory, construct segments from consecutive points.
    # A: start points, shape [B, M, T-1, 2]
    # B: end points,   shape [B, M, T-1, 2]
    a = trajectories[:, :, :-1, :]
    b_exp = trajectories[:, :, 1:, :]

    # Compute segment vectors: v = B - A, shape: [B, M, T-1, 2]
    v = b_exp - a

    # Expand points for broadcasting:
    # points: [B, N, 2] -> [B, N, 1, 1, 2]
    points_exp = points.unsqueeze(2).unsqueeze(2)
    # Expand A and v: they are [B, M, T-1, 2] and become [B, 1, M, T-1, 2]
    a_exp = a.unsqueeze(1)
    v_exp = v.unsqueeze(1)

    # Compute vector from each segment start a to each point: w = point - a, shape: [B, N, M, T-1, 2]
    w = points_exp - a_exp

    # Compute the dot products: (w dot v) and (v dot v)
    dot_wv = (w * v_exp).sum(dim=-1)  # shape: [B, N, M, T-1]
    dot_vv = (v_exp * v_exp).sum(dim=-1) + 1e-8  # shape: [B, N, M, T-1] with epsilon to avoid division by zero

    # Compute projection parameter t for each segment: t = (w dot v) / (v dot v)
    t = dot_wv / dot_vv  # shape: [B, N, M, T-1]
    # Clamp t so that the projection falls on the segment: t ∈ [0, 1]
    t = torch.clamp(t, 0.0, 1.0)

    # Compute the projection point for each segment: projection = A + t * v
    # t needs to be unsqueezed to broadcast: shape becomes [B, N, M, T-1, 1]
    projection = a_exp + t.unsqueeze(-1) * v_exp  # shape: [B, N, M, T-1, 2]

    # Compute the Euclidean distance from the point to the projection on each segment
    diff = points_exp - projection  # shape: [B, N, M, T-1, 2]
    dists = torch.norm(diff, dim=-1)  # shape: [B, N, M, T-1]

    # For each point and trajectory, take the minimum distance over all segments (axis T-1)
    min_dist, _ = dists.min(dim=-1)  # shape: [B, N, M]

    return min_dist


# if __name__ == '__main__':
#     import math, torch
#     import matplotlib.pyplot as plt

#     # 构造矩形A：中心(0,0), 宽2, 高1, 旋转角度30°
#     angle_a = 30.0 * math.pi / 180.0
#     R_a = torch.tensor([[math.cos(angle_a), -math.sin(angle_a)],
#                         [math.sin(angle_a),  math.cos(angle_a)]])
#     half_sizes_a = torch.tensor([1.0, 0.5])
#     corners_local_a = torch.tensor([[-half_sizes_a[0], -half_sizes_a[1]],
#                                     [ half_sizes_a[0], -half_sizes_a[1]],
#                                     [ half_sizes_a[0],  half_sizes_a[1]],
#                                     [-half_sizes_a[0],  half_sizes_a[1]]])
#     corners_a = (R_a @ corners_local_a.T).T  # [4,2]

#     # 构造矩形B：中心(1,0), 宽2, 高1, 旋转角度-20°
#     angle_b = -20.0 * math.pi / 180.0
#     R_b = torch.tensor([[math.cos(angle_b), -math.sin(angle_b)],
#                         [math.sin(angle_b),  math.cos(angle_b)]])
#     half_sizes_b = torch.tensor([1.0, 0.5])
#     corners_local_b = torch.tensor([[-half_sizes_b[0], -half_sizes_b[1]],
#                                     [ half_sizes_b[0], -half_sizes_b[1]],
#                                     [ half_sizes_b[0],  half_sizes_b[1]],
#                                     [-half_sizes_b[0],  half_sizes_b[1]]])
#     corners_b = (R_b @ corners_local_b.T).T + torch.tensor([1.0, 0.0])  # 平移至(1,0)

#     # 为满足 batch 维度, 将 [4,2] 扩展为 [1,4,2]
#     corners_a_batch = corners_a.unsqueeze(0)
#     corners_b_batch = corners_b.unsqueeze(0)

#     # 计算是否相交
#     intersect = obb_is_intersect_batch(corners_a_batch, corners_b_batch)

#     # 绘制矩形用于可视化验证
#     def plot_rect(corners, color='b', label=None):
#         # corners: [4,2] Tensor
#         pts = corners.detach().cpu().numpy()
#         pts = list(pts) + [pts[0]]  # 连接最后一点到起始点
#         xs, ys = zip(*pts)
#         plt.plot(xs, ys, color=color, label=label)

#     plt.figure()
#     plot_rect(corners_a_batch[0], color='r', label='Rectangle A')
#     plot_rect(corners_b_batch[0], color='g', label='Rectangle B')
#     plt.legend()
#     plt.title(f"Intersection: {intersect.item()}")
#     plt.axis('equal')
#     plt.savefig("obb_collision.png")
#     plt.show()
