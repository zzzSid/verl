# -*- coding: utf-8 -*-
# flake8: noqa
"""Coords transform."""

import cv2
import numpy as np
import torch

from tpp_onemodel.utils.lidar_camera_utils import imwrite


def coords2img(
    coords_lidar,
    rot,
    tran,
    cam2img,
    post_rot,
    post_tran,
):
    """Transform lidar coords to pixel uv.

    Args:
        coords_lidar (tensor): 3D coords [N, 3]
        cam_feat (tensor): [N_view, C, H, W], output from camera backbone
        rot (tensor): [N_view, 3, 3], camera to lidar
        tran (tensor): [N_view, 3],   camera to lidar
        cam2img (tensor): [N_view, 3, 3]
        post_rot (tensor): [N_view, 3, 3]
        post_tran (tensor): [N_view, 3]


    Returns:
        coords_pixel (tensor): [N_view, N, 2]
        camera_depth (tensor): [N_view, N], pixel depth in camera coordinates.

    """
    # forward transform, lidar to camera
    # [N, 3], [N_view, 3] -> [1, N, 3], [N_view, 1, 3] ->[N_view, N, 3]
    coords_cam = coords_lidar.unsqueeze(0) - tran.unsqueeze(1)
    # lidar to camera, inverse rots
    # [N_view, N, 3], [N_view, 3, 3]
    coords_cam = torch.einsum("nij,nmj->nmi", rot.permute(0, 2, 1), coords_cam)
    # remove points not in view
    camera_depth = coords_cam[..., 2]
    # coords_mask = coords_cam[..., 2] > 1e-1
    # coords_cam[torch.logical_not(coords_mask)] = 0
    coords_cam[..., 2] = torch.clamp(coords_cam[..., 2], 1e-3, 1e3)
    # normalize
    coords_cam_norm = torch.cat(
        [
            coords_cam[..., :2] / coords_cam[..., 2:3],
            torch.full(
                (coords_cam.shape[0], coords_cam.shape[1], 1),
                1,
                dtype=coords_cam.dtype,
                device=coords_cam.device,
            ),
        ],
        axis=-1,
    )
    # camera to pixel
    # [N_view, N, 3] [N_view, 3, 3]
    coords_pixel = torch.einsum("nij,nmj->nmi", cam2img, coords_cam_norm)

    # image augments
    coords_pixel = torch.einsum("nij,nmj->nmi", post_rot, coords_pixel)
    coords_pixel = coords_pixel + post_tran.unsqueeze(1)

    return coords_pixel[..., :2], camera_depth


def project_points_to_img(points, img, vehicle2cam, cam2img, name):
    """Vis lidar on pic."""
    image_h = img.shape[0]
    image_w = img.shape[1]
    if cam2img.shape[-1] == 3:
        ori_cam2img = torch.from_numpy(cam2img).float()
        cam2img = ori_cam2img.new_zeros(1, 4, 4)
        cam2img[0, :3, :3] = ori_cam2img
        cam2img[0, 3, 3] = 1.0
    else:
        cam2img = torch.from_numpy(cam2img).float()
        cam2img = cam2img[:16].reshape(1, 4, 4)

    vehicle2cam = torch.from_numpy(vehicle2cam).float()[None]
    vehicle2img = torch.matmul(cam2img, vehicle2cam)
    vehicle2img = vehicle2img.view(1, 4, 4).permute(0, 2, 1)  # BN, 4, 4

    points = torch.from_numpy(points[:, :3]).float()
    points = torch.cat((points, torch.ones_like(points[..., :1])), -1)
    point2d = torch.matmul(points, vehicle2img)  # BN, XYZ, 4
    coords_pixel = point2d[..., :2] / point2d[..., 2:3]  # [1, 80593, 2]
    camera_depth = point2d[..., 2]  # [1, 80593]
    # use old func
    # coords_pixel, camera_depth = coords2img(
    #     torch.from_numpy(points[:, :3]),
    #     torch.from_numpy(extrinsic[:3, :3]).unsqueeze(0),
    #     torch.from_numpy(extrinsic[:3, 3]).unsqueeze(0),
    #     torch.from_numpy(intrinsic).unsqueeze(0),
    #     torch.from_numpy(np.eye(3)).unsqueeze(0),
    #     torch.from_numpy(np.zeros(3)).unsqueeze(0),
    # )

    camera_depth = camera_depth.float()
    in_view_mask = camera_depth > 1e-1
    # camera_depth = np.array(
    # reset depth not in view
    camera_depth[torch.logical_not(in_view_mask)] = 0

    on_img = (
        (coords_pixel[..., 0] < image_w)
        & (coords_pixel[..., 0] >= 0)
        & (coords_pixel[..., 1] < image_h)
        & (coords_pixel[..., 1] >= 0)
    )

    on_img = torch.logical_and(on_img, in_view_mask)

    # [N_view, 1, H, W]
    depth = torch.zeros(1, 1, image_h, image_w)

    # for c in range(on_img.shape[0]):
    #     print(c, "on_img", on_img[c].sum())
    masked_coords = coords_pixel[0, on_img[0]].long()
    masked_dist = camera_depth[0, on_img[0]]
    depth[0, 0, masked_coords[:, 1], masked_coords[:, 0]] = masked_dist

    # draw viz images
    # for c in range(on_img.shape[0]):
    # img = torch.from_numpy(fw_image)  # imgs[c]
    # img = img.cpu().numpy()
    # [C, H, W] -> [H, W, C]
    # img = np.ascontiguousarray(
    #     img.astype(np.float32).transpose([1, 2, 0])
    # )

    # print(c, depth[c].min(), depth[c].max())

    # [H, W, 1]
    pixel_dist = torch.clamp(depth[0].permute(1, 2, 0) / 60.0, 0, 1.0).cpu().numpy() * 255
    # print("pixel_dist", pixel_dist.shape)
    pixel_dist_color = cv2.applyColorMap(pixel_dist.astype(np.uint8), cv2.COLORMAP_VIRIDIS)
    # print(pixel_dist_color.shape)

    # draw points in image
    masked_coords = coords_pixel[0, on_img[0]].long()
    img = img.copy()
    img = img[:, :, [2, 1, 0]]  # RGB->BGR for cv2.imwrite
    img = np.ascontiguousarray(img, dtype=np.uint8)
    img_ori = img.copy()
    for pi in range(len(masked_coords)):  # pylint: disable = C0103
        color = pixel_dist_color[masked_coords[pi, 1], masked_coords[pi, 0]]
        cv2.circle(
            img,
            (int(masked_coords[pi, 0]), int(masked_coords[pi, 1])),
            radius=1,
            color=(
                int(color[0]),
                int(color[1]),
                int(color[2]),
            ),
            thickness=-1,
        )
    out_img = np.zeros((image_h * 3, image_w, 3), img.dtype)
    out_img[:image_h, :image_w, :] = pixel_dist_color
    out_img[image_h : image_h * 2, :image_w, :] = img
    out_img[image_h * 2 :, :image_w, :] = img_ori

    imwrite(out_img, f"/perception/LIDAR/tmp/lc_viz/{name}.jpg")
