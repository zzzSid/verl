# -*- coding: utf-8 -*-
"""The ProfileStopwatch utility."""

import logging
import statistics
from collections import defaultdict
from typing import Dict
from typing import List

import torch
import torch.distributed as dist
from prettytable import PrettyTable
from torchpilot.utils.stopwatch import Stopwatch


logger = logging.getLogger(__name__)


class ProfileStopwatch(Stopwatch):
    """Stopwatch for profile.

    Examples::

        >>> # Init ProfileStopwatch
        >>> profile_stopwatch = ProfileStopwatch(
                stopwatch_name="ProfileStopwatch",
                barrier_before_stopwatch=True,
            )
        >>> # Code1 to be profile
        >>> time.sleep(1)
        >>> # Record time cost
        >>> profile_stopwatch.record_time_cost("Code1")
        >>> # Code2 to be profile
        >>> time.sleep(2)
        >>> # Record time cost
        >>> profile_stopwatch.record_time_cost("Code2")
        >>> # Log time cost
        >>> profile_stopwatch.log_time_cost()
        >>> # Outputs:
            +------------------+-----------+
            | ProfileStopwatch | Time Cost |
            +------------------+-----------+
            |      Code1       |  1.001445 |
            |      Code2       |  2.001772 |
            +------------------+-----------+
        >>> # Reset stopwatch
        >>> profile_stopwatch.reset()
    """

    def __init__(
        self,
        stopwatch_name: str,
        barrier_before_stopwatch: bool = True,
        **kwargs,
    ):
        """Initialize.

        Args:
            stopwatch_name (str): Stopwatch name.
            barrier_before_stopwatch (bool): Whether enable barrier before stopwatch.
                Default=True.
        """
        super().__init__(**kwargs)
        self._barrier_before_stopwatch = barrier_before_stopwatch
        self._time_cost: Dict[str, List[float]] = defaultdict(list)
        self._table = PrettyTable()
        self._table.field_names = [stopwatch_name, "Time Cost"]
        self._table.align["Time Cost"] = "r"

    def toc(self):
        """Stop the Stopwatch."""
        if self._barrier_before_stopwatch:
            torch.cuda.synchronize()
            dist.barrier()

        return super().toc()

    def record_time_cost(self, time_cost_key: str):
        """Record time cost.

        Args:
            time_cost_key (str): Key of time cost.
        """
        self._time_cost[time_cost_key].append(self.toc2())

    def reset(self):
        """Reset the whole Stopwatch."""
        super().reset()
        self._time_cost: Dict[str, List[float]] = defaultdict(list)
        self._table.clear_rows()

    def log_time_cost(self):
        """Log time cost."""
        for key, value in self._time_cost.items():
            time_cost = statistics.mean(value)
            self._table.add_row([key, f"{time_cost:.6f}"])

        logger.warning("\n%s", self._table.get_string())
