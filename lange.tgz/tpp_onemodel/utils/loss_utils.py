# -*- coding: utf-8 -*-
"""Loss utilities."""
# import numpy as np
from enum import Enum
from typing import Tuple

import torch
import torch.nn as nn


# from torch import nn


def compute_closest_scenario(pred, gt, gt_mask):  # pylint: disable=unused-argument
    """Compute Closest Scenario."""
    # pred: [B, A+1, M, T, 2]
    # gt: [B, A+1, T, 2]
    # gt_mask: [B, A+1, T]

    # [B, M]
    dist_l2 = (torch.norm(pred - gt.unsqueeze(2), dim=-1) * gt_mask.unsqueeze(2)).sum(-1).sum(-2)
    return dist_l2


def compute_closest_marginal(pred, gt, gt_mask):
    """Compute Closest Marginal Trajectory."""
    # pred: [B, 1, M, T, 2]
    # gt: [B, 1, T, 2]
    # gt_mask: [B, 1, T]

    # [B, 1, M]
    validity_num = gt_mask.sum(-1)
    masked_dist_l2 = (torch.norm(pred - gt.unsqueeze(2), dim=-1) * gt_mask.unsqueeze(2)).sum(-1)
    dist_l2 = masked_dist_l2 / validity_num.unsqueeze(-1)

    return dist_l2


def compute_derivatives(
    x_pts: torch.Tensor, y_pts: torch.Tensor, spacing: float = 1.0
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """Compute the first and second derivatives of the 2D points.

    Args:
        x_pts (torch.Tensor): x coordinates of the 2D points (..., num_points)
        y_pts (torch.Tensor): y coordinates of the 2D points (..., num_points)
        spacing (float): spacing between the points

    Return:
        Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
            x_prime (torch.Tensor): First derivative of x_pts (..., num_points)
            y_prime (torch.Tensor): First derivative of y_pts (..., num_points)
            x_double_prime (torch.Tensor): Second derivative of x_pts (..., num_points)
            y_double_prime (torch.Tensor): Second derivative of y_pts (..., num_points)
    """
    x_prime = torch.gradient(x_pts, spacing=spacing, dim=-1)[0]
    y_prime = torch.gradient(y_pts, spacing=spacing, dim=-1)[0]
    x_double_prime = torch.gradient(x_prime, spacing=spacing, dim=-1)[0]
    y_double_prime = torch.gradient(y_prime, spacing=spacing, dim=-1)[0]
    return x_prime, y_prime, x_double_prime, y_double_prime


def compute_curvature(x_pts: torch.Tensor, y_pts: torch.Tensor) -> torch.Tensor:
    """Compute curvature from 2D points.

    Args:
        x_pts (torch.Tensor): x coordinates of the 2D points (..., num_points)
        y_pts (torch.Tensor): y coordinates of the 2D points (..., num_points)

    Returns:
        curvature (torch.Tensor): Curvature of the 2D points (..., num_points)

    Notes:
        - The curvatures of the first and last two points are estimated
        - Returns nan where the curvature computation fails due to zero division.
    """
    x_prime, y_prime, x_double_prime, y_double_prime = compute_derivatives(x_pts.squeeze(), y_pts.squeeze())
    numerator = x_prime * y_double_prime - y_prime * x_double_prime
    denominator = (x_prime**2 + y_prime**2) ** 1.5
    curvature = numerator / (denominator + 1.0e-8)
    return curvature


def get_loss_func(method, **kargs):
    """Get loss function.

    Args:
        method (str): Loss function name.
        **kargs: Loss function parameters.

    Raises:
        ValueError: Unsupported loss function.

    Returns:
        nn.Module: Loss function.
    """
    if method == "l1_loss":
        return nn.L1Loss(reduction=kargs.get("reduction", "mean"))
    elif method == "mse_loss":
        return nn.MSELoss(reduction=kargs.get("reduction", "mean"))
    elif method == "huber_loss":
        return nn.HuberLoss(reduction=kargs.get("reduction", "mean"), delta=kargs.get("delta", 1.0))
    elif method == "smooth_l1_loss":
        return nn.SmoothL1Loss(reduction=kargs.get("reduction", "mean"))
    else:
        raise ValueError(f"Unsupported loss function: {method}")


class TensorDim(Enum):
    """Tensor dimension."""

    BATCH_SIZE = 0
    K_EGO = 1
    K_SCENE = 2
    N_POINTS = 3
    N_PARAMS = 4

    @classmethod
    def __len__(cls) -> int:
        """Get the number of tensor dimensions.

        Returns:
            int: The number of tensor dimensions.
        """
        return len(cls.__members__)


class TrajDim(Enum):
    """Trajectory dimension."""

    X = 0
    Y = 1
    SPEED = 2
    ACC = 3
    KAPPA = 4
    YAW_RATE = 5

    @classmethod
    def __len__(cls) -> int:
        """Get the number of tensor dimensions.

        Returns:
            int: The number of tensor dimensions.
        """
        return len(cls.__members__)
