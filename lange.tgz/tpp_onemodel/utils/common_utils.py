# -*- coding: utf-8 -*-
"""Common utils."""
import time
from functools import lru_cache
from typing import List

from niofs import Client
from torchpilot import logger

from tpp_onemodel.utils.niofs import niofs_head_object


def timer(vis=False, addition_info=""):
    """Timer."""

    def time_it(func):
        def inner(*arg, **kwarg):
            s_time = time.time()
            res = func(*arg, **kwarg)
            e_time = time.time()
            cost = e_time - s_time
            if vis:
                logger.info(
                    "[%s%s, %s] cost time: %.3f",
                    addition_info,
                    func.__module__,
                    func.__qualname__,
                    cost,
                )
            return res

        return inner

    return time_it


def init_averager():  # -> Callable[..., float]:
    """Initialize a running averager."""
    count: int = 0
    total: int = 0

    def averager(new_value: int) -> float:
        nonlocal count, total
        count += 1
        total += new_value
        return total / count

    return averager


def get_paths_finfos(client: Client, paths: List[List[str]], detect_outliers: bool = False, outliers_mul: int = 2):
    """Return list of FileInfo objects for given paths. Optionally detect outliers based on size."""
    if not paths:
        return []
    metas = []

    @lru_cache
    def _list_path(path):
        try:
            return niofs_head_object(path, client=client)
        except:  # noqa: E722
            logger.error("Failed to get file info: %s", path)
            return None

    averager = init_averager()
    for path in paths:
        path_meta = [_list_path(p) for p in path]
        if path_meta[0] is None:
            continue
        # If size is much more than running mean - dont include, log warning
        # Keep running mean of sizes
        if detect_outliers:
            if path_meta[0].size > averager(path_meta[0].size) * outliers_mul:
                logger.warning("File size outlier detected: %s file size: %i", path_meta[0].path, path_meta[0].size)
                continue
        metas.append(path_meta)
    return metas
