# -*- coding: utf-8 -*-
from collections import defaultdict

import torch


def get_next_action_label(
    sampler,
    next_step_action_tokens,
    dynamic_states_expand,
    dynamic_states,
    raw_label_vocab,
    delta_ts_all,
    soft_label_sigma=0.01,
):
    """Get pred states."""
    vocab = sampler._token_decoder.vocab  # [512,2]
    # next_ego_action = next_step_action_tokens["ego_action"]  # [B*sample_num,1,T_all,512]
    # next_agents_action = next_step_action_tokens["agents_action"]  # [B*sample_num,A,T_all,2]
    ego_states = dynamic_states_expand["ego"]  # [B*sample_num,1,T_all,4]
    # agents_states = dynamic_states_expand["agents"]  # [B*sample_num,A,T_all,5]
    # bs = ego_states.shape[0]
    t_all = ego_states.shape[2]

    delta_ts_all_diff = torch.diff(delta_ts_all, dim=-1)  # [B,T_all-1]
    # delta_ts_all_diff_last = delta_ts_all[..., -1]  # [B]
    # delta_ts_all_diff = torch.cat([delta_ts_all_diff, delta_ts_all_diff_last.unsqueeze(-1)], dim=-1)  # [B,T_all]
    bs = delta_ts_all_diff.shape[0]
    bs_sample = ego_states.shape[0]
    sample_num = bs_sample // bs
    delta_ts_all_diff_expand = (
        delta_ts_all_diff[:, None, :].expand(-1, sample_num, -1).reshape(bs * sample_num, 1, t_all - 1)
    )  # [B*sample_num,1,T_all]

    ego_vel = ego_states[:, :, :, 3]  # [B*sample_num,1,T_all]
    ego_yaw = ego_states[:, :, :, 2]  # [B*sample_num,1,T_all]
    ego_acc = (ego_vel[..., 1:] - ego_vel[..., :-1]) / delta_ts_all_diff_expand  # [B*sample_num,1,T_all-1]
    delta_yaw = (
        torch.remainder(ego_yaw[..., 1:] - ego_yaw[..., :-1] + torch.pi, 2 * torch.pi) - torch.pi
    )  # [B*sample_num,1,T_all-1]
    yaw_rate = delta_yaw / delta_ts_all_diff_expand  # [B*sample_num,1,T_all-1]
    acc_range = sampler._token_decoder.acc_range
    yaw_rate_range = sampler._token_decoder.yaw_rate_range
    ego_acc_norm = (ego_acc - acc_range[0]) / (acc_range[1] - acc_range[0])  # [B*sample_num,1,T_all-1]
    yaw_rate_norm = (yaw_rate - yaw_rate_range[0]) / (yaw_rate_range[1] - yaw_rate_range[0])  # [B*sample_num,1,T_all-1]
    action = torch.cat([ego_acc_norm[..., None], yaw_rate_norm[..., None]], dim=-1)  # [B*sample_num,1,T_all-1,2]
    vocab = vocab.unsqueeze(0).unsqueeze(-2).expand(bs_sample, -1, t_all - 1, -1).cuda()  # [B*sample_num,512,T_all-1,2]
    action_dist_to_center = torch.norm(action - vocab, dim=-1)  # [B*sample_num,512,T_all-1]
    action_label = torch.argmin(action_dist_to_center, dim=1)  # [B*sample_num,T_all-1]

    # Gaussian kernel: exp(-d^2 / (2 * sigma^2))
    # sigma越大，越soft
    soft_labels = torch.exp(-(action_dist_to_center**2) / (2 * soft_label_sigma**2))
    # Normalize to sum to 1 across each row (each timestep)
    soft_labels /= torch.sum(soft_labels, axis=1, keepdims=True) + 1e-8

    # raw_label_vocab = raw_label_vocab.unsqueeze(1).expand(-1, 5, -1).reshape(bs, -1)
    # action_label_fut = action_label[:, 14:]
    # torch.where(action_label_fut.int() != raw_label_vocab.int())

    # ego_states_raw = dynamic_states["ego"]
    # agents_states_raw = dynamic_states["agents"]

    return action_label, soft_labels


def get_topk_best_states(sampler, action_tokens, dynamic_states, model_inputs, topk):
    """
    Get top-k predictions and find the best action and states.

    Args:
        action_tokens (dict): Dictionary containing ego_action and agents_action.
        dynamic_states (dict): Dictionary containing dynamic states of ego and agents.
        topk (int): Number of top actions to consider.

    Returns:
        tuple: (ego_best_pred_states, agents_best_pred_states)
              - ego_best_pred_states: shape [B,1,T_future,4]
              - agents_best_pred_states: shape [B,A,T_future,5]
    """
    # 1.1 Get topk action, Decode topk ego action to states
    ego_action = action_tokens["ego_action"]  # [B,1,T_all,512]
    agent_action_values = action_tokens["agents_action"]  # [B,A,T_all,2]
    topk_ego_action_values, topk_ego_action_indices = torch.topk(ego_action, k=topk, dim=-1)
    # topk_agents_action_values, topk_agents_action_indices = torch.topk(action_tokens["agents_action"], k=topk, dim=-1)

    # gt_action_vocab = model_inputs["ar_ego_action_vocab"]  # [B,t_fut]
    gt_action_vocab_all = model_inputs["ar_ego_action_vocab_all"]  # [B,t_all-1]
    gt_action = sampler._token_decoder.vocab.float().cuda()[gt_action_vocab_all.int()]  # [B,t_all-1,2]
    topk_action = sampler._token_decoder.vocab.float().cuda()[topk_ego_action_indices].squeeze(1)  # [B,t_all,topk,2]
    topk_action = topk_action[:, 0:-1]  # [B,t_all-1,topk,2]
    action_dist = torch.norm(topk_action - gt_action.unsqueeze(2), dim=-1)  # [B,t_all-1,topk]
    topk_action_index = torch.argmin(action_dist, dim=-1)  # [B,t_all-1]

    delta_ts_all = model_inputs["delta_timestamp_all"]  # [B,t_all]

    topk_ego_pred_states, agents_pred_states = sampler._token_decoder.finetune_decode(
        topk_ego_action_indices, agent_action_values, dynamic_states, delta_ts_all
    )  # [B,1,T_all,topk,4], [B,A,T_all,topk=1,5]
    # Note: after decode, T_all represent pred state of [1,T+1]

    # 1.2 Select best state
    history_length = 14
    ego_best_pred_states, agents_best_pred_states, ego_best_pred_index = select_best_state(
        topk_ego_pred_states, agents_pred_states, dynamic_states, history_length
    )  # [B,1,T_future,4], [B,A,T_future,5]
    # Note: after select best state, T_future represent pred state of [cur,end-1],cur=history_length
    # check gt states and pred states should be close:
    # dynamic_states['ego'][0,0,17],ego_best_pred_states[0,0,2]
    # dynamic_states['agents'][0,0:5,17,0],agents_best_pred_states[0,0:5,2,0]

    # TODO: Try use action choose best state
    ego_best_pred_index = topk_action_index[:, history_length:].unsqueeze(1)

    topk_ego_action_indices_future = topk_ego_action_indices[..., history_length + 1 :, :]  # [B,1,T_future,topk]
    ego_best_pred_index_expand = ego_best_pred_index.unsqueeze(-1)
    best_ego_action_indices = torch.gather(  # [B,1,T_future]
        topk_ego_action_indices_future, dim=2, index=ego_best_pred_index_expand
    ).squeeze(-1)

    return ego_best_pred_states, agents_best_pred_states, best_ego_action_indices


def get_conditional_expand_states(ego_best_pred_states, agents_best_pred_states, dynamic_states, history_lenth=14):
    """Conditional next step pred.

    Return [B*1,T_future,T_all,4], [B,A,T_future,T_all,5]
    """
    # ego_best_pred_states [B,1,T_future,4]
    # agents_best_pred_states [B,A,T_future,5]
    # # T_future represent pred state of [cur,end-1],cur=history_length
    ego_all_state = dynamic_states["ego"]  # [B,1,T_all,4] (x,y,yaw,vel)
    agents_all_state = dynamic_states["agents"]  # [B,A,T_all,5] (x,y,l,w,h)

    t_fut = ego_best_pred_states.shape[2]
    t_all = ego_all_state.shape[2]
    bs = ego_all_state.shape[0]
    agent_num = agents_all_state.shape[1]
    # ego_feat_dim = ego_all_state.shape[-1]
    agents_feat_dim = agents_all_state.shape[-1]

    ego_all_state_expand = ego_all_state.expand(-1, t_fut, -1, -1)  # [B*1,T_future,T_all,4]
    agents_all_state_expand = agents_all_state.reshape(-1, 1, t_all, agents_feat_dim).expand(
        -1, t_fut, -1, -1
    )  # [B*A,T_future,T_all,5]

    fut_t_index = torch.arange(t_fut).cuda()  # [T_future], value range:[0,T_futre-1]
    fut_t_index_onehot = torch.nn.functional.one_hot(fut_t_index, num_classes=t_fut)  # [T_future,T_future]
    fut_t_index_onehot = fut_t_index_onehot.reshape(1, t_fut, t_fut, 1).expand(
        bs, -1, -1, -1
    )  # [B,T_future,T_future,1], take it as feature mask
    agents_fut_t_index_onehot = (
        fut_t_index_onehot.unsqueeze(1).expand(-1, agent_num, -1, -1, -1).reshape(-1, t_fut, t_fut, 1)
    )  # [B*A,T_future,T_future,1]

    ego_all_state_expand_last = ego_all_state_expand[:, :, -1:, :]  # [B*1,T_future,1,4]
    ego_all_state_expand_future = ego_all_state_expand[:, :, history_lenth:-1, :]  # [B*1,T_future,T_f,4]
    ego_all_state_expand_history = ego_all_state_expand[:, :, :history_lenth, :]  # [B*1,T_future,T_h,4]
    ego_best_pred_states_expand = ego_best_pred_states.expand(-1, t_fut, -1, -1)  # [B*1,T_future,T_f,4]
    ego_all_state_expand_future = (
        ego_best_pred_states_expand * fut_t_index_onehot
        + ego_all_state_expand_future * torch.logical_not(fut_t_index_onehot)
    )  # [B*1,T_future,T_f,4]
    ego_all_state_expand = torch.cat(
        [ego_all_state_expand_history, ego_all_state_expand_future, ego_all_state_expand_last], dim=2
    )  # [B*1,T_future,T_all,4]

    agents_all_state_expand_last = agents_all_state_expand[:, :, -1:, :]  # [B*A,T_future,1,5]
    agents_all_state_expand_future = agents_all_state_expand[:, :, history_lenth:-1, :]  # [B*A,T_future,T_f,5]
    agents_all_state_expand_history = agents_all_state_expand[:, :, :history_lenth, :]  # [B*A,T_future,T_h,5]
    agents_best_pred_states_expand = agents_best_pred_states.reshape(-1, 1, t_fut, agents_feat_dim).expand(
        -1, t_fut, -1, -1
    )  # [B*A,T_future,T_future,5]
    agents_all_state_expand_future = (
        agents_best_pred_states_expand * agents_fut_t_index_onehot
        + agents_all_state_expand_future * torch.logical_not(agents_fut_t_index_onehot)
    )  # [B*A,T_future,T_f,5]
    agents_all_state_expand = torch.cat(
        [agents_all_state_expand_history, agents_all_state_expand_future, agents_all_state_expand_last], dim=2
    ).reshape(
        bs, agent_num, t_fut, t_all, -1
    )  # [B,A,T_future,T_all,5]
    return ego_all_state_expand, agents_all_state_expand


def sample_from_expand_states(ego_all_state_expand, agents_all_state_expand, dynamic_states, sample_num):
    """Sample from expand states."""
    bs, t_fut, t_all, ego_state_dim = ego_all_state_expand.shape
    _, agent_num, _, agent_state_dim = dynamic_states["agents"].shape
    # T_future represent pred state of [cur,end-1],cur=history_length

    # NOTE: here t_fut represent pred state of [cur,end-1],cur=history_length
    sampled_future_step = (  # sample from 0 represent label from 1, so label \in [cur+1,end]
        torch.randint(0, t_fut, (sample_num,)).reshape(1, -1, 1, 1).expand(bs, -1, t_all, 1).cuda()
    )
    ego_sampled_future_step = sampled_future_step.expand(-1, -1, -1, ego_state_dim)  # [B,sample_num,T_all,4]
    agents_sampled_future_step = (sampled_future_step.unsqueeze(1).expand(-1, agent_num, -1, -1, -1)).expand(
        -1, -1, -1, -1, agent_state_dim
    )  # [B*A,sample_num,T_all,5]
    ego_all_state_sampled = torch.gather(ego_all_state_expand, dim=1, index=ego_sampled_future_step).reshape(
        bs * sample_num, 1, t_all, -1
    )  # [B*sample_num,1,T_all,4]
    agents_all_state_sampled = (
        torch.gather(agents_all_state_expand, dim=2, index=agents_sampled_future_step)
        .transpose(1, 2)
        .reshape(bs * sample_num, agent_num, t_all, -1)
    )  # [B*sample_num,A,T_all,5]
    return ego_all_state_sampled, agents_all_state_sampled, sampled_future_step


def pred_next_step_action(
    ego_all_state_sampled,
    agents_all_state_sampled,
    dynamic_state_tokenizer,
    static_scene_tokens,
    action_model,
    bs,
    sample_num,
):
    """Pred next step action."""
    dynamic_states_expand = {
        "ego": ego_all_state_sampled,  # [B*sample_num,1,T_all,4]
        "agents": agents_all_state_sampled,  # [B*sample_num,A,T_all,5]
    }
    dynamic_state_tokens_expand = dynamic_state_tokenizer(dynamic_states_expand)
    static_scene_tokens_expand = defaultdict(dict)
    for static_type_name, static_type_value in static_scene_tokens.items():
        static_scene_tokens_expand[static_type_name] = {}
        for token_name, token_value in static_type_value.items():
            feat_dim = token_value.shape[1:]
            static_scene_tokens_expand[static_type_name][token_name] = (
                token_value.unsqueeze(1).expand(bs, sample_num, *feat_dim).reshape(bs * sample_num, *feat_dim)
            )  # token_value.expand(bs*sample_num, -1, -1)

    next_step_action_tokens = action_model(static_scene_tokens_expand, dynamic_state_tokens_expand)
    # ego_action [B*sample_num,1,T_all,512], agents_action [B*sample_num,A,T_all,2]
    return next_step_action_tokens, dynamic_states_expand


def select_best_state(topk_ego_pred_states, agents_pred_states, dynamic_states, history_lenth=14):
    """Select best state."""
    # topk_ego_pred_states [B,1,T_all,topk,4]
    # agents_pred_states [B,A,T_all,topk=1,5]
    # T_all represent pred state of [1,T+1]

    ego_all_state = dynamic_states["ego"]  # [B,1,T_all,4] (x,y,yaw,vel)
    # agents_all_state = dynamic_states["agents"]  # [B,A,T_all,5] (x,y,l,w,h)
    ego_state_dim = ego_all_state.shape[-1]

    topk_ego_pred_states = topk_ego_pred_states[:, :, history_lenth:-1, ...]  # [B,1,T_future,topk,4]
    agents_pred_states = agents_pred_states[:, :, history_lenth:-1, ...]  # [B,A,T_future,topk=1,5]
    # T_future represent raw [cur+1,end]

    ego_future_state = ego_all_state[:, :, history_lenth + 1 :, ...]  # [B,1,T_future,4]
    # agents_future_state = agents_all_state[:, :, history_lenth + 1 :, ...]  # [B,A,T_future,5]

    ego_future_state_norm = ego_future_state.clone()
    ego_future_state_norm[..., 0] = (ego_future_state[..., 0] - (-50)) / (150 + 50)
    ego_future_state_norm[..., 1] = (ego_future_state[..., 1] - (-20)) / (20 + 20)
    ego_future_state_norm[..., 2] = (ego_future_state[..., 2] - (-torch.pi)) / (2 * torch.pi)
    ego_future_state_norm[..., 3] = (ego_future_state[..., 3] - (0)) / (3 + 0)

    topk_ego_pred_states_norm = topk_ego_pred_states.clone()
    topk_ego_pred_states_norm[..., 0] = (topk_ego_pred_states[..., 0] - (-50)) / (150 + 50)
    topk_ego_pred_states_norm[..., 1] = (topk_ego_pred_states[..., 1] - (-20)) / (20 + 20)
    topk_ego_pred_states_norm[..., 2] = (topk_ego_pred_states[..., 2] - (-torch.pi / 4)) / (2 * torch.pi / 4)
    topk_ego_pred_states_norm[..., 3] = (topk_ego_pred_states[..., 3] - (0)) / (3 + 0)

    topk_ego_pred_error = (
        ego_future_state_norm[:, :, :, None] - topk_ego_pred_states_norm[:, :, :, :]
    ) * 1000  # [B,1,T_future,topk,4]

    # topk_ego_pred_error = torch.norm(
    #     ego_future_state[:, :, :, None, 2:4] - topk_ego_pred_states[:, :, :, :, 2:4], dim=-1
    # )  # [B,1,T_future,topk]
    # topk_agents_pred_error = torch.norm(
    #     agents_future_state[:, :, :, None, 0:2] - agents_pred_states[:, :, :, :, 0:2], dim=-1
    # )  # [B,A,T_future,topk]

    topk_ego_pred_error_norm = torch.norm(topk_ego_pred_error[..., 2:4], dim=-1)  # [B,1,T_future,topk]
    ego_best_pred_index = torch.argmin(topk_ego_pred_error_norm, dim=-1)  # [B,1,T_future]

    # Use gather for more efficient indexing
    ego_best_pred = torch.gather(
        topk_ego_pred_states,
        dim=3,
        index=ego_best_pred_index.unsqueeze(-1).unsqueeze(-1).expand(-1, -1, -1, -1, ego_state_dim),
    ).squeeze(
        -2
    )  # [B,1,T_future,4]

    # check
    # 看 topk_ego_pred_error[0,0,0:5] 可以找最小值，即为最佳预测

    agents_best_pred = agents_pred_states[:, :, :, 0, :]  # [B,A,T_future,5]
    return ego_best_pred, agents_best_pred, ego_best_pred_index  # [B,1,T_future,4], [B,A,T_future,5], [B,1,T_future]


def conditional_pred_next_step(
    dynamic_state_tokenizer,
    static_scene_tokens,
    action_model,
    ego_best_pred_states,
    agents_best_pred_states,
    dynamic_states,
    sample_num,
):
    """Condition on cur pred results, pred next step action."""
    # 2.1 Expand states condition on best pred states
    ego_all_state_expand, agents_all_state_expand = get_conditional_expand_states(
        ego_best_pred_states, agents_best_pred_states, dynamic_states
    )  # [B*1,T_future,T_all,4], [B,A,T_future,T_all,5]
    # # T_future represent pred state of [cur,end-1],cur=history_length
    # check expand states:
    # ego_all_state_expand[0,2,17] ≈ dynamic_states['ego'][0,0,17]
    # ego_all_state_expand[0,2,18] = dynamic_states['ego'][0,0,18]
    # agents_all_state_expand[0,0:5,2,17,0] ≈ dynamic_states['agents'][0,0:5,17,0]
    # agents_all_state_expand[0,0:5,2,18,0] ≈ dynamic_states['agents'][0,0:5,18,0]
    bs, t_fut, t_all, ego_state_dim = ego_all_state_expand.shape

    # 2.2 Sample from expand states
    ego_all_state_sampled, agents_all_state_sampled, sampled_future_step = sample_from_expand_states(
        ego_all_state_expand, agents_all_state_expand, dynamic_states, sample_num
    )  # [B*sample_num,1,T_all,4], [B*sample_num,A,T_all,5]
    # check sample from expand states:
    # sample_index = sampled_future_step[0,0,0]; all_index = 15+sample_index
    # ego_all_state_sampled[0,0,all_index] == ego_all_state_expand[0,sample_index,all_index]

    # 2.3 Pred next step action
    next_step_action_tokens, dynamic_states_expand = pred_next_step_action(
        ego_all_state_sampled,
        agents_all_state_sampled,
        dynamic_state_tokenizer,
        static_scene_tokens,
        action_model,
        bs,
        sample_num,
    )
    return next_step_action_tokens, dynamic_states_expand, sampled_future_step
