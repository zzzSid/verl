# -*- coding: utf-8 -*-

import os

import matplotlib.lines as mlines
import matplotlib.pyplot as plt
import torch


def get_agents_delta_xy_gt(model_inputs, history_num):
    """Get agents delta xy gt."""
    agents_states_gt = model_inputs["ar_agents_state"]  # [B,A,T_all,7]
    agents_xy = agents_states_gt[:, :, history_num:, :2]
    agents_delta_xy_gt = agents_xy[:, :, 1:, :] - agents_xy[:, :, :-1, :]  # [B,A,T_fut,2]
    gt_invalid_frame_mask = (torch.abs(agents_states_gt[:, :, history_num:, :]) < 1e-6).all(-1)
    # agents_valid_mask = ~gt_invalid_frame_mask[:, :, 1:]  # [B,A,T_fut]
    gt_invalid_mask = gt_invalid_frame_mask[:, :, 1:] | gt_invalid_frame_mask[:, :, :-1]
    gt_valid_mask = ~gt_invalid_mask  # [B,A,T_fut]
    agents_delta_xy_gt = agents_delta_xy_gt * gt_valid_mask.unsqueeze(-1) + gt_invalid_mask.unsqueeze(-1) * -1e3
    return agents_delta_xy_gt


def debug_close_loop_forward(
    model_inputs,
    dynamic_states,
    sample_id: int = 0,
    save_path: str = "save_debug",
    x_lim: tuple = (-40, 100),  # 横向 X: -50~150 m  (200 m 宽)
    y_lim: tuple = (-40, 40),  # 纵向 Y: -50~50 m   (100 m 高)
    base_height: float = 8.0,  # 画布高 (in) —— 宽 = base_height * 2
):
    """
    前向闭环调试 + 轨迹可视化（固定坐标系 & 等比例).

    - X 轴: -50~150 m；Y 轴: -50~50 m
    - 横纵向比例尺一致；图幅默认为 16×8 inch，400 dpi
    """
    os.makedirs(save_path, exist_ok=True)

    # ---------- 数据裁剪（与原逻辑一致） ----------
    hist = 15
    t_pred = dynamic_states["ego"].size(2) - hist

    ego_pred = dynamic_states["ego"][:, :, hist:, :2]
    ego_gt = model_inputs["ar_ego_state"][:, :, hist : hist + t_pred, :2]

    agents_pred = dynamic_states["agents"][:, :, hist:, :2]
    agents_gt = model_inputs["ar_agents_state"][:, :, hist : hist + t_pred, :2]
    agents_mask = (agents_gt < 1e-6).all(dim=-1)

    # =============== 可视化 ====================
    b = sample_id
    ego_gt_xy = ego_gt[b, 0].detach().cpu().numpy()
    ego_pred_xy = ego_pred[b, 0].detach().cpu().numpy()

    agent_num = agents_gt.shape[1]

    # ---------- Matplotlib 全局设置 ----------
    plt.rcParams.update(
        {
            "figure.dpi": 500,
            "savefig.dpi": 500,
            "font.size": 16,
            "axes.linewidth": 1.4,
        }
    )
    fig_w = base_height * 2  # 宽:高 = 2:1
    fig_h = base_height
    fig, ax = plt.subplots(figsize=(fig_w, fig_h))

    ax.set_aspect("equal", adjustable="box")
    ax.set_xlim(*x_lim)
    ax.set_ylim(*y_lim)
    ax.set_title("Trajectory Prediction vs. Ground Truth", fontweight="bold", fontsize=20)

    # ---------- 车道线 ------------------------
    lanes = model_inputs["lane_points"][b]  # [L,50,2]
    mask_l = model_inputs["lane_types"][b] == -1  # [L,50]
    for pts, m in zip(lanes, mask_l):
        valid = ~m
        pts = pts[valid].detach().cpu().numpy()
        if pts.shape[0] > 1:
            ax.plot(pts[:, 0], pts[:, 1], color="lightgray", linewidth=1.0, zorder=0)

    # ---------- Ego 轨迹 ----------------------
    (line_ego_gt,) = ax.plot(
        ego_gt_xy[:, 0], ego_gt_xy[:, 1], color="royalblue", linewidth=3.2, label="Ego GT", zorder=3
    )
    (line_ego_pred,) = ax.plot(
        ego_pred_xy[:, 0], ego_pred_xy[:, 1], color="navy", linewidth=2.0, linestyle="--", label="Ego Pred", zorder=4
    )

    # ---------- Agents 轨迹 -------------------
    for a in range(agent_num):
        valid = ~agents_mask[b, a].detach().cpu().numpy()
        if valid.sum() <= 1:
            continue
        ag_gt = agents_gt[b, a].detach().cpu().numpy()[valid]
        ag_pred = agents_pred[b, a].detach().cpu().numpy()[valid]

        ax.plot(ag_gt[:, 0], ag_gt[:, 1], color="orangered", linewidth=1.8, alpha=0.35, zorder=1)
        ax.plot(ag_pred[:, 0], ag_pred[:, 1], color="firebrick", linewidth=1.2, alpha=0.35, linestyle="--", zorder=1)

    # ---------- Legend ------------------------
    agent_gt_h = mlines.Line2D([], [], color="orangered", linewidth=2.5, label="Agent GT")
    agent_pred_h = mlines.Line2D([], [], color="firebrick", linestyle="--", linewidth=2.0, label="Agent Pred")
    ax.legend(
        handles=[line_ego_gt, line_ego_pred, agent_gt_h, agent_pred_h], loc="upper right", framealpha=0.9, fontsize=14
    )

    # ---------- 细节 --------------------------
    ax.set_xlabel("X (m)")
    ax.set_ylabel("Y (m)")
    ax.grid(alpha=0.25, linestyle=":", linewidth=0.8)

    fig.tight_layout()
    fig.savefig(os.path.join(save_path, "ego_agent_trajectories.png"), bbox_inches="tight")
    plt.close(fig)
