# -*- coding: utf-8 -*-
"""Utility functions for experiments package."""
import os
from enum import Enum
from typing import Optional

import torch
import torch.backends
import torch.distributed as dist
import torchpilot

from tpp_onemodel.utils.constant_utils import get_env_or_constant
from tpp_onemodel.utils.constant_utils import load_constants


logger = torchpilot.logger


class LidarInferMode(Enum):
    """Enum for the lidar inference mode."""

    TRACE = "trace"
    TORCH = "torch"

    def __str__(self):
        """Return the string representation of the enum."""
        return self.name


# Environment variable constants
LIDAR_INFER_MODE = "LIDAR_INFER_MODE"
WORLD_SIZE = "WORLD_SIZE"


def configure_torch_backend(infer_mode: Optional[LidarInferMode] = None) -> None:
    """Configure torch backend."""
    if infer_mode is not None:
        consts = load_constants("tpp_onemodel.utils.experiments_utils")
        infer_mode = str(  # type: ignore
            LidarInferMode(get_env_or_constant(constants=consts, attr=LIDAR_INFER_MODE, default=LidarInferMode.TORCH))  # type: ignore
        )

    try:
        world_size = dist.get_world_size()
        os.environ[WORLD_SIZE] = str(world_size)
        logger.info("Num GPUs reported: %s", world_size)
    except RuntimeError:
        logger.info("Process group is not initialized.")

    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    torch.use_deterministic_algorithms(True)  # type: ignore
    torch.backends.cudnn.allow_tf32 = True  # type: ignore
    torch.backends.cuda.matmul.allow_tf32 = True
    if infer_mode == LidarInferMode.TRACE:
        torch.backends.cudnn.enabled = False
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False  # type: ignore
    logger.warning(
        "torch.backends.cuda.matmul.allow_tf32: %s",
        str(torch.backends.cuda.matmul.allow_tf32),
    )
    logger.warning("torch.backends.cudnn.allow_tf32: %s", str(torch.backends.cudnn.allow_tf32))  # type: ignore
