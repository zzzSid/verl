import math
import numpy as np


class ReferenceLine:
    MAX_T = 5.0
    MAX_V = 8.0
    ACC_ASSUMPTION = 1.0
    LENGTH = 300.0
    LENGTH_RATIO = 0.1
    DISTANCE_THRESHOLD = 0.1

    def __init__(self, localization_points, ego_speed):
        self.ego_speed = ego_speed
        self.reference_points = []
        self.path_points = []
        self.sample_path_points = []
        self.total_length = 0.0
        self.straight = True
        self.concatenate_drive_path(localization_points)
        self.construct_reference_line()

    def is_valid(self):
        return len(self.reference_points) > 1

    def is_valid_for_model(self):
        if self.total_length < self.get_desired_path_length() or self.total_length < ReferenceLine.LENGTH:
            return False
        if self.check_forward() is False:
            return False
        return True

    def check_forward(self):
        if len(self.path_points) < 2:
            return False
        points_num = len(self.path_points)
        path_vectors = []
        for i in range(1, points_num):
            path_vectors.append(
                [
                    self.path_points[i][0] - self.path_points[i - 1][0],
                    self.path_points[i][1] - self.path_points[i - 1][1],
                ]
            )
        vector_num = len(path_vectors)
        if vector_num < 2:
            return False
        for i in range(0, vector_num - 1):
            v2 = path_vectors[i + 1]
            v1 = path_vectors[i]
            vector_prod = v1[0] * v2[0] + v1[1] * v2[1]
            length_prod = math.sqrt(pow(v1[0], 2) + pow(v1[1], 2)) * math.sqrt(pow(v2[0], 2) + pow(v2[1], 2))
            cos_theta = vector_prod * 1.0 / (length_prod * 1.0 + 1e-6)
            angle_radian = math.acos(cos_theta)
            if angle_radian > 1.571:  # 90 degree
                return False
        return True

    def get_length(self):
        return self.total_length

    def get_desired_path_length(self):
        if self.ego_speed > ReferenceLine.MAX_V:
            return self.ego_speed * ReferenceLine.MAX_T
        t_acc = (ReferenceLine.MAX_V - self.ego_speed) / ReferenceLine.ACC_ASSUMPTION
        desired_length = (
            self.ego_speed * t_acc
            + ReferenceLine.ACC_ASSUMPTION * t_acc * t_acc / 2.0
            + ReferenceLine.MAX_V * max(0, ReferenceLine.MAX_T - t_acc)
        )
        return desired_length

    def get_path_points(self):
        return self.path_points

    def get_equally_spaced_path_points(self):
        path_points = []
        for s in range(0, int(ReferenceLine.LENGTH)):
            x, y = self.sltoxy(s, 0)
            path_points.append([x, y])
        return path_points

    def is_straight(self):
        if self.is_valid() is False:
            return False
        if self.straight:
            return True
        return False

    def concatenate_drive_path(self, localization_points):
        if len(localization_points) < 2:
            return
        pre_x = localization_points[0][0]
        pre_y = localization_points[0][1]
        self.path_points.append([pre_x, pre_y])
        for points in localization_points:
            distance_sqaure = pow(points[0] - pre_x, 2) + pow(points[1] - pre_y, 2)
            if distance_sqaure < 1.0:
                continue
            pre_x, pre_y = points[0], points[1]
            self.total_length += math.sqrt(distance_sqaure)
            self.path_points.append([points[0], points[1]])
            if self.total_length > self.LENGTH:
                break

        points_num = len(self.path_points)
        vectors = []
        for i in range(0, points_num // 2 - 5, 5):
            vectors.append(
                [
                    self.path_points[i + 5][0] - self.path_points[i][0],
                    self.path_points[i + 5][1] - self.path_points[i][1],
                ]
            )
        vector_num = len(vectors)
        if vector_num > 2:
            theta_diff = []
            for i in range(0, vector_num - 1):
                v2 = vectors[i + 1]
                v1 = vectors[i]
                vector_prod = v1[0] * v2[0] + v1[1] * v2[1]
                length_prod = math.sqrt(pow(v1[0], 2) + pow(v1[1], 2)) * math.sqrt(pow(v2[0], 2) + pow(v2[1], 2))
                cos_theta = vector_prod * 1.0 / (length_prod * 1.0 + 1e-6)
                clamped_cos_value = np.clip(cos_theta, -1.0, 1.0)
                angle_radian = math.acos(clamped_cos_value)
                theta_diff.append(angle_radian)
            for angle_diff in theta_diff:
                if angle_diff > 0.15:  # 8.6 degree
                    self.straight = False
                    break

        indexes = []
        indexes.append(0)
        indexes.append(points_num - 1)
        range_list = []
        range_list.append([0, points_num - 1])

        far_index = 0
        while range_list:
            check_range = range_list.pop()
            far_index = self.SearchFarIndex(self.path_points, check_range[0], check_range[1])
            if far_index is not None:
                indexes.append(far_index)
                range_list.append([check_range[0], far_index])
                range_list.append([far_index, check_range[1]])
        indexes.sort()
        for index in indexes:
            self.sample_path_points.append(self.path_points[index])

    def SearchFarIndex(self, path_points, start_index, end_index):
        if start_index + 1 >= end_index:
            return None

        dx = path_points[end_index][0] - path_points[start_index][0]
        dy = path_points[end_index][1] - path_points[start_index][1]
        angle = math.atan2(dy, dx)
        length = math.hypot(dx, dy)
        cos_angle = math.cos(angle)
        sin_angle = math.sin(angle)

        far_distance = 0
        res = start_index
        for index in range(start_index + 1, end_index):
            dx = path_points[index][0] - path_points[start_index][0]
            dy = path_points[index][1] - path_points[start_index][1]
            distance = abs(dx * sin_angle - dy * cos_angle)
            if distance > far_distance:
                far_distance = distance
                res = index

        if far_distance > min(ReferenceLine.DISTANCE_THRESHOLD, ReferenceLine.LENGTH_RATIO * length):
            return res

        return None

    def construct_reference_line(self):
        points_num = len(self.sample_path_points)
        for i in range(points_num - 1):
            dx = self.sample_path_points[i + 1][0] - self.sample_path_points[i][0]
            dy = self.sample_path_points[i + 1][1] - self.sample_path_points[i][1]
            seg_length = math.sqrt(dx * dx + dy * dy)
            math.atan2(dy, dx)
            self.reference_points.append(
                [
                    self.sample_path_points[i][0],
                    self.sample_path_points[i][1],
                    math.cos(math.atan2(dy, dx)),
                    math.sin(math.atan2(dy, dx)),
                    seg_length,
                ]
            )
        if points_num >= 2:
            self.reference_points.append(
                [
                    self.sample_path_points[points_num - 1][0],
                    self.sample_path_points[points_num - 1][1],
                    self.reference_points[points_num - 2][2],
                    self.reference_points[points_num - 2][3],
                    0,
                ]
            )
            self.reference_points[0].append(0)
        for i in range(1, points_num):
            self.reference_points[i].append(self.reference_points[i - 1][4] + self.reference_points[i - 1][5])

    def xytosl(self, x, y):
        if self.is_valid() is False:
            return None, None
        reference_points_num = len(self.reference_points)
        near_index = 1e5
        near_distance = 1e3
        distance = 0
        for i in range(reference_points_num - 1):
            dx = x - self.reference_points[i][0]
            dy = y - self.reference_points[i][1]
            project = dx * self.reference_points[i][2] + dy * self.reference_points[i][3]
            if project <= 0:
                distance = dx * dx + dy * dy
            elif project >= self.reference_points[i][4]:
                distance = pow(x - self.reference_points[i + 1][0], 2) + pow(y - self.reference_points[i + 1][1], 2)
            else:
                product = -dx * self.reference_points[i][3] + dy * self.reference_points[i][2]
                distance = pow(product, 2)

            if distance < near_distance:
                near_distance = distance
                near_index = i
        if near_index > reference_points_num - 1:
            return None, None
        near_distance = math.sqrt(near_distance)
        dx = x - self.reference_points[near_index][0]
        dy = y - self.reference_points[near_index][1]
        project = dx * self.reference_points[near_index][2] + dy * self.reference_points[near_index][3]
        product = -dx * self.reference_points[near_index][3] + dy * self.reference_points[near_index][2]

        s, d = 0, 0
        if reference_points_num == 2:
            s, d = self.reference_points[near_index][5] + project, product
        elif near_index == 0:
            s = self.reference_points[near_index][5] + min(project, self.reference_points[near_index][4])
            if project < 0:
                d = product
            else:
                # sign = 1 if product > 0 else -1
                # d = sign * near_distance
                d = near_distance if product > 0 else -near_distance
        elif near_index + 2 == reference_points_num:
            s = self.reference_points[near_index][5] + max(0, project)
            if project > 0:
                d = product
            else:
                # sign = 1 if product > 0 else -1
                # d = sign * near_distance
                d = near_distance if product > 0 else -near_distance
        else:
            length = self.reference_points[near_index][4]
            s = self.reference_points[near_index][5] + max(0, min(project, length))
            # sign = 1 if product > 0 else -1
            # d = sign * near_distance
            d = near_distance if product > 0 else -near_distance
        return s, d

    def find_near_segment_by_s(self, s):
        left = 0
        right = len(self.reference_points) - 2
        near_index = 0
        while left + 1 < right:
            near_index = (left + right) // 2
            if self.reference_points[near_index][5] > s:
                right = near_index - 1
            else:
                left = near_index
        near_index = left if self.reference_points[right][5] > s else right
        return near_index

    def sltoxy(self, s, d):
        reference_points_num = len(self.reference_points)
        if reference_points_num < 2:
            return None, None
        near_index = self.find_near_segment_by_s(s)
        delta_s = s - self.reference_points[near_index][5]
        x = (
            self.reference_points[near_index][0]
            + delta_s * self.reference_points[near_index][2]
            - d * self.reference_points[near_index][3]
        )
        y = (
            self.reference_points[near_index][1]
            + delta_s * self.reference_points[near_index][3]
            + d * self.reference_points[near_index][2]
        )
        return x, y
