# -*- coding: utf-8 -*-
# All constants should be UPPERCASED for proper discovery
import typing as tp

from tpp_onemodel.utils.params_utils import Params  # type: ignore[attr-defined]


class TGMConstants(Params):
    TGM_LOSS_CLASS: str = "PlannerTGMIntegratedLoss"
    TGM_POS_LOSS_CLASS: str = "PlannerTGMPositionLoss"
    TGM_SPEED_LOSS_CLASS: str = "PlannerTGMSpeedLoss"
    TGM_CUVATURE_LOSS_CLASS: str = "PlannerTGMCurvatureLoss"
    TGM_POS_X_LOSS: str = "pos_x_loss"
    TGM_POS_Y_LOSS: str = "pos_y_loss"
    TGM_Speed_LOSS: str = "speed_loss"
    TGM_CUVATURE_LOSS: str = "kappa_loss"

    # Consts Used For Decoder
    TGM_TRAJ_PRED_CLASS: str = "PlannerTGMTrajecotryPredictor"
    TGM_CLASS: str = "PlannerTGMDecoder"

    NUM_TOP_SCENES: int = 6
    NUM_TOP_EGO_TRAJ: int = 1

    BOX_SIZE_INDICES: tp.Tuple[int, ...] = (3, 5)
    BOX_SPEED_INDICES: tp.Tuple[int, ...] = (10, 11)


class PlannerConstants(Params):
    """Constants for planner."""

    tgm_constants: TGMConstants = TGMConstants()

    EPSILON = 1e-6
    MAX_VAL = 5e4

    GT_REMAP: tp.Dict[str, int] = {
        "vehicle_rect": 1,
        "vehicle_rect+car": 1,
        "vehicle_rect+medium_sized_car": 1,
        "vehicle_rect+van": 1,
        "vehicle_rect+engineering_vehicle": 1,
        "vehicle_rect+tricycle": 1,
        "vehicle_rect+pick_up_truck": 1,
        "smallVehicle": 1,  # SVC label
        "tricycle": 1,  # SVC label
        "part_vehicle_rect+pick_up_truck": 1,
        "part_vehicle_rect+car": 1,
        "part_vehicle_rect+engineering_vehicle": 1,
        "part_vehicle_rect+van": 1,
        "part_vehicle_rect": 1,
        "vehicle_rect+truck": 4,
        "vehicle_rect+bus": 4,
        "vehicle_rect+special_shaped_vehicle": 4,
        "vehicle_rect+car7": 4,  # car7 means special_shaped_vehicle
        "part_vehicle_rect+truck": 4,
        "bigVehicle": 4,  # SVC label
        "differentCar": 4,  # SVC label
        "vehicle_rect+two_wheels_high_speed_vehicle": 2,
        "pedestrian_rect+standing": 2,
        "pedestrian_rect+bending": 2,
        "pedestrian_rect": 2,
        "pedestrian": 2,  # SVC label
        "vehicle_rect+motorcycle": 3,
        "vehicle_rect+bicycle": 3,
        "vehicle_rect+eBike": 3,
        "vehicle_rect+ebike": 3,
        "vehicle_rect+two_wheels_low_speed_vehicle": 3,  # lunyi
        "cyclist": 3,  # SVC label
        "cyclist_rect": 3,  # SVC label
        "elecCyclist": 3,  # SVC label
        # others：
        "unknown": 0,
        "4wheels": 1,
        "2/3wheels": 3,
        # "doorCovers": 0,
        "CAR": 1,  # 4D category:
        "PEDESTRIAN": 2,  # 4D category:
        "BIKE": 3,  # 4D category:
        "TRUNK": 4,  # 4D category:
        "unknown_rect": 0,
        "ignore_rect": 0,
    }

    """GT box information  dimension"""
    GT_BOX_DIM: int = 19

    RANDOM_SEED: int = 666

    """xyz,lwh,yaw,vx,vy,acc_x,acc_y,yaw_rate"""
    STATE_DIM: int = 12

    SUBTYPE_REMAP: tp.Dict[str, int] = {
        "car": 0,
        "medium_sized_car": 1,
        "pick_up_truck": 2,
        "van": 3,
        "truck": 4,
        "bus": 5,
        "engineering_vehicle": 6,
        "tricycle": 7,
        "special_shaped_vehicle": 8,
        "pedestrian": 9,
        "motorcycle": 10,
        "bicycle": 11,
        "two_wheels_high_speed_vehicle": 12,
        "two_wheels_low_speed_vehicle": 13,
        "ebike": 14,
    }

    SUBTYPE_TO_SYBTYPE_MAP: tp.Dict[str, str] = {
        "motorcyclist": "motorcycle",
        "bicyclist": "bicycle",
        "two_wheels_high_speed_vehiclist": "two_wheels_high_speed_vehicle",
        "two_wheels_low_speed_vehiclist": "two_wheels_low_speed_vehicle",
        "ebikelist": "ebike",
        "tricyclist": "tricycle",
    }

    MOTION_TYPE_MAPPING: tp.Tuple[tp.Dict[str, int], ...] = (
        {"static": 2000, "moving": 1000},
        {"backing": 200, "non-backing": 100},
        {
            "constant": 10,
            "accelerate": 20,
            "starting": 20,
            "slowing": 30,
            "stopping": 30,
        },
        {
            "straight": 1,
            "right-turn": 2,
            "left-turn": 3,
        },
    )

    """falcon origin DET box: xyz,lwh,yaw,c,vx,vy,motion_state,semantic,semantic_score"""
    ORIGINAL_BOX_FEAT_DIM: int = 40

    # wo god
    BOX_FEAT_DIMS_NO_GOD: tp.Tuple[int, ...] = (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14, 15, 16, 21)
    BOX_EMBED_DIMS_NO_GOD: tp.Tuple[int, ...] = (0, 1, 2, 3, 4, 12, 6, 17)  # xyz, lw, sensor_type, yaw, delta_ts

    SOD_BOX_FEAT_DIMS: tp.Tuple[int, ...] = tuple(range(23))

    BBOXES_TIMESTAMP_IDX: int = 16

    """
        TLD_Panel_ID        0
        Panel3d_Pos         1-3
        Panel_Heading       4
        Panel_Confidence    5
        panel_blocked       6
        panel_blocked_ratio 7
        panel_theta         8
        panel_failure_status   9
        JunctionColor           10-13
        TLD_Junction_Status          14-17
        tld_junction_timer           18-21
        panels_blocked         22-25
        TLD_junction_failure_status  26-29
        TLD_ts              # 30
    """
    TLD_BOX_FEAT_DIMS: tp.Tuple[int, ...] = tuple(range(31))

    """
        x, y, z,  # 0, 1, 2
        l, w, h,  # 3, 4, 5
        heading,  # 6
        object class,  # 7
        object special class,  # 8
        object id,  # 9
        vx, vy,  # 10, 11
        source,  # 12
        ax, ay,  # 13, 14
        angle rate,  # 15
        existence probability,  # 16
        is blocked parts,  # 17
        age second,  # 18
        missing age second,  # 19
        motion state,  # 20
        motion category,  # 21
        motion consistent prob,  # 22
        brake light,  # 23
        left indicator,  # 24
        right indicator,  # 25
        brake light probability,  # 26
        left indicator probability,  # 27
        right indicator probability,  # 28
        [
            lidar_cluster_infos...,  # 29-39
        ]
        delta_ts, # 40 padding later
    """
    BOX_FEAT_DIMS: tp.Tuple[int, ...] = (
        0,  # x
        1,  # y
        2,  # z
        3,  # l
        4,  # w
        5,  # h
        6,  # heading
        7,  # object class
        8,  # object special class
        10,  # vx
        11,  # vy
        12,  # source
        13,  # ax
        14,  # ay
        15,  # angle rate
        17,  # is blocked parts
        18,  # age second
        19,  # missing age second
        20,  # motion state
        23,  # brake light
        24,  # left indicator
        25,  # right indicator
        26,  # brake light probability
        27,  # left indicator probability
        28,  # right indicator probability
    )

    """xyz, lw, sensor_type, yaw, delta_ts"""
    BOX_EMBED_DIMS: tp.Tuple[int, ...] = (0, 1, 2, 3, 4, 13, 6, 25)

    """ original ego feats
    xyz, lwh, yaw, class, whlag, whlagspd, vxvy, acc_x, acc_y, yaw_rate
    """
    EGO_BOX_FEAT_DIMS: tp.Tuple[int, ...] = (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14)

    """
    xy, vxvy, accxaccy, yaw_rate, delta_ts
    """
    EGO_BOX_EMBED_DIMS: tp.Tuple[int, ...] = (0, 1, 10, 11, 12, 13, 14, 15)

    """
    xyz, lw, sensor_type, yaw, delta_ts
    """
    TLD_BOX_EMBED_DIMS: tp.Tuple[int, ...] = (1, 2, 3, 5, 6, 8, 4, 30)

    """
        x, y, 0,  # 0, 1, 2
        l, w, h,  # 3, 4, 5
        heading,  # 6
        type,  # 7
        type probability,  # 8
        object id,  # 9
        existence probability,  # 10
        source,  # 11
        [
            lidar_cluster_infos...,  # 12-22
        ]
    """
    SOD_BOX_EMBED_DIMS: tp.Tuple[int, ...] = (0, 1, 2, 3, 4, 11, 6, 7)

    SENSOR_TYPE_REMAP: tp.Dict[str, int] = {
        "BEV_11C": 0,
        "BEV_S1": 0,
        "falcon": 1,
        "BEV_S3": 2,
    }

    DATA_DISTRIBUTE_MAP: tp.Dict[str, int] = {
        "lidar_query_lidar_key_num": 9,
        "camera_query_lidar_key_num": 9,
        "lidar_sample_step": 1,
        "camera_sample_step": 1,
    }

    BEV_KEY: str = "BEV_S1"

    MAX_SPEED: int = 50
