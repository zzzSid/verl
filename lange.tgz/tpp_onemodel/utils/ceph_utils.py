# -*- coding: utf-8 -*-
"""Ceph utilities."""


def get_path_for_read_cache(full_ceph_path: str) -> str:
    """Get path for read cache op.

    Args:
      full_ceph_path (string): the ceph path with site as prefix.

    Returns:
      ceph path without site prefix.
    """
    index = full_ceph_path.find(":")
    if index == -1:
        return full_ceph_path
    return "/" + full_ceph_path[index + 1 :]
