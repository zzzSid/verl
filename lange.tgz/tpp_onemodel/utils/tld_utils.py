# -*- coding: utf-8 -*-

import torch


k_max_stopline_thw_for_yellow_vtld = 2.0
yellow_light_full_time = 3.0


def enable_stop_by_yellow_light(stopline_thw, stopline_dist, tld_color, tld_blink, tld_countdown):
    """Enable stop by yellow light."""
    enable_by_yellow_vtld = torch.zeros_like(stopline_thw, dtype=torch.bool)
    # Use tensor operations to handle the logic
    condition1 = (tld_color == 2) & (tld_blink == 1)
    tld_countdown = torch.where(tld_color == 2, torch.clamp(tld_countdown, min=0, max=3), tld_countdown)
    condition2 = (tld_color == 2) & (stopline_dist > 0)
    condition3 = stopline_thw + yellow_light_full_time - tld_countdown >= k_max_stopline_thw_for_yellow_vtld

    # Combine conditions
    enable_by_yellow_vtld = torch.where(condition2 & ~condition1, condition3, enable_by_yellow_vtld)

    return enable_by_yellow_vtld


def enable_stop_by_green_light(stopline_thw, stopline_dist, tld_color, tld_blink, tld_countdown):
    """Enable stop by green light."""
    enable_by_green_vtld = torch.zeros_like(stopline_thw, dtype=torch.bool)

    mask_conditions = (tld_color == 3) & (stopline_dist > 0) & (tld_countdown <= 5)
    checker = stopline_thw >= k_max_stopline_thw_for_yellow_vtld + tld_countdown - 1.0

    enable_by_green_vtld = torch.where(mask_conditions, checker, enable_by_green_vtld)

    return enable_by_green_vtld


def enable_stop_by_red_light(stopline_thw, stopline_dist, tld_color, tld_blink, tld_countdown):
    """Enable stop by red light."""
    return (tld_color == 1) & (stopline_dist > 0)


def enable_stop_by_tld(stopline_thw, navi_path_stoppoints_x, tld_color, tld_blink, tld_countdown):
    """Enable stop by tld."""
    enable_by_yellow_vtld = enable_stop_by_yellow_light(
        stopline_thw, navi_path_stoppoints_x, tld_color, tld_blink, tld_countdown
    )
    enable_by_green_vtld = enable_stop_by_green_light(
        stopline_thw, navi_path_stoppoints_x, tld_color, tld_blink, tld_countdown
    )
    enable_by_red_vtld = enable_stop_by_red_light(
        stopline_thw, navi_path_stoppoints_x, tld_color, tld_blink, tld_countdown
    )
    # print("enable_by_yellow_vtld", enable_by_yellow_vtld, "enable_by_green_vtld", enable_by_green_vtld, "enable_by_red_vtld", enable_by_red_vtld)
    return enable_by_yellow_vtld | enable_by_green_vtld | enable_by_red_vtld
