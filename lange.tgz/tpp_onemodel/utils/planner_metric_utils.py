# -*- coding: utf-8 -*-
def sum_nested_dicts(list_of_dicts):
    """
    Merge a list of nested dictionaries with the same structure.

    summing the contents of lists at corresponding positions.

    Parameters:
    list_of_dicts (list): A list containing multiple dictionaries with the same structure.

    Returns:
    dict: The merged dictionary.
    """

    def recursive_sum(dict1, dict2):
        """
        Recursively sum the contents of lists at corresponding positions in two nested dictionaries.

        Parameters:
        dict1 (dict): The first dictionary.
        dict2 (dict): The second dictionary, with the same structure as the first.
        """
        for key in dict1:
            if isinstance(dict1[key], dict) and isinstance(dict2[key], dict):
                # If both values are dictionaries, recurse into them
                recursive_sum(dict1[key], dict2[key])
            elif isinstance(dict1[key], list) and isinstance(dict2[key], list):
                # If both values are lists, sum their elements
                dict1[key] = [x + y for x, y in zip(dict1[key], dict2[key])]

    if not isinstance(list_of_dicts, list):
        return list_of_dicts
    # Initialize the merged result as the first dictionary in the list
    merged_dict = list_of_dicts[0].copy()

    # Iterate through the remaining dictionaries and sum their contents
    for i in range(1, len(list_of_dicts)):
        recursive_sum(merged_dict, list_of_dicts[i])

    return merged_dict
