# -*- coding: utf-8 -*-
"""Torch Cuda Timer."""

# import numpy as np
import torch


class TorchCudaStopwatch:
    """Torch cuda timer."""

    def __init__(self, start=False) -> None:
        """Init."""
        self.start_event = torch.cuda.Event(enable_timing=True)
        self.stop_event = torch.cuda.Event(enable_timing=True)
        self.duration = 0.0
        if start:
            self.tic()

    def tic(self):
        """Start."""
        self.start_event.record()

    def toc(self):
        """Stop."""
        self.stop_event.record()
        torch.cuda.synchronize()
        elapsed_time_second = self.start_event.elapsed_time(self.stop_event) / 1000.0
        return elapsed_time_second

    def toc2(self):
        """Record duration, and Restart the Stopwatch."""
        delta = self.toc()
        self.tic()
        return delta

    def acc(self):
        """Accumulates the duration."""
        delta = self.toc()
        self.duration += delta
        self.tic()
        return delta

    def reset(self):
        """Reset the whole Stopwatch."""
        self.tic()
        self.duration = 0.0
