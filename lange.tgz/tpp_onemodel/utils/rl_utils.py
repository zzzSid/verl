# -*- coding: utf-8 -*-

import math

from tpp_onemodel.model.loss.reward_loss import AgentCollisionReward
from tpp_onemodel.model.loss.reward_loss import LaneCollisionReward
from tpp_onemodel.model.loss.reward_loss import NaviFollowReward
from tpp_onemodel.model.loss.reward_loss import ProgressReward
from tpp_onemodel.model.loss.reward_loss import SmoothReward


def get_default_reward_summary_config():
    """Get defualt summary cfg."""
    summary_cfg = dict(
        dt=0.2,
        rewards_types_cfg=dict(
            agent_collision_reward=dict(
                func=dict(
                    type=AgentCollisionReward,
                ),
                collision_thresh=dict(
                    continuous_len_thresh=5,
                    collision_thresh=0.5,
                ),
                collision_weight_decay=0.92,
                panalty_values=dict(continuous_collision_panalty=-100.0),
            ),
            lane_collision_reward=dict(
                func=dict(
                    type=LaneCollisionReward,
                ),
                collision_thresh=dict(
                    continuous_len_thresh=5,
                    collision_thresh=0.5,
                    cross_solid_continuous_len_thresh=10,
                    cross_solid_thresh=0.5,
                ),
                collision_weight_decay=0.92,
            ),
            navi_follow_reward=dict(
                func=dict(
                    type=NaviFollowReward,
                ),
            ),
            smooth_reward=dict(
                func=dict(
                    type=SmoothReward,
                ),
            ),
            progress_reward=dict(
                func=dict(
                    type=ProgressReward,
                ),
            ),
        ),
        rewards_weights_cfg=dict(
            agent_collision_reward=1.0,
            lane_collision_reward=1.0,
            navi_follow_reward=1.0,
            smooth_reward=1.0,
            progress_reward=1.0,
        ),
    )
    return summary_cfg


def fit_infer_batch_size(datasets, infer_batch_size):
    """Fit infer batch size for each dataset."""
    if infer_batch_size <= 1:
        return 1
    pkl_num = 0
    for d in datasets:
        if isinstance(d, tuple):
            d = d[0]
        if not isinstance(d, str):
            continue
        with open(d, "r") as f:
            pkl_num += len([x.strip() for x in f.readlines() if x.strip()])
    for i in range(infer_batch_size, 1, -1):
        if pkl_num % i == 0:
            return i
    return 1
