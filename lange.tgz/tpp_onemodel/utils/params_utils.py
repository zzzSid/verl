# -*- coding: utf-8 -*-
# type: ignore
"""Parameters definitions and utilities."""
import json
import re
import typing as tp
from collections import abc
from enum import Enum
from inspect import signature
from pathlib import Path
from subprocess import check_call  # noqa: S404
from typing import Any
from typing import Dict
from typing import Optional
from typing import TypeVar

import yaml
from pydantic import BaseModel
from pydantic import root_validator
from torchpilot import logger
from torchpilot.utils.cfg_parser import PyConfig


COMPUTED_FIELDS: Dict[str, Any] = {}

Computed = Optional


def _get_parameters(method, values, property_key):
    """Get parameters for computed method."""
    method_params = signature(method).parameters
    parameter_names = [name for name, param in method_params.items() if param.kind == param.POSITIONAL_OR_KEYWORD]
    parameters = {property: values[property] for property in parameter_names if property != property_key}
    # create the dictionary containing all remaining unnamed/kwarg parameters
    new_kwarg_names = list(filter(lambda key: key not in parameters, values.keys()))
    new_kwargs = {property: values[property] for property in new_kwarg_names if property != property_key}
    # pass in var keyword arguments if function has e.g. **kwargs in signature
    contains_var_keyword_arg = (
        lambda params: len(list(filter(lambda param: param.kind == param.VAR_KEYWORD, params))) > 0
    )
    method_args = dict(new_kwargs, **parameters) if contains_var_keyword_arg(method_params.values()) else parameters
    return method_args


def computed(property_key: str):
    """Make a decorator for computed fields of pydantic v1 BaseModel."""

    def __wrapper(method: classmethod):  # type: ignore
        global COMPUTED_FIELDS
        qualified_class_name = ".".join(method.__qualname__.split(".")[:-1])  # type: ignore

        def compute(cls, values):
            cls.Config.validate_assignment = True
            for prop_key, computed_method in COMPUTED_FIELDS[qualified_class_name].items():
                parameters = _get_parameters(computed_method, values, prop_key)
                values[prop_key] = computed_method(**parameters)
            values[property_key] = COMPUTED_FIELDS[qualified_class_name][property_key](**values)
            return values

        if COMPUTED_FIELDS.get(qualified_class_name) is None:
            COMPUTED_FIELDS[qualified_class_name] = {}
        COMPUTED_FIELDS[qualified_class_name][property_key] = method
        return root_validator(allow_reuse=True)(compute)

    return __wrapper


class SerializeFormat(str, Enum):
    """Serialization format."""

    YAML = "yaml"
    PY = "py"

    def __str__(self) -> str:
        """Represent as string."""
        return self.value


ParamsType = TypeVar("ParamsType", bound="Params")


MUTABLE_TYPES = {list, dict, set}
CFG_CLASS_SUFFIX = "Cfg"
PYTHON_SUFFIX = ".py"

SERIALIZED_PREFIX = "cfg_"
SERIALIZATION_FORMAT = SerializeFormat.PY
SERIALIZE_PY_INDENT = 4
SERIALZE_PY_MSG = f"# -*- coding: utf-8 -*-\n#{'*'*20}Automatically generated file. Do not edit manually!{'*'*20}"


def is_optional_field(field: tp.Any) -> bool:
    """Check if field is optional."""
    return tp.get_origin(field) is tp.Union and type(None) in tp.get_args(field)


def camel_to_snake(string: str) -> str:
    """Convert CamelCase to snake_case.

    Args:
        string: CamelCase string for conversion.

    Returns: snake_case version of string.
    """
    string = re.sub(r"(.)([A-Z][a-z]+)", r"\1_\2", string)
    return re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", string).lower()


class Params(BaseModel):
    class Config:
        """
        Configuration class for pydantic BaseModel.

        Note: this class exists only for forbidding extra arguments.
        """

        extra: str = "forbid"
        validate_assignment = True

    @staticmethod
    def _get_params_dir() -> Path:
        """
        Get directory with params files stored in it.

        If this method implemented, you can use from_parameters_name method to load params by name,
            e.g. MyParams.from_parameters_name("my_example_params").

        Returns: params directory path.
        """
        raise NotImplementedError("_get_params_dir method is not implemented.")

    @classmethod
    def get_params_dir(cls) -> Path:
        """
        Public method for params directory.

        Returns: params directory path.
        """
        return cls._get_params_dir()

    def _finalize(self) -> None:
        """
        Check correctness of initialization and process inputs.

        Returns: None.
        """
        pass

    def _override_default_attributes(self) -> None:
        """
        Override default attributes before finalization.

        Method is private, because it will be redefined in each experiment.
            But syleguide requires docstrings for public methods.

        Returns: None
        """
        pass

    def assign_experiment_attributes(self) -> None:
        """
        Public wrapper on override default attributes method.

        Do not redefine it please.

        Returns: None
        """
        self._override_default_attributes()

    def pre_finalize(self) -> None:
        """
        Share attributes between child classes.

        Returns: None
        """
        pass

    def finalize_recursive(self) -> None:
        """Recursive apply of finalize.

        Returns: None
        """
        for name, attribute_value in self:
            # Recompute if needed
            setattr(self, name, attribute_value)
            # Params
            if isinstance(attribute_value, Params):
                attribute_value.finalize_recursive()
        self._finalize()

    def serialize(self) -> None:
        """
        Serialize Params to params_dir.

        Note: see also _serialize_to_yaml method docstring.

        Returns: None
        """
        serialization_dir = self._get_params_dir()
        serialization_dir.mkdir(exist_ok=True, parents=True)
        snake_class_name = camel_to_snake(self.__class__.__name__)
        if snake_class_name.startswith(SERIALIZED_PREFIX):
            snake_class_name = snake_class_name[len(SERIALIZED_PREFIX) :]
        params_file_path = serialization_dir / (SERIALIZED_PREFIX + snake_class_name + PYTHON_SUFFIX)
        if SERIALIZATION_FORMAT == SerializeFormat.YAML:
            self._serialize_to_yaml(params_file_path)
        elif SERIALIZATION_FORMAT == SerializeFormat.PY:
            self._serialize_to_py(params_file_path)
            self._verify_py_serialize(params_file_path)
            self._format_py_serialization(params_file_path)

    @property
    def non_serializable_types(self) -> tp.Set[str]:
        """Override _non_serializable_types to add non-serializable types."""
        return {cls.__name__ for cls in self._non_serializable_types()}  # type: ignore

    def _non_serializable_types(self) -> tp.Set["Params"]:
        return set()

    def _params_sequence_to_conf_str(self, params_list: tp.Sequence["Params"]) -> str:
        if not all(isinstance(el, Params) for el in params_list):
            # Parameters lists, we dont support mixing Params and other types in lists
            return ""

        val_list = []
        # [dict(field1=value1, ...), dict(field1=value1, ...)]
        for el in params_list:
            if el.__class__.__name__ in self.non_serializable_types:
                continue
            val_list.append(el._fields_to_conf_str() + ",")
        return "[" + "\n".join(val_list) + "]"

    def _serializer_iterator(self, params_only: bool = False) -> tp.Iterator[tp.Tuple[str, tp.Any]]:
        for name, value in self:
            if isinstance(value, Params):
                if value.__class__.__name__ in self.non_serializable_types:
                    continue
                yield name, value
            elif isinstance(value, abc.Sequence) or isinstance(value, abc.MutableSequence):
                if all(isinstance(el, Params) for el in value):
                    if list_val := self._params_sequence_to_conf_str(value):
                        yield name, list_val
                elif not params_only:
                    yield name, value
            else:
                if not params_only:
                    yield name, value

    def _fields_to_conf_str(self) -> str:
        # Form a dict(field1=value1, field2=value2, ...)
        cur_out = []
        ftype: str = self.__class__.__name__
        cur_out.append("dict(")
        if CFG_CLASS_SUFFIX in ftype:
            ftype = ftype[: -len(CFG_CLASS_SUFFIX)]
            cur_out.append(f"{' ' * SERIALIZE_PY_INDENT}type=\"{ftype}\",")
        for name, value in self._serializer_iterator():
            if isinstance(value, str) and not value.startswith("["):
                value = f'"{value}"'
            elif isinstance(value, Params):
                value = getattr(self, name)._fields_to_conf_str()

            cur_out.append(f"{' ' * SERIALIZE_PY_INDENT}{name}={value},")
        cur_out.append(")")
        return "\n".join(cur_out)

    def _to_cfg_str(self) -> str:
        """Convert to serializable string with torchpilot Pyconfig format."""
        out_str: tp.List[str] = []
        for fname, attribute_value in self._serializer_iterator(params_only=True):
            if isinstance(attribute_value, str) and attribute_value.startswith("["):
                # List[Params] serialization
                out_str.append(f"{fname} = {attribute_value}")
            else:
                out_str.append(f"{fname} = {attribute_value._fields_to_conf_str()}")
        return "\n".join(out_str)

    def _py_file_callables(self) -> tp.List[str]:
        """Override to add callables to the front of the serialized file."""
        return []

    def _serialize_to_py(self, path: Path) -> None:
        """Serialize into python file for torchpilot config reading."""
        out_str: tp.List[str] = []
        out_str.append(SERIALZE_PY_MSG)
        out_str.append(self._to_cfg_str())
        to_py_str = "\n".join(out_str)
        # Write to file
        with path.open("w") as file:
            file.write(to_py_str)

    def _verify_py_serialize(self, path: Path) -> None:
        """Verify the serialized python file."""
        try:
            config = PyConfig.fromfile(path)
            logger.info("Successfully verified serialized file: %s", path)
            logger.info("Found %s parameters.", len(config))
            logger.info("Parameter keys: %s", config.keys())
        except Exception as e:
            raise ValueError(f"Error in verifying serialized file: {e}")

    def _format_py_serialization(self, path: Path) -> None:
        """Format the serialized python file."""
        try:
            check_call(["black", "--quiet", path])  # noqa: S607, S603
            logger.info("Successfully formatted serialized file: %s", path)
        except Exception as e:
            raise ValueError(f"Error in formatting serialized file: {e}")

    def _serialize_to_yaml(self, path: Path) -> None:
        """
        Serialize Params to YAML file (with .yml suffix).

        Args:
            path: Path for saving file.

        Returns: None.
        """
        serialized = json.loads(self.json())
        with path.open("w") as file:
            yaml.dump(serialized, file)

    @classmethod
    def from_yaml(cls: tp.Type[ParamsType], path: Path) -> ParamsType:
        """
        Initialize Params from YAML file.

        Args:
            path: Path to .yaml (or .yml) file.

        Returns: initialized Params object.
        """
        with path.open() as file:
            cfg = yaml.load(file, Loader=yaml.SafeLoader)
        return cls(**cfg)

    @classmethod
    def available_params(cls) -> tp.Dict[str, Path]:
        """
        Map of all available parameters names to its file names.

        Raises:
            NotImplementedError: If _get_params_dir is not implemented.
            ValueError: If params dir contains serialized and manually created
                .yaml with the same name
                (e.g. serialized_param.yml and param.yml)

        Returns: Mapping from parameter name to parameter file path, e.g. {"param": Path("../param.yml")}
        """
        files = cls._get_params_dir().glob("*")

        params_files: tp.Dict[str, Path] = {}
        for params_file in files:
            if params_file.suffix not in PYTHON_SUFFIX:
                continue

            params_name = params_file.stem
            if params_name in {"__init__", "__pycache__"}:
                continue

            if params_name.startswith(SERIALIZED_PREFIX):
                params_name = params_name[len(SERIALIZED_PREFIX) :]

            if params_name in params_files:
                raise ValueError(
                    f"For params {params_name} you have both serialized "
                    "and not serialized params. Please leave just one"
                )
            params_files[params_name] = params_file

        return params_files

    @classmethod
    def from_py(cls: tp.Type[ParamsType], path: Path) -> ParamsType:
        """
        Initialize Params from PY file.

        Args:
            path: Path to .yaml (or .yml) file.

        Returns: initialized Params object.
        """
        raise NotImplementedError("from_py method is not implemented.")

    @classmethod
    def from_parameters_name(cls: tp.Type[ParamsType], name: str) -> ParamsType:
        """
        Initialize Params object from parameters name.

        Raises:
            NotImplementedError: If get_params_dir is not implemented.
            NotImplementedError: If params stored not in YAML file.
            FileNotFoundError: If can't find parameter file.

        Args:
            name: parameters name, e.g. if file named some_params.yml, you should
                pass name="some_params" to this method.

        Returns: Params instance.
        """
        available_params = cls.available_params()
        params_filename = available_params.get(name)

        if params_filename is not None:
            return cls.from_yaml(params_filename)

        raise FileNotFoundError(
            f"Can't find parameter file for name={name}. " f"Available params names: {list(available_params.keys())}."
        )


def prepare_params(cls: tp.Type[ParamsType]) -> tp.Type[ParamsType]:
    """
    Decorate for base model params class (not for experiment).

    Can be used to remove all previously serialized PY params files.

    Also, fetch and prune tags, so you won't need to prune tags during
    params initialization (for serialization). It will speed-up
    initialization if you have a lot of experiment params.

    Args:
        cls: Class, inherited from Params.

    Returns: cls
    """

    def _erase_existed_params(params_paths: tp.List[Path]) -> None:
        for params_path in params_paths:
            if params_path.name.startswith(SERIALIZED_PREFIX):
                params_path.unlink()

    _erase_existed_params(list(cls.available_params().values()))
    return cls


def serialize_params(cls: tp.Type[ParamsType]) -> tp.Type[ParamsType]:
    """
    Initialize object of Params type and call .serialize method.

    Args:
        cls: Class, inherited from Params.

    Returns: cls
    """
    params_object = cls()
    params_object.assign_experiment_attributes()
    params_object.pre_finalize()
    params_object.finalize_recursive()
    params_object.serialize()
    return cls
