
# 实验管理发版接入使用说明
可以参照飞书文档：https://nio.feishu.cn/docx/I3GDdg07Jo9DopxvoFAc5rDnnad
### 使用参数说明
```
-n|--run-name:
-tid|--template-id:

```
###
```
bash tpp_onemodel/tools/run_pipeline/submit_exp_training.sh 8 experiments/task_planner/exp_planner_release/cfg_planner.py -n debug_train -dm test -ts train-stage1
```
