#!/bin/bash

RED='\e[1;31m'
GREEN='\e[1;32m'
YELLOW='\e[1;33m'
BLUE='\e[1;34m'
PINK='\e[1;35m'
RES='\e[0m'

echotimestamp() {
  if [[ -n $2 ]]; then
    COLOR=$2
  else
    COLOR=${RES}
  fi

  echo -e "${COLOR}$(date +'%Y-%m-%d %H:%M:%S') $1${RES}"
}

echo_log() {
  echotimestamp "$1" ${GREEN}
}

echo_warning() {
  echotimestamp "$1" ${YELLOW}
}

echo_error() {
  echotimestamp "$1" ${RES}
}

get_gpu_node_num() {
  local gpu_type=$1
  local device_num=$2

  case ${gpu_type} in
    a100-15c|a100-80g)
      gpu_num=8
      cpu_num=120
      mem_num=1920
      ;;
    a100-pop-40g)
      gpu_num=8
      cpu_num=120
      mem_num=960
      ;;
    *)
      echo_error "Error: Unknown device *${gpu_type}*"
      exit 1
      ;;
  esac

  # check if devidce num is a multiple of 8 or equal to 1, 2, 4
  if [[ ${device_num} -lt 8 ]]; then
    if [[ ${device_num} -eq 1 ]] || [[ ${device_num} -eq 2 ]] || [[ ${device_num} -eq 4 ]]; then
      node_num=1
      gpu_num=$((gpu_num * device_num / 8))
      cpu_num=$((cpu_num * device_num / 8))
      mem_num=$((mem_num * device_num / 8))
    else
      echo_error "Error: Device number ${device_num} must be a multiple of 8 or equal to 1, 2, 4"
      exit 1
    fi
  else
    if [[ $((device_num % 8)) -eq 0 ]]; then
      node_num=$((device_num / 8))
    else
      echo_error "Error: Device number ${device_num} must be a multiple of 8 or equal to 1, 2, 4"
      exit 1
    fi
  fi

  echo "${node_num},${gpu_num},${cpu_num},${mem_num}"
}

get_running_status() {
  local exp_dir=$1

  local last_step=
  local max_step=
  local running_progress=

  log_path=${exp_dir}/log/0.log
  if [[ -f ${log_path} ]]; then
    last_output=`tac ${log_path} | grep -m 1 "step: " | tac`
    if [[ -n ${last_output} ]]; then
      last_step=`echo ${last_output} | grep -oP "(?<=step: ).*?(?=/)"`
      max_step=`echo ${last_output} | grep -oP "(?<=/).*?(?=,)"`
      running_progress=`echo ${last_output} | grep -oP "(?<=, ).*?(?=%)"`
    fi
  fi
  echo "${last_step},${max_step},${running_progress}"
}

checkpoint_checker() {
  local exp_dir=$1

  local checkpoint_dir=${exp_dir}/ckpt
  local checkpoint_last_path=${checkpoint_dir}/checkpoint_last.pth.tar

  RESUME_STR=

  # check if checkpoint_last.pth.tar exists
  if [[ -f ${checkpoint_last_path} ]]; then
    echo_log "=> File checkpoint_last.pth.tar found. Prepare to resume ..."

    return_info=$(pipenv run python -c "
from tpp_onemodel.tools.run_pipeline.python_utils.utils import ckpt_test;
print(ckpt_test(\"${checkpoint_last_path}\"));
    ")
    if [[ ${return_info} == *"Succeed"* ]] ; then
        echo_log "=> Check ckpt ${checkpoint_last_path} succeed."
        RESUME_STR="--resume"
        return
    else
        echo_warning "=> Check ckpt ${checkpoint_last_path} failed: *${return_info}*. Try to find previous checkpoint ..."
    fi
  else
    echo_log "=> File checkpoint_last.pth.tar not found. Try to find previous checkpoint ..."
  fi

  while true; do
    checkpoint_list=`find ${checkpoint_dir} -maxdepth 1 -name "checkpoint_epoch*.pth.tar" -type f | sort -V`
    if [[ -z ${checkpoint_list} ]] ; then
      echo_warning "=> Available checkpoint not found. Prepare to training from scratch ..."
      cur_time=`date +"%Y-%m-%d-%H-%M-%S"`
      mv ${exp_dir} ${exp_dir}.bak_${cur_time}
      return
    fi

    pre_checkpoint_path=`echo ${checkpoint_list} | tail -n 1`
    return_info=$(pipenv run python -c "
from tpp_onemodel.tools.run_pipeline.python_utils.utils import ckpt_test;
print(ckpt_test(\"${pre_checkpoint_path}\"));
    ")
    if [[ ${return_info} == *"Succeed"* ]] ; then
        echo_log "=> Check ckpt ${pre_checkpoint_path} succeed. Use this ckpt instead."
        cur_time=`date +"%Y-%m-%d-%H-%M-%S"`
        mv ${checkpoint_last_path} ${checkpoint_last_path}.bak_${cur_time}
        cp ${pre_checkpoint_path} ${checkpoint_last_path}
        RESUME_STR="--resume"
        return
    else
        echo_warning "=> Check ckpt ${checkpoint_last_path} failed: *${return_info}*. Try to find previous checkpoint ..."
        mv ${pre_checkpoint_path} ${pre_checkpoint_path}.bak_${cur_time}
    fi
  done
}

convert_to_json() {
    python3 -c '
import ast, json, sys
try:
    data = ast.literal_eval(sys.stdin.read())
    print(json.dumps(data, ensure_ascii=False))
except Exception as e:
    sys.stderr.write(f"ERROR: {str(e)}\n")
    sys.exit(1)
'
}

save_exp_type_meta() {
  local exp_dir=$1
  local exp_run_name=$2
  local exp_train_stage=$3
  local exp_id=$4
  local artifact_output_dir=$5
  if [[ -z ${exp_id} ]]; then
    echo_error "Error: exp_id is empty."
    return
  fi
  if [[ -z ${exp_run_name} ]]; then
    echo_error "Error: exp_run_name is empty."
    return
  fi
  if [[ -z ${exp_train_stage} ]]; then
    echo_error "Error: exp_train_stage is empty."
    return
  fi
  if [[ -z ${exp_dir} ]]; then
    echo_error "Error: exp_dir is empty."
    return
  fi
  meta_path="${exp_dir}/${exp_run_name}"
  meta_filename="${exp_train_stage}_meta.json"

  if [[ ! -d ${meta_path} ]]; then
    mkdir -p ${meta_path}
  fi

  echo "{
    \"exp_id\": \"${exp_id}\",
    \"artifact_output_dir\": \"${artifact_output_dir}\"
  }" > ${meta_path}/${meta_filename}
  if [[ $? -ne 0 ]]; then
    echo_error "Error: Failed to save ${exp_train_stage} meta to ${meta_path}/${meta_filename}"
    return
  fi
  echo "${meta_path}/${meta_filename}"
}

load_exp_type_meta() {
  local exp_dir=$1
  local exp_run_name=$2
  local exp_train_stage=$3
  if [[ -z ${exp_run_name} ]]; then
    echo_error "Error: exp_run_name is empty."
    return
  fi
  if [[ -z ${exp_train_stage} ]]; then
    echo_error "Error: exp_train_stage is empty."
    return
  fi
  if [[ -z ${exp_dir} ]]; then
    echo_error "Error: exp_dir is empty."
    return
  fi
  meta_path="${exp_dir}/${exp_run_name}/${exp_train_stage}_meta.json"
  if [[ -f ${meta_path} ]]; then
    exp_id=`cat ${meta_path} | grep -oP "(?<=\"exp_id\": \").*?(?=\")"`
    artifact_output_dir=`cat ${meta_path} | grep -oP "(?<=\"artifact_output_dir\": \").*?(?=\")"`
    if [[ -z ${exp_id} ]]; then
      echo_error "Error: exp_id is empty."
      return
    fi
  else
    echo_error "Error: No ${meta_filename} meta file found in ${meta_path}"
    return
  fi
  echo "${exp_id},${artifact_output_dir}"
}

send_feishu_message() {
  eval feishu_hook="${1}"
  eval version="${2}"
  eval version_description="${3}"
  eval torchpilot_commit_id="${4}"
  eval share_checkpoint_last_path="${5}"
  eval trace_model_path="${6}"
  eval quant_x86_version="${7}"
  eval quant_orin_version="${8}"
  eval quant_a40_version="${9}"
  eval integration_branch_name="${10}"
  eval base_integration_branch_or_commit="${11}"
  eval model_branch_name="${12}"
  eval base_model_branch_or_commit="${13}"
  eval model_commit_id="${14}"
  eval base_bundle_id="${15}"
  eval bundle_id="${16}"

  if [[ -z ${feishu_hook} ]]; then
    echo_warning "Warning: No hook given, skip sending feishu message."
    return
  fi

  curl -X POST -H "Content-Type: application/json" \
    -d "{
      \"msg_type\": \"interactive\",
      \"card\": {
        \"elements\": [
          {
            \"tag\": \"div\",
            \"text\": {
              \"content\": \"🔺 **版本号:** ${version}\",
              \"tag\": \"lark_md\"
            }
          },
          {
            \"tag\": \"div\",
            \"text\": {
              \"content\": \"🔺 **版本描述:** ${version_description}\",
              \"tag\": \"lark_md\"
            }
          },
          {
            \"tag\": \"div\",
            \"text\": {
              \"content\": \"🔺 **Melange commit id:** ${torchpilot_commit_id}\",
              \"tag\": \"lark_md\"
            }
          },
          {
            \"tag\": \"div\",
            \"text\": {
              \"content\": \"🔺 **Ckpt 路径:** ${share_checkpoint_last_path}\",
              \"tag\": \"lark_md\"
            }
          },
          {
            \"tag\": \"div\",
            \"text\": {
              \"content\": \"🔺 **Trace Model 路径:** ${trace_model_path}\",
              \"tag\": \"lark_md\"
            }
          },
          {
            \"tag\": \"div\",
            \"text\": {
              \"content\": \"🔺 **Tvm Model Version**\",
              \"tag\": \"lark_md\"
            },
            \"fields\": [
              {
                \"is_short\": false,
                \"text\": {
                  \"tag\": \"lark_md\",
                  \"content\": \"  🔺 **Ntsctl:** ${quant_x86_version}\"
                }
              },
              {
                \"is_short\": false,
                \"text\": {
                  \"tag\": \"lark_md\",
                  \"content\": \"  🔺 **Orin:** ${quant_orin_version}\"
                }
              },
              {
                \"is_short\": false,
                \"text\": {
                  \"tag\": \"lark_md\",
                  \"content\": \"  🔺 **A40:** ${quant_a40_version}\"
                }
              }
            ]
          },
          {
            \"tag\": \"div\",
            \"text\": {
              \"content\": \"🔺 **Integration Version**\",
              \"tag\": \"lark_md\"
            },
            \"fields\": [
              {
                \"is_short\": false,
                \"text\": {
                  \"tag\": \"lark_md\",
                  \"content\": \"  🔺 **Integration Branch Name:** ${integration_branch_name}\"
                }
              },
              {
                \"is_short\": false,
                \"text\": {
                  \"tag\": \"lark_md\",
                  \"content\": \"  🔺 **Integration Base Commit ID:** ${base_integration_branch_or_commit}\"
                }
              },
              {
                \"is_short\": false,
                \"text\": {
                  \"tag\": \"lark_md\",
                  \"content\": \"  🔺 **Model Branch Name:** ${model_branch_name}\"
                }
              },
              {
                \"is_short\": false,
                \"text\": {
                  \"tag\": \"lark_md\",
                  \"content\": \"  🔺 **Model Base Commit ID:** ${base_model_branch_or_commit}\"
                }
              },
              {
                \"is_short\": false,
                \"text\": {
                  \"tag\": \"lark_md\",
                  \"content\": \"  🔺 **Model Commit ID:** ${model_commit_id}\"
                }
              }
            ]
          },
          {
            \"tag\": \"div\",
            \"text\": {
              \"content\": \"🔺 **Bundle Version**\",
              \"tag\": \"lark_md\"
            },
            \"fields\": [
              {
                \"is_short\": false,
                \"text\": {
                  \"tag\": \"lark_md\",
                  \"content\": \"  🔺 **Base bundle id:** ${base_bundle_id}\"
                }
              },
              {
                \"is_short\": false,
                \"text\": {
                  \"tag\": \"lark_md\",
                  \"content\": \"  🔺 **Bundle id:** ${bundle_id}\"
                }
              }
            ]
          }
        ],
        \"header\": {
          \"title\": {
            \"content\": \"✅ Astra Planner Model Daily 版本发布通知\",
            \"tag\": \"plain_text\"
          }
        }
      }
    }" \
    ${feishu_hook}
}

send_eval_report_feishu_message() {
  local feishu_hook=${1}
  local http_link=${2}
  local version=${3}
  local eval_report=${4}

  if [[ -z ${feishu_hook} ]]; then
    echo_warning "Warning: No hook given, skip sending feishu message."
    return
  fi

  if [[ -n ${http_link} ]]; then
    eval_report_link="[${eval_report}](${http_link})"
  else
    eval_report_link=${eval_report}
  fi

  curl -X POST -H "Content-Type: application/json" \
    -d "{
      \"msg_type\": \"interactive\",
      \"card\": {
        \"elements\": [
          {
            \"tag\": \"div\",
            \"text\": {
              \"content\": \"🔺 **版本号:** ${version}\",
              \"tag\": \"lark_md\"
            }
          },
          {
            \"tag\": \"div\",
            \"text\": {
              \"content\": \"🔺 **评测报告:** ${eval_report_link}\",
              \"tag\": \"lark_md\"
            }
          }
        ],
        \"header\": {
          \"title\": {
            \"content\": \"✅ Astra Planner Model Daily 模型自测报告\",
            \"tag\": \"plain_text\"
          }
        }
      }
    }" \
    ${feishu_hook}
}
