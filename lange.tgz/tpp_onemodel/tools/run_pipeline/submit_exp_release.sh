#!/bin/bash

source $(dirname "$(realpath "$0")")/common_util.sh

source $(dirname "$(realpath "$0")")/common_config.sh

# ================================== Env script ==================================

CUR_DIR=`pwd`

mkdir -p ${WORKSPACE}
mkdir -p ${LOCAL_OUTPUT_DIR}
mkdir -p ${SHARE_DIR}

mkdir -p ${TRACE_DUMP_ROOT}
mkdir -p ${QUANT_DUMP_ROOT}

mkdir -p ${SHARE_EVAL_REPORT_DUMP_ROOT}

echo_log "=> Prepare torchpilot env ..."
cd ${WORKSPACE}
if [[ ! -d ${TORCHPILOT_DIR} ]] ; then
  git clone git@ad-gitlab.nioint.com:ad/perception/perception_fte/melange.git
fi
cd ${TORCHPILOT_DIR}
git fetch --all --prune
git checkout ${TORCHPILOT_COMMIT_ID_SHORT}
make dev
sed -i 's/scaler.update()/scaler.update(1.0)/g' .venv/lib/python3.8/site-packages/torchpilot/runner/trainer/tp_trainer.py
sleep 10
echo_log "=> Prepare torchpilot env done."

echo_log "=> Prepare integration env ..."
cd ${WORKSPACE}
if [[ ! -d ${INTEGRATION_DIR} ]] ; then
  git clone git@ad-gitlab.nioint.com:ad/perception/engineering/external_group/argus_post_integration.git
fi
cd ${INTEGRATION_DIR}
git fetch --all --prune
git reset --hard
git checkout ${BASE_INTEGRATION_BRANCH_OR_COMMIT}
git submodule update --init --recursive
git checkout -B ${INTEGRATION_BRANCH_NAME}
git push -f origin ${INTEGRATION_BRANCH_NAME}
sleep 10

cd ${WORKSPACE}
if [[ ! -d ${MODEL_DIR} ]] ; then
  git clone git@ad-gitlab.nioint.com:ad/perception/engineering/internal/argus_model.git
fi
cd ${MODEL_DIR}
git fetch --all --prune
git reset --hard
git checkout ${BASE_MODEL_BRANCH_OR_COMMIT}
git submodule update --init --recursive
sleep 10
echo_log "=> Prepare integration env done."

cd ${CUR_DIR}

# ================================== Train script ==================================

if [[ ${USE_DEFAULT_MODEL} == 0 ]]; then
  echo_log "=> Prepare to submit job of training ..."
  Stage1_Output="${LOCAL_OUTPUT_DIR}/torchpilot_outputs"
  bash tpp_onemodel/tools/run_pipeline/submit_exp_training.sh \
      ${DEVICE_NUM} \
      ${CFG_PATH} \
      -tid ${TEMPLATE_ID} \
      -cl ${CLUSTER} \
      -ts ${TRAIN_STAGE1} \
      -n ${RUN_NAME} \
      -dm ${DATASET_MODE} \
      -PR ${PRIORITY} \
      -GT ${GPU_TYPE} \
      -I ${DOCKER_IMAGE} \
      -WD ${TORCHPILOT_DIR} \
      -OD ${Stage1_Output}
  exit_code=$?
  # 检查退出状态码
  if [ $exit_code -ne 0 ]; then
    echo_error "=>Error: Training failed with exit code $exit_code."
    exit 1
  fi
  echo_log "=> Training successed."
  IFS=$',' read -r TRAIN_STAGE1_EXP_ID STAGE1_ARTIFACT_OUTPUT_DIR <<< `load_exp_type_meta "${Stage1_Output}" "${RUN_NAME}" "${TRAIN_STAGE1}"`
  # 判断TRAIN_STAGE1_EXP_ID
  if ! [[ ${TRAIN_STAGE1_EXP_ID} =~ ^[0-9]+$ ]] ; then
    echo_error "=>Error: TRAIN_STAGE1_EXP_ID is not a number."
    exit 1
  fi
  # STAGE1_ARTIFACT_OUTPUT_DIR是否为空
  if [[ -z ${STAGE1_ARTIFACT_OUTPUT_DIR} ]] ; then
    echo_error "=>Error: STAGE1_ARTIFACT_OUTPUT_DIR is empty."
    exit 1
  fi

  echo_log "=> Copy training stage1 outputs ${STAGE1_ARTIFACT_OUTPUT_DIR} to /share-global ..."
  mkdir -p ${SHARE_DIR}/torchpilot_outputs/${EXP_BASE_DIR}/${RUN_NAME}
  cp -r ${STAGE1_ARTIFACT_OUTPUT_DIR}/${EXP_BASE_DIR}/${RUN_NAME}/cfg_* ${SHARE_DIR}/torchpilot_outputs/${EXP_BASE_DIR}/${RUN_NAME}
  cp -r ${STAGE1_ARTIFACT_OUTPUT_DIR}/${EXP_BASE_DIR}/${RUN_NAME}/ckpt/ ${SHARE_DIR}/torchpilot_outputs/${EXP_BASE_DIR}/${RUN_NAME}
  cp -r ${STAGE1_ARTIFACT_OUTPUT_DIR}/${EXP_BASE_DIR}/${RUN_NAME}/log/ ${SHARE_DIR}/torchpilot_outputs/${EXP_BASE_DIR}/${RUN_NAME}
  cp -r ${STAGE1_ARTIFACT_OUTPUT_DIR}/${EXP_BASE_DIR}/${RUN_NAME}/summary/ ${SHARE_DIR}/torchpilot_outputs/${EXP_BASE_DIR}/${RUN_NAME}

  DEFAULT_MODEL=${SHARE_DIR}/torchpilot_outputs/${EXP_BASE_DIR}/${RUN_NAME}/ckpt/checkpoint_last.pth.tar
fi

sleep 10

# ================================== Stage2 Train script ==================================

cd ${CUR_DIR}

if [[ ${STAGE2_USE_DEFAULT_MODEL} == 0 ]]; then
  cd ${TORCHPILOT_DIR}
  python -c "
fr = open('${STAGE2_CFG_PATH}', 'r')
fl = fr.readlines()
for i, v in enumerate(fl):
  if 'pretrain_model' in v:
    fl[i] = 'ckpt[\"pretrain_model\"] = \"${DEFAULT_MODEL}\"'
fr.close()
fw = open('${STAGE2_CFG_PATH}', 'w');
fw.writelines(fl)
fw.close()
  "
  cd ${CUR_DIR}
  Stage2_Output="${LOCAL_OUTPUT_DIR}/torchpilot_outputs"
  bash tpp_onemodel/tools/run_pipeline/submit_exp_training.sh \
      ${DEVICE_NUM} \
      ${STAGE2_CFG_PATH} \
      -tid ${STAGE2_TEMPLATE_ID} \
      -cl ${STAGE2_CLUSTER} \
      -ts ${TRAIN_STAGE2} \
      -n ${RUN_NAME} \
      -dm ${DATASET_MODE} \
      -PR ${PRIORITY} \
      -GT ${GPU_TYPE} \
      -I ${DOCKER_IMAGE} \
      -WD ${TORCHPILOT_DIR} \
      -OD ${Stage2_Output}

  exit_code=$?
  # 检查退出状态码
  if [ $exit_code -ne 0 ]; then
    echo_error "=>Error: Training failed with exit code $exit_code."
    exit 1
  fi

  echo_log "=> Training Stage2 successed."
  IFS=$',' read -r TRAIN_STAGE2_EXP_ID STAGE2_ARTIFACT_OUTPUT_DIR <<< `load_exp_type_meta "${Stage2_Output}" "${RUN_NAME}" "${TRAIN_STAGE2}"`
  # 判断TRAIN_STAGE1_EXP_ID
  if ! [[ ${TRAIN_STAGE2_EXP_ID} =~ ^[0-9]+$ ]] ; then
    echo_error "=>Error: TRAIN_STAGE2_EXP_ID is not a number."
    exit 1
  fi
  # STAGE1_ARTIFACT_OUTPUT_DIR是否为空
  if [[ -z ${STAGE2_ARTIFACT_OUTPUT_DIR} ]] ; then
    echo_error "=>Error: STAGE2_ARTIFACT_OUTPUT_DIR is empty."
    exit 1
  fi

  echo_log "=> Copy training stage2 outputs ${STAGE2_ARTIFACT_OUTPUT_DIR} to /share-global ..."
  mkdir -p ${SHARE_DIR}/torchpilot_outputs/${EXP_BASE_DIR}/${RUN_NAME}
  cp -r ${STAGE2_ARTIFACT_OUTPUT_DIR}/${EXP_BASE_DIR}/${RUN_NAME}/cfg_* ${SHARE_DIR}/torchpilot_outputs/${EXP_BASE_DIR}/${RUN_NAME}
  cp -r ${STAGE2_ARTIFACT_OUTPUT_DIR}/${EXP_BASE_DIR}/${RUN_NAME}/ckpt/ ${SHARE_DIR}/torchpilot_outputs/${EXP_BASE_DIR}/${RUN_NAME}
  cp -r ${STAGE2_ARTIFACT_OUTPUT_DIR}/${EXP_BASE_DIR}/${RUN_NAME}/log/ ${SHARE_DIR}/torchpilot_outputs/${EXP_BASE_DIR}/${RUN_NAME}
  cp -r ${STAGE2_ARTIFACT_OUTPUT_DIR}/${EXP_BASE_DIR}/${RUN_NAME}/summary/ ${SHARE_DIR}/torchpilot_outputs/${EXP_BASE_DIR}/${RUN_NAME}

  STAGE2_DEFAULT_MODEL=${SHARE_DIR}/torchpilot_outputs/${EXP_BASE_DIR}/${RUN_NAME}/ckpt/checkpoint_last.pth.tar
fi

sleep 10

# ================================== Fuse CKPT ==================================

cd ${TORCHPILOT_DIR}

FUSE_CHECKPOINT_FOLDER=${EXP_DIR}/fuse_ckpt
FUSE_CHECKPOINT_PATH=${FUSE_CHECKPOINT_FOLDER}/checkpoint_fused.pth.tar
mkdir -p ${FUSE_CHECKPOINT_FOLDER}
echo "stage1 ckpt: ${DEFAULT_MODEL}"
echo "stage2 ckpt: ${STAGE2_DEFAULT_MODEL}"

  python -c "
import torch
c1 = torch.load('${DEFAULT_MODEL}')
c2 = torch.load('${STAGE2_DEFAULT_MODEL}')
for k in c2['model'].keys():
  if 'stage2' in k:
    c1['model'][k] = c2['model'][k]
torch.save(c1, '${FUSE_CHECKPOINT_PATH}')
  "
CHECKPOINT_LAST_PATH=${FUSE_CHECKPOINT_PATH}

sleep 10

# ================================== Trace and quant script ==================================

cd ${TORCHPILOT_DIR}

if [[ ! -f ${QUANT_DUMP_ROOT}/libs_info.json ]] ; then
  EXTRA_ARGS=
  if [[ -n ${QUANT_EXPORT_BRANCH} ]] ; then
    EXTRA_ARGS="${EXTRA_ARGS} --quant_export_branch ${QUANT_EXPORT_BRANCH}"
  fi
  if [[ -n ${QUANT_COMPILE_BRANCH} ]] ; then
    EXTRA_ARGS="${EXTRA_ARGS} --quant_compile_branch ${QUANT_COMPILE_BRANCH}"
  fi
  bash tpp_onemodel/tools/run_pipeline/submit_trace_quant.sh \
    ${TRACE_CFG_PATH} \
    -c ${CHECKPOINT_LAST_PATH} \
    -qt_cfg ${QUANT_CFG_PATH} \
    -et ${QUANT_EXPORT_TARGET} \
    -dt ${QUANT_DEPLOY_TYPE} \
    -user ${USER} \
    --version ${VERSION} \
    -ld $(dirname "${LOCAL_OUTPUT_DIR}") \
    -sd $(dirname "${SHARE_DIR}") \
    ${EXTRA_ARGS}
else
  echo_log "=> Detect tracing and converting tvm has finished! Skip running."
fi

cd ${CUR_DIR}

QUANT_VERSION_INFO=$(pipenv run python -c "
import json;
response = json.load(open('${QUANT_DUMP_ROOT}/libs_info.json', 'r'));
libs_info = response['models']['cuda']['artifacts']['compile'];
ntsctl_version = libs_info.get('ntsctl_libs', '::Null').split(':')[2];
orin_version = libs_info.get('orin_libs', '::Null').split(':')[2];
a40_version = libs_info.get('a40_libs', '::Null').split(':')[2];
print(f'{ntsctl_version} {orin_version} {a40_version}');
")
QUANT_X86_VERSION=`echo ${QUANT_VERSION_INFO} | cut -d " " -f 1`
QUANT_ORIN_VERSION=`echo ${QUANT_VERSION_INFO} | cut -d " " -f 2`
QUANT_A40_VERSION=`echo ${QUANT_VERSION_INFO} | cut -d " " -f 3`

QUANT_X86_MODEL_PATH=${QUANT_DUMP_ROOT}/ntsctl_${QUANT_X86_VERSION}
QUANT_ORIN_MODEL_PATH=${QUANT_DUMP_ROOT}/orin_${QUANT_ORIN_VERSION}
QUANT_A40_MODEL_PATH=${QUANT_DUMP_ROOT}/a40_${QUANT_A40_VERSION}

SHARE_QUANT_X86_MODEL_PATH=${SHARE_QUANT_DUMP_ROOT}/ntsctl_${QUANT_X86_VERSION}
SHARE_QUANT_ORIN_MODEL_PATH=${SHARE_QUANT_DUMP_ROOT}/orin_${QUANT_ORIN_VERSION}
SHARE_QUANT_A40_MODEL_PATH=${SHARE_QUANT_DUMP_ROOT}/a40_${QUANT_A40_VERSION}

echo_log "=> Convert tvm successed. model version:"
echo_log "=>   x86: ${QUANT_X86_VERSION}"
echo_log "=>   orin: ${QUANT_ORIN_VERSION}"
echo_log "=>   a40: ${QUANT_A40_VERSION}"

sleep 10

# ================================== Integration script ==================================

echo_log "=> Prepare to gen integration version ..."

source ${TORCHPILOT_DIR}/.venv/bin/activate
pip install ruamel.yaml

cd ${MODEL_DIR}

if [[ -n $(git branch -a | grep origin/${MODEL_BRANCH_NAME}) ]] && \
  [[ $(git log -3 origin/${MODEL_BRANCH_NAME} --format="%s") == *${QUANT_X86_VERSION}* ]] ; then
  echo_log "=> Detect integration version has update! Skip this step."
else
  python -c "
from ruamel.yaml import YAML;
yaml = YAML(typ='rt');
yaml.indent(mapping=4, sequence=4, offset=4);
yaml.preserve_quotes = True;
yaml.width = 4096;
fr = open('model_release.yml', 'r');
model_release = yaml.load(fr);
fr.close();
model_release['normal']['astra_planner']['x86'] = '${QUANT_X86_VERSION}';
model_release['normal']['astra_planner']['x86A40'] = '${QUANT_A40_VERSION}';
model_release['normal']['astra_planner']['orin'] = '${QUANT_ORIN_VERSION}';
fw = open('model_release.yml', 'w');
yaml.dump(model_release, fw);
fw.close();
  "

  if [[ -z $(git diff -r | grep model_release.yml) ]] ; then
    echo_log "model_release.yml has no diff, Ignore this commit!"
  else

    git checkout -B ${MODEL_BRANCH_NAME}
    git add model_release.yml
    git commit -m "Update astra planner model ${QUANT_X86_VERSION}"
    git push -f origin ${MODEL_BRANCH_NAME}
    sleep 10

    while true; do
      git fetch --all --prune > /dev/null 2>&1
      if [[ -n $(git show origin/${MODEL_BRANCH_NAME} --format=%s -q HEAD | grep 该commit为自动生成) ]] ; then
        break
      fi
      echotimestamp "=> Waiting for auto commit."
      sleep ${LOG_FREQ}
    done

    git pull origin ${MODEL_BRANCH_NAME}
  fi

  sleep 10
fi

MODEL_COMMIT_ID=`git log -1 ${MODEL_BRANCH_NAME} --format="%H"`
echo_log "=> Model branch name: ${MODEL_BRANCH_NAME}"
echo_log "=> Model commit id: ${MODEL_COMMIT_ID}"

deactivate
cd ${CUR_DIR}

sleep 10

# ================================== Patch bundle build ==================================

if [[ -n ${BASE_BUNDLE_ID} ]] ; then
  echo_log "=> Prepare to build patch bundle ..."

  cd ${TORCHPILOT_DIR}

  if [[ ! -f ${LOCAL_OUTPUT_DIR}/build/response.json ]] ; then
    pipenv run python tpp_onemodel/tools/run_pipeline/python_utils/submit_bundle_build.py \
      --user ${USER} \
      --version ${VERSION} \
      --base_bundle ${BASE_BUNDLE_ID} \
      --integration ${INTEGRATION_BRANCH_NAME} \
      --argus_model ${MODEL_BRANCH_NAME} \
      --dump_root ${LOCAL_OUTPUT_DIR}/build
  else
    echo_log "=> Detect patch bundle building has finished! Skip."
  fi

  cd ${CUR_DIR}

  BUNDLE_ID=$(python -c "
import json;
response = json.load(open('${LOCAL_OUTPUT_DIR}/build/response.json', 'r'));
print(response['bundle_uuid']);
  ")

  echo_log "=> Base bundle id: ${BASE_BUNDLE_ID}"
  echo_log "=> Bundle id: ${BUNDLE_ID}"

  sleep 10
fi

# ================================== Send feishu message ==================================

if [[ -n ${QUANT_X86_VERSION} ]] && [[ ${QUANT_X86_VERSION}x != "Null"x ]] && \
  [[ -n ${QUANT_ORIN_VERSION} ]] && [[ ${QUANT_ORIN_VERSION}x != "Null"x ]] && \
  [[ -n ${QUANT_A40_VERSION} ]] && [[ ${QUANT_A40_VERSION}x != "Null"x ]] && \
  [[ -n ${MODEL_COMMIT_ID} ]] && [[ ${MODEL_COMMIT_ID}x != "Null"x ]] ; then
  send_feishu_message \
    "\${FEISHU_HOOK}" \
    "\${VERSION}" \
    "\${VERSION_DESCRIPTION}" \
    "\${TORCHPILOT_COMMIT_ID}" \
    "\${SHARE_CHECKPOINT_LAST_PATH}" \
    "\${SHARE_TRACE_MODEL_PATH}" \
    "\${QUANT_X86_VERSION}" \
    "\${QUANT_ORIN_VERSION}" \
    "\${QUANT_A40_VERSION}" \
    "\${INTEGRATION_BRANCH_NAME}" \
    "\${BASE_INTEGRATION_BRANCH_OR_COMMIT}" \
    "\${MODEL_BRANCH_NAME}" \
    "\${BASE_MODEL_BRANCH_OR_COMMIT}" \
    "\${MODEL_COMMIT_ID}" \
    "\${BASE_BUNDLE_ID}" \
    "\${BUNDLE_ID}"
else
  echo_error "Error!"
fi

sleep 10

# ================================== Eval script ==================================

echo_log "=> Prepare to submit job of eval ckpt ..."
EVAL_OUTPUT_DIR="${LOCAL_OUTPUT_DIR}/torchpilot_outputs"
EVAL_RUN_NAME="eval_${RUN_NAME}"
SKIP_EVAL=0
CUR_EXP_DIR=""

IFS=$',' read -r TRAIN_EVAL_EXP_ID EVAL_ARTIFACT_OUTPUT_DIR <<< `load_exp_type_meta "${EVAL_OUTPUT_DIR}" "${EVAL_RUN_NAME}" "${EVAL_TRAIN_STAGE}"`

# STAGE1_ARTIFACT_OUTPUT_DIR是否为空
if [[ ! -z ${EVAL_ARTIFACT_OUTPUT_DIR} ]] ; then
  CUR_EXP_DIR="${EVAL_ARTIFACT_OUTPUT_DIR}/${EXP_BASE_DIR}/${EVAL_RUN_NAME}"
  if [[ -f ${CUR_EXP_DIR}/export/scene_metrics_table.csv ]] ; then
    echo_log "=> Detect eval job has finished! Skip running."
    SKIP_EVAL=1
  fi
fi

if [[ ${SKIP_EVAL} == 0 ]] ; then
  if [[ -d ${CUR_EXP_DIR} ]] ; then
    rm -rf ${CUR_EXP_DIR}
  fi

  bash tpp_onemodel/tools/run_pipeline/submit_exp_eval.sh \
      ${EVAL_DEVICE_NUM} \
      ${CFG_PATH} \
      -it torch \
      -tid ${EVAL_TEMPLATE_ID} \
      -cl ${EVAL_CLUSTER} \
      -ts ${EVAL_TRAIN_STAGE} \
      -n ${EVAL_RUN_NAME} \
      -c ${SHARE_CHECKPOINT_LAST_PATH} \
      -PR normal \
      -GT ${EVAL_GPU_TYPE} \
      -I ${DOCKER_IMAGE} \
      -WD ${TORCHPILOT_DIR} \
      -OD ${EVAL_OUTPUT_DIR}

  exit_code=$?
  # 检查退出状态码
  if [ $exit_code -ne 0 ]; then
    echo_error "=>Error: Training failed with exit code $exit_code."
    exit 1
  fi

  IFS=$',' read -r TRAIN_EVAL_EXP_ID EVAL_ARTIFACT_OUTPUT_DIR <<< `load_exp_type_meta "${EVAL_OUTPUT_DIR}" "${EVAL_RUN_NAME}" "${EVAL_TRAIN_STAGE}"`
  CUR_EXP_DIR="${EVAL_ARTIFACT_OUTPUT_DIR}/${EXP_BASE_DIR}/${EVAL_RUN_NAME}"

  if [[ -f ${CUR_EXP_DIR}/export/scene_metrics_table.csv ]] ; then
    echo_log "=> Eval job has finished!"
    break
  else
    echo_log "=> Eval report not found. Retry ..."
  fi
fi

sleep 10

echo_log "=> Copy eval report to /share-global ..."
cp ${CUR_EXP_DIR}/export/scene_metrics_table.csv \
  ${SHARE_EVAL_REPORT_DUMP_ROOT}/scene_metrics_table_ckpt.csv

sleep 10

# # ================================== Eval ckpt for release ==================================

# echo_log "=> Prepare to submit job of eval ckpt for release ..."

# CUR_EXP_DIR="${LOCAL_OUTPUT_DIR}/torchpilot_outputs/${EXP_BASE_DIR}/eval_${RUN_NAME}_ckpt_for_trace"
# if [[ -f ${CUR_EXP_DIR}/export/scene_metrics_table.csv ]] ; then
#   echo_log "=> Detect eval job has finished! Skip running."
# else
#   while true; do
#     if [[ -d ${CUR_EXP_DIR} ]] ; then
#       rm -rf ${CUR_EXP_DIR}
#     fi
#     bash tpp_onemodel/tools/run_pipeline/submit_eval.sh \
#       ${EVAL_DEVICE_NUM} \
#       ${CFG_PATH_EVAL_TRACE} \
#       -it torch \
#       -n eval_${RUN_NAME}_ckpt_for_trace \
#       -c ${SHARE_CHECKPOINT_LAST_PATH} \
#       -PR normal \
#       -GT ${EVAL_GPU_TYPE} \
#       -I ${DOCKER_IMAGE} \
#       -WD ${TORCHPILOT_DIR} \
#       -OD ${LOCAL_OUTPUT_DIR}/torchpilot_outputs

#     if [[ -f ${CUR_EXP_DIR}/export/scene_metrics_table.csv ]] ; then
#       echo_log "=> Eval job has finished!"
#       break
#     else
#       echo_log "=> Eval report not found. Retry ..."
#     fi
#   done
# fi

# sleep 10

# echo_log "=> Copy eval report to /share-global ..."
# cp ${CUR_EXP_DIR}/export/scene_metrics_table.csv \
#   ${SHARE_EVAL_REPORT_DUMP_ROOT}/scene_metrics_table_ckpt_tiny.csv

# sleep 10

# # ================================== Eval trace for release ==================================

# echo_log "=> Prepare to submit job of eval trace model ..."

# CUR_EXP_DIR="${LOCAL_OUTPUT_DIR}/torchpilot_outputs/${EXP_BASE_DIR}/eval_${RUN_NAME}_trace"
# if [[ -f ${CUR_EXP_DIR}/export/scene_metrics_table.csv ]] ; then
#   echo_log "=> Detect eval job has finished! Skip running."
# else
#   while true; do
#     if [[ -d ${CUR_EXP_DIR} ]] ; then
#       rm -rf ${CUR_EXP_DIR}
#     fi
#     bash tpp_onemodel/tools/run_pipeline/submit_eval.sh \
#       ${EVAL_DEVICE_NUM} \
#       ${CFG_PATH_EVAL_TRACE} \
#       -it trace \
#       -n eval_${RUN_NAME}_trace \
#       -c ${SHARE_TRACE_MODEL_PATH} \
#       -PR normal \
#       -GT ${EVAL_GPU_TYPE} \
#       -I ${DOCKER_IMAGE} \
#       -WD ${TORCHPILOT_DIR} \
#       -OD ${LOCAL_OUTPUT_DIR}/torchpilot_outputs

#     if [[ -f ${CUR_EXP_DIR}/export/scene_metrics_table.csv ]] ; then
#       echo_log "=> Eval job has finished!"
#       break
#     else
#       echo_log "=> Eval report not found. Retry ..."
#     fi
#   done
# fi

# sleep 10

# echo_log "=> Copy eval report to /share-global ..."
# cp ${CUR_EXP_DIR}/export/scene_metrics_table.csv \
#   ${SHARE_EVAL_REPORT_DUMP_ROOT}/scene_metrics_table_trace_tiny.csv

# sleep 10

# # ================================== Eval tvm for release ==================================

# echo_log "=> Prepare to submit job of eval tvm model ..."

# CUR_EXP_DIR="${LOCAL_OUTPUT_DIR}/torchpilot_outputs/${EXP_BASE_DIR}/eval_${RUN_NAME}_tvm"
# if [[ -f ${CUR_EXP_DIR}/export/scene_metrics_table.csv ]] ; then
#   echo_log "=> Detect eval job has finished! Skip running."
# else
#   while true; do
#     if [[ -d ${CUR_EXP_DIR} ]] ; then
#       rm -rf ${CUR_EXP_DIR}
#     fi
#     bash tpp_onemodel/tools/run_pipeline/submit_eval.sh \
#       ${EVAL_DEVICE_NUM} \
#       ${CFG_PATH_EVAL_TRACE} \
#       -it tvm \
#       -n eval_${RUN_NAME}_tvm \
#       -c ${SHARE_QUANT_X86_MODEL_PATH} \
#       -PR normal \
#       -GT ${EVAL_GPU_TYPE} \
#       -I ${DOCKER_IMAGE} \
#       -WD ${TORCHPILOT_DIR} \
#       -OD ${LOCAL_OUTPUT_DIR}/torchpilot_outputs

#     if [[ -f ${CUR_EXP_DIR}/export/scene_metrics_table.csv ]] ; then
#       echo_log "=> Eval job has finished!"
#       break
#     else
#       echo_log "=> Eval report not found. Retry ..."
#     fi
#   done
# fi

# sleep 10

# echo_log "=> Copy eval report to /share-global ..."
# cp ${CUR_EXP_DIR}/export/scene_metrics_table.csv \
#   ${SHARE_EVAL_REPORT_DUMP_ROOT}/scene_metrics_table_tvm_tiny.csv

# sleep 10

# # ================================== Send feishu message ==================================

# cd ${TORCHPILOT_DIR}

# pipenv run python tpp_onemodel/tools/run_pipeline/python_utils/csv_to_md.py \
#   -v ${VERSION} \
#   --commit ${TORCHPILOT_COMMIT_ID} \
#   --ckpt ${SHARE_CHECKPOINT_LAST_PATH} \
#   --trace ${SHARE_TRACE_MODEL_PATH} \
#   --ntsctl ${SHARE_QUANT_X86_MODEL_PATH} \
#   --orin ${SHARE_QUANT_ORIN_MODEL_PATH} \
#   --a40 ${SHARE_QUANT_A40_MODEL_PATH} \
#   --report_ckpt ${SHARE_EVAL_REPORT_DUMP_ROOT}/scene_metrics_table_ckpt.csv \
#   --report_ckpt_tiny ${SHARE_EVAL_REPORT_DUMP_ROOT}/scene_metrics_table_ckpt_tiny.csv \
#   --report_trace_tiny ${SHARE_EVAL_REPORT_DUMP_ROOT}/scene_metrics_table_trace_tiny.csv \
#   --report_tvm_tiny ${SHARE_EVAL_REPORT_DUMP_ROOT}/scene_metrics_table_tvm_tiny.csv \
#   -d ${SHARE_EVAL_REPORT_DUMP_ROOT}/eval_report.md

# if [[ -e ${SHARE_EVAL_REPORT_DUMP_ROOT}/eval_report.md ]] ; then
#   if [[ -n ${HTTP_PORT} ]] ; then
#     HTTP_LINK=${HTTP_PORT}/${VERSION}/eval_report/eval_report.md
#   else
#     HTTP_LINK=
#   fi

#   send_eval_report_feishu_message \
#     ${FEISHU_HOOK} \
#     ${HTTP_LINK} \
#     ${VERSION} \
#     ${SHARE_EVAL_REPORT_DUMP_ROOT}/eval_report.md
# else
#   echo_error "Error!"
# fi

# cd ${CUR_DIR}
