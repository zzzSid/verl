# -*- coding: utf-8 -*-
"""Utilities."""

import torch


def ckpt_test(ckpt_path=None) -> str:
    """Test ckpt."""
    try:
        _ = torch.load(ckpt_path)
    except Exception as e:
        return f"Error: {e}"

    return "Succeed"
