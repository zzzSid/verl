# -*- coding: utf-8 -*-
# pylint: skip-file
# flake8: noqa
import argparse
import os

from tqdm import tqdm


def generate_video(input_path, output_path, clean_src=False):
    clip_list = os.listdir(input_path)
    os.makedirs(output_path, exist_ok=True)
    for clip in tqdm(clip_list, desc="Generating Video"):
        clip_path = os.path.join(input_path, clip)
        video_path = os.path.join(output_path, clip + ".mp4")

        try:
            os.system(
                f'ffmpeg -y -framerate 5 -pattern_type glob -i "{clip_path}/*.jpg" -c:v libx264 -vf "pad=ceil(iw/2)*2:ceil(ih/2)*2" -pix_fmt yuv420p "{video_path}"'
            )
            if clean_src:
                print(f"Video generate success, start to delete files at {clip_path}.")
                os.system(f"rm -rf {clip_path}/*.jpg")
            else:
                print(f"Video generate success.")
        except Exception as e:
            print(f"Error: {e}")
            continue


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-p", "--input_path", metavar="folder", nargs="?", required=True)
    parser.add_argument("-op", "--output_path", metavar="folder", nargs="?", required=True)
    parser.add_argument("-clean", "--clean_src", action="store_true", default=False)
    args = parser.parse_args()

    generate_video(args.input_path, args.output_path, clean_src=args.clean_src)
