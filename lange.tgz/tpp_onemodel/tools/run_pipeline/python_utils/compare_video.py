# -*- coding: utf-8 -*-
# pylint: skip-file
# flake8: noqa
import argparse
import os

from tqdm import tqdm


def compare_video(video_roots, output_path):
    common_video_list = set()
    for video_root in video_roots:
        if len(common_video_list) == 0:
            common_video_list = set(os.listdir(video_root))
        else:
            common_video_list = common_video_list & set(os.listdir(video_root))
    common_video_list = list(common_video_list)

    os.makedirs(output_path, exist_ok=True)
    for clip in tqdm(common_video_list, desc="Comparing Video"):
        video_path = os.path.join(output_path, clip)

        try:
            input_text = [f"-i {video_root}/{clip}" for video_root in video_roots]
            input_text = " ".join(input_text)
            os.system(
                f'ffmpeg {input_text} -filter_complex "[1]pad=iw:ih+5:0:5[v1];[0][v1]vstack=inputs=2" {video_path}'
            )
            print(f"Generate comparing video success.")
        except Exception as e:
            print(f"Error: {e}")
            continue


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-p", "--input_path", metavar="folder", nargs="?", required=True)
    parser.add_argument("-op", "--output_path", metavar="folder", nargs="?", required=True)
    args = parser.parse_args()

    video_roots = args.input_path.split(",")
    compare_video(video_roots, args.output_path)
