# -*- coding: utf-8 -*-
"""Tools for converting csv to md."""
import argparse
import csv


def gen_base_info(
    version,
    torchpilot_commit_id,
    share_checkpoint_last_path,
    trace_model_path,
    quant_x86_model_path,
    quant_orin_model_path,
    quant_a40_model_path,
) -> str:
    """Generate base info."""
    info_string = ""
    info_string += f"- **Version:** {version}\n"
    info_string += f"- **Melange Commit ID:** {torchpilot_commit_id}\n"
    info_string += f"- **Checkpoint Path:** {share_checkpoint_last_path}\n"
    info_string += f"- **Trace Model Path:** {trace_model_path}\n"
    info_string += "- **Tvm Model Path**\n"
    info_string += f"  - **Ntsctl:** {quant_x86_model_path}\n"
    info_string += f"  - **Orin:** {quant_orin_model_path}\n"
    info_string += f"  - **A40:** {quant_a40_model_path}\n"
    return info_string


def convert_csv_to_md(csv_file_path: str) -> str:
    """Convert csv to md."""
    csv_data = []
    with open(csv_file_path, "r", newline="", encoding="utf-8") as csvfile:
        csvreader = csv.reader(csvfile)
        for row in csvreader:
            csv_data.append(row)

    markdown_table = ""
    markdown_table += "| " + " | ".join(csv_data[0]) + " |\n"
    markdown_table += "| " + " | ".join(["---"] * len(csv_data[0])) + " |\n"
    for row in csv_data[1:]:
        for i_value, value in enumerate(row[2:]):
            if float(value) != int(float(value)):
                row[i_value + 2] = f"{float(row[i_value + 2]):.6f}"
            else:
                row[i_value + 2] = f"{float(row[i_value + 2]):.1f}"
        markdown_table += "| " + " | ".join(row) + " |\n"

    return markdown_table


def convert_csv_to_md_and_compare(csv_file_path: str, base_csv_file_path: str) -> str:
    """Convert csv to md and compare."""

    def get_color(diff, reverse=False):
        if reverse:
            return "green" if diff < 0 else ("black" if diff == 0 else "red")
        else:
            return "green" if diff > 0 else ("black" if diff == 0 else "red")

    csv_data = []
    with open(csv_file_path, "r", newline="", encoding="utf-8") as csvfile:
        csvreader = csv.reader(csvfile)
        for row in csvreader:
            csv_data.append(row)

    base_csv_data = []
    with open(base_csv_file_path, "r", newline="", encoding="utf-8") as csvfile:
        csvreader = csv.reader(csvfile)
        for row in csvreader:
            base_csv_data.append(row)

    markdown_table = ""
    markdown_table += "| " + " | ".join(csv_data[0]) + " |\n"
    markdown_table += "| " + " | ".join(["---"] * len(csv_data[0])) + " |\n"
    for row, row_base in zip(csv_data[1:], base_csv_data[1:]):
        for i_value, value in enumerate(row[2:]):
            diff = float(row[i_value + 2]) - float(row_base[i_value + 2])
            color = get_color(diff, reverse=not ("acc" in row[1] or "similarity" in row[1]))

            if float(value) != int(float(value)):
                row[i_value + 2] = f"<font color={color}>{float(row[i_value + 2]):.6f} ({diff:+.6f})</font>"
            else:
                row[i_value + 2] = f"<font color={color}>{float(row[i_value + 2]):.1f} ({diff:+.1f})</font>"
        markdown_table += "| " + " | ".join(row) + " |\n"

    return markdown_table


def gen_daily_report(
    version,
    torchpilot_commit_id,
    share_checkpoint_last_path,
    trace_model_path,
    quant_x86_model_path,
    quant_orin_model_path,
    quant_a40_model_path,
    csv_file_path_ckpt,
    csv_file_path_ckpt_tiny,
    csv_file_path_trace_tiny,
    csv_file_path_tvm_tiny,
):
    """Generate daily report."""
    report_string = ""
    report_string += "# Astra Planner Model Eval Report\n"

    report_string += "### Base Info\n"
    report_string += gen_base_info(
        version,
        torchpilot_commit_id,
        share_checkpoint_last_path,
        trace_model_path,
        quant_x86_model_path,
        quant_orin_model_path,
        quant_a40_model_path,
    )

    report_string += "### Eval Report of Ckpt\n"
    report_string += "<details>\n"
    report_string += "<summary>details</summary>\n\n"

    report_string += convert_csv_to_md(csv_file_path_ckpt)
    report_string += "\n</details>\n\n"

    report_string += "### Eval Report of Ckpt with Tiny Dataset\n"
    report_string += "<details>\n"
    report_string += "<summary>details</summary>\n\n"

    report_string += convert_csv_to_md(csv_file_path_ckpt_tiny)
    report_string += "\n</details>\n\n"

    report_string += "### Eval Report of Trace Model with Tiny Dataset\n"
    report_string += "<details>\n"
    report_string += "<summary>details</summary>\n\n"

    report_string += convert_csv_to_md_and_compare(csv_file_path_trace_tiny, csv_file_path_ckpt_tiny)
    report_string += "\n</details>\n\n"

    report_string += "### Eval Report of Tvm Model with Tiny Dataset\n"
    report_string += "<details>\n"
    report_string += "<summary>details</summary>\n\n"

    report_string += convert_csv_to_md_and_compare(csv_file_path_tvm_tiny, csv_file_path_trace_tiny)
    report_string += "\n</details>\n\n"

    return report_string


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-v", "--version", type=str, default=None, help="version")
    parser.add_argument("--commit", type=str, default=None, help="torchpilot commit id")
    parser.add_argument("--ckpt", type=str, default=None, help="ckpt path")
    parser.add_argument("--trace", type=str, default=None, help="trace model path")
    parser.add_argument("--ntsctl", type=str, default=None, help="ntsctl tvm model path")
    parser.add_argument("--orin", type=str, default=None, help="orin tvm model path")
    parser.add_argument("--a40", type=str, default=None, help="a40 tvm model path")
    parser.add_argument("--report_ckpt", type=str, default=None, help="report of ckpt")
    parser.add_argument("--report_ckpt_tiny", type=str, default=None, help="report of ckpt with tiny dataset")
    parser.add_argument("--report_trace_tiny", type=str, default=None, help="report of trace model with tiny dataset")
    parser.add_argument("--report_tvm_tiny", type=str, default=None, help="report of tvm model with tiny dataset")
    parser.add_argument("-d", "--dump_path", type=str, default=None, help="dump path")
    args = parser.parse_args()

    report_string = gen_daily_report(
        version=args.version,
        torchpilot_commit_id=args.commit,
        share_checkpoint_last_path=args.ckpt,
        trace_model_path=args.trace,
        quant_x86_model_path=args.ntsctl,
        quant_orin_model_path=args.orin,
        quant_a40_model_path=args.a40,
        csv_file_path_ckpt=args.report_ckpt,
        csv_file_path_ckpt_tiny=args.report_ckpt_tiny,
        csv_file_path_trace_tiny=args.report_trace_tiny,
        csv_file_path_tvm_tiny=args.report_tvm_tiny,
    )
    with open(args.dump_path, "w", encoding="utf-8") as fw:
        fw.write(report_string)
