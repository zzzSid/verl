# -*- coding: utf-8 -*-
# flake8: noqa
import argparse
import json
import os
import re
import time

import requests


def add_retry_postfix(version_name):
    """Add postfix to version name."""
    pattern = r"retry\d+"
    match = re.search(pattern, version_name)
    if not match:
        version_name = version_name + "_retry01"
        retry_time = 1
    else:
        retry_time = int(match.group(0)[-2:]) + 1
        version_name = re.sub(pattern, f"retry{retry_time:0>2d}", version_name, count=1)
    return version_name, retry_time


def post_bundle_job(user_name, version_name, base_bundle_id, integration_branch, argus_model_branch):
    """Post message of bundle job."""
    response_get = requests.get("http://perception-mapping-backend.nioint.com/api/v4/model/manage/templates", data={})

    data_bundle = {}
    data_job = {}
    for i in json.loads(response_get.text)["data"]:
        if i["type"] == "bundle":
            data_bundle = i
        if i["type"] == "job":
            data_job = i

    response_bp = requests.get(
        f"http://perception-mapping-backend.nioint.com/api/v4/model/manage/bundle_project_info?bundle_uuid={base_bundle_id}",
        data={},
    )
    data_bp = json.loads(response_bp.text)["data"]

    table = {
        "version": version_name,
        "torchpolit_commit_id": "",
        "torchpolit_git_repo": data_job["template_config"]["torchpolit_git_repo"],
        "torchpolit_image": data_job["template_config"]["torchpolit_image"],
        "torchpolit_nioflow_cache_branch": data_job["template_config"]["torchpolit_nioflow_cache_branch"],
        "nadp_token": data_job["template_config"]["nadp_token"],
        "node_list": [
            {
                "node_type": "bundle",
                "fw_build": 1,
                "fw_force_build": 1,
                "longmen_test": True,
                "platform_template_id": data_bundle["platform_template_id"],
                "platform_template_name": data_bundle["platform_template_name"],
                "bundle_project": data_bp["project_name"],
                "release_version_id": data_bp["release_version_id"],
                "source_release_id": data_bp["source_release_id"],
                "base_bundle_uuid": str(base_bundle_id),
                "post_integration_branch_tag": integration_branch,
                "argus_model_branch_tag": argus_model_branch,
            }
        ],
        "create_user": user_name,
    }
    response_post = requests.post("http://perception-mapping-backend.nioint.com/api/v4/model/manage/job", json=table)
    return response_post


def build_bundle(user_name, version_name, base_bundle_id, integration_branch, argus_model_branch, max_retry_time=5):
    """Build bundle."""
    while True:
        need_retry = False

        print(f"=> Posting message to oceanus, version name: {version_name}")
        response_post = post_bundle_job(user_name, version_name, base_bundle_id, integration_branch, argus_model_branch)
        response_post = response_post.json()
        job_id = response_post.get("data", None)
        message = response_post.get("message", None)
        if message == "ok":
            print("=> Post message to oceanus succeed.")
        elif "parameter job version is existed version" in message:
            version_name, retry_time = add_retry_postfix(version_name)
            if retry_time > max_retry_time:
                raise RuntimeError("Max retry time exceed. Exiting ...")
            need_retry = True
        else:
            raise NotImplementedError(f"Unknown return message: {message}")

        if need_retry:
            print(f"=> Missing error when posting message to oceanus. Retry {retry_time} ...")
            time.sleep(10)
            continue

        print("=> Waiting for response of oceanus.")
        need_retry = False

        while True:
            try:
                response_monitor = requests.get(
                    f"http://perception-mapping-backend.nioint.com/api/v4/model/manage/job/detail?job_id={job_id}",
                    data={},
                )
                bundle_id = response_monitor.json()["data"]["bundle_uuid"]
                status = response_monitor.json()["data"]["status"]
                if status == 2:
                    print("=> Patch bundle build failed.")
                    version_name, retry_time = add_retry_postfix(version_name)
                    if retry_time > max_retry_time:
                        raise RuntimeError("Max retry time exceed. Exiting ...")
                    need_retry = True
                    break
                if bundle_id is None:
                    print(f"=> Patch bundle building, status: {status} ...")
                    time.sleep(30)
                else:
                    print(f"=> Patch bundle build succeed, status: {status}, bundle_id: {bundle_id}.")
                    return response_monitor.json()["data"]
            except:
                time.sleep(30)

        if need_retry:
            print(f"Missing error when get response of oceanus. Retry {retry_time} ...")
            time.sleep(10)
            continue


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-u", "--user", type=str, required=True, help="user name")
    parser.add_argument("-v", "--version", type=str, required=True, help="version name")
    parser.add_argument("-b", "--base_bundle", type=int, required=True, help="base bundle id")
    parser.add_argument("-i", "--integration", type=str, required=True, help="integration branch")
    parser.add_argument("-m", "--argus_model", type=str, required=True, help="argus model branch")
    parser.add_argument("-d", "--dump_root", type=str, required=True, help="dump root")
    args = parser.parse_args()

    response = build_bundle(args.user, args.version, args.base_bundle, args.integration, args.argus_model)

    dump_path = os.path.join(args.dump_root, "response.json")
    os.makedirs(args.dump_root, exist_ok=True)
    with open(dump_path, "w") as fw:
        json.dump(response, fw)
