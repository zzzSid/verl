#!/bin/bash

set -e

DEVICE_NUM=$1
CFG_PATH=
INFER_TYPE=
RUN_NAME=
DATASET_MODE="test"
CKPT=
CLEAN_SRC=
OUTPUT_DIR="${HOME}/torchpilot_outputs"

while [[ $# -gt 0 ]]; do
  case $1 in
    -it|--infer-type)
      INFER_TYPE="$2"
      shift # past argument
      shift # past value
      ;;
    -n|--run-name)
      RUN_NAME="$2"
      shift # past argument
      shift # past value
      ;;
    -dm|--dataset-mode)
      DATASET_MODE="$2"
      shift # past argument
      shift # past value
      ;;
    -c|--ckpt)
      CKPT="$2"
      shift # past argument
      shift # past value
      ;;
    -clean|--clean_src)
      CLEAN_SRC="--clean_src"
      shift # past argument
      ;;
    -OD|--output-dir)
      OUTPUT_DIR="$2"
      shift # past argument
      shift # past value
      ;;
    -*|--*)
      echo_error "Unknown option *$1*"
      exit 1
      ;;
    *)
      CFG_PATH="$1" # save positional arg
      shift # past argument
      ;;
  esac
done

EXP_BASE_DIR=`echo ${CFG_PATH} | cut -d "/" -f 2`/`echo ${CFG_PATH} | cut -d "/" -f 3`
EXP_DIR=${OUTPUT_DIR}/${EXP_BASE_DIR}/${RUN_NAME}

TORCHPILOT_OUTPUT_DIR=${OUTPUT_DIR} bash run.sh ${DEVICE_NUM} ${CFG_PATH} -it ${INFER_TYPE} -n ${RUN_NAME} -dm ${DATASET_MODE} -c ${CKPT}

pipenv run python tpp_onemodel/tools/run_pipeline/python_utils/convert_to_video.py \
  -p ${EXP_DIR}/visualize \
  -op ${EXP_DIR}/visualize_video \
  ${CLEAN_SRC}
