#!/bin/bash

# Usage:
# bash tpp_onemodel/tools/run_pipeline/submit_trace_quant.sh \
#   ${CFG_PATH} \
#   -c ${CHECKPOINT_PATH}

source $(dirname "$(realpath "$0")")/common_util.sh

CFG_PATH=
VERSION=
CHECKPOINT_PATH=

QUANT_CFG_PATH="tpp_onemodel/tools/run_pipeline/quant/config_fp32.py"
QUANT_EXPORT_BRANCH=
QUANT_COMPILE_BRANCH=
EXPORT_TARGET="ntsctl,orin,a40"
DEPLOY_TYPE="fp16"

USER_NAME=${USER}
LOCAL_OUTPUT_DIR="./export_models"
SHARE_DIR="/share-global/${USER}/release/planner"

while [[ $# -gt 0 ]]; do
  case $1 in
    -v|--version)
      VERSION="$2"
      shift
      shift
      ;;
    -c|--checkpoint_path)
      CHECKPOINT_PATH="$2"
      shift
      shift
      ;;
    -qt_cfg|--quant_cfg_path)
      QUANT_CFG_PATH="$2"
      shift
      shift
      ;;
    --quant_export_branch)
      QUANT_EXPORT_BRANCH="$2"
      shift
      shift
      ;;
    --quant_compile_branch)
      QUANT_COMPILE_BRANCH="$2"
      shift
      shift
      ;;
    -et|--export_target)
      EXPORT_TARGET="$2"
      shift
      shift
      ;;
    -dt|--deploy_type)
      DEPLOY_TYPE="$2"
      shift
      shift
      ;;
    -user|--user_name)
      USER_NAME="$2"
      shift
      shift
      ;;
    -ld|--local_dir)
      LOCAL_OUTPUT_DIR="$2"
      shift
      shift
      ;;
    -sd|--share_dir)
      SHARE_DIR="$2"
      shift
      shift
      ;;
    -*|--*)
      echo "Unknown Option *$1*"
      exit 1
      ;;
    *)
      CFG_PATH="$1"
      shift
      ;;
  esac
done

if [[ -z ${NADP_TOKEN} ]] ; then
  echo_error 'Error: ${NADP_TOKEN} not found. Please add to ${HOME}/.bashrc manually!'
  exit 1
fi

if [[ -z ${VERSION} ]]; then
    TORCHPILOT_COMMIT_ID=`git log -1 --format="%H"`
    TORCHPILOT_COMMIT_ID_SHORT=${TORCHPILOT_COMMIT_ID:0:8}
    VERSION="release_$(date +'%m%d')_${TORCHPILOT_COMMIT_ID_SHORT}"
fi
echo_log "=> Version: ${VERSION}"

LOCAL_OUTPUT_DIR="${LOCAL_OUTPUT_DIR}/${VERSION}"
SHARE_DIR="${SHARE_DIR}/${VERSION}"

TRACE_MODEL_PATH="astra_planner_${VERSION}_traced_model.pt"
TRACE_INPUT_OUTPUT_NAME_PATH="astra_planner_${VERSION}_traced_model_inputs_outputs_info.txt"

if [[ -d ${LOCAL_OUTPUT_DIR} ]]; then
  rm -rf ${LOCAL_OUTPUT_DIR}/ckpt ${LOCAL_OUTPUT_DIR}/trace ${LOCAL_OUTPUT_DIR}/${DEPLOY_TYPE}
else
  mkdir -p ${LOCAL_OUTPUT_DIR}
fi

if [[ -d ${SHARE_DIR} ]]; then
  rm -rf ${SHARE_DIR}/ckpt ${SHARE_DIR}/trace ${SHARE_DIR}/${DEPLOY_TYPE}
else
  mkdir -p ${SHARE_DIR}
fi

echo_log "=> Backup ckpt ..."
mkdir -p ${LOCAL_OUTPUT_DIR}/ckpt
cp ${CHECKPOINT_PATH} ${LOCAL_OUTPUT_DIR}/ckpt
cp -r ${LOCAL_OUTPUT_DIR}/ckpt ${SHARE_DIR}

# trace
echo_log "=> Prepare to dump trace model ..."
echo "trace CFG_PATH: ${CFG_PATH}"
mkdir -p ${LOCAL_OUTPUT_DIR}/trace
pipenv run python tests/end2end/task_planner/exp_planner/planner_trace_stage2_test.py \
  --cfg_path ${CFG_PATH} \
  --ckpt_path ${CHECKPOINT_PATH} \
  --save_path ${LOCAL_OUTPUT_DIR}/trace/${TRACE_MODEL_PATH}
echo_log "=> Trace successed."

echo_log "=> Copy trace model to share-global ..."
cp -r ${LOCAL_OUTPUT_DIR}/trace ${SHARE_DIR}

# tvm
echo_log "=> Prepare to submit quantization job ..."
mkdir -p ${LOCAL_OUTPUT_DIR}/${DEPLOY_TYPE}

EXTRA_ARGS=
if [[ -n ${QUANT_EXPORT_BRANCH} ]]; then
  EXTRA_ARGS="${EXTRA_ARGS} --export_branch ${QUANT_EXPORT_BRANCH}"
fi
if [[ -n ${QUANT_COMPILE_BRANCH} ]]; then
  EXTRA_ARGS="${EXTRA_ARGS} --compile_branch ${QUANT_COMPILE_BRANCH}"
fi
pipenv run python tpp_onemodel/tools/run_pipeline/quant/quantization.py \
  --config_path ${QUANT_CFG_PATH} \
  --model_path ${SHARE_DIR}/trace/${TRACE_MODEL_PATH} \
  --io_info_path ${SHARE_DIR}/trace/${TRACE_INPUT_OUTPUT_NAME_PATH} \
  --dump_path ${LOCAL_OUTPUT_DIR}/${DEPLOY_TYPE} \
  --user_name ${USER_NAME} \
  --nadp_token ${NADP_TOKEN} \
  --task_alias astra_planner_${VERSION} \
  --export_target ${EXPORT_TARGET} \
  --deploy_type ${DEPLOY_TYPE} \
  ${EXTRA_ARGS}
echo_log "=> Convert tvm successed."

echo_log "=> Copy tvm model to share-global ..."
cp -r ${LOCAL_OUTPUT_DIR}/${DEPLOY_TYPE} ${SHARE_DIR}
