set +e

source $(dirname "$(realpath "$0")")/common_util.sh

DEVICE_NUM=$1
CFG_PATH=
INFER_TYPE=
RUN_NAME=
DATASET_MODE="test"
CKPT=
PRIORITY="normal"
GPU_TYPE="a100-15c"
DOCKER_IMAGE="adas-img.nioint.com/nio-pilot/torchpilot:cu114-v2.0.0"
WORKING_DIR=`pwd`
PURPOSETYPE="测评"
L1PURPOSE="Planning 2.0"
OUTPUT_DIR="${HOME}/torchpilot_outputs"

LOG_FREQ=60
TRAINING_SUCCESS_RATE=98
MAX_RETRY_TIME=500

while [[ $# -gt 0 ]]; do
  case $1 in
    -it|--infer-type)
      INFER_TYPE="$2"
      shift # past argument
      shift # past value
      ;;
    -n|--run-name)
      RUN_NAME="$2"
      shift # past argument
      shift # past value
      ;;
    -dm|--dataset-mode)
      DATASET_MODE="$2"
      shift # past argument
      shift # past value
      ;;
    -c|--ckpt)
      CKPT="$2"
      shift # past argument
      shift # past value
      ;;
    -PR|--priority)
      PRIORITY="$2"
      shift # past argument
      shift # past value
      ;;
    -GT|--gpu-type)
      GPU_TYPE="$2"
      shift # past argument
      shift # past value
      ;;
    -I|--image)
      DOCKER_IMAGE="$2"
      shift # past argument
      shift # past value
      ;;
    -WD|--working-dir)
      WORKING_DIR="$2"
      shift # past argument
      shift # past value
      ;;
    -OD|--output-dir)
      OUTPUT_DIR="$2"
      shift # past argument
      shift # past value
      ;;
    -*|--*)
      echo_error "Unknown option *$1*"
      exit 1
      ;;
    *)
      CFG_PATH="$1" # save positional arg
      shift # past argument
      ;;
  esac
done

# 根据 gpu type 和 device num 申请集群资源
IFS=$',' read -r NODE_NUM GPU_NUM CPU_NUM MEM_NUM <<< `get_gpu_node_num ${GPU_TYPE} ${DEVICE_NUM}`

EXP_COMMAND="export TORCHPILOT_OUTPUT_DIR=${OUTPUT_DIR} && \
  bash run.sh ${DEVICE_NUM} ${CFG_PATH} -it ${INFER_TYPE} -n ${RUN_NAME} -dm ${DATASET_MODE} -c ${CKPT}
"

EXP_BASE_DIR=`echo ${CFG_PATH} | cut -d "/" -f 2`/`echo ${CFG_PATH} | cut -d "/" -f 3`
EXP_DIR=${OUTPUT_DIR}/${EXP_BASE_DIR}/${RUN_NAME}

JOB_HAS_FINISHED=false
JOB_HAS_QUEUED=false

while ! $JOB_HAS_FINISHED; do
  if ! $JOB_HAS_QUEUED; then
    echo_log "=> Prepare to submit job ..."

    JOB_COMMAND="ntsctl apply \
      -t job \
      -p ${PRIORITY} \
      -n ${NODE_NUM} \
      -G ${GPU_TYPE}=${GPU_NUM} \
      -C ${CPU_NUM} \
      -M ${MEM_NUM} \
      -i ${DOCKER_IMAGE} \
      -c \"${EXP_COMMAND}\" \
      -D ${WORKING_DIR} \
      -T \"${PURPOSETYPE}\" \
      -1 \"${L1PURPOSE}\" \
      2>&1 \
    "
    echo_log "=> Job command: ${JOB_COMMAND}"

    return_info=$(eval ${JOB_COMMAND})
    echo_log "=> Return info: ${return_info}"
    sleep 10
  else
    while true; do
      echotimestamp "=> Job has been queued. Waitting for job ${alias_name} to be submitted ..."
      queue_info=`ntsctl ps | grep ${alias_name}`
      if [[ -n ${queue_info} ]]; then
        instance_name=`echo ${queue_info} | cut -d " " -f 2`
        echo_log "=> Job ${alias_name} has been submitted! Instance name: ${instance_name}"
        return_info="Instance ${instance_name} has been created!"
        JOB_HAS_QUEUED=false
        sleep 10
        break
      else
        sleep ${LOG_FREQ}
      fi
    done
  fi

  # 监控运行状态
  if [[ ${return_info} =~ "has been created!" ]]; then
    instance_name=`echo ${return_info} | grep -oP "(?<=Instance ).*(?= has been created!)"`
    echo_log "=> Job ${instance_name} has been created!"
    sleep 120

    while true; do
      phase_info=`ntsctl ps | grep ${instance_name} -A 2 | grep -oP "(?<=Phase:).*" | cut -d " " -f 1`
      status_info=`ntsctl ps | grep ${instance_name} -A 2 | grep -oP "(?<=Status:).*" | cut -d " " -f 1`
      log_string="=> Instance: ${instance_name}, Phase: ${phase_info}, Status: ${status_info}"

      IFS=$',' read -r last_step max_step running_progress <<< `get_running_status ${EXP_DIR}`
      if [[ -n ${last_step} ]]; then
        log_string="${log_string}, Progress: ${last_step} / ${max_step} (${running_progress}%)"
      fi
      echotimestamp "${log_string}"

      case ${phase_info} in
        Pending|Running)
          sleep ${LOG_FREQ}
          ;;
        Succeeded)
          echo_log "=> Job ${instance_name} has finished! Exiting ..."
          JOB_HAS_FINISHED=true
          sleep ${LOG_FREQ}
          exit 0
          ;;
        *)
          echo_log "=> Job ${instance_name} has failed."
          exit 1
      esac
    done

  elif [[ ${return_info} =~ "quota exceeded" ]]; then
    echo_log "=> Quota exceeded. Prepare to submit job to queue ..."
    cur_time=`date +"%Y-%m-%d-%H-%M-%S"`
    alias_name="Exp_${RUN_NAME}_${cur_time}"
    JOB_COMMAND="ntsctl apply \
      -t job \
      -p ${PRIORITY} \
      -n ${NODE_NUM} \
      -G ${GPU_TYPE}=${GPU_NUM} \
      -C ${CPU_NUM} \
      -M ${MEM_NUM} \
      -i ${DOCKER_IMAGE} \
      -c \"${EXP_COMMAND}\" \
      --Alias ${alias_name} \
      -D ${WORKING_DIR} \
      -T \"${PURPOSETYPE}\" \
      -1 \"${L1PURPOSE}\" \
      --queue \
      2>&1 \
    "
    echo_log "=> Job command: ${JOB_COMMAND}"

    return_info=$(eval ${JOB_COMMAND})
    echo_log "=> Return info: ${return_info}"

    queue_instance_name=`echo ${return_info} | grep -oP "(?<=request id: ).*"`
    alias_name=`ntsctl queue | grep ${queue_instance_name} -A 100 | tr '\n' ' ' | sed 's/ //g' | sed 's/|//g' | grep -oP "(?<=Alias\":\").*?(?=\")" | head -n 1`
    JOB_HAS_QUEUED=true
    sleep 10

  elif [[ ${return_info} =~ "time interval between two low priority resource application" ]]; then
    echo_log "=> Waiting for 180 seconds ..."
    sleep 180
  fi
done
