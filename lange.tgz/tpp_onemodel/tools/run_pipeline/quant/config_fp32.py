# -*- coding: utf-8 -*-
"""Base config of tf32 quantization job."""

basic_config = {
    "user_token": None,
    "gpu_type": "a100-15c",  # NTS 中的 gpu 类别
    "gpu_cluster": "hlidc",  # NTS 集群
    "task_alias": "astra_planner_release",  # 任务别名
    "cosine_version": "6070",
    "torch_version": "2",
    "l1_purpose": "Planning 2.0",
}

export_config = {
    "export_by": "quantization",
    "target": "a100",
    "branch": "master_2.0",
    "export_type": "common",
    "model_path": None,
    "io_info_path": None,
    "x86_hpc_whl": "1.3.0+g646cc78.planner.torch210",
    "orin_hpc_whl": "1.3.0+g646cc78.planner.torch210",
    "task_config": {
        "input_output_info": None,
        # use_random 和 data_dir 二选一即可
        # "use_random": True,  # 使用随机数据进行推理
        # "data_dir": "/share-global/yanpeng.yin/tmp",  # 部分模型推理耗时对输入数据敏感，需指定真实数据路径，目录下为 npy 或 pkl 格式文件，每个文件内容为 {"inputs_0": npy0, "inputs_1": npy1}
    },
    "export_args": "-tc planner/config_tf32.json",
}

compile_config = {
    "compile_by": "quantization",
    "branch": "master_2.0",
    "type": "release",
    "cross_orin_enable": "true",
    "tune_level": 1,  # 使能快速调优，需与下文 targets 数量一致，如需全量调优，改为 2,2
    "guard_level": 0,
    "profile_level": 0,
    "num_golden": 0,
    "speed_err": -1.0,
    # "runtime_version": "2.0.3.dev87+ga4eb924.develop.6070",
}
