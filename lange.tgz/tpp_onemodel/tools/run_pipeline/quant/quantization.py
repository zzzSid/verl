# -*- coding: utf-8 -*-
import argparse
import json
import os

from msir_pipe import utils
from msir_pipe.client import TaskScheduler
from torchpilot.utils.cfg_parser import PyConfig


def quantization(
    cfg,
    model_path,
    io_info_path,
    user_name,
    nadp_token,
    task_alias,
    export_branch,
    compile_branch,
    export_target,
    deploy_type,
):
    """Submit quantization job."""
    device_type = "cuda"

    basic_config = cfg.basic_config
    basic_config.update(
        {
            "user_token": nadp_token,
            "task_alias": task_alias,
        }
    )

    export_config = cfg.export_config
    export_config.update(
        {
            "model_path": model_path,
            "io_info_path": io_info_path,
        }
    )
    export_config["task_config"]["input_output_info"] = io_info_path
    if export_branch is not None:
        export_config["branch"] = export_branch
    if deploy_type == "fp16":
        export_config["export_args"] = "-tc planner/config_fp16.json"

    compile_config = cfg.compile_config
    if compile_branch is not None:
        compile_config["branch"] = compile_branch

    scheduler = TaskScheduler(
        "perception-planner",
        ("" if device_type == "cuda" else "cpu_") + deploy_type,
        user_name,
        targets=export_target,  # 部署在云上需带上 ntsctl 编出 X86 模型 libs，需要在车上部署则需要 orin 编出 aarch64 的
        basic_config=basic_config,
    )
    scheduler.add_model_task(
        device_type,
        model_path,
        export_config=export_config,
        compile_config=compile_config,
    )
    scheduler._model_requests[device_type]["task_mark"] = "perception-planner"

    return scheduler.trigger(wait_response=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-cfg", "--config_path", type=str, required=True, help="config path")
    parser.add_argument("-m", "--model_path", type=str, required=True, help="trace model path")
    parser.add_argument("-i", "--io_info_path", type=str, required=True, help="io info path")
    parser.add_argument("-d", "--dump_path", type=str, required=True, help="dump path")
    parser.add_argument("-u", "--user_name", type=str, required=True, help="user name")
    parser.add_argument("-t", "--nadp_token", type=str, required=True, help="nadp token")
    parser.add_argument("-a", "--task_alias", type=str, default="astra_planner_release", help="task alias")
    parser.add_argument("-eb", "--export_branch", type=str, default=None, help="export branch")
    parser.add_argument("-cb", "--compile_branch", type=str, default=None, help="compile branch")
    parser.add_argument("-et", "--export_target", type=str, default="ntsctl,orin", help="export target")
    parser.add_argument("-dt", "--deploy_type", type=str, choices=["fp32", "fp16"], help="deploy type")
    args = parser.parse_args()

    export_target = args.export_target
    export_target = export_target.split(",")

    config = PyConfig.fromfile(args.config_path)

    response = quantization(
        cfg=config,
        model_path=args.model_path,
        io_info_path=args.io_info_path,
        user_name=args.user_name,
        nadp_token=args.nadp_token,
        task_alias=args.task_alias,
        export_branch=args.export_branch,
        compile_branch=args.compile_branch,
        export_target=export_target,
        deploy_type=args.deploy_type,
    )

    with open(os.path.join(args.dump_path, "libs_info.json"), "w") as fw:
        json.dump(response, fw)

    libs_info = response["models"]["cuda"]["artifacts"]["compile"]
    for target in export_target:
        _, name, version = libs_info[target + "_libs"].split(":")
        utils.download_file(target, name, version, dst_path=os.path.join(args.dump_path, target + "_" + version))
