#!/bin/bash

# ================================== Global params ==================================

# 实验版本号，必须指定
VERSION="release_20250500_daily"
VERSION_DESCRIPTION=""

# 实验产物路径，必须指定：其中 workspace 用于存放 codebase，local output dir 用于存放实验目录，share dir 用于存放实验产物
WORKSPACE="/home/${USER}/workspace/code/${VERSION}"
LOCAL_OUTPUT_DIR="/home/${USER}/workspace/output/${VERSION}"
SHARE_DIR="/share-global/${USER}/release/planner/${VERSION}"

# NADP Token，必须指定：用于提交量化 job
if [[ -z ${NADP_TOKEN} ]]; then
  echo_error 'Error: ${NADP_TOKEN} not found. Please add to ${HOME}/.bashrc manually!'
  exit 1
fi

# 飞书机器人，必须指定：如果不希望同步消息到任何群，将该项置为空
FEISHU_HOOK="https://open.feishu.cn/open-apis/bot/v2/hook/a7737964-2eea-48f1-99d2-4cab70ad62ef"

# Http 端口，必须指定：如果不希望通过链接分享评测报告，将该项置为空
HTTP_PORT="http://172.22.158.161:8099"

# 其它参数，推荐用默认值
LOG_FREQ=60              # 对训练/评测/update integration 等流程生效，用于控制输出 log 的时间间隔（单位：s）
TRAINING_SUCCESS_RATE=98 # 对训练生效，当训练系统返回失败状态时，如果当前训练进度超过该值，视为训练结束（单位：%）

# ================================== Train params ==================================

# Torchpilot commit id，必须指定
TORCHPILOT_COMMIT_ID="self"
if [ ${TORCHPILOT_COMMIT_ID}x == 'self'x ]; then
  TORCHPILOT_COMMIT_ID=$(git log -1 --format="%H")
fi

if [ ${#TORCHPILOT_COMMIT_ID} -ge 8 ]; then
  TORCHPILOT_COMMIT_ID_SHORT=${TORCHPILOT_COMMIT_ID:0:8}
  echo_log "=> Torchpilot commit id: ${TORCHPILOT_COMMIT_ID_SHORT}"
else
  echo_error "Error: Length of torchpilot commit id must longer than 8."
  exit 1
fi

# Torchpilot 训练指令相关参数，推荐用默认值
TEMPLATE_ID=343 #实验管理训练模板ID，必须指定，通过：https://aip.nioint.com/#/ard/experiment设置管理
CLUSTER="hl-vgpu" # 集群名称，必须指定，可选值：huailai, hl-vgpu, jinshan, tcsh
TRAIN_STAGE1="train-stage1" # 训练模式，必须指定，可选值：train-stage1, train-stage2, 可以添加其他值
DEVICE_NUM=64
CFG_PATH="experiments/task_planner/exp_planner_release/cfg_planner.py"
RUN_NAME="exp_planner_${VERSION}_${TORCHPILOT_COMMIT_ID_SHORT}"
DATASET_MODE="train"
USE_DEFAULT_MODEL=0
DEFAULT_MODEL="/share-global/nell.dong/release/planner/release_20250428_daily/torchpilot_outputs/task_planner/exp_planner_release/exp_planner_release_20250428_daily_84d34b9d/ckpt/checkpoint_last.pth.tar"

# Stage2 训练参数
STAGE2_TEMPLATE_ID=343
STAGE2_CLUSTER="hl-vgpu"
TRAIN_STAGE2="train-stage2"
STAGE2_CFG_PATH="experiments/task_planner/exp_planner_release/cfg_planner_astra_planner_stage2_trainval.py"
STAGE2_USE_DEFAULT_MODEL=1
STAGE2_DEFAULT_MODEL="/share-global/xin.li25/release/planner/release_20250428_beta3/ckpt/checkpoint_fused.pth.tar"

# Ntsctl 相关参数，推荐用默认值
DOCKER_IMAGE="adas-img.nioint.com/nio-pilot/torchpilot:cu114-v2.0.0"
PRIORITY="normal"
GPU_TYPE="a100-15c"
PURPOSETYPE="训练"
L1PURPOSE="Planning 2.0"

# 由现有参数生成的参数，不建议修改
TORCHPILOT_DIR="${WORKSPACE}/melange"

EXP_BASE_DIR=$(echo ${CFG_PATH} | cut -d "/" -f 2)/$(echo ${CFG_PATH} | cut -d "/" -f 3)
EXP_DIR=${LOCAL_OUTPUT_DIR}/torchpilot_outputs/${EXP_BASE_DIR}/${RUN_NAME}
CHECKPOINT_DIR=${EXP_DIR}/ckpt
CHECKPOINT_LAST_PATH=${CHECKPOINT_DIR}/checkpoint_last.pth.tar

# ================================== Trace and quant params ==================================

TRACE_CFG_PATH="experiments/task_planner/exp_planner_release/cfg_planner_astra_planner_stage2_trace.py"

# 由现有参数生成的参数，不建议修改
TRACE_DUMP_ROOT="${LOCAL_OUTPUT_DIR}/trace"
TRACE_MODEL_PATH="${TRACE_DUMP_ROOT}/astra_planner_traced_model.pt"
TRACE_INPUT_OUTPUT_NAME_PATH="${TRACE_DUMP_ROOT}/astra_planner_traced_model_inputs_outputs_info.txt"

# 量化配置，必须指定
QUANT_CFG_PATH="tpp_onemodel/tools/run_pipeline/quant/config_fp32.py"
# 如果指定以下量化分支，会覆盖默认 config 中的分支；如果不希望指定量化分支，则将以下两项置为空
QUANT_EXPORT_BRANCH="BL320_planner_0425"
QUANT_COMPILE_BRANCH="BL320_planner_0425"
QUANT_EXPORT_TARGET="ntsctl,orin,a40"
QUANT_DEPLOY_TYPE="fp16"

QUANT_DUMP_ROOT="${LOCAL_OUTPUT_DIR}/${QUANT_DEPLOY_TYPE}"

# 运行过程中赋值的参数
QUANT_X86_VERSION="Null"
QUANT_ORIN_VERSION="Null"
QUANT_A40_VERSION="Null"

QUANT_X86_MODEL_PATH="Null"
QUANT_ORIN_MODEL_PATH="Null"
QUANT_A40_MODEL_PATH="Null"

# ================================== Integration params ==================================

# base integration 分支，必须指定，但不更新
BASE_INTEGRATION_BRANCH_OR_COMMIT="f573fd4a"

# base model 分支，必须指定
BASE_MODEL_BRANCH_OR_COMMIT="6e4866fe"

# base bundle id，置为空时会跳过 patch bundle 构建，必须指定
BASE_BUNDLE_ID=14451762

# 由现有参数生成的参数，不建议修改
INTEGRATION_DIR="${WORKSPACE}/argus_post_integration"

# 由现有参数生成的参数，不建议修改
INTEGRATION_BRANCH_NAME="feature/planner/${VERSION}"

# 由现有参数生成的参数，不建议修改
MODEL_DIR="${WORKSPACE}/argus_model"

# 运行过程中赋值的参数
MODEL_BRANCH_NAME="feature/planner/${VERSION}"
MODEL_COMMIT_ID="Null"

# 运行过程中赋值的参数
BUNDLE_ID=

# ================================== Eval params ==================================

# 由现有参数生成的参数，不建议修改
CFG_PATH_EVAL_TRACE="experiments/task_planner/exp_planner_release/cfg_planner_trace.py"

EVAL_TEMPLATE_ID=343
EVAL_DEVICE_NUM=8
EVAL_GPU_TYPE="a100-15c"
EVAL_PURPOSETYPE="测评"
EVAL_CLUSTER="hl-vgpu"
EVAL_TRAIN_STAGE="eval-train"

# ================================== Share params ==================================

SHARE_EXP_DIR=${SHARE_DIR}/torchpilot_outputs/${EXP_BASE_DIR}/${RUN_NAME}
SHARE_CHECKPOINT_LAST_PATH=${SHARE_EXP_DIR}/ckpt/checkpoint_last.pth.tar

SHARE_TRACE_DUMP_ROOT="${SHARE_DIR}/trace"
SHARE_TRACE_MODEL_PATH="${SHARE_TRACE_DUMP_ROOT}/astra_planner_${VERSION}_traced_model.pt"
SHARE_TRACE_INPUT_OUTPUT_NAME_PATH="${SHARE_TRACE_DUMP_ROOT}/astra_planner_${VERSION}_traced_model_inputs_outputs_info.txt"

SHARE_QUANT_DUMP_ROOT="${SHARE_DIR}/${QUANT_DEPLOY_TYPE}"

# 运行过程中赋值的参数
SHARE_QUANT_X86_MODEL_PATH="Null"
SHARE_QUANT_ORIN_MODEL_PATH="Null"
SHARE_QUANT_A40_MODEL_PATH="Null"

SHARE_EVAL_REPORT_DUMP_ROOT="${SHARE_DIR}/eval_report"
