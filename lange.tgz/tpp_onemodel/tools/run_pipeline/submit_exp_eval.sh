set +e

source $(dirname "$(realpath "$0")")/common_util.sh

DEVICE_NUM=$1
CLUSTER="hl-vgpu" # 集群名称，可选值：huailai, hl-vgpu, jinshan, tcsh
TASK_LABEL_NAME="Planner模型发版" # 任务标签，配置了可用的quota，目前为
TEMPLATE_ID=343 # 实验平台模板ID，可以去https://aip.nioint.com/#/ard/experiment查看
TRAIN_STAGE="train-eval" # 训练模式，可选值：train-eval, 可以添加其他值
AUTO_RESUME="TRUE"
MAX_RESUME_COUNT=100
CFG_PATH=
INFER_TYPE=
RUN_NAME=
DATASET_MODE="test"
CKPT=
PRIORITY="normal"
GPU_TYPE="a100-15c"
DOCKER_IMAGE="adas-img.nioint.com/nio-pilot/torchpilot:cu114-v2.0.0"
WORKING_DIR=`pwd`
PURPOSETYPE="测评"
L1PURPOSE="Planning 2.0"
OUTPUT_DIR="${HOME}/torchpilot_outputs"

LOG_FREQ=60
TRAINING_SUCCESS_RATE=98
MAX_RETRY_TIME=500

while [[ $# -gt 0 ]]; do
  case $1 in
    -it|--infer-type)
      INFER_TYPE="$2"
      shift # past argument
      shift # past value
      ;;
    -n|--run-name)
      RUN_NAME="$2"
      shift # past argument
      shift # past value
      ;;
    -tid|--template-id)
      TEMPLATE_ID="$2"
      shift # past argument
      shift # past value
      ;;
    -cl|--cluster)
      CLUSTER="$2"
      shift # past argument
      shift # past value
      ;;
    -ts|--train-stage)
      TRAIN_STAGE="$2"
      shift # past argument
      shift # past value
      ;;
    -ar|--auto_resume)
      AUTO_RESUME="$2"
      shift # past argument
      shift # past value
      ;;
    -mrc|--max_resume_count)
      MAX_RESUME_COUNT="$2"
      shift # past argument
      shift # past value
      ;;
    -dm|--dataset-mode)
      DATASET_MODE="$2"
      shift # past argument
      shift # past value
      ;;
    -c|--ckpt)
      CKPT="$2"
      shift # past argument
      shift # past value
      ;;
    -PR|--priority)
      PRIORITY="$2"
      shift # past argument
      shift # past value
      ;;
    -GT|--gpu-type)
      GPU_TYPE="$2"
      shift # past argument
      shift # past value
      ;;
    -I|--image)
      DOCKER_IMAGE="$2"
      shift # past argument
      shift # past value
      ;;
    -WD|--working-dir)
      WORKING_DIR="$2"
      shift # past argument
      shift # past value
      ;;
    -OD|--output-dir)
      OUTPUT_DIR="$2"
      shift # past argument
      shift # past value
      ;;
    -*|--*)
      echo_error "Unknown option *$1*"
      exit 1
      ;;
    *)
      CFG_PATH="$1" # save positional arg
      shift # past argument
      ;;
  esac
done

# 根据 gpu type 和 device num 申请集群资源
IFS=$',' read -r NODE_NUM GPU_NUM CPU_NUM MEM_NUM <<< `get_gpu_node_num ${GPU_TYPE} ${DEVICE_NUM}`

EXP_COMMAND="bash run.sh ${DEVICE_NUM} ${CFG_PATH} -it ${INFER_TYPE} -n ${RUN_NAME} -dm ${DATASET_MODE} -c ${CKPT}"

EXP_BASE_DIR=`echo ${CFG_PATH} | cut -d "/" -f 2`/`echo ${CFG_PATH} | cut -d "/" -f 3`
# EXP_DIR=${OUTPUT_DIR}/${EXP_BASE_DIR}/${RUN_NAME}

EXP_HAS_FINISHED=false
EXP_ID=""
TP_ARTIFACT_OUTPUT_DIR=""

IFS=$',' read -r EXP_ID TP_ARTIFACT_OUTPUT_DIR <<< `load_exp_type_meta ${OUTPUT_DIR} ${RUN_NAME} ${TRAIN_STAGE}`
# 判断TRAIN_STAGE1_EXP_ID是否为整数，如果存在则说明已经提交过训练任务，不然重新提交

if ! [[ ${EXP_ID} =~ ^[0-9]+$ ]] ; then
  echo_log "=> Prepare to submit job ..."
  SUBMIT_EXP_COMMAND="nioml apply \
    --tid ${TEMPLATE_ID} \
    --name \"${RUN_NAME}\" \
    --cluster \"${CLUSTER}\" \
    --priority \"${PRIORITY}\" \
    --node_num ${NODE_NUM} \
    --gpu_type_num \"${GPU_TYPE}=${GPU_NUM}\" \
    --cpu_num ${CPU_NUM} \
    --memory ${MEM_NUM} \
    --image \"${DOCKER_IMAGE}\" \
    --command \"${EXP_COMMAND}\" \
    --working_dir \"${WORKING_DIR}\" \
    --goal \"${PURPOSETYPE}\" \
    --project_name \"${L1PURPOSE}\" \
    --auto_resume \"${AUTO_RESUME}\" \
    --max_resume_count ${MAX_RESUME_COUNT} \
    --task_label_name \"${TASK_LABEL_NAME}\" \
    --env \"TORCHPILOT_OUTPUT_DIR=${OUTPUT_DIR}\" \
  "
  echo_log "=> Submit exp command: ${SUBMIT_EXP_COMMAND}"
  # 执行命令并捕获stdout和stderr到变量，同时获取退出状态码
  return_info=$(eval "${SUBMIT_EXP_COMMAND}" 2>&1)
  exit_code=$?
  # 检查退出状态码
  if [ $exit_code -ne 0 ]; then
      echo_error "=> ${SUBMIT_EXP_COMMAND} 命令执行失败，退出码：$exit_code"
      echo_error "=> 错误信息：$return_info"
      # 在此处添加错误处理逻辑，例如退出脚本或记录日志
      exit $exit_code  # 可选：退出脚本并返回相同的错误码
  fi
  echo_log "=> Return info: ${return_info}"
  sleep 5
  # 上述命令执行后，会返回实验ID，如下：
  # 实验创建成功，实验ID:3312
  # 云端地址：https://aip-dev.nioint.com/#/ard/run/3312/info
  # 需要提取上述的实验ID，用于后续的实验状态查询, 只保留数字部分
  # EXP_ID=`echo ${return_info} | grep -oP "(?<=实验ID:).*?(?=云端地址)"`
  EXP_ID=`echo ${return_info} | sed -n 's/.*实验ID:\([0-9]\+\).*/\1/p'`
  if [[ -z ${EXP_ID} ]]; then
    echo_error "=> Failed to get experiment ID. Exiting ..."
    exit 1
  fi
  echo_log "=> Experiment ${RUN_NAME} ${TRAIN_STAGE} has been submitted. Experiment ID: ${EXP_ID}"
  echo_log "=> Experiment ${RUN_NAME} ${TRAIN_STAGE} has been submitted. Artifacts Path: ${TP_ARTIFACT_OUTPUT_DIR}"
  # 提交成功后，保存实验ID到本地文件
  save_exp_type_meta "${OUTPUT_DIR}" "${RUN_NAME}" "${TRAIN_STAGE}" "${EXP_ID}" "${TP_ARTIFACT_OUTPUT_DIR}"
else
  echo_log "=> Experiment ${RUN_NAME} ${TRAIN_STAGE} has been submitted. Experiment ID: ${EXP_ID}"
  echo_log "=> Experiment ${RUN_NAME} ${TRAIN_STAGE} has been submitted. Artifacts Path: ${TP_ARTIFACT_OUTPUT_DIR}"
fi

while ! $EXP_HAS_FINISHED; do
  # 监控运行状态 nioml detail --eid 2555 --format json
  GET_EXP_COMMAND="nioml detail --eid ${EXP_ID} --format json"
  DETAIL_STR=$(eval ${GET_EXP_COMMAND})
  exit_code=$?
  # 检查退出状态码
  if [ $exit_code -ne 0 ]; then
      echo_error "=> ${GET_EXP_COMMAND} 命令执行失败，退出码：$exit_code"
      echo_error "=> 错误信息：$return_info"
      # 在此处添加错误处理逻辑，例如退出脚本或记录日志
      exit $exit_code  # 可选：退出脚本并返回相同的错误码
  fi
  DETAIL_STR=$(echo "$DETAIL_STR" | convert_to_json | jq -c '.')
  echo_log "=> Experiment detail: ${DETAIL_STR}"
  # 格式验证
  if ! echo "${DETAIL_STR}" | jq empty 2>/dev/null; then
    echo_log "JSON格式验证失败，原始数据开头：${DETAIL_STR:0:100}"
    exit 1
  fi
  # 从返回的str中提取实验状态，如下：
  if [[ ${DETAIL_STR} =~ "status" ]]; then
    auto_resume=`echo ${DETAIL_STR} | jq -r '.auto_resume'`
    max_resume_count=`echo ${DETAIL_STR} | jq -r '.max_resume_count'`
    current_resume_count=`echo ${DETAIL_STR} | jq -r '.current_resume_count'`
    status_info=`echo ${DETAIL_STR} | jq -r '.status'`
    TP_ARTIFACT_OUTPUT_DIR=`echo ${DETAIL_STR} |  jq -r '.local_artifact_path'`
    echo_log "=> ${TRAIN_STAGE} Experiment ${EXP_ID} status: ${status_info}"
    echo_log "=> ${TRAIN_STAGE} Experiment ${EXP_ID} auto_resume: ${auto_resume}, max_resume_count: ${max_resume_count}, current_resume_count: ${current_resume_count}"
    echo_log "=> ${TRAIN_STAGE} Experiment ${EXP_ID} artifact output dir: ${TP_ARTIFACT_OUTPUT_DIR}."

    # 写入实验Meta信息到本地产物文件
    IFS=$',' read -r META_PATH <<< `save_exp_type_meta "${OUTPUT_DIR}" "${RUN_NAME}" "${TRAIN_STAGE}" "${EXP_ID}" "${TP_ARTIFACT_OUTPUT_DIR}"`
    echo_log "=> ${TRAIN_STAGE} Experiment ${EXP_ID} Save experiment meta info to ${META_PATH}"

    case ${status_info} in
      JobInit|Pending|Running)
        echo_error "=> ${TRAIN_STAGE} Experiment ${EXP_ID} status is ${status_info}. Check the progress ..."
        EXP_HAS_FINISHED=false
        sleep ${LOG_FREQ}
        ;;
      WaitingForRetry|RateLimited)
        echo_log "=> ${TRAIN_STAGE} Experiment ${EXP_ID} status is ${status_info}! Please wait ..."
        sleep ${LOG_FREQ}
        ;;
      Succeeded)
        echo_log "=> ${TRAIN_STAGE} Experiment ${EXP_ID} status is ${status_info}! Exiting ..."
        EXP_HAS_FINISHED=true
        ;;
      Failed|Released|AutoReleased)
        if [[ ${auto_resume} -eq "True" ]] && [[ ${current_resume_count} -lt ${max_resume_count} ]]; then
          echo_warning "=> ${TRAIN_STAGE} Experiment ${EXP_ID} status is ${status_info}. auto_resume: ${auto_resume}, Wait to resume (${current_resume_count} / ${max_resume_count}) ..."
          EXP_HAS_FINISHED=false
          sleep ${LOG_FREQ}
        else
          echo_error "=> ${TRAIN_STAGE} Experiment ${EXP_ID} status is ${status_info}. Exiting ..."
          EXP_HAS_FINISHED=true
          exit 1
        fi
        ;;
      Cancelled)
        echo_error "=> ${TRAIN_STAGE} Experiment ${EXP_ID} status is ${status_info}. Exiting ..."
        EXP_HAS_FINISHED=true
        exit 1
        ;;
      LanchFailed)
        echo_error "=> ${TRAIN_STAGE} Experiment ${EXP_ID} status is ${status_info}. Exiting ..."
        EXP_HAS_FINISHED=true
        # 清理meta信息
        # 判断metapath路径是否包含 RUN_NAME, 避免误删其他实验的meta信息
        if [[ ${META_PATH} =~ ${RUN_NAME} ]]; then
          echo_log "=> ${TRAIN_STAGE} Experiment ${EXP_ID} status is ${status_info}. Clean up meta info , rm -rf ${META_PATH} ..."
          rm -rf ${META_PATH}
        fi
        exit 1
        ;;
      *)
        echo_error "${TRAIN_STAGE} Experiment ${EXP_ID} Uncaught status ${status_info}"
        EXP_HAS_FINISHED=true
        exit 1
        ;;
    esac

    echo_log "=> ${TRAIN_STAGE} Experiment ${EXP_ID} log: ${TP_ARTIFACT_OUTPUT_DIR}/${EXP_BASE_DIR}/${RUN_NAME}"
    IFS=$',' read -r last_step max_step running_progress <<< `get_running_status ${TP_ARTIFACT_OUTPUT_DIR}/${EXP_BASE_DIR}/${RUN_NAME}`
    if [[ -n ${last_step} ]]; then
      log_string="=> ${TRAIN_STAGE} Experiment ${EXP_ID} Progress: ${last_step} / ${max_step} (${running_progress}%)"
    fi

    echotimestamp "${log_string}"
    # check if training has nearly finished
    if [[ ${running_progress} -ge ${TRAINING_SUCCESS_RATE} ]]; then
      echo_log "=> ${TRAIN_STAGE} Experiment ${EXP_ID} status is ${status_info}. Training has nearly finished! Exiting ..."
      EXP_HAS_FINISHED=true
      exit 0
    fi
  fi
done
