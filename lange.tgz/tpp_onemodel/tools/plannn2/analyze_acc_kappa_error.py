from glob import glob
from typing import List
import numpy as np
import os
from pathlib import Path
import shutil
import pickle
import matplotlib.pyplot as plt
from tabulate import tabulate
from multiprocessing import Pool
from tqdm import tqdm
import functools
from read_cache_op_py import read_cache_op_py
import random

from tpp_onemodel.data.dataset.plannn2_dataset_utils.data_parser import global_data_parser
from tpp_onemodel.data.dataset.plannn2_dataset import (
    AccKappaVehicleTokenizer,
    cal_acc_kappa_ego_labels,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import (
    normalize_angle,
)


HISTORY_SIZE = 15
TIMESTAMP_SIZE = 41
SEGMENT_LABELS = 2
TRAJ_LEN = (TIMESTAMP_SIZE - HISTORY_SIZE) // SEGMENT_LABELS


def load_frame_data(fname):
    try:
        fname = fname.replace("\t", " ")
        content = fname.split()
        is_pkl = fname.endswith(".pkl") or ".pkl " in fname

        if len(content) == 3:
            ceph_path, filesize, _ = content
            fname = " ".join([ceph_path, filesize])

        # 远程路径情况
        if " " in fname:
            fname = "/" + fname.split(":")[-1]

            try:
                content = read_cache_op_py([fname])[0]
            except Exception as e:
                print(f"[Warning] Remote file not found: {fname}")
                return None

            try:
                data = pickle.loads(content) if is_pkl else global_data_parser.parse(content)
            except Exception as e:
                print(f"[Warning] File parse failed: {fname}")
                return None
        else:
            if not os.path.exists(fname):
                print(f"[Warning] File not exists: {fname}")
                return None

            try:
                if is_pkl:
                    with open(fname, "rb") as f:
                        data = pickle.load(f)
                else:
                    data = global_data_parser.parse(fname)
            except Exception as e:
                print(f"[Warning] File load failed: {fname}")
                return None

        return data

    except Exception as e:
        print(f"[Error] Unexpected error in load_frame_data: {e}")
        return None


def cal_x_y_yaw_k_seq_from_data(fname):
    data = load_frame_data(fname)
    if data is None:
        return []

    timestamps = sorted(data["timestamp_list"])
    timestamps = np.array(timestamps)

    cur_frame_idx = 14
    trajpose0 = data[timestamps[cur_frame_idx]]["car_pose"] # 后轴中心在世界坐标系下的位置
    shift = np.eye(4)  # I
    shift[:3, 3] = [1.4, 0, 0]
    egocenter_pose0 = trajpose0 @ shift # 几何中心在世界坐标系下的位置
    initpose = np.linalg.inv(egocenter_pose0)
    transformed_egocenter_poses = []
    for ts in timestamps:
        ego_pose_backwheel = initpose @ data[ts]["car_pose"]
        transformed_egocenter_poses.append(ego_pose_backwheel @ shift)

    wheel_base = [data[ts]["vehicle_geometry"]["wheel_base"] for ts in timestamps]
    frnt_whl_ag = [data[ts]["vehicle_info"][0]["VehFrontWhlAg"] for ts in timestamps]

    x_y_yaw_k = []
    for idx, egocenter_pose in enumerate(transformed_egocenter_poses):
        whlbase = wheel_base[idx]
        frntwhlag = frnt_whl_ag[idx]
        x = egocenter_pose[0, 3]
        y = egocenter_pose[1, 3]
        yaw = np.arctan2(egocenter_pose[1, 0], egocenter_pose[0, 0])
        k = -1 * np.tan(frntwhlag) / max(1e-6, whlbase)
        x_y_yaw_k.append([x, y, yaw, k])
    return x_y_yaw_k


def generate_all_x_y_yaw_k_seq(
    dataset,
    x_y_yaw_k_save_path,
    regenerate_x_y_yaw_k_seq=True,
    max_files_num=100000,
    processes_num=15,
    timestamp_size=TIMESTAMP_SIZE,
):
    print("Generating x_y_yaw_k sequences...")
    if not regenerate_x_y_yaw_k_seq:
        return

    with open(dataset) as f:
        lines = f.readlines()
    sampled = random.sample(lines, max_files_num)

    processes_num = min(processes_num, len(sampled))
    with Pool(processes=processes_num) as pool:
        x_y_yaw_k = list(tqdm(pool.imap_unordered(cal_x_y_yaw_k_seq_from_data, sampled), total=len(sampled)))
    x_y_yaw_k = [group for group in x_y_yaw_k if len(group) >= timestamp_size]
    with open(x_y_yaw_k_save_path, "wb") as f:
        pickle.dump(x_y_yaw_k, f)


def generate_eval_traj(
    x_y_yaw_k_path,
    eval_traj_save_path,
    vehicle_tokenizer,
    use_filter=True,
    use_trajectory_optimizer=False,
    processes_num=15,
    history_size=HISTORY_SIZE,
    timestamp_size=TIMESTAMP_SIZE,
    segment_labels=SEGMENT_LABELS,
):
    print("Generating acc_kappa sequences...")
    with open(x_y_yaw_k_path, "rb") as f:
        x_y_yaw_k = pickle.load(f)
        print("x_y_yaw_k len:", len(x_y_yaw_k))

    gt_traj_list = []
    optimized_states_list = []
    decoded_states_list = []

    processes_num = min(processes_num, len(x_y_yaw_k))
    func = functools.partial(
        cal_acc_kappa_ego_labels,
        vehicle_tokenizer=vehicle_tokenizer,
        use_filter=use_filter,
        use_trajectory_optimizer=use_trajectory_optimizer,
        history_size=history_size,
        timestamp_size=timestamp_size,
        segment_labels=segment_labels,
    )
    with Pool(processes=processes_num) as pool:
        for _, gt_traj, optimized_states, decoded_states in tqdm(pool.imap_unordered(func, x_y_yaw_k), total=len(x_y_yaw_k)):
            if len(gt_traj) != 0:
                gt_traj_list.append(gt_traj)
                optimized_states_list.append(optimized_states)
                decoded_states_list.append(decoded_states)
    print("generated trajectories len:", len(x_y_yaw_k))
    gt_traj_list = np.array(gt_traj_list, dtype=np.float32)
    optimized_states_list = np.array(optimized_states_list, dtype=np.float32)
    decoded_states_list = np.array(decoded_states_list, dtype=np.float32)

    # [gt_x, gt_y, gt_yaw, gt_k, _gt_v, gt_a, opt_x, opt_y, opt_yaw, opt_v, dec_x, dec_y, dec_yaw, dec_v]
    save_data = np.concatenate([gt_traj_list, optimized_states_list, decoded_states_list], axis=2)
    with open(eval_traj_save_path, 'wb') as file:
        pickle.dump(save_data, file)


class AccKappaAnalyzer:
    def __init__(self, tempalte_set, traj_len=TRAJ_LEN):
        self.traj_len = traj_len
        self.dt = 0.2
        self.vehicle_tokenizer = AccKappaVehicleTokenizer(tempalte_set)


    def reconstruct_traj_and_cal_error(self, data):
        gt_traj = data[:, :6]   # [gt_x, gt_y, gt_yaw, gt_k, _gt_v, gt_a]
        opt_traj = data[:, 6:12] # [opt_x, opt_y, opt_yaw, opt_v]
        dec_traj = data[:, 12:18] # [dec_x, dec_y, dec_yaw, dec_v]

        gt_opt_all_errors = []
        gt_opt_final_errors = []
        gt_dec_all_errors = []
        gt_dec_final_errors = []
        for idx in range(self.traj_len):
            gt_pt = gt_traj[idx]
            opt_pt = opt_traj[idx]
            dec_pt = dec_traj[idx]
            opt_xy_error = np.sqrt((gt_pt[IDX_X] - opt_pt[IDX_X])**2 + (gt_pt[IDX_Y] - opt_pt[IDX_Y])**2)
            opt_x_error = np.abs(gt_pt[IDX_X] - opt_pt[IDX_X])
            opt_y_error = np.abs(gt_pt[IDX_Y] - opt_pt[IDX_Y])
            opt_yaw_error = np.abs(normalize_angle(gt_pt[IDX_YAW] - opt_pt[IDX_YAW]))
            opt_kappa_error = np.abs(gt_pt[IDX_KAPPA] - opt_pt[IDX_KAPPA])
            opt_v_error = np.abs(gt_pt[IDX_V] - opt_pt[IDX_V])
            opt_acc_error = np.abs(gt_pt[IDX_ACC] - opt_pt[IDX_ACC])

            gt_opt_all_errors.append([opt_x_error, opt_y_error, opt_yaw_error, opt_kappa_error, opt_v_error, opt_acc_error, opt_xy_error])

            dec_xy_error = np.sqrt((gt_pt[IDX_X] - dec_pt[IDX_X])**2 + (gt_pt[IDX_Y] - dec_pt[IDX_Y])**2)
            dec_x_error = np.abs(gt_pt[IDX_X] - dec_pt[IDX_X])
            dec_y_error = np.abs(gt_pt[IDX_Y] - dec_pt[IDX_Y])
            dec_yaw_error = np.abs(normalize_angle(gt_pt[IDX_YAW] - dec_pt[IDX_YAW]))
            dec_kappa_error = np.abs(gt_pt[IDX_KAPPA] - dec_pt[IDX_KAPPA])
            dec_v_error = np.abs(gt_pt[IDX_V] - dec_pt[IDX_V])
            dec_acc_error = np.abs(gt_pt[IDX_ACC] - dec_pt[IDX_ACC])
            gt_dec_all_errors.append([dec_x_error, dec_y_error, dec_yaw_error, dec_kappa_error, dec_v_error, dec_acc_error, dec_xy_error])

            if idx == self.traj_len - 1:
                gt_opt_final_errors.append([opt_x_error, opt_y_error, opt_yaw_error, opt_kappa_error, opt_v_error, opt_acc_error, opt_xy_error])
                gt_dec_final_errors.append([dec_x_error, dec_y_error, dec_yaw_error, dec_kappa_error, dec_v_error, dec_acc_error, dec_xy_error])
        return np.array(gt_traj), np.array(opt_traj), np.array(dec_traj), np.array(gt_opt_all_errors), np.array(gt_dec_all_errors), np.array(gt_opt_final_errors), np.array(gt_dec_final_errors)


    def cal_ade_fde(self, gt_opt_all_errors, gt_dec_all_errors, gt_opt_final_errors, gt_dec_final_errors):
        if len(gt_opt_all_errors) == 0 or len(gt_dec_all_errors) == 0 or len(gt_opt_final_errors) == 0 or len(gt_dec_final_errors) == 0:
            print("No error data to calculate metrics.")
            return {}

        gt_opt_all_errors = np.array(gt_opt_all_errors)
        gt_dec_all_errors = np.array(gt_dec_all_errors)
        gt_opt_final_errors = np.array(gt_opt_final_errors)
        gt_dec_final_errors = np.array(gt_dec_final_errors)

        opt_ade = gt_opt_all_errors.mean(axis=(0, 1))
        opt_p99 = np.percentile(gt_opt_all_errors, 99, axis=(0, 1))
        opt_fde = gt_opt_final_errors.mean(axis=(0, 1))
        dec_ade = gt_dec_all_errors.mean(axis=(0, 1))
        dec_p99 = np.percentile(gt_dec_all_errors, 99, axis=(0, 1))
        dec_fde = gt_dec_final_errors.mean(axis=(0, 1))

        metrics = [
            ["mADE_xy", opt_ade[IDX_XY], dec_ade[IDX_XY]],
            ["mADE_x", opt_ade[IDX_X], dec_ade[IDX_X]],
            ["mADE_y", opt_ade[IDX_Y], dec_ade[IDX_Y]],
            ["mADE_yaw", opt_ade[IDX_YAW], dec_ade[IDX_YAW]],
            ["mADE_kappa", opt_ade[IDX_KAPPA], dec_ade[IDX_KAPPA]],
            ["mADE_v", opt_ade[IDX_V], dec_ade[IDX_V]],
            ["mADE_acc", opt_ade[IDX_ACC], dec_ade[IDX_ACC]],
            ["mFDE_xy", opt_fde[IDX_XY], dec_fde[IDX_XY]],
            ["mFDE_x", opt_fde[IDX_X], dec_fde[IDX_X]],
            ["mFDE_y", opt_fde[IDX_Y], dec_fde[IDX_Y]],
            ["mFDE_yaw", opt_fde[IDX_YAW], dec_fde[IDX_YAW]],
            ["mFDE_kappa", opt_fde[IDX_KAPPA], dec_fde[IDX_KAPPA]],
            ["mFDE_v", opt_fde[IDX_V], dec_fde[IDX_V]],
            ["mFDE_acc", opt_fde[IDX_ACC], dec_fde[IDX_ACC]],
            ["p99_xy", opt_p99[IDX_XY], dec_p99[IDX_XY]],
            ["p99_x", opt_p99[IDX_X], dec_p99[IDX_X]],
            ["p99_y", opt_p99[IDX_Y], dec_p99[IDX_Y]],
            ["p99_yaw", opt_p99[IDX_YAW], dec_p99[IDX_YAW]],
            ["p99_kappa", opt_p99[IDX_KAPPA], dec_p99[IDX_KAPPA]],
            ["p99_v", opt_p99[IDX_V], dec_p99[IDX_V]],
            ["p99_acc", opt_p99[IDX_ACC], dec_p99[IDX_ACC]],
            ["count", len(gt_dec_all_errors), len(gt_opt_all_errors)],
        ]

        print(tabulate(metrics, headers=["metrics", "opt", "dec"], tablefmt="grid", colalign=("left", "left", "left")))

        return metrics


    def vis_opt_decode_trajectory(
        self,
        gt_traj,
        opt_traj,
        dec_traj,
        opt_errors,
        dec_errors,
        save_path,
    ):
        """
        gt_traj / opt_traj / dec_traj:
            list of [x, y, yaw, kappa, v, a]

        opt_errors / dec_errors:
            list or array

        save_path:
            output image path
        """

        gt_traj = np.array(gt_traj)
        opt_traj = np.array(opt_traj)
        dec_traj = np.array(dec_traj)

        opt_errors = np.array(opt_errors)
        dec_errors = np.array(dec_errors)

        # 不同轨迹不同 marker
        markers = {
            "gt": "v",
            "opt": "^",
            "dec": "x",
        }

        fig, axes = plt.subplots(2, 3, figsize=(18, 10))

        # ========== 1. XY ==========
        ax = axes[0, 0]
        ax.plot(gt_traj[:, IDX_X], gt_traj[:, IDX_Y], marker=markers["gt"], label="gt")
        ax.plot(opt_traj[:, IDX_X], opt_traj[:, IDX_Y], marker=markers["opt"], label="opt")
        ax.plot(dec_traj[:, IDX_X], dec_traj[:, IDX_Y], marker=markers["dec"], label="dec")
        ax.set_title("XY")
        ax.set_xlabel("x")
        ax.set_ylabel("y")
        ax.axis("equal")
        ax.legend()
        ax.grid(True)

        # ========== 2. yaw ==========
        ax = axes[0, 1]
        ax.plot(gt_traj[:, IDX_YAW], marker=markers["gt"], label="gt")
        ax.plot(opt_traj[:, IDX_YAW], marker=markers["opt"], label="opt")
        ax.plot(dec_traj[:, IDX_YAW], marker=markers["dec"], label="dec")
        ax.set_title("yaw")
        ax.set_xlabel("index")
        ax.legend()
        ax.grid(True)

        # ========== 3. kappa ==========
        ax = axes[0, 2]
        ax.plot(gt_traj[:, IDX_KAPPA], marker=markers["gt"], label="gt")
        ax.plot(opt_traj[:, IDX_KAPPA], marker=markers["opt"], label="opt")
        ax.plot(dec_traj[:, IDX_KAPPA], marker=markers["dec"], label="dec")
        ax.set_title("kappa")
        ax.set_xlabel("index")
        ax.legend()
        ax.grid(True)

        # ========== 4. v ==========
        ax = axes[1, 0]
        ax.plot(gt_traj[:, IDX_V], marker=markers["gt"], label="gt")
        ax.plot(opt_traj[:, IDX_V], marker=markers["opt"], label="opt")
        ax.plot(dec_traj[:, IDX_V], marker=markers["dec"], label="dec")
        ax.set_title("v")
        ax.set_xlabel("index")
        ax.legend()
        ax.grid(True)

        # ========== 5. a ==========
        ax = axes[1, 1]
        ax.plot(gt_traj[:, IDX_ACC], marker=markers["gt"], label="gt")
        ax.plot(opt_traj[:, IDX_ACC], marker=markers["opt"], label="opt")
        ax.plot(dec_traj[:, IDX_ACC], marker=markers["dec"], label="dec")
        ax.set_title("a")
        ax.set_xlabel("index")
        ax.legend()
        ax.grid(True)

        # ========== 6. Errors ==========
        ax = axes[1, 2]
        ax.plot(opt_errors[:, IDX_XY], marker="^", label="xy-opt_errors")
        ax.plot(opt_errors[:, IDX_X], marker="x", label="x-opt_errors")
        ax.plot(opt_errors[:, IDX_Y], marker="v", label="y-opt_errors")
        ax.plot(dec_errors[:, IDX_XY], marker="^", label="xy-dec_errors")
        ax.plot(dec_errors[:, IDX_X], marker="x", label="x-dec_errors")
        ax.plot(dec_errors[:, IDX_Y], marker="v", label="y-dec_errors")
        ax.set_title("Errors")
        ax.set_xlabel("index")
        ax.legend()
        ax.grid(True)

        plt.tight_layout()
        plt.savefig(save_path)
        plt.close(fig)


    def analyze_error_and_vis(self, eval_traj_save_path, vis_save_folder, error_thresh=None, processes_num=15):
        with open(eval_traj_save_path, 'rb') as file:
            data = pickle.load(file)

            processes_num = min(processes_num, len(data))
            results = []
            with Pool(processes=processes_num) as pool:
                for result in tqdm(pool.imap_unordered(self.reconstruct_traj_and_cal_error, data), total=len(data)):
                    results.append(result)

            # 主进程绘图
            gt_opt_all_errors_list = []
            gt_dec_all_errors_list = []
            gt_opt_final_errors_list = []
            gt_dec_final_errors_list = []
            for i, (gt_traj, opt_traj, dec_traj, gt_opt_all_errors, gt_dec_all_errors, gt_opt_final_errors, gt_dec_final_errors) in enumerate(results):
                gt_opt_all_errors_list.append(gt_opt_all_errors)
                gt_dec_all_errors_list.append(gt_dec_all_errors)
                gt_opt_final_errors_list.append(gt_opt_final_errors)
                gt_dec_final_errors_list.append(gt_dec_final_errors)

                max_opt_error = gt_opt_all_errors[:, -1].max()
                max_dec_error = gt_dec_all_errors[:, -1].max()
                if error_thresh is None or max_opt_error > error_thresh or max_dec_error > error_thresh:
                    name = f"{i}.jpg"
                    vis_path = os.path.join(vis_save_folder, name)
                    self.vis_opt_decode_trajectory(
                        gt_traj,
                        opt_traj,
                        dec_traj,
                        gt_opt_all_errors,
                        gt_dec_all_errors,
                        vis_path
                    )

            return self.cal_ade_fde(gt_opt_all_errors_list, gt_dec_all_errors_list, gt_opt_final_errors_list, gt_dec_final_errors_list)


if __name__ == "__main__":
    # 轨迹维度索引定义
    IDX_X = 0
    IDX_Y = 1
    IDX_YAW = 2
    IDX_KAPPA = 3
    IDX_V = 4
    IDX_ACC = 5
    IDX_XY = 6

    REGENERATE_X_Y_YAW_K_SEQ = False
    MAX_FILES_NUM = 10000  # 100000
    CLEAR_HIS_EVAL_VIS = True

    all_dataset = dict(
        pre_train="/share-global/nell.dong/data/planner/planner_basedata_20260301_5856111.txt",
        normal_small="/share-global/charlie.cheng1/melange-plannn2/data/dataset/issues/pln2-225fz-aimless-lc.txt",
        normal="/share-global/xiangwei.geng/plannn2/data/1118/matched/test1000_case_v3_1_new.txt",
        right_left_turn="/share-global/rong.zhang2/plannn2_data/1119_v5_left_right_turn_t_junction_1436.txt",
        turn = "/share-global/menghan.pan/st/plann2_three_point_turn_1124_1_80040.txt",
        right_turn_small = "/share-global/jim.zhou/test/right_turn_small.txt",
    )
    eval_dataset = "pre_train"
    save_folder = "/ephstorage/melange/output/acc_kappa/eval/"

    Path(save_folder).mkdir(parents=True, exist_ok=True)
    metrics_save_path = os.path.join(save_folder, "metrics", "metrics.pkl")
    Path(os.path.dirname(metrics_save_path)).mkdir(parents=True, exist_ok=True)

    vis_save_folder = os.path.join(save_folder, "vis")
    if CLEAR_HIS_EVAL_VIS:
        if os.path.exists(vis_save_folder) and os.path.isdir(vis_save_folder):
            shutil.rmtree(vis_save_folder)
    Path(vis_save_folder).mkdir(parents=True, exist_ok=True)

    tempalte_set = (
        # "/share-global/kent.cheng/acc_kappa_codebook/codebook/acc_kappa_kmeans/data_v2_0_trainset_1280.npy"
        "/share-global/kent.cheng/acc_kappa_codebook/codebook/acc_kappa_kmeans_no_limit/data_v2_0_trainset_1792.npy"
    )

    X_Y_YAW_K_SEQ_PATH = os.path.join(save_folder, "x_y_yaw_k_seq.pkl")
    os.makedirs(os.path.dirname(X_Y_YAW_K_SEQ_PATH), exist_ok=True)
    EVAL_TRAJ_SEQ_PATH = os.path.join(save_folder, "eval_traj_seq.pkl")

    acc_kappa_analyzer = AccKappaAnalyzer(tempalte_set)
    generate_all_x_y_yaw_k_seq(
        dataset=all_dataset[eval_dataset],
        x_y_yaw_k_save_path=X_Y_YAW_K_SEQ_PATH,
        regenerate_x_y_yaw_k_seq=REGENERATE_X_Y_YAW_K_SEQ,
        max_files_num=MAX_FILES_NUM,
        timestamp_size=TIMESTAMP_SIZE,
    )
    generate_eval_traj(
        x_y_yaw_k_path=X_Y_YAW_K_SEQ_PATH,
        eval_traj_save_path=EVAL_TRAJ_SEQ_PATH,
        vehicle_tokenizer=acc_kappa_analyzer.vehicle_tokenizer,
        use_filter=True,
        use_trajectory_optimizer=True,
        history_size=HISTORY_SIZE,
        timestamp_size=TIMESTAMP_SIZE,
        segment_labels=SEGMENT_LABELS,
    )

    metrics = acc_kappa_analyzer.analyze_error_and_vis(eval_traj_save_path=EVAL_TRAJ_SEQ_PATH, vis_save_folder=vis_save_folder, error_thresh=0.2)
    with open(metrics_save_path, "wb") as file:
        pickle.dump(metrics, file)
    exit(0)
