from dataclasses import dataclass
from typing import Optional
from typing import Tuple

import numpy as np


def wrap_angle(angle: np.ndarray) -> np.ndarray:
    return (angle + np.pi) % (2.0 * np.pi) - np.pi


@dataclass
class BeamSearchConfig:
    dt: float = 0.2
    x_weight: float = 1.0
    y_weight: float = 1.0
    yaw_weight: float = 1.0
    v_weight: float = 1.0
    acc_weight: float = 0.0
    kappa_weight: float = 0.0
    jerk_weight: float = 0.0
    dkappa_weight: float = 0.0
    beam_size: int = 64
    min_v: float = 0.0
    max_v: float = 50.0
    min_acc: float = -7.0
    max_acc: float = 3.0
    min_kappa: float = -0.25
    max_kappa: float = 0.25
    ref_control_topk: int = 0
    ref_acc_weight: float = 1.0
    ref_kappa_weight: float = 1.0


class BeamSearchTrajectoryOptimizer:
    def __init__(self, codebook, config: BeamSearchConfig):
        if isinstance(codebook, str):
            self.codebook = np.load(codebook, allow_pickle=True)
        else:
            self.codebook = np.asarray(codebook, dtype=np.float32)
        if self.codebook.ndim != 2 or self.codebook.shape[1] != 2:
            raise ValueError('codebook must have shape (K, 2)')

        self.cfg = config
        self.codebook = np.asarray(self.codebook, dtype=np.float32).copy()
        valid_codebook_mask = self._control_valid_mask(self.codebook)
        self.codebook_indices = np.flatnonzero(valid_codebook_mask).astype(np.int64)
        self.codebook = self.codebook[valid_codebook_mask]
        if self.codebook.shape[0] == 0:
            raise ValueError('codebook has no valid control within configured acc/kappa bounds')
        self.codebook_size = self.codebook.shape[0]
        self.codebook_acc = self.codebook[:, 0]
        self.codebook_kappa = self.codebook[:, 1]

        self.state_weights = np.array([
            self.cfg.x_weight,
            self.cfg.y_weight,
            self.cfg.yaw_weight,
            self.cfg.v_weight,
        ], dtype=np.float32)
        self.control_weights = np.array([self.cfg.acc_weight, self.cfg.kappa_weight], dtype=np.float32)
        self.acc_weight = np.float32(self.cfg.acc_weight)
        self.kappa_weight = np.float32(self.cfg.kappa_weight)
        self.jerk_weight = np.float32(self.cfg.jerk_weight)
        self.dkappa_weight = np.float32(self.cfg.dkappa_weight)
        self.ref_acc_weight = np.float32(self.cfg.ref_acc_weight)
        self.ref_kappa_weight = np.float32(self.cfg.ref_kappa_weight)

    def _candidate_control_indices(self, ref_u: np.ndarray) -> np.ndarray:
        if self.cfg.ref_control_topk <= 0 or self.cfg.ref_control_topk >= self.codebook_size:
            return np.arange(self.codebook_size, dtype=np.int64)

        ref_u = np.asarray(ref_u, dtype=np.float32)
        control_distance = (
            ((self.codebook_acc - ref_u[0]) ** 2) * self.ref_acc_weight
            + ((self.codebook_kappa - ref_u[1]) ** 2) * self.ref_kappa_weight
        )
        keep = min(self.cfg.ref_control_topk, self.codebook_size)
        candidate_idx = np.argpartition(control_distance, keep - 1)[:keep]
        return candidate_idx[np.argsort(control_distance[candidate_idx])].astype(np.int64)

    def _control_valid_mask(self, u: np.ndarray) -> np.ndarray:
        return (
            (u[:, 0] >= self.cfg.min_acc)
            & (u[:, 0] <= self.cfg.max_acc)
            & (u[:, 1] >= self.cfg.min_kappa)
            & (u[:, 1] <= self.cfg.max_kappa)
        )

    def rk4_step_batch(self, x: np.ndarray, u: np.ndarray) -> np.ndarray:
        dt = self.cfg.dt
        acc = u[:, 0]
        kappa = u[:, 1]

        yaw = x[:, 2]
        v = x[:, 3]

        k1_x = v * np.cos(yaw)
        k1_y = v * np.sin(yaw)
        k1_yaw = v * kappa
        k1_v = acc

        yaw_2 = yaw + 0.5 * dt * k1_yaw
        v_2 = v + 0.5 * dt * k1_v
        k2_x = v_2 * np.cos(yaw_2)
        k2_y = v_2 * np.sin(yaw_2)
        k2_yaw = v_2 * kappa
        k2_v = acc

        yaw_3 = yaw + 0.5 * dt * k2_yaw
        v_3 = v + 0.5 * dt * k2_v
        k3_x = v_3 * np.cos(yaw_3)
        k3_y = v_3 * np.sin(yaw_3)
        k3_yaw = v_3 * kappa
        k3_v = acc

        yaw_4 = yaw + dt * k3_yaw
        v_4 = v + dt * k3_v
        k4_x = v_4 * np.cos(yaw_4)
        k4_y = v_4 * np.sin(yaw_4)
        k4_yaw = v_4 * kappa
        k4_v = acc

        x_next = x.copy()
        x_next[:, 0] += (dt / 6.0) * (k1_x + 2.0 * k2_x + 2.0 * k3_x + k4_x)
        x_next[:, 1] += (dt / 6.0) * (k1_y + 2.0 * k2_y + 2.0 * k3_y + k4_y)
        x_next[:, 2] = wrap_angle(yaw + (dt / 6.0) * (k1_yaw + 2.0 * k2_yaw + 2.0 * k3_yaw + k4_yaw))
        x_next[:, 3] = v + (dt / 6.0) * (k1_v + 2.0 * k2_v + 2.0 * k3_v + k4_v)
        return x_next

    def rk4_step_grid(self, x: np.ndarray, u: np.ndarray) -> np.ndarray:
        dt = self.cfg.dt
        acc = u[None, :, 0]
        kappa = u[None, :, 1]

        yaw = x[:, :, 2]
        v = x[:, :, 3]

        k1_x = v * np.cos(yaw)
        k1_y = v * np.sin(yaw)
        k1_yaw = v * kappa
        k1_v = acc

        yaw_2 = yaw + 0.5 * dt * k1_yaw
        v_2 = v + 0.5 * dt * k1_v
        k2_x = v_2 * np.cos(yaw_2)
        k2_y = v_2 * np.sin(yaw_2)
        k2_yaw = v_2 * kappa
        k2_v = acc

        yaw_3 = yaw + 0.5 * dt * k2_yaw
        v_3 = v + 0.5 * dt * k2_v
        k3_x = v_3 * np.cos(yaw_3)
        k3_y = v_3 * np.sin(yaw_3)
        k3_yaw = v_3 * kappa
        k3_v = acc

        yaw_4 = yaw + dt * k3_yaw
        v_4 = v + dt * k3_v
        k4_x = v_4 * np.cos(yaw_4)
        k4_y = v_4 * np.sin(yaw_4)
        k4_yaw = v_4 * kappa
        k4_v = acc

        x_next = x.copy()
        x_next[:, :, 0] += (dt / 6.0) * (k1_x + 2.0 * k2_x + 2.0 * k3_x + k4_x)
        x_next[:, :, 1] += (dt / 6.0) * (k1_y + 2.0 * k2_y + 2.0 * k3_y + k4_y)
        x_next[:, :, 2] = wrap_angle(yaw + (dt / 6.0) * (k1_yaw + 2.0 * k2_yaw + 2.0 * k3_yaw + k4_yaw))
        x_next[:, :, 3] = v + (dt / 6.0) * (k1_v + 2.0 * k2_v + 2.0 * k3_v + k4_v)
        return x_next

    def smooth_cost(self, du: np.ndarray, speed: np.ndarray) -> np.ndarray:
        jerk_cost = (du[..., 0] ** 2) * self.cfg.jerk_weight
        effective_speed = np.maximum(speed, 5.0)
        dkappa_cost = (du[..., 1] ** 2) * self.cfg.dkappa_weight * (effective_speed ** 2)
        return jerk_cost + dkappa_cost

    def control_cost(self, u: np.ndarray, u_ref: np.ndarray) -> np.ndarray:
        control_err = u - u_ref
        return np.sum((control_err ** 2) * self.control_weights, axis=-1)

    def stage_cost(
        self,
        x_next: np.ndarray,
        u: np.ndarray,
        prev_u: np.ndarray,
        x_ref: np.ndarray,
        u_ref: np.ndarray,
    ) -> np.ndarray:
        err = x_next - x_ref[None, :]
        err[:, 2] = wrap_angle(err[:, 2])
        du = u - prev_u[None, :]
        return (
            np.sum((err ** 2) * self.state_weights[None, :], axis=1)
            + self.control_cost(u, u_ref[None, :])
            + self.smooth_cost(du, x_next[:, 3])
        )

    def rollout_segment_batch(self, x: np.ndarray, u: np.ndarray, segment_labels: int) -> np.ndarray:
        x_next = x
        for _ in range(segment_labels):
            x_next = self.rk4_step_batch(x_next, u)
        return x_next

    def rollout_segment_batch_with_valid_mask(
        self,
        x: np.ndarray,
        u: np.ndarray,
        segment_labels: int,
    ) -> Tuple[np.ndarray, np.ndarray]:
        x_next = x
        valid_mask = self._control_valid_mask(u)
        for _ in range(segment_labels):
            x_next = self.rk4_step_batch(x_next, u)
            valid_mask &= (x_next[:, 3] >= self.cfg.min_v) & (x_next[:, 3] <= self.cfg.max_v)
        return x_next, valid_mask

    def rollout_segment_grid_with_valid_mask(
        self,
        x: np.ndarray,
        u: np.ndarray,
        segment_labels: int,
    ) -> Tuple[np.ndarray, np.ndarray]:
        x_next = np.broadcast_to(x[:, None, :], (x.shape[0], u.shape[0], x.shape[1])).copy()
        valid_mask = np.ones((x.shape[0], u.shape[0]), dtype=bool)
        for _ in range(segment_labels):
            x_next = self.rk4_step_grid(x_next, u)
            valid_mask &= (x_next[:, :, 3] >= self.cfg.min_v) & (x_next[:, :, 3] <= self.cfg.max_v)
        return x_next, valid_mask

    def search(
        self,
        x0: np.ndarray,
        ref_traj: np.ndarray,
        segment_labels: int,
        ref_u_traj: Optional[np.ndarray] = None,
        u_prev: Optional[np.ndarray] = None,
    ) -> np.ndarray:
        x0 = np.asarray(x0, dtype=np.float32)
        ref_traj = np.asarray(ref_traj, dtype=np.float32)
        if ref_traj.ndim != 2 or ref_traj.shape[1] != 4:
            raise ValueError('ref_traj must have shape (N, 4)')
        if x0.shape != (4,):
            raise ValueError('x0 must have shape (4,)')
        if len(ref_traj) == 0:
            raise ValueError('ref_traj must be non-empty')
        if segment_labels <= 0:
            raise ValueError('segment_labels must be positive')
        horizon = len(ref_traj) - 1
        if horizon <= 0:
            return np.zeros((0,), dtype=np.int64)
        if ref_u_traj is None:
            ref_u_traj = np.zeros((horizon, 2), dtype=np.float32)
        else:
            ref_u_traj = np.asarray(ref_u_traj, dtype=np.float32)
            if ref_u_traj.shape != (horizon, 2):
                raise ValueError(f'ref_u_traj must have shape ({horizon}, 2)')
        if u_prev is None:
            raise ValueError('u_prev must be provided as the real previous control with shape (2,)')
        u_prev = np.asarray(u_prev, dtype=np.float32)
        if u_prev.shape != (2,):
            raise ValueError('u_prev must have shape (2,)')

        beam_size = min(self.cfg.beam_size, self.codebook_size)
        beam_costs = np.array([0.0], dtype=np.float32)
        beam_states = x0[None, :].copy()
        beam_prev_u = u_prev[None, :].copy()

        parent_history = []
        control_history = []

        for step in range(1, len(ref_traj)):
            ref_u = ref_u_traj[step - 1]
            candidate_idx = self._candidate_control_indices(ref_u)
            candidate_controls = self.codebook[candidate_idx]
            candidate_acc = self.codebook_acc[candidate_idx]
            candidate_kappa = self.codebook_kappa[candidate_idx]

            x_next, valid_mask = self.rollout_segment_grid_with_valid_mask(beam_states, candidate_controls, segment_labels)

            err = x_next - ref_traj[step][None, None, :]
            err[:, :, 2] = wrap_angle(err[:, :, 2])
            control_cost = (
                ((candidate_acc - ref_u[0]) ** 2) * self.acc_weight
                + ((candidate_kappa - ref_u[1]) ** 2) * self.kappa_weight
            )[None, :]
            du_acc = candidate_acc[None, :] - beam_prev_u[:, None, 0]
            du_kappa = candidate_kappa[None, :] - beam_prev_u[:, None, 1]
            effective_speed = np.maximum(x_next[:, :, 3], 5.0)
            stage_cost = (
                np.sum((err ** 2) * self.state_weights[None, None, :], axis=2)
                + control_cost
                + (du_acc ** 2) * self.jerk_weight
                + (du_kappa ** 2) * self.dkappa_weight * (effective_speed ** 2)
            )
            total_cost = beam_costs[:, None] + stage_cost

            valid_flat_mask = valid_mask.reshape(-1)
            if not np.any(valid_flat_mask):
                raise RuntimeError(f'No valid beam node remains at step {step}')

            flat_cost = total_cost.reshape(-1)
            valid_flat_idx = np.flatnonzero(valid_flat_mask)
            valid_flat_cost = flat_cost[valid_flat_idx]
            keep = min(beam_size, valid_flat_cost.shape[0])
            best_valid_idx = np.argpartition(valid_flat_cost, keep - 1)[:keep]
            best_order = np.argsort(valid_flat_cost[best_valid_idx])
            best_flat_idx = valid_flat_idx[best_valid_idx[best_order]]

            candidate_size = candidate_controls.shape[0]
            parent_idx = best_flat_idx // candidate_size
            control_idx = best_flat_idx % candidate_size
            selected_control_idx = candidate_idx[control_idx]

            beam_costs = flat_cost[best_flat_idx].copy()
            beam_states = x_next[parent_idx, control_idx].copy()
            beam_prev_u = candidate_controls[control_idx].copy()

            parent_history.append(parent_idx.copy())
            control_history.append(selected_control_idx.copy())

        best_final = int(np.argmin(beam_costs))
        best_control_ids = np.zeros(horizon, dtype=np.int64)

        cur_idx = best_final
        for step in range(horizon - 1, -1, -1):
            best_control_ids[step] = self.codebook_indices[control_history[step][cur_idx]]
            cur_idx = parent_history[step][cur_idx]

        return best_control_ids
