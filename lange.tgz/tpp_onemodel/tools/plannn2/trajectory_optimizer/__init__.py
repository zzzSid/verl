"""
Trajectory Optimizer Package
Automatically creates symlink on import if needed
"""
import os
import sys
import time
import fcntl
import subprocess

def _is_real_so_file(filepath: str) -> bool:
    """
    检查是否为真正的共享库文件
    """
    if not os.path.exists(filepath):
        return False

    try:
        result = subprocess.run(
            ['file', '--brief', filepath],
            capture_output=True,
            text=True,
            timeout=8
        )

        output = result.stdout.lower()

        if any(x in output for x in [
            'elf', 'shared object', 'dynamically linked',
            'pie executable', 'x86-64', 'arm'
        ]):
            return True

        if any(x in output for x in [
            'ascii text', 'utf-8 text', 'text',
            'git-lfs', 'lfs pointer'
        ]):
            return False

    except Exception as e:
        print(f"get file type error, error: {e}")

    return False

def _create_symlink_if_needed():
    """创建符号链接（如果不存在或需要更新）"""
    print("--------------------_create_symlink_if_needed -------------")
    source = "/share-global/chuanpu.zhang/trajectory_optimizer.cpython-38-x86_64-linux-gnu.so"
    target_dir = os.path.dirname(__file__)
    target = os.path.join(target_dir, "trajectory_optimizer.cpython-38-x86_64-linux-gnu.so")

    print(f"target: {target}")

    lock_file = target + ".lock"

    if not os.path.exists(source):
        print(f"Warning: Source file not found: {source}")
        return False

    if _is_real_so_file(target):
        print(f"Target file is a so file: {target}")
        return True
    else:
        print("Target file is a link file")

    try:
        os.makedirs(os.path.dirname(target), exist_ok=True)
        os.makedirs(os.path.dirname(lock_file), exist_ok=True)

        with open(lock_file, "w") as lock_f:
            try:
                fcntl.flock(lock_f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                time.sleep(0.1)
                fcntl.flock(lock_f.fileno(), fcntl.LOCK_EX)

            if os.path.islink(target) and os.readlink(target) == source:
                fcntl.flock(lock_f.fileno(), fcntl.LOCK_UN)
                print("no need to link ")
                return True
            else:
                print("remove target")
                try:
                    os.remove(target)
                except OSError:
                    pass

            try:
                os.symlink(source, target)
                print(f"Created symlink: {target} -> {source}")
                fcntl.flock(lock_f.fileno(), fcntl.LOCK_UN)
                return True
            except FileExistsError as e:
                fcntl.flock(lock_f.fileno(), fcntl.LOCK_UN)
                print(f"fail to create link, {e}")
                return False

    except Exception as e:
        print(f"Failed to create symlink: {e}")
        return False
    finally:
        try:
            if os.path.exists(lock_file):
                os.remove(lock_file)
        except:
            pass

_create_symlink_if_needed()

from .trajectory_optimizer import *
