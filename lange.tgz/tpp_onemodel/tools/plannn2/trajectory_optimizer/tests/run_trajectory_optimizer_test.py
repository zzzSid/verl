import os
import numpy as np
from typing import List, Tuple, Dict, Any
import matplotlib.pyplot as plt
import time
from dataclasses import dataclass

from tpp_onemodel.tools.plannn2.trajectory_optimizer.trajectory_optimizer import Point
from tpp_onemodel.tools.plannn2.trajectory_optimizer.trajectory_optimizer import run_trajectory_optimizer


@dataclass
class TestResult:
    def __init__(
        self, name: str, reference_traj: List[Point], optimized_traj: List[Point] = None, execution_time: float = 0.0
    ):
        self.name = name
        self.reference_traj = reference_traj
        self.optimized_traj = optimized_traj
        self.execution_time = execution_time

    def __repr__(self):
        return f"TestResult({self.name}, ref_points={len(self.reference_traj)}, opt_points={len(self.optimized_traj) if self.optimized_traj else 0}, time={self.execution_time:.4f}s)"


def test_scenario_1_straight_line():
    """场景1：直线轨迹"""
    print("=" * 50)
    print("场景1：直线轨迹")
    print("=" * 50)

    init_state = Point(0, 0, 0, 0, 1.0, 0, 0, 0)

    reference_traj = []
    for i in range(20):
        x = i * 0.5
        y = 0.0
        heading = 0.0
        speed = 1.0 + i * 0.05
        reference_traj.append(Point(x, y, heading, 0, speed, 0, 0, 0))

    print(f"初始状态: {init_state}")
    print(f"参考轨迹点数: {len(reference_traj)}")

    start_time = time.time()
    try:
        optimized_traj = run_trajectory_optimizer(init_state, reference_traj)
        end_time = time.time()
        execution_time = end_time - start_time

        return TestResult("Straight Line", reference_traj, optimized_traj, execution_time)
    except Exception as e:
        end_time = time.time()
        execution_time = end_time - start_time
        print(f"调用失败: {e}")
        print(f"执行到失败耗时: {execution_time:.6f} 秒")
        return TestResult("Straight Line", reference_traj, None, execution_time)


def test_scenario_2_circular_arc():
    """场景2：圆形弧线轨迹"""
    print("\n" + "=" * 50)
    print("场景2：圆形弧线轨迹")
    print("=" * 50)

    init_state = Point(0, 0, 0, 0.1, 1.0, 0, 0, 0)  # 有一定曲率

    reference_traj = []
    radius = 10.0
    num_points = 30

    for i in range(num_points):
        angle = i * (np.pi) / num_points
        x = radius * (1 - np.cos(angle))
        y = radius * np.sin(angle)
        heading = angle
        kappa = 1.0 / radius
        speed = 1.0
        reference_traj.append(Point(x, y, heading, kappa, speed, 0, 0, 0))

    print(f"初始状态: {init_state}")
    print(f"参考轨迹点数: {len(reference_traj)}")
    print(f"圆弧半径: {radius}")

    start_time = time.time()
    try:
        optimized_traj = run_trajectory_optimizer(init_state, reference_traj)
        end_time = time.time()
        execution_time = end_time - start_time

        return TestResult("Circular Arc", reference_traj, optimized_traj, execution_time)
    except Exception as e:
        end_time = time.time()
        execution_time = end_time - start_time
        print(f"调用失败: {e}")
        print(f"执行到失败耗时: {execution_time:.6f} 秒")
        return TestResult("Circular Arc", reference_traj, None, execution_time)


def test_scenario_3_s_curve():
    """场景3：S型曲线轨迹"""
    print("\n" + "=" * 50)
    print("场景3：S型曲线轨迹")
    print("=" * 50)

    init_state = Point(0, 0, 0, 0, 1.0, 0, 0, 0)

    reference_traj = []
    num_points = 40
    length = 20.0

    for i in range(num_points):
        x = i * (length / num_points)
        y = 2.0 * np.sin(2 * np.pi * x / length)
        dy_dx = 2.0 * (2 * np.pi / length) * np.cos(2 * np.pi * x / length)
        heading = np.arctan(dy_dx)
        d2y_dx2 = -2.0 * (2 * np.pi / length) ** 2 * np.sin(2 * np.pi * x / length)
        kappa = d2y_dx2 / ((1 + dy_dx**2) ** 1.5)
        speed = 1.0 + 0.02 * i
        reference_traj.append(Point(x, y, heading, kappa, speed, 0, 0, 0))

    print(f"初始状态: {init_state}")
    print(f"参考轨迹点数: {len(reference_traj)}")
    print(f"轨迹长度: {length}")

    start_time = time.time()
    try:
        optimized_traj = run_trajectory_optimizer(init_state, reference_traj)
        end_time = time.time()
        execution_time = end_time - start_time

        return TestResult("S Curve", reference_traj, optimized_traj, execution_time)
    except Exception as e:
        end_time = time.time()
        execution_time = end_time - start_time
        print(f"调用失败: {e}")
        print(f"执行到失败耗时: {execution_time:.6f} 秒")
        return TestResult("S Curve", reference_traj, None, execution_time)


def calculate_path_distance(points: List[Point]) -> List[float]:
    if not points:
        return []

    distances = [0.0]
    for i in range(1, len(points)):
        dx = points[i].x - points[i - 1].x
        dy = points[i].y - points[i - 1].y
        distances.append(distances[-1] + np.sqrt(dx * dx + dy * dy))

    return distances


def visualize_trajectories(test_results: List[TestResult]):
    """可视化所有测试结果，包括参考轨迹和优化轨迹"""
    if not test_results:
        print("没有有效的测试结果用于可视化")
        return

    fig, axes = plt.subplots(2, 3, figsize=(16, 10))

    ref_color = "blue"
    opt_color = "red"

    for idx, test_result in enumerate(test_results):
        if idx >= 3:
            break

        if test_result is None or test_result.optimized_traj is None:
            continue

        ax_pos = axes[0, idx]
        ax_speed = axes[1, idx]

        ref_traj = test_result.reference_traj
        opt_traj = test_result.optimized_traj

        ref_x = [p.x for p in ref_traj]
        ref_y = [p.y for p in ref_traj]
        opt_x = [p.x for p in opt_traj]
        opt_y = [p.y for p in opt_traj]

        ref_speed = [p.speed for p in ref_traj]
        opt_speed = [p.speed for p in opt_traj]

        ref_distances = calculate_path_distance(ref_traj)
        opt_distances = calculate_path_distance(opt_traj)

        ax_pos.plot(ref_x, ref_y, "b--", linewidth=1.5, alpha=0.7, label="Reference")
        ax_pos.plot(opt_x, opt_y, "r-", linewidth=2.5, label="Optimized")

        ax_pos.plot(ref_x[0], ref_y[0], "go", markersize=8, label="Start")
        ax_pos.plot(ref_x[-1], ref_y[-1], "bs", markersize=8, label="Ref End")
        ax_pos.plot(opt_x[-1], opt_y[-1], "r*", markersize=10, label="Opt End")

        ax_pos.set_xlabel("X (m)")
        ax_pos.set_ylabel("Y (m)")
        ax_pos.set_title(f"{test_result.name}")
        ax_pos.legend(loc="best", fontsize=9)
        ax_pos.grid(True, alpha=0.3)
        ax_pos.axis("equal")

        if ref_distances and opt_distances:
            ax_speed.plot(ref_distances, ref_speed, "b--", linewidth=1.5, alpha=0.7, label="Ref Speed")
            ax_speed.plot(opt_distances, opt_speed, "r-", linewidth=2.0, label="Opt Speed")

            ax_speed.set_xlabel("Path Distance (m)")
            ax_speed.set_ylabel("Speed (m/s)")
            ax_speed.set_title(f"{test_result.name} - Speed Profile")
            ax_speed.legend(loc="best", fontsize=9)
            ax_speed.grid(True, alpha=0.3)

            max_dist = max(max(ref_distances), max(opt_distances))
            ax_speed.set_xlim([0, max_dist * 1.05])

        stats_text = f"Ref Points: {len(ref_traj)}\nOpt Points: {len(opt_traj)}"
        if len(opt_traj) > 0:
            opt_length = calculate_path_distance(opt_traj)[-1]
            stats_text += f"\nOpt Length: {opt_length:.2f}m"

        stats_text += f"\nTime: {test_result.execution_time*1000:.1f}ms"

        ax_pos.text(
            0.95,
            0.05,
            stats_text,
            transform=ax_pos.transAxes,
            fontsize=8,
            verticalalignment="bottom",
            horizontalalignment="right",
            bbox=dict(boxstyle="round", facecolor="wheat", alpha=0.5),
        )

    for idx in range(len(test_results), 3):
        axes[0, idx].set_visible(False)
        axes[1, idx].set_visible(False)

    plt.tight_layout()

    save_path = os.path.dirname(__file__)
    plt.savefig(f"{save_path}/test_trajectory_optimizer.png", dpi=150, bbox_inches="tight")
    print(f"图像已保存到: {save_path}")

    # 显示图像
    plt.show()


def create_comparison_summary(test_results: List[TestResult]):
    """创建对比总结表格（包含耗时统计）"""
    print("\n" + "=" * 90)
    print("测试结果对比总结")
    print("=" * 90)

    # 表头
    header = f"{'场景名称':<20} {'参考点数':<10} {'优化点数':<10} {'状态':<10} {'优化长度(m)':<12} {'执行时间(ms)':<15} {'每点耗时(µs)':<15}"
    print(header)
    print("-" * 90)

    total_time = 0.0
    successful_tests = 0

    # 数据行
    for result in test_results:
        if result is None:
            continue

        status = "成功" if result.optimized_traj is not None and len(result.optimized_traj) > 0 else "失败"

        if result.optimized_traj:
            opt_length = calculate_path_distance(result.optimized_traj)[-1]
            opt_points = len(result.optimized_traj)
        else:
            opt_length = 0.0
            opt_points = 0

        execution_time_ms = result.execution_time * 1000  # 转换为毫秒

        # 计算每点平均耗时（微秒）
        if opt_points > 0:
            time_per_point_us = (execution_time_ms * 1000) / opt_points  # 转换为微秒/点
        else:
            time_per_point_us = 0.0

        # 统计成功测试的总时间
        if status == "成功":
            total_time += result.execution_time
            successful_tests += 1

        row = (
            f"{result.name:<20} "
            f"{len(result.reference_traj):<10} "
            f"{opt_points:<10} "
            f"{status:<10} "
            f"{opt_length:<12.2f} "
            f"{execution_time_ms:<15.2f} "
            f"{time_per_point_us:<15.2f}"
        )
        print(row)

    print("=" * 90)

    # 总体统计
    if successful_tests > 0:
        avg_time = total_time / successful_tests
        print(f"\n总体统计:")
        print(f"  成功测试数: {successful_tests}")
        print(f"  总执行时间: {total_time:.4f} 秒 ({total_time*1000:.2f} 毫秒)")
        print(f"  平均执行时间: {avg_time:.4f} 秒 ({avg_time*1000:.2f} 毫秒)")

        # 计算FPS（帧率）
        fps = 1.0 / avg_time if avg_time > 0 else float("inf")
        print(f"  估计帧率(FPS): {fps:.2f}")


def run_all_tests():
    """运行所有测试场景"""
    print("开始测试轨迹优化器...")
    print("=" * 60)

    # 存储所有测试结果
    test_results = []

    # 运行三个测试场景
    print(f"\n开始运行测试场景...")

    result1 = test_scenario_1_straight_line()
    test_results.append(result1)

    result2 = test_scenario_2_circular_arc()
    test_results.append(result2)

    result3 = test_scenario_3_s_curve()
    test_results.append(result3)

    # 可视化结果
    visualize_trajectories(test_results)

    # 创建对比总结
    create_comparison_summary(test_results)


def test_simple_case():
    """一个最简单的测试用例，用于调试（包含耗时统计）"""
    print("简单测试用例...")

    # 最简单的输入
    init_state = Point(0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0)

    # 只有5个点的参考轨迹
    reference_traj = [
        Point(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0),
        Point(2.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0),
        Point(3.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0),
        Point(4.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0),
        Point(5.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0),
    ]

    # 调用C++优化函数，并计时
    start_time = time.time()
    try:
        optimized_traj = run_trajectory_optimizer(init_state, reference_traj)
        end_time = time.time()
        execution_time = end_time - start_time

        print(f"成功！返回{len(optimized_traj)}个点")
        print(f"执行耗时: {execution_time:.6f} 秒 ({execution_time*1000:.2f} 毫秒)")

        # 计算每点平均耗时
        if len(optimized_traj) > 0:
            time_per_point_us = (execution_time * 1000000) / len(optimized_traj)
            print(f"每点平均耗时: {time_per_point_us:.2f} 微秒")

        # 创建测试结果
        test_result = TestResult("Simple Test", reference_traj, optimized_traj, execution_time)

        return test_result
    except Exception as e:
        end_time = time.time()
        execution_time = end_time - start_time
        print(f"失败: {e}")
        print(f"执行到失败耗时: {execution_time:.6f} 秒")
        import traceback

        traceback.print_exc()
        return None


if __name__ == "__main__":
    print("轨迹优化器测试脚本")
    print(f"开始时间: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    # 首先尝试简单测试
    print("运行简单测试...")
    simple_result = test_simple_case()

    if simple_result is not None:
        print("\n简单测试成功，开始完整测试...")
        run_all_tests()
    else:
        print("\n简单测试失败，请检查模块导入和函数签名")

    print(f"\n测试结束时间: {time.strftime('%Y-%m-%d %H:%M:%S')}")
