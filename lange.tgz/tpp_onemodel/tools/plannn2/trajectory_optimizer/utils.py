from dataclasses import dataclass
from typing import List
import torch
import matplotlib.pyplot as plt
import numpy as np
import pathlib
import os

from tpp_onemodel.tools.plannn2.trajectory_optimizer.trajectory_optimizer import Point


@dataclass
class TrajectoryOptimizerDebug:
    init_point: Point
    predict_traj: List[Point]
    reference_traj: List[Point]


def convert_tensor_to_trajectory(traj_tensor: torch.Tensor) -> List[List[Point]]:
    """
    traj: a tensor of [B, N, D]
    """
    B, N, _ = traj.shape
    traj = traj_tensor.cpu().numpy()

    trajectory_list: List[List[Point]] = []
    for i in range(B):
        current_traj: List[Point] = []
        for idx, j in enumerate(range(N)):
            pt = traj[i, j, :]
            point = Point(pt[0], pt[1], pt[2], pt[3], pt[4], pt[5], 0.0, 0.0)
            current_traj.append(point)
        trajectory_list.append(current_traj)

    return trajectory_list

def calculate_and_record_optimizer_errors(ref_traj_list, optimized_traj_list, log_path="traj_error_log.txt"):
    all_errors = []

    with open(log_path, "a", encoding="utf-8") as f:
        header = f"{'Window_ID':<10} | {'Mean_Err(m)':<12} | {'Max_Err(m)':<11} | {'RMSE(m)':<10}"
        f.write(header + "\n")
        f.write("-" * 60 + "\n")
        print("\n" + header)
        print("-" * 60)

        for i, (ref_traj, opt_traj) in enumerate(zip(ref_traj_list, optimized_traj_list)):
            min_len = min(len(ref_traj), len(opt_traj))
            if min_len == 0:
                continue

            ref_pts = np.array([[p.x, p.y] for p in ref_traj[:min_len]])
            opt_pts = np.array([[p.x, p.y] for p in opt_traj[:min_len]])

            errors = np.linalg.norm(ref_pts - opt_pts, axis=1)

            m_err = np.mean(errors)
            max_err = np.max(errors)
            rmse_val = np.sqrt(np.mean(errors**2))

            log_line = f"{i:<10} | {m_err:<12.4f} | {max_err:<11.4f} | {rmse_val:<10.4f}"
            print(log_line)
            f.write(log_line + "\n")

            all_errors.append({"mean": m_err, "max": max_err, "rmse": rmse_val})

        if all_errors:
            total_mean_err = np.mean([x["mean"] for x in all_errors])
            total_max_err = np.max([x["max"] for x in all_errors])
            total_rmse = np.mean([x["rmse"] for x in all_errors])

            summary_str = (
                f"{'-' * 60}\n"
                f"{'TOTAL AVG':<10} | {total_mean_err:<12.4f} | {total_max_err:<11.4f} | {total_rmse:<10.4f}\n"
                f"{'-' * 60}"
            )

            print(summary_str)
            f.write(summary_str + "\n")
        else:
            print("警告：未计算任何有效误差数据。")

    print(f"[完成] 详细日志已保存至: {os.path.abspath(log_path)}")
    return all_errors


def draw_traj_optimizer_debug_info(debug_info_list: List[TrajectoryOptimizerDebug], output_dir: str = None) -> None:

    if output_dir is None:
        output_dir = os.path.dirname(os.path.abspath(__file__))

    PLOT_CONFIGS = [
        {"title": "Trajectories", "ylabel": "Y", "xlabel": "X", "is_xy": True},
        {"title": "Speed", "ylabel": "Speed", "data_key": "speeds"},
        {"title": "Acceleration", "ylabel": "Acceleration", "data_key": "accelerations"},
        {"title": "Curvature (Kappa)", "ylabel": "Kappa", "data_key": "kappas"},
        {"title": "Yaw Rate", "ylabel": "Yaw Rate", "data_key": "yaw_rates"},
        {"title": "Yaw", "ylabel": "Yaw", "data_key": "yaw"},
        {"title": "Kappa rate", "ylabel": "Kappa rate", "data_key": "dks"},
        {"title": "Jerk", "ylabel": "Jerk", "data_key": "jerks"},
    ]

    def extract_data(traj_points):
        if not traj_points:
            return None
        t_vals = [0.2 * t for t in range(len(traj_points))]
        return {
            "x": [p.x for p in traj_points],
            "y": [p.y for p in traj_points],
            "speeds": [p.speed for p in traj_points],
            "accelerations": [p.acc for p in traj_points],
            "kappas": [p.kappa for p in traj_points],
            "yaw_rates": [p.kappa * p.speed for p in traj_points],
            "yaw": [p.heading for p in traj_points],
            "dks": [p.dk for p in traj_points],
            "jerks": [p.jerk for p in traj_points],
            "t": t_vals,
        }

    def calculate_bounds(trajectories):
        bounds = [1000, -1000, 1000, -1000]  # x_min, x_max, y_min, y_max
        for traj_data in trajectories:
            if traj_data:
                bounds[0] = min(bounds[0], min(traj_data["x"]))
                bounds[1] = max(bounds[1], max(traj_data["x"]))
                bounds[2] = min(bounds[2], min(traj_data["y"]))
                bounds[3] = max(bounds[3], max(traj_data["y"]))
        return bounds

    for idx, debug_info in enumerate(debug_info_list):
        fig, axes = plt.subplots(2, 4, figsize=(20, 10))
        axes_flat = axes.flatten()

        colors = plt.cm.tab10(np.linspace(0, 1, 10))

        traj1_data = extract_data(debug_info.predict_traj)
        traj2_data = extract_data(debug_info.reference_traj)
        trajectories_data = [(traj1_data, colors[0]), (traj2_data, colors[1])]

        x_min, x_max, y_min, y_max = calculate_bounds([d for d, _ in trajectories_data if d])

        for i, config in enumerate(PLOT_CONFIGS):
            ax = axes_flat[i]

            for traj_data, color in trajectories_data:
                if not traj_data:
                    continue

                if config.get("is_xy", False):
                    ax.plot(traj_data["x"], traj_data["y"], "o-", color=color, linewidth=2, markersize=4)
                else:
                    ax.plot(traj_data["t"], traj_data[config["data_key"]], "o-", color=color, linewidth=2, markersize=4)

            ax.set_xlabel(config.get("xlabel", "Time"))
            ax.set_ylabel(config["ylabel"])
            ax.set_title(config["title"])
            ax.grid(True, alpha=0.3)

            if config.get("is_xy", False):
                max_range = max(y_max - y_min, x_max - x_min) + 2
                center_x, center_y = (x_min + x_max) / 2, (y_min + y_max) / 2
                ax.set_xlim([center_x - max_range / 2, center_x + max_range / 2])
                ax.set_ylim([center_y - max_range / 2, center_y + max_range / 2])
                ax.set_aspect("equal")

        plt.tight_layout()
        file_path = f"{output_dir}/trajectory_optimizer_{idx}.png"
        try:
            plt.savefig(file_path)
            print(f"Save traj optimizer to {file_path}")
        except Exception as e:
            print(f"Save traj optimizer failed, path: {file_path}, error: {e}")
        finally:
            plt.close(fig)
