# -*- coding: utf-8 -*-
"""Run for PB Save."""

import logging
import math
import os
import struct
import torch
import traceback

import numpy as np

from datetime import datetime
from tqdm import tqdm

from torchpilot.utils.plus_manager import load_plus

from torchpilot.utils.cfg_parser import PyConfig
from torchpilot.utils.checkpoint_manager import CheckpointManager
from torchpilot.utils.file_manager import FileManager
from torchpilot.utils.registries import DATALOADER
from torchpilot.utils.registries import TASK_FLOW

from argus_mazu_messages.common.perception.astra_planner_trajectories_pb2 import AstraPlannerAgents
from argus_mazu_messages.common.perception.astra_planner_trajectories_pb2 import AstraTrajectory
from argus_mazu_messages.common.perception.astra_planner_trajectories_pb2 import AstraWayPoint

logger = logging.getLogger(__name__)

SAVE_PB_NAME = "common-perception-astra_planner_agents_post_plannn2.pb.dat"
DT = 0.2
REAR_WHEEL_TO_CENTER = 1.4
SHIFT = np.eye(4)  # I
SHIFT[:3, 3] = [REAR_WHEEL_TO_CENTER, 0, 0]


def save_pb(path, times, pb_rets):
    """Save result to pb."""
    with open(path, "wb") as w:
        for i in range(len(times)):
            sub_ptp_ts = struct.pack("Q", times[i][0])
            pub_ptp_ts = struct.pack("Q", times[i][1])
            sub_utc_ts = struct.pack("Q", times[i][2])
            pub_utc_ts = struct.pack("Q", times[i][3])
            w.write(sub_ptp_ts)
            w.write(pub_ptp_ts)
            w.write(sub_utc_ts)
            w.write(pub_utc_ts)

            ret = pb_rets[i].SerializeToString()
            fsize = struct.pack("Q", len(ret))
            w.write(fsize)
            w.write(ret)


class Plannn2PBInfer:
    def __init__(self, cfg: PyConfig, *args, **kwargs):
        self._cfg = cfg
        self.dataset_kwargs = self._cfg["infer_task_flow"]["dataset_kwargs"]
        self._build()

        FileManager.init(self._cfg._filename, run_name=f"pb_{datetime.now().strftime('%Y%m%dT%H%M%S')}")
        self.pb_out_dir = os.path.join(FileManager.get_export_dir(), "pb")
        os.makedirs(self.pb_out_dir, exist_ok=True)

    def _build(self):
        """Build infer Environment."""
        self._dataloader = DATALOADER.build(self._cfg.infer_dataloader)

        self._taskflow = TASK_FLOW.build(self._cfg.infer_task_flow)
        self._taskflow.cuda()
        self._taskflow.eval()

        self._load_model_file(self._cfg.ckpt["eval_model"])

        self._sample_num_per_gpu = self._dataloader.get_sample_num_per_gpu()
        self._sample_per_epoch = self._dataloader.get_sample_per_epoch()
        self._one_epoch_size = self._dataloader.get_one_epoch_step_per_gpu()
        self._bs_per_gpu = self._dataloader.get_batch_size_per_gpu()
        self._history_size = self._cfg.infer_dataloader["dataset_cfg"]["history_size"]
        self._state_range = self._cfg.infer_task_flow["task_model_cfg"]["infer_cfg"]["state_range"]

        desc = "DataLoader Config:"
        desc += f" sample_num_per_gpu {self._sample_num_per_gpu}"
        desc += f" sample_per_epoch {self._sample_per_epoch}"
        desc += f" one_epoch_step_per_gpu {self._one_epoch_size}"
        desc += f" batch_size_per_gpu {self._bs_per_gpu}"
        desc += f" history_size {self._history_size}"
        desc += f" state_range {self._state_range}"
        logger.info(desc)

    def _load_model_file(self, ckpt_path: str):
        """Load ckpt or resume ckpt."""
        CheckpointManager(
            model=self._taskflow,
            optimizer=None,
            lr_scheduler=None,
            scaler=None,
            save_dir=None,
            pretrain_model=ckpt_path,
            resume=False,
            to_cuda=self._cfg.infer_ckpt.to_cuda,
            ckpt2model_json=self._cfg.infer_ckpt.ckpt2model_json,
            trace_mode=False,
        ).load_model()

    def _get_batch_data(self):
        """Dataloader get batch data."""
        try:
            data = self._dataloader.move_data_to_cuda(self._dataloader.get_batch_data())
            return data
        except Exception:
            traceback.print_exc()
            raise Exception("Dataloader get_batch_data fail")

    def _polygon_to_trajectory(self, polygon):
        """Polygon trans to trajectory."""
        # 坐标系转换（几何中心坐标系转换到后轴中心坐标系）
        N, M, _ = polygon.shape
        polygon4 = np.concatenate([polygon, np.zeros((N, M, 1)), np.ones((N, M, 1))], axis=2)  # [N, M, 4]
        polygon4 = polygon4 @ SHIFT.T
        polygon = polygon4[:, :, :2]  # [N, M, 2]

        center = polygon.mean(axis=1)  # (N, 2)

        front = polygon[:, [1, 2]].mean(axis=1)  # (N, 2)
        back = polygon[:, [0, 3]].mean(axis=1)  # (N, 2)
        diff = front - back  # (N, 2)
        yaw = np.arctan2(diff[:, 1], diff[:, 0]).reshape(-1, 1)  # (N, 1)

        # 从几何中心点转到后轴中心点
        bias_x = -REAR_WHEEL_TO_CENTER * np.cos(yaw)  # (N, 1)
        bias_y = -REAR_WHEEL_TO_CENTER * np.sin(yaw)  # (N, 1)
        point = center + np.concatenate([bias_x, bias_y], axis=1)  # (N, 2)

        trajectory = AstraTrajectory()
        trajectory.trajectory_scene_type = 50  # 默认都在城区场景
        last_x, last_y, last_yaw = 0, 0, 0
        for i in range(N):
            waypoint = AstraWayPoint()
            waypoint.position.x = point[i, 0]
            waypoint.position.y = point[i, 1]
            waypoint.position.z = 0

            waypoint.yaw = yaw[i, 0]

            dx = waypoint.position.x - last_x
            dy = waypoint.position.y - last_y
            dyaw = waypoint.yaw - last_yaw
            dxy = math.hypot(dx, dy)

            waypoint.yaw_rate = dyaw / DT
            waypoint.speed = dxy / DT
            waypoint.kappa = dyaw / (dxy + 1e-4)

            trajectory.trajectory.append(waypoint)

            last_x = waypoint.position.x
            last_y = waypoint.position.y
            last_yaw = waypoint.yaw

        for i in range(N):
            speed_i = trajectory.trajectory[i].speed
            speed_j = trajectory.trajectory[min(i + 1, N - 1)].speed
            acc = (speed_j - speed_i) / DT
            trajectory.trajectory[i].acceleration = acc

        return trajectory

    def _turnlightsignal_to_turn_indicator(self, turnlightsignal):
        """TurnLightSignal trans to turn_indicator_req."""
        turn_indicator_reqs = []
        if turnlightsignal is None:
            return turn_indicator_reqs
        N = turnlightsignal.shape[0]
        for i in range(N):
            turn_indicator_req = AstraPlannerAgents.TurnIndicatorTypeInfo()
            turn_indicator_req.turn_indicator_type = 0
            turn_indicator_req.turn_indicator_direction = turnlightsignal[i]
            turn_indicator_reqs.append(turn_indicator_req)
        return turn_indicator_reqs

    def _result_to_pb_frame(self, index, timestamp, v3_ceph, polygon, turnlightsignal):
        """Model result trans to pb frame."""
        pb_frame = AstraPlannerAgents()

        ego_trajectory = self._polygon_to_trajectory(polygon)
        pb_frame.marginal_ego_trajectories.append(ego_trajectory)

        turn_indicator_reqs = self._turnlightsignal_to_turn_indicator(turnlightsignal)
        pb_frame.turn_indicator_req.extend(turn_indicator_reqs)

        pb_frame.timestamp = timestamp
        pb_frame.publish_ptp_ts = timestamp
        pb_frame.publish_ts = timestamp
        pb_frame.counter = index
        pb_frame.publisher_id = v3_ceph

        return pb_frame

    def process(self, tqdm_disable=False):
        """Process model infer and result save."""
        self._dataloader.reset()
        for _ in tqdm(range(0, self._one_epoch_size), desc="batch progress", disable=tqdm_disable):
            data = self._get_batch_data()
            res = self._taskflow.forward_model_rl(data)

            v3_ceph = res["raw_env_list"][0][self._history_size]["v3_ceph"]
            uuid = v3_ceph.split("/")[3].split("_")[0]
            save_root = os.path.join(self.pb_out_dir, uuid)
            os.makedirs(save_root, exist_ok=True)
            save_path = os.path.join(save_root, SAVE_PB_NAME)

            frame_polygons = res["frame_polygons"][0].cpu().numpy() * self._state_range
            if "frame_turnlightsignal" in res:
                frame_turnlightsignal = res["frame_turnlightsignal"][0].cpu().numpy()
            else:
                frame_turnlightsignal = None

            size = len(frame_polygons)
            use_timestamps = res["raw_env_list"][0][self._history_size]["use_timestamps"]
            pb_frames, times = [], []
            for index in range(size):
                polygon = frame_polygons[index]  # [N, 4, 2]
                if frame_turnlightsignal is not None:
                    turnlightsignal = frame_turnlightsignal[index]  # [L]
                else:
                    turnlightsignal = None
                timestamp = int(use_timestamps[self._history_size + index] * 1e9)
                pb_frames.append(self._result_to_pb_frame(index, timestamp, v3_ceph, polygon, turnlightsignal))
                times.append([timestamp] * 4)
            save_pb(save_path, times, pb_frames)
            logger.info(f"\033[93mSave PB File {save_path}\033[0m")


if __name__ == "__main__":
    load_plus()
    torch.distributed.init_process_group(
        backend="nccl",
        init_method="tcp://localhost:9999",
        world_size=1,
        rank=0,
    )

    cfg_path = "experiments/task_planner/exp_plannn2/cfg_plannn2_rl_pb.py"
    cfg = PyConfig.fromfile(cfg_path)
    infer_pb = Plannn2PBInfer(cfg)
    infer_pb.process()
