# -*- coding: utf-8 -*-
import torch
from torchpilot import logger
import os

plannn2_model_path = "/data-algorithm-hl/junxuan.chen/work/plannn2/out/planner6_v3_0604_fulldata_1339/ckpt.pt"
tp_model_template_path = (
    "/share-global/xiangwei.geng/plannn2/model/0828_tp_plannn2_template/checkpoint_epoch000_step0001.pth.tar"
)

tp_new_model_dump_path = "tmp/plannn2_to_tp_checkpoint.pth.tar"


plannn2_model = torch.load(plannn2_model_path)["model"]
tp_model_all = torch.load(tp_model_template_path)
tp_model = tp_model_all["model"]

plannn2_in_tp_keys = {f"module._task_model.{k}": v for k, v in plannn2_model.items()}
plannn2_model_keys = plannn2_in_tp_keys.keys()

if not len(plannn2_model.keys()) == len(tp_model.keys()):
    raise ValueError(
        f"Key number mismatch: plannn2 has {len(plannn2_model.keys())} keys, tp has {len(tp_model.keys())} keys"
    )

for key in plannn2_in_tp_keys:
    if not torch.allclose(torch.tensor(plannn2_in_tp_keys[key].shape), torch.tensor(tp_model[key].shape)):
        raise ValueError(
            f"Shape mismatch for key {key}: plannn2 shape {plannn2_in_tp_keys[key].shape}, tp shape {tp_model[key].shape}"
        )
    tp_model[key] = plannn2_in_tp_keys[key]
tp_model_all["model"] = tp_model

if os.path.exists(tp_new_model_dump_path):
    raise ValueError(f"File {tp_new_model_dump_path} already exists. Please remove it before running this script.")

torch.save(tp_model_all, tp_new_model_dump_path)
logger.warning("Model transformation complete. Saved to %s", tp_new_model_dump_path)
