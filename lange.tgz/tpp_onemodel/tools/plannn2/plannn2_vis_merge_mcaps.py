import json
import os
import urllib.parse
from uuid import uuid4

from tpp_onemodel.tools.loader.ceph import client as niofs_client


def merge_mcap(mcaps):
    merged = {}
    prefix_mapping = {}
    for i, mcap in enumerate(mcaps):
        mcap_cos, mcap_key = niofs_client.divide_niofs_path(mcap)
        access_url = niofs_client.generate_presigned_url(mcap_cos, mcap_key, expiration=604800)
        prefix = mcap.split("-")[-1][:-5]
        prefix_mapping[prefix] = f"vis{i}"
        merged[f"vis{i}"] = access_url

    uuid = f"merged_{uuid4()}"
    out_bucket = "ad-cn-hlidc-fdm-algo3-infra"
    out_path = f"plannn2_visualization/{os.environ.get('USER', 'anon')}/{uuid}.json"
    with niofs_client.open(out_bucket, out_path, "w") as output_file:
        json.dump(merged, output_file)
    access_url = niofs_client.generate_presigned_url(out_bucket, out_path, expiration=604800)
    mapping_arg = urllib.parse.quote(json.dumps(prefix_mapping, separators=(',', ':')))
    access_url = f"https://adviz.nioint.com/?ds=x-mcaps&mapping={mapping_arg}&ds.url={urllib.parse.quote(access_url)}"
    return access_url


if __name__ == "__main__":
    ret = merge_mcap([
        "huailai:ad-cn-hlidc-fdm-algo3-infra/plannn2_visualization/lin.zhao/372f67ce-1512-41c6-a011-d58e91477a40-v55663dea954949f8be0c71338542107c.mcap",
        "huailai:ad-cn-hlidc-fdm-algo3-infra/plannn2_visualization/lin.zhao/3b2f7b81-12cc-4545-b45e-0a426d96c1e6-ve707b753fa0449708480bf9397b4ec99.mcap",
        "huailai:ad-cn-hlidc-fdm-algo3-infra/plannn2_visualization/lin.zhao/372f67ce-1512-41c6-a011-d58e91477a40-v95515de16efc427b98555373f069d865.mcap",
    ])
    print(ret)