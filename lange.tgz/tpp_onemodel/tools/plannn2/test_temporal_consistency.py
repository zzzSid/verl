import os

import matplotlib.cm as cm
import matplotlib.colors as mcolors
import matplotlib.pyplot as plt
import numpy as np


class Clip():
    def __init__(self, clip_path, xy_range=400):
        self.clip_path = clip_path
        self.pred_trajs = np.load(f'{clip_path}').mean(axis=2) * xy_range
        # self.pred_trajs = np.load(f'{clip_path}').mean(axis=2)

        self.traj_len = self.pred_trajs.shape[0]
        self.uuid = clip_path.split('/')[-1].split('.')[0]
        self.eval_metric = {
            "lat_distance": [],
            "long_distance": [],
            "num": 0,
        }

    def update_eval_metric(self, lat_distance, long_distance):
        self.eval_metric["lat_distance"].append(lat_distance)
        self.eval_metric["long_distance"].append(long_distance)

    def get_eval_metric(self):
        self.eval_metric["lat_distance"] = np.array(self.eval_metric["lat_distance"])
        self.eval_metric["long_distance"] = np.array(self.eval_metric["long_distance"])

        diff = []
        for x in self.eval_metric["lat_distance"]:
            if (x < 0).sum() > (x > 0).sum():
                diff.append(-1)
            else:
                diff.append(1)
        diff = np.array(diff)


        self.eval_metric["lat_distance"] = np.abs(self.eval_metric["lat_distance"])
        self.eval_metric["long_distance"] = np.abs(self.eval_metric["long_distance"])

        idx = self.eval_metric["lat_distance"] > 0.4
        self.eval_metric["lat_distance"][~idx] = 0
        self.eval_metric["lat_distance_valid"] = self.eval_metric["lat_distance"].sum(1) / (idx.sum(1) + 1e-9)
        self.eval_metric["lat_err"] = int(self.eval_metric["lat_distance_valid"].sum())
        self.eval_metric["lat_num"] = (self.eval_metric["lat_distance_valid"] > 0).sum()

        diff[idx.sum(1) ==0] = 0
        last_idx, last_diff = -1, 0
        for i in range(len(diff)):
            if diff[i] == 0:
                continue
            if last_idx == -1:
                last_idx, last_diff = i, diff[i]
                continue
            if last_diff * diff[i] < 0 and i - last_idx < 10:
                self.eval_metric["num"] += 1
            last_idx, last_diff = i, diff[i]

        self.eval_metric["long_err"] = int(np.abs(self.eval_metric["long_distance"]).sum())


class Eval():
    def __init__(self, root, thres_dis=[0.2, 0.5, 1.5], thres_time=2, fps=5, vis=False, percentile=[10, 50, 90, 95, 99]):
        self.root = root
        self.thres_dis = thres_dis
        self.thres_time = thres_time
        self.fps = fps
        self.vis = vis
        self.percentile = percentile

        os.makedirs(f'{self.root}/vis', exist_ok=True)
        self.clip_list = sorted([x for x in os.listdir(f'{root}/trajs') if x.endswith('.npy')])
        self.clips = []

    def eval(self):
        """ 主入口函数 """
        print(f"Start Evaluation on {len(self.clip_list)} clips...")

        # 清理旧日志
        if os.path.exists(f'{self.root}/eval_details.txt'):
            os.remove(f'{self.root}/eval_details.txt')

        for clip_name in self.clip_list:
            clip_path = os.path.join(self.root, 'trajs', clip_name)
            # 假设 Clip 类负责加载数据，这里简单模拟
            clip = Clip(clip_path)

            if clip.pred_trajs is None:
                print(f'Invalid clip: {clip_name}')
                continue

            self._eval_one_clip(clip)
            self.clips.append(clip)

        self._summary()

    def _eval_one_clip(self, clip):
        """ 处理单个 Clip 的核心流程 """
        lat_dists_all = []
        long_dists_all = []

        # 1. 逐帧计算偏差
        for i in range(clip.traj_len - 1):
            # 核心逻辑：上一帧的[1:] vs 当前帧的[:-1]
            prev_segment = clip.pred_trajs[i][1:]
            curr_segment = clip.pred_trajs[i+1][:-1]

            lat, longi = self._compute_frame_deviation(prev_segment, curr_segment)
            lat_dists_all.append(lat)
            long_dists_all.append(longi)

        # 2. 统计该 Clip 的指标 (跳变次数、摆动次数等)
        clip_metrics = self._calculate_clip_metrics(lat_dists_all, clip.uuid, clip)
        clip.eval_metric.update(clip_metrics)

        # 3. 可视化 (可选)
        if self.vis:
            # if clip.uuid == '83_3447c6df-fa6f-4f35-95c3-19980e961852_0':
            if clip.uuid == '1_eeb6f455-7015-417e-b241-1c378b484747_0':

                self._vis_one_clip(clip)

    def _compute_frame_deviation(self, prev_traj, cur_traj):
        """
        核心算法：计算两段轨迹的横向与纵向偏差
        使用 np.gradient 实现全向量化计算，无需循环
        """
        # 计算切向 (Tangent) - 中心差分
        tangents = np.gradient(prev_traj, axis=0)

        # 归一化
        norms = np.linalg.norm(tangents, axis=1, keepdims=True)
        norms[norms < 1e-6] = 1.0
        tangent_dirs = tangents / norms

        # 计算横向方向 (逆时针旋转90度)
        lateral_dirs = np.stack([-tangent_dirs[:, 1], tangent_dirs[:, 0]], axis=1)

        # 偏差向量
        diff_vecs = cur_traj - prev_traj

        # 投影
        lat_dists = np.sum(diff_vecs * lateral_dirs, axis=1)
        long_dists = np.sum(diff_vecs * tangent_dirs, axis=1)

        return lat_dists, long_dists

    def _calculate_clip_metrics(self, lat_distance_list, uuid, clip):
        """
        统计逻辑：根据不同阈值计算 Max 偏差、Change 次数、Shake 次数
        """
        eval_metric = {}
        if not lat_distance_list:
            return {}

        # 转为矩阵: (Frames x Points)
        lat_matrix = np.array(lat_distance_list)

        # 1. 计算每一帧的最大绝对偏差
        max_abs_dev = np.max(np.abs(lat_matrix), axis=1)

        # 原逻辑：取绝对值最大的点的符号 -> 容易受单个离群点影响
        # 新逻辑：取该帧所有点的平均值的符号 -> 代表整体侧向趋势
        # =======================================================
        frame_means = np.mean(lat_matrix, axis=1)
        frame_signs = np.sign(frame_means)
        # 意味着：只有当整条轨迹平均偏离超过 5cm 时，我们才认为它有一个明确的方向
        frame_signs[np.abs(frame_means) < 0.15] = 0

        # 针对每个阈值统计
        for thres in self.thres_dis:
            # Mask: 哪些帧是不稳定的
            is_unstable = max_abs_dev > thres

            # 基础指标
            valid_devs = max_abs_dev[is_unstable]
            eval_metric[f"lat_distance_valid_{thres}"] = valid_devs
            eval_metric[f"lat_change_num_{thres}"] = is_unstable.sum()

            change_num = is_unstable.sum()
            eval_metric[f"lat_change_num_{thres}"] = change_num

            # 摆动检测 (Shake Logic)
            shake_cnt = 0
            last_flip_idx = -999
            last_sign = 0

            for i in range(len(frame_signs)):
                # 只关注不稳定的帧，且方向明确的
                if not is_unstable[i] or frame_signs[i] == 0:
                    continue

                curr_sign = frame_signs[i]

                # 初始化
                if last_sign == 0:
                    last_sign = curr_sign
                    continue

                # 检测反转 (Flip)
                if curr_sign != last_sign:
                    if (i - last_flip_idx) <= 10:
                        # if uuid == '83_3447c6df-fa6f-4f35-95c3-19980e961852_0' and thres == 1.5:
                        if uuid == '1_eeb6f455-7015-417e-b241-1c378b484747_0' and thres == 1.5:
                            print(i, last_flip_idx, curr_sign, last_sign)
                        shake_cnt += 1

                    last_flip_idx = i
                    last_sign = curr_sign

            eval_metric[f"lat_shake_num_{thres}"] = shake_cnt

            lat_err = int(np.sum(valid_devs)) if len(valid_devs) > 0 else 0

            # 格式：uuid: change_num | shake_num | lat_err
            info_str = f"{uuid}: thres{thres} change_num {change_num} | shake_cnt {shake_cnt} | lat_err {lat_err} \n"
            # if uuid == '83_3447c6df-fa6f-4f35-95c3-19980e961852_0' and thres == 1.5:
            # if uuid == '1_eeb6f455-7015-417e-b241-1c378b484747_0' and thres == 1.5:
                # import pdb; pdb.set_trace()

            try:
                with open(f'{self.root}/eval_details.txt', 'a') as f:
                    f.write(info_str)
            except Exception as e:
                print(f"[Warning] Failed to write eval details: {e}")

        return eval_metric

    def _summary(self):
        """ 汇总所有 Clips 的结果并打印美观的表格 """
        results = {
            "lat_change_cnt": [],
            "lat_shake_cnt": [],
            "mean_lat_err": []
        }

        # 聚合数据
        for thres in self.thres_dis:
            all_valid_errs = []
            tot_change = 0
            tot_shake = 0

            for clip in self.clips:
                # 收集误差数值
                errs = clip.eval_metric.get(f"lat_distance_valid_{thres}", [])
                if len(errs) > 0:
                    all_valid_errs.extend(errs)

                tot_change += clip.eval_metric.get(f"lat_change_num_{thres}", 0)
                tot_shake += clip.eval_metric.get(f"lat_shake_num_{thres}", 0)

            mean_err = np.mean(all_valid_errs) if all_valid_errs else 0.0

            results["lat_change_cnt"].append(tot_change)
            results["lat_shake_cnt"].append(tot_shake)
            results["mean_lat_err"].append(mean_err)

        # 调用打印函数
        self._print_pretty_table(results)

    def _print_pretty_table(self, results):
        """ 专门负责表格格式化打印的函数 """

        def get_str_width(s):
            """计算字符串显示宽度 (中文=2, 英文=1)"""
            return sum(2 if ord(c) > 127 else 1 for c in str(s))

        def make_row(label, values, is_float=False):
            """生成表格的一行，确保右对齐和边框对齐"""
            col_width = 15
            label_width = 32

            # 处理标签列
            pad_lbl = label_width - get_str_width(label)
            row_str = f"| {label}{' ' * pad_lbl} "

            # 处理数据列
            for val in values:
                if is_float:
                    s_val = f"{val:.4f}"
                else:
                    s_val = f"{val}"

                pad_val = col_width - get_str_width(s_val)
                row_str += f"| {' ' * pad_val}{s_val} "

            row_str += "|"
            return row_str

        def make_line():
            """生成横向分割线"""
            col_width = 15
            label_width = 32
            line = f"+{'-' * (label_width + 2)}"
            for _ in self.thres_dis:
                line += f"+{'-' * (col_width + 2)}"
            line += "+"
            return line

        # 开始构建输出
        lines = []
        lines.append(make_line())

        # 表头
        header_vals = [str(t) for t in self.thres_dis]
        # 表头居中稍微特殊点，这里为了统一简单，也复用 make_row 但视为字符串
        # 或者为了美观，手动拼表头
        label_width = 32
        col_width = 15
        header = f"| {'Metric /横向距离阈值(m)':<{label_width}} " # 英文左对齐没问题
        for t in self.thres_dis:
            # 居中显示阈值
            s = str(t)
            p = col_width - len(s)
            l = p // 2
            r = p - l
            header += f"| {' '*l}{s}{' '*r} "
        header += "|"

        lines.append(header)
        lines.append(make_line())
        lines.append(make_row("横向跳变次数 (Change Num)", results["lat_change_cnt"]))
        lines.append(make_row("横向来回摆次数 (Shake Num)", results["lat_shake_cnt"]))
        lines.append(make_row("不稳定帧平均误差 (Mean Err)", results["mean_lat_err"], is_float=True))
        lines.append(make_line())

        final_output = "\n".join(lines)
        print(final_output)

        with open(f'{self.root}/eval.txt', 'w') as f:
            f.write(final_output)


    def _vis_one_clip(self, clip, width=10):
        """
        为每个 uuid 创建子文件夹。
        每帧生成一张图，包含 [t-2, t-1, t, t+1, t+2] 共5条轨迹。
        """
        # 1. 创建该 uuid 专属的文件夹
        save_dir = f'{self.root}/vis/{clip.uuid}'
        os.makedirs(save_dir, exist_ok=True)

        # 2. 计算全局视场范围 (Global Viewport)
        # 必须基于整段 50 帧的所有点计算，保证生成 50 张图时坐标轴不乱跳
        all_points = clip.pred_trajs.reshape(-1, 2)
        min_x, min_y = all_points.min(0)
        max_x, max_y = all_points.max(0)

        # 增加一点边缘留白 (Padding)
        pad_x = (max_x - min_x) * 0.1
        pad_y = (max_y - min_y) * 0.1
        global_xlim = (min_x - pad_x, max_x + pad_x)
        global_ylim = (min_y - pad_y, max_y + pad_y)

        # 根据长宽比动态调整画布大小
        range_x = global_xlim[1] - global_xlim[0]
        range_y = global_ylim[1] - global_ylim[0]
        if range_y < range_x:
            figsize = (width, max(4, width * range_y / range_x))
        else:
            figsize = (max(4, width * range_x / range_y), width)

        # 3. 逐帧绘图
        total_frames = clip.traj_len  # 比如 50
        for curr_idx in range(total_frames):
            plt.figure(figsize=figsize)
            ax = plt.gca()

            # 定义滑动窗口范围：[curr-2, curr+2]
            # 注意边界处理，比如第0帧没有前2帧
            start_idx = curr_idx - 2
            end_idx = curr_idx + 2

            # 遍历窗口内的索引
            for idx in range(start_idx, end_idx + 1):
                # 越界检查
                if idx < 0 or idx >= total_frames:
                    continue

                traj = clip.pred_trajs[idx]
                colors = ['red', 'green', 'blue', 'black', 'yellow']

                # 设置样式
                if idx == curr_idx:
                    # 当前帧：红色，加粗，最清楚
                    color = 'red'
                    alpha = 1.0
                    lw = 2.5
                    zorder = 10 # 画在最上层
                    label = f'Current (T={idx})'
                elif idx < curr_idx:
                    # 历史帧 (T-1, T-2)：蓝色，变淡
                    color = 'blue'
                    alpha = 0.4
                    lw = 1.5
                    zorder = 5
                    label = f'Past (T={idx})'
                else:
                    # 未来帧 (T+1, T+2)：绿色，变淡
                    color = 'green'
                    alpha = 0.4
                    lw = 1.5
                    zorder = 5
                    label = f'Future (T={idx})'

                ax.plot(traj[:, 0], traj[:, 1], color=colors[idx - start_idx], alpha=alpha, linewidth=lw, label=label, zorder=zorder)
                # 画个终点小圆点，方便看长度变化
                ax.scatter(traj[-1, 0], traj[-1, 1], color=colors[idx - start_idx], s=20, alpha=alpha, zorder=zorder)

            # 4. 固定视场和样式
            ax.set_xlim(global_xlim)
            ax.set_ylim(global_ylim)
            # ax.set_aspect('equal') # 保证物理比例
            ax.grid(True, linestyle=':', alpha=0.5)

            # 标题显示当前帧进度
            plt.title(f'{clip.uuid} - Frame {curr_idx}/{total_frames}', fontsize=12)
            ax.legend(loc='best', fontsize=12, framealpha=0.9, fancybox=True)

            # 添加图例 (去重)
            handles, labels = ax.get_legend_handles_labels()
            by_label = dict(zip(labels, handles)) # 利用字典键唯一性去重
            # 只显示 Current, Past, Future 三类图例
            # 也可以简单点：ax.legend()

            plt.tight_layout()

            # 保存文件，使用 03d 补零，方便排序 (000.png, 001.png ...)
            plt.savefig(f'{save_dir}/{curr_idx:03d}.png', dpi=100)
            plt.close() # 必须关闭，否则内存爆炸

        print(f"Saved {total_frames} images to {save_dir}")



if __name__ == '__main__':
    # root = '/home/zhe.du/code/planner/nio_planner/melange_all/melange_pca_1218/work_dirs/eval_temporal_consistency/pca_layer_12_epoch54'
    root = '/home/xiangwei.geng/python_workspace/melange/tmp/1228_pca_test'

    eval = Eval(root, vis=True)
    eval.eval()
