from glob import glob
from typing import List
import numpy as np
import os
from pathlib import Path
import shutil
import pickle
import matplotlib.pyplot as plt
from tabulate import tabulate
from multiprocessing import Pool
from tqdm import tqdm


from tpp_onemodel.data.transform.plannn2_transform import PCATokenizer
from tpp_onemodel.data.dataset.plannn2_dataset import (
    AccKappaVehicleTokenizer,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import (
    normalize_angle,
)
from tpp_onemodel.tools.plannn2.fit_pca_acc_kappa_params import (
    generate_all_x_y_yaw_k_seq,
    generate_all_acc_kappa_seq,
)


class PcaAccKappaAnalyzer:
    def __init__(self, pca_tempalte_set):
        self.num_components = 15
        self.ego_seq_len = 25
        self.dt = 0.2
        self.pca_tokenizer = PCATokenizer(pca_tempalte_set)


    def reconstruct_traj_and_cal_error(self, data):
        ego_seq = data[:, -2:]  # [acc, kappa]
        gt_traj = data[:, :6]   # [gt_x, gt_y, gt_yaw, gt_k, _gt_v, gt_a]
        ego_seq_np = np.expand_dims(np.array(ego_seq),axis=0)
        ego_seq_np = ego_seq_np[:,:self.ego_seq_len]
        init_state = gt_traj[0][[0, 1, 2, 4]]  # [gt_x, gt_y, gt_yaw, gt_k, _gt_v, gt_a,]

        opt_traj = []
        gt_opt_all_errors = []
        gt_opt_final_errors = []
        gt_pca_all_errors = []
        gt_pca_final_errors = []
        current_state = init_state
        for idx in range(self.ego_seq_len):
            gt_pt = gt_traj[idx + 1]
            control_i = ego_seq[idx]
            current_state = AccKappaVehicleTokenizer.rk4_step(current_state, control_i, dt=self.dt)
            current_state = current_state.reshape(-1)
            opt_pt = np.array([current_state[0], current_state[1], current_state[2], control_i[1], current_state[3], control_i[0]], dtype=np.float32)
            opt_traj.append(opt_pt)
            opt_error = np.sqrt((gt_pt[IDX_X] - opt_pt[IDX_X])**2 + (gt_pt[IDX_Y] - opt_pt[IDX_Y])**2)
            abs_x_error = np.abs(gt_pt[IDX_X] - opt_pt[IDX_X])
            abs_y_error = np.abs(gt_pt[IDX_Y] - opt_pt[IDX_Y])
            abs_yaw_error = np.abs(normalize_angle(gt_pt[IDX_YAW] - opt_pt[IDX_YAW]))
            abs_kappa_error = np.abs(gt_pt[IDX_KAPPA] - opt_pt[IDX_KAPPA])
            abs_v_error = np.abs(gt_pt[IDX_V] - opt_pt[IDX_V])
            abs_acc_error = np.abs(gt_pt[IDX_ACC] - opt_pt[IDX_ACC])
            gt_opt_all_errors.append([abs_x_error, abs_y_error, abs_yaw_error, abs_kappa_error, abs_v_error, abs_acc_error, opt_error])
            if idx == self.ego_seq_len - 1:
                gt_opt_final_errors.append([abs_x_error, abs_y_error, abs_yaw_error, abs_kappa_error, abs_v_error, abs_acc_error, opt_error])

        pca_traj = []
        pca_errors = []
        pca_res = self.pca_tokenizer(ego_seq_np, num_components=self.num_components)
        dequant = self.pca_tokenizer.decode(pca_res, num_components=self.num_components)
        current_state = init_state
        for idx in range(self.ego_seq_len):
            gt_pt = gt_traj[idx + 1]
            control_i = dequant[:,idx]
            current_state = AccKappaVehicleTokenizer.rk4_step(current_state, control_i, dt=self.dt)
            current_state = current_state.reshape(-1)
            control_i = control_i.reshape(-1)
            pca_pt = np.array([current_state[0], current_state[1], current_state[2], control_i[1], current_state[3], control_i[0]], dtype=np.float32)
            pca_traj.append(pca_pt)
            pca_error = np.sqrt((gt_pt[IDX_X] - pca_pt[IDX_X])**2 + (gt_pt[IDX_Y] - pca_pt[IDX_Y])**2)
            pca_errors.append(pca_error)
            abs_x_error = np.abs(gt_pt[IDX_X] - pca_pt[IDX_X])
            abs_y_error = np.abs(gt_pt[IDX_Y] - pca_pt[IDX_Y])
            abs_yaw_error = np.abs(normalize_angle(gt_pt[IDX_YAW] - pca_pt[IDX_YAW]))
            abs_kappa_error = np.abs(gt_pt[IDX_KAPPA] - pca_pt[IDX_KAPPA])
            abs_v_error = np.abs(gt_pt[IDX_V] - pca_pt[IDX_V])
            abs_acc_error = np.abs(gt_pt[IDX_ACC] - pca_pt[IDX_ACC])
            gt_pca_all_errors.append([abs_x_error, abs_y_error, abs_yaw_error, abs_kappa_error, abs_v_error, abs_acc_error, pca_error])
            if idx == self.ego_seq_len - 1:
                gt_pca_final_errors.append([abs_x_error, abs_y_error, abs_yaw_error, abs_kappa_error, abs_v_error, abs_acc_error, pca_error])

        return np.array(gt_traj), np.array(opt_traj), np.array(pca_traj), np.array(gt_opt_all_errors), np.array(gt_pca_all_errors), np.array(gt_opt_final_errors), np.array(gt_pca_final_errors)


    def cal_ade_fde(self, gt_opt_all_errors, gt_pca_all_errors, gt_opt_final_errors, gt_pca_final_errors):
        if len(gt_opt_all_errors) == 0 or len(gt_pca_all_errors) == 0 or len(gt_opt_final_errors) == 0 or len(gt_pca_final_errors) == 0:
            print("No error data to calculate metrics.")
            return {}

        gt_opt_all_errors = np.array(gt_opt_all_errors)
        gt_pca_all_errors = np.array(gt_pca_all_errors)
        gt_opt_final_errors = np.array(gt_opt_final_errors)
        gt_pca_final_errors = np.array(gt_pca_final_errors)

        opt_ade = gt_opt_all_errors.mean(axis=(0, 1))
        opt_p99 = np.percentile(gt_opt_all_errors, 99, axis=(0, 1))
        opt_fde = gt_opt_final_errors.mean(axis=(0, 1))
        pca_ade = gt_pca_all_errors.mean(axis=(0, 1))
        pca_p99 = np.percentile(gt_pca_all_errors, 99, axis=(0, 1))
        pca_fde = gt_pca_final_errors.mean(axis=(0, 1))

        metrics = [
            ["mADE_xy", opt_ade[IDX_XY], pca_ade[IDX_XY]],
            ["mADE_x", opt_ade[IDX_X], pca_ade[IDX_X]],
            ["mADE_y", opt_ade[IDX_Y], pca_ade[IDX_Y]],
            ["mADE_yaw", opt_ade[IDX_YAW], pca_ade[IDX_YAW]],
            ["mADE_kappa", opt_ade[IDX_KAPPA], pca_ade[IDX_KAPPA]],
            ["mADE_v", opt_ade[IDX_V], pca_ade[IDX_V]],
            ["mADE_acc", opt_ade[IDX_ACC], pca_ade[IDX_ACC]],
            ["mFDE_xy", opt_fde[IDX_XY], pca_fde[IDX_XY]],
            ["mFDE_x", opt_fde[IDX_X], pca_fde[IDX_X]],
            ["mFDE_y", opt_fde[IDX_Y], pca_fde[IDX_Y]],
            ["mFDE_yaw", opt_fde[IDX_YAW], pca_fde[IDX_YAW]],
            ["mFDE_kappa", opt_fde[IDX_KAPPA], pca_fde[IDX_KAPPA]],
            ["mFDE_v", opt_fde[IDX_V], pca_fde[IDX_V]],
            ["mFDE_acc", opt_fde[IDX_ACC], pca_fde[IDX_ACC]],
            ["p99_xy", opt_p99[IDX_XY], pca_p99[IDX_XY]],
            ["p99_x", opt_p99[IDX_X], pca_p99[IDX_X]],
            ["p99_y", opt_p99[IDX_Y], pca_p99[IDX_Y]],
            ["p99_yaw", opt_p99[IDX_YAW], pca_p99[IDX_YAW]],
            ["p99_kappa", opt_p99[IDX_KAPPA], pca_p99[IDX_KAPPA]],
            ["p99_v", opt_p99[IDX_V], pca_p99[IDX_V]],
            ["p99_acc", opt_p99[IDX_ACC], pca_p99[IDX_ACC]],
            ["count", len(gt_pca_all_errors), len(gt_opt_all_errors)],
        ]

        print(tabulate(metrics, headers=["metrics", "opt", "pca"], tablefmt="grid", colalign=("left", "left", "left")))

        return metrics


    def vis_opt_decode_trajectory(
        self,
        gt_traj,
        opt_traj,
        pca_traj,
        opt_errors,
        pca_errors,
        save_path,
    ):
        """
        gt_traj / opt_traj / pca_traj:
            list of [x, y, yaw, kappa, v, a]

        opt_errors / pca_errors:
            list or array

        save_path:
            output image path
        """

        # 转 numpy
        gt_traj = np.array(gt_traj)
        opt_traj = np.array(opt_traj)
        pca_traj = np.array(pca_traj)

        opt_errors = np.array(opt_errors)
        pca_errors = np.array(pca_errors)

        # 不同轨迹不同 marker
        markers = {
            "gt": "v",
            "opt": "^",
            "pca": "x",
        }

        fig, axes = plt.subplots(2, 3, figsize=(18, 10))

        # ========== 1. XY ==========
        ax = axes[0, 0]
        ax.plot(gt_traj[:, IDX_X], gt_traj[:, IDX_Y], marker=markers["gt"], label="gt")
        ax.plot(opt_traj[:, IDX_X], opt_traj[:, IDX_Y], marker=markers["opt"], label="opt")
        ax.plot(pca_traj[:, IDX_X], pca_traj[:, IDX_Y], marker=markers["pca"], label="pca")
        ax.set_title("XY")
        ax.set_xlabel("x")
        ax.set_ylabel("y")
        ax.axis("equal")
        ax.legend()
        ax.grid(True)

        # ========== 2. yaw ==========
        ax = axes[0, 1]
        ax.plot(gt_traj[:, IDX_YAW], marker=markers["gt"], label="gt")
        ax.plot(opt_traj[:, IDX_YAW], marker=markers["opt"], label="opt")
        ax.plot(pca_traj[:, IDX_YAW], marker=markers["pca"], label="pca")
        ax.set_title("yaw")
        ax.set_xlabel("index")
        ax.legend()
        ax.grid(True)

        # ========== 3. kappa ==========
        ax = axes[0, 2]
        ax.plot(gt_traj[:, IDX_KAPPA], marker=markers["gt"], label="gt")
        ax.plot(opt_traj[:, IDX_KAPPA], marker=markers["opt"], label="opt")
        ax.plot(pca_traj[:, IDX_KAPPA], marker=markers["pca"], label="pca")
        ax.set_title("kappa")
        ax.set_xlabel("index")
        ax.legend()
        ax.grid(True)

        # ========== 4. v ==========
        ax = axes[1, 0]
        ax.plot(gt_traj[:, IDX_V], marker=markers["gt"], label="gt")
        ax.plot(opt_traj[:, IDX_V], marker=markers["opt"], label="opt")
        ax.plot(pca_traj[:, IDX_V], marker=markers["pca"], label="pca")
        ax.set_title("v")
        ax.set_xlabel("index")
        ax.legend()
        ax.grid(True)

        # ========== 5. a ==========
        ax = axes[1, 1]
        ax.plot(gt_traj[:, IDX_ACC], marker=markers["gt"], label="gt")
        ax.plot(opt_traj[:, IDX_ACC], marker=markers["opt"], label="opt")
        ax.plot(pca_traj[:, IDX_ACC], marker=markers["pca"], label="pca")
        ax.set_title("a")
        ax.set_xlabel("index")
        ax.legend()
        ax.grid(True)

        # ========== 6. Errors ==========
        ax = axes[1, 2]
        ax.plot(opt_errors[:, IDX_XY], marker="^", label="xy-opt_errors")
        ax.plot(opt_errors[:, IDX_X], marker="x", label="x-opt_errors")
        ax.plot(opt_errors[:, IDX_Y], marker="v", label="y-opt_errors")
        ax.plot(pca_errors[:, IDX_XY], marker="^", label="xy-pca_errors")
        ax.plot(pca_errors[:, IDX_X], marker="x", label="x-pca_errors")
        ax.plot(pca_errors[:, IDX_Y], marker="v", label="y-pca_errors")
        ax.set_title("Errors")
        ax.set_xlabel("index")
        ax.legend()
        ax.grid(True)

        plt.tight_layout()
        plt.savefig(save_path)
        plt.close(fig)


    def analyze_error_and_vis(self, acc_kappa_save_path, vis_save_folder, error_thresh=None, processes_num=15):
        with open(acc_kappa_save_path, 'rb') as file:
            data = pickle.load(file)

            processes_num = min(processes_num, len(data))
            results = []
            with Pool(processes=processes_num) as pool:
                for result in tqdm(pool.imap_unordered(self.reconstruct_traj_and_cal_error, data), total=len(data)):
                    results.append(result)

            # 主进程绘图
            gt_opt_all_errors_list = []
            gt_pca_all_errors_list = []
            gt_opt_final_errors_list = []
            gt_pca_final_errors_list = []
            for i, (gt_traj, opt_traj, pca_traj, gt_opt_all_errors, gt_pca_all_errors, gt_opt_final_errors, gt_pca_final_errors) in enumerate(results):
                gt_opt_all_errors_list.append(gt_opt_all_errors)
                gt_pca_all_errors_list.append(gt_pca_all_errors)
                gt_opt_final_errors_list.append(gt_opt_final_errors)
                gt_pca_final_errors_list.append(gt_pca_final_errors)

                max_opt_error = gt_opt_all_errors[:, -1].max()
                max_pca_error = gt_pca_all_errors[:, -1].max()
                if error_thresh is None or max_opt_error > error_thresh or max_pca_error > error_thresh:
                    name = f"{i}.jpg"
                    vis_path = os.path.join(vis_save_folder, name)
                    self.vis_opt_decode_trajectory(
                        gt_traj[1:],
                        opt_traj,
                        pca_traj,
                        gt_opt_all_errors,
                        gt_pca_all_errors,
                        vis_path
                    )

            return self.cal_ade_fde(gt_opt_all_errors_list, gt_pca_all_errors_list, gt_opt_final_errors_list, gt_pca_final_errors_list)


if __name__ == "__main__":
    # 轨迹维度索引定义
    IDX_X = 0
    IDX_Y = 1
    IDX_YAW = 2
    IDX_KAPPA = 3
    IDX_V = 4
    IDX_ACC = 5
    IDX_XY = 6

    REGENERATE_X_Y_YAW_K_SEQ = False
    MAX_FILES_NUM = 10000  # 100000
    CLEAR_HIS_EVAL_VIS = True

    all_dataset = dict(
        pre_train="/share-global/leijie.zhang/data/planNN/350_data_0211_v1_trainset.txt",
        normal_small="/share-global/charlie.cheng1/melange-plannn2/data/dataset/issues/pln2-225fz-aimless-lc.txt",
        normal="/share-global/xiangwei.geng/plannn2/data/1118/matched/test1000_case_v3_1_new.txt",
        right_left_turn="/share-global/rong.zhang2/plannn2_data/1119_v5_left_right_turn_t_junction_1436.txt",
        turn = "/share-global/menghan.pan/st/plann2_three_point_turn_1124_1_80040.txt",
        pca = "/home/jim.zhou/codebook-acc-kappa/melange/right_turn_big_kappa.txt",
        right_turn_small = "/share-global/jim.zhou/test/right_turn_small.txt",
    )
    eval_dataset = "pre_train"
    save_folder = "/ephstorage/melange/output/pca_acc_kappa/eval/"

    Path(save_folder).mkdir(parents=True, exist_ok=True)
    metrics_save_path = os.path.join(save_folder, "metrics", "metrics.pkl")
    Path(os.path.dirname(metrics_save_path)).mkdir(parents=True, exist_ok=True)

    vis_save_folder = os.path.join(save_folder, "vis")
    if CLEAR_HIS_EVAL_VIS:
        if os.path.exists(vis_save_folder) and os.path.isdir(vis_save_folder):
            shutil.rmtree(vis_save_folder)
    Path(vis_save_folder).mkdir(parents=True, exist_ok=True)

    pca_tempalte_set = (
        "/ephstorage/melange/output/pca_acc_kappa/fit/pca_acc_kappa_rear_axle_whl_ag.json"
    )

    X_Y_YAW_K_SEQ_PATH = os.path.join(save_folder, "x_y_yaw_k_seq.pkl")
    os.makedirs(os.path.dirname(X_Y_YAW_K_SEQ_PATH), exist_ok=True)
    ACC_KAPPA_SEQ_PATH = os.path.join(save_folder, "acc_kappa_seq.pkl")

    generate_all_x_y_yaw_k_seq(dataset=all_dataset[eval_dataset], x_y_yaw_k_save_path=X_Y_YAW_K_SEQ_PATH, regenerate_x_y_yaw_k_seq=REGENERATE_X_Y_YAW_K_SEQ, max_files_num=MAX_FILES_NUM)
    generate_all_acc_kappa_seq(x_y_yaw_k_path=X_Y_YAW_K_SEQ_PATH, acc_kappa_save_path=ACC_KAPPA_SEQ_PATH, use_filter=True)

    pca_acc_kappa_analyzer = PcaAccKappaAnalyzer(pca_tempalte_set)
    metrics = pca_acc_kappa_analyzer.analyze_error_and_vis(acc_kappa_save_path=ACC_KAPPA_SEQ_PATH, vis_save_folder=vis_save_folder, error_thresh=0.5)
    with open(metrics_save_path, "wb") as file:
        pickle.dump(metrics, file)
    exit(0)
