import pickle
from tpp_onemodel.evaluator.plannn2_evaluator_utils.planner_env import PlannerEnv

def convert_pkl_visulization(pkl_path:str):
    with open(pkl_path, "rb") as f:
        args = pickle.load(f)
    env = args["env"]
    env.vis(
        savename=args.get("savename"),
        ego_polygon=args.get("ego_polygon"),
        actions=args.get("actions", None),
        gt_polygon=args.get("gt_polygon", None),
        pred_polygons_draw=args.get("pred_polygons_draw", None),
        reward_keys=args.get("reward_keys", None),
        turnlightsignal_pred=args.get("turnlightsignal_pred", None),
        turnlightsignal_gt=args.get("turnlightsignal_gt", None),
        **args.get("log_infos", {}),
    )
