# -*- coding: utf-8 -*-
import os
import random
import pickle
import numpy as np
from read_cache_op_py import read_cache_op_py
from tqdm import tqdm
from multiprocessing import Pool
import functools

from tpp_onemodel.data.dataset.plannn2_dataset_utils.data_parser import global_data_parser
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import transform_obj
from tpp_onemodel.data.transform.plannn2_transform import PCATokenizer
from tpp_onemodel.data.dataset.plannn2_dataset import cal_pca_acc_kappa_seq


PRE_TRAIN_DATASET = "/share-global/leijie.zhang/data/planNN/350_data_0211_v1_trainset.txt"
SAVE_FOLDER = "/ephstorage/melange/output/pca_acc_kappa/fit/"
os.makedirs(os.path.dirname(SAVE_FOLDER), exist_ok=True)
X_Y_YAW_K_SEQ_PATH = os.path.join(SAVE_FOLDER, "x_y_yaw_k_seq.pkl")
ACC_KAPPA_SEQ_PATH = os.path.join(SAVE_FOLDER, "acc_kappa_seq.pkl")
ACC_KAPPA_TEMPLATE_SET_PATH = os.path.join(SAVE_FOLDER, "pca_acc_kappa_rear_axle_whl_ag.json")

MAX_FILES_NUM = 100000  # 100000
PROCESSES_NUM = 15
DT = 0.2
TIMESTAMP_SIZE = 40
V_EPS = 0.1
WINDOW_LEN = 15

MAX_ACC = 4.0
MIN_ACC = -8.0
MAX_KAPPA = 0.5
MIN_KAPPA = -0.5

REGENERATE_X_Y_YAW_K_SEQ = False
ENABLE_FILTER = True


def load_frame_data(fname):
    try:
        fname = fname.replace("\t", " ")
        content = fname.split()
        is_pkl = fname.endswith(".pkl") or ".pkl " in fname

        if len(content) == 3:
            ceph_path, filesize, _ = content
            fname = " ".join([ceph_path, filesize])

        # 远程路径情况
        if " " in fname:
            fname = "/" + fname.split(":")[-1]

            try:
                content = read_cache_op_py([fname])[0]
            except Exception as e:
                print(f"[Warning] Remote file not found: {fname}")
                return None

            try:
                data = pickle.loads(content) if is_pkl else global_data_parser.parse(content)
            except Exception as e:
                print(f"[Warning] File parse failed: {fname}")
                return None
        else:
            if not os.path.exists(fname):
                print(f"[Warning] File not exists: {fname}")
                return None

            try:
                if is_pkl:
                    with open(fname, "rb") as f:
                        data = pickle.load(f)
                else:
                    data = global_data_parser.parse(fname)
            except Exception as e:
                print(f"[Warning] File load failed: {fname}")
                return None

        return data

    except Exception as e:
        print(f"[Error] Unexpected error in load_frame_data: {e}")
        return None


def cal_x_y_yaw_k_seq_from_data(fname):
    data = load_frame_data(fname)
    if data is None:
        return []

    timestamps = sorted(data["timestamp_list"])
    timestamps = np.array(timestamps)

    cur_frame_idx = 14
    trajpose0 = data[timestamps[cur_frame_idx]]["car_pose"] # 后轴中心在世界坐标系下的位置
    shift = np.eye(4)  # I
    shift[:3, 3] = [1.4, 0, 0]
    egocenter_pose0 = trajpose0 @ shift # 几何中心在世界坐标系下的位置
    initpose = np.linalg.inv(egocenter_pose0)
    transformed_egocenter_poses = []
    for ts in timestamps:
        ego_pose_backwheel = initpose @ data[ts]["car_pose"]
        transformed_egocenter_poses.append(ego_pose_backwheel @ shift)

    wheel_base = [data[ts]["vehicle_geometry"]["wheel_base"] for ts in timestamps]
    frnt_whl_ag = [data[ts]["vehicle_info"][0]["VehFrontWhlAg"] for ts in timestamps]

    x_y_yaw_k = []
    for idx, egocenter_pose in enumerate(transformed_egocenter_poses):
        whlbase = wheel_base[idx]
        frntwhlag = frnt_whl_ag[idx]
        x = egocenter_pose[0, 3]
        y = egocenter_pose[1, 3]
        yaw = np.arctan2(egocenter_pose[1, 0], egocenter_pose[0, 0])
        k = -1 * np.tan(frntwhlag) / max(1e-6, whlbase)
        x_y_yaw_k.append([x, y, yaw, k])
    return x_y_yaw_k


def generate_all_x_y_yaw_k_seq(dataset, x_y_yaw_k_save_path, regenerate_x_y_yaw_k_seq=True, max_files_num=100000, processes_num=15, timestamp_size=40):
    print("Generating x_y_yaw_k sequences...")
    if not regenerate_x_y_yaw_k_seq:
        return

    with open(dataset) as f:
        lines = f.readlines()
    sampled = random.sample(lines, max_files_num)

    processes_num = min(processes_num, len(sampled))
    with Pool(processes=processes_num) as pool:
        x_y_yaw_k = list(tqdm(pool.imap_unordered(cal_x_y_yaw_k_seq_from_data, sampled), total=len(sampled)))
    x_y_yaw_k = [group for group in x_y_yaw_k if len(group) >= timestamp_size]
    with open(x_y_yaw_k_save_path, "wb") as f:
        pickle.dump(x_y_yaw_k, f)


def generate_all_acc_kappa_seq(x_y_yaw_k_path, acc_kappa_save_path, use_filter=True, processes_num=15, ego_seq_len=39, future_ego_seq_len=25):
    print("Generating acc_kappa sequences...")
    with open(x_y_yaw_k_path, "rb") as f:
        x_y_yaw_k = pickle.load(f)
        print("x_y_yaw_k len:", len(x_y_yaw_k))
    acc_kappa_list = []
    gt_traj_list = []
    processes_num = min(processes_num, len(x_y_yaw_k))
    func = functools.partial(cal_pca_acc_kappa_seq, use_filter=use_filter, with_gt_traj=True)
    with Pool(processes=processes_num) as pool:
        for acc_kappa, gt_traj in tqdm(pool.imap_unordered(func, x_y_yaw_k), total=len(x_y_yaw_k)):
            if len(acc_kappa) == ego_seq_len:
                tmp_acc_kappa = acc_kappa[-future_ego_seq_len:]
                tmp_acc_kappa = np.vstack([tmp_acc_kappa, [0.0, 0.0]]) # 为了和gt_traj长度一样，实际没有用到
                acc_kappa_list.append(tmp_acc_kappa)
                gt_traj_list.append(gt_traj)
    acc_kappa_list = np.array(acc_kappa_list, dtype=np.float32)
    print("acc_kappa_list len after filter:", len(acc_kappa_list))
    gt_traj_list = np.array(gt_traj_list, dtype=np.float32)

    save_data = np.concatenate([gt_traj_list, acc_kappa_list], axis=2) # [gt_x, gt_y, gt_yaw, gt_k, _gt_v, gt_a, acc, kappa]
    with open(acc_kappa_save_path, 'wb') as file:
        pickle.dump(save_data, file)


def filter_ego_seqs(acc_kappas):
    acc = acc_kappas[..., 0]
    kappa = acc_kappas[..., 1]

    # 判断每一帧是否在合法范围
    valid_acc = (acc >= MIN_ACC) & (acc <= MAX_ACC)
    valid_kappa = (kappa >= MIN_KAPPA) & (kappa <= MAX_KAPPA)

    # 每一帧是否合法
    valid_frame = valid_acc & valid_kappa  # [N, 25]

    # 每个样本 25 帧是否全部合法
    valid_sample = np.all(valid_frame, axis=1)  # [N]

    # 只保留合法样本
    return acc_kappas[valid_sample]


def generate_pca_params():
    with open(ACC_KAPPA_SEQ_PATH, "rb") as f:
        data = pickle.load(f)

    data = data[:, :25, :]
    acc_kappas = data[:, :, -2:]
    if ENABLE_FILTER:
        print(f"Original ego seqs len: {len(acc_kappas)}")
        acc_kappas = filter_ego_seqs(acc_kappas)
        print(f"Filtered ego seqs len: {len(acc_kappas)}")

    mean_val = acc_kappas.mean(axis=(0, 1), keepdims=True)
    std_val  = acc_kappas.std(axis=(0, 1), keepdims=True, ddof=1)

    pca_tokenizer = PCATokenizer()

    pca_tokenizer.fit(acc_kappas, mean_val=mean_val, std_val=std_val, save_json_path=ACC_KAPPA_TEMPLATE_SET_PATH, n_components=15, n_bins=2048)


if __name__ == "__main__":
    generate_all_x_y_yaw_k_seq(dataset=PRE_TRAIN_DATASET, x_y_yaw_k_save_path=X_Y_YAW_K_SEQ_PATH, regenerate_x_y_yaw_k_seq=REGENERATE_X_Y_YAW_K_SEQ, max_files_num=MAX_FILES_NUM)
    generate_all_acc_kappa_seq(x_y_yaw_k_path=X_Y_YAW_K_SEQ_PATH, acc_kappa_save_path=ACC_KAPPA_SEQ_PATH, use_filter=False)
    generate_pca_params()
