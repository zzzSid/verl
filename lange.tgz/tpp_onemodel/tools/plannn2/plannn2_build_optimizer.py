# -*- coding: utf-8 -*-
"""PlaceHolder: base_optimizer.

This file provides pytorch native optimizer and custom optimizer.
"""


import logging
from typing import Dict
from typing import List

from torch.optim import ASGD
from torch.optim import LBFGS
from torch.optim import SGD
from torch.optim import Adam
from torch.optim import Adamax
from torch.optim import AdamW
from torch.optim import Optimizer


logger = logging.getLogger(__name__)


def build_optimizer(
    type: str,
    params_policy: List[Dict],
    **kwargs,  # pylint: disable=redefined-builtin
) -> Optimizer:
    """Build optimizer."""
    if type == "ASGD":
        # reference: https://pytorch.org/docs/stable/optim.html
        return ASGD(params_policy, **kwargs)
    if type == "LBFGS":
        # reference: https://pytorch.org/docs/stable/optim.html
        return LBFGS(params_policy, **kwargs)
    if type == "SGD":
        # reference: https://pytorch.org/docs/stable/optim.html
        return SGD(params_policy, **kwargs)
    if type == "Adam":
        # reference: https://pytorch.org/docs/stable/optim.html
        return Adam(params_policy, **kwargs)
    if type == "Adamax":
        # reference: https://pytorch.org/docs/stable/optim.html
        return Adamax(params_policy, **kwargs)
    if type == "AdamW":
        # reference: https://pytorch.org/docs/stable/optim.html
        return AdamW(params_policy, **kwargs)
    raise ValueError(f"optimizer {type} not supported!!!")
