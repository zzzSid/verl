# -*- coding: utf-8 -*-
"""TPP-OneModel utils."""
