# -*- coding: utf-8 -*-
"""TPP-BEV ceph parser utils."""
import logging
from typing import List
from typing import Union

import niofs
from torchpilot.utils.reader import read_bytes


logger = logging.getLogger(__name__)


class CephSettings:  # pylint: disable=too-few-public-methods
    """Ceph info settings."""

    defualt_client: str = "hefei"
    access_key: str = "81fbac8cd8abdee5"
    secret_key: str = "1c46fdaf88a24f35b7f68289e6e236ce"
    timeout: int = 600  # timeout in seconds


ceph_settings = CephSettings()
client = niofs.Client(ceph_settings.access_key, ceph_settings.secret_key)


# TODO(yuxiang.yan): As generator. # pylint: disable=fixme.
def load_bytes_from_ceph(ceph_path_list: Union[str, List[str]]) -> List[bytes]:
    """Load bytes from ceph.

    Note:
        Replace cloud path is needed if read from qcloud, more details at
        (https://nio.feishu.cn/docs/doccn8EX5FHT3NdPtuxLLoiH7Rf).

    Args:
        ceph_path_list (Union[str, List[str]]): Path to ceph or list of path to ceph.

    Returns:
        List of bytes.
    """
    if isinstance(ceph_path_list, str):
        ceph_path_list = [ceph_path_list]

    for i, ceph_path in enumerate(ceph_path_list):
        if ceph_path.startswith("qcloud:"):
            ceph_path_list[i] = "s3://cos.ap-beijing.myqcloud.com/" + ceph_path[len("qcloud:") :]
        elif ceph_path.startswith("hefei:"):
            ceph_path_list[i] = "/" + ceph_path[len("hefei:") :]
        elif ceph_path.startswith("hefei_cos:"):
            ceph_path_list[i] = "/" + ceph_path[len("hefei_cos:") :]

        # hack for bev json path. insert '/' before "camera" if not exists
        if "camera_ful" not in ceph_path_list[i]:
            continue
        index = ceph_path_list[i].index("camera_ful")
        if index != -1 and ceph_path_list[i][index - 1] != "/":
            ceph_path_list[i] = ceph_path_list[i][:index] + "/" + ceph_path_list[i][index:]
    return read_bytes(ceph_path_list)


def add_file_size_to_ceph_path(ceph_path: str) -> str:
    """Add file size to ceph path.

    Args:
        ceph_path (str): Ceph path.

    Returns:
        ceph_path with file size.
    """
    if ceph_path is None or ceph_path == "":
        return ceph_path

    if len(ceph_path.split()) > 1 and ceph_path.split()[-1].isnumeric():
        # logger.warning("Ceph has been already satisfied: %s.", ceph_path)
        return ceph_path

    # ceph_path: '{cloud}:{bucket}/{path/to/file or folder}'
    bucket_and_remote = ceph_path.split(":")[-1]
    bucket_and_remote_split = bucket_and_remote.split("/")
    bucket = bucket_and_remote_split[0]
    remote_path = "/".join(bucket_and_remote_split[1:])

    # Get list out.
    head_out = client.head_object(Bucket=bucket, Key=remote_path)
    if "ContentLength" not in head_out:
        # TODO(yuxiang.yan): Enable this raise.  # pylint: disable=fixme.
        # raise FileExistsError(f"File `{ceph_path}` do not exist.")
        logger.warning("File `%s` do not exist.", ceph_path)
        return ""

    size = head_out["ContentLength"]
    return ceph_path + f" {size}"
