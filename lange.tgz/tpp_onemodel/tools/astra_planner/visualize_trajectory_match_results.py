# -*- coding: utf-8 -*-
"""Visualization function for trajectory matching."""
from copy import deepcopy
from pathlib import Path
from typing import Optional

import matplotlib.pyplot as plt
import numpy as np
import torch
import torchpilot
from matplotlib.patches import Polygon
from torchpilot.utils.file_manager import FileManager


# pylint: disable=invalid-name, too-many-arguments, too-many-locals, too-many-branches, C0301, W0105, W1203, R0915

logger = torchpilot.logger

SCENE_TO_VIS = [
    # "Learnable_LK",
    "LaneKeep",
    "LeftChange",
    "RightChange",
    "LeftTurn",
    "RightTurn",
    # "LeftUturn",
    # "RightUturn",
    # "LeftNudge": 7,
    # "RightNudge": 8
]


DEBUG = False

# Constants.

LANELINE_PLOT_CONFIG = {
    0: {"color": "#808080", "linewidth": 1.5, "linestyle": "--"},  # common lane - gray dotted
    1: {"color": "#DAA520", "linewidth": 1.5},  # road edge - darkorange
    2: {"color": "#FFA500", "linewidth": 2},  # stop line - orange
}

NAVIPATH_PLOT_CONFIG = {
    # navi path -
    "positive": {"color": "#00FFFF", "linewidth": 1, "marker": "o", "zorder": 1},
}

NAVILANE_PLOT_CONFIG = {
    # positive lane - dark pink
    # "positive_lane_change": {"color": "#A33DA3", "linewidth": 2, "marker": "o"},
    # negative lane - light pink
    # "negative_lane_change": {"color": "#FFC0CD", "linewidth": 2, "marker": "o"},
    # positive lane turn - dark pink & star marker
    # "positive_lane_turn": {"color": "#A33DA3", "linewidth": 2, "marker": "*"},
    # positive lane keep - dark pink & circle marker
    # "positive_lane_keep": {"color": "#A33DA3", "linewidth": 2, "marker": "D"},
    # negative lane turn - light pink & star marker
    # "negative_lane_turn": {"color": "#FFC0CD", "linewidth": 2, "marker": "*"},
    # negative lane keep - light pink & circle marker
    # "negative_lane_keep": {"color": "#FFC0CD", "linewidth": 2, "marker": "D"},
    # lane keep - dark pink & circle marker
    "lane_keep": {"color": "#A33DA3", "linewidth": 2, "marker": "D"},
    # left turn - dark yellow & star marker
    "left_turn": {"color": "#FFD700", "linewidth": 2, "marker": "*"},
    # left change - pink
    "left_change": {"color": "#FFC0CB", "linewidth": 2, "marker": "o"},
    # left around - yellow
    "left_around": {"color": "#FFD700", "linewidth": 2, "marker": "o"},
    # left nudge - dark gray
    "left_nudge": {"color": "#808080", "linewidth": 2, "marker": "o"},
    # right turn - dark blue & star marker
    "right_turn": {"color": "#0000FF", "linewidth": 2, "marker": "*"},
    # right change - light blue
    "right_change": {"color": "#ADD8E6", "linewidth": 2, "marker": "o"},
    # right around - normal blue
    "right_around": {"color": "#0000FF", "linewidth": 2, "marker": "o"},
    # right nudge - light blue
    "right_nudge": {"color": "#00CED1", "linewidth": 2, "marker": "o"},
}

WTA_LANE_PLOT_CONFIG = {
    # positive lane - yellow
    "positive": {"color": "#EEEE00", "linewidth": 2, "marker": "o"},
    # negative lane - light yellow
    # "negative": {"color": "#EEEE00", "linewidth": 2, "marker": "o"},
}

STA_LANE_PLOT_CONFIG = {
    # positive lane - green
    "positive": {"color": "#ADFF2F", "linewidth": 2, "marker": "o"},
    # negative lane - light pink
    # "negative": {"color": "#FFC0CD", "linewidth": 2, "marker": "o"},
}

BBOX_PLOT_CONFIG = {
    # dark green
    "OD": {"edgecolor": "#008000", "fill": False, "linewidth": 1, "zorder": 3},
    # red
    "EGO": {"edgecolor": "#FF4500", "fill": False, "linewidth": 3, "zorder": 3},
}

# red
GT_TRAJECTORY_PLOT_CONFIG = {"color": "#FF4500", "linewidth": 3, "zorder": 2}

PRED_TRAJECTORY_PLOT_CONFIG = {
    # postive trajectory - green
    "positive": {"color": "#008000", "linewidth": 3, "zorder": 1},
    "DrivePathNormal": {"color": "#008000", "linewidth": 3, "zorder": 1},
    "DrivePathLaneKeep": {"color": "#FFD700", "linewidth": 3, "zorder": 1},
    # negative trajectory - light blue
    # "negative": {"color": "#87CEEB", "linewidth": 1, "alpha": 0.5, "zorder": 2},
    # choose scene - blue
    "ChooseScene": {"color": "#0000FF", "linewidth": 2, "alpha": 1, "zorder": 2},
    # lane keep - dark pink & circle marker
    "LaneKeep": {"color": "#A33DA3", "linewidth": 2, "alpha": 1, "zorder": 2},
    # left turn - dark yellow & star marker
    "LeftTurn": {"color": "#FFD700", "linewidth": 2, "alpha": 1, "zorder": 2},
    # left change - pink
    "LeftChange": {"color": "#FFC0CB", "linewidth": 2, "alpha": 1, "zorder": 2},
    # left u turn - yellow
    "LeftUturn": {"color": "#FFD700", "linewidth": 2, "alpha": 1, "zorder": 2},
    # left nudge - dark gray
    "LeftNudge": {"color": "#808080", "linewidth": 2, "alpha": 1, "zorder": 2},
    # right turn - dark blue & star marker
    "RightTurn": {"color": "#000099", "linewidth": 2, "alpha": 1, "zorder": 2},
    # right change - light blue
    "RightChange": {"color": "#ADD8E6", "linewidth": 2, "alpha": 1, "zorder": 2},
    # right u turn - normal blue
    "RightUturn": {"color": "#0000FF", "linewidth": 2, "alpha": 1, "zorder": 2},
    # right nudge - light blue
    "RightNudge": {"color": "#00CED1", "linewidth": 2, "alpha": 1, "zorder": 2},
    # learnable
    "learnable": {"color": "#111111", "linewidth": 2, "alpha": 1, "zorder": 2},
    # postive trajectory - orange
    "wta": {"color": "#CD5555", "linewidth": 3, "alpha": 1, "zorder": 3},
    # postive trajectory - deep green
    "sta": {"color": "#698B22", "linewidth": 2, "alpha": 1, "zorder": 4},
}


EGO_INTENTION_POINTS_LOT_CNFIG = {
    "positive": {"color": "#FF4500", "linewidth": 5, "marker": "o", "zorder": 5},
    "negative": {"color": "#191970", "linewidth": 5, "marker": "o", "zorder": 5},
}

# SCENE_MAP = {
#     "LK": "lane_keep",
#     "LT": "left_turn",
#     "LC": "left_change",
#     "LA": "left_around",
#     "LN": "left_nudge",
#     "RT": "right_turn",
#     "RC": "right_change",
#     "RA": "right_around",
#     "RN": "right_nudge",
#     "Learnabl_LK": "learnable",
# }
SCENE_MAP = [
    "LaneKeep",
    # "Learnable_LaneKeep",
    "LeftChange",
    "RightChange",
    "LeftTurn",
    "RightTurn",
    "LeftUturn",
    "RightUturn",
    "LeftNudge",
    "RightNudge",
]

# SCENE_TO_VIS = ["Learnabl_LK", "LK", "LT", "RT", "LC", "RC"]

# Coordianate Conversion Functions.


def trans_ego2img(coords, offsets):
    """Convert coordinates from ego coordinate to image coordinate."""
    if not isinstance(coords, np.ndarray):
        coords = coords.detach().cpu().numpy()
    coords_uv = coords[..., :2] * 10
    coords_uv[..., 0] = coords_uv[..., 0] + offsets[0]
    coords_uv[..., 1] = coords_uv[..., 1] + offsets[1]
    return coords_uv


def calculate_rectangle_corners(bbox):
    """Calculate rectangle corners of a rotated bbox."""
    assert len(bbox) == 5
    x, y, w, h, theta = bbox
    half_w = w / 2
    half_h = h / 2

    corners = np.array(
        [
            [-half_w, -half_h],
            [half_w, -half_h],
            [half_w, half_h],
            [-half_w, half_h],
        ]
    )
    rotation_matrix = np.array([[np.cos(theta), -np.sin(theta)], [np.sin(theta), np.cos(theta)]])
    rotated_corners = rotation_matrix @ corners.T
    rotated_corners = rotated_corners.T
    rotated_corners += np.array([x, y])
    return rotated_corners


# Draw Functions.


def draw_frame(
    clip_id,
    frame_id,
    save_dir: Path,
    timestamp: Optional[float] = None,
    canvas_size=(1000, 1750),
    reference_offset=250,
    select_scenes=["LK"],
    laneline_points: Optional[torch.Tensor] = None,
    laneline_types: Optional[torch.Tensor] = None,
    navi_lane_points: Optional[torch.Tensor] = None,
    navi_lane_types: Optional[torch.Tensor] = None,
    navi_path_points: Optional[torch.Tensor] = None,
    navi_path_types: Optional[torch.Tensor] = None,
    navi_lane_match_idx: Optional[torch.Tensor] = None,
    wta_lane_match_idx: Optional[torch.Tensor] = None,
    sta_lane_idx: Optional[torch.Tensor] = None,
    od_bboxes: Optional[torch.Tensor] = None,
    od_bboxes_mask: Optional[torch.Tensor] = None,
    ego_gt_traj: Optional[torch.Tensor] = None,
    gt_traj_mask: Optional[torch.Tensor] = None,
    ego_pred_traj: Optional[torch.Tensor] = None,
    ego_pred_score: Optional[torch.Tensor] = None,
    ego_pred_pos_traj: Optional[torch.Tensor] = None,
    drive_path: Optional[torch.Tensor] = None,
    dis_wta_pred_pos_traj: Optional[torch.Tensor] = None,
    sta_pred_pos_traj: Optional[torch.Tensor] = None,
    cuerrent_scene: Optional[str] = None,
    navi_scenes_pred: Optional[str] = None,
    ego_intention_points: Optional[torch.Tensor] = None,
    best_select_scene_idx: Optional[torch.Tensor] = None,
    navi_best_mod_ego_select_idx: Optional[torch.Tensor] = None,
):
    """Draw one frame."""
    # generate save folder
    clip_save_dir = save_dir / clip_id
    clip_save_dir.mkdir(parents=True, exist_ok=True)
    save_path = clip_save_dir / f"{frame_id:04d}.png"

    # generate image title
    title = f"clip: {clip_id}"
    if timestamp is not None:
        title += f", timestamp: {timestamp:.4f}"

    # generate canvas
    plt.figure(dpi=100, figsize=(20, 10))
    ax = plt.gca()
    ax.set_title(title)
    ax.set_xlim(0, canvas_size[1])
    ax.set_ylim(0, canvas_size[0])

    # bev coordinate origin points offset on image coordinate
    coord_offsets = [reference_offset, canvas_size[0] // 2]

    # draw current scene on left top corner
    if cuerrent_scene is not None:
        ax.text(
            10,
            canvas_size[0] - 50,
            "navi scene gt: " + cuerrent_scene,
            fontsize=16,
            color="black",
            bbox={"facecolor": "white", "alpha": 1.0, "pad": 5},
        )
    if navi_scenes_pred is not None:
        ax.text(
            10,
            canvas_size[0] - 100,
            "navi scene pred: " + navi_scenes_pred,
            fontsize=16,
            color="black",
            bbox={"facecolor": "white", "alpha": 1.0, "pad": 5},
        )
    # set axis ticks
    grid_size = 250
    ax.set_xticks(np.arange(0, canvas_size[1], grid_size))
    ax.set_xticklabels((np.arange(0, canvas_size[1], grid_size) - coord_offsets[0]) // 10)
    ax.set_yticks(np.arange(0, canvas_size[0] + 1, grid_size))
    ax.set_yticklabels((np.arange(0, canvas_size[0] + 1, grid_size) - coord_offsets[1]) // 10)
    ax.grid(True)

    # draw lane lines
    if laneline_points is not None and laneline_types is not None:
        for lane_line, lane_type in zip(laneline_points, laneline_types):
            lane_mask = lane_type >= 0
            # skip invalid lane
            if lane_mask.sum() == 0:
                continue
            lane_line = lane_line[lane_mask]
            lane_type = lane_type[lane_mask][0]
            plot_cfg = LANELINE_PLOT_CONFIG.get(int(lane_type), None)
            if plot_cfg is not None:
                lane_line_pts = trans_ego2img(lane_line, offsets=coord_offsets)
                ax.plot(lane_line_pts[:, 0], lane_line_pts[:, 1], **plot_cfg)

    # draw navilane
    # ax.text(
    #     10,
    #     canvas_size[0] - 150,
    #     f"valid navilane num: {navi_lane_types}",
    #     fontsize=16,
    #     color="black",
    #     bbox={"facecolor": "white", "alpha": 1.0, "pad": 5},
    # )

    if navi_path_points is not None and navi_path_types is not None:
        for navi_path, navi_path_type in zip(navi_path_points, navi_path_types):
            navi_path_mask = navi_path_type >= 0
            # skip invalid navi path
            if (navi_path_mask == -1).all():
                continue
            navi_path = navi_path[navi_path_mask]
            valid_navi_path = trans_ego2img(navi_path, offsets=coord_offsets)
            plot_cfg = deepcopy(NAVIPATH_PLOT_CONFIG["positive"])
            plot_cfg["label"] = "navi path"
            ax.plot(valid_navi_path[:, 0], valid_navi_path[:, 1], **plot_cfg)
            break  # only one navi path

    if navi_lane_points is not None and navi_lane_types is not None:
        # plot all navilane
        for navi_lane_idx in range(navi_lane_points.shape[0]):
            navi_lane = navi_lane_points[navi_lane_idx]
            navi_lane_type = navi_lane_types[navi_lane_idx]
            navi_lane_mask = navi_lane_type >= 0
            valid_navi_lane = trans_ego2img(navi_lane[navi_lane_mask], offsets=coord_offsets)
            navi_lane_type = navi_lane_type[navi_lane_mask]
            if not isinstance(navi_lane_type, np.ndarray):
                navi_lane_type = navi_lane_type.detach().cpu().numpy()
            lk_mask = navi_lane_type == 0
            lt_mask = navi_lane_type == 1
            rt_mask = navi_lane_type == 2
            lc_mask = navi_lane_type == 3
            rc_mask = navi_lane_type == 4
            left_change_plot_cfg = deepcopy(NAVILANE_PLOT_CONFIG["left_change"])
            right_change_plot_cfg = deepcopy(NAVILANE_PLOT_CONFIG["right_change"])
            left_turn_plot_cfg = deepcopy(NAVILANE_PLOT_CONFIG["left_turn"])
            right_turn_plot_cfg = deepcopy(NAVILANE_PLOT_CONFIG["right_turn"])
            lane_keep_plot_cfg = deepcopy(NAVILANE_PLOT_CONFIG["lane_keep"])
            left_around_plot_cfg = deepcopy(NAVILANE_PLOT_CONFIG["left_around"])
            right_around_plot_cfg = deepcopy(NAVILANE_PLOT_CONFIG["right_around"])
            # add label for the first positive navilane
            # add label for the first negative navilane
            if navi_lane_idx == 0:
                lane_keep_plot_cfg["label"] = "navilane LK"
                left_turn_plot_cfg["label"] = "navilane LT"
                right_turn_plot_cfg["label"] = "navilane RT"
                left_change_plot_cfg["label"] = "navilane LC"
                right_change_plot_cfg["label"] = "navilane RC"
                left_around_plot_cfg["label"] = "navilane LA"
                right_around_plot_cfg["label"] = "navilane RA"
            # plot negative navilane
            ax.plot(valid_navi_lane[lk_mask, 0], valid_navi_lane[lk_mask, 1], **lane_keep_plot_cfg)
            ax.plot(valid_navi_lane[lt_mask, 0], valid_navi_lane[lt_mask, 1], **left_turn_plot_cfg)
            ax.plot(valid_navi_lane[rt_mask, 0], valid_navi_lane[rt_mask, 1], **right_turn_plot_cfg)
            ax.plot(valid_navi_lane[lc_mask, 0], valid_navi_lane[lc_mask, 1], **left_change_plot_cfg)
            ax.plot(valid_navi_lane[rc_mask, 0], valid_navi_lane[rc_mask, 1], **right_change_plot_cfg)

        # plot positive navilane at top of all navilane
        # if navi_lane_match_idx is not None and navi_lane_match_idx >= 0:
        #     navi_lane = navi_lane_points[navi_lane_match_idx]
        #     navi_lane_type = navi_lane_types[navi_lane_match_idx]
        #     navi_lane_mask = navi_lane_type >= 0
        #     valid_navi_lane = trans_ego2img(navi_lane[navi_lane_mask], offsets=coord_offsets)
        #     navi_lane_type = navi_lane_type[navi_lane_mask]
        #     if not isinstance(navi_lane_type, np.ndarray):
        #         navi_lane_type = navi_lane_type.detach().cpu().numpy()
        #     lk_mask = navi_lane_type == 0
        #     lt_mask = navi_lane_type == 1
        #     lc_mask = navi_lane_type == 4
        #     lane_change_plot_cfg = deepcopy(NAVILANE_PLOT_CONFIG["negative_lane_change"])
        #     lane_keep_plot_cfg = deepcopy(NAVILANE_PLOT_CONFIG["negative_lane_keep"])
        #     lane_turn_plot_cfg = deepcopy(NAVILANE_PLOT_CONFIG["negative_lane_turn"])
        #     ax.plot(
        #         valid_navi_lane[lc_mask, 0], valid_navi_lane[lc_mask, 1], **NAVILANE_PLOT_CONFIG["positive_lane_change"], label="pos navilane LC"
        #     )
        #     ax.plot(
        #         valid_navi_lane[lk_mask, 0], valid_navi_lane[lk_mask, 1], **NAVILANE_PLOT_CONFIG["positive_lane_keep"], label="pos navilane LK"
        #     )
        #     ax.plot(
        #         valid_navi_lane[lt_mask, 0], valid_navi_lane[lt_mask, 1], **NAVILANE_PLOT_CONFIG["positive_lane_turn"], label="pos navilane LT"
        #     )

    # draw od bboxes
    if od_bboxes is not None and od_bboxes_mask is not None:
        valid_od_bboxes = od_bboxes[od_bboxes_mask.bool()]
        bboxes_bev = valid_od_bboxes[:, [0, 1, 3, 4, 6]].cpu().numpy()
        for bbox in bboxes_bev:
            bbox_corners = calculate_rectangle_corners(bbox)
            img_pts = trans_ego2img(bbox_corners, offsets=coord_offsets)
            ax.add_patch(Polygon(img_pts, closed=True, **BBOX_PLOT_CONFIG["OD"]))

    # draw ego bbox
    ego_bbox = np.array([[2.5, 1.0], [2.5, -1.0], [-2.5, -1.0], [-2.5, 1.0]])
    ego_img_pts = trans_ego2img(ego_bbox, offsets=coord_offsets)
    ax.add_patch(Polygon(ego_img_pts, closed=True, **BBOX_PLOT_CONFIG["EGO"]))

    # draw ego gt trajectory
    if ego_gt_traj is not None:
        ego_gt_traj = ego_gt_traj[gt_traj_mask.bool()]
        ego_gt_img_pts = trans_ego2img(ego_gt_traj, offsets=coord_offsets)
        ax.plot(ego_gt_img_pts[:, 0], ego_gt_img_pts[:, 1], **GT_TRAJECTORY_PLOT_CONFIG, label="gt traj")

    traj_num_per_scene = ego_pred_score.shape[0] // len(select_scenes)

    # draw anchors
    # ego_intention_points = ego_intention_points.reshape(len(select_scenes), -1, 2)
    # navi_scene_ego_intention_points = ego_intention_points[best_select_scene_idx]
    # navi_scene_ego_intention_points = trans_ego2img(navi_scene_ego_intention_points, offsets=coord_offsets)
    # for idx, point in enumerate(navi_scene_ego_intention_points):
    #     inner_idx = navi_best_mod_ego_select_idx - best_select_scene_idx * traj_num_per_scene
    #     if idx != inner_idx:
    #         plot_cfg = EGO_INTENTION_POINTS_LOT_CNFIG["negative"]
    #         # plot_label="select scene negtive anchor"
    #     else:
    #         plot_cfg = EGO_INTENTION_POINTS_LOT_CNFIG["positive"]
    #         # plot_label="select scene positive anchor"

    #     ax.plot(
    #         point[0],
    #         point[1],
    #         **plot_cfg,
    #         # label=plot_label,
    #     )
    # ax.text(
    #     10,
    #     canvas_size[0] - 150,
    #     "anchor scene matched: " + SCENE_TO_VIS[best_select_scene_idx],
    #     fontsize=16,
    #     color="black",
    #     bbox={"facecolor": "white", "alpha": 1.0, "pad": 5},
    # )

    # draw ego pred trajectory
    if ego_pred_traj is not None and ego_pred_score is not None:
        ego_pred_img_pts = trans_ego2img(ego_pred_traj.unflatten(-1, (-1, 2)), offsets=coord_offsets)
        ego_pred_score = ego_pred_score.detach().cpu().numpy()
        # for i, traj in enumerate(ego_pred_img_pts):
        #     plot_cfg = deepcopy(PRED_TRAJECTORY_PLOT_CONFIG["negative"])
        #     # add label for the first negative trajectory
        #     if i == 0:
        #         plot_cfg["label"] = "pred neg traj"
        #     ax.plot(traj[:, 0], traj[:, 1], **plot_cfg)

        # for scene in SCENE_TO_VIS:
        for scene in [navi_scenes_pred]:
            idx = select_scenes.index(scene)
            # scene_full_name = SCENE_MAP[scene]
            # sort_score_idx = np.argsort(
            #     ego_pred_score[idx * traj_num_per_scene : idx * traj_num_per_scene + traj_num_per_scene]  # type: ignore[index]
            # )
            # sort_score_idx = sort_score_idx[::-1]
            # scene_full_name = scene
            for i, s_idx in enumerate([0, 1]):
                if s_idx == 0:
                    plot_cfg = deepcopy(PRED_TRAJECTORY_PLOT_CONFIG["ChooseScene"])
                else:
                    plot_cfg = deepcopy(PRED_TRAJECTORY_PLOT_CONFIG["LaneKeep"])
                if i == 0:
                    plot_cfg["label"] = "WayPointNormal"
                    plot_cfg["alpha"] = 1.0
                else:
                    # plot_cfg["label"] = f"pred {scene_full_name} extra traj"
                    plot_cfg["alpha"] = 1.0
                    # plot_cfg["linestyle"] = "--"
                    plot_cfg["label"] = "WayPointLaneKeep"
                s_idx = idx * traj_num_per_scene + s_idx

                ax.plot(
                    ego_pred_img_pts[s_idx][:, 0],
                    ego_pred_img_pts[s_idx][:, 1],
                    **plot_cfg,
                )
                if scene != navi_scenes_pred:
                    break
        # draw positive trajectory
        if ego_pred_pos_traj is not None:
            ego_pred_pos_img_pts = trans_ego2img(ego_pred_pos_traj, offsets=coord_offsets)
            ax.plot(
                ego_pred_pos_img_pts[:, 0],
                ego_pred_pos_img_pts[:, 1],
                **PRED_TRAJECTORY_PLOT_CONFIG["positive"],
                label="pred pos matched traj",
            )
        if drive_path is not None:
            drive_path_img_pts = trans_ego2img(drive_path, offsets=coord_offsets)
            ax.plot(
                drive_path_img_pts[0, :, 0],
                drive_path_img_pts[0, :, 1],
                **PRED_TRAJECTORY_PLOT_CONFIG["DrivePathNormal"],
                label="DrivePathNormal",
            )
            ax.plot(
                drive_path_img_pts[1, :, 0],
                drive_path_img_pts[1, :, 1],
                **PRED_TRAJECTORY_PLOT_CONFIG["DrivePathLaneKeep"],
                label="DrivePathLaneKeep",
            )
        # if dis_wta_pred_pos_traj is not None:
        #     dis_wta_pred_pos_img_pts = trans_ego2img(dis_wta_pred_pos_traj,
        #                                              offsets=coord_offsets)
        #     ax.plot(
        #         dis_wta_pred_pos_img_pts[:, 0],
        #         dis_wta_pred_pos_img_pts[:, 1],
        #         **PRED_TRAJECTORY_PLOT_CONFIG["wta"],
        #         label="pred pos wta traj",
        #     )
        # if sta_pred_pos_traj is not None:
        #     sta_pred_pos_img_pts = trans_ego2img(sta_pred_pos_traj,
        #                                          offsets=coord_offsets)
        #     ax.plot(
        #         sta_pred_pos_img_pts[:, 0],
        #         sta_pred_pos_img_pts[:, 1],
        #         **PRED_TRAJECTORY_PLOT_CONFIG["sta"],
        #         label="pred pos sta traj",
        #     )

    plt.legend(loc="upper right")
    plt.savefig(save_path, bbox_inches="tight")
    logger.info(f"save match result image at {save_path}")  # noqa: G004


# Main Function.


def visualize_astra_planner_match_result(model_inputs, model_outputs, select_scenes=["LK", "LT", "RT", "LC", "RC"]):
    """Plot match results."""
    save_dir = Path(FileManager.get_export_dir()) / "match_results"
    save_dir.mkdir(parents=True, exist_ok=True)

    batch_size = len(model_inputs["subclip_ids"])

    for i in range(batch_size):
        if "wta_selected_ego_pred" in model_outputs["marginal_output"]:
            dis_wta_pred_pos_traj = model_outputs["marginal_output"]["wta_selected_ego_pred"][i, 0]
        else:
            dis_wta_pred_pos_traj = None

        if "sta_selected_ego_pred" in model_outputs["marginal_output"]:
            sta_pred_pos_traj = model_outputs["marginal_output"]["sta_selected_ego_pred"][i, 0]
        else:
            sta_pred_pos_traj = None
        if "navi_scene_pred_name" in model_outputs["marginal_output"]:
            navi_scenes_pred = model_outputs["marginal_output"]["navi_scene_pred_name"][i]
        else:
            navi_scenes_pred = None

        laneline_points = (
            model_inputs["lane_points"] if "lane_points" in model_inputs else model_inputs["manner_lane_points"]
        )
        laneline_types = (
            model_inputs["lane_types"] if "lane_types" in model_inputs else model_inputs["manner_lane_types"]
        )

        navi_path_points = model_inputs["navi_path_points"] if "navi_path_points" in model_inputs else None
        navi_path_types = model_inputs["navi_path_types"] if "navi_path_types" in model_inputs else None

        draw_frame(
            clip_id=model_inputs["subclip_ids"][i],
            frame_id=int(model_inputs["ids"][i].split("_")[-1]),
            save_dir=save_dir,
            select_scenes=select_scenes,
            timestamp=model_inputs["timestamp"][i, -1],
            laneline_points=laneline_points[i],
            laneline_types=laneline_types[i],
            navi_lane_points=model_inputs["navi_line_points"][i],
            navi_lane_types=model_inputs["navi_line_types"][i],
            navi_path_points=navi_path_points[i],
            navi_path_types=navi_path_types[i],
            navi_lane_match_idx=model_outputs["marginal_output"]["navi_ego_chosen_idx_k"][i],
            od_bboxes=model_inputs["bboxes"][i, -1],
            od_bboxes_mask=1 - model_inputs["bboxes_padding_mask"][i, -1],
            ego_gt_traj=model_inputs["egos_pred_gt"][i, 0],  # T 2
            gt_traj_mask=model_inputs["egos_pred_mask"][i, 0],  # T
            ego_pred_traj=model_outputs["marginal_output"]["ego_pred_pos"][i, 0],
            ego_pred_score=model_outputs["marginal_output"]["ego_pred_score"][i, 0],
            ego_pred_pos_traj=model_outputs["marginal_output"]["selected_ego_pred"][i, 0],
            drive_path=model_outputs["marginal_output"]["ego_pred_drive_path"][i, 0],
            dis_wta_pred_pos_traj=dis_wta_pred_pos_traj,
            sta_pred_pos_traj=sta_pred_pos_traj,
            cuerrent_scene=model_inputs["navilane_scene_type"][i],
            navi_scenes_pred=navi_scenes_pred,
            # ego_intention_points=model_outputs["ego_intention_points"][i],
            # best_select_scene_idx=model_outputs["marginal_output"]["best_select_scene_idx"][i],
            # navi_best_mod_ego_select_idx=model_outputs["marginal_output"]["navi_best_mod_ego_select_idx"][i],
        )
