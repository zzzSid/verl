# -*- coding: utf-8 -*-
"""Generate viz results."""
import argparse
import os
import shutil
from multiprocessing import Pool
from os import listdir
from os.path import join

import numpy as np

from tpp_onemodel.tools.astra_planner.input_output_viz import plot_sample


def plot_bokeh_result(bokeh_dir: str):
    """Plot bokeh pickle result in the giving directory."""
    for f in listdir(args.bokeh_dir):
        full_name = join(args.bokeh_dir, f)
        if os.path.isdir(full_name):
            shutil.rmtree(full_name)

    num_processes = 16
    for f in listdir(args.bokeh_dir):
        full_name = join(args.bokeh_dir, f)
        dir_name = full_name + "_img"
        if os.path.isdir(dir_name):
            shutil.rmtree(dir_name)
        os.mkdir(dir_name)
        raw_data = np.load(full_name, allow_pickle=True)
        inputs = []
        for idx, val in enumerate(raw_data):
            fn = str(val["timestamp"][-1]) + "_" + str(idx)
            fn = fn.replace(".", "_")
            inputs.append((val, join(dir_name, fn)))

        with Pool(processes=num_processes) as pool:
            # Use starmap to pass multiple arguments to the function in parallel
            pool.starmap(plot_sample, inputs)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--bokeh_dir", type=str, required=True, help="bokeh_dir")
    args = parser.parse_args()
    plot_bokeh_result(args.bokeh_dir)
