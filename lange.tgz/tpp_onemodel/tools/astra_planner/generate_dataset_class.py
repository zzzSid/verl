# -*- coding: utf-8 -*-
import argparse
import json
import os
import random


def write_to_file(output_dataset_class_path, proportion, update_subtasks, root_dir, datasets, dataset_mode, file_name):
    """
    Write dataset configuration to a file.

    Args:
        output_dataset_class_path (str): The path to the output dataset class file.
        proportion (float): The proportion value.
        update_subtasks (List[str]): The list of update subtasks.
        root_dir (str): The root directory.
        datasets (List[str]): The list of datasets.
        dataset_mode (str): The dataset mode.
        file_name (str): The file name.

    Returns:
        None
    """
    content = f"""class Dataset_{file_name}_{dataset_mode}(DatasetConfig):
    proportion: float = {proportion}
    update_subtasks: List[str] = {json.dumps(update_subtasks)}
    root_dir: str = "{root_dir}"
    datasets: List[str] = {json.dumps(datasets)}
    """

    with open(output_dataset_class_path, "a") as file:
        file.write(content)
        file.write("\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Write specified content to a text file.")
    parser.add_argument(
        "--output_dataset_class_path", type=str, default="./new_dataset_class.txt", help="The path to the text file"
    )
    # parser.add_argument("--proportion", type=float, required=True, help="The proportion value")
    # parser.add_argument("--update_subtasks", type=str, nargs="+", required=True, help="The list of update subtasks")
    parser.add_argument(
        "--root_dir",
        type=str,
        default="/share-global/mccree.zhao/share/planning/dataset/0822_30w_route/",
        help="The root directory",
    )
    # parser.add_argument("--datasets", type=str, nargs="+", required=True, help="The list of datasets")
    parser.add_argument("--file_name", type=str, default="new_data", help="The name of new dataset")
    parser.add_argument("--target_tag_list", type=str, nargs="+", required=True, help="The list of target tags")
    parser.add_argument(
        "--target_scene_file_name", type=str, default="target_scene.txt", help="The name of target scene"
    )

    args = parser.parse_args()
    proportion = 1.0
    update_subtasks = ["prediction"]
    dataset_list = [f for f in os.listdir(args.root_dir) if f.endswith(".txt")]
    target_dataset_list = ["train", "test", "infer", "val", "debug"]
    matched_files = {
        target: [filename for filename in dataset_list if target in filename] for target in target_dataset_list
    }
    if os.path.exists(args.output_dataset_class_path):
        os.remove(args.output_dataset_class_path)
    for key, val in matched_files.items():
        # print(key, val)
        dataset_mode = key
        dataset = val
        write_to_file(
            args.output_dataset_class_path, 1.0, update_subtasks, args.root_dir, dataset, dataset_mode, args.file_name
        )
    print(f"New Dataset Class Write to {args.output_dataset_class_path} successfully!\n")  # noqa: T201

    print("Generate target scene dataset")  # noqa: T201
    target_tag_list = ["".join(target_tag) for target_tag in args.target_tag_list]
    print("target_tag_list is ", target_tag_list)  # noqa: T201
    single_scene_path_list = [f for f in os.listdir(args.root_dir) if not f.endswith(".txt")]
    for single_scene_path in single_scene_path_list:
        if "test" in single_scene_path:
            single_scene_name_list = os.listdir(os.path.join(args.root_dir, single_scene_path))
            badcase_list = []
            for single_scene_name in single_scene_name_list:
                if single_scene_name.split(".")[0] in target_tag_list:
                    scene_file_path = os.path.join(args.root_dir, single_scene_path, single_scene_name)
                    with open(scene_file_path, "r") as f:
                        scene_content = f.readlines()
                    badcase_list += scene_content
    random.shuffle(badcase_list)
    badcase_list_50 = badcase_list[0:50]
    split_filename = args.target_scene_file_name.split(".")
    target_scene_file_name = (
        split_filename[0] + "_{}".format(len(badcase_list)) + "." + split_filename[1]  # noqa: FS002
    )
    print("target_scene dataset name is ", args.target_scene_file_name)  # noqa: T201
    with open(os.path.join(args.root_dir, target_scene_file_name), "w") as f:
        f.writelines(badcase_list)
        print(f"Write to {os.path.join(args.root_dir, target_scene_file_name)} successfully!")  # noqa: T201
    target_scene_file_name_50 = (
        split_filename[0] + "_viz_{}".format(len(badcase_list_50)) + "." + split_filename[1]  # noqa: FS002
    )
    with open(os.path.join(args.root_dir, target_scene_file_name_50), "w") as f:
        f.writelines(badcase_list_50)
        print(f"Write to {os.path.join(args.root_dir, target_scene_file_name_50)} successfully!")  # noqa: T201
    write_to_file(
        args.output_dataset_class_path,
        1.0,
        update_subtasks,
        args.root_dir,
        [target_scene_file_name],
        "targetscene",
        args.file_name,
    )
