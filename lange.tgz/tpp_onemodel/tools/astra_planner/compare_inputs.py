# -*- coding: utf-8 -*-
"""Dump torch trace model."""
import argparse
import glob
import os
import os.path as osp
import time
from typing import List
from typing import Tuple

import matplotlib.pyplot as plt
import numpy as np
import torch
import torchpilot
from prettytable import PrettyTable
from torchpilot.utils.cfg_parser import PyConfig
from torchpilot.utils.plus_manager import load_plus
from torchpilot.utils.registries import DATALOADER


logger = torchpilot.logger

DTYPE = np.float32
DEVICE = torch.device("cuda")
np.set_printoptions(precision=2, suppress=True)


def parse_argus_dump_data(dump_dir: str, ts_ms: int) -> Tuple[List[torch.Tensor], List[torch.Tensor]]:
    """Parse meta info, numpy binary data from given the specific argus dump directory and timestamp with ms.

    Directory structure:
    dump_dir
    ├── input
    │   ├── 1715957111146
    │   │   ├── inputs_0
    │   │   ├── inputs_0.txt
    |   |   | ...
    └── output
    ├── 1715957111146
    │   ├── perception_obs_ids
    │   ├── perception_obs_ids.txt
    │   ├── top_joint_agent_trajs
    │   ├── top_joint_agent_trajs.txt
    │   ├── top_joint_ego_trajs
    │   ├── top_joint_ego_trajs.txt
    │   ├── top_scene_probs
    │   └── top_scene_probs.txt
    Txt format: 1;float32;1,15,194,40
    """
    input_path = osp.join(dump_dir, "input", str(ts_ms))
    txts_path = glob.glob(f"{input_path}/*.txt")

    input_list = []
    for i in range(len(txts_path)):
        with open(f"{input_path}/inputs_{i}.txt") as fh:
            lines = fh.readlines()
        parts = lines[0].split(";")
        _, dtype, shape_str = parts
        shape = tuple(map(int, shape_str.split(",")))
        data = np.fromfile(f"{input_path}/inputs_{i}", dtype=dtype)
        input_list.append(torch.from_numpy(data.reshape(shape)))

    output_path = osp.join(dump_dir, "output", str(ts_ms))
    txts_path = glob.glob(f"{output_path}/*.txt")
    output_list = []
    for output_txt_path in txts_path:
        with open(output_txt_path) as fh:
            lines = fh.readlines()
        parts = lines[0].split(";")
        _, dtype, shape_str = parts
        shape = tuple(map(int, shape_str.split(",")))
        data = np.fromfile(output_txt_path.replace(".txt", ""), dtype=dtype)
        output_list.append(torch.from_numpy(data.reshape(shape)))
    return input_list, output_list


def select_sample_by_ts(planner_cfg, ts_ms: int):
    """Select the clip frame sample by given micro-seconds timetamp."""
    data_cfg = planner_cfg.infer_dataloader
    data_cfg.dataset_cfg.batch_size = 1
    data_cfg.num_workers = 1
    data_cfg.dataset_cfg.num_workers = 0
    data_cfg.dataset_cfg.shuffle = False
    data_cfg.prefetch_factor = 1
    # data_cfg.dataset_cfg.debug = True
    data_loader = DATALOADER.build(data_cfg)
    for sample in data_loader:
        cur_ms = int(sample["timestamp"][0, -1] * 1000)
        if abs(cur_ms - ts_ms) < 10:
            logger.info("time_diff: %f ms", cur_ms - ts_ms)
            return {key: sample[key] for key in trace_input_keys}
        else:
            logger.info("time_diff: %f ms", cur_ms - ts_ms)
    logger.warning("Can't find the sample near given timestamp")
    return None


def compare_maps_lanes(
    map1_points: torch.Tensor,
    map1_types: torch.Tensor,
    map2_points: torch.Tensor,
    map2_types: torch.Tensor,
    save_path: str,
):
    """Compare and visualize the lane lines from two different maps."""
    # Convert tensors to numpy arrays
    map1_points_np = map1_points.numpy()
    map1_types_np = map1_types.numpy()
    map2_points_np = map2_points.numpy()
    map2_types_np = map2_types.numpy()

    plt.figure(figsize=(10, 10))

    num_lanes = map1_points_np.shape[1]
    map1_lane_num = 0
    map2_lane_num = 0

    for lane_idx in range(num_lanes):
        # Get valid points from map 1
        map1_valid_mask = map1_types_np[0, lane_idx, :] != -1
        map1_valid_points = map1_points_np[0, lane_idx, map1_valid_mask, :]

        # Get valid points from map 2
        map2_valid_mask = map2_types_np[0, lane_idx, :] != -1
        map2_valid_points = map2_points_np[0, lane_idx, map2_valid_mask, :]

        if map1_valid_points.shape[0] > 0:
            map1_lane_num += 1
            plt.plot(map1_valid_points[:, 0], map1_valid_points[:, 1], "o-", color="green")

        if map2_valid_points.shape[0] > 0:
            map2_lane_num += 1
            plt.plot(map2_valid_points[:, 0], map2_valid_points[:, 1], "x--", color="red")

    plt.title("Lane Line Comparison Between Cpp/Python")
    plt.xlabel("X")
    plt.ylabel("Y")
    plt.grid(True)

    # Add single legend for each map
    plt.plot([], [], "o-", color="green", label=f"Cpp (o-): {map1_lane_num}")
    plt.plot([], [], "x--", color="red", label=f"Pyton (x--): {map2_lane_num}")
    plt.legend(title="Source, Line Type, Line Num", loc="upper right")
    plt.savefig(save_path)


def sort_sod_box(boxes):
    """Sort sod boxes."""
    ids = boxes[:, 9]
    non_zero_id_mask = ids != 0

    boxes = boxes[non_zero_id_mask]
    no_zero_ids = boxes[:, 9]

    sorted_indices = torch.argsort(no_zero_ids)
    sorted_boxes = boxes[sorted_indices]

    return sorted_boxes


if __name__ == "__main__":
    load_plus()
    torch.distributed.init_process_group(
        backend="nccl",
        init_method="tcp://localhost:9999",
        world_size=1,
        rank=0,
    )

    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--cfg_planner", type=str, required=True, help="planner_cfg")
    parser.add_argument("--cpp_dump_dir", type=str, required=True, help="cpp_dump_dir")
    parser.add_argument("--ts", type=int, required=True, help="Compare timestamp.")
    parser.add_argument("--result_dir", type=str, required=False, default="./export_models/")
    args = parser.parse_args()

    cfg = PyConfig.fromfile(args.cfg_planner)

    # The input and ouput keys need to align with the deploy version.
    trace_input_keys = [
        "bboxes",
        "bboxes_padding_mask",
        "egos",
        "egos_padding_mask",
        "lane_points",
        "lane_types",
        "sod_poly_boxes",
        "sod_poly_boxes_padding_mask",
        "sod_poly_pts",
        "sod_poly_pts_padding_mask",
        "tld",
        "tld_padding_mask",
        "atlas",
        "sdmap_polylines",
        "sdmap_polylines_type",
        "global_routing_mask",
        "hist2curr_trans",
        "delta_timestamp",
    ]

    trace_output_keys = [
        "top_joint_ego_trajs",
        "top_joint_agent_trajs",
        "top_scene_probs",
        "perception_obs_ids",
    ]

    ts_ms = args.ts

    argi, argo = parse_argus_dump_data(args.cpp_dump_dir, ts_ms)
    dsi = select_sample_by_ts(cfg, ts_ms)
    compare_keys = [
        "bboxes",
        "bboxes_padding_mask",
        "egos",
        "egos_padding_mask",
        "lane_points",
        "lane_types",
        "sod_poly_boxes",
        "sod_poly_boxes_padding_mask",
        "sod_poly_pts",
        "sod_poly_pts_padding_mask",
        "tld",
        "tld_padding_mask",
        "hist2curr_trans",
        "delta_timestamp",
    ]

    mse_dict = {}
    for t1, key in zip(argi, trace_input_keys):
        if key in compare_keys:
            if key == "sod_poly_boxes":  # TODO(ian.xu) for debug
                sorted_pyboxes = sort_sod_box(dsi[key][0])
                sorted_cppboxes = sort_sod_box(t1[0])

            if not torch.allclose(t1, dsi[key], atol=1e-04):
                squared_difference = (t1 - dsi[key]) ** 2
                mean_squared_error = torch.mean(squared_difference).item()
                mse_dict[key] = mean_squared_error
            else:
                mse_dict[key] = 0.0
            logger.info("%s mean squared error: %f", key, mse_dict[key])

    cmp_result = PrettyTable()
    cmp_result.field_names = ["input_name", "tensor shape", "mean squared error", "arg ppl slice", "dataset slice"]
    cur_key = "delta_timestamp"
    cmp_result.add_row([cur_key, dsi[cur_key].shape, mse_dict[cur_key], argi[-1][0, :], dsi[cur_key][0, :]])

    cur_key = "hist2curr_trans"
    cmp_result.add_row(
        [cur_key, dsi[cur_key].shape, mse_dict[cur_key], argi[-2][0, -2:, ...], dsi[cur_key][0, -2:, ...]]
    )

    cur_key = "egos"
    cmp_result.add_row(
        [cur_key, dsi[cur_key].shape, mse_dict[cur_key], argi[2][0, -2:, ...], dsi[cur_key][0, -2:, ...]]
    )

    cur_key = "egos_padding_mask"
    cmp_result.add_row([cur_key, dsi[cur_key].shape, mse_dict[cur_key], argi[3][0, :, 0], dsi[cur_key][0, :, 0]])

    cur_key = "bboxes"
    cmp_result.add_row(
        [cur_key, dsi[cur_key].shape, mse_dict[cur_key], argi[0][0, -2:, 0, :], dsi[cur_key][0, -2:, 0, :]]
    )

    cur_key = "bboxes_padding_mask"
    cmp_result.add_row([cur_key, dsi[cur_key].shape, mse_dict[cur_key], argi[1][0, -2:, 0], dsi[cur_key][0, -2:, 0]])

    cur_key = "lane_types"
    cmp_result.add_row(
        [cur_key, dsi[cur_key].shape, mse_dict[cur_key], argi[5][0, -2:, 0], dsi[cur_key][0, -2:, 0]]
    )  # last 2 lane, first point

    cur_key = "sod_poly_boxes"
    cmp_result.add_row([cur_key, dsi[cur_key].shape, mse_dict[cur_key], argi[6][0, 0, :], dsi[cur_key][0, 0, :]])

    cur_key = "sod_poly_boxes_padding_mask"
    cmp_result.add_row([cur_key, dsi[cur_key].shape, mse_dict[cur_key], argi[7], dsi[cur_key]])

    cur_key_val = "sod_poly_pts"
    cmp_result.add_row(
        [cur_key_val, dsi[cur_key_val].shape, mse_dict[cur_key_val], argi[8][0, 0, :], dsi[cur_key_val][0, 0, :]]
    )

    cur_key = "sod_poly_pts_padding_mask"
    cmp_result.add_row([cur_key, dsi[cur_key].shape, mse_dict[cur_key], argi[9][0, 0, :], dsi[cur_key][0, 0, :]])

    sum_along_ft_dim = dsi[cur_key][0].sum(dim=1)

    if not osp.exists(args.result_dir):
        os.mkdir(args.result_dir)
    timestr = time.strftime("%Y%m%d%H%M%S")

    table_result_path = osp.join(args.result_dir, f"compare_input_table_{timestr}.txt")
    with open(
        table_result_path,
        "w",
        encoding="utf-8",
    ) as fout:
        fout.write(cmp_result.get_string())

    lane_plot_path = osp.join(args.result_dir, f"lanes_diff_{timestr}.jpg")
    compare_maps_lanes(argi[4], argi[5], dsi["lane_points"], dsi["lane_types"], lane_plot_path)

    logger.info("result saved in: %s, %s", table_result_path, lane_plot_path)
    logger.info("Success!!!")
