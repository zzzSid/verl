# -*- coding: utf-8 -*-
import argparse
import os
import pickle as pkl

import numpy as np
import torch


trace_input_keys = [
    "bboxes",
    "bboxes_padding_mask",
    "egos",
    "egos_padding_mask",
    "lane_points",
    "lane_types",
    "lane_attr",
    "sod_poly_boxes",
    "sod_poly_boxes_padding_mask",
    "sod_poly_pts",
    "sod_poly_pts_padding_mask",
    "atlas",
    "sdmap_polylines",
    "sdmap_polylines_type",
    "global_routing_mask",
    "hist2curr_trans",
    "delta_timestamp",
    "navi_line_points",
    "navi_line_types",
    "god_poly_pts",
    "god_poly_pts_padding_mask",
    "god_attrs",
    "god_attr_padding_mask",
    "road_detection_veh2ref",
    "road_post_veh2ref",
    "atlas_veh2ref",
    "navi_lane_to_target_lc_times",
    "navi_lane_tld",
    "navi_lane_stoppoints",
    "navi_lane_speed_limit",
    "navi_path_points",
    "tld",
    "tld_padding_mask",
    "navi_path_types",
    "navi_path_tld",
    "navi_path_stoppoints",
    "navi_path_speed_limit",
    "control_points",
    "egos_gear",
    "uturn_control_points",
    "prediction_traj",
    "od_prior_mask_input",
]


class ARInferPipeline:
    """Autoregressive inference pipeline for managing multiple JIT trace models."""

    def __init__(
        self, model_paths: dict, device: str = "cuda", ar_infer_ts_hist_num: int = 15, infer_step_num: int = 25
    ):
        """
        Initialize the inference pipeline.

        Args:
            model_paths: Dictionary containing the following keys with corresponding model paths:
                - "preprocess": Preprocess model path
                - "loop_flatten": Loop_flatten model path
                - "add_on": Add_on model path
                - "reward": Reward model path
            device: Device to load models ("cpu" or "cuda")
        """
        self.ar_infer_ts_hist_num = ar_infer_ts_hist_num
        self.infer_step_num = infer_step_num

        # Store device information
        self.device = torch.device(device)

        # Validate required model keys
        required_keys = {"preprocess", "loop_flatten", "add_on", "reward"}
        if set(model_paths.keys()) != required_keys:
            missing = required_keys - set(model_paths.keys())
            extra = set(model_paths.keys()) - required_keys
            raise ValueError(f"Model path configuration error. Missing keys: {missing}, Extra keys: {extra}")

        # Load all traced models
        self.models = {}
        for name, path in model_paths.items():
            if not isinstance(path, str) or not path.endswith(".pt"):
                raise TypeError(f"Model path '{name}' must be a string ending with .pt")
            try:
                # Load model to the specified device
                model = torch.jit.load(path, map_location=self.device)
                model.eval()  # Set to inference mode
                self.models[name] = model
            except Exception as e:
                raise RuntimeError(f"Failed to load model '{name}': {str(e)}") from e

    def trace_forward(self, *args, mode="all"):
        """
        Execute full autoregressive inference pipeline.

        Args:
            *args: Input arguments for the models
            mode: Inference mode (currently only supports "all")
        Returns:
            Final inference output result
        """
        # Step 1: Preprocessing
        preprocess_output = self.models["preprocess"](*args)
        # Unpack Preprocess output
        (
            static_scene_tokens_lane,
            static_scene_tokens_current_od,
            static_scene_tokens_navi_path,
            static_scene_tokens_tld,
            static_scene_tokens_control_point,
            dynamic_states_agents,
            dynamic_states_ego,
        ) = preprocess_output

        # Autoregressive inference hyperparameters
        ar_infer_ts_hist_num = self.ar_infer_ts_hist_num
        infer_step_num = self.infer_step_num

        # Step 2: Loop_flatten processing
        loop_flatten_output = self.models["loop_flatten"](
            static_scene_tokens_lane,
            static_scene_tokens_current_od,
            static_scene_tokens_navi_path,
            static_scene_tokens_tld,
            static_scene_tokens_control_point,
            dynamic_states_agents,
            dynamic_states_ego,
        )
        # Unpack Loop_flatten output
        (
            dynamic_states_agents,
            dynamic_states_ego,
            batch_mapping,
        ) = loop_flatten_output

        # Check sequence length and truncate
        if dynamic_states_ego.size(2) - ar_infer_ts_hist_num >= infer_step_num:
            dynamic_states_ego = dynamic_states_ego[:, :, : ar_infer_ts_hist_num + infer_step_num, :]
            dynamic_states_agents = dynamic_states_agents[:, :, : ar_infer_ts_hist_num + infer_step_num, :]

        # Step 3: Add_on processing
        add_on_output = self.models["add_on"](
            static_scene_tokens_lane,
            static_scene_tokens_current_od,
            static_scene_tokens_navi_path,
            static_scene_tokens_tld,
            static_scene_tokens_control_point,
            dynamic_states_agents,
            dynamic_states_ego,
            batch_mapping,
        )

        # Step 4: Reward/Postprocess processing
        final_output = self.models["reward"](*args, *add_on_output)

        return final_output


if __name__ == "__main__":
    # Set up command-line arguments
    parser = argparse.ArgumentParser(description="Autoregressive Inference Pipeline Script")

    # Optional arguments
    parser.add_argument(
        "--data_path",
        type=str,
        default="/share-global/wei.wang22/release/planner/dev_0612_ar_beta1/trace/preprocess/input/input.npy",
        help="Path to input data .npy file",
    )
    parser.add_argument(
        "--preprocess",
        type=str,
        default="/share-global/wei.wang22/release/planner/dev_0612_ar_beta1/trace/preprocess/astra_planner_trace_model.pt",
        help="Path to preprocess model",
    )
    parser.add_argument(
        "--loop_flatten",
        type=str,
        default="/share-global/wei.wang22/release/planner/dev_0612_ar_beta1/trace/loop_flatten/astra_planner_trace_model.pt",
        help="Path to loop_flatten trace model (.pt file)",
    )
    parser.add_argument(
        "--add_on",
        type=str,
        default="/share-global/wei.wang22/release/planner/dev_0612_ar_beta1/trace/add_on/astra_planner_trace_model.pt",
        help="Path to add_on trace model (.pt file)",
    )
    parser.add_argument(
        "--reward",
        type=str,
        default="/share-global/wei.wang22/release/planner/dev_0612_ar_beta1/trace/reward/astra_planner_trace_model.pt",
        help="Path to reward trace model (.pt file)",
    )
    parser.add_argument(
        "--device",
        type=str,
        default="cuda",
        choices=["cpu", "cuda"],
        help="Device to run inference on (default: %(default)s)",
    )
    parser.add_argument(
        "--output_path",
        type=str,
        default="export_output/output.pkl",
        help="Path to save output numpy file (default: %(default)s)",
    )

    args = parser.parse_args()

    # Validate model file extensions
    for path in [args.preprocess, args.loop_flatten, args.add_on, args.reward]:
        if not path.endswith(".pt"):
            raise ValueError(f"Model path must end with .pt: {path}")

    # Load input data from .npy file
    if not os.path.exists(args.data_path):
        raise FileNotFoundError(f"Input data file not found: {args.data_path}")

    input_tensor = []
    data_npy = np.load(args.data_path, allow_pickle=True).item()
    for key in trace_input_keys:
        data_tensor = torch.from_numpy(np.ascontiguousarray(data_npy[key])).to(args.device)
        input_tensor.append(data_tensor)

    # Create model paths dictionary
    model_paths = {
        "preprocess": args.preprocess,
        "loop_flatten": args.loop_flatten,
        "add_on": args.add_on,
        "reward": args.reward,
    }

    try:
        # Initialize inference pipeline
        pipeline = ARInferPipeline(
            model_paths=model_paths,
            device=args.device,
            ar_infer_ts_hist_num=15,
            infer_step_num=25,
        )

        # Execute inference
        output = pipeline.trace_forward(*input_tensor)

        # Convert output to numpy and save
        output = [t.detach().cpu().numpy() for t in output]
        os.makedirs(os.path.dirname(args.output_path), exist_ok=True)
        with open(args.output_path, "wb") as f:
            pkl.dump(output, f)

        print("Inference completed successfully!")  # noqa: T201
        print(f"Output saved to: {args.output_path}")  # noqa: T201

    except Exception as e:
        print(f"Error during inference: {str(e)}")  # noqa: T201
        raise
