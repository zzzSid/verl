# -*- coding: utf-8 -*-
# The input and ouput keys need to align with the deploy version.
import torch


TRACE_INPUT_KEYS_SHAPE_TYPE = [
    ("bboxes", torch.Size([1, 45, 191, 40]), torch.float32),
    ("bboxes_padding_mask", torch.Size([1, 45, 191]), torch.float32),
    ("egos", torch.Size([1, 45, 1, 16]), torch.float32),
    ("egos_padding_mask", torch.Size([1, 45, 1]), torch.float32),
    ("lane_points", torch.Size([1, 100, 50, 2]), torch.float32),
    ("lane_types", torch.Size([1, 100, 50]), torch.float32),
    ("lane_attr", torch.Size([1, 100, 50, 2]), torch.float32),
    ("sod_poly_boxes", torch.Size([1, 128, 23]), torch.float32),
    ("sod_poly_boxes_padding_mask", torch.Size([1, 128]), torch.float32),
    ("sod_poly_pts", torch.Size([1, 128, 128, 2]), torch.float32),
    ("sod_poly_pts_padding_mask", torch.Size([1, 128, 128]), torch.float32),
    ("atlas", torch.Size([1, 50, 30, 3]), torch.float32),
    ("sdmap_polylines", torch.Size([1, 50, 30, 2]), torch.float32),
    ("sdmap_polylines_type", torch.Size([1, 50, 30]), torch.float32),
    ("global_routing_mask", torch.Size([1, 50]), torch.float32),
    ("hist2curr_trans", torch.Size([1, 45, 4, 4]), torch.float32),
    ("delta_timestamp", torch.Size([1, 45]), torch.float32),
    ("navi_line_points", torch.Size([1, 6, 200, 2]), torch.float32),
    ("navi_line_types", torch.Size([1, 6, 200]), torch.float32),
    ("god_poly_pts", torch.Size([1, 32, 16, 2]), torch.float32),
    ("god_poly_pts_padding_mask", torch.Size([1, 32, 16]), torch.float32),
    ("god_attrs", torch.Size([1, 32, 8]), torch.float32),
    ("god_attr_padding_mask", torch.Size([1, 32]), torch.float32),
    ("road_detection_veh2ref", torch.Size([1, 4, 4]), torch.float32),
    ("road_post_veh2ref", torch.Size([1, 4, 4]), torch.float32),
    ("atlas_veh2ref", torch.Size([1, 4, 4]), torch.float32),
    ("navi_lane_to_target_lc_times", torch.Size([1, 6, 1]), torch.float32),
    ("navi_lane_tld", torch.Size([1, 6, 3]), torch.float32),
    ("navi_lane_stoppoints", torch.Size([1, 6, 200, 2]), torch.float32),
    ("navi_lane_speed_limit", torch.Size([1, 6, 200, 2]), torch.float32),
    ("navi_path_points", torch.Size([1, 1, 30, 2]), torch.float32),
    ("tld", torch.Size([1, 1, 12]), torch.float32),
    ("tld_padding_mask", torch.Size([1, 1]), torch.float32),
    ("navi_path_types", torch.Size([1, 1, 30]), torch.float32),
    ("navi_path_tld", torch.Size([1, 1, 3]), torch.float32),
    ("navi_path_stoppoints", torch.Size([1, 1, 30, 2]), torch.float32),
    ("navi_path_speed_limit", torch.Size([1, 1, 30, 2]), torch.float32),
    ("control_points", torch.Size([1, 10, 3, 8]), torch.float32),
    ("egos_gear", torch.Size([1, 45]), torch.float32),
    ("uturn_control_points", torch.Size([1, 2, 8]), torch.float32),
    ("prediction_traj", torch.Size([1, 191, 1, 25, 2]), torch.float32),
    ("od_prior_mask_input", torch.Size([1, 191]), torch.float32),
]

TRACE_OUTPUT_KEYS_SHAPE_KEY = [
    ("planning_traj", torch.Size([1, 72, 25, 6]), torch.float32),
    ("planning_score", torch.Size([1, 4, 6, 3]), torch.float32),
    ("prediction_traj", torch.Size([1, 191, 6, 35, 2]), torch.float32),
    ("prediction_score", torch.Size([1, 191, 6]), torch.float32),
    ("planning_scene_score_softmax", torch.Size([1, 4]), torch.float32),
    ("planning_scene_score_sigmoid", torch.Size([1, 4]), torch.float32),
    ("goal_point_planner_traj", torch.Size([1, 10, 25, 6]), torch.float32),
    ("uturn_point_planner_traj", torch.Size([1, 1, 25, 7]), torch.float32),
    ("od_prior_score", torch.Size([1, 64]), torch.float32),
    ("agent_index", torch.Size([1, 64]), torch.float32),
    ("trackable_pred", torch.Size([1, 64]), torch.float32),
    ("rewards_trajectories", torch.Size([1, 70, 25, 6]), torch.float32),
    ("trajectories_collisions", torch.Size([1, 70, 25, 2]), torch.float32),
    ("drive_path", torch.Size([1, 72, 100, 2]), torch.float32),
    ("drive_path_sampled", torch.Size([1, 19, 100, 2]), torch.float32),
]
INPUT_TEMPORAL_KEYS = [
    "bboxes",
    "bboxes_padding_mask",
    "egos",
    "egos_padding_mask",
    "hist2curr_trans",
    "delta_timestamp",
    "egos_gear",
]

TRACE_REWARD_OUTPUT_KEYS = [
    "rewards_trajectories",
    "trajectories_collisions",
    # "drive_path_sampled",
]

TRACE_INPUT_KEYS = [key_name for key_name, _, _ in TRACE_INPUT_KEYS_SHAPE_TYPE]
TRACE_INPUT_SHAPE = [key_shape for _, key_shape, _ in TRACE_INPUT_KEYS_SHAPE_TYPE]
TRACE_INPUT_TYPE = [key_type for _, _, key_type in TRACE_INPUT_KEYS_SHAPE_TYPE]

TRACE_OUTPUT_KEYS = [key_name for key_name, _, _ in TRACE_OUTPUT_KEYS_SHAPE_KEY]
TRACE_OUTPUT_SHAPE = [key_shape for _, key_shape, _ in TRACE_OUTPUT_KEYS_SHAPE_KEY]
TRACE_OUTPUT_TYPE = [key_type for _, _, key_type in TRACE_OUTPUT_KEYS_SHAPE_KEY]
