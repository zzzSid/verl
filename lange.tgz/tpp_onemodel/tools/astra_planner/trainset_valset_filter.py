# -*- coding: utf-8 -*-
# flake8:noqa
import argparse
import glob
import json
import os
import re
from logging.config import valid_ident
from math import inf

from tqdm import tqdm


def split_dataset(
    input_file_list,
    output_dir_path,
    file_name,
    infer_length,
    val_length,
    test_pick_length,
    old_version_infer_file,
    old_version_val_file,
):

    INFER_FILE_NUM = infer_length
    VAL_FILE_NUM = val_length
    TEST_FILE_NUM = test_pick_length

    # # input infos
    # input_file_list = [
    #     "/share-global/yuesong.xie/share/planning_data/20240821/prod_yx_20240820-fix-rel-pose-*",
    # ]  # input file list

    # # oupput infos
    # output_dir_path = "/share-global/leis.zhou/planning_dataset/manner_0821"  # output_dir
    # file_name = "0821_41w"  # ouput_file_name
    summay_raw_file = f"{output_dir_path}/summay_{file_name}.txt"  # summary file

    # # old version data
    # # old_version_infer_file = "/share-global/leis.zhou/planning_dataset/manner_0816/inferset_1782clips.txt"
    # # old_version_val_file = "/share-global/leis.zhou/planning_dataset/manner_0816/valset_100clips.txt"
    # old_version_infer_file = ""
    # old_version_val_file = ""

    if not os.path.exists(output_dir_path):
        os.makedirs(output_dir_path)

    # read all file path
    with open(summay_raw_file, "w") as outfile:
        all_files = []
        for input_file in input_file_list:
            all_files.extend(glob.glob(input_file))
        for filename in tqdm(all_files):
            if filename.endswith(".txt"):
                with open(filename, "r") as infile:
                    content = infile.read()
                    outfile.write(content)

    # read summary file path
    with open(summay_raw_file, "r") as file:
        file_paths = [line.strip() for line in file if line.strip()]
    print(f"Total file number: {len(file_paths)}")
    if len(file_paths) < INFER_FILE_NUM:
        print(f"Total file number is less than infer file number: {len(file_paths)}")
        print("Only summary file will be generate. Please check the input file list")
        exit(0)

    infer_paths = []
    val_paths = []
    train_paths = []

    # read privous infer set and val set
    inferset_clip_id_list = []
    if old_version_infer_file:
        with open(old_version_infer_file, "r") as f:
            lines = f.read().split("\n")
            for line in lines[:-1]:
                clip_id_infos = re.split(r"[_.]", line.split("/")[-1])[:3]
                clip_id = "_".join(clip_id_infos)
                inferset_clip_id_list.append(clip_id)

    valset_clip_id_list = []
    if old_version_val_file:
        with open(old_version_val_file, "r") as f:
            lines = f.read().split("\n")
            for line in lines[:-1]:
                clip_id_infos = re.split(r"[_.]", line.split("/")[-1])[:3]
                clip_id = "_".join(clip_id_infos)
                valset_clip_id_list.append(clip_id)

    # filter val set and infer set
    for file_path in file_paths:
        clip_id_infos = re.split(r"[_.]", file_path.split("/")[-1])[:3]
        clip_id = "_".join(clip_id_infos)
        if clip_id in valset_clip_id_list:
            val_paths.append(file_path + "\n")

        if clip_id in inferset_clip_id_list:
            infer_paths.append(file_path + "\n")

    if len(infer_paths) < INFER_FILE_NUM - 100:
        print(f"Drop too much old infer file, current infer file number: {len(infer_paths)}")
        infer_paths = []

    if len(val_paths) < VAL_FILE_NUM - 10:
        print(f"Drop too much old val file, current infer file number: {len(val_paths)}")
        val_paths = []

    sorted(file_paths)

    if not infer_paths:
        if not val_paths:
            print("infer path and val path are both unavailable")
            # infer path and val path are both unavailable
            val_interval = len(file_paths) // VAL_FILE_NUM  # 0.001
            val_paths = file_paths[::val_interval]
            remaining_train_paths = [path for i, path in enumerate(file_paths) if i % val_interval != 0]

            infer_interval = len(remaining_train_paths) // INFER_FILE_NUM  # 0.01
            infer_paths = remaining_train_paths[::infer_interval]
            remaining_train_paths = [path for i, path in enumerate(remaining_train_paths) if i % infer_interval != 0]
            train_paths = remaining_train_paths
        else:
            # only val path are both available
            print("infer path is unavailable")
            remaining_train_paths = [path for path in file_paths if path not in val_paths]
            infer_interval = len(remaining_train_paths) // INFER_FILE_NUM  # 0.01
            infer_paths = remaining_train_paths[::infer_interval]
            remaining_train_paths = [path for i, path in enumerate(remaining_train_paths) if i % infer_interval != 0]
            train_paths = remaining_train_paths
    else:
        if not val_paths:
            print("val path is unavailable")
            # only val path are both available
            val_interval = len(file_paths) // VAL_FILE_NUM  # 0.001
            val_paths = file_paths[::val_interval]
            remaining_train_paths = [path for i, path in enumerate(file_paths) if i % val_interval != 0]

            remaining_train_paths = [path for path in file_paths if path not in infer_paths]
            train_paths = remaining_train_paths
        else:
            print("infer path and val path are both available")
            # infer path and val path are both available
            remaining_train_paths = [path for path in file_paths if path not in val_paths and path not in infer_paths]
            train_paths = remaining_train_paths

    test_pick_interval = len(train_paths) // TEST_FILE_NUM
    test_pick_paths = train_paths[::test_pick_interval]
    remaining_train_paths = [path for i, path in enumerate(train_paths) if i % test_pick_interval != 0]
    train_paths = remaining_train_paths

    path_set = set()
    for path in train_paths:
        path_set.add(path)
    for path in val_paths:
        if path in path_set:
            print(f"error: {path}")
        else:
            path_set.add(path)
    for path in infer_paths:
        if path in path_set:
            print(f"error: {path}")
        else:
            path_set.add(path)
    for path in test_pick_paths:
        if path in path_set:
            print(f"error: {path}")
        else:
            path_set.add(path)

    # train/val split
    train_file = f"{output_dir_path}/{file_name}_train_{len(train_paths)}.txt"
    val_file = f"{output_dir_path}/{file_name}_val_{len(val_paths)}.txt"
    infer_file = f"{output_dir_path}/{file_name}_infer_{len(infer_paths)}.txt"
    test_pick_file = f"{output_dir_path}/{file_name}_test_pick_{len(test_pick_paths)}.txt"
    debug_file = f"{output_dir_path}/debug.txt"

    # train set
    with open(train_file, "w") as file:
        file.write("\n".join(train_paths))
    print(f"trainset with {len(train_paths)} clips has been written to {train_file}")

    # val set
    with open(val_file, "w") as file:
        file.write("\n".join(val_paths))
    print(f"Valset with {len(val_paths)} clips has been written to {val_file}")

    # infer set
    with open(infer_file, "w") as file:
        file.write("\n".join(infer_paths))
    print(f"Inferset with {len(infer_paths)} clips has been written to {infer_file}")

    # test_pick set
    with open(test_pick_file, "w") as file:
        file.write("\n".join(test_pick_paths))
    print(f"Testset with {len(test_pick_paths)} clips has been written to {test_pick_file}")

    # infer set
    with open(debug_file, "w") as file:
        file.write("\n".join(infer_paths[:2]))
    print(f"Debugset with 2 clips has been written to {debug_file}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process some parameters.")
    parser.add_argument(
        "--input_file_list",
        default=["/share-global/yuesong.xie/share/planning_data/20240821/prod_yx_20240820-fix-rel-pose-*"],
        nargs="+",
        type=str,
        help="The input data path file list",
    )
    parser.add_argument("--output_dir_path", default="./gen_dataset", type=str, help="The save path")
    parser.add_argument("--file_name", default="0821_41w", type=str, help="The name of generated dataset")
    parser.add_argument("--infer_length", type=int, default=1500, help="The length of infer set")
    parser.add_argument("--test_length", type=int, default=50000, help="The length of test pick set")
    parser.add_argument("--val_length", type=int, default=100, help="The length of val set")
    parser.add_argument("--old_version_infer_file", type=str, default="", help="The old version infer file")
    parser.add_argument("--old_version_val_file", type=str, default="", help="The old version val file")

    args = parser.parse_args()
    input_file_list = ["".join(input_file) for input_file in args.input_file_list]

    split_dataset(
        input_file_list,
        args.output_dir_path,
        args.file_name,
        args.infer_length,
        args.val_length,
        args.test_length,
        args.old_version_infer_file,
        args.old_version_val_file,
    )
