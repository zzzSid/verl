# -*- coding: utf-8 -*-
import argparse
import glob
import os
import os.path as osp
import time
from pathlib import Path
from typing import List
from typing import Tuple

import input_output_viz as viz  # noqa: I900
import matplotlib.pyplot as plt
import numpy as np
import torch
import torchpilot
from prettytable import PrettyTable
from torchpilot.utils.cfg_parser import PyConfig
from torchpilot.utils.plus_manager import load_plus
from torchpilot.utils.registries import DATALOADER

from tpp_onemodel.tools.astra_planner.deploy.trace_keys import INPUT_TEMPORAL_KEYS
from tpp_onemodel.tools.astra_planner.deploy.trace_keys import TRACE_INPUT_KEYS


logger = torchpilot.logger

DTYPE = np.float32
DEVICE = torch.device("cuda")
np.set_printoptions(precision=2, suppress=True)


def parse_argus_dump_data(dump_dir: str, ts_ms: int) -> Tuple[List[torch.Tensor], List[torch.Tensor]]:
    """Parse meta info, numpy binary data from given the specific argus dump directory and timestamp with ms.

    Directory structure:
    dump_dir
    ├── input
    │   ├── 1715957111146
    │   │   ├── inputs_0
    │   │   ├── inputs_0.txt
    |   |   | ...
    └── output
    ├── 1715957111146
    │   ├── perception_obs_ids
    │   ├── perception_obs_ids.txt
    │   ├── top_joint_agent_trajs
    │   ├── top_joint_agent_trajs.txt
    │   ├── top_joint_ego_trajs
    │   ├── top_joint_ego_trajs.txt
    │   ├── top_scene_probs
    │   └── top_scene_probs.txt
    Txt format: 1;float32;1,15,194,40
    """
    input_path = osp.join(dump_dir, "input", str(ts_ms))
    txts_path = glob.glob(f"{input_path}/*.txt")

    input_list = []
    for i in range(len(txts_path)):
        with open(f"{input_path}/inputs_{i}.txt") as fh:
            lines = fh.readlines()
        parts = lines[0].split(";")
        _, dtype, shape_str = parts
        shape = tuple(map(int, shape_str.split(",")))
        data = np.fromfile(f"{input_path}/inputs_{i}", dtype=dtype)
        input_list.append(torch.from_numpy(data.reshape(shape)))

    output_path = osp.join(dump_dir, "output", str(ts_ms))
    txts_path = glob.glob(f"{output_path}/*.txt")
    output_list = []
    for output_txt_path in txts_path:
        with open(output_txt_path) as fh:
            lines = fh.readlines()
        parts = lines[0].split(";")
        _, dtype, shape_str = parts
        shape = tuple(map(int, shape_str.split(",")))
        data = np.fromfile(output_txt_path.replace(".txt", ""), dtype=dtype)
        output_list.append(torch.from_numpy(data.reshape(shape)))
    return input_list, output_list


def select_sample_by_ts(planner_cfg, ts_ms: int):
    """Select the clip frame sample by given micro-seconds timetamp."""
    data_cfg = planner_cfg.infer_dataloader
    data_cfg.dataset_cfg.batch_size = 1
    data_cfg.dataset_cfg.num_workers = 0
    data_cfg.num_workers = 1
    data_cfg.dataset_cfg.shuffle = False
    data_cfg.prefetch_factor = 1
    # data_cfg.dataset_cfg.debug = True
    data_loader = DATALOADER.build(data_cfg)
    for sample in data_loader:
        cur_ms = int(sample["timestamp"][0, -1] * 1000)
        if abs(cur_ms - ts_ms) < 70:
            logger.info("time_diff: %f ms", cur_ms - ts_ms)
            return {key: sample[key] for key in TRACE_INPUT_KEYS}
        else:
            logger.info("curr_time: %f ms", cur_ms)
            logger.info("ts_ms    : %f ms", ts_ms)
            logger.info("time_diff: %f ms", cur_ms - ts_ms)
    logger.warning("Can't find the sample near given timestamp")
    return None


def plot_single_source(data, ax, plot_keys, plot_settings, source_name):
    """Plot single source."""
    for key in plot_keys:
        label = f"{key}_{source_name}"
        settings = {}
        if key in plot_settings:
            settings = plot_settings[key]

        if key == "egos":
            # current box
            want_feat_idx = [0, 1, 3, 4, 6]  # x,y,l,w,heading
            boxes_np = data["egos"].numpy()[0, -1][:, want_feat_idx]  # [1, 5]
            masks_np = data["egos_padding_mask"].numpy()[0, -1]  # [1, ]
            viz.plot_rectangles(boxes_np, masks_np, ax, label=label, mask_valid_val=0, **(settings["curr_box"]))
            # history
            viz.plot_agent_hist(
                data["egos"].numpy()[0, :, :, :3],  # x, y, z
                data["egos_padding_mask"].numpy()[0],
                data["hist2curr_trans"].numpy()[0],
                ax,
                mask_valid_val=0,
                label=f"{key}_hist_{source_name}",
                **(settings["hist"]),
            )

        elif key == "bboxes":
            # current box
            want_feat_idx = [0, 1, 3, 4, 6]  # x,y,l,w,heading
            boxes_np = data["bboxes"].numpy()[0, -1][:, want_feat_idx]  # [A, 5]
            masks_np = data["bboxes_padding_mask"].numpy()[0, -1]  # [A, ]
            viz.plot_rectangles(boxes_np, masks_np, ax, label=label, mask_valid_val=0, **(settings["curr_box"]))
            # history
            viz.plot_agent_hist(
                data["bboxes"].numpy()[0, :, :, :3],  # x, y, z
                data["bboxes_padding_mask"].numpy()[0],
                data["hist2curr_trans"].numpy()[0],
                ax,
                label=f"{key}_hist_{source_name}",
                mask_valid_val=0,
                **(settings["hist"]),
            )

        elif key == "sod_poly_boxes":
            want_feat_idx = [0, 1, 3, 4, 6]  # x,y,l,w,heading
            boxes_np = data["sod_poly_boxes"].numpy()[0][:, want_feat_idx]
            masks_np = data["sod_poly_boxes_padding_mask"].numpy()[0]
            viz.plot_rectangles(boxes_np, masks_np, ax, label=label, mask_valid_val=0, **settings)

        elif key == "sod_poly_pts":
            viz.plot_lines(
                data["sod_poly_pts"].numpy()[0],
                data["sod_poly_pts_padding_mask"].numpy()[0],
                ax,
                label=label,
                type_invalid_val=1,
                **settings,
            )

        elif key == "atlas":
            atlas = data["atlas"].numpy()[0]
            atlas_trans = data["atlas_veh2ref"].numpy()[0]
            atlas_homogeneous = np.ones((atlas.shape[0], atlas.shape[1], 4))
            atlas_homogeneous[..., :2] = atlas[..., :2]

            # Apply the homogeneous transformation
            transformed_atlas = np.zeros_like(atlas_homogeneous)
            for i in range(atlas.shape[0]):
                transformed_atlas[i] = np.dot(atlas_trans, atlas_homogeneous[i].T).T

            atlas_data = transformed_atlas[:, :, :2]
            atlas_type = atlas[:, :, -1]
            viz.plot_lines(atlas_data, atlas_type, ax, label=label, type_invalid_val=-1, **settings)

        elif key == "lane_points":
            viz.plot_lines(
                data["lane_points"].numpy()[0],
                data["lane_types"].numpy()[0],
                ax,
                label=label,
                type_invalid_val=-1,
                **settings,
            )

        elif key == "god_poly_pts":
            viz.plot_polygons(
                data["god_poly_pts"].numpy()[0],  # [32, 16, 2]
                data["god_poly_pts_padding_mask"].numpy()[0],
                ax,
                label=label,
                **settings,
            )

        elif key == "navi_line_points":
            viz.plot_lines(
                data["navi_line_points"].numpy()[0],
                data["navi_line_types"].numpy()[0],
                ax,
                label=label,
                type_invalid_val=-1,
                **settings,
            )

        elif key == "sdmap_polylines":
            if source_name == "py":
                continue
            viz.plot_lines(
                data["sdmap_polylines"].numpy()[0],
                data["sdmap_polylines_type"].numpy()[0],
                ax,
                label=label,
                type_invalid_val=-1,
                **settings,
            )


def find_best_match_timestamp(cfg_planner, cpp_dump_dir):
    """Find best match timestamp."""
    logger.info("matching timestamps ... ")
    # load dataset, get all model timestamp
    model_ts_list = []
    cfg = PyConfig.fromfile(cfg_planner)
    data_cfg = cfg.infer_dataloader
    data_cfg.dataset_cfg.batch_size = 1
    data_cfg.dataset_cfg.num_workers = 0
    data_cfg.num_workers = 1
    data_cfg.dataset_cfg.shuffle = False
    data_cfg.prefetch_factor = 1
    data_loader = DATALOADER.build(data_cfg)
    for sample in data_loader:
        cur_ms = int(sample["timestamp"][0, -1] * 1000)
        model_ts_list.append(cur_ms)

    # read dump dir, get all deploy timestamp
    input_path = osp.join(cpp_dump_dir, "input")
    deploy_ts_list = [int(entry.name) for entry in Path(input_path).iterdir() if entry.is_dir()]

    min_diff = 1e9
    res_model_ts = 0
    res_deploy_ts = 0

    for model_ts in model_ts_list:
        for deploy_ts in deploy_ts_list:
            diff = abs(model_ts - deploy_ts)
            if diff < min_diff:
                min_diff = diff
                res_model_ts = model_ts
                res_deploy_ts = deploy_ts

    logger.info("matched ts: model %d, deploy %d, diff: %d", res_model_ts, res_deploy_ts, min_diff)
    return res_deploy_ts


if __name__ == "__main__":
    load_plus()
    torch.distributed.init_process_group(
        backend="nccl",
        init_method="tcp://localhost:9999",
        world_size=1,
        rank=0,
    )

    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--cfg_planner", type=str, required=False, help="planner_cfg")
    parser.add_argument("--cpp_dump_dir", type=str, required=False, help="cpp_dump_dir")
    parser.add_argument("--ts", type=int, required=False, default=0, help="Compare timestamp.")
    parser.add_argument("--result_dir", type=str, required=False, default="./compare_inputs_viz/")
    parser.add_argument("--same_plot", action="store_true", default=False)
    parser.add_argument("--compare_value", action="store_true", default=False)
    args = parser.parse_args()

    # Configs ---
    compare_on_same_subplot = args.same_plot

    py_source_exist = True if args.cfg_planner else False
    cpp_source_exist = True if args.cpp_dump_dir else False
    both_source_exist = py_source_exist and cpp_source_exist
    if not os.path.exists(args.result_dir):
        os.mkdir(args.result_dir)

    ts_ms = args.ts
    if ts_ms == 0:
        if both_source_exist:
            ts_ms = find_best_match_timestamp(args.cfg_planner, args.cpp_dump_dir)
        else:
            logger("No ts and no matched ts!!")

    torch.set_printoptions(linewidth=500, edgeitems=8, profile="default", sci_mode=False)
    np.set_printoptions(linewidth=500, edgeitems=8, suppress=True)

    """ The input and ouput keys need to align with the deploy version sequentially!!!.
    Currently tested on 0823 version: https://nio.feishu.cn/wiki/XXGVwOMa5iO8oAk4sThcOAeJnGh
    """
    """
    Plotting Target keys:
    """
    plot_keys = [
        "bboxes",
        "bboxes_padding_mask",
        "egos",
        "egos_padding_mask",
        "lane_points",
        "lane_types",
        "sod_poly_boxes",
        "sod_poly_boxes_padding_mask",
        "sod_poly_pts",
        "sod_poly_pts_padding_mask",
        "atlas",
        # "sdmap_polylines",
        # "sdmap_polylines_type",
        "global_routing_mask",
        "hist2curr_trans",
        "delta_timestamp",
        "navi_line_points",
        "navi_line_types",
        "god_poly_pts",
        "god_poly_pts_padding_mask",
        "god_attrs",
        "god_attr_padding_mask",
    ]

    """
    Plotting COLOR-CODE:
    different color to distinguish among input types,
    different shade of a color to distinguish bwtween cpp and python, cpp is lighter, python is darker
    """
    py_plot_settings = {
        "bboxes": {
            "curr_box": {
                "color": "teal",
                "fill": False,
                "lw": 1.0,
                "zorder": 100,
            },
            "hist": {
                "edgecolors": "teal",
                "facecolors": "none",
                "marker": "o",
                "zorder": 100,
            },
        },
        "egos": {
            "curr_box": {
                "color": "darkviolet",
                "fill": False,
                "lw": 1.0,
                "zorder": 100,
            },
            "hist": {
                "edgecolors": "darkviolet",
                "facecolors": "none",
                "marker": "o",
                "zorder": 100,
            },
        },
        "sod_poly_boxes": {"fill": False, "lw": 0.3, "color": "darkorange", "zorder": 100},
        "sod_poly_pts": {
            "marker": "o",
            "linestyle": "-",
            "color": "darkolivegreen",
            "fillstyle": "none",
        },
        "atlas": {
            "marker": "o",
            "linestyle": "-",
            "color": "navy",
            "fillstyle": "none",
        },
        "lane_points": {
            "marker": "o",
            "linestyle": "-",
            "color": "dimgrey",
            "fillstyle": "none",
        },
        "god_poly_pts": {"fill": False, "lw": 0.3, "color": "red", "zorder": 100},
        "navi_line_points": {
            "marker": "o",
            "linestyle": "-",
            "color": "red",
            "fillstyle": "none",
        },
        "sdmap_polylines": {
            "marker": "o",
            "linestyle": "-",
            "color": "red",
            "fillstyle": "none",
        },
    }

    cpp_plot_settings = {
        "bboxes": {
            "curr_box": {
                "color": "cyan",
                "fill": False,
                "lw": 1.0,
                "zorder": 100,
            },
            "hist": {
                "color": "cyan",
                "marker": ".",
                "zorder": 100,
            },
        },
        "egos": {
            "curr_box": {
                "color": "violet",
                "fill": False,
                "lw": 1.0,
                "zorder": 100,
            },
            "hist": {
                "color": "violet",
                "marker": ".",
                "zorder": 100,
            },
        },
        "sod_poly_boxes": {"fill": False, "lw": 0.3, "color": "gold", "zorder": 100},
        "sod_poly_pts": {"marker": ".", "linestyle": "-", "color": "greenyellow"},
        "atlas": {
            "marker": ".",
            "linestyle": "--",
            "color": "royalblue",
        },
        "lane_points": {
            "marker": ".",
            "linestyle": "-",
            "color": "silver",
        },
        "god_poly_pts": {"fill": False, "lw": 0.3, "color": "pink", "zorder": 100},
        "navi_line_points": {
            "marker": ".",
            "linestyle": "-",
            "color": "pink",
        },
        "sdmap_polylines": {
            "marker": ".",
            "linestyle": "-",
            "color": "pink",
        },
    }

    # Fig setting ---
    if both_source_exist:
        # plot both source
        if compare_on_same_subplot:
            fig, ax_py = plt.subplots(figsize=(30, 15), dpi=400)
            ax_cpp = ax_py
        else:
            fig, (ax_py, ax_cpp) = plt.subplots(2, 1, figsize=(30, 30), sharex=True, sharey=True, dpi=400)
            ax_py.set_title("Python")
            ax_cpp.set_title("Cpp")
            ax_cpp.scatter([0], [0], color="red")
            ax_cpp.set_aspect("equal")
            ax_cpp.grid(True)

        fig.suptitle("Compare Inputs")

        ax_py.scatter([0], [0], color="red")
        ax_py.set_aspect("equal")
        ax_py.set_xlabel("X")
        ax_py.set_ylabel("Y")
        ax_py.grid(True)

    else:
        # plot single source
        fig, ax = plt.subplots(figsize=(30, 15), dpi=400)
        if cpp_source_exist:
            ax.set_title("Cpp")
        if py_source_exist:
            ax.set_title("Python")

        ax.scatter([0], [0], color="red")
        ax.set_aspect("equal")
        ax.set_xlabel("X")
        ax.set_ylabel("Y")
        ax.grid(True)

        ax_cpp = ax
        ax_py = ax

    # Load and plot data ---
    file_name = ""

    cpp_data_in = dict()
    if cpp_source_exist:
        # Load dumped data and plot
        plot_settings = cpp_plot_settings if compare_on_same_subplot else py_plot_settings
        argi, argo = parse_argus_dump_data(args.cpp_dump_dir, ts_ms)
        for key, value in zip(TRACE_INPUT_KEYS, argi):
            if key in INPUT_TEMPORAL_KEYS:
                value = value[:, 2::3, ...]
            cpp_data_in[key] = value

        plot_single_source(cpp_data_in, ax_cpp, plot_keys, plot_settings, source_name="cpp")
        ax_cpp.legend(loc="upper right")
        file_name += "cpp"

    py_data_in = dict()
    if py_source_exist:
        # Load pkl data and plot
        cfg = PyConfig.fromfile(args.cfg_planner)
        py_data_in = select_sample_by_ts(cfg, ts_ms)

        plot_single_source(py_data_in, ax_py, plot_keys, py_plot_settings, source_name="py")
        ax_py.legend(loc="upper left")
        file_name += "py"

    # Save viz results ---
    timestr = time.strftime("%Y%m%d%H%M%S")
    save_plot_path = osp.join(args.result_dir, f"input_plot_{file_name}_{timestr}.jpg")
    plt.savefig(save_plot_path)
    logger.info(
        "result saved in:\n %s\n",
        save_plot_path,
    )
    logger.info("Viz Success!!!")

    """COMPARE VALUES"""
    if both_source_exist and args.compare_value:
        keys_to_compare_value = [
            "egos",
            "egos_padding_mask",
            "hist2curr_trans",
            "delta_timestamp",
            "lane_points",
            "lane_types",
            "navi_line_points",
            "navi_line_types",
            "bboxes",
            "bboxes_padding_mask",
            "sod_poly_boxes",
            "sod_poly_boxes_padding_mask",
        ]

        match_dict = {}
        for key in keys_to_compare_value:
            if key not in TRACE_INPUT_KEYS:
                continue
            if key not in cpp_data_in:
                logger.info("cpp data has no key %s", key)
                continue
            if key not in py_data_in:
                logger.info("py data has no key %s", key)
                continue

            if not torch.allclose(cpp_data_in[key], py_data_in[key], atol=1e-04):
                if key == "bboxes":
                    bboxes_py = py_data_in[key].numpy()[0].transpose(1, 0, 2)
                    bboxes_mask_py = py_data_in["bboxes_padding_mask"].numpy()[0].transpose(1, 0)
                    bboxes_cpp = cpp_data_in[key].numpy()[0].transpose(1, 0, 2)
                    bboxes_mask_cpp = cpp_data_in["bboxes_padding_mask"].numpy()[0].transpose(1, 0)

                    want_feat_idx = [0, 1, 3, 4, 6]  # x,y,l,w,heading
                    match_score, (py_idx, cpp_idx) = viz.match_items(
                        bboxes_py[..., want_feat_idx],
                        bboxes_mask_py,
                        bboxes_cpp[..., want_feat_idx],
                        bboxes_mask_cpp,
                        1,
                        distance_type="iou",
                    )

                    matched_mask = match_score < 1
                    cpp_idx = cpp_idx[matched_mask]
                    py_idx = py_idx[matched_mask]
                    mse = viz.calc_mse(
                        bboxes_py[py_idx, :, :2],
                        bboxes_mask_py[py_idx],
                        bboxes_cpp[cpp_idx, :, :2],
                        bboxes_mask_cpp[cpp_idx],
                        1,
                    )

                    logger.info(
                        "%s with IOU, valid match: %d of %d, MSE: %f", key, matched_mask.sum(), len(matched_mask), mse
                    )
                    match_dict[key] = mse

                elif key == "sod_poly_boxes":
                    sod_poly_boxes_py = py_data_in[key].numpy()[0]
                    sod_poly_boxes_mask_py = py_data_in["sod_poly_boxes_padding_mask"].numpy()[0]
                    sod_poly_boxes_cpp = cpp_data_in[key].numpy()[0]
                    sod_poly_boxes_mask_cpp = cpp_data_in["sod_poly_boxes_padding_mask"].numpy()[0]

                    want_feat_idx = [0, 1, 3, 4, 6]  # x,y,l,w,heading
                    match_score, (py_idx, cpp_idx) = viz.match_items(
                        sod_poly_boxes_py[..., want_feat_idx],
                        sod_poly_boxes_mask_py,
                        sod_poly_boxes_cpp[..., want_feat_idx],
                        sod_poly_boxes_mask_cpp,
                        1,
                        distance_type="iou",
                    )

                    matched_mask = match_score < 1
                    cpp_idx = cpp_idx[matched_mask]
                    py_idx = py_idx[matched_mask]
                    mse = viz.calc_mse(
                        sod_poly_boxes_py[py_idx, :2],
                        sod_poly_boxes_mask_py[py_idx],
                        sod_poly_boxes_cpp[cpp_idx, :2],
                        sod_poly_boxes_mask_cpp[cpp_idx],
                        1,
                    )
                    logger.info(
                        "%s with IOU, valid match: %d of %d, MSE: %f", key, matched_mask.sum(), len(matched_mask), mse
                    )
                    match_dict[key] = mse

                elif key == "navi_line_points":
                    m, n, d = py_data_in[key].numpy()[0].shape
                    match_score, (py_idx, cpp_idx) = viz.match_items(
                        py_data_in[key].numpy()[0].reshape((m * n, d)),
                        py_data_in["navi_line_types"].numpy()[0].reshape((m * n,)),
                        cpp_data_in[key].numpy()[0].reshape((m * n, d)),
                        cpp_data_in["navi_line_types"].numpy()[0].reshape((m * n,)),
                        -1,
                    )

                    matched_thresh = 0.2
                    matched_num = (match_score < matched_thresh).sum()
                    total_py_num = match_score.shape[0]
                    matched_ratio = matched_num / total_py_num

                    logger.info(
                        "%s Point by point error, thresh: %f match ratio: %f",
                        key,
                        matched_thresh,
                        matched_ratio,
                    )
                    match_dict[key] = matched_ratio

                elif key == "lane_points":
                    match_score, (py_idx, cpp_idx) = viz.match_items(
                        py_data_in[key].numpy()[0],
                        py_data_in["lane_types"].numpy()[0],
                        cpp_data_in[key].numpy()[0],
                        cpp_data_in["lane_types"].numpy()[0],
                        -1,
                        distance_type="dtw",
                    )

                    matched_thresh = 0.3
                    matched_ratio = (match_score < matched_thresh).sum() / match_score.shape[0]

                    logger.info(
                        "%s with DTW, thresh: %f match ratio: %f",
                        key,
                        matched_thresh,
                        matched_ratio,
                    )
                    match_dict[key] = matched_ratio

                else:
                    squared_difference = (cpp_data_in[key] - py_data_in[key]) ** 2
                    mean_squared_error = torch.mean(squared_difference).item()
                    match_dict[key] = mean_squared_error
                    logger.info("%s MSE: %f", key, match_dict[key])
            else:
                match_dict[key] = 0.0
                logger.info("%s MSE: %f", key, match_dict[key])

        # gen table
        cmp_result = PrettyTable()
        cmp_result.field_names = ["input name", "tensor shape", "mean squared error", "arg ppl slice", "dataset slice"]
        for key in keys_to_compare_value:
            if key == "delta_timestamp":
                cmp_result.add_row(
                    [
                        key,
                        py_data_in[key].shape,
                        match_dict[key],
                        cpp_data_in[key][0, ...],
                        py_data_in[key][0, ...],
                    ]
                )

            if key == "egos":
                cmp_result.add_row(
                    [
                        key,
                        py_data_in[key].shape,
                        match_dict[key],
                        cpp_data_in[key][0, -2:, ...],
                        py_data_in[key][0, -2:, ...],
                    ]
                )  # check last two history

            if key == "hist2curr_trans":
                cmp_result.add_row(
                    [
                        key,
                        py_data_in[key].shape,
                        match_dict[key],
                        cpp_data_in[key][0, -2:, ...],
                        py_data_in[key][0, -2:, ...],
                    ]
                )
            if key == "bboxes":
                cmp_result.add_row(
                    [
                        key,
                        py_data_in[key].shape,
                        match_dict[key],
                        cpp_data_in[key][0, -2:, ...],
                        py_data_in[key][0, -2:, ...],
                    ]
                )

            if key == "lane_points":
                cmp_result.add_row(
                    [
                        key,
                        py_data_in[key].shape,
                        match_dict[key],
                        cpp_data_in[key][0, -2:, ...],
                        py_data_in[key][0, -2:, ...],
                    ]
                )

            if key == "sod_poly_boxes":
                cmp_result.add_row(
                    [
                        key,
                        py_data_in[key].shape,
                        match_dict[key],
                        cpp_data_in[key][0, -2:, ...],
                        py_data_in[key][0, -2:, ...],
                    ]
                )

        table_result_path = osp.join(args.result_dir, f"compare_input_table_{timestr}.txt")
        with open(
            table_result_path,
            "w",
            encoding="utf-8",
        ) as fout:
            fout.write(cmp_result.get_string())

        logger.info(
            "result saved in:\n %s\n",
            table_result_path,
        )
        logger.info("Table Success!!!")
