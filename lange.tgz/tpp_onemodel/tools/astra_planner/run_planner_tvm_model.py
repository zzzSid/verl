# -*- coding: utf-8 -*-
"""Load and run aeb tvm model."""
import os

import numpy as np
import torchpilot
from hpc_nn_ops.torch_manager import PluginManager

from tpp_onemodel.tools.astra_planner.deploy.trace_keys import TRACE_INPUT_KEYS


logger = torchpilot.logger


def process_inputs_outputs(input_file_path, output_file_path):
    """Process inputs outputs."""
    logger.warning("%s, %s", input_file_path, output_file_path)
    inputs = np.load(input_file_path, allow_pickle=True).item()

    input_dict = {f"inputs_{i}": np.ascontiguousarray(inputs[key]) for i, key in enumerate(TRACE_INPUT_KEYS)}
    output_dict = np.load(output_file_path, allow_pickle=True).item()
    return input_dict, output_dict


def load_tvm_model(model_path):
    """Load tvm model."""
    PluginManager()
    import compiler_runtime  # noqa: I900
    model = compiler_runtime.interface.create_executor(model_saved_dir=model_path, target="cuda", enable_profile=False)
    return model


def align_tvm_output(tvm_path):
    """Align output."""
    logger.warning("tvm_path: %s", tvm_path)
    model = load_tvm_model(tvm_path)
    inputs, outputs_gt = process_inputs_outputs(input_npy_path, output_npy_path)
    outputs = model.run(inputs)
    for output_name in outputs_gt.keys():
        # assert output_name in outputs, f"{output_name} not in outputs"
        pred = outputs[output_name]
        gt = outputs_gt[output_name]
        # if not np.allclose(pred, gt, atol=5e-2):
        logger.warning("Tensor: %s, MaxError: %s", output_name, np.max(np.abs(pred - gt)))


if __name__ == "__main__":
    DOWNLOAD_CMD = "/share-global/stephen.wang/download_tools/release-system-amd64.cli download --type ai_compiler --name perception-planner --version"
    # Please modify the input/ouput npy path, lib name, trace_input_keys for your version.
    io_dir = "/share-global/runlin.he/ep_580717_uturn_task_onlyl2_u3p_x10"
    lib_name = "astra_planner_astra_uturn_0317-049351.fp16.ntsctl.libs"

    input_npy_path = f"{io_dir}/input/input.npy"
    output_npy_path = f"{io_dir}/output/output.npy"

    # download tvm model:
    save_root = "output/tvm_output"
    os.system(f"rm -r {save_root}")  # noqa: S605
    download_cmd = f"{DOWNLOAD_CMD} {lib_name} -l {save_root} -t no"
    os.system(download_cmd)  # noqa: S605

    model_dir = f"{save_root}/extract"
    os.mkdir(model_dir)
    os.system(f"tar -xvzf {save_root}/*.tar.gz -C {model_dir}")  # noqa: S605
    model_path = os.path.join(model_dir, os.listdir(model_dir)[0])

    align_tvm_output(model_path)
