# -*- coding: utf-8 -*-
from importlib import import_module

import torch
from torchpilot.utils.registries import MODULE
from transformers import PretrainedConfig
from transformers import PreTrainedModel

from tpp_onemodel.model.module.auto_regressive_common_module import ARKVMaskCacheManager
from tpp_onemodel.model.module.auto_regressive_token_decoder import (
    ARTokenDecoderAccOmegaMultiStep,
)
from tpp_onemodel.model_configs.auto_regressive_planner import VOCAB_PATH


import_module("tpp_onemodel.model.module.auto_regressive_action_model")
import_module("tpp_onemodel.model.module.auto_regressive_common_module")
import_module("tpp_onemodel.model.module.dynamic_state_tokenizer")


class MyCustomConfig(PretrainedConfig):
    model_type = "ar_planner"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        train_mode = False
        mask_ego_future_history = True

        self.dynamic_tokenizer_cfg = dict(
            type="DynamicStateTokenizer",
            ego_state_tokenizer_cfg=dict(
                type="EgoStateTokenizer",
                norm_range=[-120, 280, -120, 280, -3, 40],  # x min, x max, y min, y max, vel min, vel max
                token_embedding_cfg=dict(type="EmbeddingMLP", input_dim=5, embedding_dim=256, train_mode=train_mode),
                train_mode=train_mode,
            ),
            agent_state_tokenizer_cfg=dict(
                type="AgentStateTokenizer",
                norm_range=[
                    -100,
                    200,
                    -50,
                    50,
                    0,
                    10,
                    0,
                    5,
                    0,
                    5,
                ],  # x min, x max, y min, y max, length min, length max, width min, width max, height min, height max
                embedding_cfg=dict(type="EmbeddingMLP", input_dim=5, embedding_dim=256, train_mode=train_mode),
                train_mode=train_mode,
            ),
            train_mode=train_mode,
        )

        self.action_model_cfg = dict(
            type="AutoRegressiveActionModel",
            action_model_cfg=dict(
                type="ARActionModelV1",
                history_ts_num=14,
                max_ts_num=100,
                t_attn_layer_num=2,
                attn_layer_num=2,
                ego_cross_attn_key_list=["lane", "navi_path", "tld", "control_point"],
                agent_cross_attn_key_list=["lane", "current_od"],
                feat_dim=256,
                mask_ego_future_history=mask_ego_future_history,
                t_attn_block_cfg=dict(
                    type="ARActionV1TAttnBlock",
                    feat_dim=256,
                    attn_ego_agent_cfg=dict(
                        type="ActionModelV1TAttn", feat_dim=256, head_num=8, dropout=0.0, train_mode=train_mode
                    ),
                    train_mode=train_mode,
                ),
                attn_block_cfg=(
                    dict(
                        type="ActionModelV1AttnBlock",
                        feat_dim=256,
                        self_attn_cfg=dict(
                            type="ActionModelV1EgoAgentSelfAttn",
                            feat_dim=256,
                            head_num=8,
                            dropout=0.0,
                            train_mode=train_mode,
                        ),
                        ego_cross_attn_cfg=dict(
                            type="ActionModelV1EgoAgentCrossAttn",
                            feat_dim=256,
                            head_num=8,
                            dropout=0.0,
                            train_mode=train_mode,
                        ),
                        agent_cross_attn_cfg=dict(
                            type="ActionModelV1EgoAgentCrossAttn",
                            feat_dim=256,
                            head_num=8,
                            dropout=0.0,
                            train_mode=train_mode,
                        ),
                        train_mode=train_mode,
                    )
                ),
                ego_action_decode_ffn_cfg=dict(
                    type="ARDecodeMLP",
                    input_dim=256,
                    hidden_dim=256,
                    output_dim=512,
                    train_mode=train_mode,
                ),
                agent_action_decode_ffn_cfg=dict(
                    type="ARDecodeMLP",
                    input_dim=256,
                    hidden_dim=128,
                    output_dim=3,
                    train_mode=train_mode,
                ),
                train_mode=train_mode,
            ),
            train_mode=train_mode,
        )
        self.vocab_path = VOCAB_PATH
        self.delta_t = 0.2


class AutoRegressivePlannerHF(PreTrainedModel):
    """Auto regressive action model."""

    config_class = MyCustomConfig

    def __init__(self, config):
        """Init AutoRegressiveActionModel."""
        super().__init__(config)
        self._dynamic_state_tokenizer = MODULE.build(config.dynamic_tokenizer_cfg)
        self._action_model = MODULE.build(config.action_model_cfg)
        self.token_decoder = ARTokenDecoderAccOmegaMultiStep(config.vocab_path, delta_t=config.delta_t, step=2)
        self.kv_mask_cache = ARKVMaskCacheManager()

    def forward(self, current_dynamic_state, kv_mask_cache):
        """Forward."""
        dynamic_state_tokens = self._dynamic_state_tokenizer(current_dynamic_state)

        action_logits = self._action_model.infer_loop(dynamic_state_tokens, kv_mask_cache)
        return action_logits

    def loop_forward(self, current_dynamic_state, kv_mask_cache):
        """Loop forward."""
        return self.forward(current_dynamic_state, kv_mask_cache)

    def loop_post(self, current_dynamic_state, action_logits, dynamic_states):
        """Post-process the action logits."""
        ego_action_logits = action_logits["ego_action"][:, :, -1, :]
        agents_action = action_logits["agents_action"][:, :, -1, :]

        top1_ego_action = ego_action_logits.softmax(-1).argmax(-1)

        new_agents_state = self.token_decoder._decode_agents_state(
            current_dynamic_state["agents"][0], agents_action[0].squeeze(1)
        ).unsqueeze(0)
        new_ego_state = self.token_decoder._decode_ego_state(
            current_dynamic_state["ego"][0], top1_ego_action[0].squeeze(0)
        ).unsqueeze(0)

        new_dynamic_state = {
            "ego": new_ego_state,
            "agents": new_agents_state,
        }

        dynamic_states = {
            "ego": torch.cat((dynamic_states["ego"], new_ego_state), dim=2),
            "agents": torch.cat((dynamic_states["agents"], new_agents_state), dim=2),
        }

        return new_dynamic_state, dynamic_states

    def infer_prefill(self, static_scene_tokens, dynamic_states):
        """Perform prefill inference."""
        dynamic_states_prefill = {
            "ego": dynamic_states["ego"][:, :, :-1, :],
            "agents": dynamic_states["agents"][:, :, :-1, :],
        }

        self.kv_mask_cache.empty()
        dynamic_state_tokens = self._dynamic_state_tokenizer(dynamic_states_prefill)
        self._action_model.infer_prefill(static_scene_tokens, dynamic_state_tokens, self.kv_mask_cache)

    def generate(
        self,
        static_scene_tokens_lane,
        static_scene_tokens_current_od,
        static_scene_tokens_navi_path,
        static_scene_tokens_tld,
        static_scene_tokens_control_point,
        dynamic_states_agents,
        dynamic_states_ego,
        max_length=100,
    ):
        """Generate actions."""
        dynamic_states = {
            "ego": dynamic_states_ego,
            "agents": dynamic_states_agents,
        }

        static_scene_tokens = {
            "static_tokens": {
                "lane": static_scene_tokens_lane,
                "current_od": static_scene_tokens_current_od,
            },
            "command_tokens": {
                "navi_path": static_scene_tokens_navi_path,
                "tld": static_scene_tokens_tld,
                "control_point": static_scene_tokens_control_point,
            },
        }

        self.infer_prefill(static_scene_tokens, dynamic_states)

        current_dynamic_state = {
            "ego": dynamic_states["ego"][:, :, -1:, :],
            "agents": dynamic_states["agents"][:, :, -1:, :],
        }

        history_length = dynamic_states["ego"].size(2)

        for _ in range(max_length):
            action_logits = self.loop_forward(current_dynamic_state, self.kv_mask_cache)
            current_dynamic_state, dynamic_states = self.loop_post(current_dynamic_state, action_logits, dynamic_states)
            if dynamic_states["ego"].size(2) >= max_length + history_length:
                dynamic_states["ego"] = dynamic_states["ego"][:, :, : max_length + history_length, :]
                dynamic_states["agents"] = dynamic_states["agents"][:, :, : max_length + history_length, :]
                break
        dynamic_states_agents = dynamic_states["agents"]
        dynamic_states_ego = dynamic_states["ego"]
        batch_mapping = torch.tensor([0]).cuda()  # Placeholder for batch mapping

        return dynamic_states_agents, dynamic_states_ego, batch_mapping
