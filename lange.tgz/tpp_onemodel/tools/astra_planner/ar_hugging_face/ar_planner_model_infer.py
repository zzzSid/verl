# -*- coding: utf-8 -*-
import os

import numpy as np
import torch

from tpp_onemodel.tools.astra_planner.ar_hugging_face.ar_planner_model import (
    AutoRegressivePlannerHF,
)
from tpp_onemodel.tools.astra_planner.ar_hugging_face.ar_planner_model import (
    MyCustomConfig,
)


__source_path = "/share-global/xiangwei.geng/planner/ar_hf/0715"


def dump_config(dump_path):
    """Dump the configuration to a JSON file."""
    config = MyCustomConfig()
    config.to_json_file(os.path.join(dump_path, "config.json"))


def convert_ckpt(ckpt_path, dump_path):
    """Convert a checkpoint to a Hugging Face model format."""
    state_dict = torch.load(ckpt_path)["model"]
    state_dict = {k.replace("module._task_model._auto_regressive_planner.", ""): v for k, v in state_dict.items()}
    state_dict = {
        k.replace(
            "module._task_model._auto_regressive_planner._dynamic_state_tokenizer.",
            "_action_model._dynamic_state_tokenizer.",
        ): v
        for k, v in state_dict.items()
    }
    state_dict = {k: v for k, v in state_dict.items() if "action" in k or "_dynamic_state_tokenizer" in k}
    model = AutoRegressivePlannerHF(MyCustomConfig())

    model.load_state_dict(state_dict)
    model.save_pretrained(dump_path, safe_serialization=True)


def load_hf_model(model_path):
    """Load a Hugging Face model from the specified path."""
    model = AutoRegressivePlannerHF.from_pretrained(model_path)
    model.cuda()
    return model


def load_data(data_path):
    """Load data from a specified path."""
    data = np.load(os.path.join(data_path, "output.npy"), allow_pickle=True).item()
    data = {k: torch.from_numpy(v).cuda() for k, v in data.items()}

    static_scene_tokens_lane = data["static_scene_tokens_lane"]
    static_scene_tokens_current_od = data["static_scene_tokens_current_od"]
    static_scene_tokens_navi_path = data["static_scene_tokens_navi_path"]
    static_scene_tokens_tld = data["static_scene_tokens_tld"]
    static_scene_tokens_control_point = data["static_scene_tokens_control_point"]
    dynamic_states_agents = data["dynamic_states_agents"]
    dynamic_states_ego = data["dynamic_states_ego"]

    return (
        static_scene_tokens_lane,
        static_scene_tokens_current_od,
        static_scene_tokens_navi_path,
        static_scene_tokens_tld,
        static_scene_tokens_control_point,
        dynamic_states_agents,
        dynamic_states_ego,
    )


def load_trace_model_res(data_path):
    """Load trace model results from a specified path."""
    data = np.load(os.path.join(data_path, "input.npy"), allow_pickle=True).item()
    data = {k: torch.from_numpy(v).cuda() for k, v in data.items()}

    dynamic_states_agents = data["dynamic_states_agents"]
    dynamic_states_ego = data["dynamic_states_ego"]
    batch_mapping = data["batch_mapping"]

    return dynamic_states_agents, dynamic_states_ego, batch_mapping


def one_step_forward(model, current_dynamic_state, kv_mask_cache):
    """Perform a one-step forward pass with the model."""
    return model.forward(
        current_dynamic_state=current_dynamic_state,
        kv_mask_cache=kv_mask_cache,
    )


if __name__ == "__main__":
    #     ckpt_path = f"{__source_path}/checkpoint_last.pth.tar"
    #     dump_path = f"{__source_path}"
    #     convert_ckpt(ckpt_path, dump_path)
    #     print(f"Model converted and saved to {dump_path}")

    (
        static_scene_tokens_lane,
        static_scene_tokens_current_od,
        static_scene_tokens_navi_path,
        static_scene_tokens_tld,
        static_scene_tokens_control_point,
        dynamic_states_agents,
        dynamic_states_ego,
    ) = load_data(f"{__source_path}/trace/preprocess/output")

    model = load_hf_model(__source_path)

    with torch.no_grad():
        dynamic_states_agents, dynamic_states_ego, batch_mapping = model.generate(
            static_scene_tokens_lane,
            static_scene_tokens_current_od,
            static_scene_tokens_navi_path,
            static_scene_tokens_tld,
            static_scene_tokens_control_point,
            dynamic_states_agents,
            dynamic_states_ego,
            max_length=25,
        )

    # # result check
    # dynamic_states_agents_trace, dynamic_states_ego_trace, batch_mapping_trace = load_trace_model_res(
    #     f"{__source_path}/trace/add_on/input"
    # )
    # assert torch.allclose(dynamic_states_agents, dynamic_states_agents_trace, atol=1e-5)
    # assert torch.allclose(dynamic_states_ego, dynamic_states_ego_trace, atol=1e-6)
