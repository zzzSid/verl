# -*- coding: utf-8 -*-
import argparse

import torch
import torchpilot
from torchpilot.utils.cfg_parser import PyConfig
from torchpilot.utils.checkpoint_manager import CheckpointManager
from torchpilot.utils.plus_manager import load_plus
from torchpilot.utils.registries import DATALOADER
from torchpilot.utils.registries import TASK_FLOW

from tpp_onemodel.tools.astra_planner.deploy.trace_keys import TRACE_INPUT_KEYS


def load_model_from_checkpoint(planner_cfg, ckpt_path):
    """Build model from cfg and load checkpoint weights."""
    task_flow = TASK_FLOW.build(planner_cfg.infer_task_flow)
    CheckpointManager(
        model=task_flow,
        optimizer=None,
        lr_scheduler=None,
        scaler=None,
        pretrain_model=ckpt_path,
        trace_mode=True,
    ).load_model()
    return task_flow


def get_input_data_min_max(planner_cfg):
    """Get the min and max value for the input sample."""
    torch.distributed.init_process_group(
        backend="nccl",
        init_method="tcp://localhost:9999",
        world_size=1,
        rank=0,
    )
    data_cfg = planner_cfg.infer_dataloader
    data_cfg.dataset_cfg.shuffle = False
    data_cfg.dataset_cfg.batch_size = 256
    data_loader = DATALOADER.build(data_cfg)
    sample = next(iter(data_loader))
    input_min_max = {}
    for key in TRACE_INPUT_KEYS:
        cur_tensor = sample[key]
        input_min_max[key] = (cur_tensor.min().item(), cur_tensor.max().item())
    return input_min_max


def get_param_min_max(model):
    """Get the min and max value for the model weights."""
    param_min_max = {}
    for name, param in model.named_parameters():
        param_min = param.data.min().item()
        param_max = param.data.max().item()
        param_min_max[name] = (param_min, param_max)
    return param_min_max


if __name__ == "__main__":
    load_plus()
    parser = argparse.ArgumentParser()
    parser.add_argument("--cfg", type=str, required=True, help="astra planner cfg")
    parser.add_argument("--ckpt", type=str, required=True, help="astra planner ckpt")
    args = parser.parse_args()

    cfg = PyConfig.fromfile(args.cfg)
    model = load_model_from_checkpoint(cfg, args.ckpt)
    param_min_max = get_param_min_max(model)
    data_min_max = get_input_data_min_max(cfg)

    logger = torchpilot.logger
    for name, (min_val, max_val) in param_min_max.items():
        if min_val < -10.0 or max_val > 10.0:
            logger.info("param: %s | min: %.4f | max: %.4f", name, min_val, max_val)

    for name, (min_val, max_val) in data_min_max.items():
        if min_val < -1000.0 or max_val > 1000.0:
            logger.info("input: %s | min: %.4f | max: %.4f", name, min_val, max_val)
