# -*- coding: utf-8 -*-
import argparse
import os
import pickle as pkl
import re
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import as_completed

from tqdm import tqdm

# from tpp_onemodel.configs.planner.datasets import (
#     DatasetTrainMannerNaviLine0811 as TargetDataset,
# )
from tpp_onemodel.utils.niofs import get_niofs_client
from tpp_onemodel.utils.niofs import parse_niofs_url


tag_mapping_dict = {
    "astra_planner.fft_hw.single_lane_driving.following_steady": "HighwayFollowSteady",
    "astra_planner.fft_hw.single_lane_driving.following_stop": "HighwayFollowStop",
    "astra_planner.fft_hw.single_lane_driving.following_start": "HighwayFollowStart",
    "astra_planner.fft_hw.single_lane_driving.following_accelerate_timely": "HighwayFollowAccelerateTimely",
    "astra_planner.fft_hw.single_lane_driving.avoiding_nudge": "HighwayAvoidNudge",
    "astra_planner.fft_hw.single_lane_driving.cutout_vehicle": "HighwayCutoutVehicle",
    "astra_planner.fft_hw.single_lane_driving.cutin_vehicle": "HighwayCutinVehicle",
    "astra_planner.fft_hw.single_lane_driving.SOD_react": "HighwaySODReact",
    "astra_planner.fft_hw.single_lane_driving.GOD_react": "HighwayGODReact",
    "astra_planner.fft_hw.sidepass.SOD_obstacle_avoidance": "HighwaySODObstacleAvoidance",
    "astra_planner.fft_hw.sidepass.stationary_OD_avoidance": "HighwayStationaryODAvoidance",
    "astra_planner.fft_hw.sidepass.road_to_ramp": "HighwayRoadToRamp",
    "astra_planner.fft_hw.sidepass.ramp_to_road": "HighwayRampToRoad",
    "astra_planner.fft_hw.sidepass.navigate": "HighwayNavigate",
    "astra_planner.fft_hw.sidepass.overtake": "HighwayOvertake",
    "astra_planner.fft_hw.sidepass.destination": "HighwayDestination",
    "astra_planner.fft_hw.sidepass.nudge_same_direction": "HighwayNudgeSameDirection",
    "astra_planner.fft_hw.junction.tld_go": "HighwayTLDGo",
    "astra_planner.fft_hw.sidepass.lanechange": "HighwayLaneChange",
    "astra_planner.fft_hw.sidepass.lanechange_left": "HighwayLaneChangeLeft",
    "astra_planner.fft_hw.sidepass.lanechange_right": "HighwayLaneChangeRight",
    "astra_planner.fft_hw.sidepass.ego_target_sametime": "HighwayEgoTargetSametime",
    "astra_planner.fft_urban.junction.straight_pass": "UrbanJunctionStraightPass",
    "astra_planner.fft_urban.junction.turn_right": "UrbanJunctionTurnRight",
    "astra_planner.fft_urban.junction.turn_left": "UrbanJunctionTurnLeft",
    "astra_planner.fft_urban.junction.unprotected_leftturn_opposite_vehicle": "UrbanJunctionUnprotectedLeftTurnOppositeVehicle",
    "astra_planner.fft_urban.junction.turnright_vehicle_merge": "UrbanJunctionTurnRightVehicleMerge",
    "astra_planner.fft_urban.junction.turnleft_vehicle_merge": "UrbanJunctionTurnLeftVehicleMerge",
    "astra_planner.fft_urban.junction.turnright_VRU_cross": "UrbanJunctionTurnRightVRUCross",
    "astra_planner.fft_urban.junction.turnleft_VRU_cross": "UrbanJunctionTurnLeftVRUCross",
    "astra_planner.fft_urban.single_lane_driving.following_steady": "UrbanSingleLaneDrivingFollowSteady",
    "astra_planner.fft_urban.single_lane_driving.following_stop": "UrbanSingleLaneDrivingFollowStop",
    "astra_planner.fft_urban.single_lane_driving.following_start": "UrbanSingleLaneDrivingFollowStart",
    "astra_planner.fft_urban.single_lane_driving.following_accelerate_timely": "UrbanSingleLaneDrivingFollowAccelerateTimely",
    "astra_planner.fft_urban.single_lane_driving.cutin_vehicle": "UrbanSingleLaneDrivingCutinVehicle",
    "astra_planner.fft_urban.single_lane_driving.cutin_VRU": "UrbanSingleLaneDrivingCutinVRU",
    "astra_planner.fft_urban.single_lane_driving.cutout_vehicle": "UrbanSingleLaneDrivingCutoutVehicle",
    "astra_planner.fft_urban.sidepass.nudge_same_direction": "UrbanSidepassNudgeSameDirection",
    "astra_planner.fft_urban.sidepass.nudge_opposite_direction": "UrbanSidepassNudgeOppositeDirection",
    "astra_planner.fft_urban.sidepass.navigate": "UrbanSidepassNavigate",
    "astra_planner.fft_urban.sidepass.overtake": "UrbanSidepassOvertake",
    "astra_planner.fft_urban.sidepass.destination": "UrbanSidepassDestination",
    "astra_planner.fft_urban.single_lane_driving.avoiding_nudge": "UrbanSingleLaneDrivingAvoidNudge",
    "astra_planner.fft_urban.sidepass.stationary_OD_avoidance": "UrbanSidepassStationaryODAvoidance",
    "astra_planner.fft_urban.sidepass.main_to_side": "UrbanSidepassMainToSide",
    "astra_planner.fft_urban.sidepass.side_to_main": "UrbanSidepassSideToMain",
    "astra_planner.fft_urban.junction.tld_stop": "UrbanJunctionTLDStop",
    "astra_planner.fft_urban.junction.tld_start": "UrbanJunctionTLDStart",
    "astra_planner.fft_urban.junction.T_no_tld_merge_to_main": "UrbanJunctionTNoTLDMergeToMain",
    "astra_planner.fft_urban.junction.head_pass": "UrbanJunctionHeadPass",
    "astra_planner.fft_urban.single_lane_driving.SOD_react": "UrbanSingleLaneDrivingSODReact",
    "astra_planner.fft_urban.single_lane_driving.GOD_react": "UrbanSingleLaneDrivingGODReact",
    "astra_planner.fft_urban.sidepass.SOD_obstacle_avoidance": "UrbanSidepassSODObstacleAvoidance",
    "astra_planner.fft_urban.sidepass.lanechange": "UrbanSidepassLaneChange",
    "astra_planner.fft_urban.sidepass.lanechange_left": "UrbanSidepassLaneChangeLeft",
    "astra_planner.fft_urban.sidepass.lanechange_right": "UrbanSidepassLaneChangeRight",
    "astra_planner.fft_urban.sidepass.ego_target_sametime": "UrbanSidepassEgoTargetSametime",
    "astra_planner.fft_data_cleaning.navigation_information.SD_coverage": "DataCleaningNavigationInformationSDCoverage",
    "astra_planner.fft_data_cleaning.navigation_information.no_SD_coverage": "DataCleaningNavigationInformationNoSDCoverage",
    "astra_planner.fft_data_cleaning.navigation_information.HD_coverage": "DataCleaningNavigationInformationHDCoverage",
    "astra_planner.fft_data_cleaning.navigation_information.no_HD_coverage": "DataCleaningNavigationInformationNoHDCoverage",
    "astra_planner.fft_data_cleaning.navigation_information.waypoints_coverage": "DataCleaningNavigationInformationWaypointsCoverage",
    "astra_planner.fft_data_cleaning.navigation_information.no_waypoints_coverage": "DataCleaningNavigationInformationNoWaypointsCoverage",
    "astra_planner.fft_urban.single_lane_driving.lane_centering": "UrbanSingleLaneDrivingLaneCentering",
    "astra_planner.fft_urban.sidepass.slow_target_al_front": "UrbanSidepassSlowTargetAlFront",
    "astra_planner.fft_urban.single_lane_driving.side_parked_vehicle": "UrbanSingleLaneDrivingSideParkedVehicle",
}

ceph_client = get_niofs_client(max_pool_connections=os.cpu_count())


def export_single_scene_dataset(dataset_path, single_tag_path, tag_version):
    """Single scene dataset export."""
    clip_id_to_tags_dict = {}
    tags_to_clip_id_dict = {}
    wo_tags_clip_set = set()
    # dataset_config = TargetDataset().to_dict()["4D_OD_PRED_FULL"]

    def process_clip(clip_pkl_path):
        """
        Process the clip at the given path and extract tags from it.

        Args:
            clip_pkl_path (str): The path to the clip's pickle file.

        Returns:
            None

        Raises:
            None
        """
        clip_pkl_path = clip_pkl_path.strip()

        tag_pkl_path = re.sub(r"/prod_[^/]+", "/prod_yx_20240919_tags_only_all", clip_pkl_path)
        tags_path = os.path.join(
            os.path.dirname(tag_pkl_path).replace("meta_data", "tags"),
            os.path.basename(tag_pkl_path).replace(".pkl", "_tags.pkl"),
        )

        try:
            bucket, key = parse_niofs_url(tags_path, client=ceph_client)
            os.makedirs("./tmp", exist_ok=True)
            tmp_file_path = f"./tmp/tags_{os.getpid()}_{key.replace('/', '_')}.pkl"
            ceph_client.download_file(Bucket=bucket, Key=key, Filename=tmp_file_path)
            with open(tmp_file_path, "rb") as f_tags:
                tags = pkl.load(f_tags)
                tags_set = set()
                for key, tag in tags.items():
                    tag = tag["objs"]
                    for one_tag in tag:
                        tags_set.add(tag_mapping_dict.get(one_tag["cate"], None))
                tags_set.discard(None)
                clip_id_to_tags_dict[clip_pkl_path] = tags_set
                for tag in tags_set:
                    if tag not in tags_to_clip_id_dict:
                        tags_to_clip_id_dict[tag] = set()
                    tags_to_clip_id_dict[tag].add(clip_pkl_path)
            os.remove(tmp_file_path)
        except Exception as e:
            print(f"Tags not found: {tags_path}", e)  # noqa: T201
            wo_tags_clip_set.add(clip_pkl_path)
            return

    with ThreadPoolExecutor(max_workers=os.cpu_count()) as executor:
        futures = []

        with open(dataset_path, "r") as f:
            clip_pkl_paths = f.readlines()
            for clip_pkl_path in clip_pkl_paths:
                futures.append(executor.submit(process_clip, clip_pkl_path))

        for future in tqdm(as_completed(futures), total=len(futures)):
            future.result()

    # single_tag_path = "./single_scene_export"
    os.makedirs(single_tag_path, exist_ok=True)
    for tag, clip_ids in tags_to_clip_id_dict.items():
        with open(os.path.join(single_tag_path, f"{tag}.txt"), "w") as f:
            for clip_id in clip_ids:
                f.write(f"{clip_id}\n")

    pkl.dump(clip_id_to_tags_dict, open(os.path.join(single_tag_path, f"clip_id_to_tags_dict_{tag_version}.pkl"), "wb"))
    print(  # noqa: T201
        "Save clip_id_to_tags_dict to ", os.path.join(single_tag_path, f"clip_id_to_tags_dict_{tag_version}.pkl")
    )  # noqa: T201
    print("Target tags coverage ratio = ", len(clip_id_to_tags_dict) / len(clip_pkl_paths))  # noqa: T201
    print(  # noqa: T201
        "All tags coverage ratio = ", (len(clip_pkl_paths) - len(wo_tags_clip_set)) / len(clip_pkl_paths)
    )  # noqa: T201


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process some parameters.")
    parser.add_argument("--dataset_path", default="./gen_dataset", type=str, help="The dataset to be used")
    parser.add_argument("--tag_version", default="default", type=str, help="The version name of tag")
    parser.add_argument("--single_tag_path", default="", type=str, help="The single tag path")

    args = parser.parse_args()
    single_tag_path = args.single_tag_path if len(args.single_tag_path) > 0 else args.dataset_path
    dataset_files = os.listdir(args.dataset_path)
    dataset_files = [f for f in os.listdir(args.dataset_path) if f.endswith(".txt")]
    for dataset_file in dataset_files:
        # if 'train' in dataset_file:
        #     input_dataset_path = os.path.join(args.dataset_path, dataset_file)
        #     print(1)
        # elif 'infer' in dataset_file:
        #     input_dataset_path = os.path.join(args.dataset_path, dataset_file)
        #     print(2)
        if "train" in dataset_file or "test" in dataset_file:
            # if "test" in dataset_file:
            input_dataset_path = os.path.join(args.dataset_path, dataset_file)
            output_file_path = os.path.join(single_tag_path, dataset_file.split(".")[0])
            export_single_scene_dataset(input_dataset_path, output_file_path, args.tag_version)
