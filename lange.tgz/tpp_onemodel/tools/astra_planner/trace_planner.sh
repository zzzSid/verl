#!/bin/bash
# ======================== RUN ===========================
# bash tpp_onemodel/tools/astra_planner/trace_planner.sh
# ========================================================

set -xe

source .venv/bin/activate

TRACE_NAME="astra_planner_$(date +"%Y%m%d%H%M")_trace.pt"

CFG_PATH="experiments/task_planner/exp_planner_release/cfg_planner_trace.py"
CKPT_PATH="/share-global/nell.dong/release/planner/release_20241229_daily/ckpt/checkpoint_last.pth.tar"
SAVE_PATH="/share-global/${USER}/${TRACE_NAME}"

python3 tests/end2end/task_planner/exp_planner/planner_trace_test.py \
    --cfg_path ${CFG_PATH} \
    --ckpt_path ${CKPT_PATH} \
    --save_path ${SAVE_PATH}
