set -xe

source .venv/bin/activate
export LIDAR_INFER_MODE=trace
export CUBLAS_WORKSPACE_CONFIG=:4096:8

# 在cfg文件的 infer_dataloader 中, 修改datasets， 其中存放目标clip的pkl
CFG_PATH="experiments/task_planner/cfg_release_0731.py"
# 跑 argus ppl dump 得到的目标clip的模型input和output
CPP_DUMP_DIR="/share-global/runlin.he/align_data/astra_planner_test_20240810004808"
# 要比较的目标帧
TS=1718971027108
RESULT_DIR="./export_models/"

python3 tpp_onemodel/tools/astra_planner/compare_inputs.py \
    --cfg_planner $CFG_PATH \
    --cpp_dump_dir $CPP_DUMP_DIR \
    --ts $TS \
    --result_dir $RESULT_DIR
