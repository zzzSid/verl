# -*- coding: utf-8 -*-
import torchpilot


logger = torchpilot.logger

logger.error(
    "This script is deprecated. Please use tpp_onemodel/tools/astra_planner/data/data_utils_scripts/planner_data_utils_vis.py instead."
)
