# -*- coding: utf-8 -*-
import argparse

# import json
import os

# import random
# from typing import Dict
from typing import List

import matplotlib.pyplot as plt


def plot_scene_distribution(scene_name_list, scene_sum_list, files_num_sum):
    """Plot the distribution of scene tags."""
    plt.figure(figsize=(12 * 2, 6 * 2))
    plt.bar(scene_name_list, scene_sum_list)
    plt.xlabel("Scene Tag Name")
    plt.ylabel("Clip num")
    plt.title("Distribution of Scene Tags")
    plt.xticks(rotation=45, ha="right", fontsize=8)

    for i, v in enumerate(scene_sum_list):
        plt.text(i, v, str(v), ha="center", va="bottom", fontsize=8)
        plt.text(i, v, f"{(v/files_num_sum):.4f}", ha="center", va="top", fontsize=8)

    plt.tight_layout()
    plt.savefig("scene_distribution.png")


def generate_class_file(scene_root_dir: str, target_class_name: str, target_dict_list: List) -> str:
    """Generate the content of the class file."""
    # 获取 scene_root_dir 目录下的所有标签
    label_names = set()
    for filename in os.listdir(scene_root_dir):
        if filename.endswith(".txt"):
            label_name = filename.replace(".txt", "")
            label_names.add(label_name)

    # 初始化字典模板
    class_template = f"""
class {target_class_name}(MultiDatasetConfig):  # noqa: N801
    scene_root_dir: str = "{scene_root_dir}"
"""

    # 生成每个标签字典
    for category_dict in target_dict_list:
        dict_name = category_dict["category_name"]
        class_template += f"    {dict_name}_dict: Dict[str, float] = {{\n"

        for label in category_dict["labels"]:
            if label in label_names:
                class_template += f'        "{label}": 1.0,  # default sampling rate\n'
            else:
                class_template += f'        "{label}": 1.0,  # warning: label not found in {scene_root_dir}\n'

        class_template += "    }\n"

    # 生成 multi_dataset_dict
    class_template += "    multi_dataset_dict: Dict[str, List] = {\n"

    for category_dict in target_dict_list:
        category_name = category_dict["category_name"]
        class_template += f'        "{category_name}": [{category_name}_dict, 1],\n'

    class_template += "    }\n"

    return class_template


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Write specified content to a text file.")
    parser.add_argument(
        "--output_dataset_class_path",
        type=str,
        default="./resample_dataset_class.txt",
        help="The path to the text file",
    )
    parser.add_argument(
        "--root_dir",
        type=str,
        default="/share-global/mccree.zhao/share/planning/dataset/0904_100w_tag/0904_100w_tag_train_694247",
        help="The root directory",
    )
    args = parser.parse_args()

    scene_name_list = []
    scene_sum_list = []
    scene_files_num_dict = {}
    scene_files = os.listdir(args.root_dir)
    scene_files.sort()
    print(scene_files)  # noqa: T201
    files_num_sum = 0
    UrbanStraight_num = 0
    for scene_file in scene_files:
        if scene_file.endswith(".txt"):
            with open(os.path.join(args.root_dir, scene_file), "r") as f:
                scene_content = f.readlines()
            if scene_file == "UrbanJunctionStraightPass.txt":
                UrbanStraight_num = len(scene_content)
            scene_files_num_dict[scene_file] = len(scene_content)
            files_num_sum += len(scene_content)
            scene_name_list.append(scene_file.split(".")[0])
            scene_sum_list.append(len(scene_content))

    plot_scene_distribution(scene_name_list, scene_sum_list, files_num_sum)

    target_class_name = "DatasetnSceneSelect0904_100w_static"
    target_dict_list = [
        {
            "category_name": "intersection",
            "labels": [
                "UrbanJunctionTurnRight",
                "UrbanJunctionTurnLeft",
                "UrbanJunctionStraightPass",
                "HighwayTLDGo",
                "UrbanJunctionUnprotectedLeftTurnOppositeVehicle",
                "UrbanJunctionTurnRightVehicleMerge",
                "UrbanJunctionTurnLeftVehicleMerge",
                "UrbanJunctionTurnRightVRUCross",
                "UrbanJunctionTurnLeftVRUCross",
                "UrbanJunctionTLDStop",
                "UrbanJunctionTLDStart",
                "UrbanJunctionTNoTLDMergeToMain",
                "UrbanJunctionHeadPass",
            ],
        },
        {
            "category_name": "lane_keep",
            "labels": [
                "HighwayFollowSteady",
                "HighwayFollowStop",
                "HighwayFollowStart",
                "HighwayFollowAccelerateTimely",
                "HighwayAvoidNudge",
                "HighwayCutoutVehicle",
                "HighwayCutinVehicle",
                "HighwaySODReact",
                "HighwayGODReact",
                "HighwaySODObstacleAvoidance",
                "HighwayStationaryODAvoidance",
                "HighwayRoadToRamp",
                "HighwayRampToRoad",
                "HighwayNudgeSameDirection",
                "UrbanSingleLaneDrivingFollowSteady",
                "UrbanSingleLaneDrivingFollowStop",
                "UrbanSingleLaneDrivingFollowStart",
                "UrbanSingleLaneDrivingFollowAccelerateTimely",
                "UrbanSingleLaneDrivingCutinVehicle",
                "UrbanSingleLaneDrivingCutinVRU",
                "UrbanSingleLaneDrivingCutoutVehicle",
                "UrbanSidepassNudgeSameDirection",
                "UrbanSidepassNudgeOppositeDirection",
                "UrbanSingleLaneDrivingAvoidNudge",
                "UrbanSidepassStationaryODAvoidance",
                "UrbanSidepassMainToSide",
                "UrbanSidepassSideToMain",
                "UrbanSingleLaneDrivingSODReact",
                "UrbanSingleLaneDrivingGODReact",
            ],
        },
        {
            "category_name": "lane_change",
            "labels": [
                "HighwayNavigate",
                "HighwayOvertake",
                "HighwayDestination",
                "HighwayLaneChange",
                "HighwayLaneChangeLeft",
                "HighwayLaneChangeRight",
                "HighwayEgoTargetSametime",
                "UrbanSidepassNavigate",
                "UrbanSidepassOvertake",
                "UrbanSidepassDestination",
                "UrbanSidepassSODObstacleAvoidance",
                "UrbanSidepassLaneChange",
                "UrbanSidepassLaneChangeLeft",
                "UrbanSidepassLaneChangeRight",
                "UrbanSidepassEgoTargetSametime",
            ],
        },
    ]
    class_file_content = generate_class_file(args.root_dir, target_class_name, target_dict_list)

    print(class_file_content)  # noqa: T201
    output_file_path = args.output_dataset_class_path
    with open(output_file_path, "w") as f:
        f.write(class_file_content)
