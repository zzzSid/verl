# -*- coding: utf-8 -*-

# -*- coding: utf-8 -*-
import matplotlib.patches as patches
import matplotlib.pyplot as plt
import numpy as np
from fastdtw import fastdtw
from scipy.optimize import linear_sum_assignment
from scipy.spatial import cKDTree
from scipy.spatial.distance import euclidean
from shapely.geometry import Polygon


def calculate_rectangle_corners(center_x, center_y, x_length, y_length, angle):
    """Calc rect corners."""
    theta = angle

    half_x_length = x_length / 2
    half_y_length = y_length / 2

    corners = np.array(
        [
            [-half_x_length, -half_y_length],
            [half_x_length, -half_y_length],
            [half_x_length, half_y_length],
            [-half_x_length, half_y_length],
        ]
    )

    rotation_matrix = np.array([[np.cos(theta), -np.sin(theta)], [np.sin(theta), np.cos(theta)]])

    rotated_corners = rotation_matrix @ corners.T

    rotated_corners = rotated_corners.T

    rotated_corners += np.array([center_x, center_y])

    return rotated_corners


def plot_atlas(atlas: np.ndarray, ax, label=None, **kwargs):
    """Plot atlas.

    Args:
        atlas: [50, 30, 3]
    """
    num_lines = atlas.shape[0]

    for index in range(num_lines):
        valid_line = atlas[index, 0, -1] != -1
        points = atlas[index, valid_line, :]

        if points.shape[0] > 0:
            points = points[0]
            points = points[~np.all(points == -1, axis=1)]
            ax.plot(points[:, 0], points[:, 1], **kwargs)

    ax.plot([], [], label=label, **kwargs)


def plot_lines(
    points: np.ndarray,
    types: np.ndarray,
    ax,
    label=None,
    type_invalid_val=-1,
    **kwargs,
):
    """Plot lines.

    Args:
        points: [N, M, 2]
        types: [N, M]
    """
    num_lines = points.shape[0]
    line_num = 0

    for line_idx in range(num_lines):
        valid_mask = types[line_idx] != type_invalid_val
        if valid_mask.sum() == 0:
            continue

        valid_points = points[line_idx, valid_mask, :]
        if valid_points.shape[0] > 0:
            line_num += 1
            ax.plot(valid_points[:, 0], valid_points[:, 1], **kwargs)

    ax.plot([], [], label=f"{label}_cnt_{line_num}", **kwargs)


def plot_sod_lines(lines: np.ndarray, masks: np.ndarray, ax, linestyle=None, marker=None, color=None, label=None):
    """Plot singoe source sod lines.

    Args:
        lines: [N, M, 2]
        masks: [N, M]
    """
    valid_mask = masks == 0
    num_lines = lines.shape[0]

    for line_idx in range(num_lines):
        tmp_mask = valid_mask[line_idx]
        tmp_line = lines[line_idx, tmp_mask, :]

        if tmp_line.shape[0] > 0:

            ax.plot(tmp_line[:, 0], tmp_line[:, 1], linestyle=linestyle, marker=marker, markersize=1, color=color)

    ax.plot(tmp_line[:, 0], tmp_line[:, 1], linestyle=linestyle, marker=marker, markersize=1, color=color, label=label)


def plot_polygons(polygons: np.ndarray, masks: np.ndarray, ax, label=None, **kwargs):
    """Plot polygons.

    Args:
        polygons: [32, 16, 2]
        masks: [32, 16]
    """
    for polygon_idx in range(polygons.shape[0]):
        polygon = polygons[polygon_idx]
        valid_mask = masks[polygon_idx] == 0
        if valid_mask.sum() == 0:
            continue
        valid_pts = polygon[valid_mask]
        ax.add_patch(patches.Polygon(valid_pts, **kwargs))
    ax.add_patch(patches.Polygon(np.zeros((0, 2)), label=label, **kwargs))


def batch_plot_od_hist(orig_coords: np.ndarray, trans_m: np.ndarray, ax, **kwargs):
    """Plot batch od hist.

    Args:
    orig_coords: [N, 3], x, y, z
    trans_m: [N, 4, 4]
    """
    ones_column = np.ones((orig_coords.shape[0], 1))
    orig_coords = np.hstack((orig_coords, ones_column))

    curr_frame_coords = trans_m @ orig_coords.T  # [N, 4, 1]

    ax.scatter(curr_frame_coords[0, :], curr_frame_coords[1, :], **kwargs)


def plot_ego_box(boxes: np.ndarray, masks: np.ndarray, ax, label=None, **kwargs):
    """Plot single source ego position.

    Args:
        box: [T, 1, 7]
        masks: [T, 1]
    """
    boxes_curr = boxes[-1][0]
    pts = calculate_rectangle_corners(boxes_curr[0], boxes_curr[1], boxes_curr[3], boxes_curr[4], boxes_curr[6])
    ax.add_patch(patches.Polygon(pts, fill=False, lw=1.0, label=label, zorder=100, **kwargs))


def plot_rectangles(boxes: np.ndarray, masks: np.ndarray, ax, label=None, mask_valid_val=0, **kwargs):
    """Plot rectangles.

    Args:
        boxes: [N, 5]
        masks: [N, ]
    """
    valid_pos = masks == mask_valid_val
    valid_box = boxes[valid_pos]
    bbox_index = np.arange(0, boxes.shape[0])  # 0-N

    for box_idx in range(valid_box.shape[0]):
        bbox = valid_box[box_idx]
        pts = calculate_rectangle_corners(bbox[0], bbox[1], bbox[2], bbox[3], bbox[4])
        ax.add_patch(patches.Polygon(pts, **kwargs))
        ax.text(
            bbox[0] + 0.5,
            bbox[1] + 0.5,
            str(bbox_index[box_idx]),
            fontsize=5,
            color=kwargs["color"],
            ha="center",
            va="center",
            zorder=120,
        )
    ax.add_patch(patches.Polygon(np.zeros((0, 2)), label=label, **kwargs))


def plot_od_boxes(boxes: np.ndarray, masks: np.ndarray, ax, color=None, label=None):  # to be removed
    """Plot single source od boxes.

    Args:
        boxes: [191, 7]
        masks: [191, ]
    """
    boxes = boxes[-1]
    masks = masks[-1]
    valid_pos = masks == 0
    valid_box = boxes[valid_pos]

    for box_idx in range(valid_box.shape[0]):
        bbox = valid_box[box_idx]
        pts = calculate_rectangle_corners(bbox[0], bbox[1], bbox[3], bbox[4], bbox[6])
        ax.add_patch(patches.Polygon(pts, fill=False, lw=1.0, color=color, zorder=100))
    ax.add_patch(patches.Polygon(np.zeros((0, 2)), fill=False, lw=1.0, color=color, label=label, zorder=100))


def plot_agent_hist(boxes, masks, trans, ax, label=None, mask_valid_val=0, **kwargs):
    """Plot agent hist."""
    valid_hist_cnt = 0
    for i in range(boxes.shape[0]):  # TODO(ian.xu) vectorize
        valid_mask = masks[i] == mask_valid_val
        if valid_mask.sum() == 0:
            continue
        valid_hist_cnt += 1
        valid_box = boxes[i][valid_mask]
        batch_plot_od_hist(valid_box, trans[i], ax, **kwargs)

    ax.scatter([], [], label=f"{label}_cnt_{valid_hist_cnt}", **kwargs)


def plot_agent_traj(pred, ax, label=None, **kwargs):
    """Plot agent traj."""
    for agent_id in range(pred.shape[0]):
        ax.scatter(pred[agent_id, :, 0], pred[agent_id, :, 1], **kwargs)
    ax.scatter([], [], label=label, **kwargs)


def plot_traj_with_num(pred, ax, label=None, color="yellow", point_size=20, linewidth=10):
    """Plot agent traj.

    pred: [A, T, 2]
    mask: [A, T]
    """
    for agent_id in range(pred.shape[0]):
        ax.scatter(pred[agent_id, ::5, 0], pred[agent_id, ::5, 1], color=color, s=point_size)
        ax.plot(pred[agent_id, ::5, 0], pred[agent_id, ::5, 1], color=color, linewidth=linewidth, alpha=0.3)
        # 每隔5个点显示数字
        for i in range(0, pred.shape[1], 5):
            if i % 5 == 0 and i != 0:
                ax.text(
                    pred[agent_id, i, 0],
                    pred[agent_id, i, 1],
                    str(i // 5 + 1),
                    fontsize=7,
                    ha="center",
                    va="center",
                    color="black",
                )

    ax.scatter([], [], label=label)


def plot_ego_gt(ego_gt: np.ndarray, ax):
    """Plot single source ground truth traj."""
    ax.plot(ego_gt[0, :, 0], ego_gt[0, :, 1], "-", color="grey", markersize=5, alpha=0.5)
    ax.plot(ego_gt[0, :, 0], ego_gt[0, :, 1], ".", color="grey", markersize=5, alpha=0.2)


def plot_ego_pred(ego_pred: np.ndarray, ax):
    """Plot single source ego predictions."""
    num_preds = ego_pred.shape[1]
    for idx in range(num_preds):
        # Get valid points from map 1
        pred = ego_pred[0, idx, :, :]
        if pred.shape[0] > 0:
            ax.plot(pred[:, 0], pred[:, 1], "-", color="blue", markersize=5, alpha=0.5)


def plot_agent_pred(agent_pred: np.ndarray, ax):
    """Plot single source agent predictions."""
    num_agents, num_preds, _, _ = agent_pred.shape
    for agent_idx in range(num_agents):
        for pred_idx in range(num_preds):
            # Get valid points from map 1
            pred = agent_pred[agent_idx, pred_idx, :, :]
            if pred.shape[0] > 0:
                ax.plot(pred[:, 0], pred[:, 1], "-", color="green", markersize=5, alpha=0.5)


def plot_agent_gt(agent_gt: np.ndarray, agent_mask: np.ndarray, ax):
    """Plot single source agent groundtruths."""
    num_gts = agent_gt.shape[0]
    for idx in range(num_gts):
        # Get valid points from map 1
        mask = agent_mask[idx, :] != 0
        agent = agent_gt[idx, mask, :]
        if agent.shape[0] > 0:
            ax.plot(agent[:, 0], agent[:, 1], "-", color="grey", markersize=5, alpha=0.5)


def plot_sample(dump_data, output_file_name=None):
    """Complete visualization of a sample."""
    x_min = -40
    y_min = -50
    x_max = +100
    y_max = +50
    figsize = (20, 10)
    plt.figure(0, figsize=figsize, dpi=100)
    plt.xlim(x_min, x_max)
    plt.ylim(y_min, y_max)
    ax = plt.gca()

    # Plot ego object
    if "egos" in dump_data and "egos_padding_mask" in dump_data:
        plot_ego_box(
            dump_data["egos"],
            dump_data["egos_padding_mask"],
            ax,
            color="violet",
        )

    # Plot navi lanes
    if "navi_line_points" in dump_data and "navi_line_types" in dump_data:
        plot_lines(
            dump_data["navi_line_points"],
            dump_data["navi_line_types"],
            ax,
            label="naviline",
            type_invalid_val=-1,
            marker=".",
            color="black",
        )

    # Plot lanes
    if "lane_points" in dump_data and "lane_types" in dump_data:
        plot_lines(dump_data["lane_points"], dump_data["lane_types"], ax)

    # Plot od boxes
    if "origin_bboxes" in dump_data and "origin_bboxes_padding_mask" in dump_data:
        want_feat_idx = [0, 1, 3, 4, 6]  # x,y,l,w,heading
        plot_rectangles(
            dump_data["origin_bboxes"][-1][:, want_feat_idx],
            dump_data["origin_bboxes_padding_mask"][-1],
            ax,
            mask_valid_val=0,
            fill=False,
            lw=1.0,
            zorder=100,
        )

    # Plot ego gt
    if "egos_pred_gt" in dump_data:
        plot_ego_gt(dump_data["egos_pred_gt"], ax)

    # Plot agent gt
    if "origin_bboxes_pred_gt" in dump_data and "origin_bboxes_pred_mask" in dump_data:
        plot_agent_gt(dump_data["origin_bboxes_pred_gt"], dump_data["origin_bboxes_pred_mask"], ax)

    # Plot ego pred
    if "ego_future_traj_pred" in dump_data:
        plot_ego_pred(dump_data["ego_future_traj_pred"], ax)

    # Plot agent pred
    if "future_traj_pred" in dump_data:
        plot_agent_pred(dump_data["future_traj_pred"], ax)

    # Plot Atlas
    if "atlas" in dump_data:
        atlas_data = dump_data["atlas"][:, :, :-1]
        atlas_type = dump_data["atlas"][:, :, -1]
        plot_lines(atlas_data, atlas_type, ax, type_invalid_val=-1, color="olive")

    # Plot Sod
    if "sod_poly_pts" in dump_data and "sod_poly_pts_padding_mask" in dump_data:
        plot_lines(
            dump_data["sod_poly_pts"],
            dump_data["sod_poly_pts_padding_mask"],
            ax,
            type_invalid_val=1,
            linestyle="-",
            marker="o",
            markersize=1,
            color="red",
            label="sodlines_py",
        )

    if not output_file_name:
        plt.show()
    else:
        plt.savefig(output_file_name)
        plt.clf()


def calc_dtw_distance(line1, mask1, line2, mask2, mask_invalid_val):
    """DTW cost."""
    valid_num_1 = line1[mask1 != mask_invalid_val].shape[0]
    valid_num_2 = line2[mask2 != mask_invalid_val].shape[0]
    if valid_num_1 == 0 or valid_num_2 == 0:
        return 0

    distance, path = fastdtw(line1[mask1 != mask_invalid_val], line2[mask2 != mask_invalid_val], dist=euclidean)
    pts_num = min(valid_num_1, valid_num_2)
    return distance / pts_num


def calc_perpendicular_distances(line1, mask1, line2, mask2, mask_invalid_val):
    """Compute the perpendicular (lateral) distance from each point on line1 to line2 and vice versa."""
    tree_line2 = cKDTree(line2[mask2 != mask_invalid_val])

    distances_line1_to_line2, _ = tree_line2.query(line1)

    tree_line1 = cKDTree(line1[mask1 != mask_invalid_val])

    distances_line2_to_line1, _ = tree_line1.query(line2)

    avg_distance = (np.mean(distances_line1_to_line2) + np.mean(distances_line2_to_line1)) / 2

    return avg_distance


def calc_euclidean_distance(item1, mask1, item2, mask2, mask_invalid_val):
    """
    Compute the distance between two items using Euclidean distance.

    Args:
        item1: [..., 2] single item features, last dimension is [x, y]
        mask1: [...] mask
    """
    # only calc distance of valid entries
    both_valid = np.logical_and(mask1 != mask_invalid_val, mask2 != mask_invalid_val)

    # compute the Euclidean distance between corresponding points
    distances = np.linalg.norm(item1[both_valid] - item2[both_valid], axis=-1)

    mean_distance = np.mean(distances) if distances.size != 0 else np.inf

    return mean_distance


def calc_iou(bbox1, bbox2):
    """
    Compute the iou between two bbox tensor.

    Args:
        bbox: cx, cy, length x, length y, angle
    """
    epsilon = 1e-10

    # Get the vertices of the rotated boxes
    box1_vertices = calculate_rectangle_corners(bbox1[0], bbox1[1], bbox1[2], bbox1[3], bbox1[4])
    box2_vertices = calculate_rectangle_corners(bbox2[0], bbox2[1], bbox2[2], bbox2[3], bbox2[4])

    # Create polygons from vertices
    poly1 = Polygon(box1_vertices)
    poly2 = Polygon(box2_vertices)

    # Calculate intersection and union
    intersection_area = poly1.intersection(poly2).area
    union_area = poly1.union(poly2).area + epsilon

    # Calculate IoU
    iou = intersection_area / union_area
    return iou


def calc_iou_distance(item1, mask1, item2, mask2, mask_invalid_val):
    """
    Compute the iou distance (1 - iou) between two bbox tensor.

    Args:
        item1: [..., 5] single item features, last dimension is [center_x, center_y, x_length, y_length, angle]
        mask1: [...] mask
    """
    # only calc distance of valid entries
    both_valid = np.logical_and(mask1 != mask_invalid_val, mask2 != mask_invalid_val)

    # compute the iou distance between corresponding bbox
    iou = np.array([calc_iou(b1, b2) for b1, b2 in zip(item1[both_valid], item2[both_valid])])
    mean_iou = np.mean(iou) if iou.size != 0 else 0
    mean_distance = 1 - mean_iou

    return mean_distance


def match_items(
    item1: np.ndarray,
    mask1: np.ndarray,
    item2: np.ndarray,
    mask2: np.ndarray,
    mask_invalid_val,
    distance_type="euclidean_distance",
):
    """Hungarian algorithm match.

    Args:
        item1: [A1, ..., 2]
        mask1: [A1, ...]
        item2: [A2, ..., 2]
        mask2: [A2, ...]
        mask_invalid_val: value that indicates invalid
    """
    # np.set_printoptions(linewidth=500, edgeitems=8, suppress=True)

    distance_func = None
    if distance_type == "euclidean_distance":
        distance_func = calc_euclidean_distance
    elif distance_type == "iou":
        distance_func = calc_iou_distance
        assert (
            item2.shape[-1] == 5 and item1.shape[-1] == 5
        ), "items' last dim must be 5 (cx, cy, lx, ly, angle) for iou match."
    elif distance_type == "dtw":
        distance_func = calc_dtw_distance
    else:
        raise NotImplementedError("distance_type {} not in [euclidean_distance, iou, dtw]", distance_type)

    mask_dim_list = np.arange(len(mask1.shape))  # [0, 1, 2, ...]
    sum_dim_list = mask_dim_list[1:]  # [1, 2, ...]

    # get valid items
    valid_idx1 = (
        (mask1 != mask_invalid_val)
        if len(mask1.shape) == 1
        else (mask1 != mask_invalid_val).sum(axis=tuple(sum_dim_list)) != 0
    )
    origin_idx1 = np.arange(mask1.shape[0])
    item1 = item1[valid_idx1]
    mask1 = mask1[valid_idx1]
    origin_idx1 = origin_idx1[valid_idx1]

    valid_idx2 = (
        (mask2 != mask_invalid_val)
        if len(mask2.shape) == 1
        else (mask2 != mask_invalid_val).sum(axis=tuple(sum_dim_list)) != 0
    )
    origin_idx2 = np.arange(mask2.shape[0])
    item2 = item2[valid_idx2]
    mask2 = mask2[valid_idx2]
    origin_idx2 = origin_idx2[valid_idx2]

    item1_num = item1.shape[0]
    item2_num = item2.shape[0]
    dist_matrix = np.zeros((item1_num, item2_num)) + np.inf

    for i in np.arange(item1_num):
        for j in np.arange(item2_num):
            dist_matrix[i, j] = distance_func(item1[i], mask1[i], item2[j], mask2[j], mask_invalid_val)

    # hungarian match
    row_ind, col_ind = linear_sum_assignment(dist_matrix)  # row indices is sorted
    match_score = dist_matrix[row_ind, col_ind]
    return match_score, (origin_idx1[row_ind], origin_idx2[col_ind])


def calc_mse(item1: np.ndarray, mask1: np.ndarray, item2: np.ndarray, mask2: np.ndarray, mask_invalid_val):
    """
    Compute the mse between two items.

    Args:
        item1: [A, ..., d] single item features
        mask1: [A, ...] mask
        item2: [A, ..., d] single item features
        mask2: [A, ...] mask
    """
    assert item1.shape == item2.shape, "item1 and item2 must have the same shape"

    # compute the mse between corresponding points
    mse = calc_euclidean_distance(item1, mask1, item2, mask2, mask_invalid_val)
    return mse
