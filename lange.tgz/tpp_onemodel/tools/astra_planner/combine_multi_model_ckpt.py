# -*- coding: utf-8 -*-
# flake8: noqa
# type: ignore
import argparse
import copy
import os
import random

import numpy as np
import torch
from torchpilot.utils.cfg_parser import PyConfig
from torchpilot.utils.checkpoint_manager import CheckpointManager
from torchpilot.utils.constants import Backend
from torchpilot.utils.dist_manager import get_master_hostname
from torchpilot.utils.dist_manager import mpi_broadcast_obj
from torchpilot.utils.dist_manager import mpi_get_global_rank
from torchpilot.utils.dist_manager import mpi_get_world_size
from torchpilot.utils.plus_manager import load_plus
from torchpilot.utils.registries import TASK_FLOW
from torchpilot.utils.registries import TASK_MODEL
from torchpilot.utils.settings import settings

from tpp_onemodel.tools.astra_planner.model_infer_viz import torch_fix_precision


def build_model(cfg, checkpoint_path=None, train_mode=False):
    """Build model."""
    torch_fix_precision()
    if checkpoint_path is not None:
        cfg.task_flow.task_model_cfg["checkpoint"] = checkpoint_path
        cfg.infer_task_flow.task_model_cfg["checkpoint"] = checkpoint_path
    os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    if train_mode:
        train_task_flow_cfg = cfg.task_flow
        planner_train_task_flow = TASK_FLOW.build(train_task_flow_cfg)
        # planner_train_task_flow = planner_train_task_flow.cuda()
        planner_train_task_flow.eval()
        return planner_train_task_flow
    else:
        task_cfg = cfg.infer_task_flow.task_model_cfg
        planner_infer_pipeline = TASK_MODEL.build(task_cfg)
        # planner_infer_pipeline = planner_infer_pipeline.cuda()
        planner_infer_pipeline = planner_infer_pipeline.eval()
        # planner_infer_pipeline.infer_forward = planner_infer_pipeline.trace_forward
        return planner_infer_pipeline


def init_dist():
    port = mpi_broadcast_obj(random.SystemRandom().randint(1024, 65535))
    master_hostname = get_master_hostname()
    init_method = f"tcp://{master_hostname}:{port}"
    master_hostname = get_master_hostname()
    global_rank = mpi_get_global_rank()
    world_size = mpi_get_world_size()
    settings.backend = Backend.NCCL

    try:
        torch.distributed.init_process_group(
            backend=settings.backend.value,
            init_method=init_method,
            world_size=world_size,
            rank=global_rank,
        )
    except Exception as ex:  # pylint: disable=broad-except
        logger.exception("Failed to init process group with mpi.")
        raise ex


def load_partial_checkpoint(all_model, ckpt_path, ckpt_type):
    """
    Load a checkpoint and override the corresponding parameters in all_model.
    Parameters:
        all_model: The model that has been constructed and wrapped for distributed training.
        ckpt_path: The file path of the checkpoint for this type.
        ckpt_type: A string that identifies the checkpoint type (e.g., "goal_point", "planner", "prediction").
    """
    print(f"Loading {ckpt_type} checkpoint from {ckpt_path} ...")
    ckpt = torch.load(ckpt_path, map_location=torch.device("cpu"))
    ckpt_state_dict = ckpt["model"]
    # For debugging purposes, compare the keys in the checkpoint with the keys in all_model
    model_state_dict = all_model.state_dict()
    ckpt_keys = set(ckpt_state_dict.keys())
    model_keys = set(model_state_dict.keys())
    missing_keys = model_keys - ckpt_keys
    unexpected_keys = ckpt_keys - model_keys
    restored_keys = ckpt_keys & model_keys
    print(
        f"[{ckpt_type}] Restored keys: {len(restored_keys)}, "
        f"Missing keys: {len(missing_keys)}, "
        f"Unexpected keys: {len(unexpected_keys)}"
    )
    # Load using non-strict mode (only override the parameters that exist in the checkpoint)
    all_model.load_state_dict(ckpt_state_dict, strict=False)


def main(args):
    """Combine checkpoints from multiple sources."""
    init_dist()

    # 1. Read the overall model configuration and build the model
    cfg_all_model = PyConfig.fromfile(args.cfg_planner)
    # cfg_all_model.ENGINE_TASKS = ["astra_planner", "prediction", "goal_point_planner"]
    cfg_goal_point = copy.deepcopy(cfg_all_model)
    cfg_goal_point.ENABLE_TASKS = ["goal_point_planner"]

    all_model = build_model(cfg_all_model, args.checkpoint_path_all, train_mode=True)
    cur_device = torch.cuda.current_device()
    all_model = all_model.cuda(device=cur_device)
    all_model = torch.nn.parallel.DistributedDataParallel(
        module=all_model,
        device_ids=[cur_device],
        # output_device=cur_device,
        broadcast_buffers=True,
        find_unused_parameters=False,
    )

    # 2. Sequentially load each checkpoint based on user input, overriding the corresponding model parameters
    if args.checkpoint_path_planner:
        load_partial_checkpoint(all_model, args.checkpoint_path_planner, "planner")
    if args.checkpoint_path_goal_point:
        load_partial_checkpoint(all_model, args.checkpoint_path_goal_point, "goal_point")
    if args.checkpoint_path_prediction:
        load_partial_checkpoint(all_model, args.checkpoint_path_prediction, "prediction")

    # 3. Save the new combined checkpoint
    ckpt_cfg = dict(
        pretrain_model=None,
        ckpt2model_json=None,
        to_cuda=False,
        enable_load_optimizer=False,
        enable_load_lr_scheduler=False,
    )
    save_dir = args.result_dir
    os.makedirs(save_dir, exist_ok=True)
    ckpt_cfg.update(
        dict(
            model=all_model,
            optimizer=None,
            lr_scheduler=None,
            scaler=None,
            save_dir=save_dir,
            resume=False,
            fsdp=False,
        )
    )
    ckpt_manager = CheckpointManager(**ckpt_cfg)
    ckpt_manager.save_checkpoint(
        epoch=999,
        step=0,
    )


if __name__ == "__main__":
    load_plus()

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-c",
        "--cfg_planner",
        type=str,
        default="experiments/task_planner/exp_planner_release/cfg_planner.py",
        required=False,
        help="planner_cfg",
    )
    parser.add_argument("--result_dir", type=str, required=False, default="./combined_ckpt")
    parser.add_argument(
        "--checkpoint_path_all",
        type=str,
        required=False,
        default="/home/mccree.zhao/project/offline/2024/melange_all/2025_02/melange_0210_v2/combined_ckpt/checkpoint_last.pth.tar",
        help="Path to the checkpoint used to initialize the complete model.",
    )
    parser.add_argument(
        "--checkpoint_path_goal_point",
        type=str,
        required=False,
        default="/home/mccree.zhao/torchpilot_outputs/task_planner/exp_debug/debug/ckpt/checkpoint_last.pth.tar",
        help="Path to the checkpoint used to override the goal_point part of the model.",
    )
    parser.add_argument(
        "--checkpoint_path_planner",
        type=str,
        required=False,
        default="/share-global/nell.dong/release/planner/release_20250211_beta1/torchpilot_outputs/task_planner/exp_planner_release/exp_planner_release_20250211_beta1_192866a2/ckpt/checkpoint_last.pth.tar",
        help="Path to the checkpoint used to override the planner part of the model.",
    )
    parser.add_argument(
        "--checkpoint_path_prediction",
        type=str,
        required=False,
        default=None,
        help="Path to the checkpoint used to override the prediction part of the model.",
    )
    args = parser.parse_args()
    main(args)
