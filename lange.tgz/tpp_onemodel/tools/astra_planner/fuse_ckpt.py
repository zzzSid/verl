# -*- coding: utf-8 -*-
"""Fuse checkpoint from multiple models."""
import argparse
from collections import OrderedDict
from pathlib import Path
from typing import Dict
from typing import Set

import torch


def parse_args():
    """Parse args."""
    parser = argparse.ArgumentParser("Fuse new model checkpoint on base model.")
    parser.add_argument("new_ckpt", type=Path, help="New checkpoint path.")
    parser.add_argument("base_ckpt", type=Path, help="Base checkpoint path.")
    parser.add_argument(
        "--priority",
        type=str,
        default="new",
        choices=["new", "base"],
        help="Priority of same name weight in new ckpt or base ckpt.",
    )
    parser.add_argument(
        "--save-path", type=Path, default="./tmp", help="Save path of fused ckpt, can be a directory or a file path"
    )
    return parser.parse_args()


def get_module_name(ckpt: Dict) -> Set[str]:
    """Get module name of ckpt."""
    all_keys = list(ckpt.keys())
    fitered_keys = [k.replace("module.", "").replace("_task_model.", "") for k in all_keys]
    module_names = {k.split(".")[0] for k in fitered_keys}
    return module_names


def copy_weights(ckpt, fused_ckpt, exclude_modules=[]):
    """Copy weights into fused_ckpt."""
    for k, v in ckpt.items():
        # skip copy weights from exclude modules
        if len(exclude_modules) > 0 and any([module_name in k.split(".") for module_name in exclude_modules]):
            continue
        # copy weights
        fused_ckpt[k] = v
    return fused_ckpt


def fuse_ckpt(new_ckpt, base_ckpt, priority="new"):
    """Fuse new ckpt weights into base ckpt."""
    # init fused ckpt, copy data except for model weights.
    fused_ckpt = OrderedDict()
    for k, v in new_ckpt.items():
        if k != "model":
            fused_ckpt[k] = v
        else:
            fused_ckpt[k] = OrderedDict()

    if priority == "new":
        base_exclude_modules = get_module_name(new_ckpt["model"])
        new_exclude_modules = []
    else:
        base_exclude_modules = []
        new_exclude_modules = get_module_name(base_ckpt["model"])

    # copy base ckpt weights
    copy_weights(base_ckpt["model"], fused_ckpt["model"], exclude_modules=base_exclude_modules)
    copy_weights(new_ckpt["model"], fused_ckpt["model"], exclude_modules=new_exclude_modules)

    return fused_ckpt


if __name__ == "__main__":
    args = parse_args()

    # load
    print("loading ckpt.")  # noqa: T201
    new_ckpt = torch.load(args.new_ckpt)
    base_ckpt = torch.load(args.base_ckpt)

    # fuse
    print(f"fusing ckpt {args.new_ckpt} into {args.base_ckpt}.")  # noqa: T201
    fused_ckpt = fuse_ckpt(new_ckpt, base_ckpt, args.priority)

    # save
    if args.save_path.is_dir():
        save_path = args.save_path / "fused_ckpt.pth.tar"
    else:
        save_path = args.save_path
    save_path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(fused_ckpt, save_path)
    print(f"fused ckpt saved to {save_path}")  # noqa: T201
