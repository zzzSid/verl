# -*- coding: utf-8 -*-
# flake8: noqa
# type: ignore
import argparse
import os
import os.path as osp
import time

# from typing import List
# from typing import Tuple
from typing import Any
from typing import Dict

import input_output_viz as viz  # noqa: I900
import matplotlib.pyplot as plt
import numpy as np
import torch
import torchpilot
from matplotlib.lines import Line2D
from torchpilot.utils.cfg_parser import PyConfig
from torchpilot.utils.plus_manager import load_plus
from torchpilot.utils.registries import DATALOADER
from torchpilot.utils.registries import TASK_FLOW
from torchpilot.utils.registries import TASK_MODEL
from tqdm import tqdm

from tpp_onemodel.tools.astra_planner.data.txt_to_pkl_utils import txt_to_pkl


# from tpp_onemodel.tools.astra_planner.trace_keys import INPUT_TEMPORAL_KEYS
# from tpp_onemodel.tools.astra_planner.trace_keys import TRACE_INPUT_KEYS


logger = torchpilot.logger

DTYPE = np.float32
DEVICE = torch.device("cuda")
np.set_printoptions(precision=2, suppress=True)


def select_sample_by_ts(planner_cfg, ts_ms, target_dataset_dir: str):
    """Select the clip frame sample by given micro-seconds timetamp."""
    data_cfg = planner_cfg.infer_dataloader
    data_cfg.num_workers = 8
    data_cfg.sampler_cfg.shuffle = False
    data_cfg.prefetch_factor = 2
    data_cfg.batch_size = 32
    # data_cfg.dataset_cfg.debug = True
    if target_dataset_dir != "":
        pkl_path_list = txt_to_pkl([target_dataset_dir])
        data_cfg.dataset_cfg.datasets_cfg.astra_planner.meta_file.astra_planner.test = pkl_path_list

    sample_list = []
    if type(ts_ms) is not list:
        ts_ms = [ts_ms]

    data_loader = DATALOADER.build(data_cfg)
    if True:
        for sample in tqdm(data_loader):
            sample = sample["astra_planner"]
            timestamp_list = sample["timestamp"]
            for index, timestamp in enumerate(timestamp_list):
                cur_ms = int(timestamp[-1] * 1000)
                for ts in ts_ms:
                    if abs(cur_ms - ts) < 99:
                        print("time_diff: {} ms".format(cur_ms - ts))
                        tmp_sample = {key: sample[key][index : index + 1] for key in sample.keys()}
                        tmp_sample["task_name"] = "astra_planner"
                        sample_list.append([tmp_sample, ts])
                        # return {key: sample[key] for key in TRACE_INPUT_KEYS}
                    else:
                        print("curr_time: {} ms".format(cur_ms))
                        print("ts    : {} ms".format(ts))
                        print("time_diff: {} ms".format(cur_ms - ts))
    if hasattr(data_loader, "_iterator") and data_loader._iterator is not None:
        data_loader._iterator._shutdown_workers()
    torch.distributed.destroy_process_group()
    del data_loader
    if len(sample_list) > 0:
        return sample_list
    else:
        logger.warning("Can't find the sample near given timestamp")
        return None


def torch_fix_precision():
    """Set torch fix_precision for determinsim."""
    torch.backends.cudnn.enabled = False
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    torch.manual_seed(0)
    torch.cuda.manual_seed(0)
    torch.cuda.manual_seed_all(0)
    # torch.use_deterministic_algorithms(True, warn_only=True)


def build_model(cfg, checkpoint_path=None, train_mode=False):
    """Build model."""
    # cfg = PyConfig.fromfile("experiments/task_planner/exp_debug/cfg_debug.py")
    torch_fix_precision()
    if checkpoint_path is not None:
        cfg.task_flow.task_model_cfg["checkpoint"] = checkpoint_path
        cfg.infer_task_flow.task_model_cfg["checkpoint"] = checkpoint_path
    os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    if train_mode:
        train_task_flow_cfg = cfg.task_flow
        planner_train_task_flow = TASK_FLOW.build(train_task_flow_cfg)
        planner_train_task_flow = planner_train_task_flow.cuda()
        planner_train_task_flow.eval()
        return planner_train_task_flow
    else:
        task_cfg = cfg.infer_task_flow.task_model_cfg
        planner_infer_pipeline = TASK_MODEL.build(task_cfg)
        planner_infer_pipeline = planner_infer_pipeline.cuda()
        planner_infer_pipeline = planner_infer_pipeline.eval()
        # planner_infer_pipeline.infer_forward = planner_infer_pipeline.trace_forward
        return planner_infer_pipeline


def plot_single_source(data, output_data, loss, ax, plot_keys, plot_settings, source_name):
    """Plot single source."""
    table_data = []
    for key in plot_keys:
        label = f"{key}_{source_name}"
        settings = {}
        if key in plot_settings:
            settings = plot_settings[key]

        if key == "egos":
            # current box
            egos = output_data["transformed_input"]["egos"]  # [B,T,1,D]
            # egos_pred_gt = output_data["transformed_input"]["egos_pred_gt"]  # [B,A,T,2]
            if "trans_in_loop" in output_data:
                egos_pred_gt = output_data["trans_in_loop"]["egos_pred_gt"]  # [B,A,T,2]
            else:
                egos_pred_gt = output_data["transformed_input"]["egos_pred_gt"]  # [B,A,T,2]

            want_feat_idx = [0, 1, 3, 4, 6]  # x,y,l,w,heading
            boxes_np = egos[0, -1][:, want_feat_idx]  # [1, 5]
            masks_np = data["egos_padding_mask"].numpy()[0, -1]  # [1, ]
            viz.plot_rectangles(boxes_np, masks_np, ax, label=label, mask_valid_val=0, **(settings["curr_box"]))
            # history
            viz.plot_agent_traj(
                # data["egos"].numpy()[0, :, :, :3],  # x, y, z
                egos[0].transpose((1, 0, 2)),  # [T,A,2]
                ax,
                label=f"{key}_hist_{source_name}",
                **(settings["hist"]),
            )

            viz.plot_traj_with_num(
                # data["egos"].numpy()[0, :, :, :3],  # x, y, z
                # egos_pred_gt[0].transpose((1, 0, 2)),  # [T,A,2]
                egos_pred_gt[0],  # [A,T,2]
                ax,
                label=f"{key}_fut_{source_name}",
                color="yellow",
                point_size=20,
            )

            # prediction
            if "predicton_pred_output" in output_data:
                marginal_output = output_data["planner_pred_output"][-1]["marginal_output"]
            else:
                marginal_output = output_data["marginal_output"]

            ego_pred_score = marginal_output["ego_pred_score"].squeeze(1)  # [B,M]
            batch_size, mod_num = ego_pred_score.shape[0], ego_pred_score.shape[1]
            ego_pred_pos = marginal_output["ego_pred_pos"].squeeze(1).reshape(batch_size, mod_num, -1, 2)  # [B,M,T,2]

            # Sort ego_pred_score and ego_pred_pos based on ego_pred_score
            sorted_indices = np.argsort(ego_pred_score, axis=1)[:, ::-1]

            # previous
            sorted_ego_pred_pos = ego_pred_pos[
                np.arange(ego_pred_pos.shape[0])[:, None, None], sorted_indices
            ]  # [B,M,T,2]

            viz.plot_traj_with_num(
                # data["egos"].numpy()[0, :, :, :3],  # x, y, z
                sorted_ego_pred_pos[0, :, 0],  # [1,T,2]
                ax,
                label=f"{key}_pred_{source_name}_top1",
                color="red",
                point_size=20,
            )

            # # 只展示 top1 对应的NavLane的 三条多模态轨迹
            # top1_idx = sorted_indices[0, 0]
            # top1_nav = top1_idx // 3
            # top1_nav_indices = [top1_nav * 3, top1_nav * 3 + 1, top1_nav * 3 + 2]
            # ego_pred_score_top1_nav = ego_pred_score[:, top1_nav_indices]
            # ego_pred_pos_top1_nav = ego_pred_pos[:, top1_nav_indices]
            # sorted_indices_top1_nav = np.argsort(ego_pred_score_top1_nav, axis=1)[:, ::-1]
            # # matplotlib 画图时，新增表格
            # table_data.append(["top1_nav", top1_nav])
            # table_data.append(["top1_nav_indices", top1_nav_indices])
            # table_data.append(["ego_pred_score_top1_nav", ego_pred_score_top1_nav[0, :]])
            # table_data.append(["sorted_indices_top1_nav", sorted_indices_top1_nav[0, :]])

            # # sorted_ego_pred_score = ego_pred_score[np.arange(ego_pred_score.shape[0])[:, None], sorted_indices]  # [B,M]
            # sorted_ego_pred_pos = ego_pred_pos_top1_nav[
            #     np.arange(ego_pred_pos.shape[0])[:, None], sorted_indices_top1_nav
            # ]  # [B,M,T,2]

            # viz.plot_traj_with_num(
            #     # data["egos"].numpy()[0, :, :, :3],  # x, y, z
            #     sorted_ego_pred_pos[0, 0:1, :, :],  # [1,T,2]
            #     ax,
            #     label=f"{key}_pred_{source_name}_top1",
            #     color="red",
            #     point_size=20,
            # )
            # # # top2 浅灰色
            # # settings_tmp = settings["pred"].copy()
            # # settings_tmp["edgecolors"] = "lightgrey"
            # # viz.plot_agent_traj(
            # #     # data["egos"].numpy()[0, :, :, :3],  # x, y, z
            # #     sorted_ego_pred_pos[0, 1:2, :, :],  # [1,T,2]
            # #     ax,
            # #     label=f"{key}_pred_{source_name}_top2",
            # #     **(settings_tmp),
            # # )
            # # # top2 深灰色
            # # settings_tmp["edgecolors"] = "grey"
            # # viz.plot_agent_traj(
            # #     # data["egos"].numpy()[0, :, :, :3],  # x, y, z
            # #     sorted_ego_pred_pos[0, 2:3, :, :],  # [1,T,2]
            # #     ax,
            # #     label=f"{key}_pred_{source_name}_top3",
            # #     **(settings_tmp),
            # # )

        elif key == "bboxes":
            # current box
            if "trans_in_loop" in output_data:
                bboxes = output_data["trans_in_loop"]["bboxes"]
                bboxes_pred_gt = output_data["trans_in_loop"]["bboxes_pred_gt"]
            else:
                bboxes = output_data["transformed_input"]["bboxes"]
                bboxes_pred_gt = output_data["transformed_input"]["bboxes_pred_gt"]
            want_feat_idx = [0, 1, 3, 4, 6]  # x,y,l,w,heading
            boxes_np = bboxes[0, -1][:, want_feat_idx]  # [A, 5]
            masks_np = data["bboxes_padding_mask"][0, -1]  # [A, ]
            viz.plot_rectangles(boxes_np, masks_np, ax, label=label, mask_valid_val=0, **(settings["curr_box"]))
            # history
            viz.plot_agent_traj(
                # data["egos"].numpy()[0, :, :, :3],  # x, y, z
                bboxes[0].transpose((1, 0, 2)),  # [T,A,2]
                ax,
                label=f"{key}_hist_{source_name}",
                **(settings["hist"]),
            )
            # future
            viz.plot_agent_traj(
                # data["egos"].numpy()[0, :, :, :3],  # x, y, z
                bboxes_pred_gt[0],  # [A,T,2]
                ax,
                label=f"{key}_fut_{source_name}",
                **(settings["fut"]),
            )

            # prediction
            if "predicton_pred_output" in output_data.keys():
                marginal_output = output_data["predicton_pred_output"][-1]["marginal_output"]
            else:
                marginal_output = output_data["marginal_output"]
            agent_pred_pos = marginal_output["agent_pred_pos"]  # [B,A,M,T*2]
            batch_size, agent_num, mod_num, _ = agent_pred_pos.shape
            agent_pred_pos = agent_pred_pos.reshape(batch_size, agent_num, mod_num, -1, 2)  # [B,A,M,T,2]
            agent_pred_score = marginal_output["agent_pred_score"]  # [B,A,M]

            # Sort agent_pred_score and agent_pred_pos based on agent_pred_score
            sorted_indices = np.argsort(agent_pred_score, axis=2)[:, :, ::-1]  # [B, A, M]
            # sorted_agent_pred_score = np.take_along_axis(agent_pred_score, sorted_indices, axis=2)  # [B, A, M]

            sorted_agent_pred_pos = np.take_along_axis(
                agent_pred_pos, sorted_indices[:, :, :, None, None], axis=2
            )  # [B, A, M, T, 2]

            if agent_pred_pos.shape[1] == output_data["transformed_input"]["bboxes_padding_mask"].shape[2]:
                masks_np_selected = output_data["transformed_input"]["bboxes_padding_mask"][0, -1]  # [A, ]
            else:
                masks_np_selected = masks_np.numpy()

            # if sorted_agent_pred_pos.shape[1] == masks_np_selected.shape[0]:
            #     sorted_agent_pred_pos = sorted_agent_pred_pos[0, :, 0] * (1 - masks_np_selected[:, None, None])
            # else:
            #     sorted_agent_pred_pos = sorted_agent_pred_pos[0, :, 0] * (
            #         1 - output_data["transformed_input"]["bboxes_padding_mask"][0, -1][:, None, None]
            #     )
            sorted_agent_pred_pos = sorted_agent_pred_pos[0, :, 0] * (1 - masks_np_selected[:, None, None])

            viz.plot_traj_with_num(
                # data["egos"].numpy()[0, :, :, :3],  # x, y, z
                sorted_agent_pred_pos,  # [A,T,2]
                ax,
                label=f"{key}_pred_{source_name}",
                color="blue",
                point_size=10,
                linewidth=5,
            )

            ax.legend(loc="upper left")

        elif key == "sod_poly_boxes":
            want_feat_idx = [0, 1, 3, 4, 6]  # x,y,l,w,heading
            if "trans_in_loop" in output_data:
                boxes_np = output_data["trans_in_loop"]["sod_poly_boxes"][0][:, want_feat_idx]
                masks_np = output_data["trans_in_loop"]["sod_poly_boxes_padding_mask"][0]
            else:
                boxes_np = data["sod_poly_boxes"].numpy()[0][:, want_feat_idx]
                masks_np = data["sod_poly_boxes_padding_mask"].numpy()[0]
            viz.plot_rectangles(boxes_np, masks_np, ax, label=label, mask_valid_val=0, **settings)

        elif key == "sod_poly_pts":
            if "trans_in_loop" in output_data:
                sod_poly_pts = output_data["trans_in_loop"]["sod_poly_pts"][0]
                sod_poly_pts_padding_mask = output_data["trans_in_loop"]["sod_poly_pts_padding_mask"][0]
            else:
                sod_poly_pts = data["sod_poly_pts"].numpy()[0]
                sod_poly_pts_padding_mask = data["sod_poly_pts_padding_mask"].numpy()[0]
            viz.plot_lines(
                sod_poly_pts,
                sod_poly_pts_padding_mask,
                ax,
                label=label,
                type_invalid_val=1,
                **settings,
            )

        elif key == "atlas":
            atlas = data["atlas"].numpy()[0]  # [50,30,3]
            if "trans_in_loop" in output_data:
                atlas_data = output_data["trans_in_loop"]["atlas"][0, :, :, :2]
            else:
                atlas_data = output_data["transformed_input"]["atlas"][0, :, :, :2]
            atlas_type = atlas[:, :, -1]
            atlas_type[atlas_type == 0] = -1

            viz.plot_lines(atlas_data, atlas_type, ax, label=label, type_invalid_val=-1, **settings)

        elif key == "lane_points":
            lane_points = (
                output_data["trans_in_loop"]["lane_points"]
                if "trans_in_loop" in output_data
                else output_data["transformed_input"]["lane_points"]
            )
            viz.plot_lines(
                lane_points[0],
                data["lane_types"].numpy()[0],
                ax,
                label=label,
                type_invalid_val=-1,
                **settings,
            )

        elif key == "god_poly_pts":
            if "trans_in_loop" in output_data:
                god_poly_pts = output_data["trans_in_loop"]["god_poly_pts"]
                god_poly_pts_padding = output_data["trans_in_loop"]["god_poly_pts_padding_mask"]
            else:
                god_poly_pts = data["god_poly_pts"].numpy()[0]
                god_poly_pts_padding = data["god_poly_pts_padding_mask"].numpy()[0]
            viz.plot_polygons(
                god_poly_pts,
                god_poly_pts_padding,
                ax,
                label=label,
                **settings,
            )

        elif key == "navi_path_points":
            # previous
            viz.plot_lines(
                output_data["transformed_input"]["navi_path_points"][0],
                data["navi_path_types"].numpy()[0],
                ax,
                label=label,
                type_invalid_val=-1,
                # alpha=0.5,
                **settings,
            )

        elif key == "sdmap_polylines":
            if source_name == "py":
                continue
            viz.plot_lines(
                data["sdmap_polylines"].numpy()[0],
                data["sdmap_polylines_type"].numpy()[0],
                ax,
                label=label,
                type_invalid_val=-1,
                **settings,
            )
    if loss is not None:
        loss_legend = [
            Line2D([0], [0], color="none", label=f"{loss_name}: {round(loss_value,3)}")
            for loss_name, loss_value in loss.items()
        ]
        handles, labels = ax.get_legend_handles_labels()
        loss_legend_ax = ax.legend(handles=loss_legend, loc="upper right", title="Losses")
        ax.add_artist(loss_legend_ax)
    # table = ax.table(cellText=table_data, loc="lower left", cellLoc="center", colWidths=[0.1] * len(table_data[0]))
    # table.auto_set_font_size(False)
    # table.set_fontsize(10)
    # table.scale(1, 1.5)


def init_plot_settings():
    """The input and ouput keys need to align with the deploy version sequentially. # noqa

    Currently tested on 0823 version: https://nio.feishu.cn/wiki/XXGVwOMa5iO8oAk4sThcOAeJnGh
    """
    """
    Plotting Target keys:
    """
    plot_keys = [
        "bboxes",
        "bboxes_padding_mask",
        "egos",
        "egos_padding_mask",
        "lane_points",
        "lane_types",
        "sod_poly_boxes",
        "sod_poly_boxes_padding_mask",
        "sod_poly_pts",
        "sod_poly_pts_padding_mask",
        "atlas",
        # "sdmap_polylines",
        # "sdmap_polylines_type",
        "global_routing_mask",
        "hist2curr_trans",
        "delta_timestamp",
        "navi_path_points",
        "navi_line_types",
        "god_poly_pts",
        "god_poly_pts_padding_mask",
        "god_attrs",
        "god_attr_padding_mask",
    ]

    """
    Plotting COLOR-CODE:
    different color to distinguish among input types,
    different shade of a color to distinguish bwtween cpp and python, cpp is lighter, python is darker
    """
    py_plot_settings = {
        "bboxes": {
            "curr_box": {
                "color": "teal",
                "fill": False,
                "lw": 1.0,
                "zorder": 100,
            },
            "hist": {
                "edgecolors": "teal",
                "facecolors": "none",
                "marker": ".",
                "zorder": 90,
                "s": 1,
            },
            "fut": {
                "edgecolors": "lime",
                "facecolors": "none",
                "marker": ".",
                "zorder": 10,
                "s": 2,
            },
            "pred": {
                "edgecolors": "deepskyblue",
                "facecolors": "none",
                "marker": ".",
                "zorder": 90,
                "s": 2,
            },
        },
        "egos": {
            "curr_box": {
                "color": "darkviolet",
                "fill": False,
                "lw": 1.0,
                "zorder": 100,
            },
            "hist": {
                "edgecolors": "darkviolet",
                "facecolors": "none",
                "marker": ".",
                "zorder": 90,
                "s": 5,
            },
            "fut": {
                # "edgecolors": "violet",
                # "facecolors": "none",
                # "marker": "4",
                # "zorder": 90,
                # "s": 2,
                "edgecolors": "violet",
                "facecolors": "none",
                "marker": ".",
                "zorder": 90,
                "s": 15,
            },
            "pred": {
                "edgecolors": "red",
                "facecolors": "none",
                "marker": ".",
                "zorder": 100,
                "s": 20,
            },
        },
        "sod_poly_boxes": {"fill": False, "lw": 0.3, "color": "darkorange", "zorder": 100},
        "sod_poly_pts": {
            "marker": "v",
            "linestyle": "-",
            "color": "darkolivegreen",
            "fillstyle": "none",
            "markersize": 1,
        },
        "atlas": {
            "marker": "1",
            "linestyle": "-",
            "color": "navy",
            "fillstyle": "none",
            "markersize": 3,
        },
        "lane_points": {
            "marker": "x",
            "linestyle": "-",
            "color": "dimgrey",
            "fillstyle": "none",
            "markersize": 3,
        },
        "god_poly_pts": {"fill": False, "lw": 0.3, "color": "red", "zorder": 100},
        "navi_path_points": {
            "marker": "x",
            "linestyle": "-",
            "color": "darkkhaki",
            "fillstyle": "none",
            "markersize": 5,
            "zorder": 70,
        },
        "sdmap_polylines": {
            "marker": "o",
            "linestyle": "-",
            "color": "red",
            "fillstyle": "none",
        },
    }
    return plot_keys, py_plot_settings


def init_ax(ts, clip_id, py_source_exist):
    """Init ax."""
    # plot single source
    fig, ax = plt.subplots(figsize=(30, 15), dpi=400)
    if py_source_exist:
        ax.set_title("clip_id: " + clip_id + " || ts: " + str(ts))

    ax.scatter([0], [0], color="red")
    ax.set_aspect("equal")
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.grid(True)

    ax_cpp = ax
    ax_py = ax
    return fig, ax_py, ax_cpp


def recursive_cpu_conversion(data):
    """Recursively convert data to cpu."""
    if isinstance(data, dict):
        return {key: recursive_cpu_conversion(value) for key, value in data.items()}
    elif isinstance(data, list):
        return [recursive_cpu_conversion(item) for item in data]
    elif isinstance(data, torch.Tensor):
        return data.cpu().detach().numpy()
    else:
        return data


def main(args):
    """Infer and viz."""
    torch.distributed.init_process_group(
        backend="nccl",
        init_method="tcp://localhost:9999",
        world_size=1,
        rank=0,
    )
    # Configs ---

    py_source_exist = True if args.cfg_planner else False

    if not os.path.exists(args.result_dir):
        os.mkdir(args.result_dir)

    ts_ms = args.ts

    torch.set_printoptions(linewidth=500, edgeitems=8, profile="default", sci_mode=False)
    np.set_printoptions(linewidth=500, edgeitems=8, suppress=True)

    # Fig setting ---

    plot_keys, py_plot_settings = init_plot_settings()

    # Load and plot data ---
    file_name = ""

    py_data_in: Dict[Any, Any] = dict()
    if py_source_exist:
        # Load pkl data and plot
        cfg = PyConfig.fromfile(args.cfg_planner)
        py_data_in_list = select_sample_by_ts(cfg, ts_ms, args.target_dataset_dir)
        model = build_model(cfg, args.checkpoint_path, args.train_mode)
        for py_data_in, ts in py_data_in_list:
            fig, ax_py, ax_cpp = init_ax(ts, py_data_in["subclip_ids"][0], py_source_exist)
            cuda_data_in = py_data_in.copy()
            for key, value in cuda_data_in.items():
                if isinstance(value, torch.Tensor):
                    cuda_data_in[key] = value.cuda()
            # cuda_data_in = {key: value.cuda() for key, value in py_data_in.items() if isinstance(value, torch.Tensor)}

            # planner_train_task_flow(cuda_data_in)
            if args.train_mode:
                # model = model.train()
                # model.set_mode(True)
                # output = model.train_forward(cuda_data_in)
                output, loss = model(cuda_data_in)
            else:
                output = model(cuda_data_in)
                if "pred_output" in output:
                    output = output["pred_output"]
            # py_data_output = {key: value.cpu() for key, value in output.items() if isinstance(value, torch.Tensor)}
            py_data_output = recursive_cpu_conversion(output)
            py_loss = (
                {key: value.cpu().item() for key, value in loss.items() if isinstance(value, torch.Tensor)}
                if args.train_mode
                else None
            )

            plot_single_source(
                py_data_in, py_data_output, py_loss, ax_py, plot_keys, py_plot_settings, source_name="py"
            )
            ax_py.legend(loc="upper left")
            file_name = py_data_in["subclip_ids"][0] + "_" + str(ts)

            # Save viz results ---
            timestr = time.strftime("%Y%m%d%H%M%S")
            save_dir = os.path.join(args.result_dir, py_data_in["subclip_ids"][0])
            os.makedirs(save_dir, exist_ok=True)
            save_plot_path = osp.join(save_dir, f"input_plot_{file_name}_{timestr}.jpg")
            plt.savefig(save_plot_path, bbox_inches="tight")
            print("result saved in:\n {}\n".format(save_plot_path))
            print("Viz Success!!!")


if __name__ == "__main__":
    load_plus()

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-c",
        "--cfg_planner",
        type=str,
        default="experiments/task_planner/exp_debug/cfg_debug.py",
        required=False,
        help="planner_cfg",
    )
    parser.add_argument("--cpp_dump_dir", type=str, required=False, help="cpp_dump_dir")
    parser.add_argument(
        "--ts",
        type=int,
        required=False,
        default=[
            # 1735195603973,
            # 1735195604173,
            1728809608643,
            1728809608843,
        ],
        nargs="+",
        help="Compare timestamp.",
    )
    parser.add_argument("--result_dir", type=str, required=False, default="./viz/")
    parser.add_argument("--same_plot", action="store_true", default=False)
    parser.add_argument("--compare_value", action="store_true", default=False)
    parser.add_argument(
        "--checkpoint_path",
        type=str,
        required=False,
        default="/share-global/nell.dong/release/planner/release_20250104_daily/torchpilot_outputs/task_planner/exp_planner_release/exp_planner_release_20250104_daily_f6ce5211/ckpt/checkpoint_last.pth.tar",
        help="checkpoint_path",
    )
    parser.add_argument(
        "--train_mode",
        type=bool,
        default=False,
        # default=True,
        required=False,
        help="whether use train mode to infer",
    )
    parser.add_argument(
        "--target_dataset_dir",
        type=str,
        required=False,
        # default="/home/mccree.zhao/project/offline/2024/melange_all/2024_12/melange_low_speed_1224/test_data.txt",
        default="/home/mccree.zhao/project/offline/2024/melange_all/2024_12/melange_low_speed_1224/debug_data.txt",
        help="target_dataset_dir",
    )
    args = parser.parse_args()
    main(args)
