# -*- coding: utf-8 -*-
# flake8: noqa
# type: ignore
"""Scene filters for planner dataset."""
import json
import math
import os
from collections import Counter
from collections import defaultdict

import numpy as np
from shapely.geometry import LineString

from tpp_onemodel.tools.astra_planner.data.data_filter.common_filter import (
    BaseClipProcessor,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.common_utils import get_ceph_size
from tpp_onemodel.tools.astra_planner.data.data_filter.common_utils import (
    read_bytes_from_ceph,
)
from tpp_onemodel.tools.astra_planner.data.data_utils_scripts.hand_crafted_tags.utils import (
    process_clip,
)
from tpp_onemodel.tools.astra_planner.visualization.frame_sample import (
    get_closest_navi_lane_index,
)


class WhiteListFilter(BaseClipProcessor):
    """White list filter."""

    def __init__(self, white_files: list, **kwargs):
        """Init."""
        super().__init__(**kwargs)
        self.white_files = white_files
        self.get_white_list_clips()

        self.name = "white_list_filter"
        self.reset_stats()

    def get_white_list_clips(self):
        """Get white list clips."""
        self.white_list = set()
        for path in self.white_files:
            with open(path, "r") as fin:
                lines = fin.readlines()
                lines = [line.strip() for line in lines]
                self.white_list.update(lines)

    @BaseClipProcessor.common_process(record_stats=True)
    def __call__(self, clip_sample):
        """Filter clip sample."""
        if clip_sample["clip_id"] in self.white_list:
            return clip_sample

        clip_sample["frame_sample"] = []
        return clip_sample


class BlackListFilter(BaseClipProcessor):
    """Black list filter."""

    def __init__(self, black_files: list, **kwargs):
        """Init."""
        super().__init__(**kwargs)
        self.black_files = black_files
        self.get_black_list_clips()

        self.name = "black_list_filter"
        self.reset_stats()

    def get_black_list_clips(self):
        """Get black list clips."""
        self.black_list = set()
        for path in self.black_files:
            with open(path, "r") as fin:
                lines = fin.readlines()
                lines = [line.strip() for line in lines]
                self.black_list.update(lines)

    @BaseClipProcessor.common_process(record_stats=True)
    def __call__(self, clip_sample):
        """Filter clip sample."""
        if clip_sample["clip_id"] not in self.black_list:
            return clip_sample

        clip_sample["frame_sample"] = []
        return clip_sample


class NaviYawFilter(BaseClipProcessor):
    """Navi yaw filter."""

    def __init__(self, **kwargs):
        """Init."""
        super().__init__(**kwargs)
        self.navi_gating_tag = "astra_planner.ego_state.navi.navigating_second_check"
        self.navi_yaw_tag = "astra_planner.ego_state.navi_state.navi_yaw"
        self.unknown_tag = "astra_planner.ego_state.navi_state.unknown"

        self.name = "navi_yaw_filter"
        self.reset_stats()

    @BaseClipProcessor.common_process(record_stats=True)
    def __call__(self, clip_sample):
        """Call."""
        # find the first frame with tag, if `navi_gating_tag` not in tag, drop the clip.
        clip_tag_info = clip_sample["clip_tag_info"]
        if clip_tag_info is not None and len(clip_tag_info) > 0:
            for tag in clip_tag_info.values():
                if self.navi_gating_tag in tag:
                    return clip_sample
                # if navi_yaw_tag or unknown_tag in tag, then filter.
                if self.navi_yaw_tag in tag or self.unknown_tag in tag:
                    break
        clip_sample["frame_sample"] = []
        return clip_sample


class InvalidNaviLineFilter(BaseClipProcessor):
    """Invalid navi line filter."""

    def __init__(self, invalid_navi_filters: dict, version_list=[], get_from_oceanus=False, **kwargs):
        """Init."""
        super().__init__(**kwargs)
        self.invalid_navi_filters = invalid_navi_filters
        self.version_list = version_list
        # if version_list is empty, then get from oceanus.
        self.get_from_oceanus = get_from_oceanus or len(version_list) == 0

        self.NAV_NAME = "_NAV_LANE"

        self.name = "invalid_navi_line_filter"
        self.reset_stats()

    def load_path_from_ocenas(self, clip_sample):
        """Load path from oceanus."""
        meta_path = clip_sample["meta_ceph_path"].split(" ")[0]
        base_path = meta_path.split("meta_data")[0]
        navi_path = os.path.basename(meta_path).replace(".pkl", f"{self.NAV_NAME}.json")
        navi_path = os.path.join(base_path, navi_path)

        if (size := get_ceph_size(navi_path.replace("huailai_cos:", "/"))) > 0:
            navi_path = [f"{navi_path} {size}"]
        else:
            # print(f"Cant find {self.NAV_NAME}: {navi_path}")
            navi_path = None
        return navi_path

    def get_navi_path(self, clip_sample):
        """Find valid tag path."""
        if self.get_from_oceanus:
            return self.load_path_from_ocenas(clip_sample)

        clip_id = clip_sample["clip_id"].replace(".000000", "")
        navi_path = None
        for path in self.version_list:
            tag_path = path.format(clip_id=clip_id)
            if (size := get_ceph_size(tag_path.replace("huailai_cos:", "/"))) > 0:
                navi_path = [f"{tag_path} {size}"]
                break

        # if navi_path is None:
        #     # print(f"Cant find valid navi path for clip: {clip_id}")
        #     return None
        return navi_path

    def is_valid(self, frame_info):
        """Check if frame has valid navi line."""
        for invalid_pos, invalid_sub_pos_list in self.invalid_navi_filters.items():
            for invalid_sub_pos in invalid_sub_pos_list:
                if frame_info[invalid_pos][invalid_sub_pos] == 0:
                    # print(f"Invalid navi pos ({invalid_pos}, {invalid_sub_pos})")
                    return False
        return True

    @BaseClipProcessor.common_process(record_stats=True)
    def __call__(self, clip_sample):
        """Filter invalid naviline frames."""
        if len(self.invalid_navi_filters) == 0:
            return clip_sample

        navi_path = self.get_navi_path(clip_sample)
        # If the file does not exist, then discard it directly.
        if navi_path is None:
            print(f"{self.name}: {navi_path} does not exist.")
            clip_sample["frame_sample"] = []
            return clip_sample
        # load navi info
        clip_navi_info = json.loads(read_bytes_from_ceph(navi_path)[0])[1][1]

        valid_samples = []
        for frame_sample in clip_sample["frame_sample"]:
            frame_info = clip_navi_info.get(f"{frame_sample['current'][0]['timestamp']:.6f}", [])
            if len(frame_info) == 0:
                print(f"EmptyNavi, clip={navi_path}, timestamp={frame_sample['current'][0]['timestamp']:.6f}")
                continue
                # valid_samples.append(frame_sample)
            elif self.is_valid(frame_info):
                valid_samples.append(frame_sample)

        # update clip sample
        clip_sample["frame_sample"] = valid_samples
        return clip_sample


class InvalidNaviPathFilter(InvalidNaviLineFilter):
    """Invalid navi path filter."""

    def __init__(self, invalid_navi_filters: dict, version_list=[], get_from_oceanus=False, **kwargs):
        """Init."""
        super().__init__(invalid_navi_filters, version_list, get_from_oceanus, **kwargs)
        self.NAV_NAME = "_NAV_PATH"
        self.name = "invalid_navi_path_filter"
        self.reset_stats()

    def is_valid(self, frame_info):
        # check if frame has valid navi path.
        for invalid_pos, invalid_sub_pos_list in self.invalid_navi_filters.items():
            for invalid_sub_pos in invalid_sub_pos_list:
                # filter missing -1 and invalid 0.
                if frame_info[invalid_pos][invalid_sub_pos] <= 0:
                    # print(f"{self.name}: Invalid navi pos ({invalid_pos}, {invalid_sub_pos})")
                    return False
        return True


class TLDInfoWriter(BaseClipProcessor):
    """TLD info writer."""

    def __init__(self, tld_fft_list: list, **kwargs):
        """Init."""
        super().__init__(**kwargs)
        self.tld_fft = set(tld_fft_list)

        self.name = "tld_info_writer"
        self.reset_stats()

    def get_velocity_and_acceleration(self, frame_sample):
        """Get velocity and accleration."""
        # parse meta tor get velocity and acceleration.
        # vx,vy,acc_x,acc_y,yaw[2],yaw_rate[2],whlag,whlagspd,vehspd,lgta,chassis_yawrate
        ego_motion = frame_sample["ego_motion"]
        vx, ax = ego_motion[0].item(), ego_motion[2].item()
        return vx, ax

    def get_closest_navi_line_index(self, navi_line_points):
        """Get the closest navi_lane_index, if there is no navi_lane close to the ego, return -1."""
        current_navi_line_index = -1
        closest_distance_y_list = []
        navi_num = len(navi_line_points)
        if navi_num == 0:
            return current_navi_line_index

        # ego position
        origin = np.array([0, 0])
        for navi_i in range(navi_num):
            points = navi_line_points[navi_i]
            # mask ego points and filter padding points (-1, -1)
            mask = ~(
                (points[:, 0] == 0.0) & (points[:, 1] == 0.0)
            )  # | ((points[:, 0] == -1.0) & (points[:, 1] == -1.0)))

            # Use the mask to filter out the rows
            points = points[mask]
            if len(points) == 0:
                closest_distance_y = 999999
                closest_distance_y_list.append(closest_distance_y)
                continue

            # get the closest y distance
            distances = np.linalg.norm(points - origin, axis=1)
            closest_index = np.argmin(distances)
            closest_distance_y = np.abs(points[closest_index][1])
            closest_distance_y_list.append(closest_distance_y)

        if min(closest_distance_y_list) < 2:
            current_navi_line_index = closest_distance_y_list.index(min(closest_distance_y_list))

        return current_navi_line_index

    def get_navi_path_tld_color(self, frame_sample):
        """Get tld color."""
        if "navi_path_points" not in frame_sample:
            return -1
        navi_path_points = frame_sample["navi_path_points"]
        navi_path_tld = frame_sample["navi_path_tld"]
        if len(navi_path_tld) < 1 or len(navi_path_tld[0]) < 1:
            return -1
        return navi_path_tld[0][0]

    @BaseClipProcessor.common_process(record_stats=True)
    def __call__(self, clip_sample):
        """Call."""
        if len(self.tld_fft) == 0:
            return clip_sample

        tld_info = {}
        for frame_sample in clip_sample["frame_sample"]:
            inter_ffts = self.tld_fft.intersection(set(frame_sample["current"][0]["tags"]))
            if len(inter_ffts) == 0:
                continue

            idx = frame_sample["current"][0]["index"]
            vx, ax = self.get_velocity_and_acceleration(frame_sample["current"][0])
            navi_path_tld_color = self.get_navi_path_tld_color(frame_sample["current"][0])
            tld_info[idx] = {
                "vx": vx,
                "ax": ax,
                "navi_path_tld_color": navi_path_tld_color,
                "tag": list(inter_ffts),
            }

            # [green light]
            if any(tag in tld_info[idx]["tag"] for tag in self.tld_fft) and (tld_info[idx]["navi_path_tld_color"] == 3):
                if tld_info[idx]["vx"] == 0.0:
                    frame_sample["current"][0]["namespace"].append("manual_tld_green_v=0")

                if tld_info[idx]["vx"] < 2.0 and tld_info[idx]["vx"] > 0.0:
                    frame_sample["current"][0]["namespace"].append("manual_tld_green_v>0_v<2")

            # [red light]
            if any(tag in tld_info[idx]["tag"] for tag in self.tld_fft) and (tld_info[idx]["navi_path_tld_color"] == 1):
                if tld_info[idx]["vx"] > 0.0 and tld_info[idx]["ax"] < 0.0:
                    frame_sample["current"][0]["namespace"].append("manual_tld_red_deceleration")

            # [yellow light]
            if any(tag in tld_info[idx]["tag"] for tag in self.tld_fft) and (tld_info[idx]["navi_path_tld_color"] == 2):
                frame_sample["current"][0]["namespace"].append("manual_tld_yellow")

        if len(tld_info) > 0:
            clip_sample["extra"].update({"tld": tld_info})
        return clip_sample


class SceneTagWriter(BaseClipProcessor):
    """Scene tag writer."""

    def __init__(self, scene_id_map: dict, navipath_id2scene_map: dict, **kwargs):
        """Init."""
        super().__init__(**kwargs)
        self.scene2id = scene_id_map
        self.navipath_id2scene_map = navipath_id2scene_map

        self.name = "scene_tag_writer"
        self.reset_stats()

    def get_ego_navi_dist(self, navi_path_points):
        """Get ego navi dist."""
        if len(navi_path_points) == 1:
            return navi_path_points[0][1]
        navi_path_points_diff = navi_path_points[1:] - navi_path_points[:-1]
        navi_path_points_diff = np.concatenate((navi_path_points_diff, navi_path_points_diff[-1:]))
        ego = np.array([[0, 0]])
        ego_navipath_diff = ego - navi_path_points
        distances = np.linalg.norm(navi_path_points, axis=-1)
        nearest_point_indices = distances.argmin()
        match_indeices = [nearest_point_indices]
        if nearest_point_indices > 0:
            match_indeices.append(nearest_point_indices - 1)
        dist_l_min = 1e6
        for idx in match_indeices:
            u = navi_path_points_diff[idx]
            v = ego_navipath_diff[idx]
            dist_l = v[0] * u[1] - v[1] * u[0]
            dist_l = abs(dist_l / np.linalg.norm(u))
            dist_l_min = dist_l if dist_l < dist_l_min else dist_l_min
        # print(distances.min(), dist_l_min)
        return dist_l_min

    def get_head_tail_points(self, line, distance=5):
        """
        从给定的LineString对象中获取头部和末尾指定长度的两个点
        :param line: LineString对象,表示折线
        :param distance: 要截取的头部和末尾的长度,默认为5
        :return: 包含头部两个点和末尾两个点的元组，每个点为(x, y)坐标形式的元组, 如果总长度小于distance*2,则返回空列表
        """

        line = LineString(line)
        # 获取总长度
        total_length = line.length

        # 处理头部长度对应的点
        if total_length < distance * 2:
            return [], []
        # 沿着线的方向进行线性插值获取头部长度处的点
        current_length = 0
        coords = list(line.coords)
        for i in range(len(coords) - 1):
            segment = LineString([coords[i], coords[i + 1]])
            segment_length = segment.length
            if current_length + segment_length > distance:
                alpha = (distance - current_length) / segment_length
                interp_point = (
                    coords[i][0] + alpha * (coords[i + 1][0] - coords[i][0]),
                    coords[i][1] + alpha * (coords[i + 1][1] - coords[i][1]),
                )
                head_points = [coords[0], interp_point]
                break
            current_length += segment_length

        # 处理末尾长度对应的点
        reversed_coords = list(line.coords)[::-1]
        current_length = 0
        for i in range(len(reversed_coords) - 1):
            segment = LineString([reversed_coords[i], reversed_coords[i + 1]])
            segment_length = segment.length
            if current_length + segment_length > distance:
                beta = (distance - current_length) / segment_length
                interp_point = (
                    reversed_coords[i][0] + beta * (reversed_coords[i + 1][0] - reversed_coords[i][0]),
                    reversed_coords[i][1] + beta * (reversed_coords[i + 1][1] - reversed_coords[i][1]),
                )
                tail_points = [interp_point, reversed_coords[0]]
                break
            current_length += segment_length

        return head_points, tail_points

    def get_LT_navipath(self, navipaths):
        """Get LT navipath."""
        LT_indices, RT_indices = [], []
        try:
            for idx, lane_points in enumerate(navipaths):
                head_points, tail_points = self.get_head_tail_points(lane_points)
                if len(head_points) == 0 or len(tail_points) == 0:
                    continue
                head_angle = np.arctan2(head_points[1][1] - head_points[0][1], head_points[1][0] - head_points[0][0])
                tail_angle = np.arctan2(tail_points[1][1] - tail_points[0][1], tail_points[1][0] - tail_points[0][0])
                if tail_angle - head_angle > math.pi * (60 / 180):
                    LT_indices.append(idx)
                elif tail_angle - head_angle < math.pi * (-60 / 180):
                    RT_indices.append(idx)
        except Exception:  # pylint: disable=broad-exception-caught
            return [], []
        return LT_indices, RT_indices

    def is_lane_on_left_or_right(self, self_car_position, navi_paths):
        """
        判断车道在自车正前方的左边还是右边
        :param self_car_position: 自车位置,以Point对象表示
        :param lane_line: 车道线, 以LineString对象表示
        :return: 返回判断结果字符串
        """
        ego_vector = (1, 0)
        distances = np.sqrt(np.square(navi_paths[..., 0]) + np.square(navi_paths[..., 1]))
        closest_indices = np.argsort(distances)[:1]
        points = navi_paths[closest_indices[0]]
        ego_to_point_vector = (points[0] - self_car_position[0], points[1] - self_car_position[1])
        cross_product = ego_vector[0] * ego_to_point_vector[1] - ego_vector[1] * ego_to_point_vector[0]
        if cross_product >= 0:
            return "left"
        elif cross_product < 0:
            return "right"

    def get_LC_navipath(self, navipaths, lk_navipath_index, lt_navipath_index, rt_navipath_index):
        """Get LC navipath."""
        LC_indices, RC_indices = [], []
        not_lc_navipath_index = lk_navipath_index + lt_navipath_index + rt_navipath_index
        for idx, lane_points in enumerate(navipaths):
            if idx in not_lc_navipath_index:
                continue
            flag = self.is_lane_on_left_or_right((0, 0), lane_points)
            if flag == "left":
                LC_indices.append(idx)
            elif flag == "right":
                RC_indices.append(idx)
        return LC_indices, RC_indices

    def get_scene_from_tag(self, tags):
        """Get scene from tag."""
        for tag in tags:
            if "turn" in tag and "left" in tag:
                scene = "LeftTurn"
                return scene
            if "turn" in tag and "right" in tag:
                scene = "RightTurn"
                return scene
        return None

    def get_scene(self, frame_sample):
        """Get scene."""
        # get scene from tag
        tags = frame_sample["tags"]
        scene = self.get_scene_from_tag(tags)
        if scene is not None:
            return scene, self.scene2id[scene]

        navi_path_points = frame_sample["navi_path_points"]

        if len(navi_path_points) == 0:
            scene = "Learnable_LK"
            return scene, self.scene2id[scene]

        dist_l = [self.get_ego_navi_dist(navi_path_point) for navi_path_point in navi_path_points]
        dist_l = np.array(dist_l)

        LK_indices = []
        min_idx = dist_l.argmin()
        if dist_l[min_idx] < 1.5:
            LK_indices = [min_idx]

        LT_indices, RT_indices = self.get_LT_navipath(navi_path_points)
        # keep for left change and right change for future use.
        # LC_navipath_index, RC_navipath_index = self.get_LC_navipath(
        #     navi_path_points, LK_indices, LT_indices, RT_indices
        # )
        if (
            len(LT_indices) + len(RT_indices) > 0
            and len(LK_indices) > 0
            and LK_indices[0] not in LT_indices
            and LK_indices[0] not in RT_indices
        ):
            LK_indices = []

        if len(LK_indices) == 0:
            # if len(LT_indices) > 0 or len(LC_navilane_index) > 0:
            #     scene = "LeftChange"
            # elif len(RT_indices) > 0 or len(RC_navilane_index) > 0:
            #     scene = "RightChange"
            # merge left change and right change to lane keep
            scene = "LaneKeep"
        else:
            min_dist_idx = LK_indices[0]
            if min_dist_idx in LT_indices:
                scene = "LeftTurn"
            elif min_dist_idx in RT_indices:
                scene = "RightTurn"
            else:
                scene = "LaneKeep"

        return scene, self.scene2id[scene]

    def parse_scene_from_navipath(self, frame_sample):
        # 取第一条navipath的属性作为scene type
        if len(frame_sample["navi_path_lc_attr"]) == 0:
            scene_id = self.scene2id["LaneKeep"]
        else:
            scene_id = int(frame_sample["navi_path_lc_attr"][0][0])
        # uturn合并为对应的左右转
        scene = self.navipath_id2scene_map[scene_id]
        return scene, scene_id

    @BaseClipProcessor.common_process(record_stats=True)
    def __call__(self, clip_sample):
        """Call."""
        scene_tags = {}
        # NOTE(gaona): only save scene for valid idx.
        for frame_sample in clip_sample["frame_sample"]:
            idx = frame_sample["current"][0]["index"]
            scene_tag, _ = self.parse_scene_from_navipath(frame_sample["current"][0])
            scene_tags[idx] = scene_tag

            frame_sample["current"][0]["namespace"].append(scene_tag)
        if len(scene_tags) > 0:
            clip_sample["extra"].update({"scene": scene_tags})

        stats = defaultdict(int)
        counter = Counter(list(scene_tags.values()))
        for scene_name, count in counter.items():
            stats[f"tag_distribution_{scene_name}"] += count
        clip_sample["stats"][f"{self.name}_{self.id}"] = stats
        return clip_sample

    def reset_stats(self):
        """Reset stats."""
        super().reset_stats()
        scene_list = list(self.scene2id.keys())
        self.stats.update({f"tag_distribution_{scene_name}": 0 for scene_name in scene_list})


class LowSpeedInfoWriter(BaseClipProcessor):
    """Low speed info writer."""

    def __init__(self, **kwargs):
        """Init."""
        super().__init__(**kwargs)
        self.name = "low_speed_info_writer"

    @BaseClipProcessor.common_process(record_stats=False)
    def __call__(self, clip_sample):
        """Call."""
        low_speed_info = process_clip(clip_sample)

        for frame_sample in clip_sample["frame_sample"]:
            timestamp = frame_sample["current"][0]["timestamp"]

            if timestamp in low_speed_info["low_speed"][0]:
                frame_sample["current"][0]["namespace"].append("low_speed")
            if timestamp in low_speed_info["low_speed_accelerate"][0]:
                frame_sample["current"][0]["namespace"].append("low_speed_acc")

        return clip_sample

    def reset_stats(self):
        """Reset stats."""

    def gather_stats(self, stats):
        """Gather stats."""

    def show_stats(self, logger, time_interval=0.0):
        """Show stats."""
        logger.info(f"=> Summary of {self.name}_{self.id}, avg time cost: {time_interval * 1000:f}ms")


class GreenLightStartFailFrameFilter(BaseClipProcessor):
    """Green light start fail frame filter."""

    def __init__(self, check_future_frame=5):
        """Init."""
        super().__init__()
        self.check_future_frame = check_future_frame

        self.name = "greenlight_start_fail_frame_filter"
        self.reset_stats()
        self.tld_fft_tags = [
            "astra_planner.data_cleaning.leakage_future_info.Tld_Red2Green",
            "astra_planner.fft_urban.junction.head_pass",
            "astra_planner.fft_urban.junction.tld_start",
            "astra_planner.fft_urban.junction.tld_stop",
        ]

    @BaseClipProcessor.common_process(record_stats=True)
    def __call__(self, clip_sample):
        """Call."""
        normal_samples = []

        for sample in clip_sample["frame_sample"]:
            if not self.check_if_green_start_fail(sample, check_future_frame=self.check_future_frame):
                normal_samples.append(sample)
        clip_sample["frame_sample"] = normal_samples

        return clip_sample

    def check_if_green_start_fail(self, data_input, check_future_frame=5, logger_print=False):
        """
        Check if green light start fail. True means green light start fail.

        check_future_frame = 5 means we check in the future 5 frames (1s)
        to see if there is any green light start.
        """
        if any(tag in data_input["current"][0]["tags"] for tag in self.tld_fft_tags):
            if data_input["current"][0]["ego_motion"][0] == 0.0 and data_input["current"][0]["ego_motion"][1] == 0.0:
                if (
                    len(data_input["current"][0]["navi_path_tld"]) > 0
                    and len(data_input["current"][0]["navi_path_tld"][0]) > 0
                ):
                    navi_path_tld = data_input["current"][0]["navi_path_tld"][0][0]
                else:
                    navi_path_tld = -1

                if navi_path_tld == 3:
                    if data_input["future"] is None or len(data_input["future"]) < check_future_frame:
                        return False  # not enough future frames to check
                    future_frame_data = data_input["future"][check_future_frame]
                    if future_frame_data is not None and future_frame_data["ego_motion"][0] > 0:
                        if logger_print:
                            print("green light start in 1 second succeed")
                        return False  # green light start succeed
                    if future_frame_data is not None and future_frame_data["ego_motion"][0] == 0:
                        if logger_print:
                            print("green light start in 1 second fail")
                        return True  # green light start fail
        return False


class GreenorNoTLDStopFilter(BaseClipProcessor):
    """Green light stop frame filter."""

    def __init__(self):
        """Init."""
        super().__init__()
        self.name = "green_or_no_tld_stop_frame_filter"
        self.reset_stats()
        self.tld_fft_tags = [
            "astra_planner.data_cleaning.leakage_future_info.Tld_Red2Green",
            "astra_planner.data_cleaning.leakage_future_info.Tld_Green2Yellow",
            "astra_planner.fft_urban.junction.head_pass",
            "astra_planner.fft_urban.junction.tld_start",
            "astra_planner.fft_urban.junction.tld_stop",
        ]

    @BaseClipProcessor.common_process(record_stats=True)
    def __call__(self, clip_sample):
        """Call."""
        normal_samples = []

        for sample in clip_sample["frame_sample"]:
            if not self.check_if_green_stop(sample):
                normal_samples.append(sample)
        clip_sample["frame_sample"] = normal_samples

        return clip_sample

    def check_if_green_stop(self, data_input, logger_print=False):
        """
        Check if green light but stop eventually. True means green light but stop.
        """
        if (
            any(tag in data_input["current"][0]["tags"] for tag in self.tld_fft_tags)
            and data_input["current"][0]["ego_motion"][0] > 0.0
        ):
            if (
                len(data_input["current"][0]["navi_path_tld"]) > 0
                and len(data_input["current"][0]["navi_path_tld"][0]) > 0
            ):
                navi_path_tld = data_input["current"][0]["navi_path_tld"][0][0]
            else:
                navi_path_tld = -1

            if navi_path_tld == 3 or navi_path_tld == -1 or navi_path_tld == 0:
                if data_input["future"] is None:
                    return False  # not enough future frames to check
                last_future_frame_data = data_input["future"][-1]

                if (
                    last_future_frame_data is not None
                    and last_future_frame_data["ego_motion"][0] < data_input["current"][0]["ego_motion"][0] / 4
                ):
                    if logger_print:
                        print("green light or no tld but stop in 7 seconds")
                    return True  # green light but stop
        return False
