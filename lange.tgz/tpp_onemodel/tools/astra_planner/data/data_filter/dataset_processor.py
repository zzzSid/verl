# -*- coding: utf-8 -*-
# flake8: noqa
# type: ignore
# pylint: disable=logging-fstring-interpolation
import copy
import multiprocessing
import os
import pickle as pkl
from collections import Counter
from collections import defaultdict
from itertools import chain

import numpy as np
from tqdm import tqdm

from tpp_onemodel.tools.astra_planner.data.data_filter.common_utils import (
    convert_tag_objs,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.common_utils import (
    read_bytes_from_ceph,
)
from tpp_onemodel.tools.astra_planner.data.data_utils_scripts.tag_utils import (
    export2markdown,
)


class BaseDatasetProcessor:
    """Base dataset processor."""

    def __call__(self, datasets, logger):
        """Call."""
        return datasets


class TrainValSplitProcessor(BaseDatasetProcessor):
    """Trainval split filter."""

    def __init__(self, split_config, namespace="total"):
        """Init."""
        super().__init__()
        self.split_config = split_config
        self.namespace = namespace

        self.seed = 666

    def __call__(self, datasets, logger):
        """Call."""
        dataset = datasets.get(self.namespace, None)
        if dataset is None:
            raise KeyError(f"Namespace {self.namespace} not found.")

        data_list = dataset["data_list"]
        remain_indices = np.arange(len(data_list))
        for mode, clip_num in self.split_config.items():
            remain_clips = len(remain_indices)
            if clip_num < 0:
                clip_num = remain_clips - (sum(self.split_config.values()) - clip_num)  # sum except itself
            if clip_num < 0 or clip_num > remain_clips:
                raise IndexError("List index out of range: {valid_clips}")

            np.random.seed(self.seed)
            part_indices = np.random.choice(remain_indices, clip_num, replace=False)
            part_data_list = np.array(data_list)[part_indices].tolist()
            remain_indices = np.setxor1d(remain_indices, part_indices)

            datasets[mode] = {
                "data_list": part_data_list,
                "dump_root": dataset["dump_root"],
                "dataset_name": dataset["dataset_name"],
                "subdataset_name": dataset["subdataset_name"],
            }
        return datasets


class OversampleProcessor(BaseDatasetProcessor):
    """Oversample processor."""

    def __init__(self, oversample_scale, namespace="total"):
        """Init."""
        super().__init__()
        self.oversample_scale = oversample_scale
        self.namespace = namespace

    def __call__(self, datasets, logger):
        """Call."""
        dataset = datasets.get(self.namespace, None)
        if dataset is None:
            raise KeyError(f"Namespace {self.namespace} not found.")

        oversampled_dataset = {
            "data_list": [],
            "dump_root": dataset["dump_root"],
            "dataset_name": dataset["dataset_name"],
            "subdataset_name": dataset["subdataset_name"],
        }

        data_list = dataset["data_list"]

        # Print the counts
        all_namespaces = [clip_data["namespaces"] for clip_data in data_list]
        namespaces_list = list(chain.from_iterable(all_namespaces))
        namespaces_flatten_list = list(chain.from_iterable(namespaces_list))
        namespace_count = dict(Counter(namespaces_flatten_list))
        logger.info(f"=> Summary of each namespace before oversampling:")
        for key, value in namespace_count.items():
            logger.info(f"     : {key}: {value}")

        for clip_data in tqdm(data_list, desc="oversample_processor"):
            new_clip_data = copy.deepcopy(clip_data)
            new_clip_data["selected_timestamp"] = []
            new_clip_data["selected_frame_idx"] = []
            new_clip_data["namespaces"] = []
            for timestamp, frame_idx, namespace in zip(
                clip_data["selected_timestamp"], clip_data["selected_frame_idx"], clip_data["namespaces"]
            ):
                oversample_time = 1
                for ns, scale in self.oversample_scale.items():
                    if ns in namespace:
                        oversample_time += scale

                new_clip_data["selected_timestamp"].extend([timestamp] * oversample_time)
                new_clip_data["selected_frame_idx"].extend([frame_idx] * oversample_time)
                new_clip_data["namespaces"].extend([namespace] * oversample_time)

            oversampled_dataset["data_list"].append(new_clip_data)

        datasets["train_oversample"] = oversampled_dataset
        return datasets


class PklDumpProcessor(BaseDatasetProcessor):
    """Pkl dump processor."""

    def __init__(self, namespace="total"):
        """Init."""
        super().__init__()
        self.namespace = namespace

    def __call__(self, datasets, logger):
        """Call."""
        if not isinstance(self.namespace, (tuple, list)):
            self.namespace = [self.namespace]

        for namespace in self.namespace:
            dataset = datasets.get(namespace, None)
            if dataset is None:
                raise KeyError(f"Namespace {self.namespace} not found.")

            data_list = dataset["data_list"]
            valid_clips = len(data_list)
            valid_frames = sum([len(sample_list["selected_timestamp"]) for sample_list in data_list])

            save_path = os.path.join(
                dataset["dump_root"],
                f"{dataset['dataset_name']}_{dataset['subdataset_name']}_{namespace}_{valid_clips}_{valid_frames}.pkl",
            )
            logger.info(f"=> Dumping data list to {save_path}. This might take several minutes ...")
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            with open(save_path, "wb") as fw:
                pkl.dump(data_list, fw)
            logger.info(f"=> Dump finished. Save pkl file to {save_path}")

            dataset["save_path"] = save_path
        return datasets


class TagStatisticsProcessor(BaseDatasetProcessor):
    """Tag statistics processor."""

    def __init__(self, clip_tag_num_threshold=1, num_workers=64, load_all_frames=False, namespace="total"):
        """Init."""
        super().__init__()
        self.clip_tag_num_threshold = clip_tag_num_threshold
        self.num_workers = num_workers
        self.load_all_frames = load_all_frames
        self.namespace = namespace

    @staticmethod
    def split_tag_by_level(tag_list):
        """当前帧的 tag 标签, 按照一级、二级标签计数."""
        level_tags = []
        for tag in tag_list:
            while tag.find(".") > 0:
                tag, _ = tag.rsplit(".", 1)
                level_tags.append(tag)
        return list(set(level_tags))

    def add_record(self, clip_data):
        """Add record."""
        tag_ceph_path = clip_data["tag_ceph_path"]
        selected_timestamp = clip_data["selected_timestamp"]
        tag_bytes = read_bytes_from_ceph([tag_ceph_path])[0]
        tag_info = pkl.loads(tag_bytes)

        frame_tag_counts = defaultdict(int)
        if self.load_all_frames:
            tag_objs = tag_info.values()
        else:
            tag_objs = []
            for timestamp in selected_timestamp:
                tag_key = str(int(timestamp))
                tag_obj = tag_info.get(tag_key, {"objs": []}) if tag_info and (tag_key in tag_info) else {"objs": []}
                tag_objs.append(tag_obj)

        for tag_obj in tag_objs:
            tag_list = convert_tag_objs(tag_obj)
            for tag_name in tag_list:
                frame_tag_counts[tag_name] += 1

            level_tag_list = self.split_tag_by_level(tag_list)
            for tag_name in level_tag_list:
                frame_tag_counts[tag_name] += 1

        return frame_tag_counts

    def __call__(self, datasets, logger):
        """Call."""
        if not isinstance(self.namespace, (tuple, list)):
            self.namespace = [self.namespace]

        for namespace in self.namespace:
            dataset = datasets.get(namespace, None)
            if dataset is None:
                raise KeyError(f"Namespace {self.namespace} not found.")

            tag_counts = {}
            with multiprocessing.Pool(self.num_workers) as pool:
                results = tqdm(
                    pool.imap(self.add_record, dataset["data_list"]),
                    total=len(dataset["data_list"]),
                    desc=f"Tag Statistics {namespace}",
                )
                for result in results:
                    for tag_name, count in result.items():
                        if tag_name not in tag_counts:
                            tag_counts[tag_name] = defaultdict(int)
                        tag_counts[tag_name]["frame_num"] += count
                        tag_counts[tag_name]["clip_num"] += int(count >= self.clip_tag_num_threshold)

            save_path = os.path.join(
                dataset["dump_root"],
                f"{dataset['dataset_name']}_{dataset['subdataset_name']}_{namespace}_tag_statistics",
                f"{dataset['dataset_name']}_{dataset['subdataset_name']}_{namespace}_tag_statistics.md",
            )
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            export2markdown(tag_counts, save_path)

        return datasets
