# -*- coding: utf-8 -*-
# pylint: skip-file
# mypy: ignore-errors
"""Base config for generating v1220 dataset."""
import copy

from tpp_onemodel.tools.astra_planner.data.data_filter.common_filter import (
    GenerateWindow,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.common_filter import (
    IntegratedFrameFilter,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.common_filter import (
    LoadSensorInfoFromCeph,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.common_filter import (
    MissingFFTTagFilter,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.common_filter import (
    MissingTagFileFilter,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.common_filter import (
    TagIncludeWriter,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.dataset_processor import (
    OversampleProcessor,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.dataset_processor import (
    PklDumpProcessor,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.dataset_processor import (
    TagStatisticsProcessor,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.dataset_processor import (
    TrainValSplitProcessor,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.frame_filter import (
    PaddingFilterByFrame,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.frame_filter import (
    TagExcludeFilterByFrame,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.frame_filter import (
    TagIncludeFilterByFrame,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.scene_filter import (
    GreenLightStartFailFrameFilter,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.scene_filter import (
    InvalidNaviLineFilter,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.scene_filter import (
    InvalidNaviPathFilter,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.scene_filter import NaviYawFilter
from tpp_onemodel.tools.astra_planner.data.data_filter.scene_filter import (
    SceneTagWriter,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.scene_filter import TLDInfoWriter


HISTORY_FRAMES_NUM = 14
FUTURE_FRAMES_NUM = 35
SLICE_STEP = 1
INPUT_SENSOR_MAP = {
    "current": [
        "dynamic_dets",
        "meta",
        "static_dets",
        "dynamic_gods",
        "manner_lane",
        "sdmap",
        "atlas",
        "navi_line",
        "navi_path",
        "tld",
    ],
    "history": ["dynamic_dets", "meta"],
    "future": ["dynamic_dets", "meta"],
}
NIOFS_MODE = True

NAVI_FROM_OCEANUS = True
TLD_FFT_LIST = [
    "astra_planner.fft_urban.junction.head_pass",
    "astra_planner.data_cleaning.leakage_future_info.Tld_Yellow2Red",
    "astra_planner.data_cleaning.leakage_future_info.Tld_Red2Green",
    "astra_planner.data_cleaning.leakage_future_info.Tld_Green2Yellow",
]
SCENE_ID_MAP = {
    "Learnable_LK": 0,
    "LaneKeep": 1,
    "LeftChange": 2,
    "RightChange": 3,  # useless
    "LeftTurn": 4,  # useless
    "RightTurn": 5,
}

base_sample_filters = [
    MissingTagFileFilter(),
    MissingFFTTagFilter(),
    NaviYawFilter(),
    GenerateWindow(
        history_frames_num=HISTORY_FRAMES_NUM,
        future_frames_num=FUTURE_FRAMES_NUM,
        slide_step=SLICE_STEP,
    ),
    IntegratedFrameFilter(
        namespace="wtag",
        frame_filters=[
            PaddingFilterByFrame(
                history_frames_num=HISTORY_FRAMES_NUM,
                future_frames_num=FUTURE_FRAMES_NUM,
                input_sensor_map=INPUT_SENSOR_MAP,
                allow_history_frame_is_none=0,  # 14 history frames are necessary
                allow_future_frame_is_none=30,  # 5 future frames are necessary
            ),
            TagIncludeFilterByFrame(included_tag_list=["fft_urban"]),
            TagExcludeFilterByFrame(excluded_tag_list=["astra_planner.data_cleaning.md_bad_behavior"]),
            TagExcludeFilterByFrame(excluded_tag_list=["astra_planner.ego_state.gear.R"]),
        ],
    ),
    IntegratedFrameFilter(
        namespace="wotag",
        frame_filters=[
            PaddingFilterByFrame(
                history_frames_num=HISTORY_FRAMES_NUM,
                future_frames_num=FUTURE_FRAMES_NUM,
                input_sensor_map=INPUT_SENSOR_MAP,
                allow_history_frame_is_none=0,  # 14 history frames are necessary
                allow_future_frame_is_none=30,  # 5 future frames are necessary
            ),
        ],
    ),
    LoadSensorInfoFromCeph(
        sensor_map={
            "current": ["meta", "navi_line", "navi_path"],
            "history": [],
            "future": ["meta"],
        },
        niofs_mode=NIOFS_MODE,
    ),
    InvalidNaviLineFilter(invalid_navi_filters={4: [0, 1]}, get_from_oceanus=NAVI_FROM_OCEANUS),
    InvalidNaviPathFilter(invalid_navi_filters={4: [0, 1]}, get_from_oceanus=NAVI_FROM_OCEANUS),
    GreenLightStartFailFrameFilter(),
    TagIncludeWriter(
        included_tag_list={
            "fft_oversample": [
                "astra_planner.fft_urban.junction.unprotected_leftturn_opposite_vehicle",
                "astra_planner.fft_urban.junction.turnleft_vehicle_merge",
                "astra_planner.fft_urban.junction.turnleft_parallel_vehicle",
                "astra_planner.fft_urban.junction.turnleft_VRU_cross",
                "astra_planner.fft_urban.junction.rightturn_oncoming_vehicle_leftturn",
                "astra_planner.fft_urban.junction.turnright_VRU_cross",
                "astra_planner.fft_urban.junction.turnright_parallel_vehicle",
                "astra_planner.fft_urban.junction.turnright_VRU_cross_strong_interaction",
                "astra_planner.fft_urban.junction.turnright_yield_occupiedVRU",
                "astra_planner.fft_urban.junction.turnright_vehicle_merge",
                "astra_planner.fft_urban.junction.VRU_game",
                "astra_planner.fft_urban.junction.nudge",
                "astra_planner.fft_urban.junction.oncoming_car_interact",
                "astra_planner.fft_urban.single_lane_driving.TwoDir_NarrRoad_encounter",
                "astra_planner.fft_urban.single_lane_driving.TwoDir_NarrRoad_OncoVehicle_InvadGame",
                "astra_planner.fft_urban.single_lane_driving.NarrRoad_nudge",
                "astra_planner.fft_urban.sidepass.TwoDir_NarrRoad_OppositeDir_VehicleNudge",
                "astra_planner.fft_urban.single_lane_driving.MinorRoad_VRU_cross",
                "astra_planner.fft_urban.single_lane_driving.MinorRoad_vehicle_cross",
                "astra_planner.fft_urban.single_lane_driving.MinorRoad_NarrSpace_EncounterYield",
            ],
            "whitebox_oversample": [
                "astra_planner.data_cleaning.brake_attribution_obstacle.CrossingObj_Interaction",
                "astra_planner.data_cleaning.brake_attribution_obstacle.Vru_Interaction",
            ],
        },
    ),
    TLDInfoWriter(tld_fft_list=TLD_FFT_LIST),
    SceneTagWriter(scene_id_map=SCENE_ID_MAP),
]
base_post_processors = [
    TrainValSplitProcessor(
        split_config={
            "train": -1,
            "val": 50000,
            "cicd": 100,
        },
    ),
    OversampleProcessor(
        namespace="train",
        oversample_scale={
            "fft_oversample": 3,
            "whitebox_oversample": 4,
            "LeftTurn": 2,
            "RightTurn": 2,
            "manual_tld_green_v=0": 100,
            "manual_tld_green_v>0_v<2": 30,
            "manual_tld_red_deceleration": 20,
            "manual_tld_yellow": 30,
        },
    ),
    PklDumpProcessor(
        namespace=["total", "train_oversample", "train", "val", "cicd"],
    ),
    TagStatisticsProcessor(
        namespace="train",
    ),
]

config = [
    {
        "dataset_name": "planner_dataset_v1220",
        "dataset_list": [
            "/share-global/jackson.zhong/share/planning/250103_weekly/v20250103_output_weekly_stock_adw_clips.txt",
            "/share-global/jackson.zhong/share/planning/250103_weekly/v20250103_output_adw_BC_navpath_109092clips.txt",
            "/share-global/jackson.zhong/share/planning/250103_weekly/v20250103_output_weekly_stock_dlb_clips.txt",
            "/share-global/jackson.zhong/share/planning/250103_weekly/v20250103_output_remain_dlb_300187clips.txt",
            "/share-global/jackson.zhong/share/planning/250103_weekly/v20250103_output_manner_navpth_dlb.txt",
            "/share-global/jackson.zhong/share/planning/250103_weekly/v20250103_output_append_dlb_fft_diff_213637clips.txt",
            "/share-global/jackson.zhong/share/planning/250103_weekly/v20250103_output_append_dongxue_dlb_clips.txt",
            "/share-global/jackson.zhong/share/planning/250103_weekly/v20250103_output_dongxue_total_fft_1wclips.txt",
            "/share-global/jackson.zhong/share/planning/250103_weekly/v20250103_output_manner48w_tld_diff.txt",
            "/share-global/jackson.zhong/share/planning/250103_weekly/v20250103_output_dlb_navi_lc_dongxue.txt",
            "/share-global/jackson.zhong/share/planning/250103_weekly/v20250103_output_append_dlb_clips_diff_48864clips.txt",
            "/share-global/jackson.zhong/share/planning/250103_weekly/v20250103_output_manner_tld_diff_11806clips.txt",
            "/share-global/jackson.zhong/share/planning/250103_weekly/v20250103_output_manner48w_tld_20250106_diff_9460clips.txt",
        ],
        "tag_prefix": "huailai_cos:ad-cn-hlidc-fdm-static/Tag_Static/prod_v20240111_total_tags",
        "subdataset_config": [
            {
                "subdataset_name": "all_data",
                "sample_filters": copy.deepcopy(base_sample_filters),
                "post_processors": copy.deepcopy(base_post_processors),
            },
        ],
    },
]
