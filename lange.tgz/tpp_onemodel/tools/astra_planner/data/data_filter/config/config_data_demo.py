# -*- coding: utf-8 -*-
# flake8: noqa
# type: ignore
"""Base config for generating dataset."""
from tpp_onemodel.tools.astra_planner.data.data_filter.common_filter import (
    GenerateWindow,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.common_filter import (
    IntegratedFrameFilter,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.common_filter import (
    LoadSensorInfoFromCeph,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.dataset_processor import (
    PklDumpProcessor,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.frame_filter import (
    PaddingFilterByFrame,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.scene_filter import (
    SceneTagWriter,
)


SCENE_ID_MAP = {
    "Learnable_LK": 0,
    "LaneKeep": 1,
    "LeftChange": 2,
    "RightChange": 3,  # useless
    "LeftTurn": 4,  # useless
    "RightTurn": 5,
}

NAVIPATH_ID2SCENE_MAP = {
    0: "Learnable_LK",  # unknown
    1: "LaneKeep",  # straight
    2: "LeftTurn",  # left
    3: "RightTurn",  # right
    4: "LeftTurn",  # u_turn_left
    5: "RightTurn",  # u_turn_right
}

HISTORY_FRAMES_NUM = 14
FUTURE_FRAMES_NUM = 35
SLICE_STEP = 1
INPUT_SENSOR_MAP = {
    "current": [
        "dynamic_dets",
        "meta",
        "static_dets",
        "dynamic_gods",
        "manner_lane",
        # "atlas",
        "navi_path",
    ],
    "history": ["dynamic_dets", "meta"],
    "future": ["dynamic_dets", "meta"],
}

config = [
    {
        "dataset_name": "planner_dataset_demo",
        "dataset_list": [
            "/share-global/mccree.zhao/share/planning/dataset/0920_100w_transform/0920_100w_transform_val_101.txt",
        ],
        "tag_prefix": "huailai_cos:ad-cn-hlidc-fdm-static/Tag_Static/prod_v20241228_all_tags",
        "fill_none_for_missing_tag": True,
        "subdataset_config": [
            {
                "subdataset_name": "all_data",
                "sample_filters": [
                    GenerateWindow(
                        history_frames_num=HISTORY_FRAMES_NUM,
                        future_frames_num=FUTURE_FRAMES_NUM,
                        slide_step=SLICE_STEP,
                    ),
                    IntegratedFrameFilter(
                        frame_filters=[
                            PaddingFilterByFrame(
                                history_frames_num=HISTORY_FRAMES_NUM,
                                future_frames_num=FUTURE_FRAMES_NUM,
                                input_sensor_map=INPUT_SENSOR_MAP,
                                allow_future_frame_is_none=30,
                            ),
                        ],
                    ),
                    LoadSensorInfoFromCeph(
                        sensor_map={
                            "current": ["meta", "navi_path"],
                            "history": [],
                            "future": [],
                        },
                    ),
                    SceneTagWriter(scene_id_map=SCENE_ID_MAP, navipath_id2scene_map=NAVIPATH_ID2SCENE_MAP),
                ],
                "post_processors": [
                    PklDumpProcessor(namespace=["total"]),
                ],
            },
        ],
    },
]
