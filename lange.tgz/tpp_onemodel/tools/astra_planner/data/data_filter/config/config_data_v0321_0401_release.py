# -*- coding: utf-8 -*-
# pylint: skip-file
# mypy: ignore-errors
"""Base config for generating v0303_0306 dataset."""
import copy

from tpp_onemodel.tools.astra_planner.data.data_filter.common_filter import (
    GenerateWindow,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.common_filter import (
    IntegratedFrameFilter,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.common_filter import (
    LoadSensorInfoFromCeph,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.common_filter import (
    MissingFFTTagFilter,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.common_filter import (
    MissingTagFileFilter,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.common_filter import (
    NoTrainTagFileFilter,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.common_filter import (
    TagIncludeWriter,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.dataset_processor import (
    OversampleProcessor,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.dataset_processor import (
    PklDumpProcessor,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.dataset_processor import (
    TagStatisticsProcessor,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.dataset_processor import (
    TrainValSplitProcessor,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.frame_filter import (
    PaddingFilterByFrame,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.frame_filter import (
    TagExcludeFilterByFrame,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.frame_filter import (
    TagIncludeFilterByFrame,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.scene_filter import (
    BlackListFilter,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.scene_filter import (
    GreenLightStartFailFrameFilter,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.scene_filter import (
    GreenorNoTLDStopFilter,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.scene_filter import (
    InvalidNaviPathFilter,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.scene_filter import NaviYawFilter
from tpp_onemodel.tools.astra_planner.data.data_filter.scene_filter import (
    SceneTagWriter,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.scene_filter import TLDInfoWriter
from tpp_onemodel.tools.astra_planner.data.data_filter.scene_filter import (
    WhiteListFilter,
)


HISTORY_FRAMES_NUM = 14
FUTURE_FRAMES_NUM = 35
SLICE_STEP = 1
INPUT_SENSOR_MAP = {
    "current": [
        "dynamic_dets",
        "meta",
        "static_dets",
        "dynamic_gods",
        "manner_lane",
        # "atlas",
        "navi_path",
        "car_pose",
    ],
    "history": ["dynamic_dets", "meta"],
    "future": ["dynamic_dets", "meta"],
}
NIOFS_MODE = True

NAVI_FROM_OCEANUS = True
TLD_FFT_LIST = [
    "astra_planner.fft_urban.junction.head_pass",
    "astra_planner.fft_urban.junction.tld_start",
    "astra_planner.fft_urban.junction.tld_stop",
    "astra_planner.data_cleaning.leakage_future_info.Tld_Yellow2Red",
    "astra_planner.data_cleaning.leakage_future_info.Tld_Red2Green",
    "astra_planner.data_cleaning.leakage_future_info.Tld_Green2Yellow",
]
SCENE_ID_MAP = {
    "Learnable_LK": 0,
    "LaneKeep": 1,
    "LeftChange": 2,  # useless
    "RightChange": 3,  # useless
    "LeftTurn": 4,
    "RightTurn": 5,
}

NAVIPATH_ID2SCENE_MAP = {
    0: "Learnable_LK",  # unknown
    1: "LaneKeep",  # straight
    2: "LeftTurn",  # left
    3: "RightTurn",  # right
    4: "LeftTurn",  # u_turn_left
    5: "RightTurn",  # u_turn_right
}

base_sample_filters = [
    BlackListFilter(
        black_files=[
            "/share-global/enzo.shu/for_planner/junction_reverse_steer_0224.txt",
        ]
    ),
    MissingTagFileFilter(),
    MissingFFTTagFilter(),
    NoTrainTagFileFilter(),
    NaviYawFilter(),
    GenerateWindow(
        history_frames_num=HISTORY_FRAMES_NUM,
        future_frames_num=FUTURE_FRAMES_NUM,
        slide_step=SLICE_STEP,
    ),
    IntegratedFrameFilter(
        namespace="wtag",
        frame_filters=[
            PaddingFilterByFrame(
                history_frames_num=HISTORY_FRAMES_NUM,
                future_frames_num=FUTURE_FRAMES_NUM,
                input_sensor_map=INPUT_SENSOR_MAP,
                allow_history_frame_is_none=0,  # 14 history frames are necessary
                allow_future_frame_is_none=30,  # 5 future frames are necessary
            ),
            TagIncludeFilterByFrame(included_tag_list=["fft_urban"]),
            TagExcludeFilterByFrame(excluded_tag_list=["astra_planner.data_cleaning.md_bad_behavior"]),
            TagExcludeFilterByFrame(excluded_tag_list=["astra_planner.ego_state.gear.R"]),
        ],
    ),
    IntegratedFrameFilter(
        namespace="wotag",
        frame_filters=[
            PaddingFilterByFrame(
                history_frames_num=HISTORY_FRAMES_NUM,
                future_frames_num=FUTURE_FRAMES_NUM,
                input_sensor_map=INPUT_SENSOR_MAP,
                allow_history_frame_is_none=0,  # 14 history frames are necessary
                allow_future_frame_is_none=30,  # 5 future frames are necessary
            ),
        ],
    ),
    LoadSensorInfoFromCeph(
        sensor_map={
            "current": ["meta", "navi_path"],
            "history": ["meta"],
            "future": ["meta"],
        },
        niofs_mode=NIOFS_MODE,
    ),
    InvalidNaviPathFilter(invalid_navi_filters={4: [0, 1]}, get_from_oceanus=NAVI_FROM_OCEANUS),
    GreenLightStartFailFrameFilter(),
    GreenorNoTLDStopFilter(),
    TagIncludeWriter(
        included_tag_list={
            "fft_oversample": [
                "astra_planner.fft_urban.junction.unprotected_leftturn_opposite_vehicle",
                "astra_planner.fft_urban.junction.turnleft_vehicle_merge",
                "astra_planner.fft_urban.junction.turnleft_parallel_vehicle",
                "astra_planner.fft_urban.junction.turnleft_VRU_cross",
                "astra_planner.fft_urban.junction.rightturn_oncoming_vehicle_leftturn",
                "astra_planner.fft_urban.junction.turnright_VRU_cross",
                "astra_planner.fft_urban.junction.turnright_parallel_vehicle",
                "astra_planner.fft_urban.junction.turnright_VRU_cross_strong_interaction",
                "astra_planner.fft_urban.junction.turnright_yield_occupiedVRU",
                "astra_planner.fft_urban.junction.turnright_vehicle_merge",
                "astra_planner.fft_urban.junction.VRU_game",
                "astra_planner.fft_urban.junction.nudge",
                "astra_planner.fft_urban.junction.oncoming_car_interact",
                "astra_planner.fft_urban.single_lane_driving.TwoDir_NarrRoad_encounter",
                "astra_planner.fft_urban.single_lane_driving.TwoDir_NarrRoad_OncoVehicle_InvadGame",
                "astra_planner.fft_urban.single_lane_driving.NarrRoad_nudge",
                "astra_planner.fft_urban.sidepass.TwoDir_NarrRoad_OppositeDir_VehicleNudge",
                "astra_planner.fft_urban.single_lane_driving.MinorRoad_VRU_cross",
                "astra_planner.fft_urban.single_lane_driving.MinorRoad_vehicle_cross",
                "astra_planner.fft_urban.single_lane_driving.MinorRoad_NarrSpace_EncounterYield",
                # "astra_planner.fft_urban.junction.head_pass",
                "astra_planner.fft_urban.junction.tld_start",
                # "astra_planner.fft_urban.junction.tld_stop",
            ],
            "whitebox_oversample": [
                "astra_planner.data_cleaning.brake_attribution_obstacle.CrossingObj_Interaction",
                "astra_planner.data_cleaning.brake_attribution_obstacle.Vru_Interaction",
            ],
        },
    ),
    TLDInfoWriter(tld_fft_list=TLD_FFT_LIST),
    SceneTagWriter(scene_id_map=SCENE_ID_MAP, navipath_id2scene_map=NAVIPATH_ID2SCENE_MAP),
]
base_post_processors = [
    TrainValSplitProcessor(
        split_config={
            "train": -1,
            "val": 10000,
            "cicd": 100,
        },
    ),
    OversampleProcessor(
        namespace="train",
        oversample_scale={
            "fft_oversample": 3,
            "whitebox_oversample": 4,
            "LeftTurn": 2,
            "RightTurn": 2,
            "manual_tld_green_v=0": 100,
            "manual_tld_green_v>0_v<2": 30,
            # "manual_tld_red_deceleration": 20,
            "manual_tld_yellow": 30,
        },
    ),
    PklDumpProcessor(
        namespace=["total", "train_oversample", "train", "val", "cicd"],
    ),
    TagStatisticsProcessor(
        namespace="train",
    ),
]

three_point_turn_sample_filters = [
    WhiteListFilter(
        white_files=[
            "/share-global/runlin.he/share/three_point_turn_clips_0318_weekly.txt",
        ]
    ),
    GenerateWindow(
        history_frames_num=HISTORY_FRAMES_NUM,
        future_frames_num=FUTURE_FRAMES_NUM,
        slide_step=SLICE_STEP,
    ),
    IntegratedFrameFilter(
        namespace="wtag",
        frame_filters=[
            PaddingFilterByFrame(
                history_frames_num=HISTORY_FRAMES_NUM,
                future_frames_num=FUTURE_FRAMES_NUM,
                input_sensor_map=INPUT_SENSOR_MAP,
                allow_history_frame_is_none=0,  # 14 history frames are necessary
                allow_future_frame_is_none=30,  # 5 future frames are necessary
            ),
            TagIncludeFilterByFrame(
                included_tag_list=[
                    "three_point_turn",
                ]
            ),
            TagExcludeFilterByFrame(excluded_tag_list=["astra_planner.data_cleaning.md_bad_behavior"]),
        ],
    ),
    IntegratedFrameFilter(
        namespace="wotag",
        frame_filters=[
            PaddingFilterByFrame(
                history_frames_num=HISTORY_FRAMES_NUM,
                future_frames_num=FUTURE_FRAMES_NUM,
                input_sensor_map=INPUT_SENSOR_MAP,
                allow_history_frame_is_none=0,  # 14 history frames are necessary
                allow_future_frame_is_none=30,  # 5 future frames are necessary
            ),
        ],
    ),
    LoadSensorInfoFromCeph(
        sensor_map={
            "current": ["meta", "navi_path"],
            "history": ["meta"],
            "future": ["meta"],
        },
        niofs_mode=NIOFS_MODE,
    ),
    GreenLightStartFailFrameFilter(),
    SceneTagWriter(scene_id_map=SCENE_ID_MAP, navipath_id2scene_map=NAVIPATH_ID2SCENE_MAP),
]

uturn_sample_filters = [
    WhiteListFilter(
        white_files=[
            "/share-global/runlin.he/share/uturn_clips_0318_weekly.txt",
        ]
    ),
    GenerateWindow(
        history_frames_num=HISTORY_FRAMES_NUM,
        future_frames_num=FUTURE_FRAMES_NUM,
        slide_step=SLICE_STEP,
    ),
    IntegratedFrameFilter(
        namespace="wtag",
        frame_filters=[
            PaddingFilterByFrame(
                history_frames_num=HISTORY_FRAMES_NUM,
                future_frames_num=FUTURE_FRAMES_NUM,
                input_sensor_map=INPUT_SENSOR_MAP,
                allow_history_frame_is_none=0,  # 14 history frames are necessary
                allow_future_frame_is_none=30,  # 5 future frames are necessary
            ),
            TagIncludeFilterByFrame(
                included_tag_list=[
                    "u_turn",
                ]
            ),
            TagExcludeFilterByFrame(excluded_tag_list=["astra_planner.data_cleaning.md_bad_behavior"]),
        ],
    ),
    IntegratedFrameFilter(
        namespace="wotag",
        frame_filters=[
            PaddingFilterByFrame(
                history_frames_num=HISTORY_FRAMES_NUM,
                future_frames_num=FUTURE_FRAMES_NUM,
                input_sensor_map=INPUT_SENSOR_MAP,
                allow_history_frame_is_none=0,  # 14 history frames are necessary
                allow_future_frame_is_none=30,  # 5 future frames are necessary
            ),
        ],
    ),
    LoadSensorInfoFromCeph(
        sensor_map={
            "current": ["meta", "navi_path"],
            "history": ["meta"],
            "future": ["meta"],
        },
        niofs_mode=NIOFS_MODE,
    ),
    GreenLightStartFailFrameFilter(),
    SceneTagWriter(scene_id_map=SCENE_ID_MAP, navipath_id2scene_map=NAVIPATH_ID2SCENE_MAP),
]

uturn_post_processors = [
    PklDumpProcessor(
        namespace=["total"],
    ),
    TagStatisticsProcessor(
        namespace="total",
    ),
]

config = [
    {
        "dataset_name": "planner_dataset_v0321_0401",
        "dataset_list": [
            "/share-global/pernod.pan/share/planning/20250321_weekly/v20250322005735_plan_v3.txt",
            "/share-global/pernod.pan/share/planning/20250321_weekly/v20250321_weekly_dlb_v4.txt",
            "/share-global/zhao.Du/share/planning/0326_weekly/file_save_adw.txt",
            "/share-global/zhao.Du/share/planning/0326_weekly/file_save_sub1v2_dlb.txt",
            "/share-global/zhao.Du/share/planning/0326_weekly/file_save_sub2v2_dlb.txt",
            "/share-global/zhao.Du/share/planning/0326_weekly/file_save_sub3_dlb.txt",
            "/share-global/pernod.pan/share/planning/20250331_weekly/v20250328141541_plan.txt",
            "/share-global/pernod.pan/share/planning/20250331_weekly/v20250330151423_plan.txt",
            "/share-global/zhao.Du/share/planning/0401_weekly/file_save_dlb.txt",
        ],
        "tag_prefix": "huailai_cos:ad-cn-hlidc-fdm-static/Tag_Static_Agg/250321_250401_weekly_copilot_tags_0401",
        "subdataset_config": [
            {
                "subdataset_name": "all_data",
                "sample_filters": copy.deepcopy(base_sample_filters),
                "post_processors": copy.deepcopy(base_post_processors),
            },
            {
                "subdataset_name": "uturn_data",
                "sample_filters": copy.deepcopy(uturn_sample_filters),
                "post_processors": copy.deepcopy(uturn_post_processors),
            },
            {
                "subdataset_name": "three_point_turn_data",
                "sample_filters": copy.deepcopy(three_point_turn_sample_filters),
                "post_processors": copy.deepcopy(uturn_post_processors),
            },
        ],
    },
]
