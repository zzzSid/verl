# -*- coding: utf-8 -*-
# flake8: noqa
# type: ignore
# pylint: disable=logging-fstring-interpolation
"""Common filters for planner dataset."""
import pickle as pkl
from itertools import count

import numpy as np

from tpp_onemodel.tools.astra_planner.data.data_filter.common_utils import (
    niofs_load_file_from_ceph,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.common_utils import (
    read_bytes_from_ceph,
)


class BaseClipProcessor:
    """Base clip processor."""

    _ids = count(0)

    def __init__(self, namespace=None):
        """Init."""
        self.namespace = namespace

        self.name = "base_clip_processor"
        self.id = next(self._ids)

    def __call__(self, clip_sample):
        """Call."""
        return clip_sample

    @staticmethod
    def common_process(record_stats=False):
        """Process."""

        def decorator(func):
            """Decorator."""

            def func_with_recorder(self, clip_sample, *args, **kwargs):
                """Function."""
                if self.namespace is not None:
                    frame_samples = clip_sample["frame_sample"]
                    selected_frame_samples = [
                        sample for sample in frame_samples if self.namespace in sample["current"][0]["namespace"]
                    ]
                    remain_frame_samples = [
                        sample for sample in frame_samples if self.namespace not in sample["current"][0]["namespace"]
                    ]

                    if len(selected_frame_samples) == 0:
                        return clip_sample
                    clip_sample["frame_sample"] = selected_frame_samples

                if record_stats:
                    stats = {
                        "input_clips": int(len(clip_sample["frame_sample"]) > 0),
                        "input_frames": len(clip_sample["frame_sample"]),
                    }
                result = func(self, clip_sample, *args, **kwargs)
                if record_stats:
                    stats.update(
                        {
                            "output_clips": int(len(clip_sample["frame_sample"]) > 0),
                            "output_frames": len(clip_sample["frame_sample"]),
                        }
                    )
                    clip_sample["stats"][f"{self.name}_{self.id}"].update(stats)

                if self.namespace is not None and len(remain_frame_samples) > 0:
                    clip_sample["frame_sample"].extend(remain_frame_samples)
                return result

            return func_with_recorder

        return decorator

    def reset_stats(self):
        """Reset stats."""
        self.stats = {
            "input_clips": 0,
            "input_frames": 0,
            "output_clips": 0,
            "output_frames": 0,
        }

    def gather_stats(self, stats):
        """Gather stats."""
        if stats is None:
            return
        for key, value in stats.items():
            self.stats[key] += value

    def show_stats(self, logger, time_interval=0.0):
        """Show stats."""
        logger.info(f"=> Summary of {self.name}_{self.id}, avg time cost: {time_interval * 1000:f}ms")
        for key, value in self.stats.items():
            logger.info(f"    : {key}: {value}")


class GenerateWindow(BaseClipProcessor):
    """Generate window."""

    def __init__(
        self,
        history_frames_num=14,
        future_frames_num=35,
        slide_step=1,
        **kwargs,
    ):
        """Init."""
        super().__init__(**kwargs)
        self.history_frames_num = history_frames_num
        self.future_frames_num = future_frames_num
        self.slide_step = slide_step

        self.name = "generate_window"

    @BaseClipProcessor.common_process(record_stats=False)
    def __call__(self, clip_sample):
        """Call."""
        num_frames = clip_sample["frame_num"]
        frame_samples = clip_sample["frame_sample"]
        window_samples = []
        for current in range(num_frames):
            history_start = max(0, current - self.history_frames_num)
            history_end = current
            future_start = current + 1
            future_end = min(num_frames, current + 1 + self.future_frames_num)

            history = list(range(history_start, history_end))
            history = [-1] * (self.history_frames_num - len(history)) + history
            future = list(range(future_start, future_end))
            future = future + [-1] * (self.future_frames_num - len(future))
            current_frame = [current]

            window_samples.append(
                {
                    "current": [frame_samples[idx] for idx in current_frame],
                    "history": [frame_samples[idx] if idx != -1 else None for idx in history],
                    "future": [frame_samples[idx] if idx != -1 else None for idx in future],
                }
            )

        clip_sample["frame_sample"] = window_samples[:: self.slide_step]
        return clip_sample

    def reset_stats(self):
        """Reset stats."""

    def gather_stats(self, stats):
        """Gather stats."""

    def show_stats(self, logger, time_interval=0.0):
        """Show stats."""
        logger.info(f"=> Summary of {self.name}_{self.id}, avg time cost: {time_interval * 1000:f}ms")


class LoadSensorInfoFromCeph(BaseClipProcessor):
    """Load sensor info from ceph."""

    def __init__(self, sensor_map, niofs_mode=False, **kwargs):
        """Init."""
        super().__init__(**kwargs)
        self.sensor_map = sensor_map
        self.niofs_mode = niofs_mode

        self.name = "load_sensor_info_from_ceph"

    @staticmethod
    def _parse_bytes_from_buffer(data_bytes, shape, dtype=np.float32):
        """Parse bytes from buffer."""
        return np.frombuffer(data_bytes, dtype=dtype).reshape(shape)

    def _parse_nested_list(self, bytes_list, shapes, dtype=np.float32):
        """Parse nested list."""
        return [self._parse_bytes_from_buffer(bytes_list[i], shapes[i], dtype) for i in range(len(bytes_list))]

    def _parse_sensor_info(self, sensor_bytes, sensor_key):
        """Parse sensor info."""
        sensor_info = {}

        if sensor_key == "lane":
            sensor_info["lane_points"] = self._parse_nested_list(
                sensor_bytes["lane_points"], sensor_bytes["lane_points_shape"]
            )
            sensor_info["lane_types"] = self._parse_bytes_from_buffer(
                sensor_bytes["lane_types"], sensor_bytes["lane_types_shape"]
            )

        elif sensor_key == "navi_line":
            sensor_info["navi_line_points"] = self._parse_nested_list(
                sensor_bytes["navi_line_points"], sensor_bytes["navi_line_points_shape"]
            )
            sensor_info["navi_line_types"] = 4 * np.ones(len(sensor_info["navi_line_points"]), dtype=np.float32)
            sensor_info["navi_lane_tld"] = np.array(
                self._parse_nested_list(
                    sensor_bytes["navi_lane_tld"], sensor_bytes["navi_lane_tld_shape"], dtype=np.int32
                ),
            )
            # 6x1x3
            sensor_info["navi_lane_speed_limit"] = np.array(
                self._parse_nested_list(
                    sensor_bytes["navi_lane_speed_limit"], sensor_bytes["navi_lane_speed_limit_shape"]
                ),
                dtype=object,
            )

        elif sensor_key == "navi_path":
            sensor_info["navi_path_points"] = self._parse_nested_list(
                sensor_bytes["navi_path_points"], sensor_bytes["navi_path_points_shape"]
            )
            sensor_info["navi_path_types"] = -1 * np.ones(len(sensor_info["navi_path_points"]), dtype=np.float32)
            sensor_info["navi_path_tld"] = np.array(
                self._parse_nested_list(
                    sensor_bytes["navi_path_tld"], sensor_bytes["navi_path_tld_shape"], dtype=np.int32
                ),
            )

            if (
                sensor_info["navi_path_tld"].shape[-1] >= 5
                and len(sensor_info["navi_path_tld"]) >= 1
                and sensor_info["navi_path_tld"][0][0] == 2
            ):
                navi_path_tld_info = sensor_info["navi_path_tld"][0]
                if navi_path_tld_info[0] == 2 and navi_path_tld_info[2] == 65535 and navi_path_tld_info[3] == 1:
                    navi_path_tld_info[2] = min(max(0, int(4 - navi_path_tld_info[4] / 1000)), 3)
                    sensor_info["navi_path_tld"][0] = navi_path_tld_info

            sensor_info["navi_path_lc_attr"] = np.array(
                self._parse_nested_list(
                    sensor_bytes["navi_path_lc_attr"], sensor_bytes["navi_path_lc_attr_shape"], dtype=np.float32
                )
            )

            sensor_info["navi_path_stoppoints"] = np.array(
                self._parse_nested_list(
                    sensor_bytes["navi_path_stoppoints"], sensor_bytes["navi_path_stoppoints_shape"], dtype=np.float32
                )
            )

        elif sensor_key == "sdmap":
            sensor_info["sdmap_geo"] = self._parse_nested_list(sensor_bytes["sdmap"], sensor_bytes["sdmap_shape"])
            sensor_info["sd_link_ids"] = self._parse_bytes_from_buffer(
                sensor_bytes["sd_link_ids"], sensor_bytes["sd_link_ids_shape"], dtype=np.uint64
            )

        elif sensor_key == "atlas":
            sensor_info["atlas"] = {
                "main_ground": self._parse_nested_list(
                    sensor_bytes["atlas"]["main_ground"],
                    sensor_bytes["atlas"]["main_ground_shape"],
                ),
                "foreground": self._parse_nested_list(
                    sensor_bytes["atlas"]["foreground"],
                    sensor_bytes["atlas"]["foreground_shape"],
                ),
                "unsafe_area": self._parse_nested_list(
                    sensor_bytes["atlas"]["unsafe_area"],
                    sensor_bytes["atlas"]["unsafe_area_shape"],
                ),
            }

        elif sensor_key == "atlas_bev":
            sensor_info["atlas_bev"] = self._parse_bytes_from_buffer(
                sensor_bytes["atlas_bev"], sensor_bytes["atlas_bev_shape"], dtype=np.uint8
            )

        elif sensor_key == "static_polys":
            sensor_info["static_polys"] = self._parse_bytes_from_buffer(
                sensor_bytes["static_polys"]["points"], (-1, 2), dtype=np.float32
            )
            sensor_info["static_poly_split"] = sensor_bytes["static_polys"]["counts"]

        elif sensor_key == "static_dets":
            sensor_info["static_dets"] = self._parse_bytes_from_buffer(
                sensor_bytes["static_dets"], sensor_bytes["static_dets_shape"]
            )
            sensor_info["static_polys"] = self._parse_bytes_from_buffer(
                sensor_bytes["static_polys"]["points"], (-1, 2), dtype=np.float32
            )
            sensor_info["static_poly_split"] = sensor_bytes["static_polys"]["counts"]

        elif sensor_key == "dynamic_gods":
            sensor_info["dynamic_gods"] = self._parse_bytes_from_buffer(
                sensor_bytes["dynamic_gods"], sensor_bytes["dynamic_gods_shape"]
            )
            sensor_info["dynamic_gods_polys"] = self._parse_bytes_from_buffer(
                sensor_bytes["dynamic_gods_polys"]["points"], (-1, 2), dtype=np.float32
            )
            sensor_info["dynamic_gods_polys_split"] = sensor_bytes["dynamic_gods_polys"]["counts"]

        elif sensor_key == "meta":
            sensor_info["car_poses"] = self._parse_bytes_from_buffer(sensor_bytes["car_pose"], (4, 4))
            sensor_info["ego_motion"] = self._parse_bytes_from_buffer(
                sensor_bytes["ego_motion"], (12,)
            )  # vx, vy, acc_x, acc_y, yaw[2], yaw_rate[2], whlag, whlagspd, vehspd, lgta, chassis_yawrate

        elif sensor_key == "manner_lane":
            sensor_info["manner_lane_points"] = self._parse_nested_list(
                sensor_bytes["manner_lane_points"], sensor_bytes["manner_lane_points_shape"]
            )
            sensor_info["manner_lane_types"] = self._parse_bytes_from_buffer(
                sensor_bytes["manner_lane_types"], sensor_bytes["manner_lane_types_shape"]
            )
            if "manner_lane_attr" in sensor_bytes:
                sensor_info["manner_lane_attr"] = self._parse_nested_list(
                    sensor_bytes["manner_lane_attr"], sensor_bytes["manner_lane_attr_shape"], np.int16
                )

        else:
            if sensor_key in sensor_bytes and f"{sensor_key}_shape" in sensor_bytes:
                sensor_info[sensor_key] = self._parse_bytes_from_buffer(
                    sensor_bytes[sensor_key], sensor_bytes[f"{sensor_key}_shape"]
                )
            else:
                raise NotImplementedError(f"Unknown sensor type: {sensor_key}")

        return sensor_info

    @staticmethod
    def merge_ceph_path(ceph_path_list):
        """Merge ceph path."""
        merged_ceph_path = []

        all_ceph_path_map = {
            ceph_path.split(" ")[0]: {
                "file_size": ceph_path.split(" ")[1],
                "start_bytes": None,
                "end_bytes": None,
            }
            for ceph_path in ceph_path_list
        }
        for ceph_path in ceph_path_list:
            file_path, _, start_bytes, read_size = ceph_path.split(" ")
            start_bytes, read_size = int(start_bytes), int(read_size)
            end_bytes = start_bytes + read_size
            if (
                all_ceph_path_map[file_path]["start_bytes"] is None
                or start_bytes < all_ceph_path_map[file_path]["start_bytes"]
            ):
                all_ceph_path_map[file_path]["start_bytes"] = start_bytes
            if (
                all_ceph_path_map[file_path]["end_bytes"] is None
                or end_bytes > all_ceph_path_map[file_path]["end_bytes"]
            ):
                all_ceph_path_map[file_path]["end_bytes"] = end_bytes

        merged_ceph_path = [
            (
                f"{file_path} "
                f"{file_dict['file_size']} "
                f"{file_dict['start_bytes']} "
                f"{file_dict['end_bytes'] - file_dict['start_bytes']}"
            )
            for file_path, file_dict in all_ceph_path_map.items()
        ]
        return merged_ceph_path

    @BaseClipProcessor.common_process(record_stats=False)
    def __call__(self, clip_sample):
        """Call."""
        frame_samples = clip_sample["frame_sample"]

        all_ceph_path_map = {}
        for window_sample in frame_samples:
            for state in ["history", "current", "future"]:
                for frame_sample in window_sample[state]:
                    if frame_sample is None:
                        continue
                    for sensor_name in self.sensor_map[state]:
                        sensor_key = f"{sensor_name}_{frame_sample['index']}"
                        all_ceph_path_map[sensor_key] = frame_sample["sensor_ceph_path"][sensor_name]

        sensor_keys = list(all_ceph_path_map.keys())
        ceph_path_list = [all_ceph_path_map[sensor_key] for sensor_key in sensor_keys]

        merged_ceph_path_list = self.merge_ceph_path(ceph_path_list)
        if not self.niofs_mode:
            all_sensor_bytes = read_bytes_from_ceph(merged_ceph_path_list)
        else:
            all_sensor_bytes = niofs_load_file_from_ceph(merged_ceph_path_list)
        merged_ceph_path_dict = {
            ceph_path.split(" ")[0]: {"start_bytes": int(ceph_path.split(" ")[2]), "sensor_bytes": sensor_bytes}
            for ceph_path, sensor_bytes in zip(merged_ceph_path_list, all_sensor_bytes)
        }

        all_sensor_bytes_map = {}
        for ceph_path, sensor_key in zip(ceph_path_list, sensor_keys):
            file_path, _, start_bytes, read_size = ceph_path.split(" ")
            start_bytes, read_size = int(start_bytes), int(read_size)
            merged_sensor_bytes = merged_ceph_path_dict[file_path]["sensor_bytes"]
            sensor_info = None
            if merged_sensor_bytes is not None:
                rel_start_bytes = start_bytes - merged_ceph_path_dict[file_path]["start_bytes"]
                sensor_bytes = merged_sensor_bytes[rel_start_bytes : rel_start_bytes + read_size]
                sensor_info = self._parse_sensor_info(pkl.loads(sensor_bytes), sensor_key.rsplit("_", 1)[0])

            all_sensor_bytes_map[sensor_key] = sensor_info

        updated_frame_samples = []
        for window_sample in frame_samples:
            sample_valid = all(
                all(
                    all(
                        all_sensor_bytes_map.get(f"{sensor_name}_{frame_sample['index']}") is not None
                        for sensor_name in self.sensor_map[state]
                    )
                    for frame_sample in window_sample[state]
                    if frame_sample
                )
                for state in ["history", "current", "future"]
            )
            if not sample_valid:
                clip_id = window_sample["current"][0]["clip_id"]
                print(f"window_sample invalid,clip_id : {clip_id}")
                continue
            for state in ["history", "current", "future"]:
                for frame_sample in window_sample[state]:
                    if frame_sample is None:
                        continue
                    for sensor_name in self.sensor_map[state]:
                        frame_sample.update(all_sensor_bytes_map[f"{sensor_name}_{frame_sample['index']}"])
            updated_frame_samples.append(window_sample)

        clip_sample["frame_sample"] = updated_frame_samples
        return clip_sample

    def reset_stats(self):
        """Reset stats."""

    def gather_stats(self, stats):
        """Gather stats."""

    def show_stats(self, logger, time_interval=0.0):
        """Show stats."""
        logger.info(f"=> Summary of {self.name}_{self.id}, avg time cost: {time_interval * 1000:f}ms")


class IntegratedFrameFilter(BaseClipProcessor):
    """Integrated frame filter."""

    def __init__(self, frame_filters=None, **kwargs):
        """Init."""
        super().__init__(**kwargs)
        self.frame_filters = frame_filters

        self.name = "integrated_frame_filter"
        self.reset_stats()

    @BaseClipProcessor.common_process(record_stats=True)
    def __call__(self, clip_sample):
        """Call."""
        if self.frame_filters is None or len(self.frame_filters) == 0:
            return clip_sample

        frame_samples = clip_sample["frame_sample"]
        filtered_samples = []

        all_success_flags = []
        for frame_sample in frame_samples:
            success_flags = [-1] * len(self.frame_filters)
            for i_filter, _filter in enumerate(self.frame_filters):
                if not _filter(frame_sample):
                    success_flags[i_filter] = 0
                    break
                else:
                    success_flags[i_filter] = 1
            all_success_flags.append(success_flags)

            if success_flags[-1] != 1:
                continue
            filtered_samples.append(frame_sample)

        clip_sample["frame_sample"] = filtered_samples

        stats = {
            **{
                f"filtered_frames_by_{self.frame_filters[i].name}_{self.frame_filters[i].id}": sum(
                    [k[i] == 0 for k in all_success_flags]
                )
                for i in range(len(self.frame_filters))
            },
        }
        clip_sample["stats"][f"{self.name}_{self.id}"] = stats
        return clip_sample

    def reset_stats(self):
        """Reset stats."""
        super().reset_stats()
        self.stats.update(
            {
                f"filtered_frames_by_{self.frame_filters[i].name}_{self.frame_filters[i].id}": 0
                for i in range(len(self.frame_filters))
            }
        )


class MissingTagFileFilter(BaseClipProcessor):
    """Missing tag file filter."""

    def __init__(self, **kwargs):
        """Init."""
        super().__init__(**kwargs)

        self.name = "missing_tag_file_filter"
        self.reset_stats()

    @BaseClipProcessor.common_process(record_stats=True)
    def __call__(self, clip_sample):
        """Call."""
        clip_tag_info = clip_sample["clip_tag_info"]
        if clip_tag_info is None:
            clip_sample["frame_sample"] = []
        return clip_sample


class NoTrainTagFileFilter(BaseClipProcessor):
    """No train tag file filter."""

    def __init__(self, **kwargs):
        """Init."""
        super().__init__(**kwargs)

        self.name = "no_train_tag_file_filter"
        self.reset_stats()

    @BaseClipProcessor.common_process(record_stats=True)
    def __call__(self, clip_sample):
        """Call."""
        clip_tag_info = clip_sample["clip_tag_info"]

        clip_usage_train_tag_found = False
        for _, tag_list in clip_tag_info.items():
            if not clip_usage_train_tag_found:
                for tag in tag_list:
                    if "da.clip_usage.train" in tag:
                        clip_usage_train_tag_found = True
                        break
            if clip_usage_train_tag_found:
                break

        if not clip_usage_train_tag_found:
            clip_sample["frame_sample"] = []

        return clip_sample


class MissingFFTTagFilter(BaseClipProcessor):
    """Missing fft tag filter."""

    def __init__(self, **kwargs):
        """Init."""
        super().__init__(**kwargs)

        self.name = "missing_fft_tag_filter"
        self.reset_stats()

    @BaseClipProcessor.common_process(record_stats=True)
    def __call__(self, clip_sample):
        """Call."""
        clip_tag_info = clip_sample["clip_tag_info"]

        fft_tag_found = False
        for _, tag_list in clip_tag_info.items():
            if not fft_tag_found:
                for tag in tag_list:
                    if "fft_data_cleaning" in tag:
                        continue
                    if "fft" in tag:
                        fft_tag_found = True
                        break
            if fft_tag_found:
                break

        if fft_tag_found:
            for sample in clip_sample["frame_sample"]:
                sample["namespace"].append("wtag")
        else:
            for sample in clip_sample["frame_sample"]:
                sample["namespace"].append("wotag")

        return clip_sample


class TagIncludeWriter(BaseClipProcessor):
    """Tag include writer."""

    def __init__(self, included_tag_list, **kwargs):
        """Init."""
        super().__init__(**kwargs)
        self.included_tag_list = included_tag_list

        self.name = "tag_include_writer"
        self.reset_stats()

    @BaseClipProcessor.common_process(record_stats=True)
    def __call__(self, clip_sample):
        """Call."""
        frame_samples = clip_sample["frame_sample"]

        for frame_sample in frame_samples:
            for namespace, tag_list in self.included_tag_list.items():
                if set(tag_list) & set(frame_sample["current"][0]["tags"]):
                    frame_sample["current"][0]["namespace"].append(namespace)

        return clip_sample


class RemoveDataFilter(BaseClipProcessor):
    """Remove data filter."""

    def __init__(self, **kwargs):
        """Init."""
        super().__init__(**kwargs)

        self.name = "remove_data_filter"
        self.reset_stats()

    @BaseClipProcessor.common_process(record_stats=True)
    def __call__(self, clip_sample):
        """Call."""
        clip_sample["frame_sample"] = []

        return clip_sample
