# -*- coding: utf-8 -*-
# flake8: noqa
# type: ignore
# pylint: disable=logging-fstring-interpolation
"""Trigger of planner data filter."""
import argparse
import logging
import multiprocessing
import os
import pickle as pkl
import time
from collections import defaultdict
from functools import partial

from torchpilot.utils.cfg_parser import PyConfig
from tqdm import tqdm

from tpp_onemodel.tools.astra_planner.data.data_filter.common_utils import TimeCounter
from tpp_onemodel.tools.astra_planner.data.data_filter.common_utils import (
    convert_tag_objs,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.common_utils import (
    generate_ceph_path,
)
from tpp_onemodel.tools.astra_planner.data.data_filter.common_utils import (
    read_bytes_from_ceph,
)


logger = logging.getLogger(__name__)

sample_filters = []


def generate_single_clip_samples(ceph_pair_info_path, load_timestamp_from_key="timestamp_list"):
    """Generate single clip samples."""
    global sample_filters

    data_info_path = ceph_pair_info_path["data_info_path"]
    tag_info_path = ceph_pair_info_path["tag_info_path"]

    pair_data_bytes = read_bytes_from_ceph([data_info_path, tag_info_path])
    data_info = pkl.loads(pair_data_bytes[0])
    tag_info = pkl.loads(pair_data_bytes[1]) if pair_data_bytes[1] is not None else None

    ceph_path_root = os.path.dirname(os.path.dirname(data_info_path))
    sensor_list = list(data_info["annos"].keys())
    sensor_info_path_dict = {
        sensor_name: f"{ceph_path_root}/{sensor_name}.dat {data_info['cephpath_filesize'][sensor_name]}"
        for sensor_name in sensor_list
    }

    clip_tag_info = None
    if tag_info is not None:
        clip_tag_info = {}
        for timestamp, tag_objs in tag_info.items():
            clip_tag_info[timestamp] = convert_tag_objs(tag_objs)

    num_frames = len(data_info[load_timestamp_from_key])
    frame_samples = []
    for i_frame in range(num_frames):
        timestamp = data_info[load_timestamp_from_key][i_frame]
        frame_sample = {
            "index": i_frame,
            "clip_id": data_info_path.split("/")[3],
            "timestamp": timestamp,
            "namespace": [],
        }
        frame_sample.update(
            {
                "sensor_ceph_path": {
                    sensor_name: (
                        f"{ceph_path_root}/{sensor_name}.dat "
                        f"{data_info['cephpath_filesize'][sensor_name]} "
                        f"{data_info['annos'][sensor_name][i_frame][0]} "
                        f"{data_info['annos'][sensor_name][i_frame][1]}"
                    )
                    for sensor_name in sensor_list
                }
            }
        )

        if clip_tag_info is not None:
            tag_list = clip_tag_info.get(
                f"{int(timestamp)}", ["astra_planner.data_filter.missing_tag.timestamp_mismatch"]
            )
        else:
            tag_list = ["astra_planner.data_filter.missing_tag.file_not_found"]

        frame_sample.update({"tags": tag_list})
        frame_samples.append(frame_sample)

    clip_sample = {
        "clip_id": data_info_path.split("/")[3],
        "meta_ceph_path": data_info_path,
        "tag_ceph_path": tag_info_path,
        "sensor_ceph_path": sensor_info_path_dict,
        "frame_num": num_frames,
        "frame_sample": frame_samples,
        "clip_tag_info": clip_tag_info,
        "extra": {},
        "stats": defaultdict(dict),
    }
    time_interval = []
    for _filter in sample_filters:
        start_time = time.time()
        clip_sample = _filter(clip_sample)
        time_interval.append(time.time() - start_time)
        if len(clip_sample["frame_sample"]) == 0:
            break

    if len(time_interval) < len(sample_filters):
        time_interval.extend([0.0] * (len(sample_filters) - len(time_interval)))

    valid_timestamps = [frame_sample["current"][0]["timestamp"] for frame_sample in clip_sample["frame_sample"]]
    valid_indices = [frame_sample["current"][0]["index"] for frame_sample in clip_sample["frame_sample"]]
    valid_namespaces = [frame_sample["current"][0]["namespace"] for frame_sample in clip_sample["frame_sample"]]

    if len(valid_indices) > 0:
        sample_list = {
            "meta_ceph_path": clip_sample["meta_ceph_path"],
            "tag_ceph_path": clip_sample["tag_ceph_path"],
            "frame_num": clip_sample["frame_num"],
            "selected_timestamp": valid_timestamps,
            "selected_frame_idx": valid_indices,
            "namespaces": valid_namespaces,
            "extra": clip_sample["extra"],
        }
    else:
        sample_list = None
    return sample_list, clip_sample["stats"], time_interval


def generate_dataset(config, dump_root="./export_data", num_workers=64, logger=None):
    """Generate dataset."""
    saving_file_list = []

    for dataset_cfg in config:
        dataset_name = dataset_cfg["dataset_name"]
        dataset_list = dataset_cfg["dataset_list"]
        tag_prefix = dataset_cfg["tag_prefix"]
        load_timestamp_from_key = dataset_cfg.get("load_timestamp_from_key", "timestamp_list")
        subdataset_config = dataset_cfg["subdataset_config"]

        data_info_path_list = []
        for dataset_file in dataset_list:
            with open(dataset_file, "r") as fr:
                lines = fr.readlines()
                lines = [line.strip() for line in lines]
                data_info_path_list.extend(lines)

        pair_info_path_list = []
        for data_info_path in data_info_path_list:
            tag_info_path = data_info_path.split("/")
            tag_info_path = [tag_prefix] + tag_info_path[3:]
            tag_info_path = "/".join(tag_info_path)
            tag_info_path = os.path.join(
                os.path.dirname(tag_info_path).replace("meta_data", "tags"),
                os.path.basename(tag_info_path).replace(".pkl", "_tags.pkl"),
            )
            pair_info_path_list.append([data_info_path, tag_info_path])
        logger.info(f"=> Total clip num: {len(pair_info_path_list)}")

        if num_workers <= 1:
            ceph_pair_info_path_list = []
            for pair_info_path in tqdm(pair_info_path_list, desc="Generate ceph path"):
                ceph_pair_info_path = generate_ceph_path(pair_info_path)
                ceph_pair_info_path_list.append(ceph_pair_info_path)
        else:
            ceph_pair_info_path_list = []
            with multiprocessing.Pool(num_workers) as pool:
                results = tqdm(
                    pool.imap(generate_ceph_path, pair_info_path_list),
                    total=len(pair_info_path_list),
                    desc="Generate ceph path",
                )
                for result in results:
                    if result is not None:
                        ceph_pair_info_path_list.append(result)
        logger.info(f"=> Total clip num after filter missing meta info: {len(ceph_pair_info_path_list)}")

        clip_info_map = {}
        for ceph_pair_info_path in tqdm(ceph_pair_info_path_list, desc="Remove repeat"):
            clip_id = ceph_pair_info_path["data_info_path"].split("/")[3]
            if clip_id not in clip_info_map:
                clip_info_map[clip_id] = ceph_pair_info_path
        ceph_pair_info_path_list = list(clip_info_map.values())
        logger.info(f"=> Total clip num after remove repeat: {len(ceph_pair_info_path_list)}")

        for i_cfg, subdataset_cfg in enumerate(subdataset_config):
            global sample_filters

            subdataset_name = subdataset_cfg["subdataset_name"]
            sample_filters = subdataset_cfg["sample_filters"]
            post_processors = subdataset_cfg["post_processors"]
            generate_sample_func = partial(
                generate_single_clip_samples,
                load_timestamp_from_key=load_timestamp_from_key,
            )

            all_data_list = []
            timer = defaultdict(TimeCounter)
            if num_workers <= 1:
                for ceph_pair_info_path in tqdm(ceph_pair_info_path_list, desc=f"Generate subdataset {i_cfg}"):
                    sample_list, stats, time_interval = generate_sample_func(ceph_pair_info_path)
                    if sample_list is not None:
                        all_data_list.append(sample_list)
                    for i_filter, _filter in enumerate(sample_filters):
                        _filter.gather_stats(stats.get(f"{_filter.name}_{_filter.id}", None))
                        timer[f"{_filter.name}_{_filter.id}"].add_record(time_interval[i_filter])
            else:
                with multiprocessing.Pool(num_workers) as pool:
                    results = tqdm(
                        pool.imap(generate_sample_func, ceph_pair_info_path_list),
                        total=len(ceph_pair_info_path_list),
                        desc=f"Generate subdataset {i_cfg}",
                    )
                    for result in results:
                        sample_list, stats, time_interval = result
                        if sample_list is not None:
                            all_data_list.append(sample_list)
                        for i_filter, _filter in enumerate(sample_filters):
                            _filter.gather_stats(stats.get(f"{_filter.name}_{_filter.id}", None))
                            timer[f"{_filter.name}_{_filter.id}"].add_record(time_interval[i_filter])

            for _filter in sample_filters:
                _filter.show_stats(logger, time_interval=timer[f"{_filter.name}_{_filter.id}"].show_record())

            all_data_list = {
                "total": {
                    "data_list": all_data_list,
                    "dump_root": dump_root,
                    "dataset_name": dataset_name,
                    "subdataset_name": subdataset_name,
                },
            }
            for post_processor in post_processors:
                all_data_list = post_processor(all_data_list, logger)

            if "save_path" in all_data_list["total"]:
                saving_file_list.append(all_data_list["total"]["save_path"])

    return saving_file_list


if __name__ == "__main__":
    # Sample:
    #   python tpp_onemodel/tools/astra_planner/data/data_filter/trigger.py \
    #     -cfg tpp_onemodel/tools/astra_planner/data/data_filter/config/config_data_v0918.py
    parser = argparse.ArgumentParser()
    parser.add_argument("-cfg", "--config_path", type=str, required=True, help="config path")
    parser.add_argument("-d", "--dump_root", type=str, default="./export_data", help="dump root")
    parser.add_argument("-w", "--num_workers", type=int, default=64, help="num workers")
    args = parser.parse_args()

    cfg = PyConfig.fromfile(args.config_path)

    logger.setLevel(logging.INFO)

    os.makedirs(args.dump_root, exist_ok=True)
    cur_time = time.strftime("%Y_%m_%d_%H_%M_%S", time.localtime())
    log_path = os.path.join(args.dump_root, f"log_{cfg.config[0]['dataset_name']}_{cur_time}.txt")
    fh = logging.FileHandler(log_path)
    fh.setLevel(logging.INFO)
    logger.addHandler(fh)

    generate_dataset(cfg.config, args.dump_root, args.num_workers, logger=logger)
