# -*- coding: utf-8 -*-
# flake8: noqa
# type: ignore
"""Common utils."""
import niofs
from botocore.exceptions import ClientError
from read_cache_op_py import read_cache_op_py


ceph_client = niofs.Client("81fbac8cd8abdee5", "1c46fdaf88a24f35b7f68289e6e236ce")


class TimeCounter:
    """Time counter."""

    def __init__(self):
        """Init."""
        self.average_time = 0.0
        self.count = 0

    def add_record(self, time_interval):
        """Add record."""
        self.average_time = (self.average_time * self.count + time_interval) / (self.count + 1)
        self.count += 1

    def reset(self):
        """Reset."""
        self.average_time = 0.0
        self.count = 0

    def show_record(self):
        """Show record."""
        return self.average_time


def get_ceph_size(ceph_path):
    """Get ceph size."""
    try:
        bucket_name, path = ceph_path[1:].split("/", 1)
        response_info = ceph_client.head_object(Bucket=bucket_name, Key=path)
        size = response_info["ContentLength"]
    except ClientError as e:  # pylint: disable=unused-variable
        # print(f"Error occurred when reading file {ceph_path}, skip this clip")
        # print(f"Error info: {e}")
        size = -1
    return size


def generate_ceph_path(pair_info_path):
    """Generate ceph path."""
    data_info_path, tag_info_path = pair_info_path

    ceph_pair_info_path = {}
    for key, info_path in zip(["data_info_path", "tag_info_path"], [data_info_path, tag_info_path]):
        if info_path.startswith("huailai_cos:"):
            ceph_path = "/" + info_path[len("huailai_cos:") :]
        else:
            raise NotImplementedError(f"Unknown prefix: {ceph_path}")

        if (size := get_ceph_size(ceph_path)) > 0:
            ceph_path = f"{info_path} {size}"
        else:
            if key == "tag_info_path":
                ceph_path = None
            else:
                return None

        ceph_pair_info_path[key] = ceph_path
    return ceph_pair_info_path


def read_bytes_from_ceph(ceph_path_list):
    """Read bytes from ceph."""
    indices_none = [idx for idx, ceph_path in enumerate(ceph_path_list) if ceph_path is None]
    ceph_path_list = [ceph_path for ceph_path in ceph_path_list if ceph_path is not None]

    for idx, ceph_path in enumerate(ceph_path_list):
        if ceph_path.startswith("huailai_cos:"):
            ceph_path_list[idx] = "/" + ceph_path[len("huailai_cos:") :]
        else:
            raise NotImplementedError(f"Unknown prefix: {ceph_path}")

    data_bytes_list = read_cache_op_py(ceph_path_list)
    if len(indices_none) > 0:
        for idx in indices_none:
            data_bytes_list.insert(idx, None)
    return data_bytes_list


def niofs_load_file_from_ceph(ceph_path_list):
    """Load file from ceph by niofs."""
    data_bytes_list = []
    for ceph_path in ceph_path_list:
        if ceph_path is None:
            data_bytes_list.append(None)
            continue

        if ceph_path.startswith("huailai_cos:"):
            ceph_path = "/" + ceph_path[len("huailai_cos:") :]
        else:
            raise NotImplementedError(f"Unknown prefix: {ceph_path}")

        ceph_path_split = ceph_path.split(" ")
        start_bytes, read_size, num_bytes = -1, -1, -1
        if len(ceph_path_split) == 4:
            ceph_file, num_bytes, start_bytes, read_size = ceph_path_split
            start_bytes, read_size, num_bytes = int(start_bytes), int(read_size), int(num_bytes)
        else:
            ceph_file = ceph_path_split[0]

        bucket_name, path = ceph_file[1:].split("/", 1)
        data_bytes = ceph_client.get_object(Bucket=bucket_name, Key=path)["Body"].read()
        if num_bytes != -1 and len(data_bytes) != num_bytes:
            data_bytes_list.append(None)
            continue
        if start_bytes > 0 and read_size > 0:
            data_bytes = data_bytes[start_bytes : start_bytes + read_size]
        data_bytes_list.append(data_bytes)

    return data_bytes_list


def convert_tag_objs(tag_objs):
    """Convert tag objs."""
    # Tag mode 1: {ts1: {'objs': [{'cate': tag1}, ...]}, ...}
    # Tag mode 2: {ts1: {'tag': [tag1, tag2, ...]}, ...}
    if "tag" in tag_objs:
        tag_list = tag_objs["tag"]
    elif "objs" in tag_objs:
        tag_list = [_["cate"] for _ in tag_objs["objs"]]
    else:
        tag_list = ["astra_planner.data_filter.missing_tag.missing_key"]

    return tag_list
