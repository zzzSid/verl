# -*- coding: utf-8 -*-
# flake8: noqa
# type: ignore
"""Frame filters for planner dataset."""
import pickle as pkl
from itertools import count

import numpy as np
from tqdm import tqdm


class BaseFrameFilter:
    """Base frame filter."""

    _ids = count(0)

    def __init__(self):
        """Init."""
        self.id = next(self._ids)

    def __call__(self, frame_sample):
        """Call."""
        return True


class PaddingFilterByFrame(BaseFrameFilter):
    """Padding filter by frame."""

    def __init__(
        self,
        history_frames_num=14,
        future_frames_num=35,
        input_sensor_map=None,
        allow_history_frame_is_none=0,
        allow_future_frame_is_none=0,
    ):
        """Init."""
        super().__init__()
        self.history_frames_num = history_frames_num
        self.future_frames_num = future_frames_num
        self.input_sensor_map = input_sensor_map
        self.allow_history_frame_is_none = allow_history_frame_is_none
        self.allow_future_frame_is_none = allow_future_frame_is_none
        self.name = self.__class__.__name__

    def __call__(self, frame_sample):
        """Check if sample is valid."""
        if self.history_frames_num != len(frame_sample["history"]):
            return False
        if any([item is None for item in frame_sample["history"][self.allow_history_frame_is_none :]]):
            return False

        if self.future_frames_num != len(frame_sample["future"]):
            return False
        if any(
            [
                item is None
                for item in frame_sample["future"][: self.future_frames_num - self.allow_future_frame_is_none]
            ]
        ):
            return False

        if self.input_sensor_map is not None:
            all_necessary_sensors = {item for sublist in self.input_sensor_map.values() for item in sublist}
            all_data_sensors = set(frame_sample["current"][0]["sensor_ceph_path"].keys())
            if not all_necessary_sensors.issubset(all_data_sensors):
                print(f"Missing sensors: {all_necessary_sensors - all_data_sensors}")
                return False
        return True


class TagIncludeFilterByFrame(BaseFrameFilter):
    """Tag Include filter by frame."""

    def __init__(
        self,
        included_tag_list=None,
    ):
        """Init."""
        super().__init__()
        self.included_tag_list = included_tag_list
        self.name = self.__class__.__name__

    def __call__(self, frame_sample):
        """Check if sample include all tags."""
        if not self.included_tag_list:
            return True
        current_tags = frame_sample["current"][0]["tags"]
        for tag in self.included_tag_list:
            is_found = False
            for current_tag in current_tags:
                if tag in current_tag:
                    is_found = True
                    break
            if not is_found:
                return False
        return True


class TagExcludeFilterByFrame(BaseFrameFilter):
    """Tag exclude filter by frame."""

    def __init__(
        self,
        excluded_tag_list=None,
    ):
        """Init."""
        super().__init__()
        self.excluded_tag_list = excluded_tag_list
        self.name = self.__class__.__name__

    def __call__(self, frame_sample):
        """Check if sample exclude all tags."""
        if not self.excluded_tag_list:
            return True
        current_tags = frame_sample["current"][0]["tags"]
        for tag in self.excluded_tag_list:
            for current_tag in current_tags:
                if tag in current_tag:
                    return False
        return True


class TimestampErrorFilterByFrame(BaseFrameFilter):
    """Timestamp error filter by frame."""

    def __init__(
        self,
        frame_interval=0.2,
        tolerance=0.01,  # 0.01 means 10ms
    ):
        """Init."""
        super().__init__()
        self.frame_interval = frame_interval
        self.tolerance = tolerance
        self.name = self.__class__.__name__

    def __call__(self, frame_sample):
        """Check if all timestamps satisfy requirements."""
        history_timestamps = [k["timestamp"] for k in frame_sample["history"] if k is not None]
        current_timestamps = [k["timestamp"] for k in frame_sample["current"] if k is not None]
        future_timestamps = [k["timestamp"] for k in frame_sample["future"] if k is not None]
        timestamps = np.array(history_timestamps + current_timestamps + future_timestamps)
        diff = np.abs(timestamps[1:] - timestamps[:-1] - self.frame_interval)
        no_pass = (diff > self.tolerance).any()
        if no_pass:
            return False
        return True


class TimestampAlignFilterByFrame(BaseFrameFilter):
    """Timestamp align filter by frame."""

    def __init__(
        self,
        frame_sample_pkl_path=None,
        max_time_interval=0.01,  # 0.01 means 10ms
    ):
        """Init."""
        super().__init__()
        self.frame_sample_pkl_path = frame_sample_pkl_path
        self.max_time_interval = max_time_interval
        self.name = self.__class__.__name__

        print("Loading frame sample list ...")
        with open(self.frame_sample_pkl_path, "rb") as fr:
            frame_sample_list = pkl.load(fr)

        clip_timestamp_map = {}
        for frame_sample in tqdm(frame_sample_list, desc="Load frame sample list"):
            clip_id = frame_sample["meta_ceph_path"].split("/")[3]
            selected_timestamps = frame_sample["selected_timestamp"]
            clip_timestamp_map[clip_id] = np.array(selected_timestamps)
        print("Load frame sample list done ...")
        print(f"    : Before: {len(frame_sample_list)}")
        print(f"    : After: {len(clip_timestamp_map)}")

        self.clip_timestamp_map = clip_timestamp_map

    def __call__(self, frame_sample):
        """Check if sample in given frame list."""
        clip_id = frame_sample["current"][0]["clip_id"]
        if clip_id not in self.clip_timestamp_map:
            return False

        timestamp = frame_sample["current"][0]["timestamp"]
        selected_timestamps = self.clip_timestamp_map[clip_id]
        min_interval = np.abs(selected_timestamps - timestamp).min()
        if min_interval > self.max_time_interval:
            return False
        return True
