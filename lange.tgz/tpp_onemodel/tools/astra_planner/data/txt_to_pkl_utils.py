# -*- coding: utf-8 -*-
# flake8: noqa
# type: ignore
"""Provide txt to pkl conversion utilities."""
import logging
from typing import List

from tqdm import tqdm

from tpp_onemodel.tools.astra_planner.data.data_filter.trigger import *


logger = logging.getLogger(__name__)


def txt_to_pkl(
    txt_path_list: list,
    cfg_path: str = "tpp_onemodel/tools/astra_planner/data/data_filter/config/config_data_demo.py",
    tag_version: str = "huailai_cos:ad-cn-hlidc-fdm-static/Tag_Static/prod_v20241228_all_tags",
    pkl_save_path: str = "./tmp/export_data",
    target_dataset_name: str = "test_data",
    num_workers: int = 1,
) -> List:
    """Convert multiple txt files to a single pkl."""
    os.makedirs(pkl_save_path, exist_ok=True)

    cfg = PyConfig.fromfile(cfg_path)
    cfg.config[0].dataset_list = txt_path_list
    cfg.config[0].tag_prefix = tag_version
    cfg.config[0].subdataset_config[0].tag_name = target_dataset_name

    gen_pkl_list = generate_dataset(cfg.config, pkl_save_path, num_workers, logger)
    return gen_pkl_list


def pkl_to_txt(
    pkl_path: str,
    txt_save_path: str = "./tmp_data/export_data",
    target_dataset_name: str = "test_data",
) -> List:
    """Convert a pkl file to a txt."""
    os.makedirs(txt_save_path, exist_ok=True)
    target_file_path = os.path.join(txt_save_path, f"{target_dataset_name}.txt")

    if type(pkl_path) == str:
        pkl_data = pkl.load(open(pkl_path, "rb"))
    else:
        pkl_data = pkl_path
    meta_list = []
    tag_version = "/".join(pkl_data[0]["tag_ceph_path"].split("/")[0:3]) if pkl_data[0]["tag_ceph_path"] else None
    for msg in tqdm(pkl_data):
        meta_list.append(msg["meta_ceph_path"].split(" ")[0])

    with open(target_file_path, "w") as f:
        for meta_path in meta_list:
            f.write(f"{meta_path}\n")
    print(f"Exported txt file to {target_file_path}")
    return target_file_path, tag_version


if __name__ == "__main__":
    txt_path_list = ["/share-global/mccree.zhao/share/planning/dataset/txt_to_pkl_test_data_1230/test_data.txt"]
    cfg_path = "tpp_onemodel/tools/astra_planner/data/data_filter/config/config_data_demo.py"
    pkl_save_path = "./tmp/export_data"
    txt_to_pkl(txt_path_list, cfg_path)

    pkl_path = "/share-global/xiangwei.geng/planner/planner_data/1127/planner_dataset_v1106_align_v0918_100ms_cicd_100_11743.pkl"
    txt_save_path = "./tmp_data/export_data"
    target_dataset_name = "test_data"
    pkl_to_txt(pkl_path, txt_save_path, target_dataset_name)
