# -*- coding: utf-8 -*-
from multiprocessing import Pool

import torchpilot

from tpp_onemodel.tools.astra_planner.data.data_utils.astra_planner_dataset_utils import (
    PlannerDatasetUtils,
)


logger = torchpilot.logger


if __name__ == "__main__":
    data_path = "/share-global/xiangwei.geng/planner/planner_data/1127/planner_dataset_v1106_align_v0918_100ms_cicd_100_11743.pkl"
    LOAD_ALL_FRAMES = True
    dataset = PlannerDatasetUtils(data_path, load_all_frames=LOAD_ALL_FRAMES)
    for clip in dataset:
        logger.info("clip: %s", clip)
        for frame in clip:
            logger.info("frame: %s", frame)
            frame_data = frame.frame_data
            logger.info("all data keys: %s", frame_data.keys())
            break
        break

    # index with id
    logger.warning("index with id demo.")

    frame_data = dataset[1][10]
    logger.info("frame data: %s", frame_data)
    logger.info("frame data keys: %s", frame_data.frame_data.keys())

    # index with clip id and timestamp
    logger.warning("index with clip id and timestamp demo.")

    demo_clip_id = "20240116T142000_LJ1E6A2UXPG005813_1705386120.000000_1705386179.000000"
    demo_timestamp = 1705386119.901
    frame_data = dataset[demo_clip_id][demo_timestamp]
    logger.info("frame data: %s", frame_data)
    logger.info("frame data keys: %s", frame_data.frame_data.keys())

    # multiprocess demo
    logger.warning("multiprocess demo.")

    def print_clip_all_frame_keys(idx):
        """Print clip all frame keys."""
        clip_data = dataset[idx]
        for frame in clip_data:
            logger.warning("processed %s", frame)

    with Pool(4) as p:
        p.map(print_clip_all_frame_keys, range(10))

    # vis demo
    logger.warning("vis demo.")

    frame_data.vis("tmp/test.jpg")
    clip_data = dataset[demo_clip_id]
    clip_data.vis("tmp", interval=10, dump_video=True)
