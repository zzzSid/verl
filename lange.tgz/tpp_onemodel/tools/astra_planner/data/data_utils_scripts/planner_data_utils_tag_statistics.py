# -*- coding: utf-8 -*-
import argparse
from collections import defaultdict
from multiprocessing import Pool
from pathlib import Path

from tqdm import tqdm

from tpp_onemodel.tools.astra_planner.data.data_utils.astra_planner_dataset_utils import (
    PlannerDatasetUtils,
)
from tpp_onemodel.tools.astra_planner.data.data_utils_scripts.tag_utils import (
    export2markdown,
)


def parse_args():
    """Parse arguments."""
    parser = argparse.ArgumentParser(description="Planner dataset tag statistics.")
    parser.add_argument(
        "-d",
        "--data_path",
        type=str,
        default="/share-global/wei.wang22/data/planner/v1219/planner_dataset_v1219_with_tag_train_343000_27283656.pkl",
        help="The path of planner dataset.",
    )
    parser.add_argument(
        "-o",
        "--output_dir",
        type=str,
        default="./export_data",
        help="The output directory of tag statistics.",
    )
    parser.add_argument(
        "-w",
        "--worker_num",
        type=int,
        default=64,
        help="The number of workers for multiprocessing.",
    )

    return parser.parse_args()


if __name__ == "__main__":
    LOAD_ALL_FRAMES = False
    CLIP_THRE = 1
    args = parse_args()
    dataset = PlannerDatasetUtils(
        args.data_path,
        load_all_frames=LOAD_ALL_FRAMES,
        frame_sensor_list=[],
        count_tag_by_level=True,
    )

    def tag_statistic(idx):
        """Get all tag counts."""
        clip_data = dataset[idx]
        return clip_data.frame_tag_counts

    tag_counts = {}  # type: ignore[var-annotated]
    results = []
    with Pool(args.worker_num) as p:
        results = list(tqdm(p.imap(tag_statistic, range(len(dataset))), total=len(dataset)))
        for res in results:
            for tag, count in res.items():
                if tag not in tag_counts:
                    tag_counts[tag] = defaultdict(int)
                tag_counts[tag]["frame_num"] += count
                tag_counts[tag]["clip_num"] += int(count >= CLIP_THRE)

    # dump tag statistics
    Path(args.output_dir).mkdir(parents=True, exist_ok=True)
    # print(f"Export tag statistics to {args.output_dir}")
    export2markdown(tag_counts, str(Path(args.output_dir) / f"{Path(args.data_path).stem}-tag_statistics.md"))
    # print("Done.")
