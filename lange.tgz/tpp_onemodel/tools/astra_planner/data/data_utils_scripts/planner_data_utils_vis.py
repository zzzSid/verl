# -*- coding: utf-8 -*-
# type: ignore
import random
from multiprocessing import Pool

from tpp_onemodel.tools.astra_planner.data.data_utils.astra_planner_dataset_utils import (
    PlannerDatasetUtils,
)
from tpp_onemodel.tools.astra_planner.data.txt_to_pkl_utils import txt_to_pkl


if __name__ == "__main__":
    data_path = "/share-global/xin.fu2/planning_data/release_data/0219_0224/planner_dataset_v0219_0224_all_data_val_10000_754876.pkl"
    if data_path.endswith(".txt"):
        data_path = txt_to_pkl([data_path], num_workers=16)[0]
    LOAD_ALL_FRAMES = True
    dataset = PlannerDatasetUtils(data_path, load_all_frames=LOAD_ALL_FRAMES)
    DUMP_VIDEO = True
    NUMS_WORKER = 16
    INTERVAL = 1
    CLIP_SAMPLE_NUM = 10
    vis_dump_path = "./tmp"
    random_clip_idx = random.sample(range(len(dataset)), CLIP_SAMPLE_NUM)

    def vis_clip_idx(idx):
        """Vis clip idx."""
        clip_data = dataset[idx]
        clip_data.preload_frame_ceph_data()
        clip_data.vis(vis_dump_path, interval=INTERVAL, dump_video=DUMP_VIDEO)

    if NUMS_WORKER == 1:
        for clip_idx in random_clip_idx:
            vis_clip_idx(clip_idx)
    else:
        with Pool(NUMS_WORKER) as p:
            p.map(vis_clip_idx, random_clip_idx)
