# -*- coding: utf-8 -*-
# type: ignore
# flake8: noqa
"""
Action-space clustering (multi-GPU, 1 M-sample blocks).

Stage 1 —— density-aware **K-Disk** up to K_DISK_CLUSTERS_TARGET.
Stage 2 —— **Faiss K-means** on leftovers until N_CLUSTERS_TARGET.

`torch.cdist` 被替换为 multi-GPU 分块版本，既避免 kernel 参数超限，
又能把大批样本分散到多张 GPU 上并行计算。
"""
from __future__ import annotations

import os
import pickle
import random
import sys
from multiprocessing import Pool
from multiprocessing import set_start_method
from typing import Tuple

import numpy as np
import pandas as pd
import torch
from tqdm import tqdm


# ---------------------------------------------------------------------------
# Optional dependencies ------------------------------------------------------
try:
    import faiss  # faiss-gpu OR faiss-cpu

    FAISS_AVAILABLE = True
except ImportError:  # pragma: no cover
    FAISS_AVAILABLE = False
    from sklearn.cluster import KMeans  # type: ignore[attr-defined]

from tpp_onemodel.tools.astra_planner.data.data_utils.astra_planner_dataset_utils import (
    PlannerDatasetUtils,
)
from tpp_onemodel.tools.astra_planner.data.txt_to_pkl_utils import txt_to_pkl


# --------------------------- Hyper‑parameters ------------------------------
DATA_PATH = (
    # "/share-global/ruonan.xue/planner/data/train_pkl/v0303_0312/"
    # "planner_dataset_v0303_0312_all_data_val_10000_786432.pkl"
    "/share-global/mccree.zhao/planning_data/cluster/250514/planner_dataset_v0403_0411_50000_fix.pkl"
)
DUMP_FOLDER = "./cluster"
LOAD_ALL_FRAMES = True
NUM_WORKERS = 32
print(f"NUM_WORKERS: {NUM_WORKERS}")
# CLIP_SAMPLE_NUM = 50_000
CLIP_SAMPLE_NUM = 10_000

# Clustering budgets
N_CLUSTERS_TARGET = 512  # total vocabulary size
K_DISK_CLUSTERS_TARGET = 450  # stage‑1 K‑Disk clusters

# K‑Disk specific
EPSILON = [0.02, 0.01]
GRID = 0.01
SEED = 0

# Faiss K‑means specific
FAISS_NITER = 20
FAISS_NREDO = 4

# ---------------------- distance-helper parameters -------------------------
# BATCH_SIZE_CDIST = 500_000  # 切块大小
BATCH_SIZE_CDIST = 100_000  # 切块大小


# ---------------------------------------------------------------------------
# 0. cdist helpers -----------------------------------------------------------
def batched_cdist(
    x1: torch.Tensor,
    x2: torch.Tensor,
    p: int = 2,
    batch_size: int = BATCH_SIZE_CDIST,
) -> torch.Tensor:
    """
    单 GPU 分块版本。仅当系统只有 1 张 GPU（或无 GPU）时被 `multi_gpu_batched_cdist`
    自动调用作后备方案。
    """
    n_total = x1.size(0)
    out_chunks = []
    for start in range(0, n_total, batch_size):
        end = min(start + batch_size, n_total)
        dist_chunk = torch.cdist(x1[start:end], x2, p=p)
        out_chunks.append(dist_chunk)
    return torch.cat(out_chunks, dim=0)


def multi_gpu_batched_cdist(
    x1: torch.Tensor,
    x2: torch.Tensor,
    p: int = 2,
    batch_size: int = BATCH_SIZE_CDIST,
) -> torch.Tensor:
    """
    多 GPU + 分块版 cdist。

    Parameters
    ----------
    x1 : (N, D) tensor
        待比较的大样本集合，允许放在 CPU 或任一 GPU。
    x2 : (M, D) tensor
        centroids，通常很小（<=512），会被复制到每张 GPU。
    p  : 距离范数，等同于 torch.cdist(p=p)。
    batch_size : int
        首次切块行数。每块再平均分给所有可用 GPU。

    Returns
    -------
    (N, M) tensor on CPU
    """
    n_gpu = torch.cuda.device_count()
    if n_gpu <= 1:
        # 单 GPU / CPU 环境直接用退化版
        return batched_cdist(x1, x2, p=p, batch_size=batch_size)

    # 确保输入在 CPU，避免无谓的 host-device copy
    x1_cpu = x1.cpu()
    x2_copies = [x2.to(f"cuda:{gid}") for gid in range(n_gpu)]

    n_total = x1_cpu.size(0)
    out_chunks: list[torch.Tensor] = []

    for start in range(0, n_total, batch_size):
        end = min(start + batch_size, n_total)
        block = x1_cpu[start:end]  # (B, D) on CPU
        sub_blocks = torch.chunk(block, n_gpu, dim=0)  # 平均切到各 GPU

        dist_subs: list[torch.Tensor] = []
        for gid, sub in enumerate(sub_blocks):
            if sub.numel() == 0:  # 最后一个 block 有可能空
                continue
            device = f"cuda:{gid}"
            with torch.cuda.device(device):
                sub_gpu = sub.to(device, non_blocking=True)
                dists_gpu = torch.cdist(sub_gpu, x2_copies[gid], p=p)
                dist_subs.append(dists_gpu.cpu())  # 结果搬回 CPU

        # 保持原始顺序拼接
        dists_block = torch.cat(dist_subs, dim=0)
        out_chunks.append(dists_block)
        # 及时释放显存
        torch.cuda.empty_cache()

    return torch.cat(out_chunks, dim=0)


# ----------------------------------------------------------------------------
# 1. Action extraction helpers ------------------------------------------------
dataset: "PlannerDatasetUtils | None" = None


def get_action_space(clip_id: int) -> np.ndarray:
    """Return ``[acc, yaw_rate]`` array for a clip (uses global *dataset*)."""
    global dataset
    if dataset is None:
        raise RuntimeError("Global dataset not initialised.")

    clip_data = dataset[clip_id]
    clip_data.preload_frame_ceph_data()

    frames = [clip_data[i] for i in range(len(clip_data))]
    ts = np.array([f.timestamp for f in frames])
    dt = ts[1:] - ts[:-1]

    ego = np.array([f.frame_data["ego_motion"] for f in frames])
    vx = ego[:, 0]
    acc = (vx[1:] - vx[:-1]) / dt

    yaw = ego[:, 4] - ego[0, 4]
    dyaw = np.mod((yaw[1:] - yaw[:-1]) + np.pi, 2 * np.pi) - np.pi
    yaw_rate = dyaw / dt

    return np.stack([acc, yaw_rate], axis=1).astype(np.float32)


# ----------------------------------------------------------------------------
# 2. Density‑aware K‑Disk -----------------------------------------------------


def build_density_order(data: torch.Tensor, grid: float) -> torch.Tensor:
    gcoords = torch.div(data, grid, rounding_mode="floor").to(torch.int64)
    K = int(1.0 / grid) + 2
    keys = gcoords[:, 0] * K + gcoords[:, 1]
    _, inv, counts = torch.unique(keys, return_inverse=True, return_counts=True)
    density = counts[inv]
    return torch.argsort(density, descending=True)


def kdisk_cluster(
    data: torch.Tensor,
    eps: Tuple[float, float],
    n_target: int,
    return_remaining: bool = False,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor | None]:
    """Density-aware K-Disk clustering."""
    N = data.shape[0]
    order = build_density_order(data, GRID)
    remaining = torch.ones(N, dtype=torch.bool, device=data.device)
    centroids: list[torch.Tensor] = []

    ptr = 0
    while remaining.any() and len(centroids) < n_target:
        print(f"len(centroids) = {len(centroids)}")
        while ptr < N and not remaining[order[ptr]]:
            ptr += 1
        if ptr == N:
            break
        idx = order[ptr]
        c = data[idx]
        centroids.append(c)

        diff = torch.abs(data[remaining] - c)
        acc_diff = diff[:, 0]
        yaw_rate_diff = diff[:, 1]
        keep = (acc_diff > eps[0]) | (yaw_rate_diff > eps[1])
        rem_idx = remaining.nonzero(as_tuple=True)[0]
        remaining[rem_idx[~keep]] = False
        ptr += 1

    centroids_t = torch.stack(centroids, dim=0)
    dists = multi_gpu_batched_cdist(data, centroids_t, p=1)
    assign = torch.argmin(dists, dim=1)

    if not return_remaining:
        return centroids_t, assign, None
    return centroids_t, assign, remaining  # remaining == True → uncovered


# ----------------------------------------------------------------------------
# 3. Entry point -------------------------------------------------------------
if __name__ == "__main__":
    # ---------- seeding ----------------------------------------------------
    torch.manual_seed(SEED)
    random.seed(SEED)
    np.random.seed(SEED)

    # ---------- start-method (fork preferred) -----------------------------
    if sys.platform != "win32":
        try:
            set_start_method("fork")
        except RuntimeError:
            pass
    else:
        if NUM_WORKERS > 1:
            print("[WARN] Windows cannot share dataset via fork; using single-process.")
            NUM_WORKERS = 1

    # ---------- dataset path ---------------------------------------------
    if DATA_PATH.endswith(".txt"):
        pkl_path = txt_to_pkl([DATA_PATH], num_workers=16)[0]
    else:
        pkl_path = DATA_PATH

    dataset = PlannerDatasetUtils(pkl_path, load_all_frames=LOAD_ALL_FRAMES)

    # ---------- sample clips ----------------------------------------------
    rand_idx = random.sample(range(len(dataset)), CLIP_SAMPLE_NUM)
    print(f"[INFO] Randomly sampled {CLIP_SAMPLE_NUM} clips.")

    # ---------- extract actions -------------------------------------------
    if NUM_WORKERS == 1:
        action_list = [get_action_space(i) for i in tqdm(rand_idx, desc="Extract")]
    else:
        with Pool(NUM_WORKERS) as pool:
            action_list = list(tqdm(pool.imap(get_action_space, rand_idx), total=len(rand_idx), desc="Extract"))

    action_np = np.concatenate(action_list, axis=0, dtype=np.float32)
    print(f"[INFO] Total samples: {action_np.shape[0]}")

    # ---------- normalise --------------------------------------------------
    mins = action_np.min(axis=0)
    maxs = action_np.max(axis=0)
    rng = np.where(maxs - mins == 0, 1.0, maxs - mins)
    action_norm = (action_np - mins) / rng

    # ---------- stage 1: K-Disk -------------------------------------------
    device0 = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    action_t = torch.from_numpy(action_norm).to(device0)

    centroids_t1, assign_t1, rem_mask = kdisk_cluster(action_t, EPSILON, K_DISK_CLUSTERS_TARGET, return_remaining=True)
    M1 = centroids_t1.shape[0]
    print(f"[INFO] K-Disk produced {M1} centroids (≤ {K_DISK_CLUSTERS_TARGET}).")

    # ---------- stage 2: Faiss K-means ------------------------------------
    if rem_mask is None or not rem_mask.any():
        print("[INFO] No remaining samples → skipping K-means stage.")
        centroids_t_final = centroids_t1
    else:
        leftover_budget = max(0, N_CLUSTERS_TARGET - M1)
        if leftover_budget == 0:
            print("[INFO] Budget already met → skipping K-means stage.")
            centroids_t_final = centroids_t1
        else:
            outliers_np = action_t[rem_mask].cpu().numpy().astype(np.float32)
            n_outliers = outliers_np.shape[0]
            k = min(leftover_budget, n_outliers)

            print(f"[INFO] Running K-means on {n_outliers} outliers with k={k} (budget {leftover_budget}).")

            if FAISS_AVAILABLE:
                d = outliers_np.shape[1]
                use_gpu = torch.cuda.is_available()
                if use_gpu:
                    res = faiss.StandardGpuResources()
                kmeans = faiss.Kmeans(
                    d,
                    k,
                    niter=FAISS_NITER,
                    nredo=FAISS_NREDO,
                    seed=SEED,
                    gpu=torch.cuda.current_device() if use_gpu else False,
                )
                kmeans.train(outliers_np)
                centroids_kmeans = kmeans.centroids  # numpy (k, d)
            else:
                # -- fallback: sklearn.KMeans --------------------------------
                print("[WARN] Faiss not installed → falling back to sklearn KMeans (CPU).")
                print("try pip install -i https://mirrors.tuna.tsinghua.edu.cn/pypi/web/simple faiss-gpu")
                from sklearn.cluster import KMeans  # type: ignore[attr-defined]

                kmeans = KMeans(n_clusters=k, random_state=SEED, n_init=10).fit(outliers_np)
                centroids_kmeans = kmeans.cluster_centers_.astype(np.float32)

            centroids_kmeans_t = torch.from_numpy(centroids_kmeans).to(device0)
            centroids_t_final = torch.cat([centroids_t1, centroids_kmeans_t], dim=0)

    M_final = centroids_t_final.shape[0]
    print(f"[INFO] Final vocabulary size: {M_final} centroids.")

    # ---------- assignment & stats ----------------------------------------
    with torch.no_grad():
        dists_final = multi_gpu_batched_cdist(action_t, centroids_t_final, p=1)
        assign_final_t = torch.argmin(dists_final, dim=1)

    centroids = centroids_t_final.cpu().numpy()
    assign = assign_final_t.cpu().numpy()
    unique, counts = np.unique(assign, return_counts=True)
    ratio = counts / counts.sum()

    dists = np.abs(action_norm - centroids[assign]).sum(axis=1)
    df = pd.DataFrame({"center_idx": assign, "dist": dists})
    stats = df.groupby("center_idx")["dist"].agg(["count", "mean", "max", "min", "std"])
    stats["ratio"] = stats["count"] / stats["count"].sum()

    full_stats = pd.DataFrame(index=np.arange(M_final), columns=stats.columns)
    full_stats.update(stats)

    result = {
        "kdisk": {
            "centroids": centroids_t1.cpu().numpy(),
            "epsilon": EPSILON,
        },
        "kmeans": centroids[M1:] if M_final > M1 else None,
        "merge_center": np.concatenate([centroids_t1.cpu().numpy(), centroids_kmeans_t.cpu().numpy()], axis=0),
        "ratio": ratio,
        "full_stats": full_stats,
        "acc_range": [float(mins[0]), float(maxs[0])],
        "yaw_rate_range": [float(mins[1]), float(maxs[1])],
    }

    os.makedirs(DUMP_FOLDER, exist_ok=True)
    out_path = os.path.join(
        DUMP_FOLDER,
        f"ar_action_vocab_{CLIP_SAMPLE_NUM}_{M_final}_kdisk+faiss.pkl",
    )
    with open(out_path, "wb") as f:
        pickle.dump(result, f)
    print(f"[INFO] Saved to {out_path}")

    # ---------- visualization ---------------------------------------------
    import matplotlib.pyplot as plt

    plt.figure(figsize=(8, 6))
    plt.scatter(action_np[:, 0], action_np[:, 1], s=5, alpha=0.6, label="data points")
    plt.scatter(
        centroids[:, 0] * rng[0] + mins[0],
        centroids[:, 1] * rng[1] + mins[1],
        s=30,
        marker="x",
        label="centroids",
    )
    plt.xlabel("acc")
    plt.ylabel("yaw_rate")
    plt.title(f"Two-stage K-Disk + Faiss K-means (M={M_final})")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(DUMP_FOLDER, f"kdisk_faiss_cluster_{CLIP_SAMPLE_NUM}_visualization.png"))
