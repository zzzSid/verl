# -*- coding: utf-8 -*-
import pickle as pkl
import random
import time
from concurrent.futures import ThreadPoolExecutor

from tpp_onemodel.tools.astra_planner.data.data_utils.astra_planner_dataset_utils import (
    PlannerDatasetUtils,
)


if __name__ == "__main__":
    data_paths = [
        "/share-global/na.gao1/planner/data/pkls/1211/v1211_alldata/planner_dataset_v1211_alldata_train_w_tag_100ms_811203_82610081.pkl",
        "/share-global/na.gao1/planner/data/pkls/1211/v1211_alldata/planner_dataset_v1211_alldata_train_wo_tag_100ms_209897_30482033.pkl",
    ]
    LOAD_ALL_FRAMES = True
    scene_tag_by_gt_paths = [
        "/share-global/feiyang.li/tag-static-vehicle-status-dlb-23w-1216_revised.json",
        "/share-global/feiyang.li/tag-static-vehicle-status-roadtest-180w-1213-revised.json",
    ]
    dataset = PlannerDatasetUtils(
        data_paths, load_all_frames=LOAD_ALL_FRAMES, scene_tag_by_gt_paths=scene_tag_by_gt_paths
    )
    DUMP_VIDEO = True
    NUMS_WORKER = 2
    INTERVAL = 1
    CLIP_SAMPLE_NUM = 10
    vis_dump_path = "/home/yuting.tang/exps/Astraplanner/melange"
    random_clip_idx = random.sample(range(len(dataset)), CLIP_SAMPLE_NUM)

    def vis_clip_idx(idx):
        """Vis clip idx."""
        clip_data = dataset[idx]
        clip_data.preload_frame_ceph_data()
        scene_types = clip_data.get_scene_types()
        clip_id = clip_data.clip_id
        # clip_data.vis(vis_dump_path, interval=INTERVAL, dump_video=DUMP_VIDEO)
        return clip_id, scene_types

    full_files = dataset.dataset_data
    final_files = {}
    from tqdm import tqdm

    for file in tqdm(full_files):
        final_files[file["meta_ceph_path"].split("/")[-1].split(".pkl")[0]] = file

    save_files = []
    start_time = time.time()
    if NUMS_WORKER == 1:
        for clip_idx in random_clip_idx:
            vis_clip_idx(clip_idx)
    else:
        with ThreadPoolExecutor(max_workers=NUMS_WORKER) as executor:
            results = executor.map(vis_clip_idx, range(len(dataset)))

            for clip_id, scene_types in tqdm(results):
                tmp_file = final_files[clip_id]
                # saved_idx = [idx for idx in range(len(has_navi_path)) if has_navi_path[idx] == True]
                tmp_file["scene_types"] = scene_types
                # tmp_file["scene_types_by_gt"] = scene_types_by_gt
                # ori_selected_frame_idx = tmp_file["selected_frame_idx"].copy()
                # tmp_file["selected_frame_idx"] = [idx for idx in saved_idx if idx in ori_selected_frame_idx]
                # tmp_file["selected_timestamp"] = [
                #     tmp_file["selected_timestamp"][idx]
                #     for idx in range(len(ori_selected_frame_idx))
                #     if ori_selected_frame_idx[idx] in tmp_file["selected_frame_idx"]
                # ]
                # has_target += len(tmp_file["selected_frame_idx"])
                # assert len(tmp_file["selected_frame_idx"]) == len( tmp_file["selected_timestamp"])
                save_files.append(tmp_file)

        end_time = time.time()
        elapsed_time = end_time - start_time
        print(f"Function executed in {elapsed_time} seconds.")  # noqa: T201

        with open("taged_full_1211_part1.pkl", "wb") as f:
            print("saving tata")  # noqa: T201
            pkl.dump(save_files, f)
