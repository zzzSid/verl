# -*- coding: utf-8 -*-
import functools
import os
import random

import matplotlib.pyplot as plt
from matplotlib import font_manager


GRAY = "#D3D3D3"

NAME_LEVEL2 = {
    "urban_road_driving": "城区道路行驶",
    "single_lane_driving": "单车道",
    "sidepass": "换道行驶",
    "junction": "路口通行",
}

NAME_LEVEL3 = {
    "Unclassified_Scenario": "未分类场景",
    "lane_keep": "车道保持",
    "lane_centering": "居中行驶",
    "side_parked_vehicle": "旁车道临停车辆通行",
    "al_vehicl_centering": "他车在旁车道内居中行驶",
    "al_move_toego": "邻车道内他车向自车横移",
    "al_move_dooropen": "侧方车辆开门",
    "overtake_al_slow": "超越邻车道慢车",
    "target_merge_allane": "他车汇入旁侧车道",
    "close_to_egoline": "他车在旁车道内持续贴线行驶",
    "overtake_al_largevehicle": "超越并排行驶大车",
    "following_StopAndGo": "跟随起停",
    "following_steady": "稳态跟车",
    "following_stop": "跟随停止",
    "following_start": "跟随起步",
    "following_accelerate_timely": "快速跟车加速",
    "front_vehicle_brake_suddenly": "前车急刹",
    "congestion_following": "拥堵跟车",
    "FrontFrontCar_EmergencyDec": "前前车急刹",
    "follow_close": "近距离跟车",
    "following_VRU_steady": "稳态跟随VRU",
    "NormalPos_LowSpd_DiscontinuousDece_FollowStop": "正置低速前车不连续减速-自车跟停",
    "ObliquePos_LowSpdDece_Yield": "斜置低速前车减速-自车减速避让",
    "cutin_react": "cut-in响应",
    "cutin_vehicle_avoidance": "他车cut-in自车避让",
    "cutin_vehicle": "他车cut-in车道内避让",
    "cutin_truck": "大车cut-in",
    "cutin_car": "小车cut-in",
    "close_cutin_vehicle": "他车近距离cut-in车道内避让",
    "close_cutin_largevehicle": "大车近距离cut-in车道内避让",
    "close_cutin_VRU": "VRU近距离cut-in车道内避让",
    "mid_cutin": "中距离cut-in",
    "far_cutin": "远距离cut-in",
    "VehicleStart_to_Cutin": "他车从静止起步Cut-in车道内避让",
    "VRUStart_to_Cutin": "VRU从静止起步Cut-in车道内避让",
    "continuous_sidepass_cutin": "目标连续变道Cut-in",
    "opening_cut_in": "豁口cut-in车道内避让",
    "cutin_VRU_avoidance": "VRU cut-in自车避让",
    "cutin_VRU": "VRU cut-in车道内避让",
    "cutout_react": "cut-out响应",
    "cutout_vehicle": "他车cut-out",
    "PrecedVehicleCutout_StationOD_React": "前车cut-out突现静止车响应",
    "avoiding_nudge": "道内nudge",
    "OnesideApproach_NudgeWithinLane": "单侧动态挤压-道内nudge",
    "BothsideApproach_NudgeWithinLane": "双侧动态挤压-道内nudge",
    "OnesideStraightApproach_NudgeWithinLane": "单侧动态直行单侧动态挤压-道内nudge",
    "OnesideStaticApproach_NudgeWithinLane": "单侧静态单侧动态挤压-道内nudge",
    "defencive_decelerate": "防御性减速",
    "opening_defencive_decelerate": "豁口防御性减速",
    "slope_blindzone_decelerate": "坡度盲区主动减速",
    "defencive_decelerate_junction": "路口防御性减速",
    "speed_bump_decelerate": "减速带主动减速",
    "ContinuousBumpyRoad_Pass": "持续颠簸道路通行",
    "InUphillRamp": "上坡道行驶",
    "UphillRamp_to_DownhillRamp": "上坡道转下坡道行驶",
    "curve_pass": "弯道行驶",
    "large_curvature_pass": "大曲率弯道通行",
    "s_curve_pass": "S弯通行",
    "risk_react": "风险响应",
    "not_junction_VRU_game": "非路口VRU博弈",
    "oncoming_vehicle_invasion": "避让本车道对向来车",
    "oncoming_VRU_invasion": "避让对向VRU",
    "stationary_OD_react": "静止OD风险响应",
    "SOD_react": "SOD风险响应",
    "SOD_PopUp_react": "SOD突然出现风险响应",
    "GOD_react": "GOD风险响应",
    "largevehicle_cross_in": "大车横穿车道内避让",
    "smallvehicle_cross_in": "小车横穿车道内避让",
    "straight_VRU_cross": "直行VRU横穿车道内避让",
    "VRU_blind_zone": "鬼探头车道内避让",
    "vehicle_blind_zone": "盲区车辆车道内避让",
    "FrontVehicle_UTurn": "前方车辆掉头自车避让",
    "ReverseVehicle_RiskAvoidance": "倒车车辆风险避让",
    "SpdLim_Following": "限速行驶",
    "Constant_SpdLim_Following": "恒定限速巡航",
    "SpdLim_decrease_decelerate": "限速减小提前减速",
    "SpdLim_increase_accelerate": "限速增大快速提速",
    "ReduceSpeed_after_OverSpdLim": "超限速后降速行驶",
    "cruise": "空旷车道巡航",
    "MinorRoad_Pass": "小路通行",
    "NarrRoad_NoObstacles": "窄路无障碍物行驶-无中心线",
    "NarrRoad_NoObstacles_WithCenterLine": "窄路无障碍物行驶-有中心线",
    "CurveNarrRoad_NoObstacles": "弯道窄路无障碍物行驶",
    "TwoDir_NarrRoad_encounter": "双向窄路会车",
    "TwoDir_CurveNarrRoad_encounter": "双向弯道窄路会车",
    "NarrRoad_nudge": "窄路障碍物占道nudge",
    "NarrRoad_WideLane_NoObstacles": "小路-宽车道无障碍物行驶",
    "TwoDir_NarrRoad_OncoVehicle_InvadGame": "小路双向-对向车入侵自车道风险博弈",
    "NarrRoad_NarrSpace_pass": "小路-窄通行空间行驶",
    "MinorRoad_follow_close": "小路-近距离跟车",
    "MinorRoad_following_stop": "小路-跟随停止",
    "MinorRoad_VRU_cross": "小路-VRU横穿自车避让",
    "MinorRoad_vehicle_cross": "小路-车辆横穿自车避让",
    "MinorRoad_NarrSpace_EncounterYield": "小路-窄通行空间会车让行",
    "TwoDir_NarrRoad_NoObstacles": "双向窄路无障碍物行驶",
    "SingleDir_NarrRoad_NoObstacles": "单向窄路无障碍物行驶",
    "TwoDir_SingleLane_close_CenterLine": "双向单车道偏中心线行驶",
    "TwoDir_OverWidth_LeftLaneDrv": "双向超宽车道偏左行驶",
    "SingleDir_TwoLane_close_CenterLine": "单向双车道偏中心线行驶",
    "NarrSpace_SpdControl": "窄通行空间控速",
    "MinorRoad_Standard_TwoDir_SingleLane": "小路标准双向单车道行驶",
    "MinorRoad_Standard_SingleDir_TwoLane": "小路标准单向双车道行驶",
    "MinorRoad_Standard_SingleDir_SingleLane": "小路标准单向单车道行驶",
    "lanechange": "换道",
    "lanechange_left": "左换道",
    "lanechange_right": "右换道",
    "navigate": "导航换道",
    "continuous_lc_before_intersection": "路口前连续换道",
    "navi_lc_before_intersection": "路口前导航换道",
    "navi_lc_congestion_intersection": "路口前拥堵导航换道",
    "short_multi_lane": "短路口多车道换道",
    "destination": "终点前换道",
    "select_lane_straight_short_turn": "路口前多直行车道直行-路口后短距离左右转",
    "select_lane_straight_elevated_lane": "路口前多直行车道直行-路口后短距离上高架",
    "select_lane_straight_side_road": "路口前多直行车道直行-路口后短距离进辅路",
    "navi_lc_before_split_in_advance": "路口分叉点前-导航提前换道",
    "destination_park_side": "终点前靠边停车",
    "side_start2mainlane": "路边起步驶入主路",
    "congestion": "目标车道拥堵-换道",
    "right_turn_lane_temppark_vehicle": "右转车道临停车右转",
    "overtake": "超车换道",
    "driver_trigger_lever": "拨杆换道",
    "obstacle_avoidance": "避障换道",
    "borrow_opposite_lane": "借对向车道通行",
    "accident_car_avoiding": "事故车紧急避障换道",
    "stationary_OD_avoidance": "静止OD避障换道",
    "SOD_obstacle_avoidance": "SOD避障换道",
    "GOD_avoidance": "GOD避障换道",
    "construction_lane_change": "施工改道通行",
    "merge_split_pass": "分合流通行",
    "road_split_pass": "道路级分流通行",
    "lane_split_pass": "车道级分流通行",
    "road_merge_pass": "道路级合流通行",
    "lane_merge_pass": "车道级合流通行",
    "side_to_main": "辅路进主路",
    "main_to_side": "主路进辅路",
    "junction_lane_split_select": "路口前车道分叉选道",
    "ramp_lane_split_select": "上高架前车道分叉选道",
    "borrow_lane_nudge": "借道nudge",
    "nudge_same_direction": "借同向车道nudge",
    "nudge_opposite_direction": "借对向车道nudge",
    "TwoDir_NarrRoad_OppositeDir_VehicleNudge": "小路双向-借对向车道nudge有对向来车",
    "OnesideApproach_BorrowLaneNudge": "单侧动态挤压-借道nudge",
    "BothsideApproach_BorrowLaneNudge": "双侧动态挤压-借道nudge",
    "OnesideStraightApproach_BorrowLaneNudge": "单侧动态直行单侧动态挤压-借道nudge",
    "OnesideStaticApproach_BorrowLaneNudge": "单侧静态单侧动态挤压-借道nudge",
    "cutin_lanechange": "cut-in换道避让",
    "opening_cut_in_lanechange": "豁口cut-in变道避让",
    "cutin_vehicle_lanechange": "他车cut-in变道避让",
    "cutin_VRU_lanechange": "VRU cut-in变道避让",
    "lane_chenge_game": "换道博弈",
    "fast_approach_al_behind": "目标车道后方快速目标接近",
    "slow_target_al_front": "目标车道前方有慢速目标",
    "ego_target_sametime": "自车与目标车同时换道",
    "game_ride_line": "骑线博弈换道",
    "compete_lc_parallel_vehicle": "并排车辆博弈换道",
    "turned_back": "换道折回",
    "straight_pass": "路口直行",
    "straight_oncoming_OD_leftturn": "路口直行对向OD左转",
    "straight_parallel_vehicle": "直行同向并排",
    "asymmetric_pass": "非对称路口通行",
    "misaligned_pass": "非对齐路口通行",
    "sidepass": "路口内换道",
    "VRU_junction_with_trafficlight": "有灯VRU路口通行",
    "VRU_junction_without_trafficlight": "无灯VRU路口通行",
    "turn_right": "路口右转",
    "right_turn_lane": "路口右转专用车道右转",
    "rightturn_oncoming_vehicle_leftturn": "路口右转对向车左转",
    "turnright_vehicle_merge": "右转汇入",
    "turnright_VRU_cross": "右转VRU横穿",
    "turnright_VRU_cross_strong_interaction": "右转VRU横穿-强交互",
    "turnright_parallel_vehicle": "右转有同向并排车辆",
    "turnright_yield_occupiedVRU": "右转避让占道VRU",
    "MinorRoad_TurnRight2MainRoad": "小路-右转进大路",
    "MinorRoad_TurnRight2MinorRoad": "小路-右转进小路",
    "TurnRight_NotByRightMostLane": "非右一车道右转",
    "turn_left": "路口左转",
    "unprotected_leftturn_opposite_vehicle": "无保护左转对向车直行",
    "turnleft_vehicle_merge": "左转汇入",
    "turnleft_VRU_cross": "左转VRU横穿",
    "turnleft_VRU_cross_strong_interaction": "左转VRU横穿-强交互",
    "turnleft_parallel_vehicle": "左转有同向并排车辆",
    "turnleft_parallel_VRU": "左转有同向并排VRU",
    "turnleft_waiting_area": "左转待转区左转",
    "turnleft_enter_waiting_area": "进入左转待转区",
    "turnleft_exit_waiting_area": "待转区起步左转",
    "turnleft_yield_occupiedVRU": "左转避让占道VRU",
    "MinorRoad_TurnLeft2MainRoad": "小路-左转进大路",
    "MinorRoad_TurnLeft2MinorRoad": "小路-左转进小路",
    "TurnLeft_NotByLeftMostLane": "非左一车道左转",
    "TurnLeft_InTo_HardIsolationRoad": "左转进入有硬隔离道路",
    "u_turn_junction": "路口掉头",
    "u_turn": "掉头（不含倒车）",
    "u_turn_merge": "掉头（不含倒车）汇入",
    "u_turn_notLeftLane": "非左一车道掉头",
    "u_turn_waiting_area": "左转待转区掉头",
    "u_turn_opening_area": "豁口掉头",
    "three_point_turn": "三点掉头",
    "interact_game": "路口交互博弈",
    "oncoming_car_interact": "路口逆向车交互",
    "nudge": "路口内nudge",
    "straight_nudge": "直行路口内nudge",
    "turnleft_nudge": "左转路口内nudge",
    "turnright_nudge": "右转路口内nudge",
    "VRU_game": "路口VRU博弈",
    "tld_pass": "红绿灯通行",
    "tld_start": "绿灯起步",
    "TldGreen_StartBeforeIntersection_Straight": "路口前绿灯起步直行",
    "TldGreen_StartBeforeIntersection_TurnLeft": "路口前绿灯起步左转",
    "TldGreen_StartWaitingArea_TurnLeft": "待转区内绿灯起步左转",
    "TldGreen_StartBeforeIntersection_TurnRight": "路口前绿灯起步右转",
    "tld_stop": "红灯刹停",
    "TldRed_StopBeforeIntersection_Straight": "直行路口前红灯刹停",
    "TldRed_StopBeforeIntersection_TurnLeft": "左转路口前红灯刹停",
    "TldRed_StopWaitingArea_TurnLeft": "左转待转区内红灯刹停",
    "TldRed_StopBeforeIntersection_TurnRight": "右转路口前红灯刹停",
    "special_tld_go": "特殊灯态通行",
    "TldYellow_Go": "黄灯路口通行",
    "TldYellow_StopBeforeIntersection": "黄灯路口前刹停",
    "TldGreenFlash_Go": "绿闪灯路口通行",
    "TldGreenFlash_StopBeforeIntersection": "绿闪灯路口前刹停",
    "TldYellowFlash_Go": "黄闪灯路口通行",
    "head_pass": "头车过路口",
    "enter_mainroad_three_branched": "三岔口进入主路",
    "T_no_tld_merge_to_main": "无红绿灯T字路口进入主路",
    "Y_no_tld_merge_to_main": "无红绿灯Y字路口进入主路",
    "opening_merge_to_main": "驶离豁口进入主路",
    "roundabout_pass": "环岛通行",
    "roundabout_enter": "驶入环岛",
    "roundabout_inner": "环岛中通行",
    "roundabout_leave": "驶出环岛",
}


def generate_color():
    """生成浅色的RGB值."""
    r = random.randint(200, 255)
    g = random.randint(200, 255)
    b = random.randint(200, 255)
    return f"#{r:02x}{g:02x}{b:02x}"


def get_font():
    """获取字体."""
    # 指定字体路径绘制饼状图
    font_path = "/share-global/na.gao1/font/NotoSansSC/NotoSansSC-Black.ttf"
    my_font = font_manager.FontProperties(fname=font_path)
    return my_font


def plot_geo_tags(tag_counts, geo_path, threshold=0.02):
    """Plot geo tags."""
    # 从tag_counts中提取geo信息
    geo_tags = {}
    for tag, count in tag_counts.items():
        content = tag.split(".")
        if len(content) != 4:
            continue
        _, l1, l2, l3 = content
        if l1 == "geo" and l2 not in ["country", "adcode"]:
            if l2 not in geo_tags:
                geo_tags[l2] = []
            geo_tags[l2].append([l3, count["frame_num"]])
    if len(geo_tags) == 0:
        return

    my_font = get_font()
    fig, axes = plt.subplots(1, len(geo_tags.keys()), figsize=(8 * len(geo_tags), 8))
    for i, cls in enumerate(geo_tags.keys()):
        # sorted by value
        geo = sorted(geo_tags[cls], key=lambda x: x[1], reverse=True)
        # 只显示前10个标签
        axes[i].pie(
            [item[1] for item in geo],
            labels=[item[0] for item in geo[:10]] + [""] * (len(geo) - 10),
            autopct=lambda pct: f"{pct:.1f}%" if pct >= threshold * 100 else "",
            startangle=90,
            textprops={"fontproperties": my_font},
        )
        axes[i].axis("equal")
        axes[i].set_title(f"geo-{cls}")

    plt.tight_layout()
    plt.savefig(geo_path, dpi=300)


def plot_fft_urban_tags(tag_counts, fft_path):
    """Plot fft urban tags."""
    # 提取fft_urban 2级标签信息
    fft_urban = []
    for tag, count in tag_counts.items():
        content = tag.split(".")
        if len(content) != 3:
            continue
        _, l1, l2 = content
        if l1 == "fft_urban":
            fft_urban.append([l2, count["frame_num"]])

    if len(fft_urban) == 0:
        return

    fft_urban = sorted(fft_urban, key=lambda x: x[1], reverse=True)
    # 绘制柱状图
    my_font = get_font()
    fig, ax = plt.subplots()
    ax.bar(
        range(len(fft_urban)),
        [item[1] for item in fft_urban],
        tick_label=[item[0] for item in fft_urban],
    )
    ax.set_xlabel("FFT Urban Tags", fontproperties=my_font)
    ax.set_ylabel("Frame Count", fontproperties=my_font)
    ax.set_title("FFT Urban Tag Distribution", fontproperties=my_font)
    plt.xticks(rotation=45, fontproperties=my_font)
    plt.yticks(fontproperties=my_font)
    plt.tight_layout()
    plt.savefig(fft_path, dpi=300)


def title_cmp(x, y):
    """Title compare."""
    # x y 为.连接的多级目录，有第1级的按照第1级排序，第1级名字为start和end的固定在最前和最后，其余sorted
    # start = ["fft_urban", "data_cleaning", "ego_state", "vehicle_status"]  end = ["fft_hw", "geo"]
    def find_index(lst, value):
        try:
            return lst.index(value)
        except ValueError:
            # print(f"Error: {value}")
            return len(value)

    def cmp_str(x, y):
        if x == y:
            return 0
        elif x < y:
            return -1
        else:
            return 1

    l1_order = [
        "fft_urban",
        "data_cleaning",
        "ego_state",
        "vehicle_status",
        "da",
        "da_check",
        "ego_lateral",
        "ego_longitudinal",
        "fft_data_cleaning",
        "global_routing",
        "junction_lane",
        "road_scene",
        "fft_hw",
        "geo",
    ]
    xs = x.split(".")
    ys = y.split(".")
    if len(xs) >= 2 and len(ys) >= 2:
        x_idx = find_index(l1_order, xs[1])
        y_idx = find_index(l1_order, ys[1])
        if x_idx == y_idx:
            return cmp_str(x, y)
        elif x_idx < y_idx:
            return -1
        else:
            return 1
    else:
        return cmp_str(x, y)


def get_table_from_tag(tag_counts):
    """Get table and geo from tag.

    inputs:
        tag_counts = { # 包含4级目录的帧数、clip统计
            # fft format: astraplanner.一级标签.二级标签.三级标签
            "astraplanner": {
                frame: num,
                clip: num
            }
            "astraplanner.data_cleaning": {
                frame: num,
                clip: num
            }
            "astraplanner.data_cleaning.ego_state": {
                frame: num,
                clip: num
            }
            "astraplanner.data_cleaning.ego_state.vehicle_status": {
                frame: num,
                clip: num
            }
        }
    """
    table = []
    colors = []

    title = ["0级标签", "1级标签", "2级标签", "3级标签", "frame_num", "clip_num", "3级标签在2级的frame占比", "3级标签在2级的clip占比"]
    table.append(title)
    colors.append(GRAY)  # title 填充灰色
    tags = sorted(tag_counts.keys(), key=functools.cmp_to_key(title_cmp))

    color_map = {}
    for tag in tags:
        frames = tag_counts[tag]["frame_num"]
        clips = tag_counts[tag]["clip_num"]

        content = tag.split(".")
        if len(content) <= 2:
            table.append(content + [""] * (4 - len(content)) + [frames, clips, "", ""])
            colors.append(GRAY)
            continue
        # filter geo.adcode
        if content[2] == "adcode":
            continue
        # 2级目录内容
        l2_name = ".".join(content[:3])
        if l2_name not in color_map:
            color_map[l2_name] = generate_color()
        l2_frames = tag_counts[l2_name]["frame_num"]
        l2_clips = tag_counts[l2_name]["clip_num"]

        row_tags = content + [""] * (4 - len(content))
        # replace_name
        row_tags_with_name = [
            row_tags[0],
            row_tags[1],
            row_tags[2] + NAME_LEVEL2.get(row_tags[2], ""),
            row_tags[3] + NAME_LEVEL3.get(row_tags[3], ""),
        ]
        table.append(row_tags_with_name + [frames, clips, frames / l2_frames, clips / l2_clips])
        colors.append(color_map[l2_name])
    return table, colors


def table_to_html(table, colors):
    """Table to html."""
    html = "<table>\n"
    for row, color in zip(table, colors):
        html += f'    <tr style="background-color: {color}; color: black;">\n'
        for cell in row:
            html += f"        <td>{cell}</td>\n"
        html += "    </tr>\n"
    html += "</table>\n"
    return html


def export2markdown(tag_counts, markdown_path):
    """Export tag statistics to markdown."""
    table, colors = get_table_from_tag(tag_counts)

    # FFT urban 分布图
    fft_urban_img_path = markdown_path.replace(".md", "_fft_urban.png")
    plot_fft_urban_tags(tag_counts, fft_urban_img_path)

    # 城市分布图
    geo_img_path = markdown_path.replace(".md", "_geo.png")
    plot_geo_tags(tag_counts, geo_img_path)

    with open(markdown_path, "w", encoding="utf-8") as fin:
        # 城市分布图
        fin.writelines("# 分布图\n")
        if os.path.exists(fft_urban_img_path):
            fin.writelines("\n## FFT Urban 分布图\n")
            fin.writelines(f"""<img src=./{os.path.basename(fft_urban_img_path)} style="width:60%;" >\n""")
        if os.path.exists(geo_img_path):
            fin.writelines("\n## 城市分布图\n")
            fin.writelines(f"""<img src=./{os.path.basename(geo_img_path)} style="width:90%;" >\n""")
        # tag 分布表格
        fin.writelines("\n# Tag 分布\n")
        html = table_to_html(table, colors)
        fin.writelines(html)

    # print(f"Export tag statistics to {markdown_path}.")
