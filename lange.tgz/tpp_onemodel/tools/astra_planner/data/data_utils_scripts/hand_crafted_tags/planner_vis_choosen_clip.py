# -*- coding: utf-8 -*-
# flake8: noqa
# type: ignore
import os
import pickle as pkl
from functools import partial
from multiprocessing import Pool
from multiprocessing import current_process

import numpy as np
import torchpilot
from tqdm import tqdm

from tpp_onemodel.tools.astra_planner.data.data_utils.astra_planner_dataset_utils import (
    PlannerDatasetUtils,
)


logger = torchpilot.logger


def process_clip(clip, save_dir):
    """
    处理单个clip的函数，用于多进程调用。
    """
    try:
        logger.info(f"Process {current_process().name} processing clip: {clip}")
        clip.vis(save_dir, interval=1, dump_video=True)
    except Exception as e:
        logger.error(f"Error processing clip {clip}: {e}")


if __name__ == "__main__":
    raw_pkl_path = "./export_data_debug/planner_dataset_v1219_with_tag_train_16_1020.pkl"
    save_dir = "tmp_low_speed"

    dataset = PlannerDatasetUtils(raw_pkl_path, load_all_frames=True)

    # 这里仅处理前10个clip，可以根据需要调整
    dataset.dataset_data = dataset.dataset_data[0:30]

    clips = list(dataset)  # 将dataset转换为列表，以便多进程处理

    # 设置进程池的大小，根据CPU核心数或具体需求调整
    num_processes = os.cpu_count() // 2  # 使用CPU核心数减5，可以根据需求调整

    logger.info(f"Starting multiprocessing with {num_processes} processes...")

    with Pool(processes=num_processes) as pool:
        # 使用tqdm显示进度条
        func = partial(process_clip, save_dir=save_dir)
        for _ in tqdm(pool.imap_unordered(func, clips), total=len(clips), desc="Processing clips"):
            pass  # 结果已在process_clip中处理，无需进一步操作

    logger.info("All clips have been processed.")
