# -*- coding: utf-8 -*-
# flake8: noqa
# type: ignore
import os
import pickle as pkl
from functools import partial
from multiprocessing import Pool
from multiprocessing import current_process

import numpy as np
import torchpilot
from tqdm import tqdm

from tpp_onemodel.tools.astra_planner.data.data_utils.astra_planner_dataset_utils import (
    PlannerDatasetUtils,
)


logger = torchpilot.logger


def process_clip(clip, clip_to_tag_dict):
    """
    处理单个clip的函数，用于多进程调用。
    """
    tag_name = clip_to_tag_dict.get(clip.clip_id, "default_tag")
    logger.info(f"Process {current_process().name} processing clip: {clip} with tag: {tag_name}")
    clip.vis("save_" + tag_name, interval=1, dump_video=True)


if __name__ == "__main__":
    raw_pkl_path = "/share-global/wei.wang22/data/planner/1207/planner_dataset_v1207_with_tag_v1213_495003_56938582.pkl"
    tags_to_clip_pkl_path = "/home/mccree.zhao/project/offline/2024/melange_all/2024_12/melange_1225_low_speed/tag_export/target_tag/tags_to_clip_id_dict_planner-data-v1207-training-4_test_data_1211.pkl"
    target_tag_list = ["astra_planner.fft_urban.sidepass.side_to_main"]
    viz_num = 10

    with open(raw_pkl_path, "rb") as f:
        raw_pkl = pkl.load(f)
    with open(tags_to_clip_pkl_path, "rb") as f:
        tags_to_clip_dict = pkl.load(f)

    raw_pkl_dict = {}
    for raw_item in tqdm(raw_pkl, desc="Loading raw_pkl"):
        key = raw_item["meta_ceph_path"].split("/")[3]
        raw_pkl_dict[key] = raw_item

    target_clip_list = []
    clip_to_tag_dict = {}
    for target_tag in target_tag_list:
        cnt = 0
        clip_list = tags_to_clip_dict[target_tag]
        for clip_path in clip_list:
            clip_id = clip_path.split("/")[3]
            target_clip_list.append(raw_pkl_dict[clip_id])
            clip_to_tag_dict[clip_id] = "-".join(target_tag.split(".")[-2:])
            cnt += 1
            if cnt >= viz_num:
                break

    dataset = PlannerDatasetUtils(target_clip_list, load_all_frames=True)
    clips = list(dataset)
    num_processes = os.cpu_count() // 4
    # num_processes = 1

    logger.info(f"Starting multiprocessing with {num_processes} processes...")

    with Pool(processes=num_processes) as pool:
        # 使用tqdm显示进度条
        func = partial(process_clip, clip_to_tag_dict=clip_to_tag_dict)
        for _ in tqdm(pool.imap_unordered(func, clips), total=len(clips), desc="Processing clips"):
            pass

    logger.info("All clips have been processed.")
