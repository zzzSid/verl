# -*- coding: utf-8 -*-
# flake8: noqa
import logging
from functools import partial
from multiprocessing import Lock

import numpy as np
import torchpilot


# 初始化日志记录器
logger = torchpilot.logger

# 全局变量，用于存储每个进程的tqdm位置
global_position = None
position_lock = Lock()

# 开关控制子进程内部的tqdm
ENABLE_TQDM = False

white_name_tag_set = {
    "astra_planner.fft_hw.single_lane_driving.ReduceSpeed_after_OverSpdLim",
    "astra_planner.fft_urban.single_lane_driving.following_stop",
    "astra_planner.fft_hw.single_lane_driving.cutin_vehicle",
    "astra_planner.fft_urban.single_lane_driving.TwoDir_NarrRoad_encounter",
    "astra_planner.fft_urban.sidepass.TwoDir_NarrRoad_OppositeDir_VehicleNudge",
    "astra_planner.fft_urban.sidepass.congestion",
    "astra_planner.fft_urban.junction.u_turn",
    "astra_planner.fft_urban.junction.tld_stop",
    "astra_planner.fft_urban.sidepass.ramp_lane_split_select",
    "astra_planner.fft_urban.single_lane_driving.largevehicle_cross_in",
    "astra_planner.fft_urban.single_lane_driving.VehicleStart_to_Cutin",
    "astra_planner.fft_urban.single_lane_driving.NarrRoad_nudge",
    "astra_planner.fft_urban.single_lane_driving.TwoDir_NarrRoad_OncoVehicle_InvadGame",
    "astra_planner.fft_urban.single_lane_driving.al_move_toego",
    "astra_planner.fft_urban.junction.head_pass",
    "astra_planner.fft_urban.junction.turn_left",
    "astra_planner.fft_urban.junction.turn_right",
    "astra_planner.fft_urban.single_lane_driving.VRU_blind_zone",
    "astra_planner.fft_urban.single_lane_driving.vehicle_blind_zone",
    "astra_planner.fft_urban.single_lane_driving.opening_cut_in",
    "astra_planner.fft_urban.single_lane_driving.smallvehicle_cross_in",
    "astra_planner.fft_urban.sidepass.GOD_avoidance",
    "astra_planner.fft_urban.sidepass.SOD_obstacle_avoidance",
    "astra_planner.fft_hw.single_lane_driving.following_accelerate_timely",
    "astra_planner.fft_urban.junction.VRU_game",
    # "astra_planner.fft_urban.sidepass.lane_split_pass",
    "astra_planner.fft_urban.single_lane_driving.large_curvature_pass",
    # "astra_planner.fft_urban.sidepass.road_split_pass",
    # "astra_planner.fft_urban.sidepass.road_merge_pass",
    # "astra_planner.fft_urban.sidepass.lane_merge_pass",
    # "astra_planner.fft_urban.sidepass.side_to_main",
    # "astra_planner.fft_urban.sidepass.main_to_side",
    "astra_planner.fft_urban.single_lane_driving.cutin_vehicle_avoidance",
    "astra_planner.fft_urban.single_lane_driving.MinorRoad_vehicle_cross",
    "astra_planner.fft_urban.single_lane_driving.MinorRoad_VRU_cross",
    "astra_planner.fft_urban.single_lane_driving.MinorRoad_NarrSpace_EncounterYield",
    "astra_planner.fft_urban.single_lane_driving.following_steady",
    "astra_planner.fft_urban.junction.tld_stop",
}


def compute_lane_min_weighted_distance(lane_points):
    if lane_points.shape[0] < 3:
        return np.array([1e3, 1e3]), 1e3, (0, 0)
    origin = np.array([0.0, 0.0])
    # lane_points: shape [M,2]

    # 首先找到lane上距离(0,0)最近的点:
    # 简单方法：计算每个lane point到原点的欧式距离，并找到最小距离点的索引
    dist_all = np.linalg.norm(lane_points - origin, axis=1)
    min_idx = np.argmin(dist_all)
    closest_point = lane_points[min_idx]

    # 求该点处的切线方向：
    # 若min_idx不在边界，可由相邻点求导；否则选用第二近的点近似
    if min_idx == 0:
        # 用min_idx+1的点来近似切线方向
        direction_vector = lane_points[min_idx + 1] - lane_points[min_idx]
    elif min_idx == len(lane_points) - 1:
        # 用min_idx-1的点来近似切线方向
        direction_vector = lane_points[min_idx] - lane_points[min_idx - 1]
    else:
        # 用两侧点平均求导来获取更稳健的方向
        direction_vector = lane_points[min_idx + 1] - lane_points[min_idx - 1]

    direction_unit = direction_vector / (np.linalg.norm(direction_vector) + 1e-6)

    # 将(0,0)到closest_point的向量分解到方向与其垂直方向
    vec_from_origin = closest_point - origin
    parallel_dist = np.dot(vec_from_origin, direction_unit)
    perp_unit = np.array([-direction_unit[1], direction_unit[0]])  # 与切线方向垂直
    lateral_dist = np.dot(vec_from_origin, perp_unit)

    weighted_dist = abs(parallel_dist) + 10 * abs(lateral_dist)

    return closest_point, weighted_dist, direction_unit


def compute_curvature(points):
    """
    使用三点法来估计曲率（向量化版本）。
    points: shape [M,2]
    """
    M = len(points)
    curvatures = np.zeros(M)
    if M < 3:
        return curvatures

    x = points[:, 0]
    y = points[:, 1]
    x_im1 = x[:-2]
    x_i = x[1:-1]
    x_ip1 = x[2:]
    y_im1 = y[:-2]
    y_i = y[1:-1]
    y_ip1 = y[2:]

    dx = (x_ip1 - x_im1) / 2.0
    dy = (y_ip1 - y_im1) / 2.0
    ddx = x_ip1 - 2 * x_i + x_im1
    ddy = y_ip1 - 2 * y_i + y_im1

    denominator = (dx**2 + dy**2) ** 1.5
    with np.errstate(divide="ignore", invalid="ignore"):
        curvature_mid = np.abs(dx * ddy - dy * ddx) / denominator
        curvature_mid[denominator < 1e-9] = 0.0

    curvatures[1:-1] = curvature_mid
    # 两端点使用相邻值进行填充
    curvatures[0] = curvatures[1]
    curvatures[-1] = curvatures[-2]

    return curvatures


def compute_heading_diff(points):
    """
    计算相邻点的heading差分（向量化版本）。
    points: shape [M,2]
    """
    M = len(points)
    if M < 2:
        return np.zeros(M)

    headings = np.zeros(M)
    # 计算相邻两点段的heading
    dx = points[1:, 0] - points[:-1, 0]
    dy = points[1:, 1] - points[:-1, 1]
    seg_headings = np.arctan2(dy, dx)

    # 前 M-1 个点的 heading，最后一个点与前一值保持一致（如果 M>2）
    headings[:-1] = seg_headings
    if M > 2:
        headings[-1] = headings[-2]
    else:
        headings[-1] = headings[0]

    # 计算heading差值
    heading_diff = np.zeros(M)
    diff = headings[1:] - headings[:-1]
    diff = (diff + np.pi) % (2 * np.pi) - np.pi
    heading_diff[1:] = diff
    # 第一个点与第二个点保持一致
    heading_diff[0] = heading_diff[1] if M > 1 else 0

    return heading_diff


def get_neareset_lane_curvature(manner_lane_points, manner_lane_types):
    # 只保留 t == 4 的lane
    valid_indices = [i for i, t in enumerate(manner_lane_types) if (t == 4)]
    if not valid_indices:
        return np.array([0]), np.array([0])

    lane_candidates = []
    for idx in valid_indices:
        lane_pts = manner_lane_points[idx]
        # 计算这条lane到原点的横向距离
        _, weighted_dist, direction_unit = compute_lane_min_weighted_distance(lane_pts)
        lane_candidates.append((idx, weighted_dist, direction_unit))

    lane_candidates.sort(key=lambda x: abs(x[1]))
    best_lane_idx, best_lane_lat_dist, best_lane_dir_unit = lane_candidates[0]
    best_lane_points = manner_lane_points[best_lane_idx]

    curvatures = compute_curvature(best_lane_points)
    heading_diffs = compute_heading_diff(best_lane_points)
    return curvatures, heading_diffs


def has_consecutive_frames(timestamps, threshold=0.3, needed=3):
    count = 0
    for i in range(1, len(timestamps)):
        if (timestamps[i] - timestamps[i - 1]) < threshold:
            count += 1
        else:
            count = 0
        if count >= needed:
            return True
    return False


def get_consecutive_frames_low_speed(
    anomoly_timestamp_list,
    clip_data_timestamp_list,
    clip_data_timestamp_dict,
    clip_data_longitude_acc_list,
    history_frames=15,  # ← 原先写死15帧，现改为传参
    future_frames=0,  # ← 新增未来帧查找
    threshold=0.3,
    needed=3,
):
    """
    anomoly_timestamp_list: List[float] - 已知的异常帧时间戳
    clip_data_timestamp_list: List[float] - 所有帧的时间戳（升序）
    clip_data_timestamp_dict: Dict[float, int] - 时间戳 -> 索引的映射
    clip_data_longitude_acc_list: List[float] - 对应帧的longitude加速度
    history_frames: int - 往前要查找的帧数
    future_frames: int - 往后要查找的帧数
    threshold: float - 两帧间隔小于此值时认为是连续
    needed: int - 需要连续多少帧才被保留
    """

    # ---------------------
    # 1) 扩展异常帧
    # ---------------------
    extended_anomoly_set = set(anomoly_timestamp_list)

    for anom_t in anomoly_timestamp_list:
        idx = clip_data_timestamp_dict.get(anom_t, -1)
        if idx < 0:
            # 如果拿不到索引，可能是异常数据，直接跳过
            continue

        # 计算前后查找的索引范围
        start_idx = max(0, idx - history_frames)
        end_idx = min(len(clip_data_timestamp_list) - 1, idx + future_frames)

        # 遍历[start_idx, end_idx]区间，如果long_acc <= 0，则加入异常集合
        for i in range(start_idx, end_idx + 1):
            if clip_data_longitude_acc_list[i] <= 0:
                extended_anomoly_set.add(clip_data_timestamp_list[i])

    # 取出扩展后的所有异常帧，升序排序
    extended_anomoly_list = sorted(extended_anomoly_set)

    # ---------------------
    # 2) 连续帧过滤
    # ---------------------
    final_anomoly_list = []
    if not extended_anomoly_list:
        return final_anomoly_list

    temp_group = [extended_anomoly_list[0]]

    for i in range(1, len(extended_anomoly_list)):
        prev_ts = extended_anomoly_list[i - 1]
        curr_ts = extended_anomoly_list[i]

        # 判断是否连续
        if (curr_ts - prev_ts) <= threshold:
            # 连续则加入临时组
            temp_group.append(curr_ts)
        else:
            # 如果遇到不连续，先判断已有组的长度是否达标
            if len(temp_group) >= needed:
                # 如果达标，合并到 final_anomoly_list
                final_anomoly_list.extend(temp_group)
            # 开启新一组
            temp_group = [curr_ts]

    # 循环结束后还需判断最后一个 temp_group
    if len(temp_group) >= needed:
        final_anomoly_list.extend(temp_group)

    return final_anomoly_list


def get_consecutive_frames_speedup(
    anomoly_timestamp_list,
    clip_data_timestamp_list,
    clip_data_timestamp_dict,
    clip_data_longitude_acc_list,
    clip_data_longitude_vel_dict,
    history_frames=15,  # ← 新增，指定向前查多少帧
    future_frames=15,  # ← 保留，指定向后查多少帧
    threshold=0.3,
    needed=3,
):
    """
    anomoly_timestamp_list: List[float] - 已知的异常帧时间戳
    clip_data_timestamp_list: List[float] - 所有帧的时间戳（升序）
    clip_data_timestamp_dict: Dict[float, int] - 时间戳 -> 索引的映射
    clip_data_longitude_acc_list: List[float] - 对应帧的longitude加速度
    clip_data_longitude_vel_dict: Dict[float, float] - 时间戳 -> longitude速度
    history_frames: int - 从异常帧向前最多找多少帧
    future_frames: int - 从异常帧向后最多找多少帧
    threshold: float - 两帧间隔小于此值时认为是连续
    needed: int - 需要连续多少帧才被保留
    """

    # ---------------------
    # 1) 扩展异常帧
    # ---------------------
    extended_anomoly_set = set(anomoly_timestamp_list)

    for anom_t in anomoly_timestamp_list:
        idx = clip_data_timestamp_dict.get(anom_t, -1)
        if idx == -1:
            # 如果拿不到索引，跳过
            continue

        # 计算前后查找的索引范围
        start_idx = max(0, idx - history_frames)
        end_idx = min(len(clip_data_timestamp_list) - 1, idx + future_frames)

        # 在[start_idx, end_idx]范围内，如果加速度为“正”则视为异常
        for i in range(start_idx, end_idx + 1):
            if clip_data_longitude_acc_list[i] > 0:
                extended_anomoly_set.add(clip_data_timestamp_list[i])

    # 取出扩展后的所有异常帧，升序排序
    extended_anomoly_list = sorted(extended_anomoly_set)

    # ---------------------
    # 2) 连续帧过滤
    # ---------------------
    final_anomoly_list = []
    if not extended_anomoly_list:
        return final_anomoly_list

    temp_group = [extended_anomoly_list[0]]  # 暂存连续帧的容器

    for i in range(1, len(extended_anomoly_list)):
        prev_ts = extended_anomoly_list[i - 1]
        curr_ts = extended_anomoly_list[i]

        # 判断两帧是否连续
        if (curr_ts - prev_ts) <= threshold:
            # 连续则加入临时组
            temp_group.append(curr_ts)
        else:
            # 如果遇到不连续，先判断已有组的长度是否达标
            # 并且最后一帧的速度是否大于 5
            if len(temp_group) >= needed and clip_data_longitude_vel_dict[temp_group[-1]] > 5:
                final_anomoly_list.extend(temp_group)
            # 开启新一组
            temp_group = [curr_ts]

    # 循环结束后, 判断最后一个 temp_group
    if len(temp_group) >= needed and clip_data_longitude_vel_dict[temp_group[-1]] > 5:
        final_anomoly_list.extend(temp_group)

    return final_anomoly_list


def is_ego_turn(ego_yaw, clip_data_list, idx, time_interval):
    ego_turn = False
    for time_idx in (np.array([3, 6, 9, 12]) / time_interval).astype(int):
        if idx + time_idx >= len(clip_data_list):
            break
        frame_fut = clip_data_list[int(idx + time_idx)]
        ego_motion_fut = frame_fut["ego_motion"]
        ego_yaw_fut = ego_motion_fut[4]
        yaw_diff = abs((ego_yaw_fut - ego_yaw + np.pi) % (2 * np.pi) - np.pi)
        if abs(yaw_diff) > np.pi / 6:
            ego_turn = True
    return ego_turn


def get_fut_msg(clip_data_list, time_interval, idx):
    front_box_list = []
    ego_fut_speed_max = 0
    ego_fut_speed_min = np.linalg.norm(clip_data_list[idx]["ego_motion"][0:2])
    for time_idx in (np.array([0, 1, 3, 5]) / time_interval).astype(int):
        if idx + time_idx >= len(clip_data_list):
            break
        frame_fut = clip_data_list[int(idx + time_idx)]

        ego_fut_speed = np.linalg.norm(frame_fut["ego_motion"][0:2])
        ego_fut_speed_max = max(ego_fut_speed_max, ego_fut_speed)
        ego_fut_speed_min = min(ego_fut_speed_min, ego_fut_speed)

        bbox = frame_fut["dynamic_dets"]  # [N, ...]
        bbox_pos = bbox[:, 0:2]  # [N,2], x 是纵向, y 是横向
        bbox_l = bbox[:, 3]  # [N] 长度
        bbox_vel = bbox[:, 10:12]  # [N,2], vx 是纵向, vy 是横向
        longitude_distance_threshold = max(ego_fut_speed * 7, 20)
        front_box_mask = (
            (bbox_pos[:, 0] >= bbox_l / 2) & (bbox_pos[:, 0] - bbox_l / 2 <= longitude_distance_threshold)
        ) & ((bbox_pos[:, 1] >= -2) & (bbox_pos[:, 1] <= 2))
        if time_idx != 0:  # 非当前帧，仅考虑moving的bbox
            front_box_mask = front_box_mask & (bbox_vel[:, 0] > 0.5)
        if front_box_mask.sum() > 0:
            front_bboxes = bbox[front_box_mask]
            front_bboxes_pos_x = front_bboxes[:, 0]
            nearest_front_bboxes = front_bboxes[np.argsort(front_bboxes_pos_x)[:3]]
            front_box_list.extend(nearest_front_bboxes)
    return front_box_list, ego_fut_speed_max, ego_fut_speed_min


def get_hist_msg(clip_data_list, time_interval, idx):
    ego_hist_speed_max = 0
    for time_idx in (np.array([-1, -2]) / time_interval).astype(int):
        if idx + time_idx < 0:
            break
        frame_hist = clip_data_list[int(idx + time_idx)]
        ego_hist_speed_max = max(ego_hist_speed_max, np.linalg.norm(frame_hist["ego_motion"][0:2]))
    return ego_hist_speed_max


def is_ego_speed_up(ego_speed, ego_hist_speed_max, ego_fut_speed_max, ego_acc):
    if (
        ego_speed - ego_hist_speed_max > 0.5 or (ego_speed < 0.5 and ego_acc[0] > 0)
    ) and ego_fut_speed_max - ego_speed > 2:
        return True
    if ego_acc[0] > 0.2:
        return True
    return False


def get_surrounding_bbox_info(frame):
    bbox = frame["dynamic_dets"]  # [N, ...]
    bbox_pos = bbox[:, 0:2]  # [N,2], x 是纵向, y 是横向
    bbox_vel = bbox[:, 10:12]  # [N,2], vx 是纵向, vy 是横向
    bbox_speed = np.linalg.norm(bbox_vel, axis=1)  # 求bbox速度大小
    bbox_class = bbox[:, 7] // 100
    bbox_num = bbox.shape[0]

    surrounding_bbox_mask = (
        ((bbox_pos[:, 0] >= -10) & (bbox_pos[:, 0] <= 70))
        & ((bbox_pos[:, 1] >= -4) & (bbox_pos[:, 1] <= 4))
        # & (bbox_speed > 0.5)
        & ((bbox_class >= 1) & (bbox_class <= 4))
    )

    surrounding_bbox = bbox[surrounding_bbox_mask]
    surrounding_bbox_num = surrounding_bbox.shape[0]
    surrounding_bbox_moving_mean_speed = -1.0
    if surrounding_bbox_num > 0:
        surrounding_bbox_speed = bbox_speed[surrounding_bbox_mask]
        surrounding_bbox_moving_mask = surrounding_bbox_speed > 1.0
        surrounding_bbox_moving = surrounding_bbox[surrounding_bbox_moving_mask]
        surrounding_bbox_moving_speed = surrounding_bbox_speed[surrounding_bbox_moving_mask]
        if surrounding_bbox_moving.shape[0] > 0:
            surrounding_bbox_moving_mean_speed = np.mean(surrounding_bbox_moving_speed)

    return surrounding_bbox_num, surrounding_bbox_moving_mean_speed


def is_navi_turn(frame):
    navi_line_points = frame["navi_line_points"]  # list of [N,2] points
    # navi_line_types = frame["navi_line_types"]  # [N,] np array types
    navi_line_types = 4 * np.ones(len(navi_line_points), dtype=np.float32)
    neareset_lane_curvature, nearest_lane_heading_diff = get_neareset_lane_curvature(navi_line_points, navi_line_types)
    max_heading_diff = np.max(np.abs(nearest_lane_heading_diff))
    large_heading_diff_num = (np.abs(nearest_lane_heading_diff) > 0.05).sum()
    large_heading_diff_ratio = large_heading_diff_num / len(nearest_lane_heading_diff)
    # navi_turn = max_heading_diff > 0.1 and large_heading_diff_ratio > 0.3
    large_curv_num = (neareset_lane_curvature > 0.005).sum()
    large_curv_ratio = large_curv_num / len(neareset_lane_curvature)
    navi_turn_heading = max_heading_diff > 0.1 and large_heading_diff_ratio > 0.3
    navi_turn_curv = large_curv_ratio > 0.3
    navi_turn = navi_turn_heading or navi_turn_curv
    return navi_turn


def get_manner_info(frame):
    has_zebra = False
    has_stop_line = False
    maneer_lane_points = frame["manner_lane_points"]
    manner_lane_attr = frame["manner_lane_attr"]
    manner_lane_types = frame["manner_lane_types"]
    for lane_idex, lane_attr in enumerate(manner_lane_attr):
        lane_types = int(manner_lane_types[lane_idex])
        if 300 in lane_attr[:, 0]:
            has_zebra = True
        if (
            5 in lane_attr[:, 0]
            or 100 in lane_attr[:, 0]
            or 600 in lane_attr[:, 0]
            or 901 in lane_attr[:, 0]
            or 902 in lane_attr[:, 0]
            or lane_types == 3
        ):
            lane_points = maneer_lane_points[lane_idex]
            lane_points_dist_min = np.linalg.norm(lane_points, axis=1).min()
            if lane_points_dist_min < 40:
                has_stop_line = True
    return has_zebra, has_stop_line


def get_tld_info(frame):
    has_tld = False
    virtual_tld = frame["tld"][0:4]  # "left", "uturn", "straight", "right"
    # color list: [0, 1, 2, 3, 4] -> [unknown, red, yellow, green, gray]
    if not (np.logical_or(virtual_tld == 0, virtual_tld == 4)).all():
        has_tld = True
    return has_tld


def get_navi_speed_limit(frame):
    navi_speed_limit_list = []
    for navi_speed_limit in frame["navi_lane_speed_limit"]:
        navi_speed_limit = navi_speed_limit[0][0]
        navi_speed_limit_list.append(navi_speed_limit)
    return navi_speed_limit_list


def has_white_tag(tags):
    if tags is None or tags == []:
        return False
    if type(tags) == list:
        tags = set(tags)
    else:
        tags = set(tags.get("tag", []))
    if tags.intersection(set(white_name_tag_set)):
        return True
    return False


def process_clip(sample):
    try:
        time_interval = 0.2
        frame_data_list = []
        frame_data_accelerate_list = []
        clip_data_list = [_["current"][0] for _ in sample["frame_sample"]]
        clip_data_longitude_acc_list = [frame["ego_motion"][2] for frame in clip_data_list]
        clip_data_longitude_vel_dict = {frame["timestamp"]: frame["ego_motion"][0] for frame in clip_data_list}
        clip_data_timestamp_list = [frame["timestamp"] for frame in clip_data_list]
        clip_data_timestamp_dict = {frame["timestamp"]: idx for idx, frame in enumerate(clip_data_list)}

        clip_zebra_list = []
        clip_stop_line_list = []
        clip_tld_list = []
        for idx in range(len(clip_data_list)):
            frame = clip_data_list[idx]
            clip_zebra_list.append(get_manner_info(frame)[0])
            clip_stop_line_list.append(get_manner_info(frame)[1])
            clip_tld_list.append(get_tld_info(frame))

        for idx in range(len(clip_data_list)):
            frame = clip_data_list[idx]

            ego_vel = frame["ego_motion"][0:2]  # [vx, vy]
            ego_acc = frame["ego_motion"][2:4]  # [ax, ay]
            ego_yaw = frame["ego_motion"][4]  # yaw
            ego_speed = np.linalg.norm(ego_vel)  # 求ego速度大小
            ego_acc_amp = np.linalg.norm(ego_acc)  # 求ego加速度大小

            ego_turn = is_ego_turn(ego_yaw, clip_data_list, idx, time_interval)

            front_box_list, ego_fut_speed_max, ego_fut_speed_min = get_fut_msg(clip_data_list, time_interval, idx)
            has_close_front_bbox = len(front_box_list) > 0
            ego_hist_speed_max = get_hist_msg(clip_data_list, time_interval, idx)
            ego_speed_up = is_ego_speed_up(ego_speed, ego_hist_speed_max, ego_fut_speed_max, ego_acc)

            surrounding_bbox_num, surrounding_bbox_moving_mean_speed = get_surrounding_bbox_info(frame)

            navi_turn = is_navi_turn(frame)
            has_zebra = np.array(clip_zebra_list[max(idx - 35, 0) : idx + 1]).sum() > 0
            has_stop_line = np.array(clip_stop_line_list[max(idx - 1, 0) : idx + 1]).sum() > 0
            has_tld = np.array(clip_tld_list[max(idx - 35, 0) : idx + 1]).sum() > 0

            navi_speed_limit_list = get_navi_speed_limit(frame)
            navi_speed_limit_max = np.array(navi_speed_limit_list).max() / 3.6 if len(navi_speed_limit_list) > 0 else -1
            ego_low_speed = True if navi_speed_limit_max < 0 else ego_speed < navi_speed_limit_max * 0.7
            ego_high_speed = ego_speed > 10

            is_white_name_tag = has_white_tag(frame["tags"])

            # 判断是否满足跳过条件
            if (
                has_zebra
                # or has_tld #需要搭配距离食用
                or ego_turn
                or navi_turn
                or ego_high_speed
                or ego_speed_up
                or has_stop_line
                or is_white_name_tag
            ):
                continue

            # 查找异常低速
            find_anomoly_low_speed = False
            if has_close_front_bbox:
                # nearest_front_bbox = front_box_list[0]
                # nearest_front_bbox_speed = np.linalg.norm(nearest_front_bbox[10:12])
                nearest_front_bbox_speed_min = np.linalg.norm(np.array(front_box_list)[:, 10:12], axis=-1).min()
                if nearest_front_bbox_speed_min > 6.0:
                    if ego_speed < nearest_front_bbox_speed_min * 0.6:
                        find_anomoly_low_speed = True
            else:
                if surrounding_bbox_num > 0 and surrounding_bbox_moving_mean_speed != -1.0:
                    if ego_speed / (surrounding_bbox_moving_mean_speed + 1e-6) < 0.5:
                        find_anomoly_low_speed = True
                elif ego_speed < navi_speed_limit_max * 0.5:
                    find_anomoly_low_speed = True

            if find_anomoly_low_speed and ego_acc[0] <= 0.0:
                frame_data_list.append(frame["timestamp"])
            if (
                find_anomoly_low_speed
                and ego_acc[0] > 0.0
                and (ego_fut_speed_max - ego_speed > 1)
                and (ego_fut_speed_min - ego_speed >= 0 or ego_fut_speed_min >= 4)
            ):
                frame_data_accelerate_list.append(frame["timestamp"])

        anomoly_timestamp_list = frame_data_list.copy()
        anomoly_flag = has_consecutive_frames(anomoly_timestamp_list, threshold=0.45, needed=5)  # 原生异常
        frame_data_list = (  # 扩展之前就减速的数据
            get_consecutive_frames_low_speed(
                anomoly_timestamp_list,
                clip_data_timestamp_list,
                clip_data_timestamp_dict,
                clip_data_longitude_acc_list,
                history_frames=35,  # 7s
                future_frames=60,  # 12s
                threshold=0.25,
                needed=5,
            )
            if len(anomoly_timestamp_list) > 0
            else []
        )

        low_speed_accelerate_timestamp_list = frame_data_accelerate_list.copy()
        low_speed_accelerate_flag = has_consecutive_frames(
            low_speed_accelerate_timestamp_list, threshold=0.45, needed=5
        )
        frame_data_accelerate_list = (
            get_consecutive_frames_speedup(
                low_speed_accelerate_timestamp_list,
                clip_data_timestamp_list,
                clip_data_timestamp_dict,
                clip_data_longitude_acc_list,
                clip_data_longitude_vel_dict,
                history_frames=30,  # 6s
                future_frames=30,  # 6s
                threshold=0.45,
                needed=5,
            )
            if len(low_speed_accelerate_timestamp_list) > 0
            else []
        )

        res = {"low_speed": ([], None), "low_speed_accelerate": ([], None)}
        if anomoly_flag and len(frame_data_list) > 0:
            res["low_speed"] = (frame_data_list, None)
        if low_speed_accelerate_flag and len(frame_data_accelerate_list) > 0:
            res["low_speed_accelerate"] = (frame_data_accelerate_list, None)
    except Exception as e:
        logger.error(f"process_clip error: {e}, {sample['clip_id']}")
        print(f"process_clip error: {e}, {sample['clip_id']}")
        res = {"low_speed": ([], e), "low_speed_accelerate": ([], e)}
    return res
