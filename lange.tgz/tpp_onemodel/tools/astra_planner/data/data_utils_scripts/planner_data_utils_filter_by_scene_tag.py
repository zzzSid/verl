# -*- coding: utf-8 -*-
import os
import pickle as pkl
import sys

from tpp_onemodel.tools.astra_planner.data.data_utils.astra_planner_dataset_utils import (
    PlannerDatasetUtils,
)


if __name__ == "__main__":
    data_paths = [
        "/share-global/na.gao1/planner/data/pkls/1211/v1211_alldata/planner_dataset_v1211_alldata_train_w_tag_100ms_811203_82610081.pkl",
        "/share-global/na.gao1/planner/data/pkls/1211/v1211_alldata/planner_dataset_v1211_alldata_train_wo_tag_100ms_209897_30482033.pkl",
    ]
    LOAD_ALL_FRAMES = True
    scene_tag_by_gt_paths = [
        "/share-global/feiyang.li/tag-static-vehicle-status-dlb-23w-1216_revised.json",
        "/share-global/feiyang.li/tag-static-vehicle-status-roadtest-180w-1213-revised.json",
    ]
    dataset = PlannerDatasetUtils(
        data_paths, load_all_frames=LOAD_ALL_FRAMES, scene_tag_by_gt_paths=scene_tag_by_gt_paths
    )
    DUMP_VIDEO = True
    NUMS_WORKER = 8
    INTERVAL = 1
    # CLIP_SAMPLE_NUM = len(dataset)
    dump_path = "/home/yuting.tang/exps/Astraplanner/melange/tmp_collect"
    # random_clip_idx = random.sample(range(len(dataset)), CLIP_SAMPLE_NUM)
    if not os.path.exists(dump_path):
        os.mkdir(dump_path)

    selected_scenes = {
        "LK": 10000,
        "LC": 10000,
        "RC": 10000,
        "LT": 10000,
        "RT": 10000,
    }

    full_files = dataset.dataset_data

    final_files = {}
    from tqdm import tqdm

    for file in tqdm(full_files):
        final_files[file["meta_ceph_path"].split("/")[-1].split(".pkl")[0]] = file

    def vis_clip_idx(idx):
        """Vis clip idx."""
        clip_data = dataset[idx]
        clip_data.preload_frame_ceph_data()
        # clip_data.vis(vis_dump_path, interval=INTERVAL, dump_video=DUMP_VIDEO)
        scene_types = clip_data.get_scene_types()
        clip_id = clip_data.clip_id
        return clip_id, scene_types

    # if NUMS_WORKER == 1:
    #     for clip_idx in random_clip_idx:
    #         vis_clip_idx(clip_idx)
    # else:
    # with Pool(NUMS_WORKER) as p:
    #     p.map(vis_clip_idx, range(len(dataset)))

    colleted_scenes = {}
    for scene_name in selected_scenes.keys():
        colleted_scenes[scene_name] = {"data": [], "num": 0}

    from concurrent.futures import ThreadPoolExecutor

    with ThreadPoolExecutor(max_workers=NUMS_WORKER) as executor:
        results = executor.map(vis_clip_idx, range(len(dataset)))

        for clip_id, scene_types in tqdm(results):
            clip_data = final_files[clip_id].copy()
            for scene_name in selected_scenes.keys():
                select_num = selected_scenes[scene_name]
                collect_idices = scene_types == scene_name
                collect_frames_ids = [
                    frame_idx
                    for idx, frame_idx in enumerate(clip_data["selected_frame_idx"])
                    if scene_types[idx] == scene_name
                ]

                if len(collect_frames_ids) > 0 and colleted_scenes[scene_name]["num"] < selected_scenes[scene_name]:  # type: ignore[operator] # pylint: disable=line-too-long # noqa:E501
                    clip_data["selected_frame_idx"] = collect_frames_ids
                    clip_data["selected_timestamp"] = [
                        frame_idx
                        for idx, frame_idx in enumerate(clip_data["selected_timestamp"])
                        if scene_types[idx] == scene_name
                    ]
                    colleted_scenes[scene_name]["data"].append(clip_data)  # type: ignore[operator, attr-defined] # pylint: disable=line-too-long # noqa:E501
                    colleted_scenes[scene_name]["num"] += len(collect_frames_ids)  # type: ignore[operator] # pylint: disable=line-too-long # noqa:E501

            finish_num = 0
            for scene_name in selected_scenes.keys():
                print(scene_name, colleted_scenes[scene_name]["num"])  # noqa: T201
                if colleted_scenes[scene_name]["num"] >= selected_scenes[scene_name]:  # type: ignore[operator] # pylint: disable=line-too-long # noqa:E501
                    with open(f"{dump_path}/{scene_name}.pkl", "wb") as f:  # type: ignore[assignment]
                        pkl.dump(colleted_scenes[scene_name]["data"], f)
                        finish_num += 1
            if finish_num == len(selected_scenes.keys()):
                sys.exit()
