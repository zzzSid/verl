# -*- coding: utf-8 -*-
# type: ignore
# flake8: noqa
import random
import pickle
from multiprocessing import Pool
import scipy
import itertools
import os

from tpp_onemodel.tools.astra_planner.data.data_utils.astra_planner_dataset_utils import (
    PlannerDatasetUtils,
)
from tpp_onemodel.tools.astra_planner.data.txt_to_pkl_utils import txt_to_pkl
import numpy as np
from tqdm import tqdm
from sklearn.cluster import KMeans


def norm_angle(angle):
    """Norm angle to be between -pi and pi."""
    while angle < -np.pi:
        angle = angle + 2 * np.pi
    while angle > np.pi:
        angle = angle - 2 * np.pi
    return angle


if __name__ == "__main__":

    DATA_PATH = "/share-global/ruonan.xue/planner/data/train_pkl/v0303_0312/planner_dataset_v0303_0312_all_data_val_10000_786432.pkl"
    DUMP_FOLDER = None
    LOAD_ALL_FRAMES = True
    NUMS_WORKER = 8
    INTERVAL = 1
    CLIP_SAMPLE_NUM = 5000

    if DATA_PATH.endswith(".txt"):
        DATA_PATH = txt_to_pkl([DATA_PATH], num_workers=16)[0]
    dataset = PlannerDatasetUtils(
        DATA_PATH,
        load_all_frames=LOAD_ALL_FRAMES,
    )

    random_clip_idx = random.sample(range(len(dataset)), CLIP_SAMPLE_NUM)

    if DUMP_FOLDER is None:
        raise Exception("DUMP_FOLDER is None, please set DUMP_FOLDER to a valid path")

    if not os.path.exists(DUMP_FOLDER):
        os.makedirs(DUMP_FOLDER)

    action_sapce_axis_name = ["acc", "yaw_rate"]

    def get_action_space(clip_id):
        clip_data = dataset[clip_id]
        clip_data.preload_frame_ceph_data()
        all_frames = [clip_data[i] for i in range(len(clip_data))]
        all_timestamp = np.array([frame.timestamp for frame in all_frames])
        all_timestamp_diff = all_timestamp[1:] - all_timestamp[:-1]

        all_ego_motion = np.array(
            [frame.frame_data["ego_motion"] for frame in all_frames]
        )  # vx,vy,acc_x,acc_y,yaw,yaw_rate,whlag,whlagspd,vehspd,lgta,chassis_yawrate, gear

        v_x = all_ego_motion[:, 0]
        acc = (v_x[1:] - v_x[:-1]) / all_timestamp_diff
        yaw = all_ego_motion[:, 4] - all_ego_motion[:, 4][0]
        delta_yaw = np.mod((yaw[1:] - yaw[:-1]) + np.pi, 2 * np.pi) - np.pi
        yaw_rate = delta_yaw / all_timestamp_diff

        return np.stack([acc, yaw_rate], axis=1)

    action_space = []
    if NUMS_WORKER == 1:
        for clip_id in tqdm(random_clip_idx, total=len(random_clip_idx)):
            action_space.append(get_action_space(clip_id))
    else:
        with Pool(NUMS_WORKER) as p:
            action_space = list(tqdm(p.imap(get_action_space, random_clip_idx), total=len(random_clip_idx)))

    action_space = np.concatenate(action_space, axis=0)

    action_dict = {key: action_space[:, i] for i, key in enumerate(action_sapce_axis_name)}

    action_space_combin = list(itertools.combinations(action_sapce_axis_name, 2))
    action_space_combin_index = list(itertools.combinations(range(len(action_sapce_axis_name)), 2))

    from matplotlib import pyplot as plt

    for action_name_0, action_name_1 in action_space_combin:
        plt.scatter(action_dict[action_name_0], action_dict[action_name_1], marker=".")
        plt.xlabel(action_name_0)
        plt.ylabel(action_name_1)
        plt.savefig(f"{DUMP_FOLDER}/test_{action_name_0}_{action_name_1}.jpg")
        plt.close()

    action_space_norm_dict = {
        key: (action_space[:, i] - np.min(action_space[:, i]))
        / (np.max(action_space[:, i]) - np.min(action_space[:, i]))
        for i, key in enumerate(action_sapce_axis_name)
    }

    action_space_norm = np.stack([action_space_norm_dict[key] for key in action_sapce_axis_name], axis=1)

    cluster_num = 512

    kmeans = KMeans(n_clusters=cluster_num, random_state=0).fit(action_space_norm)
    centers = kmeans.cluster_centers_
    all_sample_dis = scipy.spatial.distance.cdist(action_space_norm, kmeans.cluster_centers_)
    all_sample_center = np.argmin(all_sample_dis, axis=1)
    unique, counts = np.unique(all_sample_center, return_counts=True)
    ratio = counts / counts.sum()

    kmeans = {
        "kmeans": kmeans,
        "ratio": ratio,
    }
    kmeans.update(
        {
            f"{key}_range": [np.min(action_space[:, i]), np.max(action_space[:, i])]
            for i, key in enumerate(action_sapce_axis_name)
        }
    )

    from matplotlib import pyplot as plt

    for (action_name_0, action_name_1), (action_0_index, action_1_index) in zip(
        action_space_combin, action_space_combin_index
    ):
        plt.scatter(action_space[:, action_0_index], action_space[:, action_1_index], marker=".")
        plt.xlabel(action_name_0)
        plt.ylabel(action_name_1)

        plt.scatter(
            centers[:, action_0_index] * (kmeans[f"{action_name_0}_range"][1] - kmeans[f"{action_name_0}_range"][0])
            + kmeans[f"{action_name_0}_range"][0],
            centers[:, action_1_index] * (kmeans[f"{action_name_1}_range"][1] - kmeans[f"{action_name_1}_range"][0])
            + kmeans[f"{action_name_1}_range"][0],
            marker="x",
        )
        plt.savefig(
            f"{DUMP_FOLDER}/ar_action_vocab_{CLIP_SAMPLE_NUM}_{cluster_num}_{action_name_0}_{action_name_1}.jpg"
        )
        plt.close()

    with open(
        f"{DUMP_FOLDER}/ar_action_vocab_{CLIP_SAMPLE_NUM}_{cluster_num}.pkl",
        "wb",
    ) as f:
        pickle.dump(kmeans, f)
