# -*- coding: utf-8 -*-
import random
from multiprocessing import Pool

from tpp_onemodel.tools.astra_planner.data.data_utils.astra_planner_dataset_utils import (
    PlannerDatasetUtils,
)


if __name__ == "__main__":
    data_paths = [
        "/share-global/na.gao1/planner/data/pkls/1211/v1211_alldata/planner_dataset_v1211_alldata_train_w_tag_100ms_811203_82610081.pkl",
        # "/share-global/na.gao1/planner/data/pkls/1211/v1211_alldata/planner_dataset_v1211_alldata_train_wo_tag_100ms_209897_30482033.pkl",
    ]
    LOAD_ALL_FRAMES = True
    scene_tag_by_gt_paths = [
        "/share-global/feiyang.li/tag-static-vehicle-status-dlb-23w-1216_revised.json",
        "/share-global/feiyang.li/tag-static-vehicle-status-roadtest-180w-1213-revised.json",
    ]
    dataset = PlannerDatasetUtils(
        data_paths, load_all_frames=LOAD_ALL_FRAMES, scene_tag_by_gt_paths=scene_tag_by_gt_paths
    )
    DUMP_VIDEO = True
    NUMS_WORKER = 1
    INTERVAL = 1
    CLIP_SAMPLE_NUM = 10
    vis_dump_path = "/home/yuting.tang/exps/Astraplanner/melange"
    random_clip_idx = random.sample(range(len(dataset)), CLIP_SAMPLE_NUM)

    def vis_clip_idx(idx):
        """Vis clip idx."""
        clip_data = dataset[idx]
        clip_data.preload_frame_ceph_data()
        clip_data.vis(vis_dump_path, interval=INTERVAL, dump_video=DUMP_VIDEO)

    if NUMS_WORKER == 1:
        for clip_idx in random_clip_idx:
            vis_clip_idx(clip_idx)
    else:
        with Pool(NUMS_WORKER) as p:
            p.map(vis_clip_idx, random_clip_idx)
