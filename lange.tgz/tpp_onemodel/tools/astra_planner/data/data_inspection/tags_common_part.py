# -*- coding: utf-8 -*-
# flake8: noqa: F403
# flake8: noqa: F405
# type: ignore
import argparse

from tpp_onemodel.tools.astra_planner.data.data_inspection.tags_utils import *


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process some parameters.")
    parser.add_argument(
        "--tag_version_raw", default="prod_yx_20240919_tags_only_all", type=str, help="The version name of tag"
    )
    parser.add_argument(
        "--tag_version_new", default="prod_v202411061500_all_tags", type=str, help="The version name of tag"
    )
    parser.add_argument(
        "--save_dir",
        default="./data_compare",
        type=str,
        help="The saving path",
    )
    parser.add_argument(
        "--input_dataset_path_raw",
        default="/home/mccree.zhao/project/offline/2024/melange_all/2024_10/2024_11/melange_1121_data/data_compare/raw_common_sample.txt",
        type=str,
        help="The raw dataset clip list path",
    )
    parser.add_argument(
        "--input_dataset_path_new",
        default="/home/mccree.zhao/project/offline/2024/melange_all/2024_10/2024_11/melange_1121_data/data_compare/new_common_sample.txt",
        type=str,
        help="The new dataset clip list path",
    )
    parser.add_argument(
        "--raw_dict_name",
        default="raw_common",
        type=str,
        help="The raw dict name",
    )
    parser.add_argument(
        "--new_dict_name",
        default="new_common",
        type=str,
        help="The new dict name",
    )

    args = parser.parse_args()
    save_dir = args.save_dir
    os.makedirs(save_dir, exist_ok=True)
    # input_dataset_path_raw = os.path.join(save_dir, "file1_common_top200.txt")
    # input_dataset_path_new = os.path.join(save_dir, "file2_common_top200.txt")
    # input_dataset_path_raw = os.path.join(save_dir, "file1_common.txt")
    # input_dataset_path_new = os.path.join(save_dir, "file2_common.txt")
    input_dataset_path_raw = args.input_dataset_path_raw
    input_dataset_path_new = args.input_dataset_path_new

    clip_id_to_tags_dict_raw, tags_to_clip_id_dict_raw = export_single_scene_dataset(
        input_dataset_path_raw, save_dir, args.tag_version_raw, args.raw_dict_name
    )

    clip_id_to_tags_dict_new, tags_to_clip_id_dict_new = export_single_scene_dataset(
        input_dataset_path_new, save_dir, args.tag_version_new, args.new_dict_name
    )

    plot_tag_clip_distribution_with_csv_and_labels(
        tags_to_clip_id_dict_raw,
        os.path.join(save_dir, "tag_raw_distribution.png"),
        os.path.join(save_dir, "tag_raw_distribution.csv"),
    )
    plot_tag_clip_distribution_with_csv_and_labels(
        tags_to_clip_id_dict_new,
        os.path.join(save_dir, "tag_new_distribution.png"),
        os.path.join(save_dir, "tag_new_distribution.csv"),
    )
    plot_tag_clip_distribution_comparison_with_labels(
        tags_to_clip_id_dict_raw,
        tags_to_clip_id_dict_new,
        os.path.join(save_dir, "tag_new_raw_distribution_comparison.png"),
    )

    plot_tag_clip_distribution_with_csv_v2(
        tags_to_clip_id_dict_raw,
        tags_to_clip_id_dict_new,
        os.path.join(save_dir, "tag_new_raw_distribution_comparison.csv"),
    )
