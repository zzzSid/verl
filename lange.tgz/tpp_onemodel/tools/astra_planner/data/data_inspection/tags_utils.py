# -*- coding: utf-8 -*-
# flake8: noqa: D403
# flake8: noqa: D205
# flake8: noqa: D400
# flake8: noqa: D401
# flake8: noqa: D103
# flake8: noqa: T201
# type: ignore

import csv
import os
import pickle as pkl
import re
import subprocess
from concurrent.futures import ProcessPoolExecutor
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import as_completed
from typing import Any
from typing import Dict
from typing import List
from typing import Set
from typing import Tuple

import matplotlib
import matplotlib.font_manager as fm
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from read_cache_op_py import read_cache_op_py
from tqdm import tqdm

from tpp_onemodel.utils.niofs import get_niofs_client
from tpp_onemodel.utils.niofs import parse_niofs_url


matplotlib.use("Agg")
cpu_count = os.cpu_count() or 1  # Defaults to 1 if os.cpu_count() is None
ceph_client = get_niofs_client(max_pool_connections=cpu_count // 2)


def install_noto_sans_cjk():
    try:
        # 更新软件包索引
        subprocess.run(["sudo", "apt", "update"], check=True)

        # 安装 Noto Sans CJK 字体
        subprocess.run(["sudo", "apt", "install", "-y", "fonts-noto-cjk"], check=True)

        print("Noto Sans CJK 字体安装完成！")
    except subprocess.CalledProcessError as e:
        print(f"安装字体时出错: {e}")


def set_font_for_chinese():
    # Locate Noto Sans CJK fonts
    fonts = fm.findSystemFonts()
    noto_sans_cjk_fonts = [font for font in fonts if "NotoSansCJK" in font]
    if noto_sans_cjk_fonts:
        # Use the first available Noto Sans CJK font
        font_path = noto_sans_cjk_fonts[0]
        font_prop = fm.FontProperties(fname=font_path)
        plt.rcParams["font.family"] = font_prop.get_name()
        print(f"Using font: {font_prop.get_name()} ({font_path})")
    else:
        print("Noto Sans CJK font not found. Please install it and try again.")
        install_noto_sans_cjk()
        set_font_for_chinese()


set_font_for_chinese()


def process_meta_chunk(clip_pkl_paths: List[str]) -> Tuple[Dict[str, Dict[str, Any]], Set[str]]:
    """
    Process a chunk of clips and extract metadata.

    Args:
        clip_pkl_paths (List[str]): List of clip pickle paths.
        tag_version (str): The tag version to use.

    Returns:
        Tuple containing:
            - clip_id_to_frames_dict (Dict[str, Dict[str, Any]]),
            - wo_meta_clip_set (Set[str])
    """
    # 初始化本地结果
    local_clip_id_to_frames = {}
    local_wo_meta_clip_set = set()

    # 在子进程中初始化 ceph_client 和其他必要的资源
    # 例如，如果 ceph_client 需要初始化，可以在这里进行
    # ceph_client = initialize_ceph_client()

    for clip_pkl_path in tqdm(clip_pkl_paths, desc="Processing clips", position=0, leave=False):
        clip_pkl_path = clip_pkl_path.strip()

        try:
            if clip_pkl_path.startswith("huailai_cos:"):
                ceph_path = "/" + clip_pkl_path[len("huailai_cos:") :]
            else:
                raise NotImplementedError(f"Unknown prefix: {clip_pkl_path}")

            bucket_name, path = ceph_path[1:].split("/", 1)
            response_info = ceph_client.head_object(Bucket=bucket_name, Key=path)
            size = response_info["ContentLength"]
            ceph_path_full = f"{ceph_path} {size}"
            data_bytes = read_cache_op_py([ceph_path_full])[0]
            meta = pkl.loads(data_bytes)
            metadata = {
                "clip_pkl_path": clip_pkl_path,
                "timestamp_list": meta["timestamp_list"],
                "frame_len": len(meta["timestamp_list"]),
            }
            local_clip_id_to_frames[clip_pkl_path] = metadata
        except Exception as e:
            print(f"clip meta not found: {clip_pkl_path}", e)  # noqa: T201
            local_wo_meta_clip_set.add(clip_pkl_path)
            continue

    return local_clip_id_to_frames, local_wo_meta_clip_set


def read_meta(dataset_path: str, single_tag_path: str) -> Dict[str, Dict[str, Any]]:
    """
    Read metadata using multiprocessing with chunked processing.

    Args:
        dataset_path (str): Path to the dataset file containing clip pickle paths.
        single_tag_path (str): Path to save single tag data (not used in this function).
        tag_version (str): The tag version to use.

    Returns:
        Dict[str, Dict[str, Any]]: Mapping from clip_pkl_path to its metadata.
    """
    # 全局结果
    clip_id_to_frames_dict = {}
    wo_meta_clip_set = set()

    # 读取所有 clip_pkl_paths
    with open(dataset_path, "r") as f:
        clip_pkl_paths = f.readlines()

    total_clips = len(clip_pkl_paths)
    if total_clips == 0:
        print("No clips found in the dataset.")
        return clip_id_to_frames_dict

    # 确定进程数
    num_workers = os.cpu_count() or 4  # 如果 os.cpu_count() 返回 None，默认使用 4 个进程
    num_workers = max(1, num_workers // 2)  # 根据需要调整

    # 切分 clip_pkl_paths 为若干块
    def chunkify(lst: List[str], n: int) -> List[List[str]]:
        """将列表切分为 n 个子列表"""
        return [lst[i::n] for i in range(n)]

    chunks = chunkify(clip_pkl_paths, num_workers)

    # 使用 ProcessPoolExecutor 进行多进程处理
    with ProcessPoolExecutor(max_workers=num_workers) as executor:
        # 提交所有块
        future_to_chunk = {executor.submit(process_meta_chunk, chunk): idx for idx, chunk in enumerate(chunks)}

        # 使用 tqdm 显示总进度
        for future in tqdm(as_completed(future_to_chunk), total=len(future_to_chunk), desc="Processing chunks"):
            try:
                local_clip_id_to_frames, local_wo_meta_clip_set = future.result()
                # 合并 clip_id_to_frames_dict
                clip_id_to_frames_dict.update(local_clip_id_to_frames)

                # 合并 wo_meta_clip_set
                wo_meta_clip_set.update(local_wo_meta_clip_set)
            except Exception as e:
                print(f"Error processing a chunk: {e}")  # noqa: T201

    # 输出覆盖率信息
    covered_clips = len(clip_id_to_frames_dict)
    coverage_ratio = covered_clips / total_clips if total_clips > 0 else 0
    print(
        "Meta tags coverage ratio = ",
        coverage_ratio,
    )  # noqa: T201
    print(
        "Missing meta tags count = ",
        len(wo_meta_clip_set),
    )  # noqa: T201

    return clip_id_to_frames_dict


def process_clips_chunk(
    clip_pkl_paths: List[str], tag_version: str
) -> Tuple[Dict[str, Set[str]], Dict[str, Set[str]], Set[str]]:
    """
    Process a chunk of clips and extract tags.

    Args:
        clip_pkl_paths (List[str]): List of clip pickle paths.
        tag_version (str): The tag version to use.

    Returns:
        Tuple containing:
            - clip_id_to_tags_dict (Dict[str, Set[str]]),
            - tags_to_clip_id_dict (Dict[str, Set[str]]),
            - wo_tags_clip_set (Set[str])
    """
    # 初始化本地结果
    local_clip_id_to_tags = {}
    local_tags_to_clip_id = {}
    local_wo_tags_clip_set = set()

    # 在子进程中初始化 ceph_client 和其他必要的资源
    # 例如，如果 ceph_client 需要初始化，可以在这里进行
    # ceph_client = initialize_ceph_client()

    # 使用 tqdm 监控进度
    for clip_pkl_path in tqdm(clip_pkl_paths, desc="Processing clips", position=0, leave=False):
        clip_pkl_path = clip_pkl_path.strip()
        tag_pkl_path = [tag_version] + clip_pkl_path.split("/")[3:]
        tag_pkl_path = "/".join(tag_pkl_path)
        tags_path = os.path.join(
            os.path.dirname(tag_pkl_path).replace("meta_data", "tags"),
            os.path.basename(tag_pkl_path).replace(".pkl", "_tags.pkl"),
        )

        try:
            if tags_path.startswith("huailai_cos:"):
                ceph_path = "/" + tags_path[len("huailai_cos:") :]
            else:
                raise NotImplementedError(f"Unknown prefix: {tags_path}")

            bucket_name, path = ceph_path[1:].split("/", 1)
            response_info = ceph_client.head_object(Bucket=bucket_name, Key=path)
            size = response_info["ContentLength"]
            ceph_path_full = f"{ceph_path} {size}"
            data_bytes = read_cache_op_py([ceph_path_full])[0]
            tags = pkl.loads(data_bytes)
            tags_set = set()
            for key, tag in tags.items():
                if "objs" in tag:
                    tag_list = [_["cate"] for _ in tag["objs"]]
                else:
                    tag_list = tag["tag"]
                for one_tag in tag_list:
                    if "fft_urban" in one_tag or "md_bad_behavior" in one_tag or "leakage_future_info" in one_tag:
                        tags_set.add(one_tag)
                    if "province" in one_tag:
                        tags_set.add(one_tag.split(".")[-1])
            tags_set.discard(None)
            local_clip_id_to_tags[clip_pkl_path] = tags_set
            for tag in tags_set:
                if tag not in local_tags_to_clip_id:
                    local_tags_to_clip_id[tag] = set()
                local_tags_to_clip_id[tag].add(clip_pkl_path)
        except Exception as e:
            print(f"Tags not found: {tags_path}", e)  # noqa: T201
            local_wo_tags_clip_set.add(clip_pkl_path)
            continue

    return local_clip_id_to_tags, local_tags_to_clip_id, local_wo_tags_clip_set


def export_single_scene_dataset(
    dataset_path: str, single_tag_path: str, tag_version: str, file_name: str
) -> Tuple[Dict[str, Set[str]], Dict[str, Set[str]]]:
    """Single scene dataset export using multiprocessing with chunked processing."""
    # 全局结果
    clip_id_to_tags_dict = {}
    tags_to_clip_id_dict = {}
    wo_tags_clip_set = set()

    # 读取所有 clip_pkl_paths
    with open(dataset_path, "r") as f:
        clip_pkl_paths = f.readlines()

    total_clips = len(clip_pkl_paths)
    if total_clips == 0:
        print("No clips found in the dataset.")
        return clip_id_to_tags_dict, tags_to_clip_id_dict

    # 确定进程数
    num_workers = os.cpu_count() or 4  # 如果 os.cpu_count() 返回 None，默认使用 4 个进程
    num_workers = max(1, num_workers // 2)  # 根据需要调整

    # 切分 clip_pkl_paths 为若干块
    def chunkify(lst: List[str], n: int) -> List[List[str]]:
        """将列表切分为 n 个子列表"""
        return [lst[i::n] for i in range(n)]

    chunks = chunkify(clip_pkl_paths, num_workers)

    # 使用 ProcessPoolExecutor 进行多进程处理
    with ProcessPoolExecutor(max_workers=num_workers) as executor:
        # 提交所有块
        future_to_chunk = {
            executor.submit(process_clips_chunk, chunk, tag_version): idx for idx, chunk in enumerate(chunks)
        }

        # 使用 tqdm 显示总进度
        for future in tqdm(as_completed(future_to_chunk), total=len(future_to_chunk), desc="Processing chunks"):
            try:
                local_clip_id_to_tags, local_tags_to_clip_id, local_wo_tags_clip_set = future.result()
                # 合并 clip_id_to_tags_dict
                clip_id_to_tags_dict.update(local_clip_id_to_tags)

                # 合并 tags_to_clip_id_dict
                for tag, clip_ids in local_tags_to_clip_id.items():
                    if tag not in tags_to_clip_id_dict:
                        tags_to_clip_id_dict[tag] = set()
                    tags_to_clip_id_dict[tag].update(clip_ids)

                # 合并 wo_tags_clip_set
                wo_tags_clip_set.update(local_wo_tags_clip_set)
            except Exception as e:
                print(f"Error processing a chunk: {e}")  # noqa: T201

    # 保存结果
    os.makedirs(single_tag_path, exist_ok=True)

    if "/" in tag_version:
        tag_version = tag_version.split("/")[-1]
    # 保存 clip_id_to_tags_dict
    clip_id_to_tags_file = os.path.join(single_tag_path, f"clip_id_to_tags_dict_{tag_version}_{file_name}.pkl")
    with open(clip_id_to_tags_file, "wb") as f:
        pkl.dump(clip_id_to_tags_dict, f)
    print("Save clip_id_to_tags_dict to ", clip_id_to_tags_file)  # noqa: T201

    # 保存 tags_to_clip_id_dict
    tags_to_clip_id_file = os.path.join(single_tag_path, f"tags_to_clip_id_dict_{tag_version}_{file_name}.pkl")
    with open(tags_to_clip_id_file, "wb") as f:
        pkl.dump(tags_to_clip_id_dict, f)
    print("Save tags_to_clip_id_dict to ", tags_to_clip_id_file)  # noqa: T201

    # 输出覆盖率信息
    covered_clips = len(clip_id_to_tags_dict)
    covered_tags_clips = total_clips - len(wo_tags_clip_set)

    print(
        "Target tags coverage ratio = ",
        covered_clips / total_clips if total_clips > 0 else 0,
    )  # noqa: T201
    print(  # noqa: T201
        "All tags coverage ratio = ",
        covered_tags_clips / total_clips if total_clips > 0 else 0,
    )  # noqa: T201

    return clip_id_to_tags_dict, tags_to_clip_id_dict


def plot_tag_clip_distribution_with_csv_and_labels(tags_to_clip_id_dict_raw, fig_name, csv_name):
    """
    Plots the distribution of clips per tag using matplotlib, saves the data to a CSV file,
    and displays values on the bars.

    :param tags_to_clip_id_dict_raw: A dictionary where keys are tag names (str)
    and values are lists of clip names (list of str).
    :param fig_name: Name of the output figure file.
    :param csv_name: Name of the output CSV file.
    """
    # Extract tags and their corresponding clip counts
    tags = list(tags_to_clip_id_dict_raw.keys())
    clip_counts = [len(clips) for clips in tags_to_clip_id_dict_raw.values()]

    # Create a DataFrame and sort it by Clip_Count
    data = {"Tag": tags, "Clip_Count": clip_counts}
    df = pd.DataFrame(data).sort_values(by="Clip_Count", ascending=False)
    df.to_csv(csv_name, index=False)

    # Create the bar plot
    plt.figure(figsize=(max(10, len(tags) * 0.5), 10))  # Dynamically adjust the width
    bars = plt.bar(df["Tag"], df["Clip_Count"], alpha=0.75)
    plt.xlabel("Tags")
    plt.ylabel("Number of Clips")
    plt.title("Distribution of Clips per Tag")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()

    # Add labels on top of the bars
    for bar in bars:
        yval = bar.get_height()
        plt.text(bar.get_x() + bar.get_width() / 2, yval + 0.05, int(yval), ha="center", va="bottom")

    # Save the plot
    plt.savefig(fig_name)
    # plt.show()

    return csv_name


def plot_tag_clip_distribution_comparison_with_labels(tags_to_clip_id_dict_raw, tags_to_clip_id_dict_new, fig_name):
    """
    Compares the distribution of clips per tag between two dictionaries, visualizes the differences,
    ensures the labels are clear, dynamically adjusts value labels to avoid overlap,
    and uses different colors for raw and new clip counts.

    :param tags_to_clip_id_dict_raw: A dictionary where keys are tag names (str) and values are lists of clip names (list of str).
    :param tags_to_clip_id_dict_new: A second dictionary of the same format to compare against the first.
    :param fig_name: Name of the output figure file.
    """
    # Extract unique tags from both dictionaries
    all_tags = set(tags_to_clip_id_dict_raw.keys()).union(tags_to_clip_id_dict_new.keys())

    # Count the clips for each tag in both dictionaries
    raw_clip_counts = {tag: len(tags_to_clip_id_dict_raw.get(tag, [])) for tag in all_tags}
    new_clip_counts = {tag: len(tags_to_clip_id_dict_new.get(tag, [])) for tag in all_tags}

    # Sort by raw clip counts for better clarity in the plot
    sorted_tags = sorted(all_tags, key=lambda tag: raw_clip_counts[tag], reverse=True)
    sorted_raw_clip_counts = [raw_clip_counts[tag] for tag in sorted_tags]
    sorted_new_clip_counts = [new_clip_counts[tag] for tag in sorted_tags]

    # Create a bar plot for comparison
    x = range(len(sorted_tags))
    width = 0.35  # Width of the bars

    plt.figure(figsize=(max(24, len(sorted_tags) * 1), 20))  # Dynamically adjust the width based on the number of tags
    bars1 = plt.bar(x, sorted_raw_clip_counts, width, label="Raw Clips", color="skyblue", alpha=0.7)
    bars2 = plt.bar([i + width for i in x], sorted_new_clip_counts, width, label="New Clips", color="orange", alpha=0.7)

    # Add labels and title
    plt.xlabel("Tags")
    plt.ylabel("Number of Clips")
    plt.title("Comparison of Clip Counts per Tag")
    plt.xticks([i + width / 2 for i in x], sorted_tags, rotation=45, ha="right")
    plt.legend()
    plt.tight_layout()

    # Add labels on top of the bars
    for bar in bars1 + bars2:
        yval = bar.get_height()
        fontsize = 6  # Adjust font size for larger numbers
        vertical_adjustment = 0.01 if yval < 10 else yval * 0.001  # Adjust position based on height
        plt.text(
            bar.get_x() + bar.get_width() / 2,
            yval + vertical_adjustment,
            int(yval),
            ha="center",
            va="bottom",
            fontsize=fontsize,
        )

    # Save the plot
    plt.savefig(fig_name)
    plt.show()


def plot_tag_clip_distribution_with_csv_v2(
    tags_to_clip_id_dict_raw, tags_to_clip_id_dict_new, filename="tag_clip_comparison.csv"
):
    """
    Compares the distribution of clips per tag between two dictionaries, visualizes the differences,
    and saves the comparison data into a CSV file within the function.

    :param tags_to_clip_id_dict_raw: A dictionary where keys are tag names (str) and values are lists of clip names (list of str).
    :param tags_to_clip_id_dict_new: A second dictionary of the same format to compare against the first.
    :param output_dir: Directory to save the CSV file.
    :param filename: Name of the CSV file to save.
    """

    # Extract unique tags from both dictionaries
    all_tags = set(tags_to_clip_id_dict_raw.keys()).union(tags_to_clip_id_dict_new.keys())

    # Count the clips for each tag in both dictionaries
    raw_clip_counts = {tag: len(tags_to_clip_id_dict_raw.get(tag, [])) for tag in all_tags}
    new_clip_counts = {tag: len(tags_to_clip_id_dict_new.get(tag, [])) for tag in all_tags}

    # Calculate the difference
    data = []
    for tag in all_tags:
        raw_count = raw_clip_counts[tag]
        new_count = new_clip_counts[tag]
        diff = new_count - raw_count
        data.append({"Tag": tag, "Raw_Clip_Num": raw_count, "New_Clip_Num": new_count, "Difference": diff})

    # Create a DataFrame
    df = pd.DataFrame(data)

    # Sort by New_Clip_Num (descending)
    df = df.sort_values(by="New_Clip_Num", ascending=False)

    # Save to CSV
    df.to_csv(filename, index=False)

    return None


def analyze_clip_diff_with_frames(
    clip_id_to_frames_dict_raw, clip_id_to_frames_dict_new, frames_compare_save_dir, save_name, fig1_name, fig2_name
):
    """
    分析两个clip数据中frame_len的分布，并将直方图保存到指定文件夹

    参数:
        clip_id_to_frames_dict_raw: dict, 原始clip数据，每个value中应包含'frame_len'字段
        clip_id_to_frames_dict_new: dict, 新clip数据，每个value中应包含'frame_len'字段
        frames_compare_save_dir: str, 保存直方图的目录
    """
    # 如果保存目录不存在，则创建
    if not os.path.exists(frames_compare_save_dir):
        os.makedirs(frames_compare_save_dir)

    # 收集frame长度数据
    raw_frame_lengths = [info["frame_len"] for info in clip_id_to_frames_dict_raw.values() if "frame_len" in info]
    new_frame_lengths = [info["frame_len"] for info in clip_id_to_frames_dict_new.values() if "frame_len" in info]

    # print(raw_frame_lengths)
    # print(new_frame_lengths)

    # 设置bins，0到1000范围内均分20个bin
    bins = np.linspace(0, 400, 10)

    # 绘制直方图，两个子图分别显示raw和new数据
    plt.figure(figsize=(12, 6))

    # 原始数据直方图
    plt.subplot(1, 2, 1)
    plt.hist(raw_frame_lengths, bins=bins, color="skyblue", edgecolor="black")
    plt.title(fig1_name + " Clips Frame Distribution")
    plt.xlabel("Frame Length")
    plt.ylabel("Number of Clips")
    plt.xlim(0, 400)

    # 新数据直方图
    plt.subplot(1, 2, 2)
    plt.hist(new_frame_lengths, bins=bins, color="salmon", edgecolor="black")
    plt.title(fig2_name + " Clips Frame Distribution")
    plt.xlabel("Frame Length")
    plt.ylabel("Number of Clips")
    plt.xlim(0, 400)

    plt.tight_layout()

    # 保存直方图到指定文件夹
    save_path = os.path.join(frames_compare_save_dir, "{}.png".format(save_name))
    plt.savefig(save_path)
    plt.close()

    print(f"直方图已保存至: {save_path}")


def analyze_clip_differences_with_frames(clip_id_to_frames_dict_raw, clip_id_to_frames_dict_new, save_dir):
    # 创建保存目录
    os.makedirs(save_dir, exist_ok=True)

    # 阈值定义
    thresholds = [7.05, 7.1, 7.2, 7.3, 7.5, 8.0, 9.0]
    # 为绘图定义的分布区间点
    bins = [6.5, 6.9, 6.97, 7.03, 7.05, 7.1, 7.2, 7.3, 7.4, 7.5, 8.0, 9.0]

    def adjust_keys(input_dict):
        adjusted_dict = {}
        for key, value in input_dict.items():
            new_key = key.split("/")[3].replace(".000000", "")
            timestamp_list = np.array(value["timestamp_list"])
            if len(timestamp_list) < 2:
                mean_time_gap = 0
                anomoly_frames = 0
            else:
                time_gaps = timestamp_list[1:] - timestamp_list[:-1]
                mean_time_gap = np.mean(time_gaps)
                anomoly_frames = (np.abs(time_gaps - 0.2) > 0.03).sum()
            adjusted_dict[new_key] = {
                "frame_len": value["frame_len"],
                "original_key": key,
                "mean_time_gap": mean_time_gap,
                "anomoly_frames": anomoly_frames,
                "timestamp_list": timestamp_list,  # 保存timestamp_list方便后续计算
            }
        return adjusted_dict

    raw_adjusted = adjust_keys(clip_id_to_frames_dict_raw)
    new_adjusted = adjust_keys(clip_id_to_frames_dict_new)

    # Identify common keys and handle mismatched lengths
    common_keys = set(raw_adjusted.keys()).intersection(new_adjusted.keys())
    missing_in_new = set(raw_adjusted.keys()) - set(new_adjusted.keys())
    missing_in_raw = set(new_adjusted.keys()) - set(raw_adjusted.keys())

    # Initialize statistics
    stats = {
        "new_more_than_raw": 0,
        "new_equal_to_raw": 0,
        "new_less_than_raw": 0,
        "total_clips": 0,
        "total_frame_difference": 0,
        "missing_in_new": len(missing_in_new),
        "missing_in_raw": len(missing_in_raw),
        "total_mean_time_gap_raw": 0,
        "total_mean_time_gap_new": 0,
        "total_anomoly_frames_raw": 0,
        "total_anomoly_frames_new": 0,
        "new_more_anomaly_than_raw": 0,
        "new_equal_anomaly_to_raw": 0,
        "new_less_anomaly_than_raw": 0,
    }

    # Collect differences
    frame_differences = []
    anomaly_differences = []

    # 收集所有帧的未来35帧时间长度（raw/new）
    all_future35_raw_list = []
    all_future35_new_list = []

    # 计算未来35帧的时间长度函数
    def compute_future_35_length(timestamp_list):
        future_lengths = []
        # 35帧理论上是7s，但需根据实际timestamp计算
        # future_length[i] = timestamp[i+35] - timestamp[i] (若i+35超出长度则不计)
        for i in range(len(timestamp_list)):
            if i + 35 < len(timestamp_list):
                future_length = timestamp_list[i + 35] - timestamp_list[i]
                future_lengths.append(future_length)
        return np.array(future_lengths)

    for key in common_keys:
        raw_data = raw_adjusted[key]
        new_data = new_adjusted[key]

        raw_frames = raw_data["frame_len"]
        new_frames = new_data["frame_len"]
        frame_diff = new_frames - raw_frames

        raw_mean_time_gap = raw_data["mean_time_gap"]
        new_mean_time_gap = new_data["mean_time_gap"]
        raw_anomoly_frames = raw_data["anomoly_frames"]
        new_anomoly_frames = new_data["anomoly_frames"]
        anomaly_frame_diff = new_anomoly_frames - raw_anomoly_frames

        # Update frame stats
        stats["total_clips"] += 1
        stats["total_frame_difference"] += frame_diff

        if frame_diff > 0:
            stats["new_more_than_raw"] += 1
        elif frame_diff == 0:
            stats["new_equal_to_raw"] += 1
        else:
            stats["new_less_than_raw"] += 1

        # Update anomaly stats
        stats["total_mean_time_gap_raw"] += raw_mean_time_gap
        stats["total_mean_time_gap_new"] += new_mean_time_gap
        stats["total_anomoly_frames_raw"] += raw_anomoly_frames
        stats["total_anomoly_frames_new"] += new_anomoly_frames

        if anomaly_frame_diff > 0:
            stats["new_more_anomaly_than_raw"] += 1
        elif anomaly_frame_diff == 0:
            stats["new_equal_anomaly_to_raw"] += 1
        else:
            stats["new_less_anomaly_than_raw"] += 1

        # Append to frame differences list
        frame_differences.append(
            {
                "clip_id": key,
                "raw_pkl": raw_data["original_key"],
                "new_pkl": new_data["original_key"],
                "raw_frames": raw_frames,
                "new_frames": new_frames,
                "frame_difference": frame_diff,
                "abs_frame_diff": abs(frame_diff),
            }
        )

        # Append to anomaly differences list
        anomaly_differences.append(
            {
                "clip_id": key,
                "raw_pkl": raw_data["original_key"],
                "new_pkl": new_data["original_key"],
                "raw_anomoly_frames": raw_anomoly_frames,
                "new_anomoly_frames": new_anomoly_frames,
                "anomaly_frame_difference": anomaly_frame_diff,
                "abs_anomaly_frame_diff": abs(anomaly_frame_diff),
                "raw_mean_time_gap": raw_mean_time_gap,
                "new_mean_time_gap": new_mean_time_gap,
            }
        )

        # 计算未来35帧时间长度
        raw_future_35 = compute_future_35_length(raw_data["timestamp_list"])
        new_future_35 = compute_future_35_length(new_data["timestamp_list"])

        # 对齐长度，以最短的为准
        min_len = min(len(raw_future_35), len(new_future_35))
        if min_len > 0:
            all_future35_raw_list.append(raw_future_35[:min_len])
            all_future35_new_list.append(new_future_35[:min_len])

    # 合并所有帧数据
    if len(all_future35_raw_list) > 0:
        all_future35_raw = np.concatenate(all_future35_raw_list)
    else:
        all_future35_raw = np.array([])

    if len(all_future35_new_list) > 0:
        all_future35_new = np.concatenate(all_future35_new_list)
    else:
        all_future35_new = np.array([])

    # Compute averages
    if stats["total_clips"] > 0:
        avg_mean_time_gap_raw = stats["total_mean_time_gap_raw"] / stats["total_clips"]
        avg_mean_time_gap_new = stats["total_mean_time_gap_new"] / stats["total_clips"]
    else:
        avg_mean_time_gap_raw = 0
        avg_mean_time_gap_new = 0

    # Prepare summary statistics for frame differences
    summary_stats_frames = {
        "Total Clips": stats["total_clips"],
        "Total Frames Difference": stats["total_frame_difference"],
        "Clips (New > Raw)": stats["new_more_than_raw"],
        "Clips (New = Raw)": stats["new_equal_to_raw"],
        "Clips (New < Raw)": stats["new_less_than_raw"],
        "Missing in New": stats["missing_in_new"],
        "Missing in Raw": stats["missing_in_raw"],
    }

    # Prepare summary statistics for anomaly differences
    summary_stats_anomalies = {
        "Total Clips": stats["total_clips"],
        "Average Time Gap (Old Data)": avg_mean_time_gap_raw,
        "Average Time Gap (New Data)": avg_mean_time_gap_new,
        "Total Anomaly Frames (Old Data)": stats["total_anomoly_frames_raw"],
        "Total Anomaly Frames (New Data)": stats["total_anomoly_frames_new"],
        "Clips with More Anomaly Frames in New Data": stats["new_more_anomaly_than_raw"],
        "Clips with Equal Anomaly Frames in New Data": stats["new_equal_anomaly_to_raw"],
        "Clips with Fewer Anomaly Frames in New Data": stats["new_less_anomaly_than_raw"],
        "Missing in New": stats["missing_in_new"],
        "Missing in Raw": stats["missing_in_raw"],
    }

    # Convert differences to DataFrames and sort
    frame_differences_df = pd.DataFrame(frame_differences)
    frame_differences_df = frame_differences_df.sort_values(by="abs_frame_diff", ascending=False)

    anomaly_differences_df = pd.DataFrame(anomaly_differences)
    anomaly_differences_df = anomaly_differences_df.sort_values(by="abs_anomaly_frame_diff", ascending=False)

    # Top 10 differences
    top_10_frame_differences = frame_differences_df.head(10)
    top_10_anomaly_differences = anomaly_differences_df.head(10)

    # Save the initial statistics and differences
    stats_frames_df = pd.DataFrame([summary_stats_frames])
    stats_frames_df.to_csv(f"{save_dir}/clip_statistics_summary.csv", index=False)

    stats_anomalies_df = pd.DataFrame([summary_stats_anomalies])
    stats_anomalies_df.to_csv(f"{save_dir}/summary_anomaly_stats.csv", index=False)

    top_10_frame_differences.to_csv(f"{save_dir}/top_10_frame_differences.csv", index=False)
    top_10_anomaly_differences.to_csv(f"{save_dir}/top_10_anomaly_frame_differences.csv", index=False)

    # ------------------- 新功能统计部分 -------------------
    total_frames_raw = len(all_future35_raw)
    total_frames_new = len(all_future35_new)

    future35_stats = []
    for thr in thresholds:
        if total_frames_raw > 0:
            raw_count = np.sum(all_future35_raw > thr)
            raw_ratio = raw_count / total_frames_raw
        else:
            raw_count = 0
            raw_ratio = 0

        if total_frames_new > 0:
            new_count = np.sum(all_future35_new > thr)
            new_ratio = new_count / total_frames_new
        else:
            new_count = 0
            new_ratio = 0

        # 同时统计 (raw>thr & new<thr) 和 (raw<thr & new>thr)
        # 注意这里是元素级对齐，因为我们确保了 all_future35_raw 和 all_future35_new 长度相同
        if total_frames_raw > 0 and total_frames_new > 0:
            condition_raw_g_new_l = np.sum((all_future35_raw > thr) & (all_future35_new < thr))
            condition_raw_l_new_g = np.sum((all_future35_raw < thr) & (all_future35_new > thr))
            denominator = max(total_frames_raw, total_frames_new, 1)
            cond_rg_nl_ratio = condition_raw_g_new_l / denominator
            cond_rl_ng_ratio = condition_raw_l_new_g / denominator
        else:
            condition_raw_g_new_l = 0
            condition_raw_l_new_g = 0
            cond_rg_nl_ratio = 0
            cond_rl_ng_ratio = 0

        future35_stats.append(
            {
                "threshold": thr,
                "raw_greater_count": raw_count,
                "raw_greater_ratio": raw_ratio,
                "new_greater_count": new_count,
                "new_greater_ratio": new_ratio,
                "raw_greater_new_less_count": condition_raw_g_new_l,
                "raw_greater_new_less_ratio": cond_rg_nl_ratio,
                "raw_less_new_greater_count": condition_raw_l_new_g,
                "raw_less_new_greater_ratio": cond_rl_ng_ratio,
            }
        )

    # 保存第一个csv表格：raw和new数据在各阈值下大于阈值帧数及比例
    df_future35_greater = pd.DataFrame(future35_stats)[
        ["threshold", "raw_greater_count", "raw_greater_ratio", "new_greater_count", "new_greater_ratio"]
    ]
    df_future35_greater.to_csv(os.path.join(save_dir, "future35_greater_stats.csv"), index=False)

    # 保存第二个csv表格：raw>thr&new<thr 和 raw<thr&new>thr 的统计
    df_future35_cross = pd.DataFrame(future35_stats)[
        [
            "threshold",
            "raw_greater_new_less_count",
            "raw_greater_new_less_ratio",
            "raw_less_new_greater_count",
            "raw_less_new_greater_ratio",
        ]
    ]
    df_future35_cross.to_csv(os.path.join(save_dir, "future35_cross_stats.csv"), index=False)

    # 绘图：分布图
    plt.figure(figsize=(10, 6))
    # 绘制raw和new的直方图分布(使用bins定义区间)
    if total_frames_raw > 0:
        all_future35_raw_viz = all_future35_raw[(all_future35_raw < 6.97) | (all_future35_raw > 7.03)]
        plt.hist(all_future35_raw_viz, bins=bins, alpha=0.5, label="Raw", edgecolor="black")
    if total_frames_new > 0:
        all_future35_new_viz = all_future35_new[(all_future35_new < 6.97) | (all_future35_new > 7.03)]
        plt.hist(all_future35_new_viz, bins=bins, alpha=0.5, label="New", edgecolor="black")

    plt.title("Distribution of Future 35 Frames Time Length")
    plt.xlabel("Time (s)")
    plt.ylabel("Frame Count")
    plt.legend()

    # 保存图片
    plt.savefig(os.path.join(save_dir, "future35_distribution.png"))
    plt.close()

    print("Analysis completed. Files saved to:", save_dir)
    print("Additional Info:")
    print(f"Clips missing in New: {len(missing_in_new)}")
    print(f"Clips missing in Raw: {len(missing_in_raw)}")
    print("Future 35 frames analysis completed.")


def analyze_clip_frame_gap(clip_id_to_frames_dict, save_dir, save_name):
    """
    分析每个 clip 内的帧间时间差以及未来25帧累计时长分布，生成统计 CSV 文件和直方图。

    参数:
        clip_id_to_frames_dict: dict
            - key: clip 的标识（如 clip 路径）
            - value: dict，必须包含 key 'timestamp_list'，其值为按升序排列的时间戳列表（单位：秒）
        save_dir: str
            保存 CSV 和直方图的文件夹路径，如果不存在会自动创建。
        save_name: str
            用于生成输出文件名的前缀

    功能:
    1. 帧间差统计：
       - 遍历所有 clip，计算相邻帧时间差（gap）。
       - 统计所有 gap 的数量（总帧间差数）、以及 gap 在 [0.19,0.21] 内的数量和比例。
       - 在 [0.1,0.3] 区间内划分 20 个 bin，统计各区间内 gap 的数量，
         并生成直方图和 CSV 文件，文件分别命名为
         "{save_name}_frame_gap_histogram.png" 和 "{save_name}_frame_gap_statistics.csv"。

    2. 未来25帧累计时长统计：
       - 对于每个 clip，遍历所有帧，若该帧之后至少有25帧，则计算累计时长：即 timestamp[i+25] - timestamp[i]。
         （理论上如果每个帧间隔为0.2秒，则累计时长应为5秒）
       - 仅统计累计时长落在 [4,10] 秒区间内的数据。
       - 在 [4,10] 区间内划分 30 个 bin，统计各 bin 内的帧数，
         并生成直方图和 CSV 文件，文件分别命名为
         "{save_name}_future_25_frame_duration_histogram.png" 和 "{save_name}_future_25_frame_duration_statistics.csv"。
       - 新增统计：统计累计时长中，大于5.5秒、6秒、7秒的帧数量及其占比（以落在[4,10]内的总数量为基准）。
    """
    # 如果保存目录不存在，则创建
    os.makedirs(save_dir, exist_ok=True)

    # -------------------- 帧间差统计 --------------------
    gap_list = []  # 存放所有计算出的相邻帧时间差
    total_gap_count = 0  # 所有 gap 的数量

    for clip_id, clip_info in clip_id_to_frames_dict.items():
        timestamps = clip_info.get("timestamp_list", [])
        if len(timestamps) < 2:
            continue  # 帧数不足，不计算帧间差
        # 确保时间戳为升序
        timestamps = sorted(timestamps)
        # 计算相邻帧时间差
        gaps = np.diff(timestamps)
        gap_list.extend(gaps)
        total_gap_count += len(gaps)

    gap_array = np.array(gap_list)

    # 统计落在 [0.19, 0.21] 内的 gap 数量（视为正常帧间差）
    normal_mask = (gap_array >= 0.19) & (gap_array <= 0.21)
    normal_count = np.sum(normal_mask)
    normal_ratio = normal_count / total_gap_count if total_gap_count > 0 else 0

    # 直方图统计：定义 [0.1,0.3] 区间内的 20 个 bin
    bins_gap = np.linspace(0.1, 0.3, 21)  # 21 个边界值产生20个区间
    hist_counts_gap, _ = np.histogram(gap_array, bins=bins_gap)

    plt.figure(figsize=(10, 6))
    plt.hist(gap_array, bins=bins_gap, edgecolor="black")
    plt.xlabel("帧间差 (秒)")
    plt.ylabel("帧数")
    plt.title("帧间差分布直方图")
    plt.xlim(0.1, 0.3)

    histogram_gap_path = os.path.join(save_dir, save_name + "_frame_gap_histogram.png")
    plt.savefig(histogram_gap_path)
    plt.close()

    # 写入 CSV 文件：帧间差统计
    csv_gap_path = os.path.join(save_dir, save_name + "_frame_gap_statistics.csv")
    with open(csv_gap_path, mode="w", newline="") as csv_file:
        writer = csv.writer(csv_file)
        # 总体统计部分
        writer.writerow(["总帧间差数", "正常帧间差数（0.19-0.21秒）", "正常比例"])
        writer.writerow([total_gap_count, normal_count, normal_ratio])
        writer.writerow([])  # 空一行分隔
        # 各 bin 的统计
        writer.writerow(["Bin区间", "帧数"])
        for i in range(len(hist_counts_gap)):
            bin_range = f"[{bins_gap[i]:.2f}, {bins_gap[i+1]:.2f})"
            writer.writerow([bin_range, hist_counts_gap[i]])

    print(f"帧间差统计 CSV 已保存至: {csv_gap_path}")
    print(f"帧间差直方图已保存至: {histogram_gap_path}")

    # -------------------- 未来25帧累计时长统计 --------------------
    future_durations = []  # 存放累计时长的列表

    for clip_id, clip_info in clip_id_to_frames_dict.items():
        timestamps = clip_info.get("timestamp_list", [])
        if len(timestamps) < 26:
            # 至少需要当前帧和后面25帧，总共26帧
            continue
        timestamps = sorted(timestamps)
        # 对于每个帧，若其后至少有25帧，则计算累计时长
        for i in range(len(timestamps) - 25):
            duration = timestamps[i + 25] - timestamps[i]
            # 仅统计累计时长在 [4,10] 秒范围内的数据
            if 4 <= duration <= 10:
                future_durations.append(duration)

    future_durations = np.array(future_durations)
    total_future_count = len(future_durations)

    # 定义 [4,10] 区间内的 30 个 bin
    bins_future = np.linspace(4, 10, 31)  # 31个边界值形成30个区间
    hist_counts_future, _ = np.histogram(future_durations, bins=bins_future)

    plt.figure(figsize=(10, 6))
    plt.hist(future_durations, bins=bins_future, edgecolor="black")
    plt.xlabel("未来25帧累计时长 (秒)")
    plt.ylabel("帧数")
    plt.title("未来25帧累计时长分布直方图")
    plt.xlim(4, 10)

    histogram_future_path = os.path.join(save_dir, save_name + "_future_25_frame_duration_histogram.png")
    plt.savefig(histogram_future_path)
    plt.close()

    # 统计未来累计时长中，大于5.5秒、6秒、7秒的数量及占比
    count_gt_5_5 = np.sum(future_durations > 5.5)
    count_gt_6 = np.sum(future_durations > 6.0)
    count_gt_7 = np.sum(future_durations > 7.0)
    ratio_gt_5_5 = count_gt_5_5 / total_future_count if total_future_count > 0 else 0
    ratio_gt_6 = count_gt_6 / total_future_count if total_future_count > 0 else 0
    ratio_gt_7 = count_gt_7 / total_future_count if total_future_count > 0 else 0

    # 写入 CSV 文件：未来25帧累计时长统计
    csv_future_path = os.path.join(save_dir, save_name + "_future_25_frame_duration_statistics.csv")
    with open(csv_future_path, mode="w", newline="") as csv_file:
        writer = csv.writer(csv_file)
        # 总体统计部分
        writer.writerow(["总累计时长计数（落在[4,10]内）", " ", " "])
        writer.writerow([total_future_count, " ", " "])
        writer.writerow([])  # 空行分隔

        # 新增统计：大于阈值的数量及比例
        writer.writerow(["阈值 (秒)", "数量", "占比 (相对于落在[4,10]内的总计数)"])
        writer.writerow([">5.5", count_gt_5_5, ratio_gt_5_5])
        writer.writerow([">6.0", count_gt_6, ratio_gt_6])
        writer.writerow([">7.0", count_gt_7, ratio_gt_7])
        writer.writerow([])  # 空行分隔

        # 各 bin 的统计
        writer.writerow(["Bin区间", "帧数"])
        for i in range(len(hist_counts_future)):
            bin_range = f"[{bins_future[i]:.2f}, {bins_future[i+1]:.2f})"
            writer.writerow([bin_range, hist_counts_future[i]])

    print(f"未来25帧累计时长统计 CSV 已保存至: {csv_future_path}")
    print(f"未来25帧累计时长直方图已保存至: {histogram_future_path}")
