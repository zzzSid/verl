# -*- coding: utf-8 -*-
# flake8: noqa: F403
# flake8: noqa: F405
# type: ignore
import argparse

from tpp_onemodel.tools.astra_planner.data.data_inspection.tags_utils import *


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process some parameters.")
    parser.add_argument("--save_dir", default="./data_compare", type=str, help="The saving path")
    parser.add_argument(
        "--raw_dataset_name",
        default="raw_common_sample.txt",
        type=str,
        help="The raw dataset clip list path",
    )
    parser.add_argument(
        "--new_dataset_name",
        default="new_common_sample.txt",
        type=str,
        help="The new dataset clip list path",
    )

    args = parser.parse_args()
    save_dir = args.save_dir
    input_dataset_path_raw = os.path.join(save_dir, args.raw_dataset_name)
    input_dataset_path_new = os.path.join(save_dir, args.new_dataset_name)
    # input_dataset_path_raw = os.path.join(save_dir, "file1_common.txt")
    # input_dataset_path_new = os.path.join(save_dir, "file2_common.txt")

    clip_id_to_frames_dict_raw = read_meta(input_dataset_path_raw, save_dir)
    clip_id_to_frames_dict_new = read_meta(input_dataset_path_new, save_dir)

    frames_compare_save_dir = os.path.join(save_dir, "frames_compare")
    os.makedirs(frames_compare_save_dir, exist_ok=True)

    analyze_clip_frame_gap(clip_id_to_frames_dict_raw, frames_compare_save_dir, save_name="raw_common")
    analyze_clip_frame_gap(clip_id_to_frames_dict_new, frames_compare_save_dir, save_name="new_common")

    analyze_clip_diff_with_frames(
        clip_id_to_frames_dict_raw,
        clip_id_to_frames_dict_new,
        frames_compare_save_dir,
        save_name="common_clip_frame_num",
        fig1_name="RawCommonData",
        fig2_name="NewCommonData",
    )

    analyze_clip_differences_with_frames(
        clip_id_to_frames_dict_raw, clip_id_to_frames_dict_new, frames_compare_save_dir
    )
