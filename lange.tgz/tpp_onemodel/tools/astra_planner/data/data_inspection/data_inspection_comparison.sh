source .venv/bin/activate

# Predefined params

raw_file_list=("/share-global/jackson.zhong/share/planning/weekly51/1216fix_w51_adw_b1_10w.txt"
    "/share-global/jackson.zhong/share/planning/12_11_weekly/1208_prod_urban_adw_b1_10w.txt"
    "/share-global/jackson.zhong/share/planning/12_11_weekly/1208_prod_urban_adw_b2_55w.txt"
    "/share-global/jackson.zhong/share/planning/12_11_weekly/1211_adw_urban_new.txt"
    "/share-global/jackson.zhong/share/planning/12_11_weekly/1211_bj_total_adw_15hz.txt"
    "/share-global/jackson.zhong/share/planning/12_11_weekly/1211_prod_bj_dlb_30hz.txt"
    "/share-global/jackson.zhong/share/planning/12_11_weekly/1211_prod_bj_dlb_15hz.txt"
    "/share-global/jackson.zhong/share/planning/12_11_weekly/1211_dlb_fft_narrow_10wclips.txt"
    "/share-global/jackson.zhong/share/planning/12_11_weekly/1217_prod_country_road_dlb_30hz.txt"
    "/share-global/jackson.zhong/share/planning/12_11_weekly/1217_prod_country_road_dlb_15hz.txt"
    "/share-global/jackson.zhong/share/planning/12_11_weekly/1211_dlb_new_14w_clips.txt"
    "/share-global/jackson.zhong/share/planning/12_11_weekly/1211_dlb_manner_navpth_15hz.txt"
    "/share-global/jackson.zhong/share/planning/12_11_weekly/1211_dlb_manner_navpth_30hz.txt"
    "/share-global/jackson.zhong/share/planning/12_11_weekly/following_stop.txt"
)
new_file_list=(
    "/share-global/jackson.zhong/share/planning/12_19_weekly/v20241219_output_b1_roadtest_adw_5wclips.txt"
    "/share-global/jackson.zhong/share/planning/12_19_weekly/v20241219_output_exist_adw_clips.txt"
    "/share-global/jackson.zhong/share/planning/12_19_weekly/v20241219_output_bj_adw_15hz.txt"
    "/share-global/jackson.zhong/share/planning/12_19_weekly/v20241219_output_append_adw.txt"
    "/share-global/jackson.zhong/share/planning/12_19_weekly/v20241219_output_to_1211_new_append_adw.txt"
    "/share-global/jackson.zhong/share/planning/12_19_weekly/v20241219_output_b1_roadtest_dlb_5wclips.txt"
    "/share-global/jackson.zhong/share/planning/12_19_weekly/v20241219_output_bj_dlb_30hz.txt"
    "/share-global/jackson.zhong/share/planning/12_19_weekly/v20241219_output_bj_dlb_15hz.txt"
    "/share-global/jackson.zhong/share/planning/12_19_weekly/v20241219_output_exist_dlb_clips.txt"
    "/share-global/jackson.zhong/share/planning/12_19_weekly/v20241219_output_country_road_dlb_30hz.txt"
    "/share-global/jackson.zhong/share/planning/12_19_weekly/v20241219_output_country_road_dlb_15hz.txt"
    "/share-global/jackson.zhong/share/planning/12_19_weekly/v20241219_output_manner_navpth_dlb_15hz.txt"
    "/share-global/jackson.zhong/share/planning/12_19_weekly/v20241219_output_manner_navpth_dlb_30hz.txt"
    "/share-global/jackson.zhong/share/planning/12_19_weekly/v20241219_output_append_dlb.txt"
    "/share-global/jackson.zhong/share/planning/12_19_weekly/v20241219_output_tag_deviation_planner_dlb.txt"
    "/share-global/jackson.zhong/share/planning/12_19_weekly/v20241219_output_to_1211_new_append_dlb.txt"
    "/share-global/jackson.zhong/share/planning/12_19_weekly/v20241219_output_2time_append_dlb.txt"
    "/share-global/jackson.zhong/share/planning/12_19_weekly/v20241219_output_new_append_dlb_12wclips.txt"
)

save_file_name="Data_monitor_0302_cmp_0210"
save_dir="./data_compare_0302_cmp_0210"
share_save_dir="/share-global/mccree.zhao/share/planning/dataset/241230_0302_cmp_0210"
tags_save_dir="${save_dir}/tags"

tag_version_raw="huailai_cos:ad-cn-hlidc-fdm-static/Tag_Static/prod_v20250210_all_tags"
tag_version_new="huailai_cos:ad-cn-hlidc-fdm-static/Tag_Static/prod_v20240224_all_tags"
tag_version_addition="huailai_cos:ad-cn-hlidc-fdm-static/Tag_Static/prod_v20240224_all_tags"
tag_version_missing="huailai_cos:ad-cn-hlidc-fdm-static/Tag_Static/prod_v20250210_all_tags"

sample_size=5

input_dataset_name_raw="raw_common.txt"
input_dataset_name_new="new_common.txt"
input_dataset_name_raw_sampled="raw_common_sample.txt"
input_dataset_name_new_sampled="new_common_sample.txt"
input_dataset_name_addition="new_unique.txt"
input_dataset_name_missing="raw_unique.txt"
raw_dict_name="raw_common"
new_dict_name="new_common"

# 1. Clips list comparison
echo "python3 tpp_onemodel/tools/astra_planner/data/data_inspection/clip_list_comparison.py --raw_file_list \"${raw_file_list[@]}\" --new_file_list \"${new_file_list[@]}\" --sample_size \"${sample_size}\" --save_dir \"${save_dir}\" --share_save_dir \"${share_save_dir}\""
python3 tpp_onemodel/tools/astra_planner/data/data_inspection/clip_list_comparison.py \
    --raw_file_list "${raw_file_list[@]}" \
    --new_file_list "${new_file_list[@]}" \
    --sample_size "${sample_size}" \
    --save_dir "${save_dir}" \
    --share_save_dir "${share_save_dir}"

# 2. Compare frames num and timestamp
# input_dataset_name_raw_sampled="raw_common_sample.txt"
# input_dataset_name_new_sampled="new_common_sample.txt"
echo "python3 tpp_onemodel/tools/astra_planner/data/data_inspection/frames_common.py --save_dir ${save_dir} --raw_dataset_name ${input_dataset_name_raw} --new_dataset_name ${input_dataset_name_new}"
python3 tpp_onemodel/tools/astra_planner/data/data_inspection/frames_common.py --save_dir ${save_dir} --raw_dataset_name ${input_dataset_name_raw} --new_dataset_name ${input_dataset_name_new}
echo "python3 tpp_onemodel/tools/astra_planner/data/data_inspection/frames_diff.py --save_dir ${save_dir} --raw_dataset_name ${input_dataset_name_missing} --new_dataset_name ${input_dataset_name_addition}"
python3 tpp_onemodel/tools/astra_planner/data/data_inspection/frames_diff.py --save_dir ${save_dir} --raw_dataset_name ${input_dataset_name_missing} --new_dataset_name ${input_dataset_name_addition}

# 3. Tag common part
# tag_version_raw="prod_yx_20240919_tags_only_all"
# tag_version_new="prod_yx_20240919_tags_only_all"
# input_dataset_name_raw_sampled="raw_common.txt"
# input_dataset_name_new_sampled="new_common.txt"
# raw_dict_name="raw_common"
# new_dict_name="new_common"

# input_dataset_path_raw="${save_dir}/${input_dataset_name_raw_sampled}"
# input_dataset_path_new="${save_dir}/${input_dataset_name_new_sampled}"
input_dataset_path_raw="${save_dir}/${input_dataset_name_raw}"
input_dataset_path_new="${save_dir}/${input_dataset_name_new}"
echo "python3 tpp_onemodel/tools/astra_planner/data/data_inspection/tags_common_part.py --tag_version_raw ${tag_version_raw} --tag_version_new ${tag_version_new} --input_dataset_path_raw ${input_dataset_path_raw} --input_dataset_path_new ${input_dataset_path_new} --save_dir ${tags_save_dir} --raw_dict_name ${raw_dict_name} --new_dict_name ${new_dict_name}"
python3 tpp_onemodel/tools/astra_planner/data/data_inspection/tags_common_part.py --tag_version_raw ${tag_version_raw} --tag_version_new ${tag_version_new} --input_dataset_path_raw ${input_dataset_path_raw} --input_dataset_path_new ${input_dataset_path_new} --save_dir ${tags_save_dir} --raw_dict_name ${raw_dict_name} --new_dict_name ${new_dict_name}

# 4. Tag diff part
# tag_version_addition="prod_yx_20240919_tags_only_all"
# tag_version_missing="prod_yx_20240919_tags_only_all"
# input_dataset_name_addition="new_unique.txt"
# input_dataset_name_missing="raw_unique.txt"
input_dataset_path_addition="${save_dir}/${input_dataset_name_addition}"
input_dataset_path_missing="${save_dir}/${input_dataset_name_missing}"

echo "python3 tpp_onemodel/tools/astra_planner/data/data_inspection/tags_diff_part.py --tag_version_addition ${tag_version_addition} --tag_version_missing ${tag_version_missing} --input_dataset_path_addition ${input_dataset_path_addition} --input_dataset_path_missing ${input_dataset_path_missing} --save_dir ${tags_save_dir}"
python3 tpp_onemodel/tools/astra_planner/data/data_inspection/tags_diff_part.py --tag_version_addition ${tag_version_addition} --tag_version_missing ${tag_version_missing} --input_dataset_path_addition ${input_dataset_path_addition} --input_dataset_path_missing ${input_dataset_path_missing} --save_dir ${tags_save_dir}

# 5. Tags comparison
# tag_version_raw="prod_yx_20240919_tags_only_all"
# tag_version_new="prod_yx_20240919_tags_only_all"
input_dict_name_raw="tags_to_clip_id_dict_${tag_version_raw}_${raw_dict_name}.pkl"
input_dict_name_new="tags_to_clip_id_dict_${tag_version_new}_${new_dict_name}.pkl"
echo "python3 tpp_onemodel/tools/astra_planner/data/data_inspection/tags_compare.py --tag_version_raw ${tag_version_raw} --tag_version_new ${tag_version_new} --input_dict_name_raw ${input_dict_name_raw} --input_dict_name_new ${input_dict_name_new} --save_dir ${tags_save_dir}"
python3 tpp_onemodel/tools/astra_planner/data/data_inspection/tags_compare.py --tag_version_raw ${tag_version_raw} --tag_version_new ${tag_version_new} --input_dict_name_raw ${input_dict_name_raw} --input_dict_name_new ${input_dict_name_new} --save_dir ${tags_save_dir}

# 6. Read & Save data frame level feature
echo "python3 tpp_onemodel/tools/astra_planner/data/data_inspection/read_data_feature.py --result_dir ${save_dir} --target_raw_dataset_name ${input_dataset_name_raw_sampled} --target_new_dataset_name ${input_dataset_name_new_sampled}"
python3 tpp_onemodel/tools/astra_planner/data/data_inspection/read_data_feature.py --result_dir ${save_dir} --target_raw_dataset_name ${input_dataset_name_raw_sampled} --target_new_dataset_name ${input_dataset_name_new_sampled}

# 7. Draw feature distribution
echo "python3 tpp_onemodel/tools/astra_planner/data/data_inspection/draw_feature_distribution.py --result_dir ${save_dir} --feature_name_raw ${input_dataset_name_raw_sampled%.txt} --feature_name_new ${input_dataset_name_new_sampled%.txt}"
python3 tpp_onemodel/tools/astra_planner/data/data_inspection/draw_feature_distribution.py --result_dir ${save_dir} --feature_name_raw ${input_dataset_name_raw_sampled%.txt} --feature_name_new ${input_dataset_name_new_sampled%.txt}

# 8. Frame level feature comparison
echo "python3 tpp_onemodel/tools/astra_planner/data/data_inspection/compare_feature.py --result_dir ${save_dir} --feature_name_raw ${input_dataset_name_raw_sampled%.txt} --feature_name_new ${input_dataset_name_new_sampled%.txt}"
python3 tpp_onemodel/tools/astra_planner/data/data_inspection/compare_feature.py --result_dir ${save_dir} --feature_name_raw ${input_dataset_name_raw_sampled%.txt} --feature_name_new ${input_dataset_name_new_sampled%.txt}

# 9. Generate Markdown file
echo "python3 tpp_onemodel/tools/astra_planner/data/data_inspection/generate_summary_md.py --save_dir \"${save_dir}\" --share_save_dir \"${share_save_dir}\" --raw_file_list \"${raw_file_list[@]}\" --new_file_list \"${new_file_list[@]}\" --tag_version_raw \"${tag_version_raw}\" --tag_version_new \"${tag_version_new}\" --save_name \"${save_file_name}\""
python3 tpp_onemodel/tools/astra_planner/data/data_inspection/generate_summary_md.py \
    --save_dir "${save_dir}" \
    --share_save_dir "${share_save_dir}" \
    --raw_file_list "${raw_file_list[@]}" \
    --new_file_list "${new_file_list[@]}" \
    --tag_version_raw "${tag_version_raw}" \
    --tag_version_new "${tag_version_new}" \
    --save_name "${save_file_name}"
