# -*- coding: utf-8 -*-
# flake8: noqa: F403
# flake8: noqa: F405
# flake8: noqa: D400
# flake8: noqa: N802
import argparse
import csv
import os
import pickle as pkl

from tpp_onemodel.tools.astra_planner.data.data_inspection.tags_utils import *


# 目标Tags列表
target_tags = [
    "astra_planner.fft_urban.junction.straight_pass",
    "astra_planner.fft_urban.junction.turn_right",
    "astra_planner.fft_urban.junction.turn_left",
    "astra_planner.fft_urban.junction.unprotected_leftturn_opposite_vehicle",
    "astra_planner.fft_urban.junction.turnright_vehicle_merge",
    "astra_planner.fft_urban.junction.turnleft_vehicle_merge",
    "astra_planner.fft_urban.junction.turnright_VRU_cross",
    "astra_planner.fft_urban.junction.turnleft_VRU_cross",
    "astra_planner.fft_urban.single_lane_driving.following_steady",
    "astra_planner.fft_urban.single_lane_driving.following_stop",
    "astra_planner.fft_urban.single_lane_driving.following_start",
    "astra_planner.fft_urban.single_lane_driving.following_accelerate_timely",
    "astra_planner.fft_urban.single_lane_driving.cutin_vehicle",
    "astra_planner.fft_urban.single_lane_driving.cutin_VRU",
    "astra_planner.fft_urban.single_lane_driving.cutout_vehicle",
    "astra_planner.fft_urban.sidepass.nudge_same_direction",
    "astra_planner.fft_urban.sidepass.nudge_opposite_direction",
    "astra_planner.fft_urban.sidepass.navigate",
    "astra_planner.fft_urban.sidepass.overtake",
    "astra_planner.fft_urban.sidepass.destination",
    "astra_planner.fft_urban.single_lane_driving.avoiding_nudge",
    "astra_planner.fft_urban.sidepass.stationary_OD_avoidance",
    "astra_planner.fft_urban.sidepass.main_to_side",
    "astra_planner.fft_urban.sidepass.side_to_main",
    "astra_planner.fft_urban.junction.tld_stop",
    "astra_planner.fft_urban.junction.tld_start",
    "astra_planner.fft_urban.junction.T_no_tld_merge_to_main",
    "astra_planner.fft_urban.junction.head_pass",
    "astra_planner.fft_urban.single_lane_driving.SOD_react",
    "astra_planner.fft_urban.single_lane_driving.GOD_react",
    "astra_planner.fft_urban.sidepass.SOD_obstacle_avoidance",
    "astra_planner.fft_urban.sidepass.lanechange",
    "astra_planner.fft_urban.sidepass.lanechange_left",
    "astra_planner.fft_urban.sidepass.lanechange_right",
    "astra_planner.fft_urban.sidepass.ego_target_sametime",
    "astra_planner.fft_urban.single_lane_driving.lane_centering",
    "astra_planner.fft_urban.sidepass.slow_target_al_front",
    "astra_planner.fft_urban.single_lane_driving.side_parked_vehicle",
]


# 预处理clip_id数据
def preprocess_tags_to_clip(tags_to_clip):
    """预处理数据，将clip路径转换为clip_id"""
    processed_data = {}
    for tag, clips in tags_to_clip.items():
        processed_data[tag] = {clip_path.split("/")[3] for clip_path in clips}
    return processed_data


# 创建各类CSV文件
def save_clip_diff_to_csv_newLack(tag_name, file_name, tags_raw_processed, tags_new_processed):
    """保存clip差异到CSV文件"""
    clip_diff = []
    if tag_name not in tags_raw_processed or tag_name not in tags_new_processed:
        return

    clips_raw = tags_raw_processed[tag_name]
    clips_new = tags_new_processed[tag_name]

    # 只展示raw有但new没有的clip_id，且确保new可以读取到clip信息
    clip_diff = [[clip_id] for clip_id in clips_raw if clip_id not in clips_new]

    # 写入CSV文件
    if len(clip_diff) > 0:
        with open(file_name, mode="w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["clip_id"])
            writer.writerows(clip_diff)


def save_clip_diff_to_csv_newAddition(tag_name, file_name, tags_raw_processed, tags_new_processed):
    """保存clip差异到CSV文件"""
    clip_diff = []
    if tag_name not in tags_raw_processed or tag_name not in tags_new_processed:
        return

    clips_raw = tags_raw_processed[tag_name]
    clips_new = tags_new_processed[tag_name]

    # 只展示new有但raw没有的clip_id
    clip_diff = [[clip_id] for clip_id in clips_new if clip_id not in clips_raw]

    # 写入CSV文件
    if len(clip_diff) > 0:
        with open(file_name, mode="w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["clip_id"])
            writer.writerows(clip_diff)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process some parameters.")
    parser.add_argument(
        "--tag_version_raw", default="prod_yx_20240919_tags_only_all", type=str, help="The version name of tag"
    )
    parser.add_argument(
        "--tag_version_new", default="prod_v202411061500_all_tags", type=str, help="The version name of tag"
    )
    parser.add_argument(
        "--save_dir",
        default="./data_compare",
        type=str,
        help="The saving path",
    )
    parser.add_argument(
        "--input_dict_name_raw",
        default="tags_to_clip_id_dict_prod_yx_20240919_tags_only_all_raw_common.pkl",
        type=str,
        help="The raw tag msg",
    )
    parser.add_argument(
        "--input_dict_name_new",
        default="tags_to_clip_id_dict_prod_v202411061500_all_tags_new_common.pkl",
        type=str,
        help="The new tag msg",
    )
    args = parser.parse_args()

    file_path = args.save_dir
    os.makedirs(file_path, exist_ok=True)

    # 加载文件
    tags_raw_to_clip_path = os.path.join(file_path, args.input_dict_name_raw)
    tags_new_to_clip_path = os.path.join(file_path, args.input_dict_name_new)

    tags_raw_to_clip = pkl.load(open(tags_raw_to_clip_path, "rb"))
    tags_new_to_clip = pkl.load(open(tags_new_to_clip_path, "rb"))

    # 初始化统计数据
    tag_diff_stats = []
    # 预处理raw和new的数据
    tags_raw_processed = preprocess_tags_to_clip(tags_raw_to_clip)
    tags_new_processed = preprocess_tags_to_clip(tags_new_to_clip)

    # 统计三个目标Tag的差异
    for tag in target_tags:
        # 如果raw或new缺失Tag，则记录缺失情况
        if tag not in tags_raw_processed or tag not in tags_new_processed:
            tag_diff_stats.append([tag, "N/A", "N/A", "缺失"])
            continue

        clips_raw = tags_raw_processed[tag]
        clips_new = tags_new_processed[tag]

        # 统计差异数量
        only_raw = len(clips_raw - clips_new)
        only_new = len(clips_new - clips_raw)

        tag_diff_stats.append([tag, str(only_raw), str(only_new), "无缺失"])

        # 保存每个Tag的clip差异到CSV
        # os.makedirs("tag_diff", exist_ok=True)
        tag_diff_path = os.path.join(file_path, "tag_diff")
        os.makedirs(tag_diff_path, exist_ok=True)
        save_clip_diff_to_csv_newLack(tag, f"{tag_diff_path}/{tag}_lack.csv", tags_raw_processed, tags_new_processed)
        save_clip_diff_to_csv_newAddition(
            tag, f"{tag_diff_path}/{tag}_addition.csv", tags_raw_processed, tags_new_processed
        )

    # 保存统计指标到CSV文件
    with open(os.path.join(tag_diff_path, "tag_diff_stats.csv"), mode="w", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["Tag", "raw有但new没有的数量", "new有但raw没有的数量", "缺失情况"])
        writer.writerows(tag_diff_stats)

    print("CSV 文件已生成完成！")
