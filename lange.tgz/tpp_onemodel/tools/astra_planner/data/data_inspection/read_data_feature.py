# -*- coding: utf-8 -*-
# flake8: noqa: F401
# flake8: noqa: D202
# flake8: noqa: T201
# type: ignore
import argparse
import os
from collections import defaultdict
from typing import Any
from typing import DefaultDict
from typing import Dict

import matplotlib.pyplot as plt
import numpy as np
import torch
import torchpilot
from torchpilot.utils.cfg_parser import PyConfig
from torchpilot.utils.plus_manager import load_plus
from torchpilot.utils.registries import DATALOADER

# from torchpilot.utils.registries import TASK_FLOW
# from torchpilot.utils.registries import TASK_MODEL
from tqdm import tqdm

from tpp_onemodel.tools.astra_planner.data.txt_to_pkl_utils import txt_to_pkl


logger = torchpilot.logger

DTYPE = np.float32
DEVICE = torch.device("cuda")
np.set_printoptions(precision=2, suppress=True)


ego_key_list = [
    "egos",
    "egos_pred_gt_transformed",
    "egos_pred_mask_transformed",
    "ego_vel_pred_gt_transformed",
    "ego_acc_pred_gt",
    "ego_yaw_rate_pred_gt",
    "car_poses",
]
od_key_list = ["bboxes", "bboxes_padding_mask"]
lane_key_list = ["lane_points", "lane_types"]
# speed_lmt_key_list = ["speed_lmt"]
navilane_key_list = ["navi_path_points", "navi_path_types"]
sod_key_list = ["sod_poly_boxes", "sod_poly_boxes_padding_mask", "sod_poly_pts", "sod_poly_pts_padding_mask"]
god_key_list = ["god_poly_pts", "god_poly_pts_padding_mask"]


def build_dataloader(planner_cfg, target_dataset_dir: str):
    """Build dataloader."""
    with open(target_dataset_dir, "r") as file:
        line_count = sum(1 for line in file)

    data_cfg = planner_cfg.infer_dataloader
    data_cfg.num_workers = 4
    data_cfg.sampler_cfg.shuffle = False
    data_cfg.prefetch_factor = 2
    data_cfg.batch_size = 16

    if line_count > 10:
        data_cfg.num_workers = 16
        data_cfg.prefetch_factor = 4
        data_cfg.dataset_cfg.datasets_cfg.astra_planner.interval = 10
        data_cfg.batch_size = 32

    # data_cfg.dataset_cfg.debug = True
    if target_dataset_dir != "":
        pkl_path_list = txt_to_pkl([target_dataset_dir], num_workers=16)
        data_cfg.dataset_cfg.datasets_cfg.astra_planner.meta_file.astra_planner.test = pkl_path_list
    data_loader = DATALOADER.build(data_cfg)
    return data_loader


def read_data(planner_cfg, target_dataset_dir: str):
    """Select the clip frame sample by given micro-seconds timetamp."""
    data_dict: DefaultDict[Any, Dict] = defaultdict(dict)

    data_loader = build_dataloader(planner_cfg, target_dataset_dir)

    for samples in tqdm(data_loader):
        for sample_idx in range(len(samples["astra_planner"]["subclip_ids"])):
            ts_dict = {}
            # keys
            # ts_dict["keys"] = samples["keys"][sample_idx][0]

            for ego_key in ego_key_list:
                ts_dict[ego_key] = samples["astra_planner"][ego_key][sample_idx].numpy()
            for od_key in od_key_list:
                ts_dict[od_key] = samples["astra_planner"][od_key][sample_idx].numpy()
            for lane_key in lane_key_list:
                ts_dict[lane_key] = samples["astra_planner"][lane_key][sample_idx].numpy()
            # for speed_lmt_key in speed_lmt_key_list:
            #     ts_dict[speed_lmt_key] = samples["astra_planner"][speed_lmt_key][sample_idx].numpy()
            for navilane_key in navilane_key_list:
                ts_dict[navilane_key] = samples["astra_planner"][navilane_key][sample_idx].numpy()
            for sod_key in sod_key_list:
                ts_dict[sod_key] = samples["astra_planner"][sod_key][sample_idx].numpy()
            for god_key in god_key_list:
                ts_dict[god_key] = samples["astra_planner"][god_key][sample_idx].numpy()
            ts_dict["timestamp"] = samples["astra_planner"]["timestamp"][sample_idx][-1]

            data_dict[samples["astra_planner"]["subclip_ids"][sample_idx]][
                samples["astra_planner"]["timestamp"][sample_idx][-1] * 1000 // 100
            ] = ts_dict

    np.save(target_dataset_dir.split(".txt")[0] + "_feature.npy", data_dict)
    print(target_dataset_dir.split(".txt")[0] + "_feature.npy", "saved.")
    return data_dict


if __name__ == "__main__":
    load_plus()
    torch.set_printoptions(linewidth=500, edgeitems=8, profile="default", sci_mode=False)
    np.set_printoptions(linewidth=500, edgeitems=8, suppress=True)

    torch.distributed.init_process_group(
        backend="nccl",
        init_method="tcp://localhost:6662",
        world_size=1,
        rank=0,
    )

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-c",
        "--cfg_planner",
        type=str,
        default="experiments/task_planner/exp_debug/cfg_debug.py",
        required=False,
        help="planner_cfg",
    )
    parser.add_argument("--result_dir", type=str, required=False, default="./data_compare/")
    parser.add_argument(
        "--target_raw_dataset_name",
        type=str,
        required=False,
        # default="raw_common_sample.txt",
        default="raw_common_sample.txt",
        help="target_raw_dataset_dir",
    )
    parser.add_argument(
        "--target_new_dataset_name",
        type=str,
        required=False,
        # default="new_common_sample.txt",
        default="",
        help="target_new_dataset_dir",
    )
    args = parser.parse_args()

    if not os.path.exists(args.result_dir):
        os.mkdir(args.result_dir)

    cfg = PyConfig.fromfile(args.cfg_planner)

    save_dir = args.result_dir

    if args.target_raw_dataset_name != "":
        read_data(cfg, os.path.join(save_dir, args.target_raw_dataset_name))
    if args.target_new_dataset_name != "":
        read_data(cfg, os.path.join(save_dir, args.target_new_dataset_name))
