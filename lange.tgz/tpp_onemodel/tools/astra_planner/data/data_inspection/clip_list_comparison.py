# -*- coding: utf-8 -*-
# flake8: noqa: D103
import argparse
import csv
import math
import os
import shutil
from collections import defaultdict

from tpp_onemodel.tools.astra_planner.data.data_inspection.find_repeat_item import (
    split_files,
)


def read_file(file_path):
    with open(file_path, "r") as file:
        return file.readlines()


def extract_key(line):
    return line.split("/")[3].replace(".000000", "")


def write_file(file_path, lines):
    with open(file_path, "w") as file:
        file.writelines(line if line.endswith("\n") else line + "\n" for line in lines)


def combine_files(file_paths):
    """Combine the content of multiple files into a single list of lines."""
    combined_lines = []
    for file_path in file_paths:
        combined_lines.extend(read_file(file_path))
    return combined_lines


def uniform_sample(lines, sample_size):
    """
    Perform uniform sampling on a list while maintaining order.
    If the number of lines is less than the sample size, return all lines.
    """
    total_lines = len(lines)
    if total_lines <= sample_size:
        return lines

    # Calculate step size
    step = total_lines / sample_size
    sampled_indices = [math.floor(i * step) for i in range(sample_size)]
    return [lines[i] for i in sampled_indices]


def main(raw_paths, new_paths, sample_size, save_dir, share_save_dir):
    # Combine all files in raw_paths and new_paths
    raw_lines = split_files(raw_paths)
    new_lines = split_files(new_paths)

    # Calculate original data lengths
    len_raw_data = len(raw_lines)
    len_new_data = len(new_lines)

    raw_keys = defaultdict(list)
    new_keys = defaultdict(list)

    # Populate dictionaries
    for line in raw_lines:
        key = extract_key(line)
        raw_keys[key].append(line)

    for line in new_lines:
        key = extract_key(line)
        new_keys[key].append(line)

    # Determine common and unique lines
    raw_common_lines = []
    new_common_lines = []
    raw_unique_lines = []
    new_unique_lines = []

    for key in raw_keys:
        if key in new_keys:
            raw_common_lines.extend(raw_keys[key])
            new_common_lines.extend(new_keys[key])
        else:
            raw_unique_lines.extend(raw_keys[key])

    for key in new_keys:
        if key not in raw_keys:
            new_unique_lines.extend(new_keys[key])

    # Convert to sets and back to lists for sorting
    raw_common_lines = sorted(set(raw_common_lines), key=extract_key)
    new_common_lines = sorted(set(new_common_lines), key=extract_key)
    raw_unique_lines = sorted(set(raw_unique_lines), key=extract_key)
    new_unique_lines = sorted(set(new_unique_lines), key=extract_key)

    # Calculate lengths
    len_common = len(raw_common_lines)
    len_raw_unique = len(raw_unique_lines)
    len_new_unique = len(new_unique_lines)

    print("len(raw_common_lines):", len_common)
    print("len(new_common_lines):", len_common)
    print("len(raw_unique_lines):", len_raw_unique)
    print("len(new_unique_lines):", len_new_unique)

    os.makedirs(save_dir, exist_ok=True)
    os.makedirs(share_save_dir, exist_ok=True)
    # Write sorted common and unique lines to files
    write_file(os.path.join(save_dir, "raw_common.txt"), raw_common_lines)
    write_file(os.path.join(save_dir, "new_common.txt"), new_common_lines)
    write_file(os.path.join(save_dir, "raw_unique.txt"), raw_unique_lines)
    write_file(os.path.join(save_dir, "new_unique.txt"), new_unique_lines)

    # Uniformly sample lines from common lines
    raw_common_sample = uniform_sample(raw_common_lines, sample_size)
    new_common_sample = uniform_sample(new_common_lines, sample_size)

    # Write sampled lines to separate files
    write_file(os.path.join(save_dir, "raw_common_sample.txt"), raw_common_sample)
    write_file(os.path.join(save_dir, "new_common_sample.txt"), new_common_sample)

    # Generate CSV report
    share_save_target = os.path.join(share_save_dir, "data_compare")
    if os.path.exists(share_save_target):
        shutil.rmtree(share_save_target)
    shutil.copytree(save_dir, share_save_target)

    csv_file_path = os.path.join(save_dir, "clip_list_diff.csv")
    with open(csv_file_path, mode="w", newline="") as csv_file:
        csv_writer = csv.writer(csv_file)
        csv_writer.writerow(["Data Part", "Length"])
        csv_writer.writerow(["Original Data Length (Raw)", len_raw_data])
        csv_writer.writerow(["Original Data Length (New)", len_new_data])
        csv_writer.writerow(["Common Part Length", len_common])
        csv_writer.writerow(["Raw Data Unique Length", len_raw_unique])
        csv_writer.writerow(["New Data Unique Length", len_new_unique])
    print(f"Data lengths have been written to {csv_file_path}")

    path_csv_file_path = os.path.join(save_dir, "clip_path.csv")
    with open(path_csv_file_path, mode="w", newline="") as csv_file:
        csv_writer = csv.writer(csv_file)
        csv_writer.writerow(["Data Name", "Data Path"])
        csv_writer.writerow(["new_common file path", os.path.join(share_save_dir, "new_common.txt")])
        csv_writer.writerow(["raw_common file path", os.path.join(share_save_dir, "raw_common.txt")])
        csv_writer.writerow(["new_unique file path", os.path.join(share_save_dir, "new_unique.txt")])
        csv_writer.writerow(["raw_unique file path", os.path.join(share_save_dir, "raw_unique.txt")])
        csv_writer.writerow(["new_common_sample file path", os.path.join(share_save_dir, "new_common_sample.txt")])
        csv_writer.writerow(["raw_common_sample file path", os.path.join(share_save_dir, "raw_common_sample.txt")])
        csv_writer.writerow(["raw_data_paths", ",".join(raw_paths)])
        csv_writer.writerow(["new_data_paths", ",".join(new_paths)])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process some parameters.")
    parser.add_argument("--save_dir", default="./data_compare", type=str, help="The saving path")
    parser.add_argument(
        "--share_save_dir",
        default="/share-global/mccree.zhao/share/planning/dataset/1114_0918_urban",
        type=str,
        help="The saving path",
    )
    parser.add_argument(
        "--raw_file_list",
        default=["/share-global/mccree.zhao/share/planning/dataset/1114_0918_urban/0918_urban_unique_dup1.txt"],
        nargs="+",
        type=str,
        help="The raw dataset clip list path",
    )
    parser.add_argument(
        "--new_file_list",
        default=["/share-global/mccree.zhao/share/planning/dataset/1114_0918_urban/1106_rl_unique_dup1.txt"],
        nargs="+",
        type=str,
        help="The new dataset clip list path",
    )
    parser.add_argument(
        "--sample_size",
        default=200,
        type=int,
        help="Sampling common part size",
    )
    args = parser.parse_args()

    main(
        args.raw_file_list,
        args.new_file_list,
        args.sample_size,
        args.save_dir,
        args.share_save_dir,
    )
