# -*- coding: utf-8 -*-
# flake8: noqa: D103
# flake8: noqa: N806
# flake8: noqa: T201
# flake8: noqa: D200
# flake8: noqa: D401
import argparse
import os

import matplotlib.pyplot as plt
import numpy as np
from tqdm import tqdm


def draw_feature_distribution(feature_name, feature_dir, save_dir):
    feature_path = os.path.join(feature_dir, feature_name + "_feature.npy")
    feature_dict = np.load(feature_path, allow_pickle=True).item()

    # Call the plotting functions
    data = collect_egos_pred_gt_transformed_data(feature_dict)
    plot_egos_pred_gt_transformed(data, save_dir, feature_name)

    data = collect_bbox_data(feature_dict)
    plot_bbox(data, save_dir, feature_name)

    data = collect_front_bbox_data(feature_dict)
    plot_front_bbox(data, save_dir, feature_name)

    data = collect_navi_data(feature_dict)
    plot_navi(data, save_dir, feature_name)

    data = collect_lane_data(feature_dict)
    plot_lane(data, save_dir, feature_name)

    data = collect_sod_data(feature_dict)
    plot_sod(data, save_dir, feature_name)

    data = collect_god_data(feature_dict)
    plot_god(data, save_dir, feature_name)


def compare_feature_distribution(feature_name_raw, feature_name_new, feature_dir, save_dir):
    feature_path_raw = os.path.join(feature_dir, feature_name_raw + "_feature.npy")
    feature_path_new = os.path.join(feature_dir, feature_name_new + "_feature.npy")

    feature_dict_raw = np.load(feature_path_raw, allow_pickle=True).item()
    feature_dict_new = np.load(feature_path_new, allow_pickle=True).item()

    # Call the comparison plotting functions
    data_raw = collect_egos_pred_gt_transformed_data(feature_dict_raw)
    data_new = collect_egos_pred_gt_transformed_data(feature_dict_new)
    compare_plot_egoss_pred_gt_transformed(data_raw, data_new, save_dir, feature_name_raw, feature_name_new)

    data_raw = collect_egos_data(feature_dict_raw)
    data_new = collect_egos_data(feature_dict_new)
    compare_plot_egos(data_raw, data_new, save_dir, feature_name_raw, feature_name_new)

    data_raw = collect_bbox_data(feature_dict_raw)
    data_new = collect_bbox_data(feature_dict_new)
    compare_plot_bbox(data_raw, data_new, save_dir, feature_name_raw, feature_name_new)

    data_raw = collect_front_bbox_data(feature_dict_raw)
    data_new = collect_front_bbox_data(feature_dict_new)
    compare_plot_front_bbox(data_raw, data_new, save_dir, feature_name_raw, feature_name_new)
    data_common_raw, data_common_new = collect_common_front_bbox_data(data_raw, data_new)
    compare_plot_front_bbox(
        data_common_raw, data_common_new, save_dir, feature_name_raw, feature_name_new, prefix="common_"
    )

    data_raw = collect_navi_data(feature_dict_raw)
    data_new = collect_navi_data(feature_dict_new)
    compare_plot_navi(data_raw, data_new, save_dir, feature_name_raw, feature_name_new)

    data_raw = collect_lane_data(feature_dict_raw)
    data_new = collect_lane_data(feature_dict_new)
    compare_plot_lane(data_raw, data_new, save_dir, feature_name_raw, feature_name_new)

    data_raw = collect_sod_data(feature_dict_raw)
    data_new = collect_sod_data(feature_dict_new)
    compare_plot_sod(data_raw, data_new, save_dir, feature_name_raw, feature_name_new)

    data_raw = collect_god_data(feature_dict_raw)
    data_new = collect_god_data(feature_dict_new)
    compare_plot_god(data_raw, data_new, save_dir, feature_name_raw, feature_name_new)


def collect_egos_pred_gt_transformed_data(feature_dict):
    # Initialize lists to collect data
    endpoints = []
    lengths = []
    speeds = []
    ego_accelerations = []
    yaw_rates = []

    # Iterate over the data to extract and compute required metrics
    for sub_clipid in tqdm(feature_dict):
        ts_dict = feature_dict[sub_clipid]
        for timestamp in ts_dict:
            feat_dict = ts_dict[timestamp]
            # Extract features
            trajectory = feat_dict.get("egos_pred_gt_transformed", None)  # shape [1,35,2]
            mask = feat_dict.get("egos_pred_mask_transformed", None)  # shape [1,35]
            velocity = feat_dict.get("ego_vel_pred_gt_transformed", None)[0]  # shape [35,2]
            acceleration = feat_dict.get("ego_acc_pred_gt", None)  # shape [35,2]
            yaw_rate = feat_dict.get("ego_yaw_rate_pred_gt", None)  # shape [35]

            if (
                trajectory is not None
                and mask is not None
                and velocity is not None
                and acceleration is not None
                and yaw_rate is not None
            ):
                # Convert to numpy arrays
                trajectory = np.array(trajectory)  # shape [1,35,2]
                mask = np.array(mask).astype(bool)  # shape [1,35]
                velocity = np.array(velocity)  # shape [35,2]
                acceleration = np.array(acceleration)  # shape [35,2]
                yaw_rate = np.array(yaw_rate)  # shape [35]

                # Remove the first dimension from trajectory and mask
                trajectory = trajectory[0]  # shape [35,2]
                mask = mask[0]  # shape [35]

                # Ensure the mask is boolean
                mask = mask.astype(bool)

                # Check shapes
                N = mask.shape[0]  # Expected to be 35
                if trajectory.shape[0] != N:
                    continue
                if velocity.shape[0] != N:
                    continue
                if acceleration.shape[0] != N:
                    continue
                if yaw_rate.shape[0] != N:
                    continue

                # Apply mask
                valid_trajectory = trajectory[mask]  # shape [N_valid, 2]
                valid_velocity = velocity[mask]  # shape [N_valid, 2]
                valid_acceleration = acceleration[mask]  # shape [N_valid, 2]
                valid_yaw_rate = yaw_rate[mask]  # shape [N_valid]

                if valid_trajectory.shape[0] == 0:
                    continue  # Skip if no valid points

                # Collect last valid point for endpoint scatter plot
                last_point = valid_trajectory[-1]
                endpoints.append(last_point)

                # Compute trajectory length
                distances = np.sqrt(np.sum(np.diff(valid_trajectory, axis=0) ** 2, axis=1))
                traj_length = np.sum(distances)
                lengths.append(traj_length)

                # Compute speeds (magnitude of velocity vectors)
                speed_values = np.sqrt(np.sum(valid_velocity**2, axis=1))
                # Compute angles in degrees
                speed_angles = np.degrees(np.arctan2(valid_velocity[:, 1], valid_velocity[:, 0]))
                # Assign sign based on angle
                speed_signed = speed_values * np.where((speed_angles >= -90) & (speed_angles <= 90), 1, -1)
                speeds.extend(speed_signed.tolist())

                # Compute longitudinal accelerations
                # Compute acceleration magnitudes
                acc_values = np.sqrt(np.sum(valid_acceleration**2, axis=1))
                # Compute angles in degrees
                acc_angles = np.degrees(np.arctan2(valid_acceleration[:, 1], valid_acceleration[:, 0]))
                # Assign sign based on angle
                acc_signed = acc_values * np.where((acc_angles >= -90) & (acc_angles <= 90), 1, -1)
                ego_accelerations.extend(acc_signed.tolist())

                # Collect yaw rates
                yaw_rates.extend(valid_yaw_rate.tolist())

    # Return the collected data
    data = {
        "endpoints": np.array(endpoints),
        "lengths": np.array(lengths),
        "speeds": np.array(speeds),
        "ego_accelerations": np.array(ego_accelerations),
        "yaw_rates": np.array(yaw_rates),
    }
    return data


def plot_egos_pred_gt_transformed(data, save_dir, feature_name):
    """
    Plots the distributions of ego vehicle features.
    """
    # Unpack data
    endpoints = data["endpoints"]
    lengths = data["lengths"]
    speeds = data["speeds"]
    ego_accelerations = data["ego_accelerations"]
    yaw_rates = data["yaw_rates"]

    # Plot the distribution of trajectory endpoints as a scatter plot
    if endpoints.size == 0:
        print("No valid endpoints found.")
    else:
        plt.figure(figsize=(8, 6))
        plt.scatter(endpoints[:, 0], endpoints[:, 1], s=1)
        plt.xlabel("X coordinate of last point")
        plt.ylabel("Y coordinate of last point")
        plt.title("Scatter Plot of Trajectory Endpoints_" + feature_name)
        plt.grid(True)
        plot_path = os.path.join(save_dir, feature_name + "_endpoint_scatter.png")
        plt.savefig(plot_path)
        plt.close()

    # Plot the distribution of trajectory lengths
    if lengths.size == 0:
        print("No valid trajectory lengths found.")
    else:
        plt.figure(figsize=(8, 6))
        plt.hist(lengths, bins=50)
        plt.xlabel("Trajectory Length")
        plt.ylabel("Counts")
        plt.title("Distribution of Trajectory Lengths_" + feature_name)
        plt.grid(True)
        plot_path = os.path.join(save_dir, feature_name + "_length_distribution.png")
        plt.savefig(plot_path)
        plt.close()

    # Plot the distribution of speeds
    if speeds.size == 0:
        print("No valid speeds found.")
    else:
        plt.figure(figsize=(8, 6))
        plt.hist(speeds, bins=50)
        plt.xlabel("Speed")
        plt.ylabel("Counts")
        plt.title("Distribution of Ego Speeds_" + feature_name)
        plt.grid(True)
        plot_path = os.path.join(save_dir, feature_name + "_speed_distribution.png")
        plt.savefig(plot_path)
        plt.close()

    # Plot the distribution of longitudinal accelerations
    if ego_accelerations.size == 0:
        print("No valid Future accelerations found.")
    else:
        plt.figure(figsize=(8, 6))
        plt.hist(ego_accelerations, bins=50)
        plt.xlabel("Ego Future Acceleration")
        plt.ylabel("Counts")
        plt.title("Distribution of Ego Future Accelerations_" + feature_name)
        plt.grid(True)
        plot_path = os.path.join(save_dir, feature_name + "_future_acceleration_distribution.png")
        plt.savefig(plot_path)
        plt.close()

    # Plot the distribution of yaw rates
    if yaw_rates.size == 0:
        print("No valid yaw rates found.")
    else:
        plt.figure(figsize=(8, 6))
        plt.hist(yaw_rates, bins=50)
        plt.xlabel("Yaw Rate")
        plt.ylabel("Counts")
        plt.title("Distribution of Ego Yaw Rates_" + feature_name)
        plt.grid(True)
        plot_path = os.path.join(save_dir, feature_name + "_yaw_rate_distribution.png")
        plt.savefig(plot_path)
        plt.close()


def compare_plot_egoss_pred_gt_transformed(data_raw, data_new, save_dir, feature_name_raw, feature_name_new):
    """
    Generates comparison plots for ego vehicle features.
    """
    # Unpack data
    endpoints_raw = data_raw["endpoints"]
    lengths_raw = data_raw["lengths"]
    speeds_raw = data_raw["speeds"]
    ego_accelerations_raw = data_raw["ego_accelerations"]
    yaw_rates_raw = data_raw["yaw_rates"]

    endpoints_new = data_new["endpoints"]
    lengths_new = data_new["lengths"]
    speeds_new = data_new["speeds"]
    ego_accelerations_new = data_new["ego_accelerations"]
    yaw_rates_new = data_new["yaw_rates"]

    # Plot endpoints comparison
    if endpoints_raw.size == 0 or endpoints_new.size == 0:
        print("No valid endpoints found in one of the datasets.")
    else:
        plt.figure(figsize=(18, 6))

        # Raw endpoints
        plt.subplot(1, 3, 1)
        plt.scatter(endpoints_raw[:, 0], endpoints_raw[:, 1], s=1)
        plt.xlabel("X coordinate")
        plt.ylabel("Y coordinate")
        plt.title("Endpoints - " + feature_name_raw)
        plt.grid(True)

        # New endpoints
        plt.subplot(1, 3, 2)
        plt.scatter(endpoints_new[:, 0], endpoints_new[:, 1], s=1)
        plt.xlabel("X coordinate")
        plt.ylabel("Y coordinate")
        plt.title("Endpoints - " + feature_name_new)
        plt.grid(True)

        # Overlayed endpoints
        plt.subplot(1, 3, 3)
        plt.scatter(endpoints_raw[:, 0], endpoints_raw[:, 1], s=1, alpha=0.5, label=feature_name_raw)
        plt.scatter(endpoints_new[:, 0], endpoints_new[:, 1], s=1, alpha=0.5, label=feature_name_new)
        plt.xlabel("X coordinate")
        plt.ylabel("Y coordinate")
        plt.title("Overlayed Endpoints")
        plt.legend()
        plt.grid(True)

        plot_path = os.path.join(save_dir, "compare_egos_endpoint_scatter.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()

    # Plot trajectory lengths comparison
    if lengths_raw.size == 0 or lengths_new.size == 0:
        print("No valid trajectory lengths found in one of the datasets.")
    else:
        plt.figure(figsize=(18, 6))

        # Raw lengths
        plt.subplot(1, 3, 1)
        plt.hist(lengths_raw, bins=50)
        plt.xlabel("Trajectory Length")
        plt.ylabel("Counts")
        plt.title("Lengths - " + feature_name_raw)
        plt.grid(True)

        # New lengths
        plt.subplot(1, 3, 2)
        plt.hist(lengths_new, bins=50)
        plt.xlabel("Trajectory Length")
        plt.ylabel("Counts")
        plt.title("Lengths - " + feature_name_new)
        plt.grid(True)

        # Overlayed lengths
        plt.subplot(1, 3, 3)
        bins = np.histogram_bin_edges(np.concatenate([lengths_raw, lengths_new]), bins=50)
        plt.hist(lengths_raw, bins=bins, alpha=0.5, label=feature_name_raw)
        plt.hist(lengths_new, bins=bins, alpha=0.5, label=feature_name_new)
        plt.xlabel("Trajectory Length")
        plt.ylabel("Counts")
        plt.title("Overlayed Lengths")
        plt.legend()
        plt.grid(True)

        plot_path = os.path.join(save_dir, "compare_egos_length_distribution.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()

    # Plot speeds comparison
    if speeds_raw.size == 0 or speeds_new.size == 0:
        print("No valid speeds found in one of the datasets.")
    else:
        plt.figure(figsize=(18, 6))

        # Raw speeds
        plt.subplot(1, 3, 1)
        plt.hist(speeds_raw, bins=50)
        plt.xlabel("Speed")
        plt.ylabel("Counts")
        plt.title("Speeds - " + feature_name_raw)
        plt.grid(True)

        # New speeds
        plt.subplot(1, 3, 2)
        plt.hist(speeds_new, bins=50)
        plt.xlabel("Speed")
        plt.ylabel("Counts")
        plt.title("Speeds - " + feature_name_new)
        plt.grid(True)

        # Overlayed speeds
        plt.subplot(1, 3, 3)
        bins = np.histogram_bin_edges(np.concatenate([speeds_raw, speeds_new]), bins=50)
        plt.hist(speeds_raw, bins=bins, alpha=0.5, label=feature_name_raw)
        plt.hist(speeds_new, bins=bins, alpha=0.5, label=feature_name_new)
        plt.xlabel("Speed")
        plt.ylabel("Counts")
        plt.title("Overlayed Speeds")
        plt.legend()
        plt.grid(True)

        plot_path = os.path.join(save_dir, "compare_egos_speed_distribution.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()

    # Plot longitudinal accelerations comparison
    if ego_accelerations_raw.size == 0 or ego_accelerations_new.size == 0:
        print("No valid longitudinal accelerations found in one of the datasets.")
    else:
        plt.figure(figsize=(18, 6))

        # Raw accelerations
        plt.subplot(1, 3, 1)
        plt.hist(ego_accelerations_raw, bins=50)
        plt.xlabel("Longitudinal Acceleration")
        plt.ylabel("Counts")
        plt.title("Longitudinal Accelerations - " + feature_name_raw)
        plt.grid(True)

        # New accelerations
        plt.subplot(1, 3, 2)
        plt.hist(ego_accelerations_new, bins=50)
        plt.xlabel("Longitudinal Acceleration")
        plt.ylabel("Counts")
        plt.title("Longitudinal Accelerations - " + feature_name_new)
        plt.grid(True)

        # Overlayed accelerations
        plt.subplot(1, 3, 3)
        bins = np.histogram_bin_edges(np.concatenate([ego_accelerations_raw, ego_accelerations_new]), bins=50)
        plt.hist(ego_accelerations_raw, bins=bins, alpha=0.5, label=feature_name_raw)
        plt.hist(ego_accelerations_new, bins=bins, alpha=0.5, label=feature_name_new)
        plt.xlabel("Ego Future Acceleration")
        plt.ylabel("Counts")
        plt.title("Overlayed Future Accelerations")
        plt.legend()
        plt.grid(True)

        plot_path = os.path.join(save_dir, "compare_egos_future_acceleration_distribution.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()

    # Plot yaw rates comparison
    if yaw_rates_raw.size == 0 or yaw_rates_new.size == 0:
        print("No valid yaw rates found in one of the datasets.")
    else:
        plt.figure(figsize=(18, 6))

        # Raw yaw rates
        plt.subplot(1, 3, 1)
        plt.hist(yaw_rates_raw, bins=50)
        plt.xlabel("Yaw Rate")
        plt.ylabel("Counts")
        plt.title("Yaw Rates - " + feature_name_raw)
        plt.grid(True)

        # New yaw rates
        plt.subplot(1, 3, 2)
        plt.hist(yaw_rates_new, bins=50)
        plt.xlabel("Yaw Rate")
        plt.ylabel("Counts")
        plt.title("Yaw Rates - " + feature_name_new)
        plt.grid(True)

        # Overlayed yaw rates
        plt.subplot(1, 3, 3)
        bins = np.histogram_bin_edges(np.concatenate([yaw_rates_raw, yaw_rates_new]), bins=50)
        plt.hist(yaw_rates_raw, bins=bins, alpha=0.5, label=feature_name_raw)
        plt.hist(yaw_rates_new, bins=bins, alpha=0.5, label=feature_name_new)
        plt.xlabel("Yaw Rate")
        plt.ylabel("Counts")
        plt.title("Overlayed Yaw Rates")
        plt.legend()
        plt.grid(True)

        plot_path = os.path.join(save_dir, "compare_egos_yaw_rate_distribution.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()


def collect_bbox_data(feature_dict):
    """
    Collects data related to bounding boxes from the feature dictionary.
    """
    # Initialize lists to collect data
    positions = []
    velocities = []
    accelerations = []

    # Iterate over the data to extract and compute required metrics
    for sub_clipid in tqdm(feature_dict):
        ts_dict = feature_dict[sub_clipid]
        for timestamp in ts_dict:
            feat_dict = ts_dict[timestamp]
            bboxes = feat_dict.get("bboxes", None)  # shape [35,191,40]
            bboxes_padding_mask = feat_dict.get("bboxes_padding_mask", None)  # shape [35,191]

            if bboxes is not None and bboxes_padding_mask is not None:
                bboxes = np.array(bboxes)  # shape [35,191,40]
                bboxes_padding_mask = np.array(bboxes_padding_mask)  # shape [35,191]

                # Use data from the last time step
                bboxes_last = bboxes[-1]  # shape [191,40]
                padding_mask_last = np.logical_not(bboxes_padding_mask[-1])  # shape [191]

                # Apply mask to filter out invalid bboxes
                valid_mask = padding_mask_last.astype(bool)  # shape [191]

                positions_data = bboxes_last[:, [0, 1]]  # shape [191,2]
                velocities_data = bboxes_last[:, [10, 11]]  # shape [191,2]
                accelerations_data = bboxes_last[:, [13, 14]]  # shape [191,2]
                headings = bboxes_last[:, 6]  # shape [191]

                if np.any(valid_mask):
                    valid_positions = positions_data[valid_mask]  # shape [N_valid,2]
                    valid_velocities = velocities_data[valid_mask]  # shape [N_valid,2]
                    valid_accelerations = accelerations_data[valid_mask]  # shape [N_valid,2]
                    valid_headings = headings[valid_mask]  # shape [N_valid]

                    # Normalize headings to unit vectors
                    heading_vectors = np.stack(
                        (np.cos(valid_headings), np.sin(valid_headings)), axis=1
                    )  # shape [N_valid,2]

                    # Determine signed velocities
                    velocity_angle_cos = np.einsum("ij,ij->i", valid_velocities, heading_vectors) / (
                        np.linalg.norm(valid_velocities, axis=1) + 1e-8
                    )
                    signed_velocities = np.linalg.norm(valid_velocities, axis=1) * np.where(
                        velocity_angle_cos > 0, 1, -1
                    )  # shape [N_valid]

                    # Determine signed accelerations
                    acceleration_angle_cos = np.einsum("ij,ij->i", valid_accelerations, heading_vectors) / (
                        np.linalg.norm(valid_accelerations, axis=1) + 1e-8
                    )
                    signed_accelerations = np.linalg.norm(valid_accelerations, axis=1) * np.where(
                        acceleration_angle_cos > 0, 1, -1
                    )  # shape [N_valid]

                    velocities.append(signed_velocities)
                    accelerations.append(signed_accelerations)
                    positions.append(valid_positions)

    # Concatenate all collected data
    if positions:
        positions = np.vstack(positions)  # shape [Total_N_valid, 2]
    else:
        positions = np.array([])
    if velocities:
        velocities = np.concatenate(velocities)  # shape [Total_N_valid]
    else:
        velocities = np.array([])
    if accelerations:
        accelerations = np.concatenate(accelerations)  # shape [Total_N_valid]
    else:
        accelerations = np.array([])

    # Return collected data
    data = {"positions": positions, "velocities": velocities, "accelerations": accelerations}
    return data


def plot_bbox(data, save_dir, feature_name):
    """Plots the distribution of bbox distances, velocities, and accelerations (with signed values)
    using bbox heading (6th dimension) to determine the sign.
    """
    # Unpack data
    positions = data["positions"]
    velocities = data["velocities"]
    accelerations = data["accelerations"]

    # Plot signed velocity histogram
    if velocities.size == 0:
        print("No valid velocities found.")
    else:
        plt.figure(figsize=(8, 6))
        plt.hist(velocities, bins=50)
        plt.xlabel("Velocity (Signed)")
        plt.ylabel("Counts")
        plt.title("Distribution of Signed Velocities_" + feature_name)
        plt.grid(True)
        plot_path = os.path.join(save_dir, feature_name + "_bbox_signed_velocity_distribution.png")
        plt.savefig(plot_path)
        plt.close()

    # Plot signed acceleration histogram
    if accelerations.size == 0:
        print("No valid accelerations found.")
    else:
        plt.figure(figsize=(8, 6))
        plt.hist(accelerations, bins=50)
        plt.xlabel("Acceleration (Signed)")
        plt.ylabel("Counts")
        plt.title("Distribution of Signed Accelerations_" + feature_name)
        plt.grid(True)
        plot_path = os.path.join(save_dir, feature_name + "_bbox_signed_acceleration_distribution.png")
        plt.savefig(plot_path)
        plt.close()

    # Compute distances from origin and plot histogram
    if positions.size == 0:
        print("No valid positions found.")
    else:
        distances = np.sqrt(np.sum(positions**2, axis=1))  # shape [Total_N_valid]
        plt.figure(figsize=(8, 6))
        plt.hist(distances, bins=50)
        plt.xlabel("Distance from Origin")
        plt.ylabel("Counts")
        plt.title("Distribution of BBox Distances at Current Step_" + feature_name)
        plt.grid(True)
        plot_path = os.path.join(save_dir, feature_name + "_bbox_distance_distribution.png")
        plt.savefig(plot_path)
        plt.close()


def compare_plot_bbox(data_raw, data_new, save_dir, feature_name_raw, feature_name_new):
    """
    Generates comparison plots for bounding box features.
    """
    # Unpack data
    positions_raw = data_raw["positions"]
    velocities_raw = data_raw["velocities"]
    accelerations_raw = data_raw["accelerations"]

    positions_new = data_new["positions"]
    velocities_new = data_new["velocities"]
    accelerations_new = data_new["accelerations"]

    # Plot signed velocity histogram comparison
    if velocities_raw.size == 0 or velocities_new.size == 0:
        print("No valid velocities found in one of the datasets.")
    else:
        plt.figure(figsize=(18, 6))

        # Raw velocities
        plt.subplot(1, 3, 1)
        plt.hist(velocities_raw, bins=50)
        plt.xlabel("Signed Velocity")
        plt.ylabel("Counts")
        plt.title("Signed Velocities - " + feature_name_raw)
        plt.grid(True)

        # New velocities
        plt.subplot(1, 3, 2)
        plt.hist(velocities_new, bins=50)
        plt.xlabel("Signed Velocity")
        plt.ylabel("Counts")
        plt.title("Signed Velocities - " + feature_name_new)
        plt.grid(True)

        # Overlayed velocities
        plt.subplot(1, 3, 3)
        bins = np.histogram_bin_edges(np.concatenate([velocities_raw, velocities_new]), bins=50)
        plt.hist(velocities_raw, bins=bins, alpha=0.5, label=feature_name_raw)
        plt.hist(velocities_new, bins=bins, alpha=0.5, label=feature_name_new)
        plt.xlabel("Signed Velocity")
        plt.ylabel("Counts")
        plt.title("Overlayed Signed Velocities")
        plt.legend()
        plt.grid(True)

        plot_path = os.path.join(save_dir, "compare_bbox_signed_velocity_distribution.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()

    # Plot signed acceleration histogram comparison
    if accelerations_raw.size == 0 or accelerations_new.size == 0:
        print("No valid accelerations found in one of the datasets.")
    else:
        plt.figure(figsize=(18, 6))

        # Raw accelerations
        plt.subplot(1, 3, 1)
        plt.hist(accelerations_raw, bins=50)
        plt.xlabel("Signed Acceleration")
        plt.ylabel("Counts")
        plt.title("Signed Accelerations - " + feature_name_raw)
        plt.grid(True)

        # New accelerations
        plt.subplot(1, 3, 2)
        plt.hist(accelerations_new, bins=50)
        plt.xlabel("Signed Acceleration")
        plt.ylabel("Counts")
        plt.title("Signed Accelerations - " + feature_name_new)
        plt.grid(True)

        # Overlayed accelerations
        plt.subplot(1, 3, 3)
        bins = np.histogram_bin_edges(np.concatenate([accelerations_raw, accelerations_new]), bins=50)
        plt.hist(accelerations_raw, bins=bins, alpha=0.5, label=feature_name_raw)
        plt.hist(accelerations_new, bins=bins, alpha=0.5, label=feature_name_new)
        plt.xlabel("Signed Acceleration")
        plt.ylabel("Counts")
        plt.title("Overlayed Signed Accelerations")
        plt.legend()
        plt.grid(True)

        plot_path = os.path.join(save_dir, "compare_bbox_signed_acceleration_distribution.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()

    # Plot distance from origin comparison
    if positions_raw.size == 0 or positions_new.size == 0:
        print("No valid positions found in one of the datasets.")
    else:
        distances_raw = np.sqrt(np.sum(positions_raw**2, axis=1))
        distances_new = np.sqrt(np.sum(positions_new**2, axis=1))

        plt.figure(figsize=(18, 6))

        # Raw distances
        plt.subplot(1, 3, 1)
        plt.hist(distances_raw, bins=50)
        plt.xlabel("Distance from Origin")
        plt.ylabel("Counts")
        plt.title("Distances - " + feature_name_raw)
        plt.grid(True)

        # New distances
        plt.subplot(1, 3, 2)
        plt.hist(distances_new, bins=50)
        plt.xlabel("Distance from Origin")
        plt.ylabel("Counts")
        plt.title("Distances - " + feature_name_new)
        plt.grid(True)

        # Overlayed distances
        plt.subplot(1, 3, 3)
        bins = np.histogram_bin_edges(np.concatenate([distances_raw, distances_new]), bins=50)
        plt.hist(distances_raw, bins=bins, alpha=0.5, label=feature_name_raw)
        plt.hist(distances_new, bins=bins, alpha=0.5, label=feature_name_new)
        plt.xlabel("Distance from Origin")
        plt.ylabel("Counts")
        plt.title("Overlayed Distances")
        plt.legend()
        plt.grid(True)

        plot_path = os.path.join(save_dir, "compare_bbox_distance_distribution.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()


def collect_navi_data(feature_dict):
    """
    Collects the lengths of all valid navi_paths and the number of valid navi_paths per frame.
    """
    # Initialize lists to collect lengths and number of valid navi_paths per frame
    navi_path_lengths = []
    num_valid_navi_paths_per_frame = []

    # Iterate over data in feature_dict
    for sub_clipid in tqdm(feature_dict):
        ts_dict = feature_dict[sub_clipid]
        for timestamp in ts_dict:
            feat_dict = ts_dict[timestamp]
            # Get navi_path_points and navi_path_types
            navi_path_points = feat_dict.get("navi_path_points", None)  # shape [6,200,2]
            navi_path_types = feat_dict.get("navi_path_types", None)  # shape [6,200]
            if navi_path_points is None or navi_path_types is None:
                continue

            # Create valid mask
            valid_mask = navi_path_types != -1  # Shape [6, 200]

            # Number of valid points per navi_path
            num_valid_points = np.sum(valid_mask, axis=1)  # Shape [6]

            # Mask for navi_paths with at least 2 valid points
            valid_navi_path_mask = num_valid_points >= 2  # Shape [6], bool

            # Number of valid navi_paths in this frame
            num_valid_navi_paths = np.sum(valid_navi_path_mask)
            num_valid_navi_paths_per_frame.append(num_valid_navi_paths)

            if num_valid_navi_paths == 0:
                continue  # No valid navi_paths in this frame

            # Prepare masked points with invalid points as NaN
            navi_path_points_masked = np.where(
                valid_mask[:, :, np.newaxis], navi_path_points, np.nan
            )  # Shape [6, 200, 2]

            # Compute differences along points axis
            diffs = np.diff(navi_path_points_masked, axis=1)  # Shape [6, 199, 2]

            # Compute distances (Euclidean distance between consecutive points)
            distances = np.sqrt(np.nansum(diffs**2, axis=2))  # Shape [6, 199]

            # Sum distances to get total length per navi_path
            lengths = np.nansum(distances, axis=1)  # Shape [6]

            # Get lengths for valid navi_paths
            valid_lengths = lengths[valid_navi_path_mask]

            # Append to the list
            navi_path_lengths.extend(valid_lengths.tolist())

    # Return collected data
    data = {"navi_path_lengths": navi_path_lengths, "num_valid_navi_paths_per_frame": num_valid_navi_paths_per_frame}
    return data


def plot_navi(data, save_dir, feature_name):
    """
    Plots the distribution of the lengths of all valid navi_paths and
    the distribution of the number of valid navi_paths per frame.
    """
    navi_path_lengths = data["navi_path_lengths"]
    num_valid_navi_paths_per_frame = data["num_valid_navi_paths_per_frame"]

    # Plot the distribution of navi_path lengths
    if navi_path_lengths:
        plt.figure(figsize=(8, 6))
        plt.hist(navi_path_lengths, bins=50)
        plt.xlabel("Navi Line Length")
        plt.ylabel("Counts")
        plt.title("Distribution of Navi Line Lengths_" + feature_name)
        plt.grid(True)
        plot_path = os.path.join(save_dir, feature_name + "_navi_path_length_distribution.png")
        plt.savefig(plot_path)
        plt.close()
    else:
        print("No valid navi lines found.")

    # Plot the distribution of the number of valid navi_paths per frame
    if num_valid_navi_paths_per_frame:
        plt.figure(figsize=(8, 6))
        plt.hist(num_valid_navi_paths_per_frame, bins=range(0, 8), align="left", rwidth=0.8)
        plt.xlabel("Number of Valid Navi Lines per Frame")
        plt.ylabel("Counts")
        plt.title("Distribution of Valid Navi Lines per Frame_" + feature_name)
        plt.xticks(range(0, 7))  # Since there are 6 navi_paths
        plt.grid(True)
        plot_path = os.path.join(save_dir, feature_name + "_navi_path_count_distribution.png")
        plt.savefig(plot_path)
        plt.close()
    else:
        print("No valid frames found.")


def compare_plot_navi(data_raw, data_new, save_dir, feature_name_raw, feature_name_new):
    """
    Generates comparison plots for navi line features.
    """
    navi_path_lengths_raw = data_raw["navi_path_lengths"]
    num_valid_navi_paths_per_frame_raw = data_raw["num_valid_navi_paths_per_frame"]

    navi_path_lengths_new = data_new["navi_path_lengths"]
    num_valid_navi_paths_per_frame_new = data_new["num_valid_navi_paths_per_frame"]

    # Plot navi line lengths comparison
    if not navi_path_lengths_raw or not navi_path_lengths_new:
        print("No valid navi line lengths found in one of the datasets.")
    else:
        plt.figure(figsize=(18, 6))

        # Raw lengths
        plt.subplot(1, 3, 1)
        plt.hist(navi_path_lengths_raw, bins=50)
        plt.xlabel("Navi Line Length")
        plt.ylabel("Counts")
        plt.title("Navi Line Lengths - " + feature_name_raw)
        plt.grid(True)

        # New lengths
        plt.subplot(1, 3, 2)
        plt.hist(navi_path_lengths_new, bins=50)
        plt.xlabel("Navi Line Length")
        plt.ylabel("Counts")
        plt.title("Navi Line Lengths - " + feature_name_new)
        plt.grid(True)

        # Overlayed lengths
        plt.subplot(1, 3, 3)
        bins = np.histogram_bin_edges(np.concatenate([navi_path_lengths_raw, navi_path_lengths_new]), bins=50)
        plt.hist(navi_path_lengths_raw, bins=bins, alpha=0.5, label=feature_name_raw)
        plt.hist(navi_path_lengths_new, bins=bins, alpha=0.5, label=feature_name_new)
        plt.xlabel("Navi Line Length")
        plt.ylabel("Counts")
        plt.title("Overlayed Navi Line Lengths")
        plt.legend()
        plt.grid(True)

        plot_path = os.path.join(save_dir, "compare_navi_path_length_distribution.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()

    # Plot number of valid navi lines per frame comparison
    if not num_valid_navi_paths_per_frame_raw or not num_valid_navi_paths_per_frame_new:
        print("No valid navi line counts found in one of the datasets.")
    else:
        plt.figure(figsize=(18, 6))

        # Raw counts
        plt.subplot(1, 3, 1)
        plt.hist(num_valid_navi_paths_per_frame_raw, bins=range(0, 8), align="left", rwidth=0.8)
        plt.xlabel("Number of Valid Navi Lines per Frame")
        plt.ylabel("Counts")
        plt.title("Valid Navi Lines per Frame - " + feature_name_raw)
        plt.xticks(range(0, 7))
        plt.grid(True)

        # New counts
        plt.subplot(1, 3, 2)
        plt.hist(num_valid_navi_paths_per_frame_new, bins=range(0, 8), align="left", rwidth=0.8)
        plt.xlabel("Number of Valid Navi Lines per Frame")
        plt.ylabel("Counts")
        plt.title("Valid Navi Lines per Frame - " + feature_name_new)
        plt.xticks(range(0, 7))
        plt.grid(True)

        # Overlayed counts
        plt.subplot(1, 3, 3)
        plt.hist(
            num_valid_navi_paths_per_frame_raw,
            bins=range(0, 8),
            alpha=0.5,
            label=feature_name_raw,
            align="left",
            rwidth=0.8,
        )
        plt.hist(
            num_valid_navi_paths_per_frame_new,
            bins=range(0, 8),
            alpha=0.5,
            label=feature_name_new,
            align="left",
            rwidth=0.8,
        )
        plt.xlabel("Number of Valid Navi Lines per Frame")
        plt.ylabel("Counts")
        plt.title("Overlayed Valid Navi Lines per Frame")
        plt.xticks(range(0, 7))
        plt.legend()
        plt.grid(True)

        plot_path = os.path.join(save_dir, "compare_navi_path_count_distribution.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()


# Similar collect, plot, and compare functions should be implemented for 'lane', 'sod', and 'god' features.

# For brevity, I'll provide the collect and compare functions for 'lane' as an example:


def collect_lane_data(feature_dict):
    """
    Collects the lengths of all valid lanes and the number of valid lanes per frame.
    """
    # Initialize lists to collect lengths and number of valid lanes per frame
    lane_lengths = []
    num_valid_lanes_per_frame = []

    # Iterate over data in feature_dict
    for sub_clipid in tqdm(feature_dict):
        ts_dict = feature_dict[sub_clipid]
        for timestamp in ts_dict:
            feat_dict = ts_dict[timestamp]
            lane_points = feat_dict.get("lane_points", None)  # shape [50,30,2]
            lane_types = feat_dict.get("lane_types", None)  # shape [50,30]
            if lane_points is None or lane_types is None:
                continue

            # Create valid mask
            valid_mask = lane_types != -1  # Shape [50, 30]

            # Number of valid points per lane
            num_valid_points = np.sum(valid_mask, axis=1)  # Shape [50]

            # Mask for lanes with at least 2 valid points
            valid_lane_mask = num_valid_points >= 2  # Shape [50], bool

            # Number of valid lanes in this frame
            num_valid_lanes = np.sum(valid_lane_mask)
            num_valid_lanes_per_frame.append(num_valid_lanes)

            if num_valid_lanes == 0:
                continue  # No valid lanes in this frame

            # Prepare masked points with invalid points as NaN
            lane_points_masked = np.where(valid_mask[:, :, np.newaxis], lane_points, np.nan)  # Shape [50, 30, 2]

            # Compute differences along points axis
            diffs = np.diff(lane_points_masked, axis=1)  # Shape [50, 29, 2]

            # Compute distances (Euclidean distance between consecutive points)
            distances = np.sqrt(np.nansum(diffs**2, axis=2))  # Shape [50, 29]

            # Sum distances to get total length per lane
            lengths = np.nansum(distances, axis=1)  # Shape [50]

            # Get lengths for valid lanes
            valid_lengths = lengths[valid_lane_mask]

            # Append to the list
            lane_lengths.extend(valid_lengths.tolist())

    # Return collected data
    data = {"lane_lengths": lane_lengths, "num_valid_lanes_per_frame": num_valid_lanes_per_frame}
    return data


def plot_lane(data, save_dir, feature_name):
    """
    Plots the distribution of the lengths of all valid lanes and
    the distribution of the number of valid lanes per frame.
    """
    lane_lengths = data["lane_lengths"]
    num_valid_lanes_per_frame = data["num_valid_lanes_per_frame"]

    # Plot the distribution of lane lengths
    if lane_lengths:
        plt.figure(figsize=(8, 6))
        plt.hist(lane_lengths, bins=50)
        plt.xlabel("Lane Length")
        plt.ylabel("Counts")
        plt.title("Distribution of Lane Lengths_" + feature_name)
        plt.grid(True)
        plot_path = os.path.join(save_dir, feature_name + "_lane_length_distribution.png")
        plt.savefig(plot_path)
        plt.close()
    else:
        print("No valid lanes found.")

    # Plot the distribution of the number of valid lanes per frame
    if num_valid_lanes_per_frame:
        plt.figure(figsize=(10, 6))
        plt.hist(num_valid_lanes_per_frame, bins=range(0, 52), align="left", rwidth=0.8)
        plt.xlabel("Number of Valid Lanes per Frame")
        plt.ylabel("Counts")
        plt.title("Distribution of Valid Lanes per Frame_" + feature_name)
        plt.xticks(range(0, 51, 5))
        plt.grid(True)
        plot_path = os.path.join(save_dir, feature_name + "_lane_count_distribution.png")
        plt.savefig(plot_path)
        plt.close()
    else:
        print("No valid frames found.")


def compare_plot_lane(data_raw, data_new, save_dir, feature_name_raw, feature_name_new):
    """
    Generates comparison plots for lane features.
    """
    lane_lengths_raw = data_raw["lane_lengths"]
    num_valid_lanes_per_frame_raw = data_raw["num_valid_lanes_per_frame"]

    lane_lengths_new = data_new["lane_lengths"]
    num_valid_lanes_per_frame_new = data_new["num_valid_lanes_per_frame"]

    # Plot lane lengths comparison
    if not lane_lengths_raw or not lane_lengths_new:
        print("No valid lane lengths found in one of the datasets.")
    else:
        plt.figure(figsize=(18, 6))

        # Raw lengths
        plt.subplot(1, 3, 1)
        plt.hist(lane_lengths_raw, bins=50)
        plt.xlabel("Lane Length")
        plt.ylabel("Counts")
        plt.title("Lane Lengths - " + feature_name_raw)
        plt.grid(True)

        # New lengths
        plt.subplot(1, 3, 2)
        plt.hist(lane_lengths_new, bins=50)
        plt.xlabel("Lane Length")
        plt.ylabel("Counts")
        plt.title("Lane Lengths - " + feature_name_new)
        plt.grid(True)

        # Overlayed lengths
        plt.subplot(1, 3, 3)
        bins = np.histogram_bin_edges(np.concatenate([lane_lengths_raw, lane_lengths_new]), bins=50)
        plt.hist(lane_lengths_raw, bins=bins, alpha=0.5, label=feature_name_raw)
        plt.hist(lane_lengths_new, bins=bins, alpha=0.5, label=feature_name_new)
        plt.xlabel("Lane Length")
        plt.ylabel("Counts")
        plt.title("Overlayed Lane Lengths")
        plt.legend()
        plt.grid(True)

        plot_path = os.path.join(save_dir, "compare_lane_length_distribution.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()

    # Plot number of valid lanes per frame comparison
    if not num_valid_lanes_per_frame_raw or not num_valid_lanes_per_frame_new:
        print("No valid lane counts found in one of the datasets.")
    else:
        plt.figure(figsize=(18, 6))

        # Raw counts
        plt.subplot(1, 3, 1)
        plt.hist(num_valid_lanes_per_frame_raw, bins=range(0, 52), align="left", rwidth=0.8)
        plt.xlabel("Number of Valid Lanes per Frame")
        plt.ylabel("Counts")
        plt.title("Valid Lanes per Frame - " + feature_name_raw)
        plt.xticks(range(0, 51, 5))
        plt.grid(True)

        # New counts
        plt.subplot(1, 3, 2)
        plt.hist(num_valid_lanes_per_frame_new, bins=range(0, 52), align="left", rwidth=0.8)
        plt.xlabel("Number of Valid Lanes per Frame")
        plt.ylabel("Counts")
        plt.title("Valid Lanes per Frame - " + feature_name_new)
        plt.xticks(range(0, 51, 5))
        plt.grid(True)

        # Overlayed counts
        plt.subplot(1, 3, 3)
        plt.hist(
            num_valid_lanes_per_frame_raw,
            bins=range(0, 52),
            alpha=0.5,
            label=feature_name_raw,
            align="left",
            rwidth=0.8,
        )
        plt.hist(
            num_valid_lanes_per_frame_new,
            bins=range(0, 52),
            alpha=0.5,
            label=feature_name_new,
            align="left",
            rwidth=0.8,
        )
        plt.xlabel("Number of Valid Lanes per Frame")
        plt.ylabel("Counts")
        plt.title("Overlayed Valid Lanes per Frame")
        plt.xticks(range(0, 51, 5))
        plt.legend()
        plt.grid(True)

        plot_path = os.path.join(save_dir, "compare_lane_count_distribution.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()


def collect_sod_data(feature_dict):
    """
    Collects data related to SOD (Stationary Objects and Debris).
    """
    # Initialize lists for sod_poly_boxes
    sod_box_areas = []
    sod_box_distances = []
    num_valid_sod_boxes_per_frame = []

    # Initialize lists for sod_poly_pts
    sod_poly_distances = []
    num_valid_sod_polys_per_frame = []

    for sub_clipid in tqdm(feature_dict):
        ts_dict = feature_dict[sub_clipid]
        for timestamp in ts_dict:
            feat_dict = ts_dict[timestamp]
            # Extract sod_poly_boxes and sod_poly_boxes_padding_mask
            sod_poly_boxes = feat_dict.get("sod_poly_boxes", None)  # shape [128,23]
            sod_poly_boxes_padding_mask = feat_dict.get("sod_poly_boxes_padding_mask", None)  # shape [128]
            sod_poly_pts = feat_dict.get("sod_poly_pts", None)  # shape [128,128,2]
            sod_poly_pts_padding_mask = feat_dict.get("sod_poly_pts_padding_mask", None)  # shape [128,128]

            # Process sod_poly_boxes
            if sod_poly_boxes is not None and sod_poly_boxes_padding_mask is not None:
                sod_poly_boxes = np.array(sod_poly_boxes)  # shape [128,23]
                sod_poly_boxes_padding_mask = np.array(sod_poly_boxes_padding_mask)  # shape [128]

                # Mask valid boxes
                valid_box_mask = sod_poly_boxes_padding_mask == 0  # Shape [128]
                num_valid_boxes = np.sum(valid_box_mask)
                num_valid_sod_boxes_per_frame.append(num_valid_boxes)

                if num_valid_boxes > 0:
                    # Compute areas and distances for valid boxes
                    valid_boxes = sod_poly_boxes[valid_box_mask]  # shape [N_valid,23]
                    areas = valid_boxes[:, 3] * valid_boxes[:, 4]  # Compute areas (length * width)
                    distances = np.sqrt(valid_boxes[:, 0] ** 2 + valid_boxes[:, 1] ** 2)  # Compute distances

                    sod_box_areas.extend(areas.tolist())
                    sod_box_distances.extend(distances.tolist())

            # Process sod_poly_pts
            if sod_poly_pts is not None and sod_poly_pts_padding_mask is not None:
                sod_poly_pts = np.array(sod_poly_pts)  # shape [128,128,2]
                sod_poly_pts_padding_mask = np.array(sod_poly_pts_padding_mask)  # shape [128,128]

                # Determine valid polygons
                valid_pt_mask = sod_poly_pts_padding_mask == 0  # Shape [128,128]
                valid_poly_mask = np.any(valid_pt_mask, axis=1)  # At least one valid point in each polygon
                num_valid_polys = np.sum(valid_poly_mask)
                num_valid_sod_polys_per_frame.append(num_valid_polys)

                if num_valid_polys > 0:
                    # Filter valid points
                    valid_pts = sod_poly_pts[valid_poly_mask]  # shape [N_valid,128,2]
                    valid_pts_mask = valid_pt_mask[valid_poly_mask]  # shape [N_valid,128]

                    # Compute distances for all valid points in parallel
                    distances = np.sqrt(np.sum(valid_pts**2, axis=2))  # Compute distances for all points
                    distances = distances[valid_pts_mask]  # Filter valid distances
                    sod_poly_distances.extend(distances.tolist())

    # Return collected data
    data = {
        "sod_box_areas": sod_box_areas,
        "sod_box_distances": sod_box_distances,
        "num_valid_sod_boxes_per_frame": num_valid_sod_boxes_per_frame,
        "sod_poly_distances": sod_poly_distances,
        "num_valid_sod_polys_per_frame": num_valid_sod_polys_per_frame,
    }
    return data


def plot_sod(data, save_dir, feature_name):
    """
    Plots the distributions for SOD (Stationary Objects and Debris) features.
    """
    # Unpack data
    sod_box_areas = data["sod_box_areas"]
    sod_box_distances = data["sod_box_distances"]
    num_valid_sod_boxes_per_frame = data["num_valid_sod_boxes_per_frame"]
    sod_poly_distances = data["sod_poly_distances"]
    num_valid_sod_polys_per_frame = data["num_valid_sod_polys_per_frame"]

    # Plot SOD box area distribution
    if sod_box_areas:
        plt.figure(figsize=(8, 6))
        plt.hist(sod_box_areas, bins=50)
        plt.xlabel("SOD Box Area")
        plt.ylabel("Counts")
        plt.title("Distribution of SOD Box Areas_" + feature_name)
        plt.grid(True)
        plot_path = os.path.join(save_dir, feature_name + "_sod_box_area_distribution.png")
        plt.savefig(plot_path)
        plt.close()
    else:
        print("No valid SOD boxes found.")

    # Plot SOD box distance distribution
    if sod_box_distances:
        plt.figure(figsize=(8, 6))
        plt.hist(sod_box_distances, bins=50)
        plt.xlabel("Distance to Origin")
        plt.ylabel("Counts")
        plt.title("Distribution of SOD Box Distances_" + feature_name)
        plt.grid(True)
        plot_path = os.path.join(save_dir, feature_name + "_sod_box_distance_distribution.png")
        plt.savefig(plot_path)
        plt.close()
    else:
        print("No valid SOD box distances found.")

    # Plot number of valid SOD boxes per frame
    if num_valid_sod_boxes_per_frame:
        plt.figure(figsize=(8, 6))
        max_bins = max(num_valid_sod_boxes_per_frame) + 1
        bins = range(0, max_bins + 1)
        plt.hist(num_valid_sod_boxes_per_frame, bins=bins, align="left", rwidth=0.8)
        plt.xlabel("Number of Valid SOD Boxes per Frame")
        plt.ylabel("Counts")
        plt.title("Distribution of Valid SOD Boxes per Frame_" + feature_name)
        plt.grid(True)
        plot_path = os.path.join(save_dir, feature_name + "_sod_box_count_distribution.png")
        plt.savefig(plot_path)
        plt.close()
    else:
        print("No valid SOD box counts found.")

    # Plot SOD polygon point distances distribution
    if sod_poly_distances:
        plt.figure(figsize=(8, 6))
        plt.hist(sod_poly_distances, bins=50)
        plt.xlabel("Distance to Origin")
        plt.ylabel("Counts")
        plt.title("Distribution of SOD Polygon Point Distances_" + feature_name)
        plt.grid(True)
        plot_path = os.path.join(save_dir, feature_name + "_sod_poly_distance_distribution.png")
        plt.savefig(plot_path)
        plt.close()
    else:
        print("No valid SOD polygon points found.")

    # Plot number of valid SOD polygons per frame
    if num_valid_sod_polys_per_frame:
        plt.figure(figsize=(8, 6))
        max_bins = max(num_valid_sod_polys_per_frame) + 1
        bins = range(0, max_bins + 1)
        plt.hist(num_valid_sod_polys_per_frame, bins=bins, align="left", rwidth=0.8)
        plt.xlabel("Number of Valid SOD Polygons per Frame")
        plt.ylabel("Counts")
        plt.title("Distribution of Valid SOD Polygons per Frame_" + feature_name)
        plt.grid(True)
        plot_path = os.path.join(save_dir, feature_name + "_sod_poly_count_distribution.png")
        plt.savefig(plot_path)
        plt.close()
    else:
        print("No valid SOD polygons found.")


def compare_plot_sod(data_raw, data_new, save_dir, feature_name_raw, feature_name_new):
    """
    Generates comparison plots for SOD features.
    """
    # Unpack data
    sod_box_areas_raw = data_raw["sod_box_areas"]
    sod_box_distances_raw = data_raw["sod_box_distances"]
    num_valid_sod_boxes_per_frame_raw = data_raw["num_valid_sod_boxes_per_frame"]
    sod_poly_distances_raw = data_raw["sod_poly_distances"]
    num_valid_sod_polys_per_frame_raw = data_raw["num_valid_sod_polys_per_frame"]

    sod_box_areas_new = data_new["sod_box_areas"]
    sod_box_distances_new = data_new["sod_box_distances"]
    num_valid_sod_boxes_per_frame_new = data_new["num_valid_sod_boxes_per_frame"]
    sod_poly_distances_new = data_new["sod_poly_distances"]
    num_valid_sod_polys_per_frame_new = data_new["num_valid_sod_polys_per_frame"]

    # Plot SOD box area comparison
    if not sod_box_areas_raw or not sod_box_areas_new:
        print("No valid SOD box areas found in one of the datasets.")
    else:
        plt.figure(figsize=(18, 6))
        # Raw areas
        plt.subplot(1, 3, 1)
        plt.hist(sod_box_areas_raw, bins=50)
        plt.xlabel("SOD Box Area")
        plt.ylabel("Counts")
        plt.title("SOD Box Areas - " + feature_name_raw)
        plt.grid(True)
        # New areas
        plt.subplot(1, 3, 2)
        plt.hist(sod_box_areas_new, bins=50)
        plt.xlabel("SOD Box Area")
        plt.ylabel("Counts")
        plt.title("SOD Box Areas - " + feature_name_new)
        plt.grid(True)
        # Overlayed areas
        plt.subplot(1, 3, 3)
        bins = np.histogram_bin_edges(np.concatenate([sod_box_areas_raw, sod_box_areas_new]), bins=50)
        plt.hist(sod_box_areas_raw, bins=bins, alpha=0.5, label=feature_name_raw)
        plt.hist(sod_box_areas_new, bins=bins, alpha=0.5, label=feature_name_new)
        plt.xlabel("SOD Box Area")
        plt.ylabel("Counts")
        plt.title("Overlayed SOD Box Areas")
        plt.legend()
        plt.grid(True)
        plot_path = os.path.join(save_dir, "compare_sod_box_area_distribution.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()

    # Plot SOD box distance comparison
    if not sod_box_distances_raw or not sod_box_distances_new:
        print("No valid SOD box distances found in one of the datasets.")
    else:
        plt.figure(figsize=(18, 6))
        # Raw distances
        plt.subplot(1, 3, 1)
        plt.hist(sod_box_distances_raw, bins=50)
        plt.xlabel("Distance to Origin")
        plt.ylabel("Counts")
        plt.title("SOD Box Distances - " + feature_name_raw)
        plt.grid(True)
        # New distances
        plt.subplot(1, 3, 2)
        plt.hist(sod_box_distances_new, bins=50)
        plt.xlabel("Distance to Origin")
        plt.ylabel("Counts")
        plt.title("SOD Box Distances - " + feature_name_new)
        plt.grid(True)
        # Overlayed distances
        plt.subplot(1, 3, 3)
        plt.hist(sod_box_distances_raw, bins=50, alpha=0.5, label=feature_name_raw)
        plt.hist(sod_box_distances_new, bins=50, alpha=0.5, label=feature_name_new)
        plt.xlabel("Distance to Origin")
        plt.ylabel("Counts")
        plt.title("Overlayed SOD Box Distances")
        plt.legend()
        plt.grid(True)
        plot_path = os.path.join(save_dir, "compare_sod_box_distance_distribution.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()

    # Plot number of valid SOD boxes per frame comparison
    if not num_valid_sod_boxes_per_frame_raw or not num_valid_sod_boxes_per_frame_new:
        print("No valid SOD box counts found in one of the datasets.")
    else:
        plt.figure(figsize=(18, 6))
        max_bins = max(max(num_valid_sod_boxes_per_frame_raw), max(num_valid_sod_boxes_per_frame_new)) + 1
        bins = range(0, max_bins + 1)
        # Raw counts
        plt.subplot(1, 3, 1)
        plt.hist(num_valid_sod_boxes_per_frame_raw, bins=bins, align="left", rwidth=0.8)
        plt.xlabel("Number of Valid SOD Boxes per Frame")
        plt.ylabel("Counts")
        plt.title("Valid SOD Boxes per Frame - " + feature_name_raw)
        plt.grid(True)
        # New counts
        plt.subplot(1, 3, 2)
        plt.hist(num_valid_sod_boxes_per_frame_new, bins=bins, align="left", rwidth=0.8)
        plt.xlabel("Number of Valid SOD Boxes per Frame")
        plt.ylabel("Counts")
        plt.title("Valid SOD Boxes per Frame - " + feature_name_new)
        plt.grid(True)
        # Overlayed counts
        plt.subplot(1, 3, 3)
        plt.hist(
            num_valid_sod_boxes_per_frame_raw, bins=bins, alpha=0.5, label=feature_name_raw, align="left", rwidth=0.8
        )
        plt.hist(
            num_valid_sod_boxes_per_frame_new, bins=bins, alpha=0.5, label=feature_name_new, align="left", rwidth=0.8
        )
        plt.xlabel("Number of Valid SOD Boxes per Frame")
        plt.ylabel("Counts")
        plt.title("Overlayed Valid SOD Boxes per Frame")
        plt.legend()
        plt.grid(True)
        plot_path = os.path.join(save_dir, "compare_sod_box_count_distribution.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()

    # Plot SOD polygon point distances comparison
    if not sod_poly_distances_raw or not sod_poly_distances_new:
        print("No valid SOD polygon point distances found in one of the datasets.")
    else:
        plt.figure(figsize=(18, 6))
        # Raw distances
        plt.subplot(1, 3, 1)
        plt.hist(sod_poly_distances_raw, bins=50)
        plt.xlabel("Distance to Origin")
        plt.ylabel("Counts")
        plt.title("SOD Polygon Point Distances - " + feature_name_raw)
        plt.grid(True)
        # New distances
        plt.subplot(1, 3, 2)
        plt.hist(sod_poly_distances_new, bins=50)
        plt.xlabel("Distance to Origin")
        plt.ylabel("Counts")
        plt.title("SOD Polygon Point Distances - " + feature_name_new)
        plt.grid(True)
        # Overlayed distances
        plt.subplot(1, 3, 3)
        bins = np.histogram_bin_edges(np.concatenate([sod_poly_distances_raw, sod_poly_distances_new]), bins=50)
        plt.hist(sod_poly_distances_raw, bins=bins, alpha=0.5, label=feature_name_raw)
        plt.hist(sod_poly_distances_new, bins=bins, alpha=0.5, label=feature_name_new)
        plt.xlabel("Distance to Origin")
        plt.ylabel("Counts")
        plt.title("Overlayed SOD Polygon Point Distances")
        plt.legend()
        plt.grid(True)
        plot_path = os.path.join(save_dir, "compare_sod_poly_distance_distribution.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()

    # Plot number of valid SOD polygons per frame comparison
    if not num_valid_sod_polys_per_frame_raw or not num_valid_sod_polys_per_frame_new:
        print("No valid SOD polygon counts found in one of the datasets.")
    else:
        plt.figure(figsize=(18, 6))
        max_bins = max(max(num_valid_sod_polys_per_frame_raw), max(num_valid_sod_polys_per_frame_new)) + 1
        bins = range(0, max_bins + 1)
        # Raw counts
        plt.subplot(1, 3, 1)
        plt.hist(num_valid_sod_polys_per_frame_raw, bins=bins, align="left", rwidth=0.8)
        plt.xlabel("Number of Valid SOD Polygons per Frame")
        plt.ylabel("Counts")
        plt.title("Valid SOD Polygons per Frame - " + feature_name_raw)
        plt.grid(True)
        # New counts
        plt.subplot(1, 3, 2)
        plt.hist(num_valid_sod_polys_per_frame_new, bins=bins, align="left", rwidth=0.8)
        plt.xlabel("Number of Valid SOD Polygons per Frame")
        plt.ylabel("Counts")
        plt.title("Valid SOD Polygons per Frame - " + feature_name_new)
        plt.grid(True)
        # Overlayed counts
        plt.subplot(1, 3, 3)
        plt.hist(
            num_valid_sod_polys_per_frame_raw, bins=bins, alpha=0.5, label=feature_name_raw, align="left", rwidth=0.8
        )
        plt.hist(
            num_valid_sod_polys_per_frame_new, bins=bins, alpha=0.5, label=feature_name_new, align="left", rwidth=0.8
        )
        plt.xlabel("Number of Valid SOD Polygons per Frame")
        plt.ylabel("Counts")
        plt.title("Overlayed Valid SOD Polygons per Frame")
        plt.legend()
        plt.grid(True)
        plot_path = os.path.join(save_dir, "compare_sod_poly_count_distribution.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()


def collect_god_data(feature_dict):
    """
    Collects data related to GOD (General Obstacles and Debris).
    """
    # Initialize lists for god_poly_pts
    god_poly_distances = []
    num_valid_god_polys_per_frame = []

    for sub_clipid in tqdm(feature_dict):
        ts_dict = feature_dict[sub_clipid]
        for timestamp in ts_dict:
            feat_dict = ts_dict[timestamp]
            # Extract god_poly_pts and god_poly_pts_padding_mask
            god_poly_pts = feat_dict.get("god_poly_pts", None)  # shape [32,16,2]
            god_poly_pts_padding_mask = feat_dict.get("god_poly_pts_padding_mask", None)  # shape [32,16]

            if god_poly_pts is not None and god_poly_pts_padding_mask is not None:
                god_poly_pts = np.array(god_poly_pts)  # shape [32,16,2]
                god_poly_pts_padding_mask = np.array(god_poly_pts_padding_mask)  # shape [32,16]

                # Determine valid polygons
                valid_pt_mask = god_poly_pts_padding_mask == 0  # Shape [32,16]
                valid_poly_mask = np.any(valid_pt_mask, axis=1)  # At least one valid point in a polygon
                num_valid_polys = np.sum(valid_poly_mask)
                num_valid_god_polys_per_frame.append(num_valid_polys)

                if num_valid_polys > 0:
                    # Filter valid points
                    valid_pts = god_poly_pts[valid_poly_mask]  # shape [N_valid,16,2]
                    valid_pts_mask = valid_pt_mask[valid_poly_mask]  # shape [N_valid,16]

                    # Compute distances for all valid points
                    distances = np.sqrt(np.sum(valid_pts**2, axis=2))  # Compute distances for all points
                    distances = distances[valid_pts_mask]  # Filter valid distances
                    god_poly_distances.extend(distances.tolist())

    # Return collected data
    data = {"god_poly_distances": god_poly_distances, "num_valid_god_polys_per_frame": num_valid_god_polys_per_frame}
    return data


def plot_god(data, save_dir, feature_name):
    """
    Plots the distributions for GOD (General Obstacles and Debris) features.
    """
    # Unpack data
    god_poly_distances = data["god_poly_distances"]
    num_valid_god_polys_per_frame = data["num_valid_god_polys_per_frame"]

    # Plot GOD polygon point distances distribution
    if god_poly_distances:
        plt.figure(figsize=(8, 6))
        plt.hist(god_poly_distances, bins=50)
        plt.xlabel("Distance to Origin")
        plt.ylabel("Counts")
        plt.title("Distribution of GOD Polygon Point Distances_" + feature_name)
        plt.grid(True)
        plot_path = os.path.join(save_dir, feature_name + "_god_poly_distance_distribution.png")
        plt.savefig(plot_path)
        plt.close()
    else:
        print("No valid GOD polygon points found.")

    # Plot number of valid GOD polygons per frame
    if num_valid_god_polys_per_frame:
        plt.figure(figsize=(8, 6))
        max_bins = max(num_valid_god_polys_per_frame) + 1
        bins = range(0, max_bins + 1)
        plt.hist(num_valid_god_polys_per_frame, bins=bins, align="left", rwidth=0.8)
        plt.xlabel("Number of Valid GOD Polygons per Frame")
        plt.ylabel("Counts")
        plt.title("Distribution of Valid GOD Polygons per Frame_" + feature_name)
        plt.grid(True)
        plot_path = os.path.join(save_dir, feature_name + "_god_poly_count_distribution.png")
        plt.savefig(plot_path)
        plt.close()
    else:
        print("No valid GOD polygons found.")


def compare_plot_god(data_raw, data_new, save_dir, feature_name_raw, feature_name_new):
    """
    Generates comparison plots for GOD features.
    """
    # Unpack data
    god_poly_distances_raw = data_raw["god_poly_distances"]
    num_valid_god_polys_per_frame_raw = data_raw["num_valid_god_polys_per_frame"]

    god_poly_distances_new = data_new["god_poly_distances"]
    num_valid_god_polys_per_frame_new = data_new["num_valid_god_polys_per_frame"]

    # Plot GOD polygon point distances comparison
    if not god_poly_distances_raw or not god_poly_distances_new:
        print("No valid GOD polygon point distances found in one of the datasets.")
    else:
        plt.figure(figsize=(18, 6))
        # Raw distances
        plt.subplot(1, 3, 1)
        plt.hist(god_poly_distances_raw, bins=50)
        plt.xlabel("Distance to Origin")
        plt.ylabel("Counts")
        plt.title("GOD Polygon Point Distances - " + feature_name_raw)
        plt.grid(True)
        # New distances
        plt.subplot(1, 3, 2)
        plt.hist(god_poly_distances_new, bins=50)
        plt.xlabel("Distance to Origin")
        plt.ylabel("Counts")
        plt.title("GOD Polygon Point Distances - " + feature_name_new)
        plt.grid(True)
        # Overlayed distances
        plt.subplot(1, 3, 3)
        bins = np.histogram_bin_edges(np.concatenate([god_poly_distances_raw, god_poly_distances_new]), bins=50)
        plt.hist(god_poly_distances_raw, bins=bins, alpha=0.5, label=feature_name_raw)
        plt.hist(god_poly_distances_new, bins=bins, alpha=0.5, label=feature_name_new)
        plt.xlabel("Distance to Origin")
        plt.ylabel("Counts")
        plt.title("Overlayed GOD Polygon Point Distances")
        plt.legend()
        plt.grid(True)
        plot_path = os.path.join(save_dir, "compare_god_poly_distance_distribution.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()

    # Plot number of valid GOD polygons per frame comparison
    if not num_valid_god_polys_per_frame_raw or not num_valid_god_polys_per_frame_new:
        print("No valid GOD polygon counts found in one of the datasets.")
    else:
        plt.figure(figsize=(18, 6))
        max_bins = max(max(num_valid_god_polys_per_frame_raw), max(num_valid_god_polys_per_frame_new)) + 1
        bins = range(0, max_bins + 1)
        # Raw counts
        plt.subplot(1, 3, 1)
        plt.hist(num_valid_god_polys_per_frame_raw, bins=bins, align="left", rwidth=0.8)
        plt.xlabel("Number of Valid GOD Polygons per Frame")
        plt.ylabel("Counts")
        plt.title("Valid GOD Polygons per Frame - " + feature_name_raw)
        plt.grid(True)
        # New counts
        plt.subplot(1, 3, 2)
        plt.hist(num_valid_god_polys_per_frame_new, bins=bins, align="left", rwidth=0.8)
        plt.xlabel("Number of Valid GOD Polygons per Frame")
        plt.ylabel("Counts")
        plt.title("Valid GOD Polygons per Frame - " + feature_name_new)
        plt.grid(True)
        # Overlayed counts
        plt.subplot(1, 3, 3)
        plt.hist(
            num_valid_god_polys_per_frame_raw, bins=bins, alpha=0.5, label=feature_name_raw, align="left", rwidth=0.8
        )
        plt.hist(
            num_valid_god_polys_per_frame_new, bins=bins, alpha=0.5, label=feature_name_new, align="left", rwidth=0.8
        )
        plt.xlabel("Number of Valid GOD Polygons per Frame")
        plt.ylabel("Counts")
        plt.title("Overlayed Valid GOD Polygons per Frame")
        plt.legend()
        plt.grid(True)
        plot_path = os.path.join(save_dir, "compare_god_poly_count_distribution.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()


def collect_egos_data(feature_dict):
    """
    Collects data related to the ego vehicle from the feature dictionary.
    """
    # Initialize lists to collect data
    positions = []
    velocities = []
    accelerations = []

    # Iterate over the data to extract and compute required metrics
    for sub_clipid in tqdm(feature_dict):
        ts_dict = feature_dict[sub_clipid]
        for timestamp in ts_dict:
            feat_dict = ts_dict[timestamp]
            egos = feat_dict.get("egos", None)  # shape [15,1,15]

            if egos is not None:
                egos = np.array(egos)  # shape [15,1,15]

                # Use data from the last time step
                egos_last = egos[-1]  # shape [1,15]
                # Since there's only one agent (ego), we can remove the agent dimension
                egos_last = egos_last[0]  # shape [15]

                # Extract position, velocity, acceleration, and heading
                position = egos_last[[0, 1]]  # shape [2]
                velocity = egos_last[[10, 11]]  # shape [2]
                acceleration = egos_last[[12, 13]]  # shape [2]
                heading = egos_last[6]  # scalar

                # Normalize heading to unit vector
                heading_vector = np.array([np.cos(heading), np.sin(heading)])  # shape [2]

                # Determine signed velocity
                velocity_angle_cos = np.dot(velocity, heading_vector) / (np.linalg.norm(velocity) + 1e-8)
                signed_velocity = np.linalg.norm(velocity) if velocity_angle_cos > 0 else -np.linalg.norm(velocity)

                # Determine signed acceleration
                acceleration_angle_cos = np.dot(acceleration, heading_vector) / (np.linalg.norm(acceleration) + 1e-8)
                signed_acceleration = (
                    np.linalg.norm(acceleration) if acceleration_angle_cos > 0 else -np.linalg.norm(acceleration)
                )

                # Append to lists
                positions.append(position)
                velocities.append(signed_velocity)
                accelerations.append(signed_acceleration)

    # Convert lists to numpy arrays
    if positions:
        positions = np.vstack(positions)  # shape [N, 2]
    else:
        positions = np.array([])
    velocities = np.array(velocities)  # shape [N]
    accelerations = np.array(accelerations)  # shape [N]

    # Return collected data
    data = {"positions": positions, "velocities": velocities, "accelerations": accelerations}
    return data


def plot_ego(data, save_dir, feature_name):
    """
    Plots the distribution of ego distances, velocities, and accelerations (with signed values)
    using ego heading to determine the sign.
    """
    # Unpack data
    positions = data["positions"]
    velocities = data["velocities"]
    accelerations = data["accelerations"]

    # Plot signed velocity histogram
    if velocities.size == 0:
        print("No valid velocities found.")
    else:
        plt.figure(figsize=(8, 6))
        plt.hist(velocities, bins=50)
        plt.xlabel("Velocity (Signed)")
        plt.ylabel("Counts")
        plt.title("Distribution of Signed Ego Velocities_" + feature_name)
        plt.grid(True)
        plot_path = os.path.join(save_dir, feature_name + "_ego_cur_signed_velocity_distribution.png")
        plt.savefig(plot_path)
        plt.close()

    # Plot signed acceleration histogram
    if accelerations.size == 0:
        print("No valid accelerations found.")
    else:
        plt.figure(figsize=(8, 6))
        plt.hist(accelerations, bins=50)
        plt.xlabel("Acceleration (Signed)")
        plt.ylabel("Counts")
        plt.title("Distribution of Signed Ego Accelerations_" + feature_name)
        plt.grid(True)
        plot_path = os.path.join(save_dir, feature_name + "_ego_cur_signed_acceleration_distribution.png")
        plt.savefig(plot_path)
        plt.close()


def compare_plot_egos(data_raw, data_new, save_dir, feature_name_raw, feature_name_new):
    """
    Generates comparison plots for ego features.
    """
    # Unpack data
    positions_raw = data_raw["positions"]
    velocities_raw = data_raw["velocities"]
    accelerations_raw = data_raw["accelerations"]

    positions_new = data_new["positions"]
    velocities_new = data_new["velocities"]
    accelerations_new = data_new["accelerations"]

    # Plot signed velocity histogram comparison
    if velocities_raw.size == 0 or velocities_new.size == 0:
        print("No valid velocities found in one of the datasets.")
    else:
        plt.figure(figsize=(18, 6))

        # Raw velocities
        plt.subplot(1, 3, 1)
        plt.hist(velocities_raw, bins=50)
        plt.xlabel("Signed Velocity")
        plt.ylabel("Counts")
        plt.title("Signed Ego Velocities - " + feature_name_raw)
        plt.grid(True)

        # New velocities
        plt.subplot(1, 3, 2)
        plt.hist(velocities_new, bins=50)
        plt.xlabel("Signed Velocity")
        plt.ylabel("Counts")
        plt.title("Signed Ego Velocities - " + feature_name_new)
        plt.grid(True)

        # Overlayed velocities
        plt.subplot(1, 3, 3)
        bins = np.histogram_bin_edges(np.concatenate([velocities_raw, velocities_new]), bins=50)
        plt.hist(velocities_raw, bins=bins, alpha=0.5, label=feature_name_raw)
        plt.hist(velocities_new, bins=bins, alpha=0.5, label=feature_name_new)
        plt.xlabel("Signed Velocity")
        plt.ylabel("Counts")
        plt.title("Overlayed Signed Ego Velocities")
        plt.legend()
        plt.grid(True)

        plot_path = os.path.join(save_dir, "compare_ego_cur_signed_velocity_distribution.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()

    # Plot signed acceleration histogram comparison
    if accelerations_raw.size == 0 or accelerations_new.size == 0:
        print("No valid accelerations found in one of the datasets.")
    else:
        plt.figure(figsize=(18, 6))

        # Raw accelerations
        plt.subplot(1, 3, 1)
        plt.hist(accelerations_raw, bins=50)
        plt.xlabel("Signed Acceleration")
        plt.ylabel("Counts")
        plt.title("Signed Ego Accelerations - " + feature_name_raw)
        plt.grid(True)

        # New accelerations
        plt.subplot(1, 3, 2)
        plt.hist(accelerations_new, bins=50)
        plt.xlabel("Signed Acceleration")
        plt.ylabel("Counts")
        plt.title("Signed Ego Accelerations - " + feature_name_new)
        plt.grid(True)

        # Overlayed accelerations
        plt.subplot(1, 3, 3)
        bins = np.histogram_bin_edges(np.concatenate([accelerations_raw, accelerations_new]), bins=50)
        plt.hist(accelerations_raw, bins=bins, alpha=0.5, label=feature_name_raw)
        plt.hist(accelerations_new, bins=bins, alpha=0.5, label=feature_name_new)
        plt.xlabel("Signed Acceleration")
        plt.ylabel("Counts")
        plt.title("Overlayed Signed Ego Accelerations")
        plt.legend()
        plt.grid(True)

        plot_path = os.path.join(save_dir, "compare_ego_cur_signed_acceleration_distribution.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()


def find_front_vehicle(ego, valid_bboxes):
    """
    Find the first front vehicle for the given ego and valid bboxes.

    Parameters:
    - ego: array of shape [15], ego's features
    - valid_bboxes: array of shape [N,40], valid bounding boxes

    Returns:
    - dict with keys 'position', 'velocity', 'acceleration', 'heading' if a front vehicle is found
    - None if no front vehicle is found
    """
    if valid_bboxes.shape[0] == 0:
        return None  # No valid bboxes

    ego_x = ego[0]
    ego_y = ego[1]
    ego_yaw = ego[6]  # Assuming this is in radians

    bbox_x = valid_bboxes[:, 0]
    bbox_y = valid_bboxes[:, 1]

    delta_x = bbox_x - ego_x
    delta_y = bbox_y - ego_y

    cos_yaw = np.cos(-ego_yaw)
    sin_yaw = np.sin(-ego_yaw)

    delta_x_prime = delta_x * cos_yaw - delta_y * sin_yaw  # Longitudinal distance
    delta_y_prime = delta_x * sin_yaw + delta_y * cos_yaw  # Lateral distance

    # Select indices where conditions are met
    selected_indices = np.where((delta_x_prime > 0) & (delta_x_prime <= 50) & (np.abs(delta_y_prime) <= 2))[0]

    if len(selected_indices) == 0:
        return None  # No front vehicle found

    # Find the one closest to ego (smallest delta_x_prime)
    min_index = selected_indices[np.argmin(delta_x_prime[selected_indices])]

    front_vehicle = {
        "position": valid_bboxes[min_index, 0:2],  # x, y
        "velocity": valid_bboxes[min_index, 10:12],  # vx, vy
        "acceleration": valid_bboxes[min_index, 13:15],  # ax, ay
        "heading": valid_bboxes[min_index, 6],  # heading
    }

    return front_vehicle


def collect_front_bbox_data(feature_dict):
    """
    Collects data related to the front bounding box (first front vehicle) from the feature dictionary.
    """
    # Initialize lists to collect data
    positions = []
    velocities = []
    accelerations = []
    headings = []
    ego_positions = []
    sub_clipids = []
    timestamps = []

    # Iterate over the data to extract and compute required metrics
    for sub_clipid in feature_dict:
        ts_dict = feature_dict[sub_clipid]
        for timestamp in ts_dict:
            feat_dict = ts_dict[timestamp]
            bboxes = feat_dict.get("bboxes", None)  # shape [35,191,40]
            bboxes_padding_mask = feat_dict.get("bboxes_padding_mask", None)  # shape [35,191]
            egos = feat_dict.get("egos", None)  # shape [15,1,15]

            if bboxes is not None and bboxes_padding_mask is not None and egos is not None:
                bboxes = np.array(bboxes)  # shape [35,191,40]
                bboxes_padding_mask = np.array(bboxes_padding_mask)  # shape [35,191]
                egos = np.array(egos)  # shape [15,1,15]

                # Use data from the last time step
                bboxes_last = bboxes[-1]  # shape [191,40]
                padding_mask_last = np.logical_not(bboxes_padding_mask[-1])  # shape [191]

                # Apply mask to filter out invalid bboxes
                valid_mask = padding_mask_last.astype(bool)  # shape [191]

                valid_bboxes = bboxes_last[valid_mask]  # shape [N_valid,40]

                # Get the last ego state
                ego = egos[-1, 0, :]  # shape [15]

                # Find front vehicle
                front_vehicle = find_front_vehicle(ego, valid_bboxes)

                if front_vehicle is not None:
                    positions.append(front_vehicle["position"])  # shape [2]
                    velocities.append(front_vehicle["velocity"])  # shape [2]
                    accelerations.append(front_vehicle["acceleration"])  # shape [2]
                    headings.append(front_vehicle["heading"])  # scalar
                    ego_positions.append(ego[0:2])  # shape [2]
                    sub_clipids.append(sub_clipid)
                    timestamps.append(timestamp)

    # Stack all collected data
    if positions:
        positions = np.vstack(positions)  # shape [Total_samples, 2]
    else:
        positions = np.array([])
    if velocities:
        velocities = np.vstack(velocities)  # shape [Total_samples, 2]
    else:
        velocities = np.array([])
    if accelerations:
        accelerations = np.vstack(accelerations)  # shape [Total_samples, 2]
    else:
        accelerations = np.array([])
    if headings:
        headings = np.array(headings)  # shape [Total_samples]
    else:
        headings = np.array([])
    if ego_positions:
        ego_positions = np.vstack(ego_positions)  # shape [Total_samples, 2]
    else:
        ego_positions = np.array([])
    if sub_clipids:
        sub_clipids = np.array(sub_clipids)
    else:
        sub_clipids = np.array([])
    if timestamps:
        timestamps = np.array(timestamps)
    else:
        timestamps = np.array([])

    # Return collected data
    data = {
        "positions": positions,
        "velocities": velocities,
        "accelerations": accelerations,
        "headings": headings,
        "ego_positions": ego_positions,
        "sub_clipids": sub_clipids,
        "timestamps": timestamps,
    }
    return data


def plot_front_bbox(data, save_dir, feature_name):
    """
    Plots the distribution of front bbox distances, velocities, and accelerations (with signed values)
    using bbox heading to determine the sign.
    """
    # Unpack data
    positions = data["positions"]
    velocities = data["velocities"]
    accelerations = data["accelerations"]
    headings = data["headings"]
    ego_positions = data["ego_positions"]

    # Compute signed velocities
    if velocities.size == 0:
        print("No valid velocities found.")
    else:
        # Normalize headings to unit vectors
        heading_vectors = np.stack((np.cos(headings), np.sin(headings)), axis=1)

        # Determine signed velocities
        velocity_angle_cos = np.einsum("ij,ij->i", velocities, heading_vectors) / (
            np.linalg.norm(velocities, axis=1) + 1e-8
        )
        signed_velocities = np.linalg.norm(velocities, axis=1) * np.where(velocity_angle_cos > 0, 1, -1)

        plt.figure(figsize=(8, 6))
        plt.hist(signed_velocities, bins=50)
        plt.xlabel("Velocity (Signed)")
        plt.ylabel("Counts")
        plt.title("Distribution of Signed Velocities_" + feature_name)
        plt.grid(True)
        plot_path = os.path.join(save_dir, feature_name + "_front_bbox_signed_velocity_distribution.png")
        plt.savefig(plot_path)
        plt.close()

    # Compute signed accelerations
    if accelerations.size == 0:
        print("No valid accelerations found.")
    else:
        # Determine signed accelerations
        acceleration_angle_cos = np.einsum("ij,ij->i", accelerations, heading_vectors) / (
            np.linalg.norm(accelerations, axis=1) + 1e-8
        )
        signed_accelerations = np.linalg.norm(accelerations, axis=1) * np.where(acceleration_angle_cos > 0, 1, -1)

        plt.figure(figsize=(8, 6))
        plt.hist(signed_accelerations, bins=50)
        plt.xlabel("Acceleration (Signed)")
        plt.ylabel("Counts")
        plt.title("Distribution of Signed Accelerations_" + feature_name)
        plt.grid(True)
        plot_path = os.path.join(save_dir, feature_name + "_front_bbox_signed_acceleration_distribution.png")
        plt.savefig(plot_path)
        plt.close()

    # Compute distances between front vehicle and ego vehicle
    if positions.size == 0:
        print("No valid positions found.")
    else:
        distances = np.sqrt(np.sum((positions - ego_positions) ** 2, axis=1))
        plt.figure(figsize=(8, 6))
        plt.hist(distances, bins=50)
        plt.xlabel("Distance from Ego")
        plt.ylabel("Counts")
        plt.title("Distribution of Front BBox Distances at Current Step_" + feature_name)
        plt.grid(True)
        plot_path = os.path.join(save_dir, feature_name + "_front_bbox_distance_distribution.png")
        plt.savefig(plot_path)
        plt.close()


def compare_plot_front_bbox(data_raw, data_new, save_dir, feature_name_raw, feature_name_new, prefix=""):
    """
    Generates comparison plots for front bounding box features.
    """
    # Unpack data
    positions_raw = data_raw["positions"]
    velocities_raw = data_raw["velocities"]
    accelerations_raw = data_raw["accelerations"]
    headings_raw = data_raw["headings"]
    ego_positions_raw = data_raw["ego_positions"]

    positions_new = data_new["positions"]
    velocities_new = data_new["velocities"]
    accelerations_new = data_new["accelerations"]
    headings_new = data_new["headings"]
    ego_positions_new = data_new["ego_positions"]

    # Plot signed velocity histogram comparison
    if velocities_raw.size == 0 or velocities_new.size == 0:
        print("No valid velocities found in one of the datasets.")
    else:
        # Compute signed velocities for raw data
        heading_vectors_raw = np.stack((np.cos(headings_raw), np.sin(headings_raw)), axis=1)
        velocity_angle_cos_raw = np.einsum("ij,ij->i", velocities_raw, heading_vectors_raw) / (
            np.linalg.norm(velocities_raw, axis=1) + 1e-8
        )
        signed_velocities_raw = np.linalg.norm(velocities_raw, axis=1) * np.where(velocity_angle_cos_raw > 0, 1, -1)

        # Compute signed velocities for new data
        heading_vectors_new = np.stack((np.cos(headings_new), np.sin(headings_new)), axis=1)
        velocity_angle_cos_new = np.einsum("ij,ij->i", velocities_new, heading_vectors_new) / (
            np.linalg.norm(velocities_new, axis=1) + 1e-8
        )
        signed_velocities_new = np.linalg.norm(velocities_new, axis=1) * np.where(velocity_angle_cos_new > 0, 1, -1)

        plt.figure(figsize=(18, 6))

        # Raw velocities
        plt.subplot(1, 3, 1)
        plt.hist(signed_velocities_raw, bins=50)
        plt.xlabel("Signed Velocity")
        plt.ylabel("Counts")
        plt.title("Signed Velocities - " + feature_name_raw)
        plt.grid(True)

        # New velocities
        plt.subplot(1, 3, 2)
        plt.hist(signed_velocities_new, bins=50)
        plt.xlabel("Signed Velocity")
        plt.ylabel("Counts")
        plt.title("Signed Velocities - " + feature_name_new)
        plt.grid(True)

        # Overlayed velocities
        bins = np.histogram_bin_edges(np.concatenate([signed_velocities_raw, signed_velocities_new]), bins=50)
        plt.subplot(1, 3, 3)
        plt.hist(signed_velocities_raw, bins=bins, alpha=0.5, label=feature_name_raw)
        plt.hist(signed_velocities_new, bins=bins, alpha=0.5, label=feature_name_new)
        plt.xlabel("Signed Velocity")
        plt.ylabel("Counts")
        plt.title("Overlayed Signed Velocities")
        plt.legend()
        plt.grid(True)

        plot_path = os.path.join(save_dir, prefix + "compare_front_bbox_signed_velocity_distribution.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()

    # Plot signed acceleration histogram comparison
    if accelerations_raw.size == 0 or accelerations_new.size == 0:
        print("No valid accelerations found in one of the datasets.")
    else:
        # Compute signed accelerations for raw data
        acceleration_angle_cos_raw = np.einsum("ij,ij->i", accelerations_raw, heading_vectors_raw) / (
            np.linalg.norm(accelerations_raw, axis=1) + 1e-8
        )
        signed_accelerations_raw = np.linalg.norm(accelerations_raw, axis=1) * np.where(
            acceleration_angle_cos_raw > 0, 1, -1
        )

        # Compute signed accelerations for new data
        acceleration_angle_cos_new = np.einsum("ij,ij->i", accelerations_new, heading_vectors_new) / (
            np.linalg.norm(accelerations_new, axis=1) + 1e-8
        )
        signed_accelerations_new = np.linalg.norm(accelerations_new, axis=1) * np.where(
            acceleration_angle_cos_new > 0, 1, -1
        )

        plt.figure(figsize=(18, 6))

        # Raw accelerations
        plt.subplot(1, 3, 1)
        plt.hist(signed_accelerations_raw, bins=50)
        plt.xlabel("Signed Acceleration")
        plt.ylabel("Counts")
        plt.title("Signed Accelerations - " + feature_name_raw)
        plt.grid(True)

        # New accelerations
        plt.subplot(1, 3, 2)
        plt.hist(signed_accelerations_new, bins=50)
        plt.xlabel("Signed Acceleration")
        plt.ylabel("Counts")
        plt.title("Signed Accelerations - " + feature_name_new)
        plt.grid(True)

        # Overlayed accelerations
        plt.subplot(1, 3, 3)
        bins = np.histogram_bin_edges(np.concatenate([signed_accelerations_raw, signed_accelerations_new]), bins=50)
        plt.hist(signed_accelerations_raw, bins=bins, alpha=0.5, label=feature_name_raw)
        plt.hist(signed_accelerations_new, bins=bins, alpha=0.5, label=feature_name_new)
        plt.xlabel("Signed Acceleration")
        plt.ylabel("Counts")
        plt.title("Overlayed Signed Accelerations")
        plt.legend()
        plt.grid(True)

        plot_path = os.path.join(save_dir, prefix + "compare_front_bbox_signed_acceleration_distribution.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()

    # Plot distance from ego comparison
    if positions_raw.size == 0 or positions_new.size == 0:
        print("No valid positions found in one of the datasets.")
    else:
        distances_raw = np.sqrt(np.sum((positions_raw - ego_positions_raw) ** 2, axis=1))
        distances_new = np.sqrt(np.sum((positions_new - ego_positions_new) ** 2, axis=1))

        plt.figure(figsize=(18, 6))

        # Raw distances
        plt.subplot(1, 3, 1)
        plt.hist(distances_raw, bins=50)
        plt.xlabel("Distance from Ego")
        plt.ylabel("Counts")
        plt.title("Distances - " + feature_name_raw)
        plt.grid(True)

        # New distances
        plt.subplot(1, 3, 2)
        plt.hist(distances_new, bins=50)
        plt.xlabel("Distance from Ego")
        plt.ylabel("Counts")
        plt.title("Distances - " + feature_name_new)
        plt.grid(True)

        # Overlayed distances
        plt.subplot(1, 3, 3)
        bins = np.histogram_bin_edges(np.concatenate([distances_raw, distances_new]), bins=50)
        plt.hist(distances_raw, bins=bins, alpha=0.5, label=feature_name_raw)
        plt.hist(distances_new, bins=bins, alpha=0.5, label=feature_name_new)
        plt.xlabel("Distance from Ego")
        plt.ylabel("Counts")
        plt.title("Overlayed Distances")
        plt.legend()
        plt.grid(True)

        plot_path = os.path.join(save_dir, prefix + "compare_front_bbox_distance_distribution.png")
        plt.tight_layout()
        plt.savefig(plot_path)
        plt.close()


def collect_common_front_bbox_data(data_raw, data_new, distance_threshold=0.5):
    """
    Collects common data where the front vehicle is within a certain distance in both datasets.
    """
    # Unpack data
    positions_raw = data_raw["positions"]
    positions_new = data_new["positions"]
    sub_clipids_raw = data_raw["sub_clipids"]
    timestamps_raw = data_raw["timestamps"]
    sub_clipids_new = data_new["sub_clipids"]
    timestamps_new = data_new["timestamps"]

    # Create dictionaries to map (sub_clipid, timestamp) to indices
    raw_index = {
        (sub_clipid, timestamp): idx for idx, (sub_clipid, timestamp) in enumerate(zip(sub_clipids_raw, timestamps_raw))
    }
    new_index = {
        (sub_clipid, timestamp): idx for idx, (sub_clipid, timestamp) in enumerate(zip(sub_clipids_new, timestamps_new))
    }

    # Find common keys
    common_keys = set(raw_index.keys()) & set(new_index.keys())

    # Initialize lists for common data indices
    common_indices_raw = []
    common_indices_new = []

    # For each common key, check if the distance between front vehicles is less than threshold
    for key in common_keys:
        idx_raw = raw_index[key]
        idx_new = new_index[key]

        pos_raw = positions_raw[idx_raw]
        pos_new = positions_new[idx_new]

        distance = np.linalg.norm(pos_raw - pos_new)

        if distance < distance_threshold:
            common_indices_raw.append(idx_raw)
            common_indices_new.append(idx_new)

    # Extract common data for raw dataset
    data_common_raw = {
        "positions": data_raw["positions"][common_indices_raw],
        "velocities": data_raw["velocities"][common_indices_raw],
        "accelerations": data_raw["accelerations"][common_indices_raw],
        "headings": data_raw["headings"][common_indices_raw],
        "ego_positions": data_raw["ego_positions"][common_indices_raw],
    }

    # Extract common data for new dataset
    data_common_new = {
        "positions": data_new["positions"][common_indices_new],
        "velocities": data_new["velocities"][common_indices_new],
        "accelerations": data_new["accelerations"][common_indices_new],
        "headings": data_new["headings"][common_indices_new],
        "ego_positions": data_new["ego_positions"][common_indices_new],
    }

    return data_common_raw, data_common_new


# Repeat similar implementations for 'sod' and 'god' features.

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--result_dir", type=str, required=False, default="./data_compare/")
    parser.add_argument("--feature_name_raw", type=str, required=False, default="raw_common_sample")
    parser.add_argument("--feature_name_new", type=str, required=False, default="new_common_sample")
    args = parser.parse_args()

    save_dir = os.path.join(args.result_dir, "feature_distribution_plots")
    os.makedirs(save_dir, exist_ok=True)
    # draw_feature_distribution(args.feature_name_raw, args.result_dir, save_dir)
    # draw_feature_distribution(args.feature_name_new, args.result_dir, save_dir)
    compare_feature_distribution(args.feature_name_raw, args.feature_name_new, args.result_dir, save_dir)
