# -*- coding: utf-8 -*-
# flake8: noqa: F403
# flake8: noqa: F405
# flake8: noqa: D400
# flake8: noqa: N802
# flake8: noqa: D103
# flake8: noqa: N806
# flake8: noqa: T201
# flake8: noqa: D200
# flake8: noqa: D401
import argparse
import base64
import csv
import mimetypes
import os
import shutil
import subprocess
import sys
import urllib.parse

import markdown  # type: ignore
import pdfkit


if "XDG_RUNTIME_DIR" not in os.environ:
    user = os.getenv("USER") or "default_user"  # 获取当前用户名称
    os.environ["XDG_RUNTIME_DIR"] = f"/tmp/runtime-{user}"


def check_and_install_wkhtmltopdf():
    # 检查 wkhtmltopdf 是否存在
    wkhtmltopdf_path = shutil.which("wkhtmltopdf")
    if wkhtmltopdf_path:
        print(f"wkhtmltopdf 已安装，路径为: {wkhtmltopdf_path}")
    else:
        print("wkhtmltopdf 未安装，开始安装...")
        try:
            # 执行 sudo apt-get update
            subprocess.run(
                ["sudo", "apt-get", "update"],
                check=True,
                text=True,
            )
            # 执行 sudo apt-get install wkhtmltopdf
            subprocess.run(
                ["sudo", "apt-get", "install", "-y", "wkhtmltopdf"],
                check=True,
                text=True,
            )
            print("wkhtmltopdf 安装完成！")
        except subprocess.CalledProcessError as e:
            print("安装 wkhtmltopdf 失败，请检查您的网络连接和权限。")


def check_and_install_font(font_name="Noto Sans CJK"):
    """
    检查系统是否已安装指定字体，如果未安装，则执行安装命令。

    :param font_name: 要检查的字体名称
    """
    try:
        # 检查系统字体目录中是否存在字体
        fc_list = shutil.which("fc-list")
        if not fc_list:
            print("无法找到 fc-list 工具，请确保字体配置工具已安装。")
            sys.exit(1)

        # 使用 fc-list 检查字体是否存在
        result = subprocess.run(
            ["fc-list", ":family"], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
        )
        if font_name in result.stdout:
            print(f"字体 '{font_name}' 已安装。")
            return
        else:
            print(f"字体 '{font_name}' 未安装，开始安装...")

        # 安装字体
        subprocess.run(
            ["sudo", "apt-get", "install", "-y", "fonts-noto-cjk"],
            check=True,
            text=True,
        )
        print(f"字体 '{font_name}' 安装完成！")

    except subprocess.CalledProcessError as e:
        print("安装字体时出错，请检查网络连接和权限。")


class MarkdownGenerator:
    def __init__(self, file_name):
        self.file_name = file_name
        self.headings = []
        self.content = []
        # 初始化内容，跳过写入文件，暂存在内存
        self.content.append("# Data Monitor\n\n")

    def write_heading(self, text, level=1):
        """写入标题并记录标题信息"""
        if 1 <= level <= 6:
            self.headings.append((level, text))
            self.content.append(f"{'#' * level} {text}\n\n")
        else:
            raise ValueError("标题级别必须在 1 到 6 之间")

    def write_paragraph(self, text):
        """写入正文内容"""
        self.content.append(f"{text}\n\n")

    def insert_image(self, args, image_path, alt_text="Image", width="100%"):
        """插入图片，直接将图片嵌入到 Markdown 文件中"""
        img_path = os.path.join(args.save_dir, image_path)
        img_path = os.path.abspath(img_path)
        if not os.path.exists(img_path):
            print(f"图片文件未找到: {img_path}")
            return

        # 读取并编码图片
        with open(img_path, "rb") as img_file:
            img_data = img_file.read()
            encoded_string = base64.b64encode(img_data).decode("utf-8")

        # 获取图片的 MIME 类型
        mime_type, _ = mimetypes.guess_type(img_path)
        if mime_type is None:
            mime_type = "image/png"  # 默认使用 png

        # 构建 data URL
        data_url = f"data:{mime_type};base64,{encoded_string}"

        # 在 Markdown 中插入图片，使用 HTML 标签以支持样式
        self.content.append(f'<img src="{data_url}" alt="{alt_text}" style="width: {width}; height: auto;">\n\n')

    def insert_csv_table(self, csv_file):
        """插入 CSV 表格为 Markdown 表格"""
        if not os.path.exists(csv_file):
            print(f"CSV 文件未找到: {csv_file}")
            return

        with open(csv_file, "r", encoding="utf-8") as f_csv:
            reader = csv.reader(f_csv)
            rows = list(reader)

            if not rows:
                print(f"CSV 文件为空: {csv_file}")
                return

            headers = rows[0]
            self.content.append("| " + " | ".join(headers) + " |\n")
            self.content.append("|" + "---|" * len(headers) + "\n")

            for row in rows[1:]:
                self.content.append("| " + " | ".join(row) + " |\n")
            self.content.append("\n")

    def save_markdown(self):
        """将目录和内容写入 Markdown 文件"""
        with open(self.file_name, "w", encoding="utf-8") as f:
            # 写入标题
            f.write("# Data Monitor\n\n")
            # 写入目录，使用 [TOC] 占位符
            f.write("[TOC]\n\n")
            # 写入实际内容
            for line in self.content[1:]:  # 跳过初始标题
                f.write(line)

    def save_as_pdf(self, output_pdf):
        """将 Markdown 文件转换为 PDF，支持图片和本地资源，并包含目录"""
        # 首先保存包含目录的 Markdown 文件
        self.save_markdown()

        with open(self.file_name, "r", encoding="utf-8") as f:
            md_content = f.read()

        # 自定义 slugify 函数
        def slugify(value, separator):
            # 对标题进行 URL 编码
            return urllib.parse.quote_plus(value)

        # 配置 markdown 扩展和选项
        extensions = ["tables", "toc", "attr_list"]
        extension_configs = {"toc": {"permalink": False, "anchorlink": True, "slugify": slugify}}

        # 使用 markdown 库的 toc 扩展来生成 HTML 中的目录
        html_content = markdown.markdown(md_content, extensions=extensions, extension_configs=extension_configs)

        # 获取 Markdown 文件所在的目录
        base_dir = os.path.dirname(os.path.abspath(self.file_name))

        # 添加 CSS 和 base 标签
        html_with_css = f"""
        <html>
        <head>
            <meta charset="utf-8">
            <base href="file://{base_dir}/"> <!-- 设置文件系统基准路径 -->
            <style>
                body {{
                    font-family: 'Noto Sans CJK SC', 'Microsoft YaHei', 'SimSun', sans-serif;
                    line-height: 1.5;
                    padding: 20px;
                }}
                table {{
                    border-collapse: collapse;
                    width: 100%;
                    table-layout: fixed;
                    word-wrap: break-word;
                }}
                th, td {{
                    border: 1px solid #ddd;
                    padding: 8px;
                    text-align: left;
                }}
                th {{
                    background-color: #f2f2f2;
                    font-weight: bold;
                }}
                img {{
                    max-width: 100%;
                    height: auto;
                    display: block;
                    margin-left: auto;
                    margin-right: auto;
                }}
                /* 目录样式 */
                .toc {{
                    margin-bottom: 20px;
                }}
                .toc ul {{
                    /* 可以根据需要调整 */
                }}
                .toc li {{
                    margin: 5px 0;
                }}
            </style>
        </head>
        <body>
            {html_content}
        </body>
        </html>
        """

        # 定义 PDF 生成选项
        options = {
            "enable-local-file-access": "",
            "page-size": "A4",
            "margin-top": "20mm",
            "margin-right": "15mm",
            "margin-bottom": "20mm",
            "margin-left": "15mm",
            "encoding": "UTF-8",
            "enable-internal-links": None,
        }

        # 使用 pdfkit 将 HTML 转换为 PDF
        try:
            pdfkit.from_string(html_with_css, output_pdf, options=options)
            print(f"PDF 文件已保存到: {output_pdf}")
        except Exception as e:
            print(f"生成 PDF 失败: {e}")
            sys.exit(1)

    def save_as_html(self, output_html):
        """将 Markdown 文件转换为 HTML，并保存为 HTML 文件"""
        # 首先保存包含目录的 Markdown 文件
        self.save_markdown()

        with open(self.file_name, "r", encoding="utf-8") as f:
            md_content = f.read()

        # 自定义 slugify 函数
        def slugify(value, separator):
            # 对标题进行 URL 编码
            return urllib.parse.quote_plus(value)

        # 配置 markdown 扩展和选项
        extensions = ["tables", "toc", "attr_list"]
        extension_configs = {"toc": {"permalink": False, "anchorlink": True, "slugify": slugify}}

        # 使用 markdown 库的 toc 扩展来生成 HTML 中的目录
        html_content = markdown.markdown(md_content, extensions=extensions, extension_configs=extension_configs)

        # 不需要再处理图片嵌入，因为图片已经嵌入在 Markdown 中

        # 添加 CSS 和其他 HTML 结构
        html_output = f"""
        <html>
        <head>
            <meta charset="utf-8">
            <style>
                body {{
                    font-family: 'Noto Sans CJK SC', 'Microsoft YaHei', 'SimSun', sans-serif;
                    line-height: 1.5;
                    padding: 20px;
                }}
                table {{
                    border-collapse: collapse;
                    width: 100%;
                    table-layout: fixed;
                    word-wrap: break-word;
                }}
                th, td {{
                    border: 1px solid #ddd;
                    padding: 8px;
                    text-align: left;
                }}
                th {{
                    background-color: #f2f2f2;
                    font-weight: bold;
                }}
                img {{
                    max-width: 100%;
                    height: auto;
                    display: block;
                    margin-left: auto;
                    margin-right: auto;
                }}
                /* 目录样式 */
                .toc {{
                    margin-bottom: 20px;
                }}
                .toc ul {{
                    /* 可以根据需要调整 */
                }}
                .toc li {{
                    margin: 5px 0;
                }}
            </style>
        </head>
        <body>
            {html_content}
        </body>
        </html>
        """

        # 将最终的 HTML 保存到文件
        with open(output_html, "w", encoding="utf-8") as f:
            f.write(html_output)
        print(f"HTML 文件已保存到: {output_html}")


# 使用示例
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process some parameters.")
    parser.add_argument("--save_dir", default="./data_compare", type=str, help="The saving path")
    parser.add_argument(
        "--share_save_dir",
        default="/share-global/mccree.zhao/share/planning/dataset/1114_0918_urban",
        type=str,
        help="The saving path",
    )
    parser.add_argument(
        "--raw_file_list",
        default=["/share-global/mccree.zhao/share/planning/dataset/1114_0918_urban/0918_urban_unique_dup1.txt"],
        nargs="+",
        type=str,
        help="The raw dataset clip list path",
    )
    parser.add_argument(
        "--new_file_list",
        default=["/share-global/mccree.zhao/share/planning/dataset/1114_0918_urban/1106_rl_unique_dup1.txt"],
        nargs="+",
        type=str,
        help="The new dataset clip list path",
    )
    parser.add_argument(
        "--tag_version_raw", default="prod_yx_20240919_tags_only_all", type=str, help="The version name of tag"
    )
    parser.add_argument(
        "--tag_version_new", default="prod_v202411061500_all_tags", type=str, help="The version name of tag"
    )
    parser.add_argument("--save_name", default="Data_monitor", type=str, help="The saving name of the markdown file")
    args = parser.parse_args()

    check_and_install_wkhtmltopdf()
    check_and_install_font()

    md = MarkdownGenerator(f"{args.save_name}.md")

    # 写入各部分内容
    md.write_heading("1.数据来源", level=1)
    md.write_paragraph("- Base数据来源:")
    raw_file_list = ",\n".join(args.raw_file_list)
    md.write_paragraph(f"    - Base数据列表:  {raw_file_list}")
    md.write_paragraph(f"    - Base数据tag版本: {args.tag_version_raw}")
    md.write_paragraph("- New数据来源:")
    new_file_list = ",\n".join(args.new_file_list)
    md.write_paragraph(f"    - New数据列表:  {new_file_list}")
    md.write_paragraph(f"    - New数据tag版本: {args.tag_version_new}")

    md.write_heading("2.数据列表", level=1)
    md.write_heading("2.1 Clip List", level=2)
    md.write_paragraph("- Clip list diff:")
    md.insert_csv_table(os.path.join(args.save_dir, "clip_list_diff.csv"))
    md.write_paragraph("- Clip txt path:")
    md.insert_csv_table(os.path.join(args.save_dir, "clip_path.csv"))
    md.write_heading("2.2 Frame", level=2)
    md.write_heading("2.2.1 Frame Num", level=3)
    md.write_paragraph("- Frame Num Comparison:")
    md.insert_csv_table(os.path.join(args.save_dir, "frames_compare/clip_statistics_summary.csv"))
    md.write_paragraph("- Top10 Frame Num Difference:")
    md.insert_csv_table(os.path.join(args.save_dir, "frames_compare/top_10_frame_differences.csv"))
    md.write_heading("2.2.2 Frame time gap", level=3)
    md.write_paragraph("- Frame time gap anomoly:")
    md.insert_csv_table(os.path.join(args.save_dir, "frames_compare/summary_anomaly_stats.csv"))
    md.write_paragraph("- Top10 Anomoly Frame Difference:")
    md.insert_csv_table(os.path.join(args.save_dir, "frames_compare/top_10_anomaly_frame_differences.csv"))
    md.write_paragraph("- Anomoly Future Timestamp:")
    md.insert_csv_table(os.path.join(args.save_dir, "frames_compare/future35_greater_stats.csv"))
    md.write_paragraph("- Anomoly Future Timestamp Comparison:")
    md.insert_csv_table(os.path.join(args.save_dir, "frames_compare/future35_cross_stats.csv"))
    md.insert_image(args, "frames_compare/future35_distribution.png")
    md.write_heading("2.2.3 Diff Clip Frame Num Comparison", level=3)
    md.write_paragraph("- Common clips frame num comparison:")
    md.insert_image(args, "frames_compare/common_clip_frame_num.png")
    md.write_paragraph("- Diff clips frame num comparison:")
    md.insert_image(args, "frames_compare/diff_clip_frame_num.png")
    md.write_heading("2.2.4 Frame time gap distribution comparison", level=3)
    md.write_paragraph("- Raw common data:")
    md.insert_csv_table(os.path.join(args.save_dir, "frames_compare/raw_common_frame_gap_statistics.csv"))
    md.insert_image(args, "frames_compare/raw_common_frame_gap_histogram.png")
    md.insert_csv_table(
        os.path.join(args.save_dir, "frames_compare/raw_common_future_25_frame_duration_statistics.csv")
    )
    md.insert_image(args, "frames_compare/raw_common_future_25_frame_duration_histogram.png")
    md.write_paragraph("- New common data:")
    md.insert_csv_table(os.path.join(args.save_dir, "frames_compare/new_common_frame_gap_statistics.csv"))
    md.insert_image(args, "frames_compare/new_common_frame_gap_histogram.png")
    md.insert_csv_table(
        os.path.join(args.save_dir, "frames_compare/new_common_future_25_frame_duration_statistics.csv")
    )
    md.insert_image(args, "frames_compare/new_common_future_25_frame_duration_histogram.png")
    md.write_paragraph("- Missing data:")
    md.insert_csv_table(os.path.join(args.save_dir, "frames_compare/missing_frame_gap_statistics.csv"))
    md.insert_image(args, "frames_compare/missing_frame_gap_histogram.png")
    md.insert_csv_table(os.path.join(args.save_dir, "frames_compare/missing_future_25_frame_duration_statistics.csv"))
    md.insert_image(args, "frames_compare/missing_future_25_frame_duration_histogram.png")
    md.write_paragraph("- Addition data:")
    md.insert_csv_table(os.path.join(args.save_dir, "frames_compare/addition_frame_gap_statistics.csv"))
    md.insert_image(args, "frames_compare/addition_frame_gap_histogram.png")
    md.insert_csv_table(os.path.join(args.save_dir, "frames_compare/addition_future_25_frame_duration_statistics.csv"))
    md.insert_image(args, "frames_compare/addition_future_25_frame_duration_histogram.png")

    md.write_heading("3.Tag对比", level=1)
    md.write_heading("3.1 Union Part Comparison", level=2)

    md.write_heading("3.1.1 Tag Distribution Comparison", level=3)
    md.insert_csv_table(os.path.join(args.save_dir, "tags/tag_new_raw_distribution_comparison.csv"))
    md.insert_image(args, "tags/tag_new_raw_distribution_comparison.png")

    md.write_heading("3.1.2 Raw Tag Distribution", level=3)
    md.insert_csv_table(os.path.join(args.save_dir, "tags/tag_raw_distribution.csv"))
    md.insert_image(args, "tags/tag_raw_distribution.png")

    md.write_heading("3.1.3 New Tag Distribution", level=3)
    md.insert_csv_table(os.path.join(args.save_dir, "tags/tag_new_distribution.csv"))
    md.insert_image(args, "tags/tag_new_distribution.png")

    if os.path.exists(os.path.join(args.save_dir, "tags/missing_tag_distribution.csv")):
        md.write_heading("3.2 Missing Part", level=2)
        md.insert_csv_table(os.path.join(args.save_dir, "tags/missing_tag_distribution.csv"))
        md.insert_image(args, "tags/missing_tag_distribution.png")

    if os.path.exists(os.path.join(args.save_dir, "tags/addition_tag_distribution.csv")):
        md.write_heading("3.3 Addition Part", level=2)
        md.insert_csv_table(os.path.join(args.save_dir, "tags/addition_tag_distribution.csv"))
        md.insert_image(args, "tags/addition_tag_distribution.png")

    md.write_heading("4.Feature对比", level=1)

    md.write_heading("4.1 Feature Distribution Comparison", level=2)

    md.write_heading("4.1.1 Ego Feature", level=3)
    md.write_heading("4.1.1.1 Ego Current Vel", level=4)
    md.insert_image(args, "feature_distribution_plots/compare_ego_cur_signed_velocity_distribution.png")

    md.write_heading("4.1.1.2 Ego Current Acc", level=4)
    md.insert_image(args, "feature_distribution_plots/compare_ego_cur_signed_acceleration_distribution.png")

    md.write_heading("4.1.1.3 Ego Future Endpoint", level=4)
    md.insert_image(args, "feature_distribution_plots/compare_egos_endpoint_scatter.png")

    md.write_heading("4.1.1.4 Ego Future length", level=4)
    md.insert_image(args, "feature_distribution_plots/compare_egos_length_distribution.png")

    md.write_heading("4.1.1.5 Ego Future Vel", level=4)
    md.insert_image(args, "feature_distribution_plots/compare_egos_speed_distribution.png")

    md.write_heading("4.1.1.6 Ego Future Acc", level=4)
    md.insert_image(args, "feature_distribution_plots/compare_egos_future_acceleration_distribution.png")

    md.write_heading("4.1.2 Navilane Feature", level=3)
    md.write_heading("4.1.2.1 Navilane Number", level=4)
    md.insert_image(args, "feature_distribution_plots/compare_navi_line_count_distribution.png")

    md.write_heading("4.1.2.2 Navilane Length", level=4)
    md.insert_image(args, "feature_distribution_plots/compare_navi_line_length_distribution.png")

    md.write_heading("4.1.3 Lane Detection Feature", level=3)
    md.write_heading("4.1.3.1 Lane Number", level=4)
    md.insert_image(args, "feature_distribution_plots/compare_lane_count_distribution.png")

    md.write_heading("4.1.3.2 Lane Length", level=4)
    md.insert_image(args, "feature_distribution_plots/compare_lane_length_distribution.png")

    md.write_heading("4.1.4 Bbox feature", level=3)
    md.write_heading("4.1.4.1 Bbox distance to Ego", level=4)
    md.insert_image(args, "feature_distribution_plots/compare_bbox_distance_distribution.png")

    md.write_heading("4.1.4.2 Bbox Current Acceleration", level=4)
    md.insert_image(args, "feature_distribution_plots/compare_bbox_signed_acceleration_distribution.png")

    md.write_heading("4.1.4.3 Bbox Current Velocity", level=4)
    md.insert_image(args, "feature_distribution_plots/compare_bbox_signed_velocity_distribution.png")

    md.write_heading("4.1.5 Front Bbox feature", level=3)
    md.write_heading("4.1.5.1 Front Bbox distance to Ego", level=4)
    md.insert_image(args, "feature_distribution_plots/compare_front_bbox_distance_distribution.png")

    md.write_heading("4.1.5.2 Front Bbox Current Acceleration", level=4)
    md.insert_image(args, "feature_distribution_plots/compare_front_bbox_signed_acceleration_distribution.png")

    md.write_heading("4.1.5.3 Front Bbox Current Velocity", level=4)
    md.insert_image(args, "feature_distribution_plots/compare_front_bbox_signed_velocity_distribution.png")

    md.write_heading("4.2 Frame-level feature comparison", level=2)

    md.write_heading("4.2.1 Ego feature", level=3)

    md.write_heading("4.2.1.1 Ego current veloicty", level=4)
    md.insert_csv_table(
        os.path.join(args.save_dir, "frame_feature_comparsion/egos/ego_table7_current_velocity_statistics.csv")
    )
    md.insert_csv_table(
        os.path.join(args.save_dir, "frame_feature_comparsion/egos/ego_table8_top10_current_velocity_differences.csv")
    )

    md.write_heading("4.2.1.2 Ego current acceleration", level=4)
    md.insert_csv_table(
        os.path.join(args.save_dir, "frame_feature_comparsion/egos/ego_table9_current_acceleration_statistics.csv")
    )
    md.insert_csv_table(
        os.path.join(
            args.save_dir, "frame_feature_comparsion/egos/ego_table10_top10_current_acceleration_differences.csv"
        )
    )

    md.write_heading("4.2.1.3 Ego future trajectory length", level=4)
    md.insert_csv_table(os.path.join(args.save_dir, "frame_feature_comparsion/egos/ego_table1_statistics.csv"))
    md.insert_csv_table(os.path.join(args.save_dir, "frame_feature_comparsion/egos/ego_table2_top10_differences.csv"))

    md.write_heading("4.2.1.4 Ego future velocity", level=4)
    md.insert_csv_table(os.path.join(args.save_dir, "frame_feature_comparsion/egos/ego_table3_velocity_statistics.csv"))
    md.insert_csv_table(
        os.path.join(args.save_dir, "frame_feature_comparsion/egos/ego_table4_top10_velocity_differences.csv")
    )
    md.write_heading("4.2.1.5 Ego future acceleration", level=4)
    md.insert_csv_table(
        os.path.join(args.save_dir, "frame_feature_comparsion/egos/ego_table5_acceleration_statistics.csv")
    )
    md.insert_csv_table(
        os.path.join(args.save_dir, "frame_feature_comparsion/egos/ego_table6_top10_acceleration_differences.csv")
    )

    md.write_heading("4.2.2 Navilane", level=3)
    md.write_heading("4.2.2.1 Navilane Num & Length", level=4)
    md.insert_csv_table(os.path.join(args.save_dir, "frame_feature_comparsion/navilane/navi_table1_statistics.csv"))
    md.insert_csv_table(
        os.path.join(args.save_dir, "frame_feature_comparsion/navilane/navi_table2_top10_differences.csv")
    )

    md.write_heading("4.2.3 Lane Detection", level=3)
    md.write_heading("4.2.3.1 Lane Num & Length", level=4)
    md.insert_csv_table(os.path.join(args.save_dir, "frame_feature_comparsion/lane/lane_table1_statistics.csv"))
    md.insert_csv_table(os.path.join(args.save_dir, "frame_feature_comparsion/lane/lane_table2_top10_differences.csv"))

    md.write_heading("4.2.4 Front Bbox", level=3)
    md.write_heading("4.2.4.1 Front Bbox Existance", level=4)
    md.insert_csv_table(
        os.path.join(args.save_dir, "frame_feature_comparsion/bbox/bbox_first_front_vehicle_statistics.csv")
    )
    md.write_heading("4.2.4.2 Front BBox Statistics", level=4)
    md.insert_csv_table(
        os.path.join(args.save_dir, "frame_feature_comparsion/bbox/bbox_speed_acceleration_statistics.csv")
    )
    md.write_heading("4.2.4.3 Front Bbox Position", level=4)
    md.insert_csv_table(
        os.path.join(args.save_dir, "frame_feature_comparsion/bbox/bbox_top10_position_differences.csv")
    )
    md.write_heading("4.2.4.4 Front Bbox Velocity", level=4)
    md.insert_csv_table(os.path.join(args.save_dir, "frame_feature_comparsion/bbox/bbox_top10_speed_differences.csv"))
    md.write_heading("4.2.4.5 Front Bbox Acceleration", level=4)
    md.insert_csv_table(
        os.path.join(args.save_dir, "frame_feature_comparsion/bbox/bbox_top10_acceleration_differences.csv")
    )
    md.write_heading("4.2.4.6 Front Bbox Anomoly Comparision", level=4)
    md.insert_csv_table(
        os.path.join(args.save_dir, "frame_feature_comparsion/bbox/bbox_zero_nonzero_speed_accel_statistics.csv")
    )

    # 生成 PDF
    md.save_as_pdf(f"{args.save_name}.pdf")
    md.save_as_html(f"{args.save_name}.html")

    share_save_dir = args.share_save_dir
    share_save_target = os.path.join(share_save_dir, "data_compare")
    os.makedirs(share_save_dir, exist_ok=True)
    shutil.copyfile(f"{args.save_name}.pdf", os.path.join(share_save_dir, f"{args.save_name}.pdf"))
    shutil.copyfile(f"{args.save_name}.html", os.path.join(share_save_dir, f"{args.save_name}.html"))
    print(f"PDF have been written to {os.path.join(share_save_dir, f'{args.save_name}.pdf')}")
    print(f"HTML have been written to {os.path.join(share_save_dir, f'{args.save_name}.html')}")
