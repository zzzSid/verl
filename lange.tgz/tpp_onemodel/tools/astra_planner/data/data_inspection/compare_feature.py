# -*- coding: utf-8 -*-
# flake8: noqa: D103
# flake8: noqa: D400
# flake8: noqa: N802
# flake8: noqa: F403
# flake8: noqa: F405
import argparse
import csv
import os

import numpy as np
from tqdm import tqdm


def draw_feature_distribution(feature_name_raw, feature_name_new, feature_dir, save_dir):

    feature_path_raw = os.path.join(feature_dir, feature_name_raw + "_feature.npy")
    feature_dict_raw = np.load(feature_path_raw, allow_pickle=True).item()

    feature_path_new = os.path.join(feature_dir, feature_name_new + "_feature.npy")
    feature_dict_new = np.load(feature_path_new, allow_pickle=True).item()

    # # Call the plotting function for egos_pred_gt_transformed
    compare_egos_pred_gt_transformed(feature_dict_raw, feature_dict_new, save_dir)

    compare_navi(feature_dict_raw, feature_dict_new, save_dir)

    compare_lane(feature_dict_raw, feature_dict_new, save_dir)

    compare_bbox(feature_dict_raw, feature_dict_new, save_dir)


def compare_egos_pred_gt_transformed(feature_dict_raw, feature_dict_new, save_dir):
    ego_save_dir = os.path.join(save_dir, "egos")
    os.makedirs(ego_save_dir, exist_ok=True)
    save_dir = ego_save_dir

    total_frames_with_differences = 0
    num_raw_longer = 0
    num_new_longer = 0
    frames_with_differences = []

    # 对速度的统计变量
    total_frames_with_velocity_differences = 0
    num_raw_faster = 0
    num_new_faster = 0
    frames_with_velocity_differences = []

    # 对加速度的统计变量
    total_frames_with_acceleration_differences = 0
    num_raw_more_accelerated = 0
    num_new_more_accelerated = 0
    frames_with_acceleration_differences = []

    # 对当前时刻速度的统计变量
    total_frames_with_current_velocity_differences = 0
    num_current_velocity_new_higher = 0
    num_current_velocity_raw_higher = 0
    frames_with_current_velocity_differences = []

    # 对当前时刻加速度的统计变量
    total_frames_with_current_acceleration_differences = 0
    num_current_acceleration_new_higher = 0
    num_current_acceleration_raw_higher = 0
    frames_with_current_acceleration_differences = []

    for sub_clipid in tqdm(feature_dict_raw):
        if sub_clipid not in feature_dict_new:
            continue  # 如果新数据中没有 sub_clipid，则跳过
        ts_dict_raw = feature_dict_raw[sub_clipid]
        ts_dict_new = feature_dict_new[sub_clipid]
        for timestamp in ts_dict_raw:
            if timestamp not in ts_dict_new:
                continue  # 如果新数据中没有 timestamp，则跳过
            feat_dict_raw = ts_dict_raw[timestamp]
            feat_dict_new = ts_dict_new[timestamp]
            fut_len = feat_dict_raw["ego_acc_pred_gt"].shape[0]
            # 提取特征
            egos_pred_gt_transformed_raw = feat_dict_raw["egos_pred_gt_transformed"][0][:fut_len]  # [35, 2]
            egos_pred_gt_transformed_new = feat_dict_new["egos_pred_gt_transformed"][0][:fut_len]
            egos_pred_mask_transformed_raw = feat_dict_raw["egos_pred_mask_transformed"][0][:fut_len]  # [1,35]
            egos_pred_mask_transformed_new = feat_dict_new["egos_pred_mask_transformed"][0][:fut_len]
            # 速度
            ego_vel_pred_gt_transformed_raw = feat_dict_raw["ego_vel_pred_gt_transformed"][0][:fut_len]  # [35, 2]
            ego_vel_pred_gt_transformed_new = feat_dict_new["ego_vel_pred_gt_transformed"][0][:fut_len]
            # 加速度
            ego_acc_pred_gt_raw = feat_dict_raw["ego_acc_pred_gt"][:fut_len]  # [35, 2]
            ego_acc_pred_gt_new = feat_dict_new["ego_acc_pred_gt"][:fut_len]
            # 获取有效索引
            valid_indices_raw = egos_pred_mask_transformed_raw == 1
            valid_indices_new = egos_pred_mask_transformed_new == 1

            # 计算轨迹长度
            valid_num_raw = valid_indices_raw.sum()
            valid_num_new = valid_indices_new.sum()

            # 定义计算长度的函数
            def calculate_length(points, valid_indices):
                if valid_indices.sum() < 2:  # 有效点少于2个
                    return 0.0
                valid_points = points[valid_indices]
                distances = np.linalg.norm(valid_points[1:] - valid_points[:-1], axis=1)
                return np.sum(distances)

            length_raw = calculate_length(egos_pred_gt_transformed_raw, valid_indices_raw)
            length_new = calculate_length(egos_pred_gt_transformed_new, valid_indices_new)
            # 获取终点
            endpoint_raw = egos_pred_gt_transformed_raw[valid_indices_raw][-1] if length_raw > 0 else None
            endpoint_new = egos_pred_gt_transformed_new[valid_indices_new][-1] if length_new > 0 else None
            # 计算差异
            length_diff = abs(length_raw - length_new)
            if endpoint_raw is not None and endpoint_new is not None:
                endpoint_diff = np.linalg.norm(endpoint_raw - endpoint_new)
            elif endpoint_raw is None and endpoint_new is None:
                endpoint_diff = 0
            else:
                endpoint_diff = None  # 无法计算
            # 记录差异
            if length_diff > 0 or (endpoint_diff is not None and endpoint_diff > 0.01):
                total_frames_with_differences += 1
                if length_raw > length_new:
                    num_raw_longer += 1
                elif length_new > length_raw:
                    num_new_longer += 1
                frames_with_differences.append(
                    {
                        "sub_clipid": sub_clipid,
                        "timestamp": timestamp,
                        "length_raw": length_raw,
                        "length_new": length_new,
                        "valid_num_raw": valid_num_raw,
                        "valid_num_new": valid_num_new,
                        "length_diff": length_diff,
                        "endpoint_diff": endpoint_diff if endpoint_diff is not None else -1,
                        "endpoint_raw": str(endpoint_raw) if endpoint_raw is not None else "None",
                        "endpoint_new": str(endpoint_new) if endpoint_new is not None else "None",
                    }
                )

            # 计算平均速度
            def calculate_mean_speed(velocities, valid_indices):
                if valid_indices.sum() == 0:
                    return 0.0
                valid_velocities = velocities[valid_indices[0]]
                speeds = np.linalg.norm(valid_velocities, axis=1)
                return np.mean(speeds)

            mean_speed_raw = calculate_mean_speed(ego_vel_pred_gt_transformed_raw, valid_indices_raw)
            mean_speed_new = calculate_mean_speed(ego_vel_pred_gt_transformed_new, valid_indices_new)
            speed_diff = abs(mean_speed_raw - mean_speed_new)
            # 获取终点速度
            endpoint_velocity_raw = (
                ego_vel_pred_gt_transformed_raw[valid_indices_raw[0]][-1] if valid_indices_raw.sum() > 0 else None
            )
            endpoint_velocity_new = (
                ego_vel_pred_gt_transformed_new[valid_indices_new[0]][-1] if valid_indices_new.sum() > 0 else None
            )
            # 计算终点速度差异
            if endpoint_velocity_raw is not None and endpoint_velocity_new is not None:
                endpoint_velocity_diff = np.linalg.norm(endpoint_velocity_raw - endpoint_velocity_new)
            elif endpoint_velocity_raw is None and endpoint_velocity_new is None:
                endpoint_velocity_diff = 0
            else:
                endpoint_velocity_diff = None  # 无法计算
            # 记录速度差异
            if speed_diff > 0 or (endpoint_velocity_diff is not None and endpoint_velocity_diff > 0.01):
                total_frames_with_velocity_differences += 1
                if mean_speed_raw > mean_speed_new:
                    num_raw_faster += 1
                elif mean_speed_new > mean_speed_raw:
                    num_new_faster += 1
                frames_with_velocity_differences.append(
                    {
                        "sub_clipid": sub_clipid,
                        "timestamp": timestamp,
                        "mean_speed_raw": mean_speed_raw,
                        "mean_speed_new": mean_speed_new,
                        "speed_diff": speed_diff,
                        "endpoint_velocity_diff": endpoint_velocity_diff if endpoint_velocity_diff is not None else -1,
                        "endpoint_velocity_raw": (
                            str(endpoint_velocity_raw) if endpoint_velocity_raw is not None else "None"
                        ),
                        "endpoint_velocity_new": (
                            str(endpoint_velocity_new) if endpoint_velocity_new is not None else "None"
                        ),
                        "valid_num_raw": valid_num_raw,
                        "valid_num_new": valid_num_new,
                    }
                )

            # 计算平均加速度
            def calculate_mean_acceleration(accelerations, valid_indices):
                if valid_indices.sum() == 0:
                    return 0.0
                valid_accelerations = accelerations[valid_indices[0]]
                accelerations_magnitude = np.linalg.norm(valid_accelerations, axis=1)
                return np.mean(accelerations_magnitude)

            mean_acceleration_raw = calculate_mean_acceleration(ego_acc_pred_gt_raw, valid_indices_raw)
            mean_acceleration_new = calculate_mean_acceleration(ego_acc_pred_gt_new, valid_indices_new)
            acceleration_diff = abs(mean_acceleration_raw - mean_acceleration_new)
            # 获取终点加速度
            endpoint_acceleration_raw = (
                ego_acc_pred_gt_raw[valid_indices_raw[0]][-1] if valid_indices_raw.sum() > 0 else None
            )
            endpoint_acceleration_new = (
                ego_acc_pred_gt_new[valid_indices_new[0]][-1] if valid_indices_new.sum() > 0 else None
            )
            # 计算终点加速度差异
            if endpoint_acceleration_raw is not None and endpoint_acceleration_new is not None:
                endpoint_acceleration_diff = np.linalg.norm(endpoint_acceleration_raw - endpoint_acceleration_new)
            elif endpoint_acceleration_raw is None and endpoint_acceleration_new is None:
                endpoint_acceleration_diff = 0
            else:
                endpoint_acceleration_diff = None  # 无法计算
            # 记录加速度差异
            if acceleration_diff > 0 or (endpoint_acceleration_diff is not None and endpoint_acceleration_diff > 0.01):
                total_frames_with_acceleration_differences += 1
                if mean_acceleration_raw > mean_acceleration_new:
                    num_raw_more_accelerated += 1
                elif mean_acceleration_new > mean_acceleration_raw:
                    num_new_more_accelerated += 1
                frames_with_acceleration_differences.append(
                    {
                        "sub_clipid": sub_clipid,
                        "timestamp": timestamp,
                        "mean_acceleration_raw": mean_acceleration_raw,
                        "mean_acceleration_new": mean_acceleration_new,
                        "acceleration_diff": acceleration_diff,
                        "endpoint_acceleration_diff": (
                            endpoint_acceleration_diff if endpoint_acceleration_diff is not None else -1
                        ),
                        "endpoint_acceleration_raw": (
                            str(endpoint_acceleration_raw) if endpoint_acceleration_raw is not None else "None"
                        ),
                        "endpoint_acceleration_new": (
                            str(endpoint_acceleration_new) if endpoint_acceleration_new is not None else "None"
                        ),
                        "valid_num_raw": valid_num_raw,
                        "valid_num_new": valid_num_new,
                    }
                )

            # 提取当前时刻的 Ego 信息
            egos_raw = feat_dict_raw["egos"]  # [15,1,15]
            egos_new = feat_dict_new["egos"]  # [15,1,15]
            # 获取最后一帧（当前帧）
            current_ego_raw = egos_raw[-1, 0, :]  # [15]
            current_ego_new = egos_new[-1, 0, :]  # [15]
            # 提取速度和加速度
            current_velocity_raw = current_ego_raw[10:12]  # vx, vy
            current_velocity_new = current_ego_new[10:12]
            current_acc_raw = current_ego_raw[12:14]  # acc_x, acc_y
            current_acc_new = current_ego_new[12:14]
            # 计算速度和加速度的模
            current_velocity_magnitude_raw = np.linalg.norm(current_velocity_raw)
            current_velocity_magnitude_new = np.linalg.norm(current_velocity_new)
            current_velocity_diff = abs(current_velocity_magnitude_raw - current_velocity_magnitude_new)
            current_acc_magnitude_raw = np.linalg.norm(current_acc_raw)
            current_acc_magnitude_new = np.linalg.norm(current_acc_new)
            current_acc_diff = abs(current_acc_magnitude_raw - current_acc_magnitude_new)

            # 记录当前速度差异
            if current_velocity_diff > 0:
                total_frames_with_current_velocity_differences += 1
                if current_velocity_magnitude_new > current_velocity_magnitude_raw:
                    num_current_velocity_new_higher += 1
                elif current_velocity_magnitude_raw > current_velocity_magnitude_new:
                    num_current_velocity_raw_higher += 1
                frames_with_current_velocity_differences.append(
                    {
                        "sub_clipid": sub_clipid,
                        "timestamp": timestamp,
                        "current_velocity_diff": current_velocity_diff,
                        "current_velocity_raw": str(current_velocity_raw),
                        "current_velocity_new": str(current_velocity_new),
                    }
                )

            # 记录当前加速度差异
            if current_acc_diff > 0:
                total_frames_with_current_acceleration_differences += 1
                if current_acc_magnitude_new > current_acc_magnitude_raw:
                    num_current_acceleration_new_higher += 1
                elif current_acc_magnitude_raw > current_acc_magnitude_new:
                    num_current_acceleration_raw_higher += 1
                frames_with_current_acceleration_differences.append(
                    {
                        "sub_clipid": sub_clipid,
                        "timestamp": timestamp,
                        "current_acc_diff": current_acc_diff,
                        "current_acc_raw": str(current_acc_raw),
                        "current_acc_new": str(current_acc_new),
                    }
                )

    # 写入 Table 1
    table1_path = os.path.join(save_dir, "ego_table1_statistics.csv")
    with open(table1_path, mode="w", newline="") as csvfile:
        fieldnames = ["Statistic", "Value"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerow({"Statistic": "Total frames with differences", "Value": total_frames_with_differences})
        writer.writerow({"Statistic": "Frames where raw trajectory is longer", "Value": num_raw_longer})
        writer.writerow({"Statistic": "Frames where new trajectory is longer", "Value": num_new_longer})

    # 写入 Table 2
    frames_with_differences_sorted = sorted(
        frames_with_differences,
        key=lambda x: (-x["length_diff"], -x["endpoint_diff"] if x["endpoint_diff"] != -1 else float("-inf")),
    )
    top_10_frames = frames_with_differences_sorted[:10]
    table2_path = os.path.join(save_dir, "ego_table2_top10_differences.csv")
    with open(table2_path, mode="w", newline="") as csvfile:
        fieldnames = [
            "sub_clipid",
            "timestamp",
            "length_diff",
            "length_raw",
            "length_new",
            "valid_num_raw",
            "valid_num_new",
            "endpoint_diff",
            "endpoint_raw",
            "endpoint_new",
        ]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for frame in top_10_frames:
            writer.writerow(
                {
                    "sub_clipid": frame["sub_clipid"],
                    "timestamp": frame["timestamp"],
                    "length_diff": frame["length_diff"],
                    "length_raw": frame["length_raw"],
                    "length_new": frame["length_new"],
                    "valid_num_raw": frame["valid_num_raw"],
                    "valid_num_new": frame["valid_num_new"],
                    "endpoint_diff": frame["endpoint_diff"] if frame["endpoint_diff"] != -1 else "N/A",
                    "endpoint_raw": frame["endpoint_raw"],
                    "endpoint_new": frame["endpoint_new"],
                }
            )

    # 写入 Table 3
    table3_path = os.path.join(save_dir, "ego_table3_velocity_statistics.csv")
    with open(table3_path, mode="w", newline="") as csvfile:
        fieldnames = ["Statistic", "Value"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerow(
            {"Statistic": "Total frames with velocity differences", "Value": total_frames_with_velocity_differences}
        )
        writer.writerow({"Statistic": "Frames where raw mean speed is higher", "Value": num_raw_faster})
        writer.writerow({"Statistic": "Frames where new mean speed is higher", "Value": num_new_faster})

    # 写入 Table 4
    frames_with_velocity_differences_sorted = sorted(
        frames_with_velocity_differences,
        key=lambda x: (
            -x["speed_diff"],
            -x["endpoint_velocity_diff"] if x["endpoint_velocity_diff"] != -1 else float("-inf"),
        ),
    )
    top_10_velocity_frames = frames_with_velocity_differences_sorted[:10]
    table4_path = os.path.join(save_dir, "ego_table4_top10_velocity_differences.csv")
    with open(table4_path, mode="w", newline="") as csvfile:
        fieldnames = [
            "sub_clipid",
            "timestamp",
            "speed_diff",
            "mean_speed_raw",
            "mean_speed_new",
            "endpoint_velocity_diff",
            "endpoint_velocity_raw",
            "endpoint_velocity_new",
            "valid_num_raw",
            "valid_num_new",
        ]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for frame in top_10_velocity_frames:
            writer.writerow(
                {
                    "sub_clipid": frame["sub_clipid"],
                    "timestamp": frame["timestamp"],
                    "speed_diff": frame["speed_diff"],
                    "mean_speed_raw": frame["mean_speed_raw"],
                    "mean_speed_new": frame["mean_speed_new"],
                    "endpoint_velocity_diff": (
                        frame["endpoint_velocity_diff"] if frame["endpoint_velocity_diff"] != -1 else "N/A"
                    ),
                    "endpoint_velocity_raw": frame["endpoint_velocity_raw"],
                    "endpoint_velocity_new": frame["endpoint_velocity_new"],
                    "valid_num_raw": frame["valid_num_raw"],
                    "valid_num_new": frame["valid_num_new"],
                }
            )

    # 写入 Table 5
    table5_path = os.path.join(save_dir, "ego_table5_acceleration_statistics.csv")
    with open(table5_path, mode="w", newline="") as csvfile:
        fieldnames = ["Statistic", "Value"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerow(
            {
                "Statistic": "Total frames with acceleration differences",
                "Value": total_frames_with_acceleration_differences,
            }
        )
        writer.writerow(
            {"Statistic": "Frames where raw mean acceleration is higher", "Value": num_raw_more_accelerated}
        )
        writer.writerow(
            {"Statistic": "Frames where new mean acceleration is higher", "Value": num_new_more_accelerated}
        )

    # 写入 Table 6
    frames_with_acceleration_differences_sorted = sorted(
        frames_with_acceleration_differences,
        key=lambda x: (
            -x["acceleration_diff"],
            -x["endpoint_acceleration_diff"] if x["endpoint_acceleration_diff"] != -1 else float("-inf"),
        ),
    )
    top_10_acceleration_frames = frames_with_acceleration_differences_sorted[:10]
    table6_path = os.path.join(save_dir, "ego_table6_top10_acceleration_differences.csv")
    with open(table6_path, mode="w", newline="") as csvfile:
        fieldnames = [
            "sub_clipid",
            "timestamp",
            "acceleration_diff",
            "mean_acceleration_raw",
            "mean_acceleration_new",
            "endpoint_acceleration_diff",
            "endpoint_acceleration_raw",
            "endpoint_acceleration_new",
            "valid_num_raw",
            "valid_num_new",
        ]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for frame in top_10_acceleration_frames:
            writer.writerow(
                {
                    "sub_clipid": frame["sub_clipid"],
                    "timestamp": frame["timestamp"],
                    "acceleration_diff": frame["acceleration_diff"],
                    "mean_acceleration_raw": frame["mean_acceleration_raw"],
                    "mean_acceleration_new": frame["mean_acceleration_new"],
                    "endpoint_acceleration_diff": (
                        frame["endpoint_acceleration_diff"] if frame["endpoint_acceleration_diff"] != -1 else "N/A"
                    ),
                    "endpoint_acceleration_raw": frame["endpoint_acceleration_raw"],
                    "endpoint_acceleration_new": frame["endpoint_acceleration_new"],
                    "valid_num_raw": frame["valid_num_raw"],
                    "valid_num_new": frame["valid_num_new"],
                }
            )

    # 写入 Table 7
    table7_path = os.path.join(save_dir, "ego_table7_current_velocity_statistics.csv")
    with open(table7_path, mode="w", newline="") as csvfile:
        fieldnames = ["Statistic", "Value"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerow(
            {
                "Statistic": "Total frames with current velocity differences",
                "Value": total_frames_with_current_velocity_differences,
            }
        )
        writer.writerow(
            {"Statistic": "Frames where new current velocity is higher", "Value": num_current_velocity_new_higher}
        )
        writer.writerow(
            {"Statistic": "Frames where raw current velocity is higher", "Value": num_current_velocity_raw_higher}
        )

    # 写入 Table 8
    frames_with_current_velocity_differences_sorted = sorted(
        frames_with_current_velocity_differences,
        key=lambda x: -x["current_velocity_diff"],
    )
    top_10_current_velocity_frames = frames_with_current_velocity_differences_sorted[:10]
    table8_path = os.path.join(save_dir, "ego_table8_top10_current_velocity_differences.csv")
    with open(table8_path, mode="w", newline="") as csvfile:
        fieldnames = [
            "sub_clipid",
            "timestamp",
            "current_velocity_diff",
            "current_velocity_raw",
            "current_velocity_new",
        ]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for frame in top_10_current_velocity_frames:
            writer.writerow(
                {
                    "sub_clipid": frame["sub_clipid"],
                    "timestamp": frame["timestamp"],
                    "current_velocity_diff": frame["current_velocity_diff"],
                    "current_velocity_raw": frame["current_velocity_raw"],
                    "current_velocity_new": frame["current_velocity_new"],
                }
            )

    # 写入 Table 9
    table9_path = os.path.join(save_dir, "ego_table9_current_acceleration_statistics.csv")
    with open(table9_path, mode="w", newline="") as csvfile:
        fieldnames = ["Statistic", "Value"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerow(
            {
                "Statistic": "Total frames with current acceleration differences",
                "Value": total_frames_with_current_acceleration_differences,
            }
        )
        writer.writerow(
            {
                "Statistic": "Frames where new current acceleration is higher",
                "Value": num_current_acceleration_new_higher,
            }
        )
        writer.writerow(
            {
                "Statistic": "Frames where raw current acceleration is higher",
                "Value": num_current_acceleration_raw_higher,
            }
        )

    # 写入 Table 10
    frames_with_current_acceleration_differences_sorted = sorted(
        frames_with_current_acceleration_differences,
        key=lambda x: -x["current_acc_diff"],
    )
    top_10_current_acceleration_frames = frames_with_current_acceleration_differences_sorted[:10]
    table10_path = os.path.join(save_dir, "ego_table10_top10_current_acceleration_differences.csv")
    with open(table10_path, mode="w", newline="") as csvfile:
        fieldnames = [
            "sub_clipid",
            "timestamp",
            "current_acc_diff",
            "current_acc_raw",
            "current_acc_new",
        ]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for frame in top_10_current_acceleration_frames:
            writer.writerow(
                {
                    "sub_clipid": frame["sub_clipid"],
                    "timestamp": frame["timestamp"],
                    "current_acc_diff": frame["current_acc_diff"],
                    "current_acc_raw": frame["current_acc_raw"],
                    "current_acc_new": frame["current_acc_new"],
                }
            )


def compare_navi(feature_dict_raw, feature_dict_new, save_dir):
    navi_save_dir = os.path.join(save_dir, "navilane")
    os.makedirs(navi_save_dir, exist_ok=True)
    save_dir = navi_save_dir

    total_frames_with_differences = 0
    num_raw_more_lines = 0
    num_new_more_lines = 0
    num_frames_raw_longer_lines = 0
    num_frames_new_longer_lines = 0
    frames_with_differences = []

    for sub_clipid in tqdm(feature_dict_raw):
        if sub_clipid not in feature_dict_new:
            continue  # Skip if sub_clipid is not in new data
        ts_dict_raw = feature_dict_raw[sub_clipid]
        ts_dict_new = feature_dict_new[sub_clipid]
        for timestamp in ts_dict_raw:
            if timestamp not in ts_dict_new:
                continue  # Skip if timestamp is not in new data
            feat_dict_raw = ts_dict_raw[timestamp]
            feat_dict_new = ts_dict_new[timestamp]
            # Extract features
            navi_path_points_raw = feat_dict_raw["navi_path_points"]  # [6, 200, 2]
            navi_path_points_new = feat_dict_new["navi_path_points"]
            navi_path_types_raw = feat_dict_raw["navi_path_types"]  # [6, 200]
            navi_path_types_new = feat_dict_new["navi_path_types"]

            # Determine valid navilane lines (lines with at least one valid point)
            valid_lines_raw = []
            valid_lines_new = []
            lengths_raw = []
            lengths_new = []

            for i in range(1):  # Iterate over 6 navilane lines
                types_raw = navi_path_types_raw[i]  # [200]
                types_new = navi_path_types_new[i]
                points_raw = navi_path_points_raw[i]  # [200, 2]
                points_new = navi_path_points_new[i]

                valid_indices_raw = np.where(types_raw != -1)[0]
                valid_indices_new = np.where(types_new != -1)[0]

                if len(valid_indices_raw) > 0:
                    valid_lines_raw.append(i)
                    # Get valid points
                    valid_points_raw = points_raw[valid_indices_raw]  # [N, 2]
                    # Compute distances between consecutive points
                    diffs_raw = np.diff(valid_points_raw, axis=0)
                    dists_raw = np.linalg.norm(diffs_raw, axis=1)
                    length_raw = np.sum(dists_raw)
                    lengths_raw.append(length_raw)
                else:
                    lengths_raw.append(0)

                if len(valid_indices_new) > 0:
                    valid_lines_new.append(i)
                    # Get valid points
                    valid_points_new = points_new[valid_indices_new]  # [N, 2]
                    # Compute distances between consecutive points
                    diffs_new = np.diff(valid_points_new, axis=0)
                    dists_new = np.linalg.norm(diffs_new, axis=1)
                    length_new = np.sum(dists_new)
                    lengths_new.append(length_new)
                else:
                    lengths_new.append(0)

            num_valid_lines_raw = len(valid_lines_raw)
            num_valid_lines_new = len(valid_lines_new)

            # Compare the number of valid navilane lines
            line_count_diff = abs(num_valid_lines_raw - num_valid_lines_new)

            # Find max length of valid lines
            max_len_raw = max(lengths_raw) if lengths_raw else 0
            max_len_new = max(lengths_new) if lengths_new else 0
            max_length_diff = abs(max_len_raw - max_len_new)

            # Compare max lengths
            if max_len_raw > max_len_new:
                num_frames_raw_longer_lines += 1
            elif max_len_new > max_len_raw:
                num_frames_new_longer_lines += 1

            # Record differences if any
            if line_count_diff > 0 or max_length_diff > 0:
                total_frames_with_differences += 1
                if num_valid_lines_raw > num_valid_lines_new:
                    num_raw_more_lines += 1
                elif num_valid_lines_new > num_valid_lines_raw:
                    num_new_more_lines += 1
                frames_with_differences.append(
                    {
                        "sub_clipid": sub_clipid,
                        "timestamp": timestamp,
                        "count_diff": line_count_diff,
                        "count_raw": num_valid_lines_raw,
                        "count_new": num_valid_lines_new,
                        "max_length_diff": max_length_diff,
                        "max_len_raw": max_len_raw,
                        "max_len_new": max_len_new,
                    }
                )

    # Write Table 1
    table1_path = os.path.join(save_dir, "navi_table1_statistics.csv")
    with open(table1_path, mode="w", newline="") as csvfile:
        fieldnames = ["Statistic", "Value"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerow({"Statistic": "Total frames with differences", "Value": total_frames_with_differences})
        writer.writerow({"Statistic": "Frames where raw has more navilane lines", "Value": num_raw_more_lines})
        writer.writerow({"Statistic": "Frames where new has more navilane lines", "Value": num_new_more_lines})
        writer.writerow(
            {"Statistic": "Frames where raw has longer navilane lines", "Value": num_frames_raw_longer_lines}
        )
        writer.writerow(
            {"Statistic": "Frames where new has longer navilane lines", "Value": num_frames_new_longer_lines}
        )

    # Write Table 2
    frames_with_differences_sorted = sorted(
        frames_with_differences, key=lambda x: (-x["count_diff"], -x["max_length_diff"])
    )
    top_10_frames = frames_with_differences_sorted[:20]
    table2_path = os.path.join(save_dir, "navi_table2_top10_differences.csv")
    with open(table2_path, mode="w", newline="") as csvfile:
        fieldnames = [
            "sub_clipid",
            "timestamp",
            "count_diff",
            "count_raw",
            "count_new",
            "max_length_diff",
            "max_len_raw",
            "max_len_new",
        ]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for frame in top_10_frames:
            writer.writerow(frame)


def compare_lane(feature_dict_raw, feature_dict_new, save_dir):
    lane_save_dir = os.path.join(save_dir, "lane")
    os.makedirs(lane_save_dir, exist_ok=True)
    save_dir = lane_save_dir

    total_frames_with_differences = 0
    num_raw_more_lines = 0
    num_new_more_lines = 0
    num_frames_raw_longer_lines = 0
    num_frames_new_longer_lines = 0
    frames_with_differences = []

    for sub_clipid in tqdm(feature_dict_raw):
        if sub_clipid not in feature_dict_new:
            continue  # Skip if sub_clipid is not in new data
        ts_dict_raw = feature_dict_raw[sub_clipid]
        ts_dict_new = feature_dict_new[sub_clipid]
        for timestamp in ts_dict_raw:
            if timestamp not in ts_dict_new:
                continue  # Skip if timestamp is not in new data
            feat_dict_raw = ts_dict_raw[timestamp]
            feat_dict_new = ts_dict_new[timestamp]
            # Extract features
            lane_points_raw = feat_dict_raw["lane_points"]  # [50, 30, 2]
            lane_points_new = feat_dict_new["lane_points"]
            lane_types_raw = feat_dict_raw["lane_types"]  # [50, 30]
            lane_types_new = feat_dict_new["lane_types"]

            # Determine valid lanes (lanes with at least one valid point)
            valid_lanes_raw = []
            valid_lanes_new = []
            lengths_raw = []
            lengths_new = []

            for i in range(50):  # Iterate over 50 lanes
                types_raw = lane_types_raw[i]  # [30]
                types_new = lane_types_new[i]
                points_raw = lane_points_raw[i]  # [30, 2]
                points_new = lane_points_new[i]

                valid_indices_raw = np.where(types_raw != -1)[0]
                valid_indices_new = np.where(types_new != -1)[0]

                if len(valid_indices_raw) > 0:
                    valid_lanes_raw.append(i)
                    # Get valid points
                    valid_points_raw = points_raw[valid_indices_raw]  # [N, 2]
                    # Compute distances between consecutive points
                    diffs_raw = np.diff(valid_points_raw, axis=0)
                    dists_raw = np.linalg.norm(diffs_raw, axis=1)
                    length_raw = np.sum(dists_raw)
                    lengths_raw.append(length_raw)
                else:
                    lengths_raw.append(0)

                if len(valid_indices_new) > 0:
                    valid_lanes_new.append(i)
                    # Get valid points
                    valid_points_new = points_new[valid_indices_new]  # [N, 2]
                    # Compute distances between consecutive points
                    diffs_new = np.diff(valid_points_new, axis=0)
                    dists_new = np.linalg.norm(diffs_new, axis=1)
                    length_new = np.sum(dists_new)
                    lengths_new.append(length_new)
                else:
                    lengths_new.append(0)

            num_valid_lanes_raw = len(valid_lanes_raw)
            num_valid_lanes_new = len(valid_lanes_new)

            # Compare the number of valid lanes
            line_count_diff = abs(num_valid_lanes_raw - num_valid_lanes_new)

            # Find max length of valid lines
            max_len_raw = max(lengths_raw) if lengths_raw else 0
            max_len_new = max(lengths_new) if lengths_new else 0
            max_length_diff = abs(max_len_raw - max_len_new)

            # Compare max lengths
            if max_len_raw > max_len_new:
                num_frames_raw_longer_lines += 1
            elif max_len_new > max_len_raw:
                num_frames_new_longer_lines += 1

            # Record differences if any
            if line_count_diff > 0 or max_length_diff > 0:
                total_frames_with_differences += 1
                if num_valid_lanes_raw > num_valid_lanes_new:
                    num_raw_more_lines += 1
                elif num_valid_lanes_new > num_valid_lanes_raw:
                    num_new_more_lines += 1
                frames_with_differences.append(
                    {
                        "sub_clipid": sub_clipid,
                        "timestamp": timestamp,
                        "count_diff": line_count_diff,
                        "count_raw": num_valid_lanes_raw,
                        "count_new": num_valid_lanes_new,
                        "max_length_diff": max_length_diff,
                        "max_len_raw": max_len_raw,
                        "max_len_new": max_len_new,
                    }
                )

    # Write Table 1
    table1_path = os.path.join(save_dir, "lane_table1_statistics.csv")
    with open(table1_path, mode="w", newline="") as csvfile:
        fieldnames = ["Statistic", "Value"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerow({"Statistic": "Total frames with differences", "Value": total_frames_with_differences})
        writer.writerow({"Statistic": "Frames where raw has more lanes", "Value": num_raw_more_lines})
        writer.writerow({"Statistic": "Frames where new has more lanes", "Value": num_new_more_lines})
        writer.writerow({"Statistic": "Frames where raw has longer lanes", "Value": num_frames_raw_longer_lines})
        writer.writerow({"Statistic": "Frames where new has longer lanes", "Value": num_frames_new_longer_lines})

    # Write Table 2
    frames_with_differences_sorted = sorted(
        frames_with_differences, key=lambda x: (-x["count_diff"], -x["max_length_diff"])
    )
    top_20_frames = frames_with_differences_sorted[:10]
    table2_path = os.path.join(save_dir, "lane_table2_top10_differences.csv")
    with open(table2_path, mode="w", newline="") as csvfile:
        fieldnames = [
            "sub_clipid",
            "timestamp",
            "count_diff",
            "count_raw",
            "count_new",
            "max_length_diff",
            "max_len_raw",
            "max_len_new",
        ]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for frame in top_20_frames:
            writer.writerow(frame)


def compare_bbox(feature_dict_raw, feature_dict_new, save_dir):
    bbox_save_dir = os.path.join(save_dir, "bbox")
    os.makedirs(bbox_save_dir, exist_ok=True)
    save_dir = bbox_save_dir

    total_frames = 0
    frames_both_found = 0
    frames_only_raw_found = 0
    frames_only_new_found = 0
    frames_both_found_but_position_diff_large = 0

    raw_speed_higher_count = 0
    new_speed_higher_count = 0
    raw_accel_magnitude_higher_count = 0
    new_accel_magnitude_higher_count = 0

    # 新增计数器：统计零非零情况
    raw_speed_zero_new_nonzero_count = 0
    raw_speed_nonzero_new_zero_count = 0
    raw_accel_zero_new_nonzero_count = 0
    raw_accel_nonzero_new_zero_count = 0

    frames_with_speed_differences = []
    frames_with_accel_differences = []
    frames_with_large_position_diff = []  # For Table 7

    frames_only_raw_found_list = []  # For Table 5
    frames_only_new_found_list = []  # For Table 6

    for sub_clipid in tqdm(feature_dict_raw):
        if sub_clipid not in feature_dict_new:
            continue  # Skip if sub_clipid is not in new data
        ts_dict_raw = feature_dict_raw[sub_clipid]
        ts_dict_new = feature_dict_new[sub_clipid]
        for timestamp in ts_dict_raw:
            if timestamp not in ts_dict_new:
                continue  # Skip if timestamp is not in new data
            feat_dict_raw = ts_dict_raw[timestamp]
            feat_dict_new = ts_dict_new[timestamp]

            # Extract features
            ego_raw = feat_dict_raw["egos"]  # [15,1,15]
            ego_new = feat_dict_new["egos"]
            bboxes_raw = feat_dict_raw["bboxes"]  # [15,191,40]
            bboxes_new = feat_dict_new["bboxes"]
            bboxes_padding_mask_raw = feat_dict_raw["bboxes_padding_mask"]  # [15,191]
            bboxes_padding_mask_new = feat_dict_new["bboxes_padding_mask"]

            # Use last frame
            ego_raw_last = ego_raw[-1, 0, :]  # [15]
            ego_new_last = ego_new[-1, 0, :]

            bboxes_raw_last = bboxes_raw[-1, :, :]  # [191,40]
            bboxes_new_last = bboxes_new[-1, :, :]

            bboxes_padding_mask_raw_last = bboxes_padding_mask_raw[-1, :]  # [191]
            bboxes_padding_mask_new_last = bboxes_padding_mask_new[-1, :]

            # Filter valid bboxes
            valid_indices_raw = np.where(bboxes_padding_mask_raw_last == 0)[0]
            valid_bboxes_raw = bboxes_raw_last[valid_indices_raw, :]  # [N_raw,40]

            valid_indices_new = np.where(bboxes_padding_mask_new_last == 0)[0]
            valid_bboxes_new = bboxes_new_last[valid_indices_new, :]  # [N_new,40]

            # Find first front vehicle
            front_vehicle_raw = find_front_vehicle(ego_raw_last, valid_bboxes_raw)
            front_vehicle_new = find_front_vehicle(ego_new_last, valid_bboxes_new)

            num_front_vehicles_raw = 1 if front_vehicle_raw else 0
            num_front_vehicles_new = 1 if front_vehicle_new else 0

            total_frames += 1

            if front_vehicle_raw is not None and front_vehicle_new is not None:
                # Both found a front vehicle
                # Check position difference
                position_diff = np.linalg.norm(front_vehicle_raw["position"] - front_vehicle_new["position"])
                if position_diff <= 0.5:
                    # Common first front vehicle
                    frames_both_found += 1

                    # Compare velocities and accelerations
                    speed_raw = np.linalg.norm(front_vehicle_raw["velocity"])
                    speed_new = np.linalg.norm(front_vehicle_new["velocity"])
                    speed_diff = abs(speed_raw - speed_new)
                    accel_raw_magnitude = np.linalg.norm(front_vehicle_raw["acceleration"])
                    accel_new_magnitude = np.linalg.norm(front_vehicle_new["acceleration"])
                    accel_diff = abs(accel_raw_magnitude - accel_new_magnitude)

                    # 更新速度和加速度零非零计数
                    # 速度判断
                    if speed_raw == 0 and speed_new != 0:
                        raw_speed_zero_new_nonzero_count += 1
                    if speed_raw != 0 and speed_new == 0:
                        raw_speed_nonzero_new_zero_count += 1

                    # 加速度判断
                    if accel_raw_magnitude == 0 and accel_new_magnitude != 0:
                        raw_accel_zero_new_nonzero_count += 1
                    if accel_raw_magnitude != 0 and accel_new_magnitude == 0:
                        raw_accel_nonzero_new_zero_count += 1

                    # Update counts
                    if speed_raw > speed_new:
                        raw_speed_higher_count += 1
                    elif speed_new > speed_raw:
                        new_speed_higher_count += 1

                    if accel_raw_magnitude > accel_new_magnitude:
                        raw_accel_magnitude_higher_count += 1
                    elif accel_new_magnitude > accel_raw_magnitude:
                        new_accel_magnitude_higher_count += 1

                    # Collect data for CSVs
                    frames_with_speed_differences.append(
                        {
                            "sub_clipid": sub_clipid,
                            "timestamp": timestamp,
                            "speed_diff": speed_diff,
                            "raw_position": front_vehicle_raw["position"],
                            "raw_velocity": front_vehicle_raw["velocity"],
                            "raw_acceleration": front_vehicle_raw["acceleration"],
                            "new_position": front_vehicle_new["position"],
                            "new_velocity": front_vehicle_new["velocity"],
                            "new_acceleration": front_vehicle_new["acceleration"],
                        }
                    )

                    frames_with_accel_differences.append(
                        {
                            "sub_clipid": sub_clipid,
                            "timestamp": timestamp,
                            "accel_diff": accel_diff,
                            "raw_position": front_vehicle_raw["position"],
                            "raw_velocity": front_vehicle_raw["velocity"],
                            "raw_acceleration": front_vehicle_raw["acceleration"],
                            "new_position": front_vehicle_new["position"],
                            "new_velocity": front_vehicle_new["velocity"],
                            "new_acceleration": front_vehicle_new["acceleration"],
                        }
                    )

                else:
                    # Position difference > 0.5m
                    frames_both_found_but_position_diff_large += 1

                    # Collect data for Table 7
                    frames_with_large_position_diff.append(
                        {
                            "sub_clipid": sub_clipid,
                            "timestamp": timestamp,
                            "position_diff": position_diff,
                            "raw_position": front_vehicle_raw["position"],
                            "raw_velocity": front_vehicle_raw["velocity"],
                            "raw_acceleration": front_vehicle_raw["acceleration"],
                            "new_position": front_vehicle_new["position"],
                            "new_velocity": front_vehicle_new["velocity"],
                            "new_acceleration": front_vehicle_new["acceleration"],
                        }
                    )
            elif front_vehicle_raw is not None and front_vehicle_new is None:
                # Only raw found front vehicle
                frames_only_raw_found += 1
                frames_only_raw_found_list.append(
                    {
                        "sub_clipid": sub_clipid,
                        "timestamp": timestamp,
                        "num_front_vehicles_raw": num_front_vehicles_raw,
                        "num_front_vehicles_new": num_front_vehicles_new,
                    }
                )
            elif front_vehicle_raw is None and front_vehicle_new is not None:
                # Only new found front vehicle
                frames_only_new_found += 1
                frames_only_new_found_list.append(
                    {
                        "sub_clipid": sub_clipid,
                        "timestamp": timestamp,
                        "num_front_vehicles_raw": num_front_vehicles_raw,
                        "num_front_vehicles_new": num_front_vehicles_new,
                    }
                )
            else:
                # Neither found front vehicle
                pass

    # Generate first CSV
    csv1_path = os.path.join(save_dir, "bbox_first_front_vehicle_statistics.csv")
    with open(csv1_path, mode="w", newline="") as csvfile:
        fieldnames = ["Statistic", "Value"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerow({"Statistic": "Total frames", "Value": total_frames})
        writer.writerow({"Statistic": "Frames with common first front vehicle", "Value": frames_both_found})
        writer.writerow({"Statistic": "Frames where only raw found front vehicle", "Value": frames_only_raw_found})
        writer.writerow({"Statistic": "Frames where only new found front vehicle", "Value": frames_only_new_found})
        writer.writerow(
            {
                "Statistic": "Frames where both found front vehicle but position difference > 0.5m",
                "Value": frames_both_found_but_position_diff_large,
            }
        )

    # Generate second CSV
    csv2_path = os.path.join(save_dir, "bbox_speed_acceleration_statistics.csv")
    with open(csv2_path, mode="w", newline="") as csvfile:
        fieldnames = ["Statistic", "Value"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerow({"Statistic": "Frames where raw speed higher than new", "Value": raw_speed_higher_count})
        writer.writerow({"Statistic": "Frames where new speed higher than raw", "Value": new_speed_higher_count})
        writer.writerow(
            {
                "Statistic": "Frames where raw acceleration magnitude higher than new",
                "Value": raw_accel_magnitude_higher_count,
            }
        )
        writer.writerow(
            {
                "Statistic": "Frames where new acceleration magnitude higher than raw",
                "Value": new_accel_magnitude_higher_count,
            }
        )

    # 增加新的CSV输出（零非零统计）
    csv8_path = os.path.join(save_dir, "bbox_zero_nonzero_speed_accel_statistics.csv")
    with open(csv8_path, mode="w", newline="") as csvfile:
        fieldnames = ["Statistic", "Value", "Ratio"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        # 确保 total_frames 不为 0，以避免除 0 错误
        if total_frames > 0:
            writer.writerow(
                {
                    "Statistic": "Raw speed=0, New speed≠0 frames",
                    "Value": raw_speed_zero_new_nonzero_count,
                    "Ratio": raw_speed_zero_new_nonzero_count / total_frames,
                }
            )
            writer.writerow(
                {
                    "Statistic": "Raw speed≠0, New speed=0 frames",
                    "Value": raw_speed_nonzero_new_zero_count,
                    "Ratio": raw_speed_nonzero_new_zero_count / total_frames,
                }
            )
            writer.writerow(
                {
                    "Statistic": "Raw accel=0, New accel≠0 frames",
                    "Value": raw_accel_zero_new_nonzero_count,
                    "Ratio": raw_accel_zero_new_nonzero_count / total_frames,
                }
            )
            writer.writerow(
                {
                    "Statistic": "Raw accel≠0, New accel=0 frames",
                    "Value": raw_accel_nonzero_new_zero_count,
                    "Ratio": raw_accel_nonzero_new_zero_count / total_frames,
                }
            )
        else:
            # 若 total_frames = 0，此时无法计算比例，直接输出 0
            writer.writerow(
                {"Statistic": "Raw speed=0, New speed≠0 frames", "Value": raw_speed_zero_new_nonzero_count, "Ratio": 0}
            )
            writer.writerow(
                {"Statistic": "Raw speed≠0, New speed=0 frames", "Value": raw_speed_nonzero_new_zero_count, "Ratio": 0}
            )
            writer.writerow(
                {"Statistic": "Raw accel=0, New accel≠0 frames", "Value": raw_accel_zero_new_nonzero_count, "Ratio": 0}
            )
            writer.writerow(
                {"Statistic": "Raw accel≠0, New accel=0 frames", "Value": raw_accel_nonzero_new_zero_count, "Ratio": 0}
            )

    # Generate third CSV (top 10 speed differences)
    frames_with_speed_differences_sorted = sorted(frames_with_speed_differences, key=lambda x: -x["speed_diff"])
    top_10_speed_differences = frames_with_speed_differences_sorted[:10]

    csv3_path = os.path.join(save_dir, "bbox_top10_speed_differences.csv")
    with open(csv3_path, mode="w", newline="") as csvfile:
        fieldnames = [
            "sub_clipid",
            "timestamp",
            "speed_diff",
            "raw_position_x",
            "raw_position_y",
            "raw_velocity_vx",
            "raw_velocity_vy",
            "raw_acceleration_ax",
            "raw_acceleration_ay",
            "new_position_x",
            "new_position_y",
            "new_velocity_vx",
            "new_velocity_vy",
            "new_acceleration_ax",
            "new_acceleration_ay",
        ]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for frame in top_10_speed_differences:
            writer.writerow(
                {
                    "sub_clipid": frame["sub_clipid"],
                    "timestamp": frame["timestamp"],
                    "speed_diff": frame["speed_diff"],
                    "raw_position_x": frame["raw_position"][0],
                    "raw_position_y": frame["raw_position"][1],
                    "raw_velocity_vx": frame["raw_velocity"][0],
                    "raw_velocity_vy": frame["raw_velocity"][1],
                    "raw_acceleration_ax": frame["raw_acceleration"][0],
                    "raw_acceleration_ay": frame["raw_acceleration"][1],
                    "new_position_x": frame["new_position"][0],
                    "new_position_y": frame["new_position"][1],
                    "new_velocity_vx": frame["new_velocity"][0],
                    "new_velocity_vy": frame["new_velocity"][1],
                    "new_acceleration_ax": frame["new_acceleration"][0],
                    "new_acceleration_ay": frame["new_acceleration"][1],
                }
            )

    # Generate fourth CSV (top 10 acceleration differences)
    frames_with_accel_differences_sorted = sorted(frames_with_accel_differences, key=lambda x: -x["accel_diff"])
    top_10_accel_differences = frames_with_accel_differences_sorted[:10]

    csv4_path = os.path.join(save_dir, "bbox_top10_acceleration_differences.csv")
    with open(csv4_path, mode="w", newline="") as csvfile:
        fieldnames = [
            "sub_clipid",
            "timestamp",
            "accel_diff",
            "raw_position_x",
            "raw_position_y",
            "raw_velocity_vx",
            "raw_velocity_vy",
            "raw_acceleration_ax",
            "raw_acceleration_ay",
            "new_position_x",
            "new_position_y",
            "new_velocity_vx",
            "new_velocity_vy",
            "new_acceleration_ax",
            "new_acceleration_ay",
        ]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for frame in top_10_accel_differences:
            writer.writerow(
                {
                    "sub_clipid": frame["sub_clipid"],
                    "timestamp": frame["timestamp"],
                    "accel_diff": frame["accel_diff"],
                    "raw_position_x": frame["raw_position"][0],
                    "raw_position_y": frame["raw_position"][1],
                    "raw_velocity_vx": frame["raw_velocity"][0],
                    "raw_velocity_vy": frame["raw_velocity"][1],
                    "raw_acceleration_ax": frame["raw_acceleration"][0],
                    "raw_acceleration_ay": frame["raw_acceleration"][1],
                    "new_position_x": frame["new_position"][0],
                    "new_position_y": frame["new_position"][1],
                    "new_velocity_vx": frame["new_velocity"][0],
                    "new_velocity_vy": frame["new_velocity"][1],
                    "new_acceleration_ax": frame["new_acceleration"][0],
                    "new_acceleration_ay": frame["new_acceleration"][1],
                }
            )

    # Generate fifth CSV (Table 5)
    csv5_path = os.path.join(save_dir, "bbox_old_has_front_new_not.csv")
    table5_entries = frames_only_raw_found_list[:10]
    with open(csv5_path, mode="w", newline="") as csvfile:
        fieldnames = ["sub_clipid", "timestamp", "num_front_vehicles_raw", "num_front_vehicles_new"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for entry in table5_entries:
            writer.writerow(entry)

    # Generate sixth CSV (Table 6)
    csv6_path = os.path.join(save_dir, "bbox_new_has_front_old_not.csv")
    table6_entries = frames_only_new_found_list[:10]
    with open(csv6_path, mode="w", newline="") as csvfile:
        fieldnames = ["sub_clipid", "timestamp", "num_front_vehicles_raw", "num_front_vehicles_new"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for entry in table6_entries:
            writer.writerow(entry)

    # Generate seventh CSV (Table 7)
    frames_with_large_position_diff_sorted = sorted(frames_with_large_position_diff, key=lambda x: -x["position_diff"])
    top_10_position_differences = frames_with_large_position_diff_sorted[:10]

    csv7_path = os.path.join(save_dir, "bbox_top10_position_differences.csv")
    with open(csv7_path, mode="w", newline="") as csvfile:
        fieldnames = [
            "sub_clipid",
            "timestamp",
            "position_diff",
            "raw_position_x",
            "raw_position_y",
            "raw_velocity_vx",
            "raw_velocity_vy",
            "raw_acceleration_ax",
            "raw_acceleration_ay",
            "new_position_x",
            "new_position_y",
            "new_velocity_vx",
            "new_velocity_vy",
            "new_acceleration_ax",
            "new_acceleration_ay",
        ]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for frame in top_10_position_differences:
            writer.writerow(
                {
                    "sub_clipid": frame["sub_clipid"],
                    "timestamp": frame["timestamp"],
                    "position_diff": frame["position_diff"],
                    "raw_position_x": frame["raw_position"][0],
                    "raw_position_y": frame["raw_position"][1],
                    "raw_velocity_vx": frame["raw_velocity"][0],
                    "raw_velocity_vy": frame["raw_velocity"][1],
                    "raw_acceleration_ax": frame["raw_acceleration"][0],
                    "raw_acceleration_ay": frame["raw_acceleration"][1],
                    "new_position_x": frame["new_position"][0],
                    "new_position_y": frame["new_position"][1],
                    "new_velocity_vx": frame["new_velocity"][0],
                    "new_velocity_vy": frame["new_velocity"][1],
                    "new_acceleration_ax": frame["new_acceleration"][0],
                    "new_acceleration_ay": frame["new_acceleration"][1],
                }
            )


def find_front_vehicle(ego, valid_bboxes):
    """
    Find the first front vehicle for the given ego and valid bboxes.

    Parameters:
    - ego: array of shape [15], ego's features
    - valid_bboxes: array of shape [N,40], valid bounding boxes

    Returns:
    - dict with keys 'position', 'velocity', 'acceleration' if a front vehicle is found
    - None if no front vehicle is found
    """
    if valid_bboxes.shape[0] == 0:
        return None  # No valid bboxes

    ego_x = ego[0]
    ego_y = ego[1]
    ego_yaw = ego[6]  # Assuming this is in radians

    bbox_x = valid_bboxes[:, 0]
    bbox_y = valid_bboxes[:, 1]

    delta_x = bbox_x - ego_x
    delta_y = bbox_y - ego_y

    cos_yaw = np.cos(-ego_yaw)
    sin_yaw = np.sin(-ego_yaw)

    delta_x_prime = delta_x * cos_yaw - delta_y * sin_yaw  # Longitudinal distance
    delta_y_prime = delta_x * sin_yaw + delta_y * cos_yaw  # Lateral distance

    # Select indices where conditions are met
    selected_indices = np.where((delta_x_prime > 0) & (delta_x_prime <= 50) & (np.abs(delta_y_prime) <= 2))[0]

    if len(selected_indices) == 0:
        return None  # No front vehicle found

    # Find the one closest to ego (smallest delta_x_prime)
    min_index = selected_indices[np.argmin(delta_x_prime[selected_indices])]

    front_vehicle = {
        "position": valid_bboxes[min_index, 0:2],  # x, y
        "velocity": valid_bboxes[min_index, 10:12],  # vx, vy
        "acceleration": valid_bboxes[min_index, 13:15],  # ax, ay (indices 13 and 14)
    }

    return front_vehicle


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--result_dir", type=str, required=False, default="./data_compare/")
    # parser.add_argument("--feature_name", type=str, required=False, default="raw_common_sample")
    parser.add_argument("--feature_name_raw", type=str, required=False, default="raw_common_sample")
    parser.add_argument("--feature_name_new", type=str, required=False, default="new_common_sample")
    args = parser.parse_args()
    feature_dir = args.result_dir
    save_dir = os.path.join(feature_dir, "frame_feature_comparsion")
    os.makedirs(save_dir, exist_ok=True)

    draw_feature_distribution(args.feature_name_raw, args.feature_name_new, feature_dir, save_dir)
