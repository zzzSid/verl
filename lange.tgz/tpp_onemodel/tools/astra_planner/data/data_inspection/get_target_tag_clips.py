# -*- coding: utf-8 -*-
# flake8: noqa: F403
# flake8: noqa: F405
# type: ignore
import argparse

from tpp_onemodel.tools.astra_planner.data.data_inspection.tags_utils import *
from tpp_onemodel.tools.astra_planner.data.txt_to_pkl_utils import pkl_to_txt


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process some parameters.")
    parser.add_argument(
        "--tag_version_raw", default="planner-data-v1207-training-4", type=str, help="The version name of tag"
    )
    parser.add_argument(
        "--save_dir",
        default="./tag_export",
        type=str,
        help="The saving path",
    )
    parser.add_argument(
        # both pkl and txt files are supported
        "--input_dataset_path_raw",
        # default="/home/mccree.zhao/project/offline/2024/melange_all/2024_12/melange_new_1217/test_data.txt",
        # default="/share-global/xiangwei.geng/planner/planner_data/1127/planner_dataset_v1106_align_v0918_100ms_cicd_100_11743.pkl",
        default="/share-global/wei.wang22/data/planner/1207/"
        "planner_dataset_v1207_with_tag_v1213_495003_56938582.pkl",
        type=str,
        help="The raw dataset clip list path",
    )
    parser.add_argument(
        "--dict_name",
        default="test_data_1207",
        type=str,
        help="The raw dict name",
    )
    parser.add_argument(
        "--target_tag_list",
        # if set to [], export all tags
        default=["astra_planner.data_cleaning.md_bad_behavior.BelowSpeed_ReasonNone"],
        type=list,
        help="The target tag list",
    )
    parser.add_argument(
        "--tags_to_clip_id_dict_raw_path",
        # default="./tag_export/target_tag/tags_to_clip_id_dict_planner-data-v1207-training-4_test_data_1207.pkl",
        default="",
        type=str,
        help="Tag_to_clip dict",
    )

    args = parser.parse_args()
    target_tag_list = args.target_tag_list
    save_dir = os.path.join(args.save_dir, "target_tag")
    os.makedirs(save_dir, exist_ok=True)
    input_dataset_path_raw = args.input_dataset_path_raw
    target_tag_version = args.tag_version_raw

    if args.tags_to_clip_id_dict_raw_path == "":
        if os.path.splitext(input_dataset_path_raw)[1] == ".pkl":
            input_dataset_path_raw, tag_version = pkl_to_txt(
                input_dataset_path_raw, txt_save_path="./tmp_data/export_data", target_dataset_name=args.dict_name
            )
            target_tag_version = tag_version

        clip_id_to_tags_dict_raw, tags_to_clip_id_dict_raw = export_single_scene_dataset(
            input_dataset_path_raw, save_dir, target_tag_version, args.dict_name
        )
    else:
        tags_to_clip_id_dict_raw = pkl.load(open(args.tags_to_clip_id_dict_raw_path, "rb"))

    if len(target_tag_list) == 0:
        target_tag_list = list(tags_to_clip_id_dict_raw.keys())  # export all tags
    for target_tag in target_tag_list:
        if target_tag not in tags_to_clip_id_dict_raw:
            continue
        target_clip_paths = tags_to_clip_id_dict_raw[target_tag]
        save_file_path = os.path.join(save_dir, f"{target_tag}_clip_paths.txt")
        with open(save_file_path, "w") as f:
            for clip_path in target_clip_paths:
                f.write(f"{clip_path}\n")
        print(f"Exported {target_tag} clip paths to {save_file_path}")

    # plot_tag_clip_distribution_with_csv_and_labels(
    #     tags_to_clip_id_dict_raw,
    #     os.path.join(save_dir, "tag_raw_distribution.png"),
    #     os.path.join(save_dir, "tag_raw_distribution.csv"),
    # )
