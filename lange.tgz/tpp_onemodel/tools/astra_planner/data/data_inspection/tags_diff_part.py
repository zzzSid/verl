# -*- coding: utf-8 -*-
# flake8: noqa: F403
# flake8: noqa: F405
# type: ignore
import argparse

from tpp_onemodel.tools.astra_planner.data.data_inspection.tags_utils import *


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process some parameters.")
    parser.add_argument(
        "--tag_version_addition", default="prod_v202411061500_all_tags", type=str, help="The version name of tag"
    )
    parser.add_argument(
        "--tag_version_missing", default="prod_yx_20240919_tags_only_all", type=str, help="The version name of tag"
    )
    parser.add_argument(
        "--save_dir",
        default="./data_compare",
        type=str,
        help="The saving path",
    )
    parser.add_argument(
        "--input_dataset_path_addition",
        default="/home/mccree.zhao/project/offline/2024/melange_all/2024_10/2024_11/melange_1121_data/data_compare/new_unique.txt",
        type=str,
        help="The addition dataset clip list path",
    )
    parser.add_argument(
        "--input_dataset_path_missing",
        default="/home/mccree.zhao/project/offline/2024/melange_all/2024_10/2024_11/melange_1121_data/data_compare/raw_unique.txt",
        type=str,
        help="The missing dataset clip list path",
    )

    args = parser.parse_args()
    save_dir = args.save_dir
    os.makedirs(save_dir, exist_ok=True)
    input_dataset_path_addition = args.input_dataset_path_addition
    input_dataset_path_missing = args.input_dataset_path_missing

    clip_id_to_tags_dict_addition, tags_to_clip_id_dict_addition = export_single_scene_dataset(
        input_dataset_path_addition, save_dir, args.tag_version_addition, "addition"
    )

    clip_id_to_tags_dict_missing, tags_to_clip_id_dict_missing = export_single_scene_dataset(
        input_dataset_path_missing, save_dir, args.tag_version_missing, "missing"
    )

    plot_tag_clip_distribution_with_csv_and_labels(
        tags_to_clip_id_dict_addition,
        os.path.join(save_dir, "addition_tag_distribution.png"),
        os.path.join(save_dir, "addition_tag_distribution.csv"),
    )
    plot_tag_clip_distribution_with_csv_and_labels(
        tags_to_clip_id_dict_missing,
        os.path.join(save_dir, "missing_tag_distribution.png"),
        os.path.join(save_dir, "missing_tag_distribution.csv"),
    )
