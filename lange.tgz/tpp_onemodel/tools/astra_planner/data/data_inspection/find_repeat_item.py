# -*- coding: utf-8 -*-
# flake8: noqa: D103
# flake8: noqa: F841
# flake8: noqa: T201
# flake8: noqa: F401
import argparse
import os


def split_files(
    input_filenames, unique_name="", dup1_name="", dup2_name="", unique_dup1_name="", save_dir="", save_file=False
):
    # 确保保存路径存在
    os.makedirs(save_dir, exist_ok=True) if save_file else None

    # 构造完整的输出文件路径
    unique_path = os.path.join(save_dir, unique_name)
    dup1_path = os.path.join(save_dir, dup1_name)
    dup2_path = os.path.join(save_dir, dup2_name)
    unique_dup1_path = os.path.join(save_dir, unique_dup1_name)

    # 初始化集合和字典
    unique_set = set()
    seen = {}
    duplicate_count = {}

    # 创建四个列表用于存储完整的行
    unique_lines = []
    dup1_lines = []
    dup2_lines = []
    unique_dup1_lines = []

    # 读取并合并多个输入文件
    all_lines = []
    for input_filename in input_filenames:
        with open(input_filename, "r", encoding="utf-8") as file:
            all_lines.extend(file.readlines())

    # 遍历所有文件中的每一行
    for line_number, line in enumerate(all_lines):
        line = line.strip()
        if not line:
            continue

        # 按照 '/' 切分，并取第 4 个元素（索引为 3）
        parts = line.split("/")
        if len(parts) > 3:
            key = parts[3]
        else:
            continue

        # 如果 key 已经在 seen 中，说明是重复元素
        if key in seen:
            duplicate_count[key] += 1
            if duplicate_count[key] == 2:
                # 第二次出现的行写入 dup2_lines
                dup2_lines.append(line)
            else:
                # 出现超过两次的行将被丢弃
                continue
        else:
            # 第一次遇到该元素
            seen[key] = line
            duplicate_count[key] = 1
            unique_lines.append(line)

    # 遍历 seen 中的元素，如果出现次数为 2，则写入 dup1_lines
    for key, count in duplicate_count.items():
        if count == 2:
            dup1_lines.append(seen[key])

    # 创建 unique_dup1_lines，包含 unique_lines 和 dup1_lines 的合并去重
    unique_dup1_lines = list(set(unique_lines + dup1_lines))

    if save_file:
        # 写入 unique.txt
        with open(unique_path, "w", encoding="utf-8") as unique_file:
            for line in unique_lines:
                unique_file.write(f"{line}\n")

        # 写入 dup1.txt
        with open(dup1_path, "w", encoding="utf-8") as dup1_file:
            for line in dup1_lines:
                dup1_file.write(f"{line}\n")

        # 写入 dup2.txt
        with open(dup2_path, "w", encoding="utf-8") as dup2_file:
            for line in dup2_lines:
                dup2_file.write(f"{line}\n")

        # 写入 unique_dup1.txt
        with open(unique_dup1_path, "w", encoding="utf-8") as unique_dup1_file:
            for line in unique_dup1_lines:
                unique_dup1_file.write(f"{line}\n")

        print(f"文件已成功保存至 {save_dir}: unique.txt、dup1.txt、dup2.txt 和 unique_dup1.txt")
    return unique_dup1_lines


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process some parameters.")
    parser.add_argument(
        "--input_files",
        nargs="+",
        required=False,
        default=[
            "/share-global/yong.zhang15/share/planning/share/1103/1108_rl_base_adw.txt",
            "/share-global/yong.zhang15/share/planning/share/1103/1106data_append_gap_at0918_49wclips.txt",
            "/share-global/mccree.zhao/share/planning/dataset/1110_alldata_100w/1108_rl_base_dlb.txt",
            "/share-global/yong.zhang15/share/planning/share/1111/retry_1106argus_1106post_adw.txt",
        ],
        help="A list of input file paths to be processed",
    )
    parser.add_argument("--unique_file", default="unique.txt", type=str, help="The output path for the unique file")
    parser.add_argument(
        "--dup1_file", default="dup1.txt", type=str, help="The output path for the first duplicate file"
    )
    parser.add_argument(
        "--dup2_file", default="dup2.txt", type=str, help="The output path for the second duplicate file"
    )
    parser.add_argument(
        "--unique_dup1_file",
        default="unique_dup1.txt",
        type=str,
        help="The output path for the unique + dup1 combined file",
    )
    parser.add_argument(
        "--save_dir",
        default="./data_compare",
        type=str,
        help="The saving path",
    )
    parser.add_argument(
        "--save_file",
        default=False,
        type=bool,
        help="Whether to save the filtered files",
    )

    args = parser.parse_args()

    # 调用函数，传递命令行参数
    unique_dup1_content = split_files(
        args.input_files,
        args.unique_file,
        args.dup1_file,
        args.dup2_file,
        args.unique_dup1_file,
        args.save_dir,
        args.save_file,
    )
