# -*- coding: utf-8 -*-
# flake8: noqa
import logging
from functools import partial
from multiprocessing import Pool
from multiprocessing import cpu_count

import matplotlib.pyplot as plt
import numpy as np
import torchpilot
from tqdm import tqdm

from tpp_onemodel.tools.astra_planner.data.data_utils.astra_planner_dataset_utils import (
    PlannerDatasetUtils,
)


# 初始化日志记录器
logger = torchpilot.logger


def process_clip(clip):
    """处理单个 clip 数据，提取拥堵信息并进行可视化.

    参数:
        clip: PlannerDatasetUtils 中的一个 clip 对象

    返回:
        tuple: (clip_id, frame_data_list)
               frame_data_list 为 [(timestamp, bbox_num, ego_speed, has_front_car), ...]
    """
    frame_data_list = []
    for frame in clip:
        bbox = frame.frame_data["dynamic_dets"]  # [N, ...]
        bbox_num = bbox.shape[0]

        ego_vel = frame.frame_data["ego_motion"][0:2]  # [vx, vy]
        ego_speed = np.linalg.norm(ego_vel)  # 求ego速度大小

        has_front_car = False
        if bbox_num > 0:
            bbox_pos = bbox[:, 0:2]  # [N,2], 假设 x 是纵向, y 是横向
            # 判断是否有前车
            # 前车定义: 纵向x在[-5,50], 横向y在[-3,3]
            in_front_mask = (
                (bbox_pos[:, 0] >= -5) & (bbox_pos[:, 0] <= 50) & (bbox_pos[:, 1] >= -3) & (bbox_pos[:, 1] <= 3)
            )
            if np.any(in_front_mask):
                has_front_car = True

        frame_data_list.append((frame.timestamp, bbox_num, ego_speed, has_front_car))

    return (clip.clip_id, frame_data_list)


def init_pool():
    """
    初始化每个进程的日志记录（如果需要）。
    """
    logging.basicConfig(level=logging.INFO)


def plot_bbox_distribution(congestion_info, output_path="bbox_distribution.png"):
    """
    绘制 bbox_num 的分布图，并保存为 PNG 文件。

    参数:
        congestion_info (dict): 包含每个 clip 的拥堵信息。
        output_path (str): 保存图像的文件路径。
    """
    # 收集所有 bbox_num
    bbox_nums = []
    for data in congestion_info.values():
        # data 为 [(timestamp, bbox_num, ego_speed, has_front_car), ...]
        for frame_data in data:
            _, bbox_num, _, _ = frame_data
            bbox_nums.append(bbox_num)

    # 设置绘图参数
    plt.figure(figsize=(24, 8), dpi=300)  # 增加宽度至24英寸

    # 定义x轴范围和bin
    bins = np.arange(0, 201, 1)  # 0到200，每个整数一个bin

    # 绘制直方图，并获取 counts 和 patches
    counts, bin_edges, patches = plt.hist(bbox_nums, bins=bins, edgecolor="black", color="skyblue")

    # 设置标签和标题
    plt.xlabel("Number of BBoxes", fontsize=16)
    plt.ylabel("Number of Frames", fontsize=16)
    plt.title("Distribution of BBox Numbers per Frame", fontsize=20)

    # 设置x轴范围
    plt.xlim(0, 200)

    # 添加每个柱子上方的帧数量
    for count, patch in zip(counts, patches):
        if count > 0:
            plt.text(
                patch.get_x() + patch.get_width() / 2,
                count,
                int(count),
                ha="center",
                va="bottom",
                fontsize=8,
                rotation=90,
            )

    # 优化布局
    plt.tight_layout()

    # 保存图像
    plt.savefig(output_path, format="png")
    plt.close()
    logger.info(f"保存 bbox_num 分布图至 {output_path}")


if __name__ == "__main__":
    # 数据路径和参数配置
    data_path = "/share-global/wei.wang22/data/planner/0918/planner_dataset_v1106_align_v0918_100ms_510438_59180214.pkl"
    LOAD_ALL_FRAMES = True

    # 加载数据集
    dataset = PlannerDatasetUtils(data_path, load_all_frames=LOAD_ALL_FRAMES)
    dataset.dataset_data = dataset.dataset_data[::100]

    # 使用多进程池处理数据
    congestion_info = {}
    num_processes = cpu_count() // 2  # 使用一半的CPU核心，可以根据需求调整
    # num_processes = 1  # 如果希望固定使用4个进程，可以取消注释

    with Pool(processes=num_processes, initializer=init_pool) as pool:
        # 使用imap_unordered 以提高性能，并结合 tqdm 显示进度条
        for result in tqdm(pool.imap_unordered(process_clip, dataset), total=len(dataset), desc="Processing Clips"):
            clip_id, data = result
            logger.info(f"Processed clip: {clip_id}")
            congestion_info[clip_id] = data

    # 保存拥堵信息
    np.save("congestion_info.npy", congestion_info)
    logger.info("拥堵信息已保存至 congestion_info.npy")

    # 绘制并保存 bbox_num 分布图
    plot_bbox_distribution(congestion_info, output_path="bbox_distribution.png")

    # --------------------新增统计逻辑--------------------
    # 汇总所有帧数据
    all_frames = []
    for clip_id, frames in congestion_info.items():
        all_frames.extend(frames)  # frames: (timestamp, bbox_num, ego_speed, has_front_car)

    # 定义 bin 区间
    bins_def = [
        (0, 0),  # bin0: bbox_num = 0
        (1, 1),  # bin1: bbox_num = 1
        (2, 5),  # bin2: bbox_num in [2,5]
        (6, 10),  # bin3: bbox_num in [6,10]
        (11, 20),  # bin4: bbox_num in [11,20]
        (21, 30),  # bin5: bbox_num in [21,30]
        (31, 50),  # bin6: bbox_num in [31,50]
        (51, 200),  # bin7: bbox_num in [51,200]
    ]

    # 统计每个 bin 的信息
    for low, high in bins_def:
        # 筛选满足条件的帧
        filtered_frames = [(t, b, v, f) for (t, b, v, f) in all_frames if low <= b <= high]
        frame_count = len(filtered_frames)
        if frame_count > 0:
            avg_speed = np.mean([v for (_, _, v, _) in filtered_frames])
        else:
            avg_speed = 0.0

        # ego速度小于1m/s的统计
        slow_frames = [(t, b, v, f) for (t, b, v, f) in filtered_frames if v < 1.0]
        slow_count = len(slow_frames)
        slow_ratio = (slow_count / frame_count) if frame_count > 0 else 0.0

        logger.info(
            f"BBox Count in [{low},{high}]: Frame Count = {frame_count}, Avg Ego Speed = {avg_speed:.2f} m/s, "
            f"Speed<1m/s Count = {slow_count}, Ratio = {slow_ratio:.2%}"
        )

    # 统计有前车帧的平均ego速度
    front_car_frames = [frame for frame in all_frames if frame[3] == True]
    if len(front_car_frames) > 0:
        front_car_avg_speed = np.mean([f[2] for f in front_car_frames])
    else:
        front_car_avg_speed = 0.0
    logger.info(f"有前车帧的平均ego速度: {front_car_avg_speed:.2f} m/s")
    # ---------------------------------------------------
