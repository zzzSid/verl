# -*- coding: utf-8 -*-
# flake8: noqa
# mypy: ignore-errors
"""Implementation of oceanus apis."""
import getpass
import json
import multiprocessing
import pickle as pkl
import time
from functools import partial

import requests
from tqdm import tqdm


class OceanusAPIS:
    """Implementation of oceanus apis."""

    def __init__(self, num_workers=64) -> None:
        """Init."""
        self.api_host = "http://perception-mapping-backend.nioint.com"

        self.num_workers = num_workers

    def get_data_info(self, clip_id, namespace=None, gt_version=None, version=None):
        """Get data info from oceanus."""
        data = {}
        if namespace is not None:
            data["namespace"] = namespace
        if gt_version is not None:
            data["gt_version"] = gt_version
        if version is not None:
            data["version"] = version

        response_get = requests.get(f"{self.api_host}/api/v1/meta/clip/{clip_id}", params=data, timeout=60)
        return response_get.json()

    def submit_data(self, clip_sample, namespace, version):
        """Submit single clip data to oceanus.

        Args:
          clip_sample (dict): dict with keys ("meta_ceph_path", "selected_timestamp").
        """
        clip_id = clip_sample["meta_ceph_path"].split("/")[3]
        selected_timestamp = clip_sample["selected_timestamp"]
        data = {
            "namespace": namespace,
            "version": version,
            "extra_info": {
                "frame_timestamp": selected_timestamp,
            },
        }
        response_post = requests.post(f"{self.api_host}/api/v1/meta/clip/{clip_id}/version", json=data, timeout=60)
        return response_post.json()

    def submit_dataset_multiprocess(self, data_list, namespace, version):
        """Submit dataset to oceanus."""
        submit_data_func = partial(self.submit_data, namespace=namespace, version=version)
        with multiprocessing.Pool(self.num_workers) as pool:
            results = tqdm(
                pool.imap(submit_data_func, data_list),
                total=len(data_list),
                desc="Submit Data",
            )
            for _ in results:
                pass

    def submit_data_job(self, tag_version, data_version, clip_id_list_file, task_id, version):
        """Submit data job to oceanus.

        Args:
            tag_version (str): tag 版本，形如："5486d67faddf1ba04ab0ff121e96214af6d161b2_20241210164048_v1_20241213"
            data_version (str): 数据集版本，形如："v1207"
            clip_id_list_file (str): clip id list 文件，
                形如："/share-global/wei.wang22/data/planner/1207/v1207_clip_id_list.txt"
            task_id (int): 任务 id，在 oceanus 实验管理平台获取
            version (str): 数据集名称，自定义，形如："planner-data-v1207-training"
        """
        params = {
            "only_tag": True,
            "tag_version": tag_version,
            "data_version": data_version,
            "tag_statistics_flag": True,
        }
        params_str = json.dumps(params)

        data = {
            "task_id": str(task_id),
            "version": version,
            "condition_type": "clip_id",
            "usage": "train",
            "remark": "",
            "parameter": params_str,
            "created_user": getpass.getuser(),
        }
        files = {
            "file": open(clip_id_list_file, "rb"),
        }
        response_post = requests.post(f"{self.api_host}/dispatch/api/v2/playback", data=data, files=files, timeout=600)
        return response_post


if __name__ == "__main__":
    oceanus_apis = OceanusAPIS(num_workers=64)

    # # ----- Demo 1: Submit v1122 dataset to oceanus. -----
    # dataset_path = (
    #     "/share-global/wei.wang22/data/planner/1122/planner_dataset_v1122_align_v0918_100ms_514561_59637177.pkl"
    # )
    # datalist = pkl.load(open(dataset_path, "rb"))
    # oceanus_apis.submit_dataset_multiprocess(datalist, namespace="Planning", version="v1122_test")

    # # ----- Demo 2: Submit v1207 dataset to oceanus. -----
    # dataset_path = (
    #     "/share-global/wei.wang22/data/planner/1207/planner_dataset_v1207_align_v0918_100ms_495003_56938582.pkl"
    # )
    # data_list = pkl.load(open(dataset_path, "rb"))
    # oceanus_apis.submit_dataset_multiprocess(data_list, namespace="Planning", version="v1207_test")

    # # ----- Demo 3: Pull dataset from oceanus by dataset version and tag version. -----
    # max_retry_time = 50
    # for i_retry in range(max_retry_time):
    #     response_post = oceanus_apis.submit_data_job(
    #         tag_version="5486d67faddf1ba04ab0ff121e96214af6d161b2_20241210164048_v1_20241213",
    #         data_version="v1207",
    #         clip_id_list_file="/share-global/wei.wang22/data/planner/1207/v1207_clip_id_list.txt",
    #         task_id=1503,
    #         version="planner-data-v1207-training-4",
    #     )
    #     if response_post.status_code == 200 and response_post.json()["code"] == 0:
    #         print(f"Message: {response_post.json()['message']}")
    #         break
    #     elif response_post.status_code == 200 and response_post.json()["code"] == 1009:
    #         print(f"Message: {response_post.json()['message']}")
    #         break
    #     else:
    #         try:
    #             print(f"Error Message: {str(response_post)}, {response_post.json()}")
    #         except Exception:
    #             print(f"Error Message: {str(response_post)}")
    #         i_retry += 1
    #         print(f"Retry {i_retry} / {max_retry_time} ...")
    #         time.sleep(30)

    # # ----- Demo 4: Get data info by clip_id. -----
    clip_id = "20231103T170000_LJ1E6A2U6NG035999_1699002000.000000_1699002059.000000"
    response_get = oceanus_apis.get_data_info(clip_id=clip_id, namespace="Planning", version="v1207")
    print(response_get)
