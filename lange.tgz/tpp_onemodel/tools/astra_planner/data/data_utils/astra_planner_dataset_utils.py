# -*- coding: utf-8 -*-
import json
import pickle

import torchpilot

from tpp_onemodel.tools.astra_planner.data.data_utils.astra_planner_clip_data import (
    PlannerClipData,
)


logger = torchpilot.logger


class PlannerDatasetUtils:
    """Planer dataset."""

    def __init__(
        self,
        dataset_paths,
        frame_sensor_list=[
            "dynamic_dets",
            "meta",
            "static_dets",
            "dynamic_gods",
            "manner_lane",
            # "atlas",
            "navi_path",
        ],
        load_all_frames=False,
        scene_tag_by_gt_paths=None,
        count_tag_by_level=False,
    ):
        """Init."""
        logger.warning("Loading dataset, load_all_frames: %s", load_all_frames)
        self.data_paths = dataset_paths
        self.dataset_data = []
        if type(dataset_paths) is not str:
            if type(dataset_paths[0]) is str and dataset_paths[0][-4:] == ".pkl":
                for dataset_path in dataset_paths:
                    self.read_data(dataset_path)
            else:
                self.dataset_data = dataset_paths
        else:
            self.read_data(dataset_paths)
        self.count_tag_by_level = count_tag_by_level
        self.scene_tag_by_gt_infos = None
        if scene_tag_by_gt_paths is not None:
            self.scene_tag_by_gt_infos = {}
            for scene_tag_by_gt_path in scene_tag_by_gt_paths:
                with open(scene_tag_by_gt_path) as f:
                    self.scene_tag_by_gt_infos.update(json.load(f))
        self.load_all_frames = load_all_frames
        self.clip_idx = {da["meta_ceph_path"].split("/")[3]: idx for idx, da in enumerate(self.dataset_data)}
        self.frame_sensor_list = frame_sensor_list

    def read_data(self, dataset_path):
        """Read data."""
        with open(dataset_path, "rb") as f:
            logger.warning("Loading dataset from %s", dataset_path)
            self.dataset_data.extend(pickle.load(f))
            logger.warning("Loaded %s clips", len(self.dataset_data))

    @property
    def clip_id_list(self):
        """Return clip id list."""
        return [da["meta_ceph_path"].split("/")[3] for da in self.dataset_data]

    def __getitem__(self, key):
        """Get item."""
        if isinstance(key, str):
            idx = self.clip_idx.get(key, None)
            clip_id = key
            if idx is None:
                raise ValueError("clip id not found")
        elif isinstance(key, int):
            idx = key
            clip_id = self.clip_id_list[idx]
        else:
            raise ValueError("key should be str or int")

        scene_tag_by_gt = False
        scene_tag_by_gt_infos = None
        if self.scene_tag_by_gt_infos is not None:
            scene_tag_by_gt = True
            if clip_id in self.scene_tag_by_gt_infos:
                scene_tag_by_gt_infos = self.scene_tag_by_gt_infos[clip_id]

        return PlannerClipData(
            self.dataset_data[idx],
            load_all_frames=self.load_all_frames,
            frame_sensor_list=self.frame_sensor_list,
            scene_tag_by_gt=scene_tag_by_gt,
            scene_tag_by_gt_info=scene_tag_by_gt_infos,
            count_tag_by_level=self.count_tag_by_level,
        )

    def __iter__(self):
        """Iterate."""
        for idx in range(len(self.dataset_data)):
            yield self[idx]

    def __len__(self):
        """Return length."""
        return len(self.dataset_data)


if __name__ == "__main__":

    data_path_test = "/share-global/xiangwei.geng/planner/planner_data/1127/planner_dataset_v1106_align_v0918_100ms_cicd_100_11743.pkl"
    dataset = PlannerDatasetUtils(data_path_test, load_all_frames=True)
