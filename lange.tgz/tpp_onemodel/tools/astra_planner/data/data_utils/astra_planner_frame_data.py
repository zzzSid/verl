# -*- coding: utf-8 -*-
import logging
import math
import os
import pickle

import cv2
import numpy as np
import torch
from read_cache_op_py import read_cache_op_py
from shapely.geometry import LineString

from tpp_onemodel.tools.astra_planner.visualization.planner_frame_figure import (
    PlannerFrameFigure,
)
from tpp_onemodel.utils.vehicle_param import EC6_length
from tpp_onemodel.utils.vehicle_param import EC6_StrngRatioMatix_LeftTurn
from tpp_onemodel.utils.vehicle_param import EC6_StrngRatioMatix_RightTurn
from tpp_onemodel.utils.vehicle_param import EC6_wheel_base
from tpp_onemodel.utils.vehicle_param import EC6_width_wo_mirror
from tpp_onemodel.utils.vehicle_param import EC7_length
from tpp_onemodel.utils.vehicle_param import EC7_StrngRatioMatix_LeftTurn
from tpp_onemodel.utils.vehicle_param import EC7_StrngRatioMatix_RightTurn
from tpp_onemodel.utils.vehicle_param import EC7_wheel_base
from tpp_onemodel.utils.vehicle_param import EC7_width_wo_mirror
from tpp_onemodel.utils.vehicle_param import ES6_length
from tpp_onemodel.utils.vehicle_param import ES6_StrngRatioMatix_LeftTurn
from tpp_onemodel.utils.vehicle_param import ES6_StrngRatioMatix_RightTurn
from tpp_onemodel.utils.vehicle_param import ES6_wheel_base
from tpp_onemodel.utils.vehicle_param import ES6_width_wo_mirror
from tpp_onemodel.utils.vehicle_param import ES7_length
from tpp_onemodel.utils.vehicle_param import ES7_StrngRatioMatix_LeftTurn
from tpp_onemodel.utils.vehicle_param import ES7_StrngRatioMatix_RightTurn
from tpp_onemodel.utils.vehicle_param import ES7_wheel_base
from tpp_onemodel.utils.vehicle_param import ES7_width_wo_mirror
from tpp_onemodel.utils.vehicle_param import ES8_length
from tpp_onemodel.utils.vehicle_param import ES8_StrngRatioMatix_LeftTurn
from tpp_onemodel.utils.vehicle_param import ES8_StrngRatioMatix_RightTurn
from tpp_onemodel.utils.vehicle_param import ES8_wheel_base
from tpp_onemodel.utils.vehicle_param import ES8_width_wo_mirror
from tpp_onemodel.utils.vehicle_param import ET5_length
from tpp_onemodel.utils.vehicle_param import ET5_StrngRatioMatix_LeftTurn
from tpp_onemodel.utils.vehicle_param import ET5_StrngRatioMatix_RightTurn
from tpp_onemodel.utils.vehicle_param import ET5_wheel_base
from tpp_onemodel.utils.vehicle_param import ET5_width_wo_mirror
from tpp_onemodel.utils.vehicle_param import ET7_length
from tpp_onemodel.utils.vehicle_param import ET7_StrngRatioMatix_LeftTurn
from tpp_onemodel.utils.vehicle_param import ET7_StrngRatioMatix_RightTurn
from tpp_onemodel.utils.vehicle_param import ET7_wheel_base
from tpp_onemodel.utils.vehicle_param import ET7_width_wo_mirror


VECHILE_PARA = {
    "ET5": {
        "length": ET5_length,
        "width_wo_mirror": ET5_width_wo_mirror,
        "wheel_base": ET5_wheel_base,
        "StrngRatioMatix_LeftTurn": ET5_StrngRatioMatix_LeftTurn,
        "StrngRatioMatix_RightTurn": ET5_StrngRatioMatix_RightTurn,
    },
    "ET7": {
        "length": ET7_length,
        "width_wo_mirror": ET7_width_wo_mirror,
        "wheel_base": ET7_wheel_base,
        "StrngRatioMatix_LeftTurn": ET7_StrngRatioMatix_LeftTurn,
        "StrngRatioMatix_RightTurn": ET7_StrngRatioMatix_RightTurn,
    },
    "ES6": {
        "length": ES6_length,
        "width_wo_mirror": ES6_width_wo_mirror,
        "wheel_base": ES6_wheel_base,
        "StrngRatioMatix_LeftTurn": ES6_StrngRatioMatix_LeftTurn,
        "StrngRatioMatix_RightTurn": ES6_StrngRatioMatix_RightTurn,
    },
    "ES7": {
        "length": ES7_length,
        "width_wo_mirror": ES7_width_wo_mirror,
        "wheel_base": ES7_wheel_base,
        "StrngRatioMatix_LeftTurn": ES7_StrngRatioMatix_LeftTurn,
        "StrngRatioMatix_RightTurn": ES7_StrngRatioMatix_RightTurn,
    },
    "ES8": {
        "length": ES8_length,
        "width_wo_mirror": ES8_width_wo_mirror,
        "wheel_base": ES8_wheel_base,
        "StrngRatioMatix_LeftTurn": ES8_StrngRatioMatix_LeftTurn,
        "StrngRatioMatix_RightTurn": ES8_StrngRatioMatix_RightTurn,
    },
    "EC6": {
        "length": EC6_length,
        "width_wo_mirror": EC6_width_wo_mirror,
        "wheel_base": EC6_wheel_base,
        "StrngRatioMatix_LeftTurn": EC6_StrngRatioMatix_LeftTurn,
        "StrngRatioMatix_RightTurn": EC6_StrngRatioMatix_RightTurn,
    },
    "EC7": {
        "length": EC7_length,
        "width_wo_mirror": EC7_width_wo_mirror,
        "wheel_base": EC7_wheel_base,
        "StrngRatioMatix_LeftTurn": EC7_StrngRatioMatix_LeftTurn,
        "StrngRatioMatix_RightTurn": EC7_StrngRatioMatix_RightTurn,
    },
}

VEHICLE_MATCH_LIST = list(VECHILE_PARA.keys())
VEHICLE_MATCH_ARRAY = np.array(
    [
        [VECHILE_PARA[veh_name][attr] for attr in ["length", "width_wo_mirror", "wheel_base"]]
        for veh_name in VEHICLE_MATCH_LIST
    ]
)


def get_car_type(length, wdith_wo_mirror, wheel_base):
    """Get car type from length, width_wo_mirror, wheel_base."""
    length = float(length)
    wdith_wo_mirror = float(wdith_wo_mirror)
    wheel_base = float(wheel_base)

    diff = np.abs(VEHICLE_MATCH_ARRAY - np.array([length, wdith_wo_mirror, wheel_base]))
    if diff.min() > 1e-6:
        raise ValueError(f"Length: {length}, Width: {wdith_wo_mirror}, Wheelbase: {wheel_base} not in vehicle list")
    min_diff_index = np.argmin(np.sum(diff, axis=1))
    car_type = VEHICLE_MATCH_LIST[min_diff_index]
    return car_type


logger = logging.getLogger(__name__)

COLOR_LIST = {
    "background_bev": (0, 0, 0),  # Black
    "background_info": (0, 0, 0),  # Black
    "info_string": (255, 255, 255),  # White
    "scale_line": (160, 160, 160),  # White
    "ego_traj_gt": (0, 0, 255),  # Red
    "ego_box": (0, 0, 255),  # Red
    "agent_box": (0, 255, 0),  # Green
    "atlas": (80, 80, 80),  # Gray
    "navi_lane": (203, 192, 255),
    "laneline": (0, 0, 0),  # Black
    "curb": (80, 127, 255),
    "stopline": (226, 43, 138),
    "roadsign_box": (255, 0, 0),  # Blue
    "line_string": (255, 255, 255),  # White
}
LANELINE_STYLE_MAP = {
    1: {"thickness": 2, "linestyle": "-"},  # Solid
    2: {"thickness": 2, "linestyle": "--"},  # Dash
    3: {"thickness": 2, "linestyle": "=="},  # Solid-Dash
    4: {"thickness": 2, "linestyle": "=="},  # Dash-Solid
    5: {"thickness": 2, "linestyle": "="},  # Solid-Solid
    9: {"thickness": 2, "linestyle": "=="},  # Dash-Dash
}
LANELINE_COLOR_MAP = {
    1: (255, 255, 255),  # White
    2: (0, 255, 255),  # Yellow
}

SCENE_TAG_2_ID = {
    "LaneKeep": 0,
    "LeftChange": 1,
    "RightChange": 2,
    "LeftTurn": 3,
    "RightTurn": 4,
    "LeftUturn": 5,
    "RightUturn": 6,
    "LeftNudge": 7,
    "RightNudge": 8,
}


def get_head_tail_points(line, distance=5):
    """
    从给定的LineString对象中获取头部和末尾指定长度的两个点.

    :param line: LineString对象，表示折线
    :param distance: 要截取的头部和末尾的长度，默认为5
    :return: 包含头部两个点和末尾两个点的元组，每个点为(x, y)坐标形式的元组，如果总长度小于distance*2，则返回空列表
    """
    line = LineString(line)
    # 获取总长度
    total_length = line.length

    # 处理头部长度对应的点
    if total_length < distance * 2:
        return [], []
    # 沿着线的方向进行线性插值获取头部长度处的点
    current_length = 0
    coords = list(line.coords)
    for i in range(len(coords) - 1):
        segment = LineString([coords[i], coords[i + 1]])
        segment_length = segment.length
        if current_length + segment_length > distance:
            alpha = (distance - current_length) / segment_length
            interp_point = (
                coords[i][0] + alpha * (coords[i + 1][0] - coords[i][0]),
                coords[i][1] + alpha * (coords[i + 1][1] - coords[i][1]),
            )
            head_points = [coords[0], interp_point]
            break
        current_length += segment_length

    # 处理末尾长度对应的点
    reversed_coords = list(line.coords)[::-1]
    current_length = 0
    for i in range(len(reversed_coords) - 1):
        segment = LineString([reversed_coords[i], reversed_coords[i + 1]])
        segment_length = segment.length
        if current_length + segment_length > distance:
            beta = (distance - current_length) / segment_length
            interp_point = (
                reversed_coords[i][0] + beta * (reversed_coords[i + 1][0] - reversed_coords[i][0]),
                reversed_coords[i][1] + beta * (reversed_coords[i + 1][1] - reversed_coords[i][1]),
            )
            tail_points = [interp_point, reversed_coords[0]]
            break
        current_length += segment_length

    return head_points, tail_points


def is_lane_on_left_or_right(self_car_position, navi_lines):
    """判断车道在自车正前方的左边还是右边.

    :param self_car_position: 自车位置，以Point对象表示
    :param lane_line: 车道线，以LineString对象表示
    :return: 返回判断结果字符串
    """
    ego_vector = (1, 0)
    distances = np.sqrt(np.square(navi_lines[..., 0]) + np.square(navi_lines[..., 1]))
    closest_indices = np.argsort(distances)[:1]
    points = navi_lines[closest_indices[0]]
    ego_to_point_vector = (points[0] - self_car_position[0], points[1] - self_car_position[1])
    cross_product = ego_vector[0] * ego_to_point_vector[1] - ego_vector[1] * ego_to_point_vector[0]
    if cross_product >= 0:
        return "left"
    elif cross_product < 0:
        return "right"


class PlannerFrameData:
    """Planner frame data."""

    def __init__(
        self,
        clip_id,
        timestamp,
        ceph_path,
        sensor_list=[
            "dynamic_dets",
            "meta",
            "static_dets",
            "dynamic_gods",
            "manner_lane",
            # "atlas",
            "navi_path",
        ],
        ceph_data=None,
        scene_tag_by_gt=False,
        scene_tag_by_gt_info=None,
        tags=None,
    ):
        """Init."""
        self.clip_id = clip_id
        self.timestamp = timestamp
        self.ceph_path = ceph_path
        self.sensor_list = sensor_list

        if ceph_data is None:
            self.ceph_data = read_cache_op_py([self.ceph_path[sensor_name] for sensor_name in self.sensor_list])
        else:
            self.ceph_data = ceph_data
        self.data = {sensor: pickle.loads(ceph_data) for sensor, ceph_data in zip(self.sensor_list, self.ceph_data)}
        self.sensors = list(self.data.keys())

        self.frame_data = self.parse_frame_data()
        self.navilane_lk_dis_thresh = 1

        self.scene_tag_by_gt = scene_tag_by_gt
        self.scene_tag_by_gt_info = scene_tag_by_gt_info
        self.tags = tags

    def vis(self, save_path, draw_keys=None, temporal_frame=None, image=None):
        """Visualize frame data."""
        self.frame_figure = PlannerFrameFigure(
            gt_range=(-40, 150, -50, 50),
            scale=16,
            color_list=COLOR_LIST,
            laneline_style_map=LANELINE_STYLE_MAP,
            laneline_color_map=LANELINE_COLOR_MAP,
            draw_order=["bev", "base_info"],
        )

        warning_str = f"Save image to {os.path.join(save_path, f'{self.timestamp:.4f}.jpg')}"
        logger.warning(warning_str)

        if draw_keys is None:
            draw_keys = [
                "ego_traj_gt",
                "ego_box",
                "agent_box",
                "navi_lane",
                "laneline",
                "curb",
                "stopline",
                "roadsign",
                "tld",
                "scene_tag",
                "navi_path",
            ]

        # navi_spped_limit_max = self.get_navi_speed_limit()
        ego_cur_speed = np.linalg.norm(self.frame_data["ego_motion"][0:2])
        if "objs" in self.tags:
            tag_list = [_["cate"] for _ in self.tags["objs"]]
        elif type(self.tags) is dict:
            tag_list = self.tags.get("tag", [])
        elif "cate" in self.tags[0]:
            tag_list = [_["cate"] for _ in self.tags]
        else:
            tag_list = self.tags
        tags_set = set()
        for one_tag in tag_list:
            if "fft_urban" in one_tag or "md_bad_behavior" in one_tag or "leakage_future_info" in one_tag:
                one_tag = ".".join(one_tag.split(".")[2:])
                tags_set.add(one_tag)

        frame_info_dict = {
            "clip_id": self.clip_id,
            "timestamp": self.timestamp,
            # "navi_speed_limit_max": str(navi_spped_limit_max)[0:5]
            # + "m/s, "
            # + str(navi_spped_limit_max * 3.6)[0:5]
            # + "km/h",
            "ego_cur_speed": str(ego_cur_speed)[0:5] + "m/s, " + str(ego_cur_speed * 3.6)[0:5] + "km/h",
            "tags": "| ".join(tags_set),
            "v_x": str(self.frame_data["ego_motion"][0])[0:5] + "m/s",
            "v_y": str(self.frame_data["ego_motion"][1])[0:5] + "m/s",
            "acc_x": str(self.frame_data["ego_motion"][2])[0:5] + "m/s^2",
            "acc_y": str(self.frame_data["ego_motion"][3])[0:5] + "m/s^2",
            "whlag": str(self.frame_data["ego_motion"][6])[0:5] + "",
            "gear": str(self.frame_data["ego_motion"][11]),
        }
        self.frame_figure.draw_base_info(frame_info_dict, image_key="base_info")

        # draw atlas
        if "atlas" in draw_keys:
            for unsafe_area in self.frame_data["atlas"]["unsafe_area"]:
                self.frame_figure.draw_atlas(unsafe_area, image_key="bev")

        # draw scale line
        self.frame_figure.draw_scale_line(image_key="bev")

        if "navi_path" in draw_keys:
            for navi_path in self.frame_data["navi_path_points"]:
                self.frame_figure.draw_navi_path(navi_path, image_key="bev")

        # draw manner lane and roadsign
        if "laneline" in draw_keys or "curb" in draw_keys or "stopline" in draw_keys or "roadsign" in draw_keys:
            self.frame_figure.draw_lane_roadsign(
                self.frame_data["manner_lane_points"],
                self.frame_data["manner_lane_types"],
                self.frame_data["manner_lane_attr"],
                draw_key=draw_keys,
                image_key="bev",
            )

        # draw agent box
        if "agent_box" in draw_keys:
            for bbox in self.frame_data["dynamic_dets"]:
                bbox_xylwh = bbox[[0, 1, 3, 4, 6]]
                self.frame_figure.draw_agent_box(bbox_xylwh, image_key="bev")

        # draw ego box
        if "ego_box" in draw_keys:
            self.frame_figure.draw_ego_pos(image_key="bev")
            self.frame_figure.draw_ego_box(image_key="bev")

        # draw ego trajectory gt
        if "ego_traj_gt" in draw_keys and temporal_frame:
            temporal_data = self.format_temporal_data(temporal_frame)
            self.frame_figure.draw_ego_traj_gt(temporal_data["ego_future"])

        if "tld" in draw_keys:
            self.frame_figure.draw_tld_e2e(self.frame_data.get("tld", None), image_key="bev")

        if "scene_tag" in draw_keys:
            self.frame_figure.draw_scene_tag(self.get_scene_type()[0], image_key="bev")

        self.frame_figure.dump_image(os.path.join(save_path, f"{self.timestamp:.4f}.jpg"))

    @staticmethod
    def _parse_bytes_from_buffer(bytes, shape, dtype=np.float32):
        """Parse bytes from buffer."""
        return np.frombuffer(bytes, dtype=dtype).reshape(shape)

    def _parse_nested_list(self, data_list, shapes, dtype=np.float32):
        """Parse nested list."""
        return [self._parse_bytes_from_buffer(data_list[i], shapes[i], dtype) for i in range(len(data_list))]

    def _parse_crop_images_list(self, crop_images_list, dtype=np.float32):
        """Parse crop images list."""
        parsed_list = []
        for crop_img_byte in crop_images_list:
            if crop_img_byte is not None:
                crop_img_raw = np.frombuffer(crop_img_byte, dtype=np.uint8)
                crop_img = cv2.imdecode(crop_img_raw, cv2.IMREAD_COLOR).reshape(-1)
            else:
                crop_img = np.zeros((64 * 64 * 3))
            parsed_list.append(crop_img)
        return np.array(parsed_list, dtype=dtype) / 255.0

    def get_navi_speed_limit(self):
        """Get speed limit from navilane."""
        navi_speed_limit_list = []

        for navi_speed_limit in self.frame_data["navi_lane_speed_limit"]:
            navi_speed_limit = navi_speed_limit[0][0]
            navi_speed_limit_list.append(navi_speed_limit)
        navi_speed_limit_max = np.array(navi_speed_limit_list).max() / 3.6 if len(navi_speed_limit_list) > 0 else -1
        return navi_speed_limit_max

    def get_scene_type(self, by_gt=True):
        """Get scene type."""
        if by_gt:
            return self._get_scene_type_by_gt()
        else:
            return self._get_scene_type()

    def _get_scene_type(self):
        if self.tags is not None:
            for tag in self.tags:
                tag = tag["cate"]
                if "turn" in tag and "left" in tag:
                    return "LT", 4
                if "turn" in tag and "right" in tag:
                    return "RT", 5
        navi_line_points = self.frame_data["navi_line_points"]
        navi_line_types = self.frame_data["navi_line_types"]

        if len(navi_line_points) == 0:
            return "Learnable_LK", 0

        dist_l = []
        for idx, (navi_line_point, _) in enumerate(zip(navi_line_points, navi_line_types)):
            dist_l.append(self.get_ego_navi_dist(navi_line_point))
        dist_l = np.array(dist_l)

        scene_id = None

        # lk_lat_dises, lk_indices = self._get_lk_navilane(navi_line_points)
        lk_indices = []
        min_idx = dist_l.argmin()
        if dist_l[min_idx] < 1.5:
            lk_indices = [min_idx]
        lt_indices, rt_indices = self._get_lt_navilane(navi_line_points)
        lc_navilane_index, rc_navilane_index = self.get_lc_navilane(
            navi_line_points, lk_indices, lt_indices, rt_indices
        )
        if (
            len(lt_indices) + len(rt_indices) > 0
            and len(lk_indices) > 0
            and lk_indices[0] not in lt_indices
            and lk_indices[0] not in rt_indices
        ):
            lk_indices = []

        if len(lk_indices) == 0:
            # if dist_l[min_dist_idx] > 1.5:
            if len(lt_indices) > 0 or len(lc_navilane_index) > 0:
                scene_type = "LC"
                scene_id = 2
            elif len(rt_indices) > 0 or len(rc_navilane_index) > 0:
                scene_type = "RC"
                scene_id = 3
        else:
            min_dist_idx = lk_indices[0]
            if min_dist_idx in lt_indices:
                scene_type = "LT"
                scene_id = 4
            elif min_dist_idx in rt_indices:
                scene_type = "RT"
                scene_id = 5
            else:
                scene_type = "LK"
                scene_id = 1

        return scene_type, scene_id

    def _get_scene_type_by_gt(self):
        scene_tag = None
        scene_id = -1
        for scene in SCENE_TAG_2_ID.keys():
            if self.scene_tag_by_gt_info is not None and scene in self.scene_tag_by_gt_info:
                for item in self.scene_tag_by_gt_info[scene]:
                    st = float(item["start_ts"])
                    et = float(item["end_ts"])
                    if self.timestamp >= st and self.timestamp <= et:
                        # print("get target of {} {}".format(self.clip_id, self.timestamp))
                        scene_tag = scene
                        scene_id = SCENE_TAG_2_ID[scene]
        return scene_tag, scene_id

    def get_ego_navi_dist(self, navi_line_points):
        """Get ego navi dist."""
        if len(navi_line_points) == 1:
            return navi_line_points[0][1]
        navi_line_points_diff = navi_line_points[1:] - navi_line_points[:-1]
        navi_line_points_diff = np.concatenate((navi_line_points_diff, navi_line_points_diff[-1:]))
        ego = np.array([[0, 0]])
        ego_navilane_diff = ego - navi_line_points
        distances = np.linalg.norm(navi_line_points, axis=-1)
        nearest_point_indices = distances.argmin()
        match_indeices = [nearest_point_indices]
        if nearest_point_indices > 0:
            match_indeices.append(nearest_point_indices - 1)
        dist_l_min = 1e6
        for idx in match_indeices:
            u = navi_line_points_diff[idx]
            v = ego_navilane_diff[idx]
            dist_l = v[0] * u[1] - v[1] * u[0]
            dist_l = abs(dist_l / np.linalg.norm(u))
            dist_l_min = dist_l if dist_l < dist_l_min else dist_l_min
        # print(distances.min(), dist_l_min)
        return dist_l_min

    def get_closet_navipoint(self, lane_points, num_points=1):
        """Get closest navipoint."""
        dises = np.sqrt(np.square(lane_points[..., 0]) + np.square(lane_points[..., 1]))
        min_args = np.argsort(dises)[:num_points]
        return min_args

    def _get_lk_navilane(self, navilanes):
        """Get LK navilane."""
        lk_lat_dises = []
        lk_indices = []
        for idx, lane_points in enumerate(navilanes):
            # closet_point_index = self.get_closet_navipoint(lane_points)
            closet_points_indices = self.get_closet_navipoint(lane_points, num_points=5)
            mean_lat_distance = abs(lane_points[closet_points_indices, 1]).mean()
            if mean_lat_distance < self.navilane_lk_dis_thresh:
                lk_lat_dises.append(mean_lat_distance)
                lk_indices.append(idx)
        return lk_lat_dises, lk_indices

    def get_lk_navilane(self):
        """Get LK navilane."""
        return self._get_lk_navilane(self.frame_data["navi_line_points"])

    def get_lt_navilane(self):
        """Get LT navilane."""
        return self._get_lt_navilane(self.frame_data["navi_line_points"])

    def _get_lt_navilane(self, navilanes):
        """Get LT navilane."""
        lt_indices, rt_indices = [], []
        try:
            for idx, lane_points in enumerate(navilanes):
                head_points, tail_points = get_head_tail_points(lane_points)
                if len(head_points) == 0 or len(tail_points) == 0:
                    continue
                head_angle = np.arctan2(head_points[1][1] - head_points[0][1], head_points[1][0] - head_points[0][0])
                tail_angle = np.arctan2(tail_points[1][1] - tail_points[0][1], tail_points[1][0] - tail_points[0][0])
                if tail_angle - head_angle > math.pi * (60 / 180):
                    lt_indices.append(idx)
                elif tail_angle - head_angle < math.pi * (-60 / 180):
                    rt_indices.append(idx)
        except:  # noqa: E722
            return [], []
        return lt_indices, rt_indices

    def get_lc_navilane(self, navilanes, lk_navilane_index, lt_navilane_index, rt_navilane_index):
        """Get LC navilane."""
        lc_indices, rc_indices = [], []
        not_lc_navilane_index = lk_navilane_index + lt_navilane_index + rt_navilane_index
        for idx, lane_points in enumerate(navilanes):
            if idx in not_lc_navilane_index:
                continue
            flag = is_lane_on_left_or_right((0, 0), lane_points)
            if flag == "left":
                lc_indices.append(idx)
            elif flag == "right":
                rc_indices.append(idx)
        return lc_indices, rc_indices

    def parse_frame_data(self):
        """Parse frame data."""
        frame_anno_info = {}
        for sensor in self.sensors:
            info_bytes = self.data[sensor]
            if sensor == "lane":
                frame_anno_info["lane_points"] = self._parse_nested_list(
                    info_bytes["lane_points"], info_bytes["lane_points_shape"]
                )
                frame_anno_info["lane_types"] = self._parse_bytes_from_buffer(
                    info_bytes["lane_types"], info_bytes["lane_types_shape"]
                )
            elif sensor == "navi_path":
                frame_anno_info["navi_path_points"] = self._parse_nested_list(
                    info_bytes["navi_path_points"], info_bytes["navi_path_points_shape"]
                )
                # frame_anno_info["navi_line_types"] = self._parse_bytes_from_buffer(
                #     info_bytes["navi_line_types"], info_bytes[f"navi_line_types_shape"]
                # )
                frame_anno_info["navi_path_types"] = 5 * np.ones(
                    len(frame_anno_info["navi_path_points"]), dtype=np.float32
                )
            elif sensor == "sdmap":
                frame_anno_info["sdmap_geo"] = self._parse_nested_list(info_bytes["sdmap"], info_bytes["sdmap_shape"])
                frame_anno_info["sd_link_ids"] = self._parse_bytes_from_buffer(
                    info_bytes["sd_link_ids"],
                    info_bytes["sd_link_ids_shape"],
                    dtype=np.uint64,
                )
            elif sensor == "atlas":
                frame_anno_info["atlas"] = {
                    "main_ground": self._parse_nested_list(
                        info_bytes["atlas"]["main_ground"],
                        info_bytes["atlas"]["main_ground_shape"],
                    ),
                    "foreground": self._parse_nested_list(
                        info_bytes["atlas"]["foreground"],
                        info_bytes["atlas"]["foreground_shape"],
                    ),
                    "unsafe_area": self._parse_nested_list(
                        info_bytes["atlas"]["unsafe_area"],
                        info_bytes["atlas"]["unsafe_area_shape"],
                    ),
                }
            elif sensor == "atlas_bev":
                frame_anno_info["atlas_bev"] = self._parse_bytes_from_buffer(
                    info_bytes["atlas_bev"],
                    info_bytes["atlas_bev_shape"],
                    dtype=np.uint8,
                )
            elif sensor == "static_polys":
                frame_anno_info["static_polys"] = np.frombuffer(
                    info_bytes["static_polys"]["points"], dtype=np.float32
                ).reshape(-1, 2)
                frame_anno_info["static_poly_split"] = info_bytes["static_polys"]["counts"]

            elif sensor == "static_dets":
                frame_anno_info[sensor] = self._parse_bytes_from_buffer(
                    info_bytes[sensor], info_bytes[f"{sensor}_shape"]
                )
                frame_anno_info["static_polys"] = np.frombuffer(
                    info_bytes["static_polys"]["points"], dtype=np.float32
                ).reshape(-1, 2)
                frame_anno_info["static_poly_split"] = info_bytes["static_polys"]["counts"]
            elif sensor == "dynamic_gods":
                frame_anno_info[sensor] = self._parse_bytes_from_buffer(
                    info_bytes[sensor], info_bytes[f"{sensor}_shape"]
                )
                frame_anno_info["dynamic_gods_polys"] = np.frombuffer(
                    info_bytes["dynamic_gods_polys"]["points"], dtype=np.float32
                ).reshape(-1, 2)
                frame_anno_info["dynamic_gods_polys_split"] = info_bytes["dynamic_gods_polys"]["counts"]

            elif sensor == "meta":
                frame_anno_info["car_poses"] = self._parse_bytes_from_buffer(info_bytes["car_pose"], (4, 4))
                frame_anno_info["ego_motion"] = self._parse_bytes_from_buffer(
                    info_bytes["ego_motion"], (12,)
                )  # vx,vy,acc_x,acc_y,yaw[2],yaw_rate[2],whlag,whlagspd,vehspd,lgta,chassis_yawrate
                frame_anno_info["ego_box"] = info_bytes["ego_box"]
                frame_anno_info["ego_gears_raw"] = frame_anno_info["ego_motion"][-1:]
                frame_anno_info["agent_label"] = info_bytes.get("agent_label", None)

                if frame_anno_info["ego_box"].get("length", None):
                    frame_anno_info["car_type"] = get_car_type(
                        frame_anno_info["ego_box"]["length"],
                        frame_anno_info["ego_box"]["width_wo_mirror"],
                        frame_anno_info["ego_box"]["wheel_base"],
                    )
                    frame_anno_info["StrngRatioMatix_LeftTurn"] = VECHILE_PARA[frame_anno_info["car_type"]][
                        "StrngRatioMatix_LeftTurn"
                    ]
                    frame_anno_info["StrngRatioMatix_RightTurn"] = VECHILE_PARA[frame_anno_info["car_type"]][
                        "StrngRatioMatix_RightTurn"
                    ]
                else:
                    frame_anno_info["car_type"] = None
                    frame_anno_info["StrngRatioMatix_LeftTurn"] = None
                    frame_anno_info["StrngRatioMatix_RightTurn"] = None

                # TODO[stephen.wang]: backup for next version.
                subclip_id = info_bytes["subclip_id"]
                frame_anno_info["subclip_ids"] = subclip_id

            elif sensor == "crop_images":
                if "crop_images" not in info_bytes.keys() or len(info_bytes["crop_images"]) == 0:
                    frame_anno_info["crop_images"] = np.zeros((frame_anno_info["dynamic_dets"].shape[0], 64 * 64 * 3))
                else:
                    frame_anno_info["crop_images"] = self._parse_crop_images_list(info_bytes["crop_images"])
            elif sensor == "manner_lane":
                frame_anno_info["manner_lane_points"] = self._parse_nested_list(
                    info_bytes["manner_lane_points"], info_bytes["manner_lane_points_shape"]
                )
                frame_anno_info["manner_lane_types"] = self._parse_bytes_from_buffer(
                    info_bytes["manner_lane_types"], info_bytes["manner_lane_types_shape"]
                )
                if "manner_lane_attr" in info_bytes:
                    frame_anno_info["manner_lane_attr"] = self._parse_nested_list(
                        info_bytes["manner_lane_attr"], info_bytes["manner_lane_attr_shape"], np.int16
                    )
            else:
                try:
                    frame_anno_info[sensor] = self._parse_bytes_from_buffer(
                        info_bytes[sensor], info_bytes[f"{sensor}_shape"]
                    )
                except Exception:
                    logger.warning("Unknown sensor type: %s", sensor)
        return frame_anno_info

    def format_temporal_data(self, temporal_frame):
        """Format temporal data."""
        temporal_data = {}
        current_to_world = torch.tensor(temporal_frame[0].frame_data["car_poses"])
        temporal_data["frame_to_current"] = torch.linalg.inv(current_to_world).unsqueeze(0) @ torch.tensor(
            np.array([frame.frame_data["car_poses"] for frame in temporal_frame])
        )
        homo_ego_future = torch.zeros((len(temporal_frame), 4, 1), dtype=torch.float32)
        homo_ego_future[:, -1, :] = 1.0

        temporal_data["ego_future"] = temporal_data["frame_to_current"] @ homo_ego_future

        temporal_data["ego_future"] = temporal_data["ego_future"][:, :3, 0].numpy()
        temporal_data["frame_to_current"] = temporal_data["frame_to_current"].numpy()

        return temporal_data

    def __repr__(self):
        """Repr."""
        return f"PlannerFrameData(clip_id={self.clip_id}, timestamp={self.timestamp})"
