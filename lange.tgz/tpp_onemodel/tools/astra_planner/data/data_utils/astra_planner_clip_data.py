# -*- coding: utf-8 -*-
import functools
import os
import pickle
from collections import defaultdict

import torchpilot
from read_cache_op_py import read_cache_op_py

from tpp_onemodel.tools.astra_planner.data.data_utils.astra_planner_frame_data import (
    PlannerFrameData,
)


logger = torchpilot.logger


def split_tag_by_level(tags):
    """当前帧的tag标签, 按照一级、二级标签计数."""
    level_tags = []
    for tag in tags:
        prefix, level1, level2, _ = tag.split(".")
        l1_name = ".".join([prefix, level1])
        l2_name = ".".join([prefix, level1, level2])
        if prefix not in level_tags:
            level_tags.append(prefix)
        if l1_name not in level_tags:
            level_tags.append(l1_name)
        if l2_name not in level_tags:
            level_tags.append(l2_name)
    return level_tags


class PlannerClipData:
    """Planner clip data."""

    def __init__(
        self,
        clip_data,
        frame_sensor_list=[
            "dynamic_dets",
            "meta",
            "static_dets",
            "dynamic_gods",
            "manner_lane",
            # "atlas",
            "navi_path",
        ],
        load_all_frames=False,
        scene_tag_by_gt=False,
        scene_tag_by_gt_info=None,
        count_tag_by_level=False,
    ):
        """Init."""
        self.clip_data = clip_data
        self.clip_id = clip_data["meta_ceph_path"].split("/")[3]
        self.path_data = f"/{clip_data['meta_ceph_path'].split(':')[-1]}"
        self.data = pickle.loads(read_cache_op_py([self.path_data])[0])
        self.tag_path = (
            f"/{clip_data['tag_ceph_path'].split(':')[-1]}" if clip_data["tag_ceph_path"] is not None else None
        )
        self.tag = pickle.loads(read_cache_op_py([self.tag_path])[0]) if self.tag_path is not None else {}

        self.load_all_frames = load_all_frames
        if self.load_all_frames or self.clip_data.get("selected_frame_idx") is None:
            self.selected_frame_idx = list(range(self.frame_num))
        else:
            self.selected_frame_idx = self.clip_data["selected_frame_idx"]

        self.clip_tags = []
        self.frame_tag_counts = defaultdict(int)
        self.count_tag_by_level = count_tag_by_level
        if self.tag is not None:  # {ts1: {'objs': [{'cate': tag1}, ]}, } -> {ts1: {'tag': [tag1, tag2, ]}, }
            if self.load_all_frames:
                tag_objs = self.tag.values()
            else:
                tag_objs = []
                for timestamp in self.clip_data["selected_timestamp"]:
                    tag_key = str(int(timestamp))
                    tag_obj = (
                        self.tag.get(tag_key, {"objs": []}) if self.tag and (tag_key in self.tag) else {"objs": []}
                    )
                    tag_objs.append(tag_obj)

            for tag_obj in tag_objs:
                if "objs" in tag_obj:
                    tags = [_["cate"] for _ in tag_obj["objs"]]
                elif "tag" in tag_obj:
                    tags = tag_obj["tag"]
                else:
                    tags = {}
                if isinstance(tags, list):
                    self.clip_tags.extend(tags)
                elif len(tags) == 0:
                    pass
                else:
                    self.clip_tags.extend([tags])

                for tag_name in tags:
                    self.frame_tag_counts[tag_name] += 1
                # 增加层级标签数目统计
                if self.count_tag_by_level:
                    level_tags = split_tag_by_level(tags)
                    for tag_name in level_tags:
                        self.frame_tag_counts[tag_name] += 1

            if len(self.clip_tags) > 0:
                self.clip_tags = functools.reduce(lambda a, b: a + b, self.clip_tags)
                self.clip_tags = list(set(self.clip_tags))
        ceph_path_root = os.path.dirname(os.path.dirname(self.path_data))

        self.frame_ceph_path = [{} for _ in range(self.frame_num)]
        self.frame_timestamp = self.data["timestamp_list"]

        for sensor in self.data["annos"]:
            frame_ceph_path_tmp = {
                "path": [f"{ceph_path_root}/{sensor}.dat" for _ in range(self.frame_num)],
                "size": [self.data["cephpath_filesize"][sensor] for _ in range(self.frame_num)],
                "offset": [self.data["annos"][sensor][i][0] for i in range(self.frame_num)],
                "window_size": [self.data["annos"][sensor][i][1] for i in range(self.frame_num)],
            }
            frame_ceph_path_tmp = list(
                zip(
                    frame_ceph_path_tmp["path"],
                    frame_ceph_path_tmp["size"],
                    frame_ceph_path_tmp["offset"],
                    frame_ceph_path_tmp["window_size"],
                )
            )
            for i in range(self.frame_num):
                self.frame_ceph_path[i][sensor] = (
                    f"{frame_ceph_path_tmp[i][0]} {frame_ceph_path_tmp[i][1]} {frame_ceph_path_tmp[i][2]} "
                    + f"{frame_ceph_path_tmp[i][3]}"
                )
        self.frame_sensor_list = frame_sensor_list

        self.frame_ts_cp = {float(ts): cp for ts, cp in zip(self.frame_timestamp, self.frame_ceph_path)}

        self.preloaded_frame_ceph = None
        self.scene_tag_by_gt = scene_tag_by_gt
        self.scene_tag_by_gt_info = scene_tag_by_gt_info

    def preload_frame_ceph_data(self):
        """Preload frame ceph data."""
        preload_frame_ceph = {}

        all_ceph_path = []
        all_ceph_len = []

        for ceph_path in self.frame_ceph_path:
            all_ceph_path.extend([ceph_path[key] for key in self.frame_sensor_list])
            all_ceph_len.append(len(self.frame_sensor_list))

        preload_frame_ceph = self.read_cache_op_py_merge_seq(all_ceph_path)
        preload_frame_ceph = [
            preload_frame_ceph[i : i + all_ceph_len[0]] for i in range(0, len(preload_frame_ceph), all_ceph_len[0])
        ]
        preload_frame_ceph = {float(ts): cp for ts, cp in zip(self.frame_timestamp, preload_frame_ceph)}
        self.preloaded_frame_ceph = preload_frame_ceph

    def read_cache_op_py_merge_seq(self, all_ceph_path):
        """Read cache op py merge seq."""
        merged_ceph_path = self.merge_ceph_path(all_ceph_path)
        merged_ceph_data = read_cache_op_py(merged_ceph_path)
        merged_ceph_path_dict = {
            ceph_path.split(" ")[0]: {"offset": int(ceph_path.split(" ")[2]), "ceph_data": ceph_data}
            for ceph_path, ceph_data in zip(merged_ceph_path, merged_ceph_data)
        }
        all_ceph_data = []
        for ceph_path in all_ceph_path:
            file_name = ceph_path.split(" ")[0]
            offset = int(ceph_path.split(" ")[2])
            window_size = int(ceph_path.split(" ")[3])
            rel_offset = offset - merged_ceph_path_dict[file_name]["offset"]
            all_ceph_data.append(merged_ceph_path_dict[file_name]["ceph_data"][rel_offset : rel_offset + window_size])

        return all_ceph_data

    def merge_ceph_path(self, all_ceph_path):
        """Merge ceph path."""
        merged_ceph_path = []
        all_file_dict = {
            file_name: {"file_size": None, "start_index": None, "end_index": None}
            for file_name in {ceph_path.split(" ")[0] for ceph_path in all_ceph_path}
        }
        for file_path in all_ceph_path:
            file_name, file_size, offset, window_size = file_path.split(" ")
            end_index = int(offset) + int(window_size)
            all_file_dict[file_name]["file_size"] = file_size
            if all_file_dict[file_name]["start_index"] is None or all_file_dict[file_name]["start_index"] > int(offset):
                all_file_dict[file_name]["start_index"] = int(offset)
            if all_file_dict[file_name]["end_index"] is None or all_file_dict[file_name]["end_index"] < end_index:
                all_file_dict[file_name]["end_index"] = end_index
        merged_ceph_path = [
            f"{file_name} {file_dict['file_size']} {file_dict['start_index']} "
            + f"{file_dict['end_index'] - file_dict['start_index']}"
            for file_name, file_dict in all_file_dict.items()
        ]

        return merged_ceph_path

    def get_scene_types(self, interval=1, by_gt=False):
        """Get scene tag list of one clip."""
        scene_types = []
        for i in range(self.frame_num):
            scene_type, _ = self[i].get_scene_type(by_gt=by_gt)
            scene_types.append(scene_type)

        return scene_types

    def vis(self, save_path, interval=1, dump_video=False):
        """Visualize clip data."""
        os.makedirs(os.path.join(save_path, self.clip_id), exist_ok=True)
        frame_save_path = os.path.join(save_path, self.clip_id)

        frame_sensor_list_tmp = self.frame_sensor_list

        all_meta = read_cache_op_py([item["meta"] for item in self.frame_ceph_path])
        temporal_data = [
            PlannerFrameData(
                self.clip_id,
                ts,
                {"meta": self.frame_ceph_path[idx]["meta"]},
                sensor_list=["meta"],
                ceph_data=[all_meta[idx]],
            )
            for idx, ts in enumerate(self.frame_timestamp)
        ]

        self.frame_sensor_list = frame_sensor_list_tmp
        for idx in self.selected_frame_idx[::interval]:
            self[idx].vis(
                frame_save_path,
                draw_keys=[
                    "ego_traj_gt",
                    "ego_box",
                    "agent_box",
                    "laneline",
                    "curb",
                    "stopline",
                    "roadsign",
                    "tld",
                    "scene_tag",
                    "navi_path",
                ],
                temporal_frame=temporal_data[idx : idx + 75 // interval],
            )
        if dump_video:
            logger.warning("Dump video for clip %s", self.clip_id)
            ffmpeg_cmd = (
                f"ffmpeg -r 10 -pattern_type glob -i '{frame_save_path}/*.jpg' {frame_save_path}/{self.clip_id}.mp4"
            )
            if self.check_cmd(ffmpeg_cmd):
                raise Exception("no rm allowed in command!")
            os.system(ffmpeg_cmd)  # noqa: S605

    def check_cmd(self, cmd):
        """Check cmd."""
        if " rm " in cmd:
            return True

    @property
    def frame_num(self):
        """Return frame number."""
        return len(self.data["timestamp_list"])

    def __getitem__(self, key):
        """Get item."""
        if isinstance(key, int):
            timestamp = float(self.frame_timestamp[key])
        if isinstance(key, float):
            timestamp = key
            if timestamp not in self.frame_ts_cp:
                raise ValueError(f"timestamp {timestamp} not found")
        frame_cp = self.frame_ts_cp[timestamp]

        item_ceph_path = {}
        for key, val in frame_cp.items():
            if key in self.frame_sensor_list:
                item_ceph_path[key] = val
        tags = self.tag.get(str(int(timestamp)), {})
        if self.preloaded_frame_ceph is not None:
            preload = self.preloaded_frame_ceph[timestamp]
            frame_data = PlannerFrameData(
                self.clip_id,
                timestamp,
                item_ceph_path,
                ceph_data=preload,
                scene_tag_by_gt=self.scene_tag_by_gt,
                scene_tag_by_gt_info=self.scene_tag_by_gt_info,
                tags=tags,
            )
        else:
            frame_data = PlannerFrameData(
                self.clip_id,
                timestamp,
                item_ceph_path,
                scene_tag_by_gt=self.scene_tag_by_gt,
                scene_tag_by_gt_info=self.scene_tag_by_gt_info,
                tags=tags,
            )
        return frame_data

    def __iter__(self):
        """Iterate."""
        self.preload_frame_ceph_data()
        for idx in self.selected_frame_idx:
            yield self[idx]

    def __len__(self):
        """Return length."""
        return self.frame_num

    def __repr__(self):
        """Show clip info."""
        return f"Clip {self.clip_id} with {self.frame_num} frames, selected {len(self)} frames"
