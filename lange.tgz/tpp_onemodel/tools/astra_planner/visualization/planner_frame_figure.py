# -*- coding: utf-8 -*-
# flake8: noqa
# mypy: ignore-errors
"""Opencv version of astra planner visualize tools."""
import logging
import os
from typing import List
from typing import Optional
from typing import Union

import cv2
import numpy as np
import torch

from tpp_onemodel.utils.collision_utils import get_box_corners


logger = logging.getLogger(__name__)

SUPPORT_KEYS = [
    "ego_traj_pred",
    "ego_traj_gt",
    "ego_box",
    "agent_box",
    "atlas",
    "navi_lane",
    "navi_path",
    "laneline",
    "curb",
    "stopline",
    "roadsign",
]

DEFAULT_COLOR_LIST = {
    "background_bev": (255, 255, 255),  # White
    "background_info": (0, 0, 0),  # Black
    "info_string": (255, 255, 255),  # White
    "scale_line": (100, 100, 100),  # Gray
    "ego_traj_pred": (255, 0, 0),  # Blue
    "ego_traj_gt": (0, 255, 0),  # Green
    "ego_box": (0, 255, 0),  # Green
    "agent_box": (255, 0, 0),  # Blue
    "atlas": (180, 180, 180),  # Gray
    "navi_lane": (255, 0, 255),  # Purple
    "laneline": (0, 192, 255),  # Yellow
    "agent_lane_line": (0, 255, 0),  # Green
    "curb": (0, 0, 0),  # Black
    "stopline": (0, 0, 255),  # Red
    "roadsign_box": (255, 0, 0),  # Blue
    "line_string": (0, 0, 0),  # Black
    "default_tld_color": {
        0: (255, 0, 255),
        1: (0, 0, 150),
        2: (0, 255, 255),
        3: (0, 150, 0),
        4: (128, 128, 128),
        5: (0, 0, 0),
    },
    "tld_arrow_color": (255, 255, 255),
    "tld_external_color": (255, 255, 255),
    "scene_tag": (255, 255, 255),
    "navi_path": (205, 224, 64),
    "control_point": {0: (71, 99, 255), 1: (211, 0, 148), 2: (19, 69, 139)},
    "control_point_heading": (71, 99, 255),
    "goal_ego_traj_pred": (128, 0, 128),
    "prior_box": (255, 0, 255),
    "not_prior_box": (0, 0, 0),
    "agents_lane_collision": (0, 255, 0),
    "agents_only_collision": (0, 0, 255),
    "lane_only_collision": (0, 192, 255),
    "drive_path_gt": (255, 0, 255),  # Purple
    "drive_path_pred": (0, 255, 0),  # gree
    "ar_ego_pos_pred": (128, 0, 128),
    "ar_agents_pos_pred": (255, 0, 0),
    "ar_drive_path_gt": (255, 0, 255),  # Purple
    "ar_drive_path_pred": (0, 255, 0),  # green
}

DEFAULT_LANELINE_STYLE_MAP = {
    1: {"thickness": 2, "linestyle": "-"},  # Solid
    2: {"thickness": 2, "linestyle": "--"},  # Dash
    3: {"thickness": 2, "linestyle": "=="},  # Solid-Dash
    4: {"thickness": 2, "linestyle": "=="},  # Dash-Solid
    5: {"thickness": 2, "linestyle": "="},  # Solid-Solid
    9: {"thickness": 2, "linestyle": "=="},  # Dash-Dash
}

DEFAULT_LANELINE_COLOR_MAP = {
    1: (255, 255, 255),  # White
    2: (0, 255, 255),  # Yellow
}

DEFAULT_TLD_RIDUS = 45

LANETYPE = dict(
    LDType_Unknown=0,
    LDType_Solid=1,
    LDType_Dash=2,
    LDType_Solid_Dash=3,
    LDType_Dash_Solid=4,
    LDType_Solid_Solid=5,
    LDType_Deceleration_Dash=6,
    LDType_Deceleration_Solid=7,
    LDType_Guide=8,
    LDType_Dash_Dash=9,
    LDType_Serrate=10,
    LDType_Composite=11,
    LDType_Parking_Space_Entrace=12,
)

ROADSIGNTYPE = dict(
    RoadSignClass_Unknown=0,
    RoadSignClass_StopLine=100,
    RoadSignClass_RoadArrow=200,
    RoadSignClass_RoadArrow_Left=201,
    RoadSignClass_RoadArrow_Right=202,
    RoadSignClass_RoadArrow_Left_Right=203,
    RoadSignClass_RoadArrow_Straight=204,
    RoadSignClass_RoadArrow_Straight_Right=205,
    RoadSignClass_RoadArrow_Straight_Left=206,
    RoadSignClass_RoadArrow_Only_Turn=207,
    RoadSignClass_RoadArrow_Left_Turn=208,
    RoadSignClass_RoadArrow_Straight_Turn=209,
    RoadSignClass_RoadArrow_Left_Merge=210,
    RoadSignClass_RoadArrow_Right_Merge=211,
    RoadSignClass_RoadArrow_Forbid_Sign=212,
    RoadSignClass_ZebraCross=300,
    RoadSignClass_NoParkingArea=400,
    RoadSignClass_SlowZone=500,
    RoadSignClass_SpeedBump=600,
    RoadSignClass_PolePillar=700,
    RoadSignClass_LimitSpd_Max=801,
    RoadSignClass_LimitSpd_Min=802,
    RoadSignClass_TextPattern=900,
    RoadSignClass_TextPattern_Yield=901,
    RoadSignClass_TextPattern_Stop=902,
    RoadSignClass_TextPattern_Variable=903,
    RoadSignClass_TextPattern_Reversible=904,
    RoadSignClass_TextPattern_Bike=905,
    RoadSignClass_TextPattern_Bus=906,
    RoadSignClass_TextPattern_HOV=907,
    RoadSignClass_TextPattern_TIME=908,
    RoadSignClass_TextPattern_WALK=909,
)


class PlannerFrameFigure:
    """Implementation for frame sample visualization."""

    def __init__(
        self,
        gt_range=(-40, 100, -50, 50),
        scale=16,
        color_list=None,
        laneline_style_map=None,
        laneline_color_map=None,
        draw_order=["bev", "base_info"],
        size_info=None,
    ):
        """Init."""
        self.gt_range = gt_range
        self.scale = scale
        self.subplot_size = ((gt_range[1] - gt_range[0]) * scale, (gt_range[3] - gt_range[2]) * scale)
        self.origin_pos = (-gt_range[0] * scale, -gt_range[2] * scale)

        self.color_list = DEFAULT_COLOR_LIST
        if color_list is not None:
            self.color_list.update(color_list)

        self.laneline_style_map = DEFAULT_LANELINE_STYLE_MAP
        if laneline_style_map is not None:
            self.laneline_style_map.update(laneline_style_map)

        self.laneline_color_map = DEFAULT_LANELINE_COLOR_MAP
        if laneline_color_map is not None:
            self.laneline_color_map.update(laneline_color_map)

        self.multi_images = {}
        self.draw_order = draw_order
        if not isinstance(draw_order, list):
            self.draw_order = [self.draw_order]
        for i_column, _ in enumerate(self.draw_order):
            if not isinstance(self.draw_order[i_column], list):
                self.draw_order[i_column] = [self.draw_order[i_column]]

            for i_raw, _ in enumerate(self.draw_order[i_column]):
                subplot_name = self.draw_order[i_column][i_raw]
                if subplot_name == "bev":
                    self.multi_images[subplot_name] = np.full(
                        (self.subplot_size[1], self.subplot_size[0], 3),
                        fill_value=self.color_list["background_bev"],
                        dtype=np.uint8,
                    )
                elif subplot_name == "base_info":
                    self.multi_images[subplot_name] = np.full(
                        (self.subplot_size[1], int(self.subplot_size[0] * 0.375), 3),
                        fill_value=self.color_list["background_info"],
                        dtype=np.uint8,
                    )
                elif subplot_name == "reward_info":
                    self.multi_images[subplot_name] = np.full(
                        (size_info[1], size_info[0], 3),
                        fill_value=self.color_list["background_info"],
                        dtype=np.uint8,
                    )
                else:
                    raise NotImplementedError(f"Unknown subplot name: {subplot_name}")

        self.column_widths = [
            max([self.multi_images[subplot_name].shape[1] for subplot_name in column_order])
            for column_order in self.draw_order
        ]
        self.image_height = max([len(column_order) for column_order in self.draw_order]) * self.subplot_size[1]
        self.image_width = sum(self.column_widths)

        self.roadsign_image = {
            ROADSIGNTYPE["RoadSignClass_RoadArrow_Left"]: cv2.flip(
                255 - cv2.imread("tpp_onemodel/tools/astra_planner/visualization/road_sign_vis_images/arrow_right.png"),
                0,
            ),
            ROADSIGNTYPE["RoadSignClass_RoadArrow_Right"]: 255
            - cv2.imread("tpp_onemodel/tools/astra_planner/visualization/road_sign_vis_images/arrow_right.png"),
            ROADSIGNTYPE["RoadSignClass_RoadArrow_Straight"]: 255
            - cv2.imread("tpp_onemodel/tools/astra_planner/visualization/road_sign_vis_images/arrow_stright.png"),
            ROADSIGNTYPE["RoadSignClass_ZebraCross"]: cv2.imread(
                "tpp_onemodel/tools/astra_planner/visualization/road_sign_vis_images/zebra.png"
            ),
            **{
                type_val: self.construct_text_roadsign_image(type.split("_")[-1][:4])
                for type, type_val in ROADSIGNTYPE.items()
                if "_TextPattern_" in type
            },
        }

    def return_image(self, resize_flag=True):
        """Dump image."""
        column_images = []
        for i_column, _ in enumerate(self.draw_order):
            column_image = []
            for subplot_name in self.draw_order[i_column]:
                subplot = self.multi_images[subplot_name]
                if resize_flag:
                    subplot = self.padding_and_resize(subplot, (self.column_widths[i_column], self.subplot_size[1]))
                column_image.append(subplot)
            column_image = np.concatenate(column_image, axis=0)
            if column_image.shape[0] < self.image_height:
                column_image = cv2.copyMakeBorder(
                    column_image,
                    0,
                    self.image_height - column_image.shape[0],
                    0,
                    0,
                    cv2.BORDER_CONSTANT,
                    value=(0, 0, 0),
                )
            column_images.append(column_image)
        result_image = np.concatenate(column_images, axis=1)

        return result_image

    def dump_image(self, dump_path):
        """Dump image."""
        column_images = []
        for i_column, _ in enumerate(self.draw_order):
            column_image = []
            for subplot_name in self.draw_order[i_column]:
                subplot = self.multi_images[subplot_name]
                subplot = self.padding_and_resize(subplot, (self.column_widths[i_column], self.subplot_size[1]))
                column_image.append(subplot)
            column_image = np.concatenate(column_image, axis=0)
            if column_image.shape[0] < self.image_height:
                column_image = cv2.copyMakeBorder(
                    column_image,
                    0,
                    self.image_height - column_image.shape[0],
                    0,
                    0,
                    cv2.BORDER_CONSTANT,
                    value=(0, 0, 0),
                )
            column_images.append(column_image)
        result_image = np.concatenate(column_images, axis=1)

        os.makedirs(os.path.dirname(dump_path), exist_ok=True)
        cv2.imwrite(dump_path, result_image)
        logger.warning("Dump image %s", dump_path)

    def draw_base_info(
        self,
        frame_info,
        image_key="base_info",
        org=(40, 0),
        piece_size=50,
        thickness=2,
        font_scale=1,
        color=None,
        pos_interval=3,
    ):
        """Draw base info."""
        if color is None:
            color = self.color_list["info_string"]

        def draw_multiline_text(image, lines, org, font_scale, color, thickness=1):
            cur_pos = [org[0], org[1]]
            for line in lines:
                split_line = [line[i_piece : i_piece + piece_size] for i_piece in range(0, len(line), piece_size)]
                for i_piece in range(1, len(split_line)):
                    split_line[i_piece] = "  " + split_line[i_piece]
                for piece_text in split_line:
                    (_, text_height), _ = cv2.getTextSize(piece_text, cv2.FONT_HERSHEY_SIMPLEX, font_scale, thickness)
                    cur_pos[1] += int(text_height * pos_interval)
                    cv2.putText(
                        img=image,
                        text=piece_text,
                        org=cur_pos,
                        fontFace=cv2.FONT_HERSHEY_SIMPLEX,
                        fontScale=font_scale,
                        color=color,
                        thickness=thickness,
                        lineType=cv2.LINE_AA,
                    )

        image = self.multi_images[image_key]
        frame_info_str = [f"{key}: {value}" for key, value in frame_info.items()]

        draw_multiline_text(
            image,
            frame_info_str,
            org=org,
            font_scale=font_scale,
            color=color,
            thickness=thickness,
        )

    def draw_scale_line(self, stride=(20, 15), image_key="bev"):
        """Draw scale line."""
        image = self.multi_images[image_key]
        image_size = (image.shape[1], image.shape[0])
        stride_pixel = (
            stride[0] * self.scale,
            stride[1] * self.scale,
        )
        max_index = [0, 0]
        start_pos = [0, 0]
        for dim_id in range(2):
            another_dim_id = (dim_id + 1) % 2
            start_point = [0, 0]
            end_point = [image_size[1], image_size[0]]

            max_index[dim_id] = (
                self.origin_pos[another_dim_id] // stride_pixel[another_dim_id]
                + (image_size[another_dim_id] - self.origin_pos[another_dim_id]) // stride_pixel[another_dim_id]
            )
            start_pos[dim_id] = self.origin_pos[another_dim_id] % stride_pixel[another_dim_id]

            for index in range(max_index[dim_id] + 1):
                start_point[dim_id] = start_pos[dim_id] + index * stride_pixel[another_dim_id]
                end_point[dim_id] = start_pos[dim_id] + index * stride_pixel[another_dim_id]

                self.draw_polylines_plus(
                    image,
                    [start_point[::-1], end_point[::-1]],
                    color=self.color_list["scale_line"],
                    thickness=1,
                    linestyle="--",
                )

        for dim_id in range(2):
            another_dim_id = (dim_id + 1) % 2
            text_pos_shift = [-10, 5] if dim_id == 0 else [20, 5]
            text_pos = [
                start_pos[0] + max_index[0] * stride_pixel[1],
                start_pos[1],
            ]
            for index in range(max_index[dim_id] + 1):
                text_pos[dim_id] = start_pos[dim_id] + index * stride_pixel[another_dim_id]
                text_str = str(int(abs(text_pos[dim_id] - self.origin_pos[another_dim_id]) / self.scale)) + "m"

                cv2.putText(
                    img=image,
                    text=text_str,
                    org=(text_pos[1] + text_pos_shift[1], text_pos[0] + text_pos_shift[0]),
                    fontFace=cv2.FONT_HERSHEY_SIMPLEX,
                    fontScale=0.5,
                    color=self.color_list["scale_line"],
                    thickness=1,
                    lineType=cv2.LINE_AA,
                )

    def draw_ego_pos(self, image_key="bev"):
        """Draw ego box."""
        image = self.multi_images[image_key]
        ego_pos = [0.0, 0.0]
        cv2.circle(
            image,
            self.convert_to_pixel(ego_pos),
            4,
            color=self.color_list["ego_box"],
            thickness=-1,
            lineType=cv2.LINE_AA,
        )

    def draw_ego_box(self, image_key="bev"):
        """Draw ego box."""
        ego_box = [1.5, 0.0, 5.0, 2.0, 0]
        self.draw_bbox_xylwh(
            ego_box,
            color=self.color_list["ego_box"],
            thickness=2,
            image_key=image_key,
        )

    def draw_agent_box(self, bbox, image_key="bev", track=False, idx=0):
        """Draw agent box."""
        self.draw_bbox_xylwh(
            bbox,
            color=self.color_list["agent_box"] if not track else (255, 255, 0),
            thickness=2,
            image_key=image_key,
            idx=idx,
        )

    def draw_prior_box(self, bbox, score=None, image_key="bev"):
        """Draw prior box."""
        self.draw_bbox_xylwh(
            bbox,
            color=self.color_list["prior_box"],
            thickness=2,
            image_key=image_key,
        )
        if score:
            area = bbox[2] * bbox[3]
            if area < 1.5:
                offset = np.array([0, -5])
            else:
                offset = np.array([-12, 5])
            cv2.putText(
                img=self.multi_images[image_key],
                text=f"{score:.2f}",
                org=self.convert_to_pixel(bbox[:2]) + offset,
                fontFace=cv2.FONT_HERSHEY_SIMPLEX,
                fontScale=0.5,
                color=self.color_list["prior_box"],
                thickness=1,
                lineType=cv2.LINE_AA,
            )

    def draw_prior_box_corner(self, bbox, bbox_type, image_key="bev"):
        """Draw prior box."""
        self.draw_bbox_corner(
            bbox,
            color=self.color_list["prior_box"],
            thickness=-1,
            radius=5,
            one_point_mode=bbox_type == 500,
            image_key=image_key,
        )

    def draw_not_prior_box(self, bbox, score=None, image_key="bev"):
        """Draw prior box."""
        self.draw_bbox_xylwh(
            bbox,
            color=self.color_list["not_prior_box"],
            thickness=2,
            image_key=image_key,
        )
        if score:
            area = bbox[2] * bbox[3]
            if area < 1.5:
                offset = np.array([0, -5])
            else:
                offset = np.array([-12, 5])
            cv2.putText(
                img=self.multi_images[image_key],
                text=f"{score:.2f}",
                org=self.convert_to_pixel(bbox[:2]) + offset,
                fontFace=cv2.FONT_HERSHEY_SIMPLEX,
                fontScale=0.5,
                color=self.color_list["not_prior_box"],
                thickness=1,
                lineType=cv2.LINE_AA,
            )

    def draw_not_prior_box_corner(self, bbox, bbox_type, image_key="bev"):
        """Draw prior box."""
        self.draw_bbox_corner(
            bbox,
            color=self.color_list["not_prior_box"],
            thickness=-1,
            radius=5,
            one_point_mode=bbox_type == 500,
            image_key=image_key,
        )

    def draw_bbox_corner(
        self,
        bbox,
        color=(0, 0, 0),
        thickness: float = 2,
        radius=3,
        one_point_mode=False,
        image_key="bev",
    ):
        """Draw bbox with tuple (center_x, center_y, length, width, heading)."""
        image = self.multi_images[image_key]
        center_x, center_y, x_length, y_length, angle = bbox
        bbox_corners = self.convert_bbox_xylwh_to_corner_pts(center_x, center_y, x_length, y_length, angle)
        aligned_bbox_corners = (
            [self.convert_to_pixel(bbox_corners)[0]] if one_point_mode else self.convert_to_pixel(bbox_corners)
        )
        for corner in aligned_bbox_corners:
            cv2.circle(
                image,
                tuple(corner),
                radius,
                color=color,
                thickness=thickness,
                lineType=cv2.LINE_AA,
            )

    def draw_bbox_xylwh(self, bbox, color=(0, 0, 0), thickness: float = 2, image_key="bev", idx=0):
        """Draw bbox with tuple (center_x, center_y, length, width, heading)."""
        image = self.multi_images[image_key]
        center_x, center_y, x_length, y_length, angle = bbox
        bbox_corners = self.convert_bbox_xylwh_to_corner_pts(center_x, center_y, x_length, y_length, angle)
        aligned_bbox_corners = self.convert_to_pixel(bbox_corners)
        cv2.polylines(
            image,
            [np.array(aligned_bbox_corners, dtype=np.int32)],
            isClosed=True,
            color=color,
            thickness=thickness,
            lineType=cv2.LINE_AA,
        )

        if idx != 0 and abs(center_x) > 0 and abs(center_y) > 0:
            cv2.putText(
                img=image,
                text=str(idx),
                org=aligned_bbox_corners[0],
                fontFace=cv2.FONT_HERSHEY_SIMPLEX,
                fontScale=1,
                color=(0, 0, 0),
                thickness=thickness,
                lineType=cv2.LINE_AA,
            )

    def draw_atlas(self, point_list, image_key="bev"):
        """Draw atlas."""
        image = self.multi_images[image_key]
        if point_list.shape[0] == 0:
            return
        aligned_point_list = self.convert_to_pixel(point_list[..., :2])
        cv2.fillPoly(
            image,
            pts=[np.array(aligned_point_list, dtype=np.int32)],
            color=self.color_list["atlas"],
        )

    def draw_atlas_outline(self, point_list, image_key="bev"):
        """Draw atlas."""
        self.draw_line(
            point_list=point_list,
            color=self.color_list["atlas"],
            thickness=4,
            draw_point=False,
            image_key=image_key,
        )

    def draw_ego_traj_pred(self, point_list, **kwargs):
        """Draw ego pred trajectory."""
        self.draw_line(point_list, color=self.color_list["ego_traj_pred"], **kwargs)

    def draw_goal_ego_traj_pred(self, point_list, **kwargs):
        """Draw ego pred trajectory."""
        self.draw_line(point_list, color=self.color_list["goal_ego_traj_pred"], **kwargs)

    def draw_ego_traj_gt(self, point_list, **kwargs):
        """Draw ego gt trajectory."""
        self.draw_line(point_list, color=self.color_list["ego_traj_gt"], **kwargs)

    def draw_ar_ego_pos_pred(self, point_list, **kwargs):
        """Draw ego gt trajectory."""
        self.draw_line(point_list, color=self.color_list["ar_ego_pos_pred"], **kwargs)

    def draw_ar_agents_pos_pred(self, point_list, **kwargs):
        """Draw ego gt trajectory."""
        self.draw_line(point_list, color=self.color_list["ar_agents_pos_pred"], **kwargs)

    def draw_align_traj_gt(self, point_list, **kwargs):
        """Draw align trajectory."""
        self.draw_line(point_list, color=(0, 255, 0), **kwargs)

    def draw_drive_path_gt(self, point_list, **kwargs):
        """Draw ego gt trajectory."""
        self.draw_line(point_list, color=self.color_list["drive_path_gt"], **kwargs)

    def draw_drive_path_pred(self, point_list, **kwargs):
        """Draw ego gt trajectory."""
        self.draw_line(point_list, color=self.color_list["drive_path_pred"], **kwargs)

    def draw_ar_drive_path_gt(self, point_list, **kwargs):
        """Draw ego gt trajectory."""
        self.draw_line(point_list, color=self.color_list["ar_drive_path_gt"], **kwargs)

    def draw_ar_drive_path_pred(self, point_list, **kwargs):
        """Draw ego gt trajectory."""
        self.draw_line(point_list, color=self.color_list["ar_drive_path_pred"], **kwargs)

    def draw_tld_e2e(self, tld, image_key="bev"):
        """Draw tld e2e."""
        if tld is None:
            return
        image = self.multi_images[image_key]
        image_h, image_w, _ = image.shape
        u_pos = image_w - int(0.25 * image_w)
        v_pos = 10
        tld_circle_pos = [
            (u_pos + int(0.25 * image_w) // 4 * idx, v_pos + int(0.05 * image_h)) for idx in range(4)
        ]  # 4 circle positions
        if tld.shape[0] == 0:
            tld_vis = np.full((4), 5)
            # tld_sec = [None, None, None, None]
        else:
            tld_vis = tld[:4].astype(int)
            # tld_sec = [sec if sec != 65535 else None for sec in tld[8:12].astype(int)]
        arrow_start = {
            "left": (u_pos + DEFAULT_TLD_RIDUS - 3, v_pos + int(0.05 * image_h)),
            "uturn": (
                u_pos + int(0.25 * image_w) // 4 * 1 - DEFAULT_TLD_RIDUS // 2,
                v_pos + int(0.05 * image_h) - DEFAULT_TLD_RIDUS // 2 + 10,
            ),
            "straight": (u_pos + int(0.25 * image_w) // 4 * 2, v_pos + int(0.05 * image_h) + DEFAULT_TLD_RIDUS - 3),
            "right": (u_pos + int(0.25 * image_w) // 4 * 3 - DEFAULT_TLD_RIDUS + 3, v_pos + int(0.05 * image_h)),
        }
        arrow_end = {
            "left": (u_pos - DEFAULT_TLD_RIDUS + 3, v_pos + int(0.05 * image_h)),
            "uturn": (
                u_pos + int(0.25 * image_w) // 4 * 1 - DEFAULT_TLD_RIDUS // 2,
                v_pos + int(0.05 * image_h) + DEFAULT_TLD_RIDUS // 2 + 10,
            ),
            "straight": (u_pos + int(0.25 * image_w) // 4 * 2, v_pos + int(0.05 * image_h) - DEFAULT_TLD_RIDUS + 3),
            "right": (u_pos + int(0.25 * image_w) // 4 * 3 + DEFAULT_TLD_RIDUS - 3, v_pos + int(0.05 * image_h)),
        }

        for idx, arrow_type in enumerate(["left", "uturn", "straight", "right"]):
            cv2.circle(
                image,
                tld_circle_pos[idx],
                DEFAULT_TLD_RIDUS,
                color=self.color_list["tld_external_color"],
                thickness=7,
                lineType=cv2.LINE_AA,
            )
            cv2.circle(
                image,
                tld_circle_pos[idx],
                DEFAULT_TLD_RIDUS,
                color=self.color_list["default_tld_color"][tld_vis[idx]],
                thickness=-1,
                lineType=cv2.LINE_AA,
            )
            cv2.arrowedLine(
                image,
                arrow_start[arrow_type],
                arrow_end[arrow_type],
                color=DEFAULT_COLOR_LIST["tld_arrow_color"],
                thickness=3,
                line_type=cv2.LINE_AA,
                tipLength=0.4,
            )
            if arrow_type == "uturn":
                cv2.line(
                    image,
                    (arrow_start[arrow_type][0] + DEFAULT_TLD_RIDUS - 1, arrow_start[arrow_type][1]),
                    (arrow_end[arrow_type][0] + DEFAULT_TLD_RIDUS - 1, arrow_end[arrow_type][1]),
                    color=DEFAULT_COLOR_LIST["tld_arrow_color"],
                    thickness=3,
                    lineType=cv2.LINE_AA,
                )
                cv2.ellipse(
                    image,
                    (u_pos + int(0.25 * image_w) // 4 * 1, v_pos + int(0.05 * image_h) - DEFAULT_TLD_RIDUS // 2 + 10),
                    (DEFAULT_TLD_RIDUS // 2, DEFAULT_TLD_RIDUS // 2),
                    0,
                    180,
                    360,
                    color=DEFAULT_COLOR_LIST["tld_arrow_color"],
                    thickness=3,
                    lineType=cv2.LINE_AA,
                )

    def draw_control_point(self, control_point, image_key="bev"):
        """Draw control point."""
        if control_point is None:
            return
        image = self.multi_images[image_key]
        for idx in range(control_point.shape[0]):
            cv2.circle(
                image,
                self.convert_to_pixel(control_point[idx][:2]),
                10,
                color=DEFAULT_COLOR_LIST["control_point"][np.where(control_point[idx][-2:] == 1)[0][0]],
                thickness=-1,
                lineType=cv2.LINE_AA,
            )
            if np.where(control_point[idx][-2:] == 1)[0][0] == 1:
                heading_x = control_point[idx][2]
                heading_y = control_point[idx][3]
                vel = control_point[idx][4]
                if (not (heading_x == -1 and heading_x == -1)) and vel != -1:
                    vx = heading_x * vel
                    vy = heading_y * vel
                    if np.sqrt(vx**2 + vy**2) > 1e-3:
                        cv2.arrowedLine(
                            image,
                            self.convert_to_pixel(control_point[idx][:2]),
                            self.convert_to_pixel(control_point[idx][:2] + np.array([vx, vy]) * 0.5),
                            color=DEFAULT_COLOR_LIST["control_point"][2],
                            thickness=3,
                            line_type=cv2.LINE_AA,
                            tipLength=0.25,
                        )
                    else:
                        cv2.line(
                            image,
                            self.convert_to_pixel(control_point[idx][:2] + np.array([0, 1.0])),
                            self.convert_to_pixel(control_point[idx][:2] - np.array([0, 1.0])),
                            color=DEFAULT_COLOR_LIST["control_point"][2],
                            thickness=3,
                            lineType=cv2.LINE_AA,
                        )
                elif (not (heading_x == -1 and heading_y == -1)) and vel == -1:
                    cv2.arrowedLine(
                        image,
                        self.convert_to_pixel(control_point[idx][:2]),
                        self.convert_to_pixel(control_point[idx][:2] + control_point[idx][2:4] * 5),
                        color=DEFAULT_COLOR_LIST["control_point_heading"],
                        thickness=3,
                        line_type=cv2.LINE_AA,
                        tipLength=0.25,
                    )
                cv2.putText(
                    img=image,
                    text=f"V: {vel:.2f}" if vel != -1 else f"V: None",
                    org=self.convert_to_pixel(control_point[idx][:2]) + np.array([0, -10]),
                    fontFace=cv2.FONT_HERSHEY_SIMPLEX,
                    fontScale=1,
                    color=DEFAULT_COLOR_LIST["control_point_heading"],
                    thickness=3,
                    lineType=cv2.LINE_AA,
                )

    def draw_navi_lane(self, point_list, **kwargs):
        """Draw navi lane."""
        self.draw_line(
            point_list, color=self.color_list["navi_lane"], thickness=4, transparent=0.5, draw_point=False, **kwargs
        )

    def draw_navi_path(self, point_list, **kwargs):
        """Draw navi lane."""
        self.draw_line(
            point_list, color=self.color_list["navi_path"], thickness=20, transparent=0.2, draw_point=False, **kwargs
        )

    def draw_scene_tag(self, scene_tag, image_key="bev"):
        image = self.multi_images[image_key]
        cv2.putText(
            img=image,
            text=scene_tag,
            org=(50, 70),
            fontFace=cv2.FONT_HERSHEY_SIMPLEX,
            fontScale=3,
            color=self.color_list["scene_tag"],
            thickness=3,
            lineType=cv2.LINE_AA,
        )

    def draw_lane_roadsign(
        self,
        lane_points,
        lane_types,
        lane_attrs,
        draw_key=["laneline", "curb", "stopline", "roadsign"],
        image_key="bev",
    ):
        """Draw lane and roadsign."""
        for i_line, (single_lane_points, single_lane_types, single_lane_attrs) in enumerate(
            zip(lane_points, lane_types, lane_attrs)
        ):
            cur_lane_type = int(single_lane_types)
            if cur_lane_type not in [0, 1, 2, 3]:
                continue
            if "laneline" in draw_key and cur_lane_type == 0:  # laneline
                color = []
                thickness = []
                linestyle = []
                for attr in single_lane_attrs:
                    color.append(self.laneline_color_map.get(attr[1], (255, 0, 0)))
                    thickness.append(
                        self.laneline_style_map.get(attr[0], {"thickness": 2, "linestyle": "-."})["thickness"]
                    )
                    linestyle.append(
                        self.laneline_style_map.get(attr[0], {"thickness": 2, "linestyle": "-."})["linestyle"]
                    )
                self.draw_laneline_with_attr(
                    single_lane_points,
                    color=color,
                    thickness=thickness,
                    linestyle=linestyle,
                    image_key=image_key,
                )
            elif "curb" in draw_key and cur_lane_type == 1:  # curb
                self.draw_curb(
                    single_lane_points,
                    thickness=2,
                    line_str=str(i_line),
                    draw_point=False,
                )
            elif "stopline" in draw_key and cur_lane_type == 2:  # stopline
                self.draw_stopline(
                    single_lane_points,
                    thickness=2,
                    line_str=str(i_line),
                    draw_point=False,
                )
            elif "roadsign" in draw_key and cur_lane_type == 3:  # stopline
                self.draw_roadsign(
                    single_lane_points,
                    single_lane_attrs,
                    image_key=image_key,
                )

    def draw_laneline(self, point_list, **kwargs):
        """Draw laneline."""
        self.draw_line(point_list, color=self.color_list["laneline"], **kwargs)

    def draw_laneline_with_attr(self, point_list, image_key="bev", **kwargs):
        """Draw laneline."""
        image = self.multi_images[image_key]
        aligned_point_list = self.convert_to_pixel(point_list[..., :2])
        self.draw_polylines_plus(image, aligned_point_list, **kwargs)

    def draw_curb(self, point_list, **kwargs):
        """Draw curb."""
        self.draw_line(point_list, color=self.color_list["curb"], **kwargs)

    def draw_stopline(self, point_list, **kwargs):
        """Draw stopline."""
        self.draw_line(point_list, color=self.color_list["stopline"], **kwargs)

    def draw_navi_lane_with_tld(self, point_list, color, **kwargs):
        """Draw navi lane."""
        self.draw_line(point_list, color=color, thickness=12, transparent=0.3, draw_point=False, **kwargs)

    def draw_navi_path_with_tld(self, point_list, color, **kwargs):
        """Draw navi lane."""
        self.draw_line(point_list, color=color, thickness=20, transparent=0.2, draw_point=False, **kwargs)

    def draw_other_ego_pred_gt(self, point_list, color=(180, 180, 180), **kwargs):
        """Draw ego gt trajectory."""
        self.draw_line(point_list, color, **kwargs)

    def draw_ego_box_on_traj(self, ego_centers, ego_headings, ego_vels, image_key="bev"):
        future_step = ego_centers.shape[0]
        ego_sizes = np.array([5.101, 2.178], dtype=np.float32)  # fixed
        ego_sizes = np.repeat(ego_sizes.reshape(1, 2), future_step, axis=0)

        ego_corners = (
            get_box_corners(
                torch.from_numpy(ego_centers).reshape(1, 1, future_step, 2),
                torch.from_numpy(ego_headings).reshape(1, 1, future_step, 1),
                torch.from_numpy(ego_vels).reshape(1, 1, future_step, 2),
                torch.from_numpy(ego_sizes).reshape(1, 1, future_step, 2),
                dynamic_padding=True,
            )
            .squeeze()
            .numpy()
        )  # [T, 4, 2]

        for i in range(future_step):
            corners = self.convert_to_pixel(ego_corners[i])
            cv2.polylines(
                self.multi_images[image_key],
                [np.array(corners, dtype=np.int32)],
                isClosed=True,
                color=(0, 0, 255),
                thickness=2,
                lineType=cv2.LINE_AA,
            )

    def draw_ego_sample_dot(self, point_pos=[0, 0], color=(0, 0, 0), image_key="bev"):
        """Draw space dot."""
        image = self.multi_images[image_key]

        cv2.circle(
            image,
            self.convert_to_pixel(point_pos),
            5,  # radius
            color=color,
            thickness=-1,
            lineType=cv2.LINE_AA,
        )

    def draw_line(
        self,
        point_list: List,
        color=(0, 0, 0),
        thickness: float = 1,
        transparent: float = 1,
        line_str: Optional[Union[str, List[str]]] = None,
        draw_point: bool = True,
        use_line_color: bool = True,
        point_color=None,
        pt_str: Optional[List[str]] = None,
        image_key="bev",
        agent_collision=None,
        lane_collision=None,
        traj_mask=None,
    ):
        """Draw line."""
        if len(point_list) == 0:
            return
        image = self.multi_images[image_key]

        if isinstance(color[0], (tuple, list)) and len(color) != len(point_list):
            raise ValueError(
                f"Length of color list should be sample as point list. Found: {len(color)} vs. {len(point_list)}"
            )
        if pt_str and len(pt_str) != len(point_list):
            raise ValueError(
                f"Length of pt_str list should be sample as point list. Found: {len(color)} vs. {len(point_list)}"
            )

        if not isinstance(color[0], (tuple, list)):
            color = [color] * len(point_list)

        if agent_collision is not None and lane_collision is not None:
            assert len(agent_collision) == len(point_list)
            assert len(lane_collision) == len(point_list)
            for i in range(len(point_list)):
                if agent_collision[i] > 0.5 and lane_collision[i] > 0.5:
                    color[i] = self.color_list["agents_lane_collision"]
                elif agent_collision[i] > 0.5 and lane_collision[i] < 0.5:
                    color[i] = self.color_list["agents_only_collision"]
                elif agent_collision[i] < 0.5 and lane_collision[i] > 0.5:
                    color[i] = self.color_list["lane_only_collision"]
                else:
                    pass

        if draw_point and use_line_color:
            point_color = color
        elif draw_point and not isinstance(point_color[0], (tuple, list)):
            point_color = [point_color] * len(point_list)

        aligned_point_list = self.convert_to_pixel(point_list[..., :2])  # type: ignore[call-overload]
        aligned_point_list = [x for x in aligned_point_list if x != (self.origin_pos[0], self.origin_pos[1])]

        if len(aligned_point_list) == 0:
            return

        for idx, _ in enumerate(aligned_point_list):
            startpoint = aligned_point_list[idx]
            endpoint = aligned_point_list[idx + 1] if idx < len(aligned_point_list) - 1 else aligned_point_list[0]

            startpoint_x, startpoint_y = int(startpoint[0]), int(startpoint[1])
            endpoint_x, endpoint_y = int(endpoint[0]), int(endpoint[1])
            if np.abs(np.array([startpoint_x, startpoint_y, endpoint_x, endpoint_y])).max() > 10000:
                continue

            if idx < len(aligned_point_list) - 1:
                self.draw_with_transparent(
                    cv2.line,
                    image,
                    (startpoint_x, startpoint_y),
                    (endpoint_x, endpoint_y),
                    color[idx],
                    thickness=thickness,
                    lineType=cv2.LINE_AA,
                    transparent=transparent,
                )
            if draw_point:
                ignored = traj_mask[idx] == 0 if traj_mask is not None else False
                self.draw_with_transparent(
                    cv2.circle,
                    image,
                    (startpoint_x, startpoint_y),
                    thickness * 4,
                    point_color[idx],
                    1 if ignored else -1,
                    lineType=cv2.LINE_AA,
                    transparent=transparent,
                )
                if idx < len(aligned_point_list) - 1:
                    ignored = traj_mask[idx + 1] == 0 if traj_mask is not None else False
                    self.draw_with_transparent(
                        cv2.circle,
                        image,
                        (endpoint_x, endpoint_y),
                        thickness * 4,
                        point_color[idx + 1],
                        1 if ignored else -1,
                        lineType=cv2.LINE_AA,
                        transparent=transparent,
                    )
                if pt_str is not None:
                    cv2.putText(
                        img=image,
                        text=pt_str[idx],
                        org=(startpoint_x + 5, startpoint_y + 15),
                        fontFace=cv2.FONT_HERSHEY_SIMPLEX,
                        fontScale=0.5,
                        color=self.color_list["line_string"],
                        thickness=1,
                        lineType=cv2.LINE_AA,
                    )

        if line_str is not None:
            pos = len(aligned_point_list) - 1
            line_str_pos_x = None
            while pos >= 0:
                line_str_pos_x, line_str_pos_y = int(aligned_point_list[pos][0]), int(aligned_point_list[pos][1])
                if np.abs(np.array([line_str_pos_x, line_str_pos_y])).max() > 10000:
                    break
                if 0 < line_str_pos_x < image.shape[1] - 20 and 20 < line_str_pos_y < image.shape[0] - 0:
                    break
                pos -= 1
            if line_str_pos_x is not None:
                cv2.putText(
                    img=image,
                    text=line_str,
                    org=(line_str_pos_x + 5, line_str_pos_y - 5),
                    fontFace=cv2.FONT_HERSHEY_SIMPLEX,
                    fontScale=0.5,
                    color=self.color_list["line_string"],
                    thickness=1,
                    lineType=cv2.LINE_AA,
                )

    def draw_roadsign(self, lane_point, lane_attr, image_key="bev"):
        """Draw road edge."""
        image = self.multi_images[image_key]
        vis_cor_points = self.convert_to_pixel(lane_point)

        roadsign_type = lane_attr[0][0]
        type_image = self.roadsign_image.get(int(roadsign_type), None)

        if type_image is None:
            attr_image = np.zeros((30, 80, 3), dtype=np.uint8)
            type_image = cv2.putText(
                attr_image,
                f"{roadsign_type}",
                (5, 28),
                cv2.FONT_HERSHEY_SIMPLEX,
                1,
                (255, 255, 255),
                3,
                cv2.LINE_AA,
            )
        affine_matrix = cv2.getAffineTransform(
            np.float32([[0, 0], [type_image.shape[1], 0], [0, type_image.shape[0]]]),
            np.float32([vis_cor_points[0], vis_cor_points[3], vis_cor_points[1]]),
        )
        trans_image = cv2.warpAffine(type_image, affine_matrix, (image.shape[1], image.shape[0]))
        trans_image_mask = (trans_image[:, :, 0] > 50) | (trans_image[:, :, 1] > 50) | (trans_image[:, :, 2] > 50)
        image[trans_image_mask] = trans_image[trans_image_mask]

        image = cv2.polylines(
            image,
            [np.array(vis_cor_points, dtype=np.int32)],
            isClosed=True,
            color=self.color_list["roadsign_box"],
            thickness=2,
            lineType=cv2.LINE_AA,
        )
        return image

    def convert_to_pixel(self, pts):
        """Convert coord to pixel."""
        if isinstance(pts, (torch.Tensor, np.ndarray)):
            pts = pts.tolist()
        recovery = False
        if not isinstance(pts[0], (tuple, list)):
            pts = [pts]
            recovery = True
        new_pts = []
        for pt in pts:
            point_x, point_y = pt
            new_point_x = point_x * self.scale + self.origin_pos[0]
            new_point_y = -point_y * self.scale + self.origin_pos[1]
            new_pts.append((int(new_point_x), int(new_point_y)))

        if len(new_pts) == 1 and recovery:
            return new_pts[0]
        return new_pts

    def convert_bbox_xylwh_to_corner_pts(self, center_x, center_y, x_length, y_length, angle):
        """Convert bbox xylwh to corner points."""
        theta = angle
        half_x_length = x_length / 2
        half_y_length = y_length / 2
        corners = np.array(
            [
                [-half_x_length, -half_y_length],
                [half_x_length, -half_y_length],
                [half_x_length, half_y_length],
                [-half_x_length, half_y_length],
            ]
        )

        rotation_matrix = np.array([[np.cos(theta), -np.sin(theta)], [np.sin(theta), np.cos(theta)]])
        rotated_corners = rotation_matrix @ corners.T
        rotated_corners = rotated_corners.T
        rotated_corners += np.array([center_x, center_y])
        return rotated_corners

    def draw_polylines_plus(
        self,
        image,
        pts,
        color,
        thickness,
        linestyle="-",
        gap=16,
    ):
        """Draw polylines."""

        def get_rotation_matrix(theta):
            return np.array([[np.cos(theta), -np.sin(theta)], [np.sin(theta), np.cos(theta)]])

        def angle(v1, v2):
            ang = np.arccos(v1 @ v2 / (np.linalg.norm(v1) * np.linalg.norm(v2)))
            return -1 * np.sign(np.cross(v1, v2)) * ang

        def subdivide_linestring(points: np.ndarray, gap=16):
            cumsum_dist = np.cumsum(np.linalg.norm(points[:-1] - points[1:], axis=1))
            x = np.linspace(0, cumsum_dist[-1], int(cumsum_dist[-1] / gap))
            samples = np.vstack([x, np.zeros_like(x)]).T

            d = [0] + cumsum_dist.tolist()
            xy = []
            for i in range(len(points) - 1):
                p0, p1 = points[[i, i + 1]]
                # can be done more efficiently
                m = np.bitwise_and(d[i] - np.finfo(float).eps < x, x < d[i + 1])
                rotation_matrix = get_rotation_matrix(angle(p1 - p0, [1, 0]))
                xy.append(p0 + (samples[m] - [d[i], 0]) @ rotation_matrix.T)
            xy.append(points[-1])
            return np.vstack(xy)

        def padding_endpoint(pts, padding_length):
            length_start = ((pts[1][0] - pts[0][0]) ** 2 + (pts[1][1] - pts[0][1]) ** 2) ** 0.5
            shift_start = [
                int(pts[0][0] - padding_length * ((pts[1][0] - pts[0][0]) / length_start)),
                int(pts[0][1] - padding_length * ((pts[1][1] - pts[0][1]) / length_start)),
            ]
            length_end = ((pts[-1][0] - pts[-2][0]) ** 2 + (pts[-1][1] - pts[-2][1]) ** 2) ** 0.5
            shift_end = [
                int(pts[-1][0] + padding_length * ((pts[-1][0] - pts[-2][0]) / length_end)),
                int(pts[-1][1] + padding_length * ((pts[-1][1] - pts[-2][1]) / length_end)),
            ]
            pts_shift = np.concatenate([np.array([shift_start]), pts, np.array([shift_end])])
            return pts_shift

        if isinstance(color, list) or isinstance(thickness, list) or isinstance(linestyle, list):
            if not isinstance(color, list):
                color = [color]
            if not isinstance(thickness, list):
                thickness = [thickness]
            if not isinstance(linestyle, list):
                linestyle = [linestyle]
            max_scale = max([len(color), len(thickness), len(linestyle)])
            color = color * (max_scale // len(color))
            thickness = thickness * (max_scale // len(thickness))
            linestyle = linestyle * (max_scale // len(linestyle))

            pointwise_attr = np.array(list(map(list, zip(*(color, thickness, linestyle)))))
            if len(pointwise_attr) <= 2:
                change_pts = [0, len(pointwise_attr) - 1]
            else:
                attr = pointwise_attr[:-1]
                change_pts = list(np.where(np.logical_not((attr[:-1] == attr[1:]).all(axis=1)))[0] + 1)
                if len(change_pts) == 0:
                    change_pts = [0, len(pointwise_attr) - 1]
                else:
                    change_pts = [0] + change_pts + [len(pointwise_attr) - 1]
            for start_pos, end_pos in zip(change_pts[:-1], change_pts[1:]):
                self.draw_polylines_plus(
                    image,
                    pts[start_pos : end_pos + 1],
                    color[start_pos],
                    thickness[start_pos],
                    linestyle[start_pos],
                    gap=gap,
                )
            return

        if linestyle not in ["-", "=", "-.", "--", "==", ":"]:
            raise NotImplementedError(f"Linestyle: {linestyle} not implemented.")

        xy = pts if linestyle == "-" or linestyle == "=" else subdivide_linestring(np.array(pts), gap)
        xy = np.rint(xy).astype(int)

        if linestyle == "-":
            for p1, p2 in zip(xy[:-1], xy[1:]):
                cv2.line(image, p1, p2, color, thickness, lineType=cv2.LINE_AA)
        elif linestyle == "=":
            for p1, p2 in zip(xy[:-1], xy[1:]):
                cv2.line(image, p1, p2, color, thickness * 3, lineType=cv2.LINE_AA)
            xy_shift = padding_endpoint(xy, thickness)
            for p1, p2 in zip(xy_shift[:-1], xy_shift[1:]):
                cv2.line(image, p1, p2, self.color_list["background_bev"], thickness, lineType=cv2.LINE_AA)
        elif linestyle == "--":
            for i, (p1, p2) in enumerate(zip(xy[:-1], xy[1:])):
                if (i + 1) % 2:
                    cv2.line(image, p1, p2, color, thickness, lineType=cv2.LINE_AA)
        elif linestyle == "==":
            for i, (p1, p2) in enumerate(zip(xy[:-1], xy[1:])):
                if (i + 1) % 2:
                    cv2.line(image, p1, p2, color, thickness * 3, lineType=cv2.LINE_AA)
            xy_shift = padding_endpoint(xy, thickness)
            for i, (p1, p2) in enumerate(zip(xy[:-1], xy[1:])):
                cv2.line(image, p1, p2, self.color_list["background_bev"], thickness, lineType=cv2.LINE_AA)
        elif linestyle == ":":
            for p in xy:
                cv2.circle(image, p, thickness, color, -1, lineType=cv2.LINE_AA)
        elif linestyle == "-.":
            for i in range(len(xy) - 1):
                if (i % 4) == 0:
                    cv2.line(image, *xy[[i, i + 1]], color, thickness, lineType=cv2.LINE_AA)
                if (i % 4) == 2:
                    p = np.rint(xy[i] + (xy[i + 1] - xy[i]) / 2).astype(int)  # interpolation
                    cv2.circle(image, p, thickness, color, -1, lineType=cv2.LINE_AA)

    @staticmethod
    def draw_with_transparent(
        function,
        image,
        *args,
        transparent=1,
        **kwargs,
    ):
        """Draw figure with transparent."""
        if transparent == 1:
            function(
                image,
                *args,
                **kwargs,
            )
            return
        image_copy = image.copy()
        function(
            image_copy,
            *args,
            **kwargs,
        )
        image[:] = cv2.addWeighted(image, 1 - transparent, image_copy, transparent, 0)

    @staticmethod
    def padding_and_resize(image, target_size, pad_value=0, interpolation=cv2.INTER_LINEAR):
        """Pad and resize image."""
        h, w = image.shape[:2]
        target_w, target_h = target_size
        if h == target_h and w == target_w:
            return image
        if h / w > target_h / target_w:
            new_h = target_h
            new_w = int(w * target_h / h)
        else:
            new_w = target_w
            new_h = int(h * target_w / w)
        image = cv2.resize(image, (new_w, new_h), interpolation=interpolation)
        if new_h == target_h:
            pad_top = 0
            pad_bottom = 0
            pad_left = (target_w - new_w) // 2
            pad_right = target_w - new_w - pad_left
        else:
            pad_top = (target_h - new_h) // 2
            pad_bottom = target_h - new_h - pad_top
            pad_left = 0
            pad_right = 0
        image = cv2.copyMakeBorder(
            image,
            pad_top,
            pad_bottom,
            pad_left,
            pad_right,
            cv2.BORDER_CONSTANT,
            value=pad_value,
        )
        return image

    @staticmethod
    def construct_text_roadsign_image(text):
        """Construct text road sign image."""
        image = np.zeros((30, 80, 3), dtype=np.uint8)
        image = cv2.putText(
            image,
            text,
            (5, 28),
            cv2.FONT_HERSHEY_SIMPLEX,
            1,
            (255, 255, 255),
            3,
            cv2.LINE_AA,
        )
        return image
