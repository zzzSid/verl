# -*- coding: utf-8 -*-
"""Opencv version of astra planner visualize tools."""
import logging
import os
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import cv2
import numpy as np
import torch
from shapely.geometry import LineString

from tpp_onemodel.tools.astra_planner.visualization.planner_frame_figure import (
    PlannerFrameFigure,
)


logger = logging.getLogger(__name__)

DRAW_KEYS = [
    "ego_traj_pred",
    "ego_traj_pred_all",
    "goal_point_ego_traj_pred",
    "ego_traj_gt",
    "ego_box",
    "agent_box",
    "atlas",
    "navi_path",
    "laneline",
    "curb",
    "stopline",
    "ego_vel",
    "tld",
    "navi_path_tld",
    "ego_pred_info",
    "control_point",
    "od_prior_gt",
    "od_prior_pred",
]

junction_color_to_bgr = {
    0: (255, 0, 255),  # Unknown - 设为Purple
    1: (0, 0, 150),  # Red - BGR中红色的表示
    2: (0, 255, 255),  # Yellow - BGR中黄色的表示
    3: (0, 150, 0),  # Green - BGR中绿色的表示
    4: (128, 128, 128),  # Gray - 灰色
}


COLOR_LIST = {
    "background_bev": (255, 255, 255),  # White
    "background_info": (0, 0, 0),  # Black
    "info_string": (255, 255, 255),  # White
    "scale_line": (100, 100, 100),  # Gray
    "ego_traj_pred": (255, 0, 0),  # Blue
    "ego_traj_gt": (0, 0, 255),  # Green
    "ego_box": (0, 255, 0),  # Green
    "agent_box": (255, 0, 0),  # Blue
    "atlas": (180, 180, 180),  # Gray
    "navi_lane": (255, 0, 255),  # Purple
    "navi_path": (255, 255, 0),  # Purple
    "laneline": (0, 192, 255),  # Yellow
    "curb": (0, 0, 0),  # Black
    "stopline": (0, 0, 255),  # Red
    "line_string": (0, 0, 0),  # Black
}


def get_head_tail_points(line, distance=5):
    """
    Retrieve two points of specified length at the beginning and end from the given LineString object.

    : Paramline: LineString object, representing a polyline
    : param distance:  The length of the head and end to be truncated is 5 by default
    : return:  A tuple containing the first two points and the last two points,
                each point in the form of (x, y) coordinates.
                If the total length is less than distance * 2, an empty list is returned.
    """
    line = LineString(line)
    # 获取总长度
    total_length = line.length

    # 处理头部长度对应的点
    if total_length < distance * 2:
        return [], []
    # 沿着线的方向进行线性插值获取头部长度处的点
    current_length = 0
    coords = list(line.coords)
    for i in range(len(coords) - 1):
        segment = LineString([coords[i], coords[i + 1]])
        segment_length = segment.length
        if current_length + segment_length > distance:
            alpha = (distance - current_length) / segment_length
            interp_point = (
                coords[i][0] + alpha * (coords[i + 1][0] - coords[i][0]),
                coords[i][1] + alpha * (coords[i + 1][1] - coords[i][1]),
            )
            head_points = [coords[0], interp_point]
            break
        current_length += segment_length

    # 处理末尾长度对应的点
    reversed_coords = list(line.coords)[::-1]
    current_length = 0
    for i in range(len(reversed_coords) - 1):
        segment = LineString([reversed_coords[i], reversed_coords[i + 1]])
        segment_length = segment.length
        if current_length + segment_length > distance:
            beta = (distance - current_length) / segment_length
            interp_point = (
                reversed_coords[i][0] + beta * (reversed_coords[i + 1][0] - reversed_coords[i][0]),
                reversed_coords[i][1] + beta * (reversed_coords[i + 1][1] - reversed_coords[i][1]),
            )
            tail_points = [interp_point, reversed_coords[0]]
            break
        current_length += segment_length

    return head_points, tail_points


def get_closest_point(points):
    """Get the closest navi_lane points to ego."""
    # Calculate distances from the origin (0, 0)
    origin = np.array([0, 0])
    distances = np.linalg.norm(points - origin, axis=1)

    # Find the index of the closest point
    closest_index = np.argmin(distances)

    # Get the closest point and its distance
    closest_point = points[closest_index]
    closest_distance_y = np.abs(closest_point[1])
    # print(f"Closest point: {closest_point}, distance: {closest_distance}")
    # if closest_point[0] == -1 and closest_point[1] == -1:
    #     closest_distance = 99999
    return closest_point, closest_distance_y


def get_closest_navi_lane_index(navi_line_points):
    """Get the closest navi_lane_index, if there is no navi_lane close to the ego, return -1."""
    current_navi_lane_index = -1
    closest_distance_y_list = []
    navi_num = navi_line_points.shape[0] if isinstance(navi_line_points, np.ndarray) else len(navi_line_points)
    if navi_num == 0:
        return current_navi_lane_index
    for navi_i in range(navi_num):
        points = navi_line_points[navi_i]

        mask = ~(((points[:, 0] == 0.0) & (points[:, 1] == 0.0)) | ((points[:, 0] == -1.0) & (points[:, 1] == -1.0)))

        # Use the mask to filter out the rows
        points = points[mask]
        if len(points) == 0:
            closest_distance_y = 999999
            closest_distance_y_list.append(closest_distance_y)
            continue
        if isinstance(points, torch.Tensor):
            points = points.detach().cpu().numpy()
        points = np.float32(points)
        closest_point, closest_distance_y = get_closest_point(points)
        closest_distance_y_list.append(closest_distance_y)

    if min(closest_distance_y_list) < 2:
        current_navi_lane_index = closest_distance_y_list.index(min(closest_distance_y_list))
    return current_navi_lane_index


def plot_collision_line(start_idx, end_idx, frame_sample, frame_figure, ego_traj_mask):
    """Plot collision lines and intersection points.

    This function draws lines representing agent trajectories and lane lines
    on a frame figure, and highlights the intersection points between these lines.

    Args:
        start_idx (int): The starting index of the trajectory.
        end_idx (int): The ending index of the trajectory.
        frame_sample (dict): A dictionary containing the frame sample data.
            - "agents_line_dict" (dict): A dictionary where keys are trajectory indices
              and values are lists of agent line information.
            - "lane_line_dict" (dict): A dictionary where keys are trajectory indices
              and values are lists of lane line information.
        frame_figure (object): An object representing the frame figure with methods to draw lines and dots.
            - draw_line (method): Method to draw a line on the figure.
            - draw_ego_sample_dot (method): Method to draw a dot on the figure.
            - color_list (dict): A dictionary containing color information for different elements.
        ego_traj_mask (array-like): A mask to apply to the ego trajectory.

    Returns:
        None
    """
    agents_line_list = []
    for traj_idx in range(start_idx, end_idx):
        agents_line_list.extend(frame_sample["agents_line_dict"].get(traj_idx, []))

    for line_info in agents_line_list:
        frame_figure.draw_line(
            np.stack((line_info[0], line_info[1]), axis=0),
            color=frame_figure.color_list["ego_traj_gt"],
            image_key="bev",
            thickness=1,
            transparent=0.5,
            traj_mask=ego_traj_mask,
        )

    lane_line_list = []
    for traj_idx in range(start_idx, end_idx):
        lane_line_list.extend(frame_sample["lane_line_dict"].get(traj_idx, []))

    for line_info in lane_line_list:
        frame_figure.draw_line(
            np.stack((line_info[0], line_info[1]), axis=0),
            color=frame_figure.color_list["laneline"],
            image_key="bev",
            thickness=1,
            transparent=0.5,
            traj_mask=ego_traj_mask,
        )

    def find_intersection(list1, list2):
        intersection = [item1[0] for item1 in list1 if any(np.array_equal(item1[0], item2[0]) for item2 in list2)]
        return intersection

    intersection_points = find_intersection(agents_line_list, lane_line_list)
    for point in intersection_points:
        frame_figure.draw_ego_sample_dot(point, frame_figure.color_list["agent_lane_line"], image_key="bev")


def visualize_single_frame_sample_2stage(
    dump_folder: str,
    frame_sample: Dict[str, Any],
    gt_range=(-40, 100, -50, 50),
    scale=16,
    draw_2stage_cfg: Optional[Dict[str, Any]] = None,
    plot_reward_type="gt",
):
    """Visualizes a single frame sample in a two-stage process.

    Args:
        dump_folder (str): The folder where the visualization will be saved.
        frame_sample (Dict[str, Any]): The frame sample data containing various information such as ego trajectory, agent boxes, etc.
        gt_range (tuple, optional): The ground truth range for the visualization. Defaults to (-40, 100, -50, 50).
        scale (int, optional): The scale of the visualization. Defaults to 16.
        draw_2stage_cfg (Optional[Dict[str, Any]], optional): Configuration dictionary for the two-stage drawing process. Defaults to None.
        plot_reward_type (str, optional): The type of reward to plot, either "gt" for ground truth or "pred" for predicted. Defaults to "gt".

    Returns:
        np.ndarray: The concatenated image of the visualized frame sample.
    """
    draw_keys = DRAW_KEYS
    if draw_2stage_cfg is not None:
        if draw_2stage_cfg.get("draw_keys") is not None:
            draw_keys = draw_2stage_cfg["draw_keys"]

        if draw_2stage_cfg.get("gt_range") is not None:
            gt_range = draw_2stage_cfg["gt_range"]

    collision_map = []

    ego_traj_mask = frame_sample["ego_pred_mask"][0]
    for plot_idx in range(draw_2stage_cfg["longtitude_num_sample"] if draw_2stage_cfg is not None else 0):
        frame_figure = PlannerFrameFigure(gt_range=gt_range, scale=scale, color_list=COLOR_LIST, draw_order=["bev"])

        interval = draw_2stage_cfg["latitude_num_sample"] if draw_2stage_cfg is not None else 1
        start_idx = plot_idx * interval
        end_idx = (plot_idx + 1) * interval

        # draw base info
        frame_info_dict = {
            "clip_id": frame_sample["clip_id"].split("_")[0],
            "timestamp": frame_sample["timestamp"],
            "ego_traj_sample_idx": f"[{start_idx}, {end_idx})",
        }
        frame_figure.draw_base_info(
            frame_info_dict,
            image_key="bev",
            color=COLOR_LIST["line_string"],
            thickness=1,
            font_scale=0.8,
            piece_size=150,
            pos_interval=1.5,
        )

        plot_shared_infos(draw_keys, frame_sample, frame_figure)

        # draw agents box
        if "agent_box" in draw_keys:
            for idx, (bbox, bbox_padding_mask) in enumerate(
                zip(frame_sample["bboxes"], frame_sample["bboxes_padding_mask"])
            ):
                if bbox_padding_mask > 0:
                    continue
                bbox_xylwh = bbox[[0, 1, 3, 4, 6]]
                # x, y, z,  l, w, h,  heading
                frame_figure.draw_agent_box(bbox_xylwh, image_key="bev", idx=idx)

        if "agents_traj" in draw_keys:
            for agents_traj, bbox_padding_mask in zip(frame_sample["agents_traj"], frame_sample["bboxes_padding_mask"]):
                if bbox_padding_mask > 0:
                    continue
                frame_figure.draw_ego_traj_pred(agents_traj, image_key="bev")

        if "ego_traj_sample_pos" in draw_keys:
            for i, ego_traj_line in enumerate(frame_sample["ego_traj_sample_pos"][start_idx:end_idx]):
                type_str = "_reward" if plot_reward_type == "pred" else "_label"
                ego_traj_sample_agents_collision = frame_sample["ego_traj_sample_agents_collision" + type_str][
                    start_idx:end_idx
                ][i]
                ego_traj_sample_lane_collision = frame_sample["ego_traj_sample_lane_collision" + type_str][
                    start_idx:end_idx
                ][i]

                frame_figure.draw_other_ego_pred_gt(
                    ego_traj_line,
                    image_key="bev",
                    agent_collision=ego_traj_sample_agents_collision,
                    lane_collision=ego_traj_sample_lane_collision,
                    traj_mask=ego_traj_mask,
                )

        if plot_reward_type == "gt":
            plot_collision_line(start_idx, end_idx, frame_sample, frame_figure, ego_traj_mask)

        collision_map.append(frame_figure.return_image())

    # plot original top1 traj and final top1 traj after reward scoring
    if plot_reward_type == "gt":
        collision_map.append(plot_top_traj(frame_sample, gt_range, scale, draw_keys, plot_traj_idx=-1))
    else:
        collision_map.append(
            plot_top_traj(
                frame_sample, gt_range, scale, draw_keys, plot_traj_idx=frame_sample["reward_sort_indices"][0]
            )
        )

    concat_img = concat_2stage_images_vertical(collision_map)

    return concat_img


def plot_top_traj(frame_sample, gt_range, scale, draw_keys, plot_traj_idx):
    """Plot the top trajectory.

    Args:
        frame_sample (dict): A dictionary containing frame sample data, including 'clip_id', 'timestamp', 'bboxes',
                             'bboxes_padding_mask', 'agents_traj', and 'ego_traj_sample_pos'.
        gt_range (tuple): Ground truth range for the plot.
        scale (float): Scale factor for the plot.
        draw_keys (list): List of keys indicating which elements to draw (e.g., 'agent_box', 'agents_traj', 'ego_traj_sample_pos').
        plot_traj_idx (int): Index of the trajectory to plot. If -1, the original trajectory is plotted.
    Returns:
        np.ndarray: The resulting image with the plotted trajectory.
    """
    frame_figure = PlannerFrameFigure(gt_range=gt_range, scale=scale, color_list=COLOR_LIST, draw_order=["bev"])

    # draw base info
    frame_info_dict = {
        "clip_id": frame_sample["clip_id"].split("_")[0],
        "timestamp": frame_sample["timestamp"],
        "reward_traj_idx": "original" if plot_traj_idx == -1 else f"sample_{plot_traj_idx}",
    }
    frame_figure.draw_base_info(
        frame_info_dict,
        image_key="bev",
        color=COLOR_LIST["line_string"],
        thickness=1,
        font_scale=0.8,
        piece_size=150,
        pos_interval=1.5,
    )

    plot_shared_infos(draw_keys, frame_sample, frame_figure)

    # draw agents box
    if "agent_box" in draw_keys:
        for idx, (bbox, bbox_padding_mask) in enumerate(
            zip(frame_sample["bboxes"], frame_sample["bboxes_padding_mask"])
        ):
            if bbox_padding_mask > 0:
                continue
            bbox_xylwh = bbox[[0, 1, 3, 4, 6]]
            # x, y, z,  l, w, h,  heading
            frame_figure.draw_agent_box(bbox_xylwh, image_key="bev", idx=idx)

    if "agents_traj" in draw_keys:
        for agents_traj, bbox_padding_mask in zip(frame_sample["agents_traj"], frame_sample["bboxes_padding_mask"]):
            if bbox_padding_mask > 0:
                continue
            frame_figure.draw_ego_traj_pred(agents_traj, image_key="bev")

    if "ego_traj_sample_pos" in draw_keys:
        frame_figure.draw_other_ego_pred_gt(
            frame_sample["ego_traj_sample_pos"][plot_traj_idx], image_key="bev", color=(0, 255, 0)
        )

    # draw ego on each position in selected trajectory
    frame_figure.draw_ego_box_on_traj(
        frame_sample["ego_traj_sample_pos"][plot_traj_idx],
        frame_sample["ego_traj_sample_yaw"][plot_traj_idx],
        frame_sample["ego_traj_sample_vel"][plot_traj_idx],
        image_key="bev",
    )

    return frame_figure.return_image()


def concat_2stage_images_vertical(collision_map):
    """Concatenates a list of images vertically with a border around each image.

    Args:
        collision_map (list of numpy.ndarray): List of images to be concatenated.

    Returns:
        numpy.ndarray: A single image obtained by concatenating the input images vertically with a border.
    """
    border_width = 2
    border_color = [0, 0, 0]

    collision_map_with_border = [
        cv2.copyMakeBorder(
            img, border_width, border_width, border_width, border_width, cv2.BORDER_CONSTANT, value=border_color
        )
        for img in collision_map
    ]

    return np.concatenate(collision_map_with_border, axis=0)


def plot_shared_infos(draw_keys, frame_sample, frame_figure):
    """Plot various elements on a frame figure.

    Args:
        draw_keys (list): List of keys indicating which elements to draw.
        frame_sample (dict): Dictionary containing frame sample data with keys such as "atlas", "navi_line_points",
                             "navi_line_types", "navi_path_points", "navi_path_types", "lane_points", "lane_types",
                             "navi_path_stoppoints", "bboxes", "bboxes_padding_mask", "trackable_ret", "trackable_gt",
                             "od_prior_pred", "agent_index", "od_prior_gt", "ego_traj_pred_all", "aligned_trajectory",
                             "ego_pred_mask", "ego_traj_pred", "goal_point_ego_traj_pred", "tld", and "control_points".
        frame_figure (object): Object responsible for drawing elements on the frame figure. It should have methods
                               such as draw_atlas_outline, draw_scale_line, draw_navi_lane, draw_navi_path,
                               draw_navi_path_with_tld, draw_laneline, draw_curb, draw_stopline, draw_agent_box,
                               draw_prior_box, draw_not_prior_box, draw_prior_box_corner, draw_not_prior_box_corner,
                               draw_ego_pos, draw_ego_box, draw_other_ego_pred_gt, draw_align_traj_gt, draw_ego_traj_pred,
                               draw_goal_ego_traj_pred, draw_tld_e2e, and draw_control_point.

    Returns:
        None
    """
    # draw atlas
    if "atlas" in draw_keys:
        for single_area in frame_sample["atlas"]:
            area_points = single_area[:, :2]
            area_types = single_area[:, -1]

            cur_area_type = area_types[0]
            selected_area_points = area_points[area_types == cur_area_type]

            if cur_area_type not in [-1, 0]:
                frame_figure.draw_atlas_outline(selected_area_points, image_key="bev")

    # draw scale line
    frame_figure.draw_scale_line(image_key="bev")

    # draw navilane
    if "navi_lane" in draw_keys:
        for i_line, (single_navi_lane_points, single_navi_lane_types) in enumerate(
            zip(frame_sample["navi_line_points"], frame_sample["navi_line_types"])
        ):
            if sum(single_navi_lane_types != -1) == 0:
                continue
            selected_navi_lane_points = single_navi_lane_points[single_navi_lane_types != -1]
            frame_figure.draw_navi_lane(selected_navi_lane_points, line_str=str(i_line), image_key="bev")

    if "navi_path" in draw_keys:
        for i_line, (single_navi_path_points, single_navi_path_types) in enumerate(
            zip(frame_sample["navi_path_points"], frame_sample["navi_path_types"])
        ):
            if sum(single_navi_path_types != -1) == 0:
                continue
            selected_navi_path_points = single_navi_path_points[single_navi_path_types != -1]
            if "navi_path_tld" in draw_keys:
                single_navi_path_tld = frame_sample["navi_path_tld"][i_line]
                if single_navi_path_tld[0] > 0:
                    color = junction_color_to_bgr[single_navi_path_tld[0]]
                    frame_figure.draw_navi_path_with_tld(
                        selected_navi_path_points, color=color, line_str=str(i_line), image_key="bev"
                    )
                else:
                    frame_figure.draw_navi_path(selected_navi_path_points, line_str=str(i_line), image_key="bev")
            else:
                frame_figure.draw_navi_path(selected_navi_path_points, line_str=str(i_line), image_key="bev")

    # draw laneline, curb, stopline
    if "laneline" in draw_keys or "curb" in draw_keys or "stopline" in draw_keys:
        for i_line, (single_lane_points, single_lane_types) in enumerate(
            zip(frame_sample["lane_points"], frame_sample["lane_types"])
        ):
            cur_lane_type = single_lane_types[0]
            selected_lane_points = single_lane_points[single_lane_types == cur_lane_type]

            if cur_lane_type not in [0, 1, 2]:
                continue
            if "laneline" in draw_keys and cur_lane_type == 0:  # laneline
                frame_figure.draw_laneline(selected_lane_points, line_str=str(i_line), image_key="bev")
            elif "curb" in draw_keys and cur_lane_type == 1:  # curb
                frame_figure.draw_curb(selected_lane_points, line_str=str(i_line), image_key="bev")
            elif "stopline" in draw_keys and cur_lane_type == 2:  # stopline
                frame_figure.draw_stopline(selected_lane_points, line_str=str(i_line), image_key="bev")

    # draw navi path stoppoints
    if (
        "stopline" in draw_keys
        and "navi_path_stoppoints" in frame_sample
        and frame_sample["navi_path_stoppoints"] is not None
    ):
        for i_line, single_stopline_points in enumerate(frame_sample["navi_path_stoppoints"]):
            single_stopline_points = single_stopline_points[
                ~((single_stopline_points[:, 0] == 0) & (single_stopline_points[:, 1] == 0))
            ]
            if single_stopline_points is not None and len(single_stopline_points) > 0:
                frame_figure.draw_stopline(
                    single_stopline_points, line_str=str(i_line), image_key="bev", draw_point=True, thickness=5
                )

    # draw agent box
    if "agent_box" in draw_keys:
        trackable_ret = (
            frame_sample["trackable_ret"]
            if frame_sample["trackable_ret"] is not None
            else [0] * len(frame_sample["bboxes"])
        )
        for bbox, bbox_padding_mask, trackpred in zip(
            frame_sample["bboxes"],
            frame_sample["bboxes_padding_mask"],
            trackable_ret,
        ):
            if bbox_padding_mask > 0:
                continue
            bbox_xylwh = bbox[[0, 1, 3, 4, 6]]

            track = True if trackpred == 1 else False
            frame_figure.draw_agent_box(bbox_xylwh, image_key="bev", track=track)
    if "od_prior_pred" in draw_keys:
        if "od_prior_pred" in frame_sample and frame_sample["od_prior_pred"] is not None:
            agent_index = frame_sample["agent_index"].astype(int)
            od_prior_pred = frame_sample["od_prior_pred"]
            od_prior_bboxes = frame_sample["bboxes"][agent_index, :]
            od_prior_bboxes_mask = frame_sample["bboxes_padding_mask"][agent_index]
            for od_pri_score, od_pri_box, id_pri_box_mask in zip(od_prior_pred, od_prior_bboxes, od_prior_bboxes_mask):
                if id_pri_box_mask > 0:
                    continue
                bbox_xylwh = od_pri_box[[0, 1, 3, 4, 6]]
                if od_pri_score > 0.5:
                    if "od_prior_pred_score" in draw_keys:
                        frame_figure.draw_prior_box(bbox_xylwh, score=od_pri_score, image_key="bev")
                    else:
                        frame_figure.draw_prior_box(bbox_xylwh, image_key="bev")
                else:
                    if "od_prior_pred_score" in draw_keys:
                        frame_figure.draw_not_prior_box(bbox_xylwh, score=od_pri_score, image_key="bev")
                    else:
                        frame_figure.draw_not_prior_box(bbox_xylwh, image_key="bev")

    if "od_prior_gt" in draw_keys:
        if (
            "od_prior_gt" in frame_sample
            and frame_sample["od_prior_gt"] is not None
            and frame_sample["agent_index"] is not None
        ):
            agent_index = frame_sample["agent_index"].astype(int)
            od_prior_gt = frame_sample["od_prior_gt"][agent_index]
            bboxes = frame_sample["bboxes"][agent_index, :]
            bboxes_mask = frame_sample["bboxes_padding_mask"][agent_index]
            for bbox, bbox_padding_mask, prior in zip(bboxes, bboxes_mask, od_prior_gt):
                if bbox_padding_mask > 0:
                    continue
                bbox_xylwh = bbox[[0, 1, 3, 4, 6]]
                bbox_type = bbox[7]
                if prior == 1:
                    frame_figure.draw_prior_box_corner(bbox_xylwh, bbox_type, image_key="bev")
                if prior == 0:
                    frame_figure.draw_not_prior_box_corner(bbox_xylwh, bbox_type, image_key="bev")

    # draw ego box
    if "ego_box" in draw_keys:
        frame_figure.draw_ego_pos(image_key="bev")
        frame_figure.draw_ego_box(image_key="bev")

    # draw ego all trajectory gt
    if "ego_traj_pred_all" in draw_keys:
        if frame_sample["ego_traj_pred_all"] is None:
            logger.warning("ego_traj_pred_all is None. Skip drawing this element.")
        else:
            for ego_traj_line in frame_sample["ego_traj_pred_all"][0]:
                frame_figure.draw_other_ego_pred_gt(ego_traj_line)

    # draw ego trajectory pred
    if "ego_traj_pred" in draw_keys:
        if frame_sample["ego_traj_pred"] is None:
            logger.warning("ego_traj_pred is None. Skip drawing this element.")
        else:
            for ego_traj_line in frame_sample["ego_traj_pred"]:
                frame_figure.draw_ego_traj_pred(ego_traj_line, image_key="bev")

    for head_name in ["goal_point_ego_traj_pred", "uturn_ego_traj_pred"]:
        if head_name in draw_keys:
            if head_name not in frame_sample or frame_sample[head_name] is None:
                logger.warning("'%s' is None. Skip drawing this element.", head_name)
            else:
                for ego_traj_line in frame_sample[head_name][0]:
                    frame_figure.draw_goal_ego_traj_pred(ego_traj_line, image_key="bev")

    # draw tld
    if "tld" in draw_keys:
        frame_figure.draw_tld_e2e(frame_sample["tld"])

    if "control_point" in draw_keys:
        control_points = frame_sample["control_points"]
        for control_point in control_points:
            control_point_mask = (control_point[:, 0] == -1.0) & (control_point[:, 1] == -1.0)
            control_point_draw = control_point[~control_point_mask, :]
            frame_figure.draw_control_point(control_point_draw, image_key="bev")


def visualize_single_frame_sample(
    dump_folder: str,
    frame_sample: Dict[str, Any],
    gt_range=(-40, 100, -50, 50),
    scale=16,
    draw_keys: Optional[List[str]] = None,
):
    """Visualize single frame sample.

    Args:
        frame_sample: dict seems like -
        {
            "clip_id": str,
            "timestamp": str,
            "ego_pred_gt": numpy.ndarray([1, 35, 2]),
            "ego_pred": numpy.ndarray([1, 35, 2]),
            "navi_line_points": numpy.ndarray([6, 200, 2]),
            "navi_line_types": numpy.ndarray([6, 200,]),
            "lane_points": numpy.ndarray([50, 30, 2]),
            "lane_types": numpy.ndarray([50, 30]),
            "bboxes": numpy.ndarray([191, 40]),
            "bboxes_padding_mask": numpy.ndarray([191, 40]),
            "atlas": numpy.ndarray([50, 30, 3]),
        }
    """
    if draw_keys is None:
        draw_keys = DRAW_KEYS

    frame_figure = PlannerFrameFigure(gt_range=gt_range, scale=scale, color_list=COLOR_LIST)

    # draw base info
    frame_info_dict = {
        "clip_id": frame_sample["clip_id"],
        "timestamp": frame_sample["timestamp"],
    }
    frame_figure.draw_base_info(frame_info_dict, image_key="base_info")
    ego_info_dict = {}
    if "ego_vel" in draw_keys:
        ego_vel = np.round(frame_sample["ego_vel"], 2)
        ego_acc = np.round(frame_sample["ego_acc"], 2)
        ego_vel_km = np.round(ego_vel * 3.6, 2)
        ego_info_dict.update(
            {
                "ego_vel": str(ego_vel) + "m/s" + "," + str(ego_vel_km) + "km/h",
                "ego_acc": str(ego_acc) + "m/s^2",
            }
        )
    if "ego_pred_info" in draw_keys:
        ego_info_dict.update(
            {
                "ego_pred_1s": str(
                    np.round(frame_sample["ego_traj_pred"][0, 4, 0] - 0, 3)
                ),  # first second ego pred distance
                "ego_pred_2s": str(
                    np.round(frame_sample["ego_traj_pred"][0, 9, 0] - frame_sample["ego_traj_pred"][0, 4, 0], 3)
                ),  # second second ego pred moving distance
                "ego_pred_3s": str(
                    np.round(frame_sample["ego_traj_pred"][0, 14, 0] - frame_sample["ego_traj_pred"][0, 9, 0], 3)
                ),  # third second ego pred moving distance
                "ego_pred_4s": str(
                    np.round(frame_sample["ego_traj_pred"][0, 19, 0] - frame_sample["ego_traj_pred"][0, 14, 0], 3)
                ),
                "ego_pred_5s": str(
                    np.round(frame_sample["ego_traj_pred"][0, 24, 0] - frame_sample["ego_traj_pred"][0, 19, 0], 3)
                ),
                # "ego_pred_6s": str(
                #    np.round(frame_sample["ego_traj_pred"][0, 29, 0] - frame_sample["ego_traj_pred"][0, 24, 0], 3)
                # ),
                # "ego_pred_7s": str(
                #    np.round(frame_sample["ego_traj_pred"][0, 34, 0] - frame_sample["ego_traj_pred"][0, 29, 0], 3)
                # ),
                "navi_scene_pred_idx": str(frame_sample["navi_scene_pred_idx"]),
            }
        )
    frame_figure.draw_base_info(ego_info_dict, image_key="base_info", org=(40, 800))
    if "drive_path" in draw_keys:
        drive_path_gt = frame_sample["drive_path_gt"][frame_sample["drive_path_mask"] > 0]
        if len(drive_path_gt) > 0:
            frame_figure.draw_drive_path_gt(drive_path_gt, image_key="bev", thickness=2, transparent=0.8)
        # drive_path_pred = frame_sample["drive_path_pred"].reshape(-1, 2)
        drive_path_pred = frame_sample["drive_path_pred"][0].reshape(-1, 2)
        frame_figure.draw_drive_path_pred(drive_path_pred, image_key="bev", thickness=2, transparent=0.8)

    if "aligned_trajectory" in frame_sample and frame_sample["aligned_trajectory"] is not None:
        ego_pred_mask = frame_sample["ego_pred_mask"][0]
        traj_num = len(ego_pred_mask)
        aligned_trajectory = frame_sample["aligned_trajectory"]
        new_bboxes_pred_gt = np.zeros((traj_num, 2))
        max_len = min(len(aligned_trajectory), traj_num)
        new_bboxes_pred_gt[:max_len, :2] = aligned_trajectory[:max_len, :2]
        align_traj_line = new_bboxes_pred_gt[ego_pred_mask.astype(bool)]
        frame_figure.draw_align_traj_gt(align_traj_line, image_key="bev", thickness=2, transparent=0.5)

    # draw ego trajectory gt
    if "ego_traj_gt" in draw_keys:
        for ego_traj_line, ego_pred_mask_single in zip(frame_sample["ego_traj_gt"], frame_sample["ego_pred_mask"]):
            ego_traj_line = ego_traj_line[ego_pred_mask_single.astype(bool)]
            frame_figure.draw_ego_traj_gt(ego_traj_line, image_key="bev", thickness=2, transparent=0.5)

    plot_shared_infos(draw_keys, frame_sample, frame_figure)
    if "ar_drive_path_pred" in draw_keys:
        drive_path_gt = frame_sample["drive_path_gt"][frame_sample["drive_path_mask"] > 0]
        if len(drive_path_gt) > 0:
            frame_figure.draw_ar_drive_path_gt(drive_path_gt, image_key="bev", thickness=1, transparent=0.8)
        for line in frame_sample["ar_drive_path_pred"]:
            frame_figure.draw_ar_drive_path_pred(line, image_key="bev", thickness=1, transparent=0.8)

    if "ar_ego_pos_pred" in draw_keys:
        for line in frame_sample["ar_ego_pos_pred"]:
            frame_figure.draw_ar_ego_pos_pred(line[0], image_key="bev")

    if "ar_agents_pos_pred" in draw_keys:
        for agents_line in frame_sample["ar_agents_pos_pred"]:
            for line in agents_line:
                points_zeros_mask = (np.abs(line) < 1e-6).all(-1)
                points_not_zeros = line[~points_zeros_mask]
                if points_not_zeros.shape[0] == 0:
                    continue
                frame_figure.draw_ar_agents_pos_pred(points_not_zeros, image_key="bev")
            break

    image_path = os.path.join(
        dump_folder,
        frame_sample["clip_id"],
        f"{frame_sample['clip_id']}-{frame_sample['timestamp']}.jpg",
    )
    frame_figure.dump_image(image_path)


def visualization_filter(
    batch_sample: Dict[str, Any],
    model_outputs: Dict[str, Any],
    draw_2stage_cfg: Optional[Dict[str, Any]] = None,
):
    """Prepare frame sample data for visualization."""
    batch_sample_for_visualization = []

    batch_size = batch_sample["egos_pred_gt"].shape[0]
    if "trans_in_loop" in model_outputs["pred_output"]:
        batch_sample["egos_pred_gt"] = model_outputs["pred_output"]["trans_in_loop"]["egos_pred_gt"]
        batch_sample["navi_line_points"] = model_outputs["pred_output"]["trans_in_loop"]["navi_line_points"]
        batch_sample["navi_path_points"] = model_outputs["pred_output"]["trans_in_loop"]["navi_path_points"]
        batch_sample["lane_points"] = model_outputs["pred_output"]["trans_in_loop"]["lane_points"]
        batch_sample["bboxes"] = model_outputs["pred_output"]["trans_in_loop"]["bboxes"]
        batch_sample["atlas"] = model_outputs["pred_output"]["trans_in_loop"]["atlas"]
        batch_sample["egos"] = model_outputs["pred_output"]["trans_in_loop"]["egos"]
        batch_sample["control_points"] = model_outputs["pred_output"]["trans_in_loop"]["control_points"]

    if draw_2stage_cfg is not None and draw_2stage_cfg["dump_image_2stage"]:
        traj_sample = model_outputs["pred_output"]["marginal_output"]["traj_sample_pred_output"][-1]
        batch_sample["traj_sample_pos"] = traj_sample["planner_pred"]["pos_sampled"]
        batch_sample["traj_sample_yaw"] = traj_sample["planner_pred"]["yaw_sampled"]
        batch_sample["traj_sample_vel"] = traj_sample["planner_pred"]["vel_sampled"]

        t = batch_sample["traj_sample_pos"].shape[2]
        batch_sample["bboxes_pred_gt"] = model_outputs["bboxes_pred_gt"][:, :, :t, :]
        batch_sample["bboxes_det_pred_full_info_gt"] = model_outputs["bboxes_det_pred_full_info_gt"][:, :, :t, :]

        batch_sample["agents_collision_reward"] = traj_sample["traj_pred_agent_collision_sigmoid"]
        batch_sample["lane_collision_reward"] = traj_sample["traj_pred_lane_collision_sigmoid"]

        # parse from multi_task_model calling func, gt_label from loss build
        batch_sample["agents_collision_label"] = model_outputs["pred_output"]["marginal_output"][
            "agents_collision_label"
        ]
        batch_sample["lane_collision_label"] = model_outputs["pred_output"]["marginal_output"]["lane_collision_label"]
        batch_sample["ego_agent_gts"] = model_outputs["pred_output"]["marginal_output"]["ego_agent_gts"]
        batch_sample["ego_agents_collision_check"] = model_outputs["pred_output"]["marginal_output"][
            "ego_agents_collision_check"
        ]
        batch_sample["ego_lane_gts"] = model_outputs["pred_output"]["marginal_output"]["ego_lane_gts"]
        batch_sample["ego_lane_collision_check"] = model_outputs["pred_output"]["marginal_output"][
            "ego_lane_collision_check"
        ]
        batch_sample["sorted_rewards_trajectories"] = model_outputs["pred_output"]["marginal_output"][
            "sorted_rewards_trajectories"
        ]
        batch_sample["sorted_trajectories_collisions"] = model_outputs["pred_output"]["marginal_output"][
            "sorted_trajectories_collisions"
        ]
        batch_sample["sorted_trajectories_reward"] = model_outputs["pred_output"]["marginal_output"][
            "sorted_trajectories_reward"
        ]
        batch_sample["reward_sort_indices"] = model_outputs["pred_output"]["marginal_output"]["reward_sort_indices"]

    if "auto_regressive_planner_output" in model_outputs:
        ar_ego_pos_pred = model_outputs["auto_regressive_planner_output"]["dynamic_states"]["ego"].cpu().numpy()
        ar_agents_pos_pred = model_outputs["auto_regressive_planner_output"]["dynamic_states"]["agents"].cpu().numpy()
        ar_batch_mapping = model_outputs["auto_regressive_planner_output"]["batch_mapping"]
        ar_drive_path_pred = (
            model_outputs["auto_regressive_planner_output"]["ar_add_on_res"]["drive_path"].cpu().numpy()
        )
        all_batch_idx_sorted = sorted(ar_batch_mapping.unique())
        ar_ego_pos_pred_list = []
        ar_agents_pos_pred_list = []
        ar_drive_path_pred_list = []
        for batch_idx in all_batch_idx_sorted:
            ar_ego_pos_pred_list.append(ar_ego_pos_pred[(ar_batch_mapping == batch_idx).tolist()])
            ar_agents_pos_pred_list.append(ar_agents_pos_pred[(ar_batch_mapping == batch_idx).tolist()])
            ar_drive_path_pred_list.append(ar_drive_path_pred[(ar_batch_mapping == batch_idx).tolist()])

    for i_sample in range(batch_size):
        clip_id = batch_sample["subclip_ids"][i_sample]
        timestamp = str(batch_sample["timestamp"][i_sample][-1])
        # egos = batch_sample["egos"][i_sample].cpu().numpy()
        ego_traj_gt = batch_sample["egos_pred_gt"][i_sample].cpu().numpy()
        ego_pred_mask = batch_sample["egos_pred_mask"][i_sample].cpu().numpy()
        navi_line_points = batch_sample["navi_line_points"][i_sample].cpu().numpy()
        navi_line_types = batch_sample["navi_line_types"][i_sample].cpu().numpy()
        navi_path_points = batch_sample["navi_path_points"][i_sample].cpu().numpy()
        navi_path_types = batch_sample["navi_path_types"][i_sample].cpu().numpy()
        navi_path_tld = batch_sample["navi_path_tld"][i_sample].cpu().numpy()
        control_points = batch_sample["control_points"][i_sample].cpu().numpy()
        lane_points = batch_sample["lane_points"][i_sample].cpu().numpy()
        lane_types = batch_sample["lane_types"][i_sample].cpu().numpy()
        bboxes = batch_sample["bboxes"][i_sample][-1].cpu().numpy()
        bboxes_padding_mask = batch_sample["bboxes_padding_mask"][i_sample][-1].cpu().numpy()
        atlas = batch_sample["atlas"][i_sample].cpu().numpy()
        drive_path_gt = batch_sample["drive_path_gt"][i_sample].cpu().numpy()
        drive_path_mask = batch_sample["drive_path_mask"][i_sample].cpu().numpy()
        if "marginal_ego_pred_drive_path" in batch_sample:
            drive_path_pred = batch_sample["marginal_ego_pred_drive_path"][i_sample].cpu().numpy()
        else:
            drive_path_pred = None

        if draw_2stage_cfg is not None and draw_2stage_cfg["dump_image_2stage"]:
            agents_traj = batch_sample["bboxes_pred_gt"][i_sample].cpu().numpy()
            agents_bbox_infos = batch_sample["bboxes_det_pred_full_info_gt"][i_sample].cpu().numpy()
            ego_traj_sample_agents_collision_reward = batch_sample["agents_collision_reward"][i_sample].cpu().numpy()
            ego_traj_sample_lane_collision_reward = batch_sample["lane_collision_reward"][i_sample].cpu().numpy()
            ego_traj_sample_agents_collision_label = batch_sample["agents_collision_label"][i_sample].cpu().numpy()
            ego_traj_sample_lane_collision_label = batch_sample["lane_collision_label"][i_sample].cpu().numpy()
            ego_traj_sample_pos = batch_sample["traj_sample_pos"][i_sample].cpu().numpy()
            ego_traj_sample_yaw = batch_sample["traj_sample_yaw"][i_sample].cpu().numpy()
            ego_traj_sample_vel = batch_sample["traj_sample_vel"][i_sample].cpu().numpy()
            ego_agent_gts = batch_sample["ego_agent_gts"][i_sample].cpu().numpy()
            ego_agents_collision_check = batch_sample["ego_agents_collision_check"][i_sample].cpu().numpy()
            sorted_rewards_trajectories = batch_sample["sorted_rewards_trajectories"][i_sample].cpu().numpy()
            sorted_trajectories_collisions = batch_sample["sorted_trajectories_collisions"][i_sample].cpu().numpy()
            sorted_trajectories_reward = batch_sample["sorted_trajectories_reward"][i_sample].cpu().numpy()
            reward_sort_indices = batch_sample["reward_sort_indices"][i_sample].cpu().numpy()

            agents_line_dict: Dict[int, List[Tuple[np.ndarray, np.ndarray, float]]] = {}
            for agent_id, traj_id, time_id in zip(
                *[item.tolist() for item in (ego_agents_collision_check > 0).nonzero()]
            ):
                if agents_line_dict.get(traj_id, None) is None:
                    agents_line_dict[traj_id] = []

                agents_line_dict[traj_id].append(
                    (
                        ego_traj_sample_pos[traj_id, time_id],
                        ego_agent_gts[agent_id, time_id],
                        ego_agents_collision_check[agent_id, traj_id, time_id],
                    )
                )

            ego_lane_gts = batch_sample["ego_lane_gts"][i_sample].cpu().numpy()
            ego_lane_collision_check = batch_sample["ego_lane_collision_check"][i_sample].cpu().numpy()

            lane_line_dict: Dict[int, List[Tuple[np.ndarray, np.ndarray, float]]] = {}
            for traj_id, time_id in zip(*[item.tolist() for item in (ego_lane_collision_check > 0).nonzero()]):
                for point in ego_lane_gts[traj_id, time_id]:
                    if lane_line_dict.get(traj_id, None) is None:
                        lane_line_dict[traj_id] = []

                    lane_line_dict[traj_id].append(
                        (
                            ego_traj_sample_pos[traj_id, time_id],
                            point,
                            ego_lane_collision_check[traj_id, time_id],
                        )
                    )

        if batch_sample.get("navi_lane_tld", None) is not None:
            navi_lane_tld = batch_sample["navi_lane_tld"][i_sample].cpu().numpy()
        else:
            navi_lane_tld = None

        if batch_sample.get("tld", None) is not None:
            tld = batch_sample["tld"][i_sample][0].cpu().numpy()
        else:
            tld = None
        aligned_trajectory = batch_sample["aligned_trajectory"]
        if aligned_trajectory is not None and aligned_trajectory[i_sample] is not None:
            aligned_trajectory = aligned_trajectory[i_sample].cpu().numpy()
        else:
            aligned_trajectory = None
        ego_vel = batch_sample["egos"][i_sample][-1][0][10].cpu().numpy()  # BOX_FEAT_DIMS, 10:vx, 11:vy
        ego_acc = batch_sample["egos"][i_sample][-1][0][12].cpu().numpy()  # BOX_FEAT_DIMS, 10:vx, 11:vy

        if model_outputs.get("goal_point_planner_output", None) is not None:
            cp_bs = model_outputs["goal_point_planner_output"]["marginal_output"]["ego_pred_pos"].size(1)
            goal_point_ego_traj_pred = (
                model_outputs["goal_point_planner_output"]["marginal_output"]["ego_pred_pos"]
                .squeeze(2)
                .squeeze(2)
                .reshape(1, cp_bs, -1, 2)
                .cpu()
                .numpy()
            )
        else:
            goal_point_ego_traj_pred = None

        def get_ego_traj_pred_by_head_name(model_outputs: Dict, head_name: str):
            ret = None
            if model_outputs.get(head_name, None) is not None:
                cp_bs = model_outputs[head_name]["marginal_output"]["ego_pred_pos"].size(1)
                ret = (
                    model_outputs[head_name]["marginal_output"]["ego_pred_pos"]
                    .squeeze(2)
                    .squeeze(2)
                    .reshape(1, cp_bs, -1, 2)
                    .cpu()
                    .numpy()
                )
            return ret

        uturn_ego_traj_pred = get_ego_traj_pred_by_head_name(model_outputs, "uturn_planner_pred_output")

        if (navi_path_stoppoints := batch_sample.get("navi_path_stoppoints", None)) is not None:
            navi_path_stoppoints = navi_path_stoppoints[i_sample].cpu().numpy()

        if (navi_scene_pred_idx := batch_sample.get("navi_scene_pred_idx", -1)) != -1:
            navi_scene_pred_idx = batch_sample["navi_scene_pred_idx"][i_sample].cpu().numpy()

        if (ego_traj_pred := batch_sample.get("marginal_ego_best_traj", None)) is not None:
            ego_traj_pred = ego_traj_pred[i_sample].cpu().numpy()

        if (ego_traj_pred_all := batch_sample.get("sorted_marginal_ego_traj", None)) is not None:
            ego_traj_pred_all = ego_traj_pred_all[i_sample].cpu().numpy()

        if (od_prior_gt := batch_sample.get("od_prior_gt", None)) is not None:
            od_prior_gt = batch_sample["od_prior_gt"][i_sample].cpu().numpy()

        if (od_prior_pred := model_outputs["pred_output"].get("od_prior_pred", None)) is not None:
            od_prior_pred = od_prior_pred[i_sample].cpu().numpy()

        if (agent_index := model_outputs["pred_output"].get("agent_index", None)) is not None:
            agent_index = agent_index[i_sample].cpu().numpy()
        # 跟车部分可视化代码#

        if (
            trackable_pred := model_outputs["pred_output"].get("trackable_output", None)
        ) is not None and trackable_pred["trackable_pred"].shape[0] != 0:
            trackable_pred = model_outputs["pred_output"]["trackable_output"]["trackable_pred"].cpu().numpy()
            agent_index_ = (
                model_outputs["pred_output"]["trackable_output"]["agent_index"].cpu().numpy().astype(np.int32)
            )
            trackable_pred = trackable_pred.reshape(batch_size, -1)
            agent_index_ = agent_index_.reshape(batch_size, -1)
            pred = trackable_pred[i_sample] >= 0.5
            pred = pred.astype(np.float64)
            agent_num = bboxes.shape[0]
            trackable_ret = np.zeros(agent_num)
            trackable_ret[agent_index_[i_sample]] = pred
            trackable_gt = batch_sample["ego_trackable_agent_gt"].cpu().numpy()[i_sample]
        else:
            trackable_ret = None
            trackable_gt = None

        if "auto_regressive_planner_output" in model_outputs:
            ar_ego_pos_pred = ar_ego_pos_pred_list[i_sample][:, :, 14:, :2]
            ar_agents_pos_pred = ar_agents_pos_pred_list[i_sample][:, :, 14:, :2]
            ar_drive_path_pred = ar_drive_path_pred_list[i_sample]
        else:
            ar_ego_pos_pred = None
            ar_agents_pos_pred = None
            ar_drive_path_pred = None

        frame_sample_for_visualization = {
            "clip_id": clip_id,
            "timestamp": timestamp,
            "ego_traj_gt": ego_traj_gt,  # (1, 35, 2)
            "ego_traj_pred": ego_traj_pred,  # (1, 35, 2)
            "ego_traj_pred_all": ego_traj_pred_all,  # (1, 18, 35, 2)
            "navi_line_points": navi_line_points,  # (6, 200, 2)
            "navi_line_types": navi_line_types,  # (6, 200)
            "navi_lane_tld": navi_lane_tld,
            "navi_path_points": navi_path_points,  # (6, 30, 2)
            "navi_path_types": navi_path_types,  # (6, 30)
            "navi_path_tld": navi_path_tld,  # (6, 1)
            "lane_points": lane_points,  # (50, 30, 2)
            "lane_types": lane_types,  # (50, 30)
            "bboxes": bboxes,  # (191, 40)
            "bboxes_padding_mask": bboxes_padding_mask,  # (191)
            "atlas": atlas,  # (50, 30, 3)
            "ego_vel": ego_vel,  # (2,)
            "ego_acc": ego_acc,  # (2,)
            "tld": tld,
            "ego_pred_mask": ego_pred_mask,
            "navi_path_stoppoints": navi_path_stoppoints,
            "navi_scene_pred_idx": navi_scene_pred_idx,
            "goal_point_ego_traj_pred": goal_point_ego_traj_pred,
            "uturn_ego_traj_pred": uturn_ego_traj_pred,
            "control_points": control_points,
            "od_prior_gt": od_prior_gt,
            "od_prior_pred": od_prior_pred,
            "agent_index": agent_index,
            "trackable_ret": trackable_ret,
            "trackable_gt": trackable_gt,
            "aligned_trajectory": aligned_trajectory,
            "drive_path_gt": drive_path_gt,
            "drive_path_mask": drive_path_mask,
            "drive_path_pred": drive_path_pred,
            "ar_ego_pos_pred": ar_ego_pos_pred,
            "ar_agents_pos_pred": ar_agents_pos_pred,
            "ar_drive_path_pred": ar_drive_path_pred,
        }

        if draw_2stage_cfg is not None and draw_2stage_cfg["dump_image_2stage"]:
            frame_sample_for_visualization.update(
                {
                    "agents_traj": agents_traj,
                    "agents_bbox_infos": agents_bbox_infos,
                    "ego_traj_sample_agents_collision_reward": ego_traj_sample_agents_collision_reward,
                    "ego_traj_sample_lane_collision_reward": ego_traj_sample_lane_collision_reward,
                    "ego_traj_sample_agents_collision_label": ego_traj_sample_agents_collision_label,
                    "ego_traj_sample_lane_collision_label": ego_traj_sample_lane_collision_label,
                    "ego_traj_sample_pos": ego_traj_sample_pos,
                    "ego_traj_sample_yaw": ego_traj_sample_yaw,
                    "ego_traj_sample_vel": ego_traj_sample_vel,
                    "agents_line_dict": agents_line_dict,
                    "lane_line_dict": lane_line_dict,
                    "ego_agent_gts": ego_agent_gts,
                    "sorted_rewards_trajectories": sorted_rewards_trajectories,
                    "sorted_trajectories_collisions": sorted_trajectories_collisions,
                    "sorted_trajectories_reward": sorted_trajectories_reward,
                    "reward_sort_indices": reward_sort_indices,
                }
            )

        batch_sample_for_visualization.append(frame_sample_for_visualization)

    return batch_sample_for_visualization
