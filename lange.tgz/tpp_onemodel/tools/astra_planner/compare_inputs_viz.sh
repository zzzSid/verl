# ======================== RUN ================================
# bash tpp_onemodel/tools/astra_planner/compare_inputs_viz.sh
# =============================================================
set -xe

export LIDAR_INFER_MODE=trace
export CUBLAS_WORKSPACE_CONFIG=:4096:8

# 使用需求及其方法：参考: https://nio.feishu.cn/wiki/QRQew6KXeii18VkNA3ycTwttnTJ
# 1. 需求：比较云端和车端的输入。方法： cfg_planner, cpp_dump_dir 都要填写，如果指定某一帧，那么填写 ts, 如果不指定，自动找两端输入的timestamp diff最小的帧
# 2. 需求：绘制单帧输入。方法：取决于你的数据来源，填写 cfg_planner 或者 cpp_dump_dir ，并加上 same_plot 选项

# Optional, 基于正常训练的cfg, 更改cfg文件的infer_dataloader里的datasets，其中存放目标clip的pkl.
CFG_PATH="/share-global/ian.xu/align/v0823/cfg_baseline_10w_for_align.py"
# Optional, 跑 argus ppl dump 得到的目标clip的模型input和output.
CPP_DUMP_DIR="/share-global/ian.xu/align/v0823/astra_planner_test_20240829172150/d8377af3-957f-45e5-816f-46ca839fe329/dump/AstraPlannerModel"
# Optional, 要比较的目标帧时间戳，单位ms, 如果不填, 那么会自动查找云端和车端timestamp差最小的那一帧.
TS=1724391405703
# Optional, default ./compare_inputs_viz/
RESULT_DIR="./compare_inputs_viz/"

python3 tpp_onemodel/tools/astra_planner/compare_inputs_viz.py \
    --cfg_planner $CFG_PATH \
    --cpp_dump_dir $CPP_DUMP_DIR \
    --ts $TS \
    --result_dir $RESULT_DIR \
    --same_plot \
    --compare_value
