# -*- coding: utf-8 -*-
"""Astra Planner metrics result compare."""
import argparse
import os
import sys

import pandas as pd


def cmp(baseline_file, cmp_file, file_name):
    """Metrics cmp."""
    if not os.path.exists(baseline_file):
        raise FileNotFoundError(baseline_file)

    if not os.path.exists(cmp_file):
        raise FileNotFoundError(cmp_file)

    save_dir = "./output/exp_compare"
    save_dir = os.path.abspath(save_dir)
    os.makedirs(save_dir, exist_ok=True)
    if not file_name:
        file_count = len(list(os.listdir(save_dir)))
        file_name = "metrics_cmp_result_" + str(file_count) + ".xlsx"

    base_data = pd.read_csv(baseline_file)
    cmp_data = pd.read_csv(cmp_file)

    diff = base_data.compare(cmp_data, keep_shape=True, keep_equal=True)
    diff.drop(columns=["Unnamed: 0"], inplace=True)
    diff.drop(columns=("MetricNames", "other"), inplace=True)
    diff.rename(columns={"self": "baseline"}, inplace=True)
    diff.rename(columns={"other": "cmp"}, inplace=True)
    columns = diff.columns[1:]
    scene_num = len(columns) // 2
    for i in range(scene_num):
        diff.insert(
            (i + 1) * 3,
            (columns[i * 2][0], "diff"),
            (diff[columns[i * 2 + 1]] - diff[columns[i * 2]]) / diff[columns[i * 2]],
        )

    new_diff = diff.style.apply(color_change, axis=1, subset=[(columns[i * 2][0], "diff") for i in range(scene_num)])
    final_path = os.path.join(save_dir, file_name)
    new_diff.to_excel(final_path, engine="openpyxl", index=True)

    sys.stdout.write("Metrics cmp result saved at:\n")
    sys.stdout.write(final_path + "\n")


def color_change(val):
    """Color change."""

    def map_val_to_color(val):
        if val < -0.2:
            return "background-color: #00FF00"
        elif val < -0.1:
            return "background-color: #33FF00"
        elif val < -0.05:
            return "background-color: #66FF00"
        elif val < -0.01:
            return "background-color: #99FF00"
        elif val < 0:
            return "background-color: #CCFF00"
        elif val < 0.01:
            return "background-color: #FFCC00"
        elif val < 0.05:
            return "background-color: #FF9900"
        elif val < 0.1:
            return "background-color: #FF6600"
        elif val < 0.2:
            return "background-color: #FF3300"
        else:
            return "background-color: #FF0000"

    return [map_val_to_color(x) for x in val]


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Astra Planner metrics compare")
    parser.add_argument("--baseline", type=str, default="", help="abs file path of baseline ckpt metrics csv")
    parser.add_argument("--cmp", type=str, default="", help="abs file path of cmp ckpt metrics csv")
    parser.add_argument("--output", type=str, default="", help="output file name")
    args = parser.parse_args()

    cmp(args.baseline, args.cmp, args.output)
