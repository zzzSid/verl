# 1. Read Raw Data txt, generate train/infer/val/debug dataset txt file
input_file_list=("/share-global/yuesong.xie/share/planning_data/20240822/test_planner_new_30w_0819_1/test_planner_new_30w_0819_1.txt"
    "/share-global/yuesong.xie/share/planning_data/20240822/test_planner_dingxiang_0820_1/test_planner_dingxiang_0820_1.txt")
file_name="0822_30w_route_2k_overfit"
output_dir_path="/share-global/mccree.zhao/share/planning/dataset/${file_name}"
#/share-global/mccree.zhao/share/planning/dataset

# 3. Generate new dataset class file, which one should copy paste to tpp_onemodel/configs/planner/datasets.py
new_class_file="./new_dataset_class.txt"
new_class_file="./${file_name}_$(basename ${new_class_file})"

# 2. Scene tag export
tag_version="default"
target_tag_list=("UrbanTurnRightVehMerge" "UrbanTurnLeftVehMerge")
target_scene_file_name="target_scene.txt"
target_scene_file_name="${file_name}_${target_scene_file_name}"

echo $target_scene_file_name

# 1. Read Raw Data txt, generate train/infer/val/debug dataset txt file
python3 tpp_onemodel/tools/astra_planner/trainset_valset_filter.py \
    --input_file_list "${input_file_list[@]}" \
    --output_dir_path "$output_dir_path" \
    --file_name "$file_name"

if [ $? -ne 0 ]; then
    echo "trainset_valset_filter anomaly exit"
    exit 1
fi

# 2. Scene tag export
python3 tpp_onemodel/tools/astra_planner/scene_tags_export.py \
    --dataset_path "$output_dir_path" \
    --tag_version "$tag_version"

if [ $? -ne 0 ]; then
    echo "scene_tags_export anomaly exit"
    exit 1
fi

# 3. Generate new dataset class file, which one should copy paste to tpp_onemodel/configs/planner/datasets.py
python3 tpp_onemodel/tools/astra_planner/generate_dataset_class.py \
    --output_dataset_class_path "$new_class_file" \
    --root_dir "$output_dir_path" \
    --file_name "$file_name" \
    --target_tag_list "${target_tag_list[@]}" \
    --target_scene_file_name $target_scene_file_name

if [ $? -ne 0 ]; then
    echo "generate_dataset_class anomaly exit"
    exit 1
fi
