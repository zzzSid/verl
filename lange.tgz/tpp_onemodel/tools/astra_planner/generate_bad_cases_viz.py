# -*- coding: utf-8 -*-
"""Generate viz results."""
import argparse
import json
import os
import shutil
from multiprocessing import Pool
from os import listdir
from os.path import join

import numpy as np

from tpp_onemodel.tools.astra_planner.input_output_viz import plot_sample


def plot_bad_cases(bokeh_dir: str, eval_res: str):
    """Plot bokeh pickle result of dumped bad cases in the giving directory."""
    with open(eval_res, "r") as json_file:
        bad_cases = json.load(json_file)
    for bokeh_pkl in listdir(bokeh_dir):
        full_name = join(bokeh_dir, bokeh_pkl)
        if os.path.isdir(full_name):
            shutil.rmtree(full_name)
    bad_cases_key_map = dict()
    for key in bad_cases.keys():
        bad_cases_key_map[key] = key.replace("/", "_")

    num_processes = 16
    for f in listdir(args.bokeh_dir):
        bokeh_name, _ = f.split(".")
        full_name = join(args.bokeh_dir, f)
        dir_name = full_name + "_img"
        if os.path.isdir(dir_name):
            shutil.rmtree(dir_name)
        os.mkdir(dir_name)
        for key, val in bad_cases_key_map.items():
            os.mkdir(dir_name + "/" + val)
        raw_data = np.load(full_name, allow_pickle=True)
        inputs = []
        for idx, val in enumerate(raw_data):
            ts = val["timestamp"][-1]
            ts_str = str(val["timestamp"][-1])
            fn = ts_str + "_" + str(idx)
            fn = fn.replace(".", "_")
            for bad_case_name, bad_case_file_name in bad_cases_key_map.items():
                bad_case = bad_cases[bad_case_name]
                if bokeh_name in bad_case.keys():
                    target_time_stamps = set(bad_case[bokeh_name]["target_timestamps"])
                    if ts in target_time_stamps:
                        inputs.append((val, join(dir_name + "/" + bad_case_file_name, fn)))

        with Pool(processes=num_processes) as pool:
            # Use starmap to pass multiple arguments to the function in parallel
            pool.starmap(plot_sample, inputs)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--bokeh_dir", type=str, required=True, help="bokeh_dir")
    parser.add_argument("--eval_res", type=str, required=True, help="evaluation bad case time stamp")
    args = parser.parse_args()
    plot_bad_cases(args.bokeh_dir, args.eval_res)
