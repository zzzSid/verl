# -*- coding: utf-8 -*-
import argparse
import os
import pickle
import shutil
import tempfile

import requests


home_dir = os.path.expanduser("~")
# install niofs: https://nio.feishu.cn/wiki/wikcnZqogAFQsLoPBvAXhzCkQLe
CMD_NIOFS = f"{home_dir}/niofs-linux/bin/niofs"
oceanus_merge_api = "http://perception-mapping-backend.nioint.com/dispatch/api/v1/playback/merge_paths_version/playback"


def get_merge_paths(dataset_name: str, scene_name=None):
    """
    Get pkl merge paths from oceanus backend.

    Args:
        dataset_name: oceanus dataset name
        scene_name: scene name
    Returns:
        list of pkl merge paths
    """
    url = f"{oceanus_merge_api}/{dataset_name}"
    response = requests.get(url, timeout=10)
    if response.status_code == 200:
        data = response.json()["data"]
    else:
        raise requests.exceptions.HTTPError(
            f"Request to {url} failed with status code {response.status_code}: {response.text}"
        )
    ret = []
    for d in data[-1:]:
        if d["crowd_name"] == scene_name:
            ret.append(d["merge_path"])
    return ret


def main():
    """
    Execute main entry point for the script.

    It parses command-line arguments and saves the pkl cloud paths to a txt file.
    """
    parser = argparse.ArgumentParser(
        prog="oceanus_ds_to_txt",
        description="Request to get pkl cloud paths and save them to txt.",
        epilog="python tpp_onemodel/tools/astra_planner/oceanus_ds_to_txt.py -o <your_txt_file> -dt <oceanus_dataset_name>",
    )

    parser.add_argument(
        "-o",
        "--output_txt",
        help="output_txt",
        type=str,
        default="/share-global/yong.zhang15/share/planning/share/demo.txt",
    )
    parser.add_argument(
        "-dt",
        "--datasets",
        help="The names for oceanus datasets, separated by comma",
        type=str,
        default="prod_yx_20240918-match-rel-loc-5hz-part1,prod_yx_20240918-match-rel-loc-5hz-part2",
    )
    args = parser.parse_args()
    output_txt = args.output_txt
    datasets = args.datasets
    dataset_list = datasets.split(",")
    filepath_local = tempfile.mkdtemp()
    print(f"download file to temp dir: {filepath_local}")  # noqa: T201

    filepath_list = []
    for dataset_name in dataset_list:
        files = get_merge_paths(dataset_name)
        filepath_list.extend(files)

    for filepaths in filepath_list:
        for filepath in filepaths.split(","):
            cmd_str = f"{CMD_NIOFS} copy {filepath} {filepath_local}"
            os.system(cmd_str)  # noqa: S605

    f_txt = open(output_txt, "w")
    for file_pkl in os.listdir(filepath_local):
        with open(os.path.join(filepath_local, file_pkl), "rb") as f:
            list_pkl = pickle.load(f)
            print(f"{len(list_pkl)} pkl files in {file_pkl}")  # noqa: T201
            for pkl in list_pkl:
                f_txt.write(pkl + "\n")
    f_txt.close()
    shutil.rmtree(filepath_local)


if __name__ == "__main__":
    main()
