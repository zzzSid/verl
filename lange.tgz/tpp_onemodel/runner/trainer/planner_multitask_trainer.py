# -*- coding: utf-8 -*-
"""Trainer for astra planner."""
import copy
from typing import Any
from typing import Dict

import torch
from torchpilot.runner.trainer.tp_trainer import TPTrainer


class PlannerMultiTaskTrainer(TPTrainer):  # pylint: disable=too-many-instance-attributes
    """Trainer for training multitask.

    Args:
        multi_step_training (bool): Whether to enable multi step training.
            Default=`True`.
    """

    def __init__(self, enable_tasks=None, *args, **kwargs):
        """Init."""
        super().__init__(*args, **kwargs)

        self._enable_tasks = enable_tasks

    def _forward_backward_model(
        self,
        batch_data: Dict[str, Any],
        task_name: str = "",
    ) -> Dict[str, Any]:
        """Froward and backward model.

        Args:
            batch_data (Dict[str, Any]): One Batch data.
            task_name (str): Time cost prefix. Default=`""`.

        Returns:
            Model outputs (Dict[str, Any]).
        """
        # Get model outputs.
        self._stopwatch.set_time_cost_prefix(task_name)
        self._stopwatch.tic("ddp_cost")
        if not self._use_fp16 and not self._use_bf16:
            model_outputs, losses = self._model(batch_data)
        else:
            target_dtype = torch.bfloat16 if self._use_bf16 else torch.float16
            with torch.cuda.amp.autocast(enabled=True, dtype=target_dtype):
                model_outputs, losses = self._model(batch_data)

        # All Reduce loss value.
        self._stopwatch.tic("parse_loss_cost")
        loss_per_gpu_list = []
        for task_name in self._enable_tasks:
            task_loss = self._train_parse_losses(losses[task_name], task_name)
            loss_per_gpu_list.append(task_loss)
        loss_per_gpu = sum(loss_per_gpu_list)
        self._stopwatch.record_time_cost("parse_loss_cost", "grad_cost")

        # Normalize loss to account for batch accumulation.
        loss_per_gpu /= self._gradient_accumulate_step

        # Calculate Gradient
        if self._use_fp16 or self._use_bf16 or self._fsdp:
            self._scaler.scale(loss_per_gpu).backward()
        else:
            loss_per_gpu.backward()
        self._stopwatch.record_time_cost("grad_cost", None)
        self._stopwatch.reset_time_cost_prefix()
        return model_outputs

    def forward_backward_model(
        self,
        batch_data: Dict[str, Any],
        task_name: str = "",
    ) -> Dict[str, Any]:
        """Forward model.

        Args:
            batch_data (Dict[str, Any]): One Batch data.
            task_name (str): Time cost prefix. Default=`""`.

        Returns:
            Model outputs (Dict[str, Any]).
        """
        # For multi-step training, `batch_data` is expected to be a dict of
        # task-specific input data. Otherwise, `batch_data` is just the input
        # data for a single task.
        if self._multi_step_training:
            del task_name

            # Loop over task-specific data and accumulate the gradients.
            model_outputs = {}
            task_batch = list(batch_data.values())[0]
            for current_task_name in self._enable_tasks:
                cur_task_batch = copy.deepcopy(task_batch)
                cur_task_batch["task_name"] = current_task_name
                model_outputs[current_task_name] = super().forward_backward_model(cur_task_batch, current_task_name)
        else:
            task_batch = list(batch_data.values())[0]
            model_outputs = self._forward_backward_model(task_batch, task_name)
        return model_outputs
