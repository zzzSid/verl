# -*- coding: utf-8 -*-
"""Trainer for plannn3 speed (thin extension over plannn2 speed trainer)."""

from __future__ import annotations

import logging
import os
from typing import Any
from typing import Dict

import torch

from tpp_onemodel.runner.trainer.plannn2_speed_trainer import Plannn2SpeedTrainer

logger = logging.getLogger(__name__)


def _noop_run_with_merge_json(func, timeout, rank, *args):
    """Skip torchpilot startup cfg.json dump."""
    del func, timeout, rank, args


class Plannn3SpeedTrainer(Plannn2SpeedTrainer):
    """Plannn3 speed trainer with plannn3-visual sanity checks."""

    def __init__(self, skip_merge_json: bool = True, *args, **kwargs) -> None:
        if skip_merge_json:
            import torchpilot.runner.trainer.tp_trainer as tp_trainer_mod
            tp_trainer_mod.run_with_merge_json = _noop_run_with_merge_json
        super().__init__(*args, **kwargs)

    def _warp_taskflow_to_ddp_model(self) -> None:
        """Keep deterministic attention masks out of per-step DDP buffer broadcasts."""
        attention_masks = [
            name
            for name, _ in self._model.named_buffers()
            if name.endswith(".attn.bias")
        ]
        if attention_masks:
            torch.nn.parallel.DistributedDataParallel._set_params_and_buffers_to_ignore_for_model(
                self._model,
                attention_masks,
            )
            logger.info("Ignored %d static attention masks in DDP buffer sync.", len(attention_masks))
        super()._warp_taskflow_to_ddp_model()
