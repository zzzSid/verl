# -*- coding: utf-8 -*-
"""Trainer for plannn2."""

import logging
import torch
from tpp_onemodel.runner.trainer.plannn2_trainer import Plannn2Trainer
from typing import Any
from typing import Dict
from typing import List
from typing import Union
from collections import OrderedDict
from collections import defaultdict

logger = logging.getLogger(__name__)

class Plannn2SpeedTrainer(Plannn2Trainer):  # pylint: disable=too-many-instance-attributes
    def train_one_step_rl(
            self,
            epoch: int,
            step: int,
        ) -> Union[Dict[str, Any], torch.Tensor, Dict[str, Dict[str, Any]]]:
            """One step training.
            Args:
                epoch (int): Current epoch.
                step (int): Current step.
            Returns:
                Model outputs (Union[Dict[str, torch.Tensor], torch.Tensor]) and
                time cost (Dict[str, float]).
            """
            self._log_vars = OrderedDict()
            self._extra_summary = OrderedDict()
            # Get batch data
            if self._pure_model:
                if self._batch_data is None:  # get one successful batch data
                    self._batch_data = self.get_batch_data()
                batch_data = self._batch_data
            else:
                batch_data = self.get_batch_data()
                next_batch_data = self._next_data
            
            if not batch_data:
                return None

            if self._pure_dataloading:
                # If self._pure_dataloading, no need to train model.
                return None  # type: ignore[return-value]

            if self._rl_training:
                batch_data["iter_num"] = self._global_step
                self._stopwatch.tic("rollout_forward_cost")
                rollout_res = self._model.module.rollout_forward(batch_data)
                logger.info(f"Rollout Closed-loop Time: step:{self._global_step}")
                result = self._model.module.prepare_env_data(next_batch_data, self._global_step)
                logger.info(f"Prepare Next Env Data Time: step:{self._global_step}")
                self._stopwatch.record_time_cost("rollout_forward_cost", None)
                
            if hasattr(self._lr_scheduler, "step"):
                self._lr_scheduler.step(self._global_step, epoch)

            update_epochs_buffer: Dict[str, List[torch.Tensor]] = defaultdict(list)
            # full_polygon = rollout_res["full_polygons"]
            extra_summary = rollout_res["extra_summary"]
            loss_all,model_outputs = {}, {}
            self._stopwatch.tic("opt_cost")
            for i in range(self._rl_update_epochs):
                rollout_res["scaler"] = self._scaler
                rollout_res["update_epochs_buffer"] = update_epochs_buffer
                self._stopwatch.tic("train_policy_step_cost")
                model_outputs = self._model.module.train_policy_step(rollout_res)
                self._stopwatch.record_time_cost("train_policy_step_cost", None)

                self._stopwatch.tic("sync_grad_cost")
                for param in self._model.parameters():
                    if param.requires_grad and param.grad is not None:
                        torch.distributed.all_reduce(
                            param.grad, op=torch.distributed.ReduceOp.SUM
                        )
                        param.grad /= torch.distributed.get_world_size()
                self._stopwatch.record_time_cost("sync_grad_cost", None)

                self._stopwatch.tic("opt_cost")
                if self._clip_gradient != 0.0:
                    self._scaler.unscale_(self._optimizer)
                    torch.nn.utils.clip_grad_norm_(
                        self._model.parameters(), self._clip_gradient
                    )
                self._scaler.step(self._optimizer)
                if self._scaler._enabled:  # pylint: disable=protected-access
                    self._scaler.update()
                self._optimizer.zero_grad(set_to_none=True)
                self._stopwatch.record_time_cost("opt_cost", None)

            self._extra_summary[""] = model_outputs.get(
                "extra_summary",
                {},
            )
            self._log_vars[""] = model_outputs["loss"]
            return model_outputs
