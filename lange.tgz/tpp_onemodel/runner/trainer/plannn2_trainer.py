# -*- coding: utf-8 -*-
"""Trainer for astra planner."""

import logging
import itertools
import torch
import torch.distributed as dist
from datetime import timedelta
import time

from torch.optim import Optimizer
from torchpilot.runner.trainer.tp_trainer import TPTrainer

from tpp_onemodel.tools.plannn2.plannn2_build_optimizer import build_optimizer
from torchpilot.utils.stopwatch import StopwatchV2
from prettytable import PrettyTable
from torchpilot.utils.misc import is_torch_2_or_later

if is_torch_2_or_later():
    from torch.distributed.fsdp.fully_sharded_data_parallel import FullStateDictConfig
    from torch.distributed.fsdp.fully_sharded_data_parallel import (
        FullyShardedDataParallel,
    )
    from torch.distributed.fsdp.fully_sharded_data_parallel import StateDictType

logger = logging.getLogger(__name__)


class Plannn2Trainer(TPTrainer):  # pylint: disable=too-many-instance-attributes
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self._reward_stopwatch = StopwatchV2(True,False)
        self._model.module._stopwatch = self._stopwatch
        if self._model.module.rl_training:
            self._model.module.rl_reward_model._stopwatch = self._reward_stopwatch
        self._rollout_gpu_time = 0.0
        self._rollout_gpu_calls = 0


    def flush_rollout_events(self):
        self._rollout_gpu_calls += 1
        while self._model.module._rollout_events:
            start_event, end_event = self._model.module._rollout_events[0]
            end_event.synchronize()
            elapsed = start_event.elapsed_time(end_event) / 1e3
            self._rollout_gpu_time += elapsed

            self._model.module._rollout_events.popleft()

    def train_one_epoch(
        self,
        epoch: int,
    ) -> None:
        """One epoch training.

        Args:
            epoch (int): Current epoch.
        """
        if epoch > 0 and epoch == self._total_epochs - 1:  # last epoch
            cur_epoch_end_step = self._total_steps - epoch * self._one_epoch_size
        else:
            cur_epoch_end_step = self._one_epoch_size
        for self._step_idx in range(self._start_step, cur_epoch_end_step):
            # if self.skip_exception, skip this one step when occuring error,
            # else raise error and aborting this experiments
            try:
                self._stopwatch.tic("one_step_cost")
                if self._rl_training:
                    outputs = self.train_one_step_rl(epoch, self._step_idx)
                else:
                    outputs = self.train_one_step(epoch, self._step_idx)
                self._stopwatch.record_time_cost("one_step_cost", None)
                self._stopwatch.sync_for_cur_iter_and_prepare_for_next_iter()

            except Exception as ex:  # pylint: disable=broad-except
                logger.exception("Found error in step %d", self._step_idx)
                if not self._skip_exception:
                    raise ex
            else:
                # rely on outputs
                if "custom_sampler_indices" in self._func_hook_list:
                    indices = self._func_hook_list["custom_sampler_indices"](
                        self._log_vars, outputs
                    )
                    self._dataloader.set_state(
                        epoch=epoch, step=self._step_idx, indices=indices
                    )

            if self.msghub is not None:
                if len(self.msghub.get_read_cache_errors()) > self.msghub.tgt_err_num:
                    self._skip_exception = True
                    self.upload_errors(type_="read-cache-op")
                    raise Exception(
                        "read cache op error exceeds thresholds(default=woker_num*100"
                    )

            if self._use_profiler:
                self._profiler_handler.step()  # type: ignore[attr-defined]

            if self._step_idx % self._print_freq_by_step == 0:
                logger.info(self)  # see more details at `self.__str__()`.
                # self._stopwatch.reset()
                if dist.get_rank() == 0:
                    self.upload_training_progress(epoch, self._step_idx)

            if (
                self._save_ckpt_freq_by_step is not None
                and self._step_idx % self._save_ckpt_freq_by_step == 0
                and self._enable_save_ckpt
            ):
                if self._fsdp:
                    with FullyShardedDataParallel.state_dict_type(
                        self._model,
                        StateDictType.FULL_STATE_DICT,
                        FullStateDictConfig(offload_to_cpu=True, rank0_only=True),
                    ):
                        self._ckpt_manager.save_checkpoint(
                            epoch=epoch,
                            step=self._step_idx + 1,
                            max_save_ckpt_num=self._max_save_ckpt_num,
                            save_by_freq=True,
                        )
                else:
                    self._ckpt_manager.save_checkpoint(
                        epoch=epoch,
                        step=self._step_idx + 1,
                        max_save_ckpt_num=self._max_save_ckpt_num,
                        save_by_freq=True,
                    )

            self._global_step += 1

        # save last step ckpt
        if self._fsdp:
            with FullyShardedDataParallel.state_dict_type(
                self._model,
                StateDictType.FULL_STATE_DICT,
                FullStateDictConfig(offload_to_cpu=True, rank0_only=True),
            ):
                self._ckpt_manager.save_checkpoint(
                    epoch=self._epoch_idx + 1,
                    step=self._step_idx,
                )
        else:
            self._ckpt_manager.save_checkpoint(
                epoch=self._epoch_idx + 1,
                step=self._step_idx,
            )

        if self._step_idx % self._print_freq_by_step != 0:
            logger.info(self)
            self._stopwatch.reset()

        # reset start_step
        self._start_step = 0
        self._step_idx = 0

    def format_rl_reward_time_cost(self, time_cost_mean_dict, extra_msg):
        rl_lines = []

        prefix = "rl_reward_model/"
        rl_items = {k: v for k, v in time_cost_mean_dict.items() if k.startswith(prefix)}
        if not rl_items:
            return [], time_cost_mean_dict

        # 从原 dict 中移除，避免重复打印
        for k in rl_items:
            time_cost_mean_dict.pop(k, None)


        pre_cost = rl_items.get(f"{prefix}pre_process", 0.0)
        calc_cost = rl_items.get(f"{prefix}calc_rewards", 0.0)
        post_cost = rl_items.get(f"{prefix}post_process", 0.0)

        if pre_cost > 0:
            rl_lines.append(
                f"{prefix}pre_process-{extra_msg}: {pre_cost:.{self._log_prec}f}"
            )
        if calc_cost > 0:
            rl_lines.append(
                f"{prefix}calc_rewards-{extra_msg}: {calc_cost:.{self._log_prec}f}"
            )

        if post_cost > 0:
            rl_lines.append(
                f"{prefix}post_process-{extra_msg}: {post_cost:.{self._log_prec}f}"
            )

        reward_prefix = f"{prefix}calc_rewards/"
        reward_items = [
            (k[len(reward_prefix):], v)
            for k, v in rl_items.items()
            if k.startswith(reward_prefix)
        ]

        if reward_items:
            for name, cost in sorted(reward_items, key=lambda x: -x[1]):
                rl_lines.append(
                    f"calc_rewards/{name}-{extra_msg}: {cost:.{self._log_prec}f}"
                )

        return rl_lines, time_cost_mean_dict

    def __str__(self) -> str:
        """Represent trainer info as table."""
        table = PrettyTable()

        # loss
        loss_info_list = []
        for task_name, task_loss in self._log_vars.items():
            if task_name != "":
                loss_info_list.append(f"Task: {task_name}")
                loss_prefix = task_name + "/"
            else:
                loss_prefix = ""
            loss_info_list.append(
                f"{loss_prefix}loss: {task_loss['loss']:.{self._log_prec}f}"
            )
            loss_info_list.extend(
                [
                    f"{loss_prefix}{loss_name}: {loss_value:.{self._log_prec}f}"
                    for loss_name, loss_value in task_loss.items()
                    if loss_name != "loss"
                ]
            )
        # extra summary
        extra_summary_list = []
        has_extra_summary = False
        for task_name, task_extra_summary in self._extra_summary.items():
            if len(task_extra_summary) == 0:
                continue
            has_extra_summary = True
            if task_name != "":
                extra_summary_list.append(f"Task: {task_name}")
                extra_summary_prefix = task_name + "/"
            else:
                extra_summary_prefix = ""
            for extra_summary_name, extra_summary_value in task_extra_summary.items():
                _extra_summary_value = (
                    extra_summary_value.item()
                    if isinstance(extra_summary_value, torch.Tensor)
                    else extra_summary_value
                )
                extra_summary_list.append(
                    f"{extra_summary_prefix}{extra_summary_name}: {_extra_summary_value:.{self._log_prec}f}"  # pylint: disable=line-too-long # noqa: E501
                )

        filed_names = ["Basic Info", "Loss", "CPU Time Cost", "CUDA Time Cost"]
        if has_extra_summary:
            filed_names.insert(2, "Extra Summary")
        table.field_names = filed_names
        table.align["Loss"] = "r"
        table.align["CPU Time Cost"] = "r"
        table.align["CUDA Time Cost"] = "r"
        if has_extra_summary:
            table.align["Extra Summary"] = "r"

        # time_cost
        time_cost_mean_dict = self._stopwatch.time_cost_mean("cpu")
        one_step_time_cost = time_cost_mean_dict.pop("one_step_cost", 0.0)

        reward_time_cost_mean_dict = self._reward_stopwatch.time_cost_mean("cpu")
        rl_reward_time_cost, rl_time_cost_mean_dict = self.format_rl_reward_time_cost(reward_time_cost_mean_dict,"cpu")
        time_cost = self.format_time_cost(time_cost_mean_dict, "cpu")
        time_cost =  time_cost + rl_reward_time_cost

        time_cost_mean_dict_cuda = self._stopwatch.time_cost_mean("cuda")
        one_step_time_cost_cuda = time_cost_mean_dict_cuda.pop("one_step_cost", 0.0)
        time_cost_cuda = self.format_time_cost(time_cost_mean_dict_cuda, "cuda")

        self.flush_rollout_events()
        rollout_cost_cuda = [f"rollout_closed_cost/rollout_cost-cuda: {self._rollout_gpu_time/self._rollout_gpu_calls:.{self._log_prec}f}"]
        time_cost_cuda = time_cost_cuda + rollout_cost_cuda



        world_size = dist.get_world_size() if dist.is_available() else 1
        # compute training consumed and eta time
        time_consumed = timedelta(seconds=int(time.time() - self._time_anchor))
        # 由于max_iters模式下total_steps已经设为max_iters，直接使用total_steps即可
        remaining_steps = self._total_steps - self._global_step
        eta_training_seconds = one_step_time_cost * remaining_steps
        eta_training = timedelta(seconds=int(eta_training_seconds))
        # ETA of current epoch
        eta_curr_epoch_seconds = one_step_time_cost * (
            self._one_epoch_size - self._global_step % self._one_epoch_size
        )
        eta_curr_epoch = timedelta(seconds=int(eta_curr_epoch_seconds))

        one_step_samples = self._bs_per_gpu * world_size

        if one_step_time_cost > 0.0:
            time_cost = [
                f"sample/s: {one_step_samples / one_step_time_cost:.{self._log_prec}f}",
                f"iter/s: {1.0 / one_step_time_cost:.{self._log_prec}f}",
            ] + time_cost
        if one_step_time_cost_cuda:
            time_cost_cuda = [
                f"sample/s: {one_step_samples / one_step_time_cost_cuda:.{self._log_prec}f}",  # pylint: disable=line-too-long # noqa: E501
                f"iter/s: {1.0 / one_step_time_cost_cuda:.{self._log_prec}f}",
            ] + time_cost_cuda
        # use tensorboard log info
        if self._use_tensorboard:
            lr_info = [
                f"lr_total: {self._optimizer.param_groups[0]['lr']}",
                f"lr_per_sample: {self._lr_per_sample}",
            ]
            self._summary.log_scaler(loss_info_list, self._global_step)
            self._summary.log_scaler(time_cost, self._global_step)
            self._summary.log_scaler(time_cost_cuda, self._global_step)
            self._summary.log_scaler(lr_info, self._global_step)
            if has_extra_summary:
                self._summary.log_scaler(
                    extra_summary_list, self._global_step, tag_prefix="extra-summary"
                )

        time_cost = [
            f"time_consumed: {time_consumed.__str__()}",
            f"eta_training: {eta_training.__str__()}",
            f"eta_curr_epoch: {eta_curr_epoch.__str__()}",
        ] + time_cost

        time_cost_cuda = [""] * 3 + time_cost_cuda
        # basic info
        basic_info = [
            f"run_name: {self._run_name}",
            f"rank: {self._rank}",
            f"word_size: {self._gpu_num}",
            f"batch_per_gpu: {self._bs_per_gpu}",
            f"lr_total: {self._optimizer.param_groups[0]['lr']}",
            f"lr_per_sample: {self._lr_per_sample}",
            f"sample_per_epoch: {self._sample_per_epoch}",
            f"sample_num_per_gpu: {self._sample_num_per_gpu}",
            f"epoch: {self._epoch_idx}/{self._total_epochs}, "
            f"{int(self._epoch_idx / self._total_epochs * 100)}%",
            f"step: {self._global_step}/{self._total_steps}, "
            f"{int(self._global_step / self._total_steps * 100)}%",
            f"total_norm: {self._total_norm.item()}",
        ]

        all_info_list = [
            basic_info,
            loss_info_list,
            time_cost,
            time_cost_cuda,
        ]
        if has_extra_summary:
            all_info_list.insert(2, extra_summary_list)
        for data_row_list in itertools.zip_longest(
            *all_info_list,
            fillvalue="",
        ):
            table.add_row(data_row_list)
        return f"\n{table.get_string()}"

    def _build_optimizer(self) -> None:
        """Build optimizer."""
        self._model.cuda()
        model_params_policy_ = self._model.get_optim_policies()
        weight_decay = self._cfg.optimizer.get("weight_decay", 0.0)
        model_params_policy = [
            {"params": model_params_policy_["decay_params"], "weight_decay": weight_decay},
            {"params": model_params_policy_["nodecay_params"], "weight_decay": 0.0},
        ]

        self._cfg.optimizer.params_policy = model_params_policy
        if self._rl_training:
            self._cfg.optimizer.lr = 0.0
        else:
            self._cfg.optimizer.lr = self._lr_per_sample * self._gpu_num * self._bs_per_gpu

        self._optimizer = build_optimizer(**(self._cfg.optimizer))

        if not isinstance(self._optimizer, Optimizer):
            raise ValueError(f"Expect type(self._optimizer)=Optimizer, " f"but got {type(self._optimizer)}.")
