# -*- coding: utf-8 -*-
"""Inferer for astra planner."""
from typing import Any

from torchpilot.runner.inferrer.tp_inferrer import InferType
from torchpilot.runner.inferrer.tp_inferrer import TPInferrer
from torchpilot.utils.registries import INFERRER


@INFERRER.register_module()
class PlannerMultiTaskInferrer(TPInferrer):
    """Inferrer for astra planner model."""

    def infer_one_step(self) -> Any:
        """One step infering.

        Returns:
            One step eval results.
        """
        # Get batch data
        self._stopwatch.tic("data_cost")
        batch_data = self._dataloader.get_batch_data()
        task_batch_data = list(batch_data.values())[0]
        self._stopwatch.record_time_cost("data_cost", None)

        # Preprocess data for tracing model.
        self._stopwatch.tic("eval_cost")
        model_inputs = self.convert_model_inputs(task_batch_data)

        # Get model outputs
        outputs = self.forward_model(model_inputs)

        # Preprocess data for tracing model.
        outputs = self.convert_model_outputs(outputs, task_batch_data)

        eval_results = self._evaluator.eval(outputs, task_batch_data)
        self._stopwatch.record_time_cost("eval_cost", None)

        return eval_results

    def convert_model_outputs(self, outputs, batch_data):
        """Convert model outputs."""
        if self._infer_type == InferType.TRACE.value:
            self._stopwatch.tic("trace_model_outputs_hook")
            outputs = self._taskflow.trace_model_outputs_hook(outputs, batch_data)
            self._stopwatch.record_time_cost("trace_model_outputs_hook", None)
        elif self._infer_type == InferType.TVM.value:
            self._stopwatch.tic("tvm_model_outputs_hook")
            outputs = self._taskflow.tvm_model_outputs_hook(outputs, batch_data)
            self._stopwatch.record_time_cost("tvm_model_outputs_hook", None)

        return outputs
