import logging

import torch
from torchpilot.runner.inferrer.tp_inferrer import InferType
from torchpilot.runner.inferrer.tp_inferrer import TPInferrer
from tqdm import tqdm


logger = logging.getLogger(__name__)

class Plannn2Inferrer(TPInferrer):
    def __init__(
        self,
        rl_infer: bool = False,
        openloop_eval: bool = False,
        *args,
        **kwargs,

    ):
        super().__init__(*args,**kwargs)
        self._rl_infer = rl_infer
        self._openloop_eval = openloop_eval

    def forward_model(self, model_inputs, task_name=""):
        if self._rl_infer:
            self._stopwatch.set_time_cost_prefix(task_name)
            # if self._infer_type == InferType.TVM.value:
            #     self._stopwatch.tic("model_run_cost")
            #     outputs = self._model.run(model_inputs)
            #     self._stopwatch.record_time_cost("model_run_cost", None)
            # elif self._infer_type == InferType.TRACE.value:
            #     self._stopwatch.tic("model_forward_cost")
            #     if self._use_fp16:
            #         with torch.cuda.amp.autocast(enabled=self._use_fp16):
            #             outputs = self._model(*model_inputs)
            #     else:
            #         outputs = self._model(*model_inputs)
            #     self._stopwatch.record_time_cost("model_forward_cost", None)
            # else:
            self._stopwatch.tic("ddp_cost")
            outputs = self._model.module.forward_model_rl(model_inputs)
            self._stopwatch.record_time_cost("ddp_cost", None)
                # if self._use_fp16:
                #     with torch.cuda.amp.autocast(enabled=self._use_fp16):
                #         outputs = self._model(model_inputs)
                # else:
                #     outputs = self._model(model_inputs)
            self._stopwatch.reset_time_cost_prefix()

            return outputs
        elif self._openloop_eval:
            task_flow = self._model.module
            if hasattr(task_flow, "forward_model_openloop_infer"):
                outputs = task_flow.forward_model_openloop_infer(model_inputs)
            else:
                outputs = task_flow.forward_model_openloop_eval(model_inputs)
            return outputs
        else:
            return super().forward_model(model_inputs, task_name)
