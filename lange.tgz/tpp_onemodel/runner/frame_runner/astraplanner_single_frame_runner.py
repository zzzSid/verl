# -*- coding: utf-8 -*-
import os
from typing import Any
from typing import Dict
from typing import List

import numpy as np
import torch
from torchpilot.utils.cfg_parser import PyConfig
from torchpilot.utils.checkpoint_manager import CheckpointManager
from torchpilot.utils.registries import TASK_FLOW


class AstraPlannerSingleCaseRunner:
    """Init."""

    def __init__(self, output_path=None, cfg_name=None, checkpoint=None, clip_path=None) -> None:

        self.pkl_load_path = os.path.join(output_path, "export/bokeh", clip_path)
        self.cfg_path = os.path.join(output_path, cfg_name)

        self.cfg = PyConfig.fromfile(self.cfg_path)
        self.checkpoint = checkpoint
        self.task_flow = TASK_FLOW.build(self.cfg.infer_task_flow)

    def build_model_and_set_mode(self, train_mode: bool = False) -> None:
        """Build up model and set mode.

        Args:
            train_mode (Dict[str, Any])

        Returns:
            None.
        """
        if self.checkpoint is not None:
            CheckpointManager(
                model=self.task_flow,
                optimizer=None,
                lr_scheduler=None,
                scaler=None,
                save_dir=None,
                pretrain_model=self.checkpoint,
                resume=False,
                to_cuda=self.cfg.infer_ckpt.to_cuda,
                ckpt2model_json=self.cfg.infer_ckpt.ckpt2model_json,
                trace_mode=True,
            ).load_model()

        if train_mode:
            self.task_flow.train()
        else:
            self.task_flow.eval()
        self.task_flow.cuda()
        return

    def run_one_batch(self, model_input: Dict[str, Any]) -> Dict[str, Any]:
        """Run One Batch.

        Args:
            model_inputs (Dict[str, Any]): Model_inputs, i.e. ground truth.

        Returns:
            model_output.
        """
        inputs = dict()
        for k, v in model_input.items():
            if isinstance(v, np.ndarray):
                inputs[k] = torch.from_numpy(v).unsqueeze(0).cuda()
            else:
                inputs[k] = v
        return self.task_flow(inputs)

    def load_frame_data(self) -> List[Dict[str, Any]]:
        """Load frame.

        Args:
            None.

        Returns:
            target_data.
        """
        all_data = np.load(self.pkl_load_path, allow_pickle=True)
        target_data = []
        for data in all_data:
            tmp_data = dict()
            for k, v in data["model_inputs"].items():
                tmp_data[k] = v
            target_data.append(tmp_data)
        return target_data
