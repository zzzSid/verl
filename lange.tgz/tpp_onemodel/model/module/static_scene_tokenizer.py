# -*- coding: utf-8 -*-
import torch
import torch.nn as nn
from torchpilot.model.module_interface import BaseModule
from torchpilot.utils.registries import MODULE


class StaticSceneTokenizer(BaseModule):
    """Auto-regressive planner input tokenizer."""

    def __init__(
        self,
        static_sensor_tokenizer_cfg=None,
        command_tokenizer_cfg=None,
        sensor_embedding_dim=256,
        sensor_index_dict=None,
        train_mode=True,
    ):
        """Init."""
        super().__init__(train_mode=train_mode)
        self._static_sensor_tokenizer = (
            MODULE.build(static_sensor_tokenizer_cfg) if static_sensor_tokenizer_cfg else None
        )
        self._command_tokenizer = MODULE.build(command_tokenizer_cfg) if command_tokenizer_cfg else None
        self._sensor_embedding = (
            torch.nn.Embedding(len(sensor_index_dict), sensor_embedding_dim) if sensor_index_dict else None
        )
        self.static_sensor_list = (
            list(static_sensor_tokenizer_cfg["static_sensor_tokenizer_cfg_dict"].keys())
            if static_sensor_tokenizer_cfg
            else []
        )
        self.command_sensor_list = (
            list(command_tokenizer_cfg["command_sensor_tokenizer_cfg_dict"].keys()) if command_tokenizer_cfg else []
        )
        for sensor, index in sensor_index_dict.items():
            self.register_buffer(f"{sensor}_sensor_index", torch.tensor(index).cuda())

    def train_forward(self, model_inputs):
        """Train forward."""
        static_inputs, command_inputs = self._format_inputs(model_inputs)
        static_tokens = self._static_sensor_tokenizer(static_inputs) if self._static_sensor_tokenizer else {}
        command_tokens = self._command_tokenizer(command_inputs) if self._command_tokenizer else {}

        static_tokens, command_tokens = self.sensor_index_embedding(static_tokens, command_tokens)

        return {"static_tokens": static_tokens, "command_tokens": command_tokens}

    def infer_forward(self, model_inputs):
        """Infer forward."""
        return self.train_forward(model_inputs)

    def sensor_index_embedding(self, static_tokens, command_tokens):
        """Sensor index embedding."""

        def sensor_token_index_emb(token_dict):
            for sensor in token_dict:
                token_dict[sensor] = (
                    self._sensor_embedding(getattr(self, f"{sensor}_sensor_index")) + token_dict[sensor]
                )
            return token_dict

        static_tokens = sensor_token_index_emb(static_tokens) if static_tokens else {}
        command_tokens = sensor_token_index_emb(command_tokens) if command_tokens else {}
        return static_tokens, command_tokens

    def _format_inputs(self, model_inputs):
        """Format inputs."""
        static_inputs = self._format_static_inputs(model_inputs)
        command_inputs = self._format_command_inputs(model_inputs)

        return static_inputs, command_inputs

    def _format_static_inputs(self, model_inputs):
        """Format static inputs."""
        formatted_static_inputs = {}
        for sensor, sensor_data_dict in model_inputs.items():
            if sensor in self.static_sensor_list:
                formatted_static_inputs.update(getattr(self, f"_format_{sensor}_inputs")(sensor_data_dict))
        return formatted_static_inputs

    def _format_lane_inputs(self, lane_data_dict):
        """Format lane inputs."""
        return {"lane": lane_data_dict}

    def _format_navi_path_inputs(self, navi_path_data_dict):
        """Format navigation path inputs."""
        return {"navi_path": navi_path_data_dict}

    def _format_current_od_inputs(self, current_od_data_dict):
        """Format current OD inputs."""
        return {"current_od": current_od_data_dict}

    def _format_tld_inputs(self, tld_data_dict):
        """Format TLD inputs."""
        return {"tld": tld_data_dict}

    def _format_control_point_inputs(self, control_point_data_dict):
        """Format control point inputs."""
        return {"control_point": control_point_data_dict}

    def _format_command_inputs(self, model_inputs):
        """Format command inputs."""
        formatted_command_inputs = {}
        for sensor, sensor_data_dict in model_inputs.items():
            if sensor in self.command_sensor_list:
                formatted_command_inputs.update(getattr(self, f"_format_{sensor}_inputs")(sensor_data_dict))
        return formatted_command_inputs


class StaticSensorTokenizer(BaseModule):
    """Static sensor tokenizer."""

    def __init__(self, train_mode=True, static_sensor_tokenizer_cfg_dict=None):
        """Init."""
        super().__init__(train_mode=train_mode)
        self.static_sensor_tokenizer_cfg_dict = static_sensor_tokenizer_cfg_dict
        self._static_sensor_tokenizer = {}
        if self.static_sensor_tokenizer_cfg_dict:
            for sensor in static_sensor_tokenizer_cfg_dict:
                self._static_sensor_tokenizer[sensor] = MODULE.build(static_sensor_tokenizer_cfg_dict[sensor])
            self._static_sensor_tokenizer = torch.nn.ModuleDict(self._static_sensor_tokenizer)
        else:
            self._static_sensor_tokenizer = None

    def train_forward(self, model_inputs):
        """Train forward."""
        static_tokens = {}
        for sensor in self.static_sensor_tokenizer_cfg_dict:
            static_tokens[sensor] = self._static_sensor_tokenizer[sensor](model_inputs[sensor])
        return static_tokens

    def infer_forward(self, model_inputs):
        """Infer forward."""
        return self.train_forward(model_inputs)


class CommandSensorTokenizer(BaseModule):
    """Command sensor tokenizer."""

    def __init__(self, train_mode=True, command_sensor_tokenizer_cfg_dict=None):
        """Init."""
        super().__init__(train_mode=train_mode)
        self.command_sensor_tokenizer_cfg_dict = command_sensor_tokenizer_cfg_dict
        self._command_sensor_tokenizer = {}
        if self.command_sensor_tokenizer_cfg_dict:
            for sensor in command_sensor_tokenizer_cfg_dict:
                self._command_sensor_tokenizer[sensor] = MODULE.build(command_sensor_tokenizer_cfg_dict[sensor])
            self._command_sensor_tokenizer = torch.nn.ModuleDict(self._command_sensor_tokenizer)
        else:
            self._command_sensor_tokenizer = None

    def train_forward(self, model_inputs):
        """Train forward."""
        command_tokens = {}
        for sensor in self.command_sensor_tokenizer_cfg_dict:
            command_tokens[sensor] = self._command_sensor_tokenizer[sensor](model_inputs[sensor])
        return command_tokens

    def infer_forward(self, model_inputs):
        """Infer forward."""
        return self.train_forward(model_inputs)


class StaticLaneTokenizer(BaseModule):
    """Static lane tokenizer."""

    def __init__(
        self,
        embedding_cfg=None,
        points_attn_cfg=None,
        lane_feat_attn_cfg=None,
        norm_range=[-100, 200, -50, 50],
        lane_type_num=3,
        lane_attr_num=20,
        type_embed_dim=24,
        attn_dim=256,
        points_attn_layer=2,
        lane_feat_attn_layer=2,
        lane_feat_num=100,
        train_mode=True,
    ):
        """Init."""
        super().__init__(train_mode=train_mode)

        self.embedding_cfg = embedding_cfg

        self.norm_range = norm_range

        self._embedding = MODULE.build(embedding_cfg) if embedding_cfg else None

        self._lane_type_embedding = torch.nn.Embedding(lane_type_num + 1, type_embed_dim)
        self._lane_attr_embedding_0 = torch.nn.Embedding(lane_attr_num + 1, type_embed_dim)
        self._lane_attr_embedding_1 = torch.nn.Embedding(lane_attr_num + 1, type_embed_dim)

        self._lane_query = torch.nn.Parameter(torch.randn(1, attn_dim))
        self.points_attn_layer = points_attn_layer
        self.lane_feat_attn_layer = lane_feat_attn_layer

        self.lane_feat_pos_embedding = torch.nn.Embedding(lane_feat_num, attn_dim)
        self.lane_feat_query = torch.nn.Parameter(torch.randn(lane_feat_num, attn_dim))

        self.points_attn = torch.nn.ModuleList([MODULE.build(points_attn_cfg) for _ in range(points_attn_layer)])
        self.lane_feat_attn = torch.nn.ModuleList(
            [MODULE.build(lane_feat_attn_cfg) for _ in range(lane_feat_attn_layer)]
        )
        self.points_attn_ln = torch.nn.ModuleList([torch.nn.LayerNorm(attn_dim) for _ in range(points_attn_layer)])
        self.lane_feat_attn_ln = torch.nn.ModuleList(
            [torch.nn.LayerNorm(attn_dim) for _ in range(lane_feat_attn_layer)]
        )

        self.points_ffn = torch.nn.Sequential(
            torch.nn.Linear(attn_dim, attn_dim),
            torch.nn.ReLU(),
            torch.nn.Linear(attn_dim, attn_dim),
        )
        self.lane_ffn = torch.nn.Sequential(
            torch.nn.Linear(attn_dim, attn_dim),
            torch.nn.ReLU(),
            torch.nn.Linear(attn_dim, attn_dim),
        )

    def train_forward(self, lane_data_dict):
        """Train forward."""
        lane_data_normed, lane_mask = self.preprocess(lane_data_dict)
        lane_embedding = self._embedding(lane_data_normed) if self._embedding else None
        lane_tokens = self.tokenize(lane_embedding, lane_mask)

        return lane_tokens

    def tokenize(self, lane_embedding, lane_points_mask):
        """Tokenize."""
        bs, lane_num, points_num, embed_dim = lane_embedding.size()
        lane_query = self._lane_query.expand(bs, lane_num, 1, -1)

        for layer_idx in range(self.points_attn_layer):
            lane_query = self.points_attn_ln[layer_idx](
                lane_query + self.points_attn[layer_idx](lane_query, lane_embedding, lane_points_mask)
            )
        lane_feat_raw = self.points_ffn(lane_query.squeeze(-2))  # [B,100,D]

        lane_mask = lane_points_mask.min(dim=-1)[0]  # [B,100]

        lane_feat_query = self.lane_feat_query + self.lane_feat_pos_embedding.weight  # [100,D]
        lane_feat_query = lane_feat_query.unsqueeze(0).expand(bs, -1, -1)  # [B,100,D]

        for layer_idx in range(self.lane_feat_attn_layer):
            lane_feat_query = self.lane_feat_attn_ln[layer_idx](
                lane_feat_query + self.lane_feat_attn[layer_idx](lane_feat_query, lane_feat_raw, lane_mask)
            )

        lane_feature = self.lane_ffn(lane_feat_query)

        return lane_feature

    def preprocess(self, lane_data_dict):
        """Lane normalization."""
        points = lane_data_dict["points"]
        lane_mask = (torch.abs(points + 1.0) < 1e-6).min(dim=-1)[0]
        normed_points = self.normalize_points(points)

        lane_types = lane_data_dict["types"]
        lane_types_embed = self._lane_type_embedding((lane_types + 1).long())

        lane_attr = lane_data_dict["attr"]
        lane_attr_0_embed = self._lane_attr_embedding_0((lane_attr[:, :, :, 0] + 1).long())
        lane_attr_1_embed = self._lane_attr_embedding_1((lane_attr[:, :, :, 1] + 1).long())
        lane_attr_embed = torch.cat([lane_attr_0_embed, lane_attr_1_embed], dim=-1)

        lane_data_normed = torch.cat([normed_points, lane_types_embed, lane_attr_embed], dim=-1)

        return lane_data_normed, lane_mask

    def normalize_points(self, points):
        """Normalize points."""
        x_min, x_max, y_min, y_max = self.norm_range
        normed_points = (points - torch.tensor([x_min, y_min], device="cuda")) / torch.tensor(
            [x_max - x_min, y_max - y_min], device="cuda"
        )

        return normed_points

    def infer_forward(self, lane_data_dict):
        """Infer forward."""
        return self.train_forward(lane_data_dict)


class StaticCurrentODTokenizer(BaseModule):
    """Static current OD tokenizer."""

    def __init__(
        self,
        embedding_cfg=None,
        norm_range=None,
        attn_layer_cfg=None,
        attn_layer_num=2,
        cur_od_feat_num=24,
        cur_od_feat_dim=256,
        train_mode=True,
    ):
        """Init."""
        super().__init__(train_mode=train_mode)
        self.embedding = MODULE.build(embedding_cfg) if embedding_cfg else None
        self.norm_range = norm_range
        self.cur_od_query = torch.nn.Parameter(torch.randn(cur_od_feat_num, cur_od_feat_dim))
        self.cur_od_query_pos_embedding = torch.nn.Embedding(cur_od_feat_num, cur_od_feat_dim)

        self.attn_layer = torch.nn.ModuleList([MODULE.build(attn_layer_cfg) for _ in range(attn_layer_num)])
        self.attn_layer_num = attn_layer_num

        self.attn_layer_ln = torch.nn.ModuleList([torch.nn.LayerNorm(cur_od_feat_dim) for _ in range(attn_layer_num)])
        self.cur_od_ffn = torch.nn.Sequential(
            torch.nn.Linear(cur_od_feat_dim, cur_od_feat_dim),
            torch.nn.ReLU(),
            torch.nn.Linear(cur_od_feat_dim, cur_od_feat_dim),
        )

    def train_forward(self, current_od_state):
        """Train forward."""
        current_od_mask = (torch.abs(current_od_state) < 1e-6).all(-1)
        current_od_state_normed = self.normalize_cur_od(current_od_state)
        current_od_state_normed = torch.where(current_od_mask.unsqueeze(-1), 0, current_od_state_normed)

        current_od_state_embedding = self.embedding(current_od_state_normed) if self.embedding else None
        current_od_state_token = self.tokenize(current_od_state_embedding, current_od_mask)

        return current_od_state_token

    def normalize_cur_od(self, current_od_state):
        """Normalize current OD state."""
        current_od_state_normed = torch.stack(
            (
                (current_od_state[:, :, 0] - self.norm_range[0]) / (self.norm_range[1] - self.norm_range[0]),
                (current_od_state[:, :, 1] - self.norm_range[2]) / (self.norm_range[3] - self.norm_range[2]),
                (current_od_state[:, :, 2] - self.norm_range[4]) / (self.norm_range[5] - self.norm_range[4]),
                (current_od_state[:, :, 3] - self.norm_range[6]) / (self.norm_range[7] - self.norm_range[6]),
                (current_od_state[:, :, 4] - self.norm_range[8]) / (self.norm_range[9] - self.norm_range[8]),
                torch.sin(current_od_state[:, :, 5]),
                torch.cos(current_od_state[:, :, 5]),
                (current_od_state[:, :, 6] - self.norm_range[10]) / (self.norm_range[11] - self.norm_range[10]),
            ),
            -1,
        )

        return current_od_state_normed

    def tokenize(self, current_od_state_embedding, current_od_mask):
        """Tokenize."""
        bs = current_od_state_embedding.size(0)
        cur_od_query = (self.cur_od_query + self.cur_od_query_pos_embedding.weight).unsqueeze(0).expand(bs, -1, -1)

        for layer_idx in range(self.attn_layer_num):
            cur_od_query = self.attn_layer_ln[layer_idx](
                cur_od_query + self.attn_layer[layer_idx](cur_od_query, current_od_state_embedding, current_od_mask)
            )

        return cur_od_query

    def infer_forward(self, current_od_state):
        """Infer forward."""
        return self.train_forward(current_od_state)


class CommandNaviPathTokenizer(BaseModule):
    """Static navigation path tokenizer."""

    def __init__(
        self,
        norm_range=[-100, 200, -50, 50],
        input_dim=400,
        hidden_dim=256,
        embed_dim=256,
        query_num=10,
        points_attn_cfg=None,
        points_attn_layer=2,
        train_mode=True,
    ):
        """Init."""
        super().__init__(train_mode=train_mode)
        self.norm_range = norm_range
        self.mlp = torch.nn.Sequential(
            torch.nn.Linear(input_dim, hidden_dim),
            torch.nn.ReLU(),
            torch.nn.Linear(hidden_dim, embed_dim),
        )
        self.points_attn_cfg = points_attn_cfg
        if points_attn_cfg is not None:
            self.navi_path_query = torch.nn.Parameter(torch.randn(query_num, embed_dim))

            self.points_attn = torch.nn.ModuleList([MODULE.build(points_attn_cfg) for _ in range(points_attn_layer)])
            self.points_attn_ln = torch.nn.ModuleList([torch.nn.LayerNorm(embed_dim) for _ in range(points_attn_layer)])
            self.points_ffn = torch.nn.Sequential(
                torch.nn.Linear(embed_dim, embed_dim),
                torch.nn.ReLU(),
                torch.nn.Linear(embed_dim, embed_dim),
            )
            self.points_attn_layer = points_attn_layer
            self.navi_path_class = torch.nn.Embedding(3, embed_dim)

    def train_forward(self, navi_path_data_dict):
        """Train forward."""
        navi_lane_processed = self.preprocess(navi_path_data_dict)
        bs, navi_lane_num, points_num, _ = navi_lane_processed.size()
        if self.points_attn_cfg is not None:
            navi_lane_token = self.mlp(navi_lane_processed)  # [B,M=1,N=200,D]
            navi_lane_mask = (
                torch.zeros(bs, navi_lane_num, points_num).bool().cuda()
            )  # [B,M=1,N=200], zeros means valid
            navi_path_query = self.navi_path_query.unsqueeze(0).expand(bs, -1, -1).unsqueeze(1)  # [B,1,Q=10,D]
            navi_path_class_query = (
                self.navi_path_class.weight.unsqueeze(0).expand(bs, -1, -1).unsqueeze(2)
            )  # [B,3,1,D]
            navi_path_query = navi_path_query + navi_path_class_query[:, 0:1, :, :]  # [B,1,Q=10,D]
            for layer_idx in range(self.points_attn_layer):
                navi_path_query = self.points_attn_ln[layer_idx](
                    navi_path_query + self.points_attn[layer_idx](navi_path_query, navi_lane_token, navi_lane_mask)
                )  # [B,1,Q=10,D]
            navi_path_query = self.points_ffn(navi_path_query)
            return navi_path_query.squeeze(1)  # [B,Q=10,D], if we have multi navi_path, should add PE
        else:
            navi_path_query = self.mlp(navi_lane_processed.reshape(bs, navi_lane_num, -1))
            return navi_path_query

    def preprocess(self, navi_path_data_dict):
        """Preprocess navigation path data."""
        navi_path_points = navi_path_data_dict["points"]

        # Normalize points
        normed_points = self.normalize_points(navi_path_points)

        return normed_points

    def normalize_points(self, points):
        """Normalize points."""
        x_min, x_max, y_min, y_max = self.norm_range
        normed_points = (points - torch.tensor([x_min, y_min], device="cuda")) / torch.tensor(
            [x_max - x_min, y_max - y_min], device="cuda"
        )

        return normed_points

    def infer_forward(self, navi_path_data_dict):
        """Infer forward."""
        return self.train_forward(navi_path_data_dict)


class CommandTLDTokenizer(BaseModule):
    """Static navigation path tokenizer."""

    def __init__(
        self,
        norm_range,
        color_num=5,
        color_embed_dim=8,
        status_num=5,
        status_embed_dim=8,
        input_dim=400,
        hidden_dim=256,
        embed_dim=256,
        train_mode=True,
    ):
        """Init."""
        super().__init__(train_mode=train_mode)
        self.mlp = torch.nn.Sequential(
            torch.nn.Linear(input_dim, hidden_dim),
            torch.nn.ReLU(),
            torch.nn.Linear(hidden_dim, embed_dim),
        )
        self.norm_range = norm_range

        self.color_embedding = torch.nn.Embedding(color_num, color_embed_dim)
        self.status_embedding = torch.nn.Embedding(status_num, status_embed_dim)

    def train_forward(self, tld_data_dict):
        """Train forward."""
        bs = tld_data_dict["navi_path_stoppoints"].size(0)
        tld_stoppoints = tld_data_dict["navi_path_stoppoints"]
        tld_stoppoints_normed = self.normalize_points(tld_stoppoints)

        tld_color_embedding = self.color_embedding(tld_data_dict["navi_path_tld_color"].long())
        tld_status_embedding = self.status_embedding(tld_data_dict["navi_path_tld_status"].long())

        tld_embedding = torch.cat(
            [tld_stoppoints_normed.reshape(bs, 1, -1), tld_color_embedding, tld_status_embedding], dim=-1
        )

        tld_token = self.mlp(tld_embedding)

        return tld_token

    def infer_forward(self, tld_data_dict):
        """Infer forward."""
        return self.train_forward(tld_data_dict)

    def normalize_points(self, points):
        """Normalize points."""
        x_min, x_max, y_min, y_max = self.norm_range
        normed_points = (points - torch.tensor([x_min, y_min], device="cuda")) / torch.tensor(
            [x_max - x_min, y_max - y_min], device="cuda"
        )

        return normed_points


class CommandControlPointResidualBlock(nn.Module):
    def __init__(self, D, D_prime, hidden_dim=None):  # noqa: N803
        super(CommandControlPointResidualBlock, self).__init__()
        if hidden_dim is None:
            hidden_dim = D_prime
        self.norm = nn.LayerNorm(D_prime)
        self.fc1 = nn.Linear(D, hidden_dim)
        self.relu = nn.LeakyReLU()
        self.fc2 = nn.Linear(hidden_dim, D_prime)
        # if D != D_prime:
        self.proj = nn.Linear(D, D_prime) if D != D_prime else nn.Identity()

    def forward(self, x):
        """Forward."""
        # x shape: [B, N, D]
        residual = self.proj(x)  #
        out = self.fc1(x)
        out = self.relu(out)
        out = self.norm(out)
        out = self.fc2(out)
        # Residual connection
        out = out + residual
        return out


class CommandControlPointTokenizer(BaseModule):
    def __init__(self, pos_norm_val=None, vel_max_val=None, input_size=2, hidden_size=128, train_mode=True):
        """Lane encoder."""
        super().__init__(train_mode=train_mode)
        self.pos_norm_val = pos_norm_val
        self.pos_norm_x_min = pos_norm_val[0]
        self.pos_norm_x_max = pos_norm_val[1]
        self.pos_norm_y_min = pos_norm_val[2]
        self.pos_norm_y_max = pos_norm_val[3]

        self.vel_max_val = vel_max_val

        self.mlp = CommandControlPointResidualBlock(input_size, hidden_size)

    def isclose(self, a, b, abs_tol=0.0):
        """Check if two values are close."""
        return torch.abs(a - b) <= abs_tol

    def train_forward(self, control_points):
        """Forward."""
        control_points_x = (control_points[..., 0] - self.pos_norm_x_min) / (self.pos_norm_x_max - self.pos_norm_x_min)
        control_points_y = (control_points[..., 1] - self.pos_norm_y_min) / (self.pos_norm_y_max - self.pos_norm_y_min)
        x_y_mask = self.isclose(
            control_points[..., 0], -1.0 * torch.ones_like(control_points[..., 0]), 1e-6
        ) & self.isclose(control_points[..., 1], -1.0 * torch.ones_like(control_points[..., 1]), 1e-6)
        control_points_x = torch.where(x_y_mask, -1.0, control_points_x).unsqueeze(-1)
        control_points_y = torch.where(x_y_mask, -1.0, control_points_y).unsqueeze(-1)

        control_points_heading = control_points[..., 2:4]

        control_points_v = torch.clamp(control_points[..., 4], 0, self.vel_max_val) / self.vel_max_val
        v_mask = self.isclose(control_points[..., 4], -1.0 * torch.ones_like(control_points[..., 4]), 1e-6)
        control_points_v = torch.where(v_mask, -1, control_points_v).unsqueeze(-1)

        control_point_type = control_points[..., 5:]
        control_points = torch.cat(
            [control_points_x, control_points_y, control_points_heading, control_points_v, control_point_type], dim=-1
        )
        control_feat = self.mlp(control_points)
        return control_feat

    def infer_forward(self, control_points):
        """Infer forward."""
        control_points = control_points[:, -1] if control_points is not None else None
        return self.train_forward(control_points)
