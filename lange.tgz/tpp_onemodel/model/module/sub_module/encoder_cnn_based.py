# -*- coding: utf-8 -*-
from typing import Dict
from typing import Optional
from typing import Sequence

import torch.nn.functional as tfunc
from torch import nn
from torchpilot.model.module_interface import BaseModule


ActFun = dict(
    relu=nn.ReLU(),
)


class ConvNormActLayer(BaseModule):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int = 3,
        stride: int = 1,
        groups: int = 1,
        activation: Optional[str] = "relu",
    ):
        super().__init__()
        assert activation is None or activation == "relu", "only support relu activation!"
        self.conv_layer = nn.Conv2d(
            in_channels,
            out_channels,
            kernel_size=kernel_size,
            stride=stride,
            padding=kernel_size // 2,
            groups=groups,
            bias=False,
        )
        self.norm_layer = nn.BatchNorm2d(out_channels)
        self.act_layer = ActFun[activation] if activation is not None else nn.Identity()

    def forward(self, x):
        """forward.

        args:
            x - (b, c, h, w).
        """
        x = self.conv_layer(x)
        x = self.norm_layer(x)
        x = self.act_layer(x)
        return x


class RegnetStem(BaseModule):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int = 3,
        stride: int = 2,
        activation: Optional[str] = "relu",
    ):
        super().__init__()
        self.stem = ConvNormActLayer(
            in_channels,
            out_channels,
            kernel_size,
            stride,
            activation=activation,
        )
        self.in_channels = in_channels

    def forward(self, x):
        """forward.

        args:
            x - (b, c, h, w).
        """
        x = self.stem(x)
        return x


class RegNetShortCut(BaseModule):
    def __init__(self, in_channels: int, out_channels: int, stride: int = 2):
        super().__init__()
        self.conv_layer = nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=stride, bias=False)
        self.norm_layer = nn.BatchNorm2d(out_channels)

    def forward(self, x):
        """forward.

        args:
            x - (b, c, h, w).
        """
        x = self.conv_layer(x)
        x = self.norm_layer(x)
        return x


class RegNetSELayer(BaseModule):
    def __init__(self, in_channels: int, reduced_channels: int):
        super().__init__()
        self.pooler = nn.AdaptiveAvgPool2d((1, 1))
        self.attention = nn.Sequential(
            nn.Conv2d(in_channels, reduced_channels, kernel_size=1),
            nn.ReLU(),
            nn.Conv2d(reduced_channels, in_channels, kernel_size=1),
            nn.Sigmoid(),
        )

    def forward(self, x):
        """forward.

        args:
            x - (b, c, h, w).
        return:
            Tensor (b, c, 1, 1)
        """
        pooled = self.pooler(x)
        x *= self.attention(pooled)
        return x


class RegNetXLayer(BaseModule):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        groups_width: int,
        stride: int = 1,
        activation: Optional[str] = "relu",
    ):
        super().__init__()
        should_apply_shortcut = in_channels != out_channels or stride != 1
        groups = max(1, out_channels // groups_width)
        self.shortcut = (
            RegNetShortCut(in_channels, out_channels, stride=stride) if should_apply_shortcut else nn.Identity()
        )
        self.layer = nn.Sequential(
            ConvNormActLayer(in_channels, out_channels, kernel_size=1, activation=activation),
            ConvNormActLayer(out_channels, out_channels, stride=stride, groups=groups, activation=activation),
            ConvNormActLayer(out_channels, out_channels, kernel_size=1, activation=None),
        )
        self.activation = ActFun[activation] if activation is not None else nn.Identity()

    def forward(self, x):
        """forward.

        args:
            x - (b, c, h, w).
        """
        residual = x
        x = self.layer(x)
        residual = self.shortcut(residual)
        x += residual
        x = self.activation(x)
        return x


class RegNetYLayer(BaseModule):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        groups_width: int,
        stride: int = 1,
        activation: Optional[str] = "relu",
    ):
        super().__init__()
        should_apply_shortcut = in_channels != out_channels or stride != 1
        groups = max(1, out_channels // groups_width)
        self.shortcut = (
            RegNetShortCut(in_channels, out_channels, stride=stride) if should_apply_shortcut else nn.Identity()
        )
        self.layer = nn.Sequential(
            ConvNormActLayer(in_channels, out_channels, kernel_size=1, activation=activation),
            ConvNormActLayer(out_channels, out_channels, stride=stride, groups=groups, activation=activation),
            RegNetSELayer(out_channels, reduced_channels=int(round(in_channels / 4))),
            ConvNormActLayer(out_channels, out_channels, kernel_size=1, activation=None),
        )
        self.activation = ActFun[activation] if activation is not None else nn.Identity()

    def forward(self, x):
        """forward.

        args:
            x - (b, c, h, w).
        """
        residual = x
        x = self.layer(x)
        residual = self.shortcut(residual)
        x += residual
        x = self.activation(x)
        return x


class RegNetStage(BaseModule):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        layer_type: str,
        groups_width: int,
        stride: int = 2,
        depth: int = 2,
    ):
        super().__init__()
        assert layer_type in ("x", "y"), "Invaid regnet layer type, not in (x, y)!"
        layer = RegNetXLayer if layer_type == "x" else RegNetYLayer

        self.layers = nn.Sequential(  # type: ignore
            layer(in_channels, out_channels, stride=stride, groups_width=groups_width),
            *[layer(out_channels, out_channels, groups_width=groups_width) for _ in range(depth - 1)],
        )

    def forward(self, x):
        """forward.

        args:
            x - (b, c, h, w).
        """
        x = self.layers(x)
        return x


class RegNetEncoder(BaseModule):
    def __init__(
        self,
        embedding_size: int,
        hidden_sizes: Sequence[int],
        layer_type: str,
        groups_width: int,
        downsample_in_first_stage: bool,
        depths: Sequence[int],
    ):
        super().__init__()
        self.stages = nn.ModuleList([])
        self.stages.append(
            RegNetStage(
                embedding_size,
                hidden_sizes[0],
                layer_type=layer_type,
                groups_width=groups_width,
                stride=2 if downsample_in_first_stage else 1,
                depth=depths[0],
            )
        )
        in_out_channels = zip(hidden_sizes, hidden_sizes[1:])
        for (in_channels, out_channels), depth in zip(in_out_channels, depths[1:]):
            self.stages.append(
                RegNetStage(in_channels, out_channels, layer_type=layer_type, groups_width=groups_width, depth=depth)
            )

    def forward(self, x):
        """forward.

        args:
            x - (b, c, h, w).
        return:
            List of featmaps from different stages
        """
        xouts = [x]
        for stage_module in self.stages:
            x = stage_module(x)
            xouts.append(x)
        return xouts


class RegNetModel(BaseModule):
    def __init__(
        self,
        in_channels: int,
        embedding_size: int,
        hidden_sizes: Sequence[int],
        layer_type: str,
        groups_width: int,
        downsample_in_first_stage: bool,
        depths: Sequence[int],
    ):
        super().__init__()
        self.in_channels = in_channels
        self.embedding_size = embedding_size
        self.hidden_sizes = hidden_sizes
        self.layer_type = layer_type
        self.groups_width = groups_width
        self.downsample_in_first_stage = downsample_in_first_stage
        self.depths = depths
        self.stem = RegnetStem(in_channels, embedding_size)
        self.encoder = RegNetEncoder(
            embedding_size, hidden_sizes, layer_type, groups_width, downsample_in_first_stage, depths
        )

    def forward(self, x):
        """forward.

        args:
            Tensor (b, c, h, w).
        return:
            List of featmaps from different stages.
        """
        stem_out = self.stem(x)
        encoder_outs = self.encoder(stem_out)
        return encoder_outs


class SimpleFPN(BaseModule):
    def __init__(
        self,
        in_channels_list: Sequence[int],
        out_channels: int,
    ):
        super().__init__()
        self.inner_layers = nn.ModuleList()
        self.lateral_layers = nn.ModuleList()
        for in_channels in in_channels_list:
            self.inner_layers.append(ConvNormActLayer(in_channels, out_channels, kernel_size=1, activation=None))
            self.lateral_layers.append(ConvNormActLayer(out_channels, out_channels, kernel_size=3, activation=None))

    def forward(self, feats):
        """forward.

        args:
            List of featmaps with different size.
        return:
            List of featmaps with top-down merge.
        """
        results = []
        inner_outs = []
        upsample_outs = []
        for idx, feat in enumerate(feats):
            inner_outs.append(self.inner_layers[idx](feat))
        for idx in range(1, len(inner_outs)):
            upsample_outs.append(
                tfunc.interpolate(inner_outs[idx], size=inner_outs[idx - 1].shape[-2:], mode="nearest")
            )
        for idx in range(len(inner_outs) - 1):
            results.append(self.lateral_layers[idx](inner_outs[idx] + upsample_outs[idx]))
        results.append(inner_outs[-1])
        return results


class EncoderBasedOnCNN(BaseModule):
    def __init__(
        self,
        backbone_cfg: Dict,
        bk_out_idxes: Sequence[int],
        neck_cfg: Optional[Dict] = None,
        neck_out_idxes: Sequence[int] = tuple(),
    ):
        super().__init__()
        self.bk_out_idxes = bk_out_idxes
        self.neck_out_idxes = neck_out_idxes
        self.backbone = RegNetModel(**backbone_cfg)
        self.neck = SimpleFPN(**neck_cfg) if neck_cfg is not None else None

    def init_weight(self):
        """Initialize weights."""
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_uniform_(m.weight)

                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)

            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

            elif isinstance(m, nn.Linear):
                nn.init.kaiming_uniform_(m.weight)
                nn.init.constant_(m.bias, 0)

    def forward(self, x):
        """forward.

        args:
            x - (b, c, h, w).
        """
        outs = self.backbone(x)
        outs = [outs[i] for i in self.bk_out_idxes]
        if self.neck is not None:
            outs = self.neck(outs)
            outs = [outs[i] for i in self.neck_out_idxes]
        return outs
