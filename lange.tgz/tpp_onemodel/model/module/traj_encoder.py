# -*- coding: utf-8 -*-
"""Global Tracking Transformer."""
from typing import Optional

from torch import Tensor
from torch import nn

from tpp_onemodel.model.layer.stamp_attention import StampMultiheadAttention
from tpp_onemodel.model.module.stamp_transformer import _get_activation_fn


class TrajectoryEncoder(nn.Module):  # pylint:disable=too-many-instance-attributes
    """TransformerEncoderLayer."""

    def __init__(
        self,
        embed_dim,
        num_heads,
        is_encoder=False,
        dim_feedforward=64,
        dropout=0.1,
        norm=True,
        use_ffn=False,
        activation="relu",
        relu_max_value=None,
        attn_hardtanh_val=None,
        use_hpc_nn_ops=False,
        use_tvm_supported_sdpa=False,
    ):
        """Init."""
        super().__init__()
        self._use_ffn = use_ffn

        self.num_heads = num_heads
        self.embed_dim = embed_dim
        self._is_encoder = is_encoder
        self.attn_hardtanh_val = attn_hardtanh_val
        self.dropout_prob = dropout
        self.use_hpc_nn_ops = use_hpc_nn_ops
        self.use_tvm_supported_sdpa = use_tvm_supported_sdpa

        self.self_attn = self._init_attention_layer()
        self.attn_dropout = nn.Dropout(dropout)
        self.attn_norm = nn.LayerNorm(self.embed_dim)

        if self._use_ffn:
            # Implementation of Feedforward model
            self.linear1 = nn.Linear(self.embed_dim, dim_feedforward)
            self.dropout = nn.Dropout(dropout)
            self.linear2 = nn.Linear(dim_feedforward, self.embed_dim)

            self.norm1 = nn.LayerNorm(self.embed_dim) if norm else nn.Identity()
            self.dropout1 = nn.Dropout(dropout)

            self.activation = _get_activation_fn(activation, relu_max_value)
            self.ffn = nn.Sequential(self.linear1, self.activation, self.dropout, self.linear2, self.activation)

    def _init_attention_layer(self):
        return StampMultiheadAttention(
            embed_dim=self.embed_dim,
            num_heads=self.num_heads,
            is_encoder=self._is_encoder,
            attn_hardtanh_val=self.attn_hardtanh_val,
            dropout=self.dropout_prob,
            use_hpc_nn_ops=self.use_hpc_nn_ops,
            use_tvm_supported_sdpa=self.use_tvm_supported_sdpa,
        )

    def forward(
        self,
        query: Tensor,
        key: Tensor,
        value: Tensor,
        key_padding_mask: Optional[Tensor] = None,
        attn_mask: Optional[Tensor] = None,
    ):
        """Forward."""
        residual = query
        attn_output, attn_output_weights = self.self_attn(
            query,
            key,
            value,
            attn_mask=attn_mask,
            key_padding_mask=key_padding_mask,
        )
        attn_output = self.attn_norm(residual + self.attn_dropout(attn_output))
        if not self._use_ffn:
            return attn_output, attn_output_weights

        ffn_output = self.ffn(attn_output)
        ffn_output = attn_output + self.dropout1(ffn_output)
        ffn_output = self.norm1(ffn_output)

        return ffn_output, attn_output_weights
