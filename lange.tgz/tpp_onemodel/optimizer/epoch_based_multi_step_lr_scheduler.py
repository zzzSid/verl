# -*- coding: utf-8 -*-
"""Iter based cosine lr scheduler."""
from typing import Dict
from typing import Optional
from typing import Union

# import numpy as np
import torch.distributed as dist
from torch.optim import Optimizer
from torchpilot.optimizer.base_lr_scheduler import BaseLrScheduler

from tpp_onemodel.utils.constant_utils import get_env_or_constant
from tpp_onemodel.utils.constant_utils import load_constants


class EpochBasedMultiStepLrScheduler(BaseLrScheduler):
    """LR Scheduler in MultiStep."""

    def __init__(
        self,
        optimizer: Optional[Optimizer] = None,
        total_epoch: int = 1,
        iter_per_epoch: int = 1,
        min_lr: float = 0.000001,
        warmup_type: Optional[str] = None,
        warmup_iters: int = 0,
        warmup_epochs: Union[int, float] = 0,
        warmup_ratio: float = 0.1,
        scale_num_gpus: bool = False,
        decay_epochs: list = [20],
        **kwargs,
    ) -> None:
        """Step LR scheduler with min_lr clipping."""
        if scale_num_gpus:
            iter_per_epoch = iter_per_epoch // int(
                get_env_or_constant(
                    constants=load_constants("tpp_onemodel.utils.experiments_utils"),
                    attr="WORLD_SIZE",
                    default=str(dist.get_world_size()),
                )
            )

        self._all_iters = total_epoch * iter_per_epoch
        self.iter_per_epoch = iter_per_epoch
        self.total_epoch = total_epoch
        warmup_iters = int(warmup_iters if warmup_epochs <= 0 else iter_per_epoch * warmup_epochs)
        if warmup_type is None:
            warmup_iters = 0
        else:
            self._all_iters -= warmup_iters
        warmup_type = None if warmup_iters == 0 else warmup_type
        self._min_lr = min_lr
        self.decay_epochs = decay_epochs
        super().__init__(
            optimizer,
            warmup_type,
            warmup_iters,
            warmup_ratio,
            **kwargs,
        )

    def get_lr(self, cur_iter, base_lr) -> float:
        """Get cur_epoch learning rate based cur_epoch.

        Here cur_epoch is cur_iter, not epoch.
        """
        if cur_iter % self.iter_per_epoch == 0 and cur_iter / self.iter_per_epoch in self.decay_epochs:
            learning_rate = base_lr * 0.2
            for index, item in enumerate(self._base_lr):
                self._base_lr[index] = learning_rate
        # learning_rate = self._min_lr + (
        #     0.5 * (1 + np.cos(np.pi * min(cur_epoch / self._all_iters, 1.0))) * (base_lr - self._min_lr)
        # )
        else:
            learning_rate = base_lr

        return learning_rate

    def step(self, cur_iter: int, cur_epoch: int) -> None:
        """Set learning rate.

        Args:
            cur_iter (int): set learning rate in warmup process by step way.
            cur_epoch (int): set learning rate \
                    in regular training process by epoch way.
        """
        self._regular_lr = self.get_regular_lr(cur_iter)
        if self._warmup_type is None or cur_iter >= self._warmup_iters:
            self._set_lr(self._regular_lr)
        else:
            warmup_lr = self.get_warmup_lr(cur_iter)
            self._set_lr(warmup_lr)

    def state_dict(self) -> Dict:
        """Return LR Scheduler State."""
        return {
            "warmup_type": self._warmup_type,
            "warmup_iters": self._warmup_iters,
            "warmup_ratio": self._warmup_ratio,
            "base_lr": self._base_lr,
            "regular_lr": self._regular_lr,
            "all_iters": self._all_iters,
            "min_lr": self._min_lr,
        }

    def load_state_dict(self, state_dict: Dict) -> None:
        """Load state dict is used init params."""
        self._warmup_type = state_dict["warmup_type"]
        self._warmup_iters = state_dict["warmup_iters"]
        self._warmup_ratio = state_dict["warmup_ratio"]
        self._base_lr = state_dict["base_lr"]
        self._regular_lr = state_dict["regular_lr"]
        self._all_iters = state_dict["all_iters"]
        self._min_lr = state_dict["min_lr"]
