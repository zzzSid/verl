# -*- coding: utf-8 -*-
"""Iter based cosine lr scheduler."""
from typing import Dict
from typing import Optional
from typing import Union

import numpy as np
from torch.optim import Optimizer
from torchpilot.optimizer.base_lr_scheduler import BaseLrScheduler


class IterBasedCosineLrScheduler(BaseLrScheduler):
    """LR Scheduler in cosine way."""

    def __init__(
        self,
        optimizer: Optional[Optimizer] = None,
        total_epoch: int = 1,
        iter_per_epoch: int = 1,
        min_lr: float = 0.000001,
        warmup_type: Optional[str] = None,
        warmup_iters: int = 0,
        warmup_epochs: Union[int, float] = 0,
        warmup_ratio: float = 0.1,
        **kwargs,
    ) -> None:
        """Step LR scheduler with min_lr clipping.

        Args:
            optimizer (torch.optim.Optimizer): params optimizer.
                Default: None.
            total_epoch (int, optional): the total epochs of training process.
                Default: 1.
            min_lr (float, optional): Minimum LR value to keep. If LR after decay
                is lower than `min_lr`, it will be clipped to this value. If None
                is given, we don't perform lr clipping. Default: None.
            warmup_type (string): Type of warmup used. It can be None(use no warmup),
                'constant', 'linear' or 'exp'. Default: None.
            warmup_iters (int): The number of iterations that warmup
                lasts. Default: 0.
            warmup_ratio (float): LR used at the beginning of warmup equals to
                warmup_ratio * initial_lr. Default: 0.
        """
        if isinstance(total_epoch, int):
            if total_epoch < 1:
                raise ValueError("total_epoch must >= 1.")
        else:
            raise TypeError("`total_epoch` must be a positive integer and >=1.")
        self._cosine_iters = total_epoch * iter_per_epoch
        warmup_iters = int(warmup_iters if warmup_epochs <= 0 else iter_per_epoch * warmup_epochs)
        if warmup_type is None:
            warmup_iters = 0
        else:
            self._cosine_iters -= warmup_iters
        self._min_lr = min_lr
        super().__init__(
            optimizer,
            warmup_type,
            warmup_iters,
            warmup_ratio,
            **kwargs,
        )

    def get_lr(self, cur_epoch, base_lr) -> float:
        """Get cur_epoch learning rate based cur_epoch.

        Here cur_epoch is cur_iter, not epoch.
        """
        learning_rate = self._min_lr + (
            0.5 * (1 + np.cos(np.pi * min(cur_epoch / self._cosine_iters, 1.0))) * (base_lr - self._min_lr)
        )

        return learning_rate

    def step(self, cur_iter: int, cur_epoch: int) -> None:
        """Set learning rate.

        Args:
            cur_iter (int): set learning rate in warmup process by step way.
            cur_epoch (int): set learning rate \
                    in regular training process by epoch way.
        """
        self._regular_lr = self.get_regular_lr(max(cur_iter - self._warmup_iters, 0))
        if self._warmup_type is None or cur_iter >= self._warmup_iters:
            self._set_lr(self._regular_lr)
        else:
            warmup_lr = self.get_warmup_lr(cur_iter)
            self._set_lr(warmup_lr)

    def state_dict(self) -> Dict:
        """Return LR Scheduler State."""
        return {
            "warmup_type": self._warmup_type,
            "warmup_iters": self._warmup_iters,
            "warmup_ratio": self._warmup_ratio,
            "base_lr": self._base_lr,
            "regular_lr": self._regular_lr,
            "cosine_iters": self._cosine_iters,
            "min_lr": self._min_lr,
        }

    def load_state_dict(self, state_dict: Dict) -> None:
        """Load state dict is used init params."""
        self._warmup_type = state_dict["warmup_type"]
        self._warmup_iters = state_dict["warmup_iters"]
        self._warmup_ratio = state_dict["warmup_ratio"]
        self._base_lr = state_dict["base_lr"]
        self._regular_lr = state_dict["regular_lr"]
        self._cosine_iters = state_dict["cosine_iters"]
        self._min_lr = state_dict["min_lr"]
