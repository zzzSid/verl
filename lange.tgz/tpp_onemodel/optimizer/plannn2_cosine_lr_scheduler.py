# -*- coding: utf-8 -*-
"""Plannn2 cosine lr scheduler based on IterBasedCosineLrScheduler."""
import math
from typing import Dict
from typing import Optional
from typing import Union

import numpy as np
from torch.optim import Optimizer
from torchpilot.optimizer.base_lr_scheduler import BaseLrScheduler


class Plannn2CosineLrScheduler(BaseLrScheduler):
    """专为Plannn2训练设计的余弦学习率调度器."""

    def __init__(
        self,
        optimizer: Optional[Optimizer] = None,
        learning_rate: float = 2e-4,
        lr_decay_iters: int = 1000,
        min_lr: float = 0.000001,
        warmup_iters: int = 0,
        warmup_type: Optional[str] = "linear",
        warmup_ratio: float = 0.1,
    ) -> None:
        """初始化Plannn2余弦学习率调度器."""
        # 存储Plannn2特定的配置
        self._learning_rate = learning_rate
        self._lr_decay_iters = lr_decay_iters
        self._min_lr = min_lr
        super().__init__(
            optimizer,
            warmup_type,
            warmup_iters,
            warmup_ratio,
        )

    def get_lr_for_iter(self, it: int) -> float:
        """根据迭代次数获取学习率.

        这个方法实现了与plannn2_trainer中get_lr方法相同的逻辑：
        1) 线性预热阶段
        2) 超过lr_decay_iters后返回最小学习率
        3) 中间阶段使用余弦衰减

        Args:
            it (int): 当前迭代次数.

        Returns:
            float: 计算出的学习率.
        """
        # 1) 线性预热阶段
        if it < self._warmup_iters:
            return self._learning_rate * it / self._warmup_iters

        # 2) 如果超过lr_decay_iters，返回最小学习率
        if it > self._lr_decay_iters:
            return self._min_lr

        # 3) 中间阶段，使用余弦衰减到最小学习率
        decay_ratio = (it - self._warmup_iters) / (self._lr_decay_iters - self._warmup_iters)
        assert 0 <= decay_ratio <= 1
        coeff = 0.5 * (1.0 + math.cos(math.pi * decay_ratio))  # coeff ranges 0..1
        return self._min_lr + coeff * (self._learning_rate - self._min_lr)

    def get_lr(self, cur_epoch, base_lr) -> float:
        """Get lr"""
        return self.get_lr_for_iter(cur_epoch)

    def step(self, cur_iter: int, cur_epoch: int = 0) -> None:
        """设置学习率.

        Args:
            cur_iter (int): 当前迭代次数.
            cur_epoch (int): 当前epoch (对于基于迭代的调度器通常不使用).
        """
        # 对于Plannn2，我们主要基于迭代次数
        learning_rate = self.get_lr_for_iter(cur_iter)
        self.set_lr(learning_rate)

    def set_lr(self, learning_rate: float) -> None:
        for param_group in self._optimizer.param_groups:
            param_group["lr"] = learning_rate

    def state_dict(self) -> Dict:
        """返回学习率调度器的状态."""
        state = {
            "learning_rate": self._learning_rate,
            "lr_decay_iters": self._lr_decay_iters,
            "min_lr": self._min_lr,
        }
        return state

    def load_state_dict(self, state_dict: Dict) -> None:
        """加载状态字典以初始化参数."""
        self._learning_rate = state_dict.get("learning_rate", self._learning_rate)
        self._lr_decay_iters = state_dict.get("lr_decay_iters", self._lr_decay_iters)
        self._min_lr = state_dict.get("min_lr", self._min_lr)
