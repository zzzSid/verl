# -*- coding: utf-8 -*-
"""Astra Planner Metrics Aggregater."""
import logging
import os
import pickle
import shutil
from typing import Any
from typing import List

import torch.distributed as dist
from torchpilot.utils.file_manager import FileManager
from tqdm import tqdm


VIS = True
logger = logging.getLogger(__name__)


class EvaluationSaver:
    """Evaluation Saver."""

    def __init__(self):
        """Init."""
        self.save_dir = FileManager.get_export_dir()

        self.all_save_keys = set()

    def _split_data_by_clip(self, all_info_ls):
        """
        Split the data by clip.

        Args:
            all_info_ls (list): The list of all information.
        Returns:
            list: The list of information split by clip.
        """
        info_by_clip = dict()
        logger.info("split by clip")
        for info in tqdm(all_info_ls):
            clip_id = info["clip_id"]
            if clip_id not in info_by_clip:
                info_by_clip[clip_id] = []
            info_by_clip[clip_id].append(info)
        return info_by_clip

    def _dump_single_gpu_results(self, results):
        """Dump single gpu results."""
        save_dir = os.path.join(self.save_dir, "eval_single_dumps")
        os.makedirs(save_dir, exist_ok=True)

        # keep order when loading all dumps to a big one
        # TPDistributedSampler samples dataset in the way that if there are 64 samples
        # and 8 gpu, than gpu0 gets data 0-7, gpu1 gets data 8-15...
        # https://git.nevint.com/nio-pilot/torchpilot/blob/master/torchpilot/data/sampler/tp_distributed_sampler.py#L197-198

        selected_data_list = []
        for frame_data in results:
            selected_data = dict()
            if "all" in self.all_save_keys:
                selected_data = frame_data
            else:
                for select_key in self.all_save_keys:
                    if select_key in frame_data.keys():
                        selected_data[select_key] = frame_data[select_key]
            selected_data_list.append(selected_data)

        save_path = os.path.join(save_dir, f"eval_single_dump_{dist.get_rank()}.pkl")
        with open(save_path, "wb") as f_id:
            pickle.dump(selected_data_list, f_id)

    def _load_dumps(self):
        """Save results."""
        output_gathered_list = []

        save_dir = os.path.join(self.save_dir, "eval_single_dumps")
        dumps_names = os.listdir(save_dir)
        if len(dumps_names) != dist.get_world_size():
            raise ValueError(
                "num of per gpu results should equal to world_size,"
                + f"got {len(dumps_names)} and {dist.get_world_size()}"
            )

        dumps_names = sorted(
            dumps_names,
            key=lambda x: int(x.split(".")[0].split("_")[-1]),
        )

        for dumps_name in tqdm(dumps_names):
            dump_path = os.path.join(save_dir, dumps_name)
            with open(dump_path, "rb") as f_id:
                output_gathered_list.extend(pickle.load(f_id))

        return output_gathered_list

    def save_clip_vis_pkl(self, eval_results):  # pylint: disable=arguments-renamed
        """All reduce by torch.distributed as dist."""
        # if dist.get_world_size() != 1:
        self._dump_single_gpu_results(eval_results)
        dist.barrier()
        if dist.get_rank() == 0:
            output_gathered_list: List[Any] = []

            # delete per gpu results first
            per_gpu_save_dir = os.path.join(self.save_dir, "eval_single_dumps")
            if os.path.exists(per_gpu_save_dir):
                shutil.rmtree(per_gpu_save_dir)

            if len(output_gathered_list) > 0:
                if len(self.all_save_keys) == 0:
                    return
                output_gathered_list = sorted(
                    output_gathered_list, key=lambda i: i["subclip_id"] + "___" + str(i["timestamp"][-1])
                )

    def save_scene_metrics_to_csv_file(self, scene_metrics_dataframe):
        """Save scene metric dataframe as csv."""
        scene_metrics_save_path = os.path.join(self.save_dir, "scene_metrics_table.csv")
        exp_name = self.save_dir.split("/")[-2]
        local_dir = "./csv_results"
        os.makedirs(local_dir, exist_ok=True)
        scene_metrics_save_local_path = os.path.join(local_dir, exp_name + "_scene_metrics_table.csv")

        scene_metrics_dataframe.to_csv(scene_metrics_save_path, index=True)
        scene_metrics_dataframe.to_csv(scene_metrics_save_local_path, index=True)
