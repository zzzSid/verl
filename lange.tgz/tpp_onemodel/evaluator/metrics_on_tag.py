# -*- coding: utf-8 -*-
"""Torchpilot Metrics on different tags."""
import math

import torch

from tpp_onemodel.evaluator.metric_on_clip import MetricsOnClip


from dataclasses import dataclass  # isort: skip


EPS = 1e-6


@dataclass
class SingleMetric:
    name: str
    index_cnt: int = 0
    val_sum: float = 0.0
    val_avg: float = 0.0

    def update(self, val_sum, index_cnt, buffer=None):
        """Update."""
        # maintain nominator and denominator. Treat val_sum as nominator, index_cnt as denominator, val_avg as nominator/denominator
        # if "ud" in self.name and (self.name[-3:] == "acc" or self.name[-2:] == "pr" or self.name[-2:] == "re"):
        #     deno = index_cnt
        #     nomi = val_avg * deno
        #     self.index_cnt += deno
        #     self.val_sum += nomi
        # else:
        if self.name in ["marginal/agent/prior_precision_based_recall", "marginal/agent/track_recall_based_precision"]:
            if isinstance(self.val_sum, float) and self.val_sum == 0:
                self.val_sum = val_sum
                self.index_cnt = index_cnt
                self.buffer = buffer
            else:
                self.val_sum = torch.concat([self.val_sum, val_sum], dim=0)
                self.index_cnt = torch.concat([self.index_cnt, index_cnt], dim=0)
                self.buffer = buffer
        elif self.name in [
            "marginal/agent/prior_precision",
            "marginal/agent/prior_recall",
            "marginal/agent/track_precision",
            "marginal/agent/track_recall",
        ]:
            if isinstance(self.val_sum, float) and self.val_sum == 0:
                self.val_sum = val_sum
                self.index_cnt = index_cnt
            else:
                self.val_sum += val_sum
                self.index_cnt += index_cnt
        else:
            if math.isnan(val_sum):
                return
            self.val_sum += val_sum
            self.index_cnt += index_cnt

    def get_metrics(self):
        """Get Metrics."""
        if "ud" in self.name and (self.name[-3:] == "acc" or self.name[-2:] == "pr" or self.name[-2:] == "re"):
            ratio = 0.0 if self.index_cnt == 0 else self.val_sum / self.index_cnt
            return self.val_sum, self.index_cnt, ratio
        else:
            self.val_avg = self.val_sum / (self.index_cnt + EPS)
            return self.val_sum, self.index_cnt, self.val_avg


class MetricsOnDaTag:
    """Metrics on Da Tag."""

    def __init__(
        self,
        tag_name="all",
        common_metrics=["agent_mFDE", "ego_mFDE"],
        key_metrics={"mFDE": {"thresh": 1.5, "cmp_method": "larger"}},
        special_metrics=["ego_tgm_min_collision_rate", "ego_tgm_best_collision_rate"],
        save_clip_id=False,
    ):
        """Initialize."""
        self.tag_name = tag_name
        self.common_metrics = common_metrics
        self.key_metrics = key_metrics
        self.frame_cnt = 0
        self.obs_cnt = 0
        self.save_clip_id = save_clip_id
        self.tag_cnt = 0
        if self.save_clip_id:
            self.clips = dict()  # {clip_id: clip_instance}
        self._init_metric_table()

    def _init_metric_table(self):
        """Init metric table."""
        self.metric_table = dict()
        for metric_name in self.common_metrics:
            self.metric_table[metric_name] = SingleMetric(name=metric_name)

    def update_tag_cnt(self):
        """Update_tag_cnt."""
        self.tag_cnt += 1

    def reset(self):
        """Reset metrics on tag."""
        self.tag_cnt = 0
        self.frame_cnt = 0
        self.obs_cnt = 0
        if self.save_clip_id:
            self.clips = dict()  # {clip_id: clip_instance}
        self._init_metric_table()

    def update(self, metrics, clip_id=None, timestamp=None):
        """For single/multi frame update."""
        for metric_name in metrics:
            if metric_name in [
                "marginal/agent/prior_precision_based_recall",
                "marginal/agent/track_recall_based_precision",
            ]:
                od_prior_pred, od_prior_gt_map, recall_thr = metrics[metric_name]
                self.metric_table[metric_name].update(od_prior_pred, od_prior_gt_map, recall_thr)
            else:
                if metric_name in self.metric_table:
                    avg_sum, cnt = metrics[metric_name]
                    self.metric_table[metric_name].update(avg_sum, cnt)

        if self.save_clip_id and clip_id is not None:
            if clip_id not in self.clips.keys():
                self.clips[clip_id] = MetricsOnClip(clip_id=clip_id, key_metrics=self.key_metrics)
            self.clips[clip_id].update(metrics, timestamp)

    def export_result(self):
        """Export metrics, counts, clip list."""
        metrics = dict()
        for metric_name in self.metric_table:
            val_sum, index_cnt, val_avg = self.metric_table[metric_name].get_metrics()
            result = {"sum": val_sum, "count": index_cnt, "mean": val_avg}
            metrics[metric_name] = result
            # metrics["scene_cnt"] = {"sum": self.tag_cnt, "count": 1, "mean": 1}

        bad_cases = dict()
        for clip_id in self.clips:
            metric_dict = self.clips[clip_id].single_gpu_export_metric_result()
            for m_name, m_attr in metric_dict.items():
                m_attr_res, is_bad_metric = m_attr.get_metrics()
                if is_bad_metric:
                    if clip_id not in bad_cases.keys():
                        bad_cases.update({clip_id: {}})
                    bad_cases[clip_id].update({m_name: m_attr_res})

        return metrics, bad_cases
