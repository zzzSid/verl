# -*- coding: utf-8 -*-

EPS = 1e-6


class MetricAttributes:
    def __init__(self, compare_method="larger", threshold=0.0, cnt=0, sum=0.0, avg=0.0, bad_cnt=0):
        """Init."""
        self.compare_method = compare_method
        self.threshold = threshold
        self.cnt = cnt
        self.sum = sum
        self.avg = avg
        self.bad_cnt = bad_cnt
        self.target_timestamps = []
        self.target_value = []

    def update(self, metric, timestamp):
        """Update."""
        self.cnt += metric[1]
        self.sum += metric[0]
        if self.compare_method == "larger":
            if metric[0] > self.threshold:
                self.bad_cnt += 1
                self.target_timestamps.append(timestamp)
                self.target_value.append(metric[0])
        elif self.compare_method == "smaller":
            if metric[0] <= self.threshold:
                self.bad_cnt += 1
                self.target_timestamps.append(timestamp)
                self.target_value.append(metric[0])

    def get_metrics(self):
        """Get Metrics."""
        is_bad_metric = False

        if self.cnt == 0:
            return {
                key: value for key, value in self.__dict__.items() if not key.startswith("__") and not callable(key)
            }, is_bad_metric

        self.avg = self.sum / self.cnt
        is_avg_bad = (self.compare_method == "larger" and self.avg > self.threshold) or (
            self.compare_method == "smaller" and self.avg < self.threshold
        )
        is_bad_metric = is_avg_bad or self.bad_cnt > 0
        return {
            key: value for key, value in self.__dict__.items() if not key.startswith("__") and not callable(key)
        }, is_bad_metric


def mass_update(multiple_result_list, key_metrics, satisfy_frame_cnt_thresh=1e9, satisfy_frame_ratio_threh=1.0):
    """Merge single clip results from multiple threads."""
    res = {}
    has_bad_metric = False
    if key_metrics is None:
        return res, has_bad_metric

    for tgt_metric_name, cfg in key_metrics.items():
        thresh = cfg["thresh"]
        cmp_method = "larger"
        if cfg.get("cmp_method"):
            cmp_method = cfg["cmp_method"]

        for single_result in multiple_result_list:
            if tgt_metric_name not in single_result.keys():
                continue
            single_metric_attr = single_result[tgt_metric_name]
            if tgt_metric_name not in res.keys():
                res.update(
                    {
                        tgt_metric_name: {
                            "compare_method": single_metric_attr["compare_method"],
                            "threshold": single_metric_attr["threshold"],
                            "cnt": 0,
                            "sum": 0.0,
                            "bad_cnt": 0,
                            "target_timestamps": [],
                            "target_value": [],
                        }
                    }
                )
            res[tgt_metric_name]["cnt"] += single_metric_attr["cnt"]
            res[tgt_metric_name]["sum"] += single_metric_attr["sum"]
            res[tgt_metric_name]["bad_cnt"] += single_metric_attr["bad_cnt"]
            res[tgt_metric_name]["target_timestamps"] += single_metric_attr["target_timestamps"]
            res[tgt_metric_name]["target_value"] += single_metric_attr["target_value"]

        res[tgt_metric_name]["target_timestamps"] = sorted(
            res[tgt_metric_name]["target_timestamps"], key=lambda x: float(x)
        )

        if tgt_metric_name not in res.keys():
            continue

        tgt_res_attr = res[tgt_metric_name]
        if tgt_res_attr["cnt"] < 1:
            res.pop(tgt_metric_name)
            continue

        tgt_res_attr["avg"] = tgt_res_attr["sum"] / (tgt_res_attr["cnt"] + 1e-6)
        is_avg_bad = (cmp_method == "larger" and tgt_res_attr["avg"] > thresh) or (
            cmp_method == "smaller" and tgt_res_attr["avg"] < thresh
        )
        if (
            is_avg_bad
            or tgt_res_attr["bad_cnt"] > satisfy_frame_cnt_thresh
            or tgt_res_attr["bad_cnt"] / (tgt_res_attr["cnt"] + 1e-6) > satisfy_frame_ratio_threh
            or len(tgt_res_attr["target_timestamps"]) > 0
        ):
            has_bad_metric = True
        else:
            res.pop(tgt_metric_name)

    return res, has_bad_metric


class MetricsOnClip:
    def __init__(
        self,
        clip_id=-1,
        key_metrics={"mFDE": {"thresh": 1.5, "cmp_method": "larger"}},
    ):
        self.clip_id = clip_id
        self.frame_cnt = 0
        self.key_metrics = key_metrics
        self.key_metric_attr_dict = self._init_metric_attributes(self.key_metrics)

    def __eq__(self, another):
        """Equal."""
        if hasattr(another, "clip_id"):
            return self.clip_id == another.clip_id
        else:
            raise RuntimeError("clip id not exist")

    def __hash__(self):
        """Hash."""
        return self.clip_id

    def _init_metric_attributes(self, key_metrics):
        """Init metric."""
        metric_attr_dict = {}
        if key_metrics is None:
            return metric_attr_dict

        for name, cfg in key_metrics.items():
            assert name not in metric_attr_dict.keys()
            cmp_method = "larger"
            if cfg.get("cmp_method"):
                cmp_method = cfg["cmp_method"]
            metric_attr_dict[name] = MetricAttributes(compare_method=cmp_method, threshold=cfg["thresh"])

        return metric_attr_dict

    def update(self, metrics, timestamp):
        """Update."""
        self.frame_cnt += 1
        for name, value in metrics.items():
            if name not in self.key_metric_attr_dict.keys():
                continue
            self.key_metric_attr_dict[name].update(value, timestamp)

    def single_gpu_export_metric_result(self):
        """Export. Return metrics."""
        return self.key_metric_attr_dict
