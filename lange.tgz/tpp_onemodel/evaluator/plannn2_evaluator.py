# -*- coding: utf-8 -*-
"""Astra Planner Scene Evaluator."""
import multiprocessing as mp
import os
import time
import signal
import shutil
import pickle
import tempfile
from collections import defaultdict
from copy import deepcopy
from functools import partial
from typing import Any
from typing import Dict
from typing import List
from functools import partial
from tqdm.contrib.concurrent import process_map

import numpy as np
import pandas as pd
import torch
import torch.distributed as dist
from easydict import EasyDict
from prettytable import PrettyTable
from tabulate import tabulate
from torchpilot import logger
from torchpilot.evaluator.base_evaluator import BaseEvaluator
from torchpilot.utils.file_manager import FileManager
from torchpilot.utils.registries import MODULE

from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import FOCUS_CHECKER_TYPES
from tpp_onemodel.evaluator.plannn2_evaluator_utils.planner_env import PlannerEnv
from tpp_onemodel.evaluator.plannn2_evaluator_utils.planner_env import DEFAULT_REWARD_KEYS
from tpp_onemodel.evaluator.plannn2_evaluator_utils.planner_env_checker import PlannerEnvChecker
from concurrent.futures import ProcessPoolExecutor
from concurrent.futures import as_completed
from tpp_onemodel.data.dataset.plannn2_dataset_utils.meta_action_manager import MetaActionManager


visualization_cache_dir = "/dev/shm/melange"
def clean_cache(signum, frame):
    if os.path.exists(visualization_cache_dir):
        shutil.rmtree(visualization_cache_dir, ignore_errors=True)

signal.signal(signal.SIGTERM, clean_cache)
signal.signal(signal.SIGINT, clean_cache)

def mpi_gather(data, root=0, chunk_size=None):
    """Gather data."""
    from mpi4py import MPI  # pylint: disable=import-outside-toplevel

    comm = MPI.COMM_WORLD
    size = comm.Get_size()
    rank = comm.Get_rank()

    if not data or chunk_size is None or len(data) <= chunk_size:
        return comm.gather(data, root=root)

    per_rank_buffers = [[] for _ in range(size)] if rank == root else None
    for start in range(0, len(data), chunk_size):
        chunk = data[start : start + chunk_size]
        chunk_result = comm.gather(chunk, root=root)
        if rank == root:
            for idx in range(size):
                per_rank_buffers[idx].extend(chunk_result[idx])

    return per_rank_buffers


def _visualize_single_sample(vis_task):
    """
    可视化单个样本的辅助函数，用于多进程处理

    @param {dict} vis_task - 包含可视化所需的所有信息
    @param {str} vis_task.savename - 保存文件名
    @param {list} vis_task.raw_env - 环境数据
    @param {dict} vis_task.reward_logs - 奖励日志
    @param {numpy.ndarray} vis_task.ego_gt_state_polygon - 自车真值轨迹
    @param {numpy.ndarray} vis_task.ego_state_polygon - 自车预测轨迹（可选，用于common evaluation）
    @param {list} vis_task.vis_reward_keys - 可视化奖励键
    @param {int} vis_task.timestamp_size - 时间戳大小
    @param {int} vis_task.history_size - 历史大小
    @param {float} vis_task.dataset_fps - 数据集FPS
    @returns {str} 处理结果信息，成功或错误消息
    """
    try:
        from tpp_onemodel.evaluator.plannn2_evaluator_utils.planner_env import (
            PlannerEnv,
        )

        # 创建环境，vehicle_tokenizer传入None
        env = PlannerEnv(
            vis_task["raw_env"][0],
            vis_task["timestamp_size"],
            vis_task["history_size"],
            vis_task["dataset_fps"],
            None,  # vehicle_tokenizer设为None
            input_tensor_data=None,
        )

        # 检查是否有预测轨迹（用于common evaluation）
        if "ego_state_polygon" in vis_task:
            # Common evaluation: 使用预测轨迹和真值轨迹
            env.vis(
                savename=vis_task["savename"],
                ego_polygon=vis_task["ego_state_polygon"][0],  # 使用预测轨迹
                actions=None,
                gt_polygon=vis_task["ego_gt_state_polygon"][0],  # 使用真值轨迹
                pred_polygons_draw=None,
                reward_keys=vis_task["vis_reward_keys"],
                **vis_task["reward_logs"],
            )
        else:
            # Reward evaluation: 只使用真值轨迹
            env.vis(
                savename=vis_task["savename"],
                ego_polygon=vis_task["ego_gt_state_polygon"][0],
                actions=None,
                gt_polygon=vis_task["ego_gt_state_polygon"][0],
                pred_polygons_draw=None,
                reward_keys=vis_task["vis_reward_keys"],
                **vis_task["reward_logs"],
            )

        return f"Successfully saved: {vis_task['savename']}"

    except Exception as e:
        return f"Error processing {vis_task['savename']}: {str(e)}"

def worker_process_batch(instance, batch_indices, batch_preds, gt_poly, env_wrapper):
    """
    批处理 Worker：一次接收多个任务，在进程内部循环，减少通信开销。
    """
    results = []

    # 在子进程内部遍历这一批数据
    for i, original_idx in enumerate(batch_indices):
        # 还原原始的数据维度：取切片 [i:i+1] 以保持 (1, T, 2) 的维度
        pred_item = batch_preds[i : i + 1]

        # 直接调用实例的方法
        # 注意：这里会用到 instance (即 self)，这需要 pickle 整个实例
        # 但因为是分块传输，频率比原来低几十倍
        res = instance.calcu_reward_one_timestep(
            original_idx,
            pred_item,
            gt_poly,
            env_wrapper
        )
        results.append(res)

    return results


class Plannn2Evaluator(BaseEvaluator):
    """Astra planner scene evaluator."""

    def __init__(
        self,
        state_range,
        timestamp_size,
        history_size,
        dataset_fps,
        vis_input_tensor,
        env_block_size,
        plot_cfg,
        reward_model_cfg: Dict[str, Any] = None,
        open_loop: bool = False,
        close_loop: bool = False,
        need_plot: bool = False,
        checker: List = [],
        dataset_kwargs: Dict[str, Any] = None,
        use_gpu: bool = False,
        eval_rewards_cfg: Dict[str, Any] = None,
        vis_topk: int = 0,
        use_multiprocessing: bool = True,
        local_analyze_mode: bool = False,
        export_dir: str = None,
        skip_eval_rewards: bool = False,
        eval_meta_action: bool = False,
        traj_vocab_size: int = 1024,
    ):
        """Init."""
        super().__init__(use_gpu=use_gpu)
        self.state_range = state_range
        self.timestamp_size = timestamp_size
        self.history_size = history_size
        self.dataset_fps = dataset_fps
        self.vis_input_tensor = vis_input_tensor
        self.env_block_size = env_block_size
        self.plot_cfg = plot_cfg
        self._open_loop = open_loop
        self._close_loop = close_loop
        self._need_plot = need_plot
        self._checker = checker
        self.dataset_kwargs = dataset_kwargs
        self.reward_model_cfg = reward_model_cfg
        if reward_model_cfg is not None:
            self.rl_reward_model = MODULE.build(self.reward_model_cfg)
        self.eval_rewards_cfg = {}
        self.eval_gt_lower_only_cross = False
        if eval_rewards_cfg is not None:
            self.eval_rewards_cfg = EasyDict(eval_rewards_cfg)
            self.eval_gt_lower_only_cross = self.eval_rewards_cfg.eval_gt_lower_only_cross
        self.reward_eval_infos = ["sum", "mean", "std", "sparsity", "max", "min"]
        self.vis_topk = vis_topk
        self.use_multiprocessing = use_multiprocessing
        self.local_analyze_mode = local_analyze_mode
        self.export_dir = export_dir if local_analyze_mode else FileManager.get_export_dir()
        self.eval_meta_action = eval_meta_action
        self._traj_vocab_size = int(traj_vocab_size)
        # for close loop
        self.all_ax = []
        self.all_ay = []

        # 临时目录，用于存放可视化中间结果
        os.makedirs(visualization_cache_dir, exist_ok=True)
        self.temp_export_dir_handle = tempfile.TemporaryDirectory(dir=visualization_cache_dir)
        self.temp_export_dir = self.temp_export_dir_handle.name
        self.skip_eval_rewards = skip_eval_rewards

        if self._need_plot:
            self.vis_proc_pool = mp.get_context("spawn").Pool(processes=4)

    def __del__(self):
        """Destructor to clean up temporary resources."""
        if self._need_plot:
            self.vis_proc_pool.close()
            self.vis_proc_pool.join()
            if self.temp_export_dir_handle:
                self.temp_export_dir_handle.cleanup()
                self.temp_export_dir_handle = None

    def _get_export_dir(self) -> str:
        """
        获取导出目录路径

        @returns {str} - 导出目录路径
        """
        return self.export_dir

    def _get_temp_export_dir(self) -> str:
        """
        获取临时导出目录路径(内存文件系统)

        @returns {str} - 临时导出目录路径
        """
        return self.temp_export_dir

    def eval(
        self,
        model_outputs: Dict[str, Any],
        model_inputs: Dict[str, Any],
    ) -> Dict[str, Any]:
        if self.eval_rewards_cfg and "type" in self.eval_rewards_cfg:
            return self.reward_eval_gt_cluster(model_outputs, model_inputs)
        if self.eval_rewards_cfg:
            return self.rewards_eval(model_outputs, model_inputs)
        if self.eval_meta_action:
            return self.meta_action_eval(model_outputs, model_inputs)
        return self.common_eval(model_outputs, model_inputs)


    def meta_action_eval(
        self,
        model_outputs: Dict[str, Any],
        model_inputs: Dict[str, Any],
    ):
        """Eval."""
        # pred
        logger.info(f"dist.get_rank():{dist.get_rank()}")
        env_block_size = self.dataset_kwargs["env_block_size"]
        replan_time = self.dataset_kwargs["replan_time"]
        history_size = self.dataset_kwargs["history_size"]
        closedloop_simu_time = model_outputs["closedloop_simu_time"]
        pred_polygons = model_outputs["pred_polygons"].cpu().numpy() * self.dataset_kwargs.state_range

        history_polygon = model_inputs["ego_polygon_full"][:, :self.history_size, :, :].cpu().numpy() * self.dataset_kwargs.state_range
        _input_polygon = model_outputs["_input_polygon"].cpu().numpy() * self.dataset_kwargs.state_range
        _input_polyline = model_outputs["_input_polyline"].cpu().numpy() * self.dataset_kwargs.state_range
        _input_polymask = model_outputs["_input_polymask"].cpu().numpy()
        _input_property = model_outputs["_input_property"].cpu().numpy()
        raw_env = model_outputs["raw_env_list"]
        pred_polygons_draw = model_outputs["pred_long_trajs"].cpu().numpy() * self.dataset_kwargs.state_range

        polygon = model_inputs["ego_polygon"]
        property = model_inputs["ego_property"]
        latitude_label = model_outputs["latitude_label"].cpu().numpy()
        longitude_label = model_outputs["longitude_label"].cpu().numpy()
        latitude_gt_labels = np.array(model_inputs["cpu_data"]["raw_data"][0][0]["latitude_gt_labels"])
        longitude_gt_labels = np.array(model_inputs["cpu_data"]["raw_data"][0][0]["longitude_gt_labels"])

        backup = {}
        for data_idx in range(polygon.shape[0]):  # batch size
            if self.dataset_kwargs.get("post_padding", False):
                max_time = model_inputs["cpu_data"]["raw_data"][data_idx][0]["max_time"]
                valid_pred_frame = max_time - history_size
                closedloop_simu_time = valid_pred_frame // replan_time

                backup.setdefault("pred_polygons", pred_polygons)
                backup.setdefault("raw_env", raw_env)
                backup.setdefault("pred_polygons_draw", pred_polygons_draw)
                backup.setdefault("latitude_label", latitude_label)
                backup.setdefault("longitude_label", longitude_label)

                pred_polygons = backup["pred_polygons"][:, :valid_pred_frame]
                raw_env[data_idx] = backup["raw_env"][data_idx][:max_time]
                pred_polygons_draw = backup["pred_polygons_draw"][:, :valid_pred_frame]
                latitude_label = backup["latitude_label"][:, :valid_pred_frame]
                longitude_label = backup["longitude_label"][:, :valid_pred_frame]



            env = PlannerEnv(
                raw_env[data_idx],
                self.timestamp_size,
                self.history_size,
                self.dataset_fps,
                None,
                input_tensor_data=(
                    None
                    # if not self.vis_input_tensor
                    # else (input_polygon[0], input_polyline[0], input_poly_mask[0], input_property[0])
                ),
            )

            state_polygon = np.concatenate(
                [history_polygon[data_idx : data_idx + 1], pred_polygons[data_idx : data_idx + 1]],
                axis=1,
            )
            # state_property = np.concatenate(
            #     [
            #         _input_property[data_idx : data_idx + 1],
            #         # pred_propertys[data_idx : data_idx + 1],
            #     ],
            #     axis=1,
            # )

            gt_state_polygon = polygon[data_idx : data_idx + 1].cpu().numpy() * self.dataset_kwargs.state_range
            gt_state_property = property[data_idx : data_idx + 1].cpu().numpy()

            # 过滤，只保留自车
            ego_state_polygon = state_polygon
            ego_gt_state_polygon = (model_inputs["ego_polygon_full"].cpu().numpy() * self.dataset_kwargs.state_range)[:, model_inputs["ego_property_full"].cpu()[data_idx, :, 3]==1][:, : closedloop_simu_time * replan_time + history_size][data_idx : data_idx + 1]
            ego_gt_state_property = model_inputs["ego_property_full"].cpu().numpy()[:, model_inputs["ego_property_full"].cpu()[data_idx, :, 3]==1][:, : closedloop_simu_time * replan_time + history_size][data_idx : data_idx + 1]

            # metric
            m_ade, m_fde, bestFDE_idx, bestADE_idx = env.metric_2(
                ego_state_polygon, ego_gt_state_polygon, ego_gt_state_property
            )
            # 使用get_reward_infos获取完整的奖励信息，避免重复调用
            rewards, dones, result, log_infos, _ = self.get_reward_infos(
                ego_state_polygon[0:1], ego_gt_state_polygon[0:1], raw_env[data_idx : data_idx + 1], None
            )
            rewards = rewards[0, 1:]
            reward = np.nansum(rewards)
            log_infos["cumr"] = np.zeros_like(log_infos["overspeed"])
            log_infos["cumr"][1:] = np.cumsum(rewards)
            no_collision = log_infos["collision"] == 0  # 没有任何碰撞
            no_col_exceptrear = log_infos["collision_except_rear"] == 0  # 没有与静态目标发生碰撞、没有排除他车追尾后的其他碰撞
            no_col_withstatic = log_infos["collision_static"] == 0  # 没有与静态目标发生碰撞
            over_ax = np.any(np.abs(log_infos["ax"]) > 6)
            over_ay = np.any(np.abs(log_infos["ay"]) > 3)
            brake = np.any(np.abs(log_infos["ax"]) > 1.6)
            over_speed = log_infos["overspeed"].sum() / len(log_infos["overspeed"]) > 0.5
            tld_fault = log_infos["traffic_light_reward"].sum() < 0
            laneline_reward_mean = log_infos["cross_solid_line_reward"].sum()
            roadsign_fault = np.any(log_infos["navi_roadsign"] < 0)
            min_dis = np.min(log_infos["dis"])
            navilane_fault = np.any(log_infos["navi_lane_reward"] < 0)
            navilane_good = np.any(log_infos["navi_lane_reward"] > 0) and np.all(log_infos["navi_lane_reward"] >= 0)
            gt_mileage = log_infos["gt_mileage"]
            pred_mileage = log_infos["pred_mileage"]
            # reward_time = time.time() - t0

            self.all_ax.append(np.abs(log_infos["ax"]))
            self.all_ay.append(np.abs(log_infos["ay"]))

            idx = model_inputs["idx"][data_idx]

            log_info = f"idx: {idx}, noCol: {no_collision}, noColExceptRear: {no_col_exceptrear}, noColStatic: {no_col_withstatic}, r: {reward:.2f}, mADE: {m_ade:.2f}, mFDE: {m_fde:.2f}"
            logger.info(log_info)

            # 构造类似rewards_eval的数据结构
            common_eval_info = {"scenario": "ALL", "dataset_type": "ALL"}  # 由于eval_rewards_info是None，设为ALL

            # meta action metric
            longitude_metaaction_metrics = {}
            for longitude_key, longitude_val in MetaActionManager.LONGITUDE_LABELS_MAP.items():
                tp = (np.array(longitude_gt_labels) == longitude_val) & (longitude_label == longitude_val)
                fp = (np.array(longitude_gt_labels) != longitude_val) & (longitude_label == longitude_val)
                fn = (np.array(longitude_gt_labels) == longitude_val) & (longitude_label != longitude_val)
                longitude_metaaction_metrics[longitude_key] = {"tp": tp.sum(),
                                                               "fp": fp.sum(),
                                                               "fn": fn.sum()}

            # 构造指标结果字典，包含所有指标，使用完整的reward_results
            metric_results = {
                "no_collision": no_collision,
                "no_col_exceptrear": no_col_exceptrear,
                "no_col_withstatic": no_col_withstatic,
                "reward": reward,  # 保留原始的总reward
                "mADE": m_ade,
                "mFDE": m_fde,
                "over_ax": over_ax,
                "over_ay": over_ay,
                "over_speed": over_speed,
                "tld_fault": tld_fault,
                "brake": brake,
                "laneline_reward_mean": laneline_reward_mean,
                "roadsign_fault": roadsign_fault,
                "min_dis": min_dis,
                "navilane_fault": navilane_fault,
                "navilane_good": navilane_good,
                "gt_mileage": gt_mileage,
                "pred_mileage": pred_mileage,
                "dones": np.ones_like(rewards),  # 添加dones信息，用于后续处理
                "longitude_metaaction_metrics": longitude_metaaction_metrics,
                **log_infos,  # 包含完整的reward信息
            }

            self.gather_all_data.append(
                (
                    ego_gt_state_polygon,
                    ego_state_polygon,  # 添加预测轨迹
                    metric_results,
                    raw_env[data_idx : data_idx + 1],
                    idx,
                    common_eval_info,
                )
            )

            if self._need_plot:
                self._plot_close_loop(
                    env,
                    {
                        **self.plot_cfg,
                        "plot_badcase": False,
                        "no_col_withstatic": no_col_withstatic,
                        "no_col_exceptrear": no_col_exceptrear,
                        "navilane_fault": navilane_fault,
                        "tld_fault": tld_fault,
                        "over_speed": over_speed,
                        "roadsign_fault": roadsign_fault,
                        "over_ax": over_ax,
                        "over_ay": over_ay,
                    },
                    idx,
                    ego_state_polygon,
                    [0],
                    latitude_label[data_idx],
                    longitude_label[data_idx],
                    latitude_gt_labels,
                    longitude_gt_labels,
                    ego_gt_state_polygon,
                    pred_polygons_draw[data_idx],
                    log_infos,
                )



    def common_eval(
        self,
        model_outputs: Dict[str, Any],
        model_inputs: Dict[str, Any],
    ):
        """Eval."""
        # pred
        logger.info(f"dist.get_rank():{dist.get_rank()}")
        if self._open_loop:
            input_polygon = model_inputs["ego_polygon_full"][:, self.history_size :self.history_size+20].cpu().numpy() * self.state_range
            input_polyline = model_inputs["polyline"][:, self.history_size :self.history_size+20].cpu().numpy() * self.state_range
            input_poly_mask = model_inputs["polymask"][:, self.history_size :self.history_size+20].cpu().numpy()
            input_property = model_inputs["property"][:, self.history_size :self.history_size+20].cpu().numpy()
            # turnlightsignal_gt = model_inputs["turnlightsignal"].cpu().numpy()

            raw_env = model_inputs["cpu_data"]["raw_data"][0][0]
            idx = model_inputs["idx"][0]
            env = PlannerEnv(
                raw_env,
                self.timestamp_size,
                self.history_size,
                self.dataset_fps,
                input_tensor_data=(
                    None
                    if not self.vis_input_tensor
                    else (input_polygon[0], input_polyline[0], input_poly_mask[0], input_property[0])
                ),
            )

            # state_polygon = np.concatenate([input_polygon[:, self.env_block_size :], pred_polygons], axis=1)
            # state_property = np.concatenate([input_property[:, self.env_block_size :], pred_propertys], axis=1)

            # polygon = model_inputs["polygon_ori"]
            # property = model_inputs["property_ori"]
            # gt_state_polygon = polygon[:, self.env_block_size :].cpu().numpy() * self.state_range
            # gt_state_property = property[:, self.env_block_size :].cpu().numpy()

            # 过滤，只保留自车
            # ego_state_polygon = state_polygon[:, state_property[0, :, 3] == 1]
            # ego_gt_state_polygon = gt_state_polygon[:, gt_state_property[0, :, 3] == 1]
            # ego_gt_state_property = gt_state_property[:, gt_state_property[0, :, 3] == 1]

            pred_label = model_outputs["pred_label"].cpu().numpy()
            ego_state_gt_history = model_inputs["ego_polygon_full"][:, :self.history_size]
            ego_state_polygon = torch.cat((ego_state_gt_history.expand(model_outputs["pred_polygons"].shape[0], -1, -1, -1), model_outputs["pred_polygons"]), dim=1).cpu().numpy() * self.state_range
            ego_gt_state_polygon = model_inputs["ego_polygon_full"][:, :35].cpu().numpy() * self.state_range
            ego_gt_state_property = model_inputs["ego_property_full"][:, :35].cpu().numpy()

            # 这里构造一个红绿灯的信号
            # turnlightsignal_gt = turnlightsignal_gt.squeeze(0)

            m_ade, m_fde, bestFDE_idx, bestADE_idx = env.metric(
                ego_state_polygon, ego_gt_state_polygon, ego_gt_state_property
            )
            logger.warning(f"mADE: {m_ade:.4f}, mFDE: {m_fde:.4f}")
            subset_info = model_inputs["cpu_data"]["raw_data"][0][0].get("subset_info", None)
            if subset_info is not None:
                metric_res = {
                    "mADE": m_ade,
                    "mFDE": m_fde,
                    "scene_type": subset_info["split"],
                }
            else:
                metric_res = {"mADE": m_ade, "mFDE": m_fde, "scene_type": "single_scene"}
            self.gather_all_data.append(metric_res)

            # open loop plot
            if self._need_plot:
                latitude_gt_labels = np.asarray(raw_env.get("latitude_gt_labels", []))
                longitude_gt_labels = np.asarray(raw_env.get("longitude_gt_labels", []))
                pred_latitude_labels = None
                pred_longitude_labels = None
                if "pred_meta_action_label" in model_outputs:
                    pred_latitude_labels, pred_longitude_labels = self._decode_meta_action_labels(
                        model_outputs["pred_meta_action_label"].detach().cpu().numpy(),
                        self._traj_vocab_size,
                    )
                self._plot_open_loop(
                    idx,
                    env,
                    self.plot_cfg,
                    ego_state_polygon,
                    pred_label,
                    ego_gt_state_polygon,
                    bestFDE_idx,
                    latitude_gt_labels=latitude_gt_labels,
                    longitude_gt_labels=longitude_gt_labels,
                    pred_latitude_labels=pred_latitude_labels,
                    pred_longitude_labels=pred_longitude_labels,
                )

        if self._close_loop:
            env_block_size = self.dataset_kwargs["env_block_size"]
            replan_time = self.dataset_kwargs["replan_time"]
            history_size = self.dataset_kwargs["history_size"]
            closedloop_simu_time = model_outputs["closedloop_simu_time"]
            pred_polygons = model_outputs["pred_polygons"].cpu().numpy() * self.dataset_kwargs.state_range

            history_polygon = model_inputs["ego_polygon_full"][:, :self.history_size, :, :].cpu().numpy() * self.dataset_kwargs.state_range
            _input_polygon = model_outputs["_input_polygon"].cpu().numpy() * self.dataset_kwargs.state_range
            _input_polyline = model_outputs["_input_polyline"].cpu().numpy() * self.dataset_kwargs.state_range
            _input_polymask = model_outputs["_input_polymask"].cpu().numpy()
            _input_property = model_outputs["_input_property"].cpu().numpy()
            raw_env = model_outputs["raw_env_list"]
            pred_polygons_draw = model_outputs["pred_long_trajs"].cpu().numpy() * self.dataset_kwargs.state_range

            polygon = model_inputs["ego_polygon"]
            property = model_inputs["ego_property"]
            latitude_label = model_outputs["latitude_label"].cpu().numpy()
            longitude_label = model_outputs["longitude_label"].cpu().numpy()
            backup = {}
            latitude_gt_labels_all = [
                np.array(raw_data_item[0]["latitude_gt_labels"])
                for raw_data_item in model_inputs["cpu_data"]["raw_data"]
            ]
            longitude_gt_labels_all = [
                np.array(raw_data_item[0]["longitude_gt_labels"])
                for raw_data_item in model_inputs["cpu_data"]["raw_data"]
            ]
            for data_idx in range(polygon.shape[0]):  # batch size
                latitude_gt_labels = latitude_gt_labels_all[data_idx]
                longitude_gt_labels = longitude_gt_labels_all[data_idx]
                if self.dataset_kwargs.get("post_padding", False):
                    max_time = model_inputs["cpu_data"]["raw_data"][data_idx][0]["max_time"]
                    valid_pred_frame = max_time - history_size
                    closedloop_simu_time = valid_pred_frame // replan_time

                    backup.setdefault("pred_polygons", pred_polygons)
                    backup.setdefault("raw_env", raw_env)
                    backup.setdefault("pred_polygons_draw", pred_polygons_draw)
                    backup.setdefault("latitude_label", latitude_label)
                    backup.setdefault("longitude_label", longitude_label)

                    pred_polygons = backup["pred_polygons"][:, :valid_pred_frame]
                    raw_env[data_idx] = backup["raw_env"][data_idx][:max_time]
                    pred_polygons_draw = backup["pred_polygons_draw"][:, :valid_pred_frame]
                    latitude_label = backup["latitude_label"][:, :valid_pred_frame]
                    longitude_label = backup["longitude_label"][:, :valid_pred_frame]



                env = PlannerEnv(
                    raw_env[data_idx],
                    self.timestamp_size,
                    self.history_size,
                    self.dataset_fps,
                    None,
                    input_tensor_data=(
                        None
                        # if not self.vis_input_tensor
                        # else (input_polygon[0], input_polyline[0], input_poly_mask[0], input_property[0])
                    ),
                )

                state_polygon = np.concatenate(
                    [history_polygon[data_idx : data_idx + 1], pred_polygons[data_idx : data_idx + 1]],
                    axis=1,
                )
                # state_property = np.concatenate(
                #     [
                #         _input_property[data_idx : data_idx + 1],
                #         # pred_propertys[data_idx : data_idx + 1],
                #     ],
                #     axis=1,
                # )

                gt_state_polygon = polygon[data_idx : data_idx + 1].cpu().numpy() * self.dataset_kwargs.state_range
                gt_state_property = property[data_idx : data_idx + 1].cpu().numpy()

                # 过滤，只保留自车
                ego_state_polygon = state_polygon
                ego_gt_state_polygon = (model_inputs["ego_polygon_full"].cpu().numpy() * self.dataset_kwargs.state_range)[:, model_inputs["ego_property_full"].cpu()[data_idx, :, 3]==1][:, : closedloop_simu_time * replan_time + history_size][data_idx : data_idx + 1]
                ego_gt_state_property = model_inputs["ego_property_full"].cpu().numpy()[:, model_inputs["ego_property_full"].cpu()[data_idx, :, 3]==1][:, : closedloop_simu_time * replan_time + history_size][data_idx : data_idx + 1]

                # metric
                m_ade, m_fde, bestFDE_idx, bestADE_idx = env.metric_2(
                    ego_state_polygon, ego_gt_state_polygon, ego_gt_state_property
                )
                # 使用get_reward_infos获取完整的奖励信息，避免重复调用
                rewards, dones, result, log_infos, _ = self.get_reward_infos(
                    ego_state_polygon[0:1], ego_gt_state_polygon[0:1], raw_env[data_idx : data_idx + 1], None
                )
                rewards = rewards[0, 1:]
                reward = np.nansum(rewards)
                log_infos["cumr"] = np.zeros_like(log_infos["overspeed"])
                log_infos["cumr"][1:] = np.cumsum(rewards)
                no_collision = log_infos["collision"] == 0  # 没有任何碰撞
                no_col_exceptrear = log_infos["collision_except_rear"] == 0  # 没有与静态目标发生碰撞、没有排除他车追尾后的其他碰撞
                no_col_withstatic = log_infos["collision_static"] == 0  # 没有与静态目标发生碰撞
                over_ax = np.any(np.abs(log_infos["ax"]) > 6)
                over_ay = np.any(np.abs(log_infos["ay"]) > 3)
                brake = np.any(np.abs(log_infos["ax"]) > 1.6)
                over_speed = log_infos["overspeed"].sum() / len(log_infos["overspeed"]) > 0.5
                tld_fault = log_infos["traffic_light_reward"].sum() < 0
                laneline_reward_mean = log_infos["cross_solid_line_reward"].sum()
                roadsign_fault = np.any(log_infos["navi_roadsign"] < 0)
                min_dis = np.min(log_infos["dis"])
                navilane_fault = np.any(log_infos["navi_lane_reward"] < 0)
                navilane_good = np.any(log_infos["navi_lane_reward"] > 0) and np.all(log_infos["navi_lane_reward"] >= 0)
                gt_mileage = log_infos["gt_mileage"]
                pred_mileage = log_infos["pred_mileage"]
                # reward_time = time.time() - t0

                self.all_ax.append(np.abs(log_infos["ax"]))
                self.all_ay.append(np.abs(log_infos["ay"]))

                idx = model_inputs["idx"][data_idx]

                log_info = f"idx: {idx}, noCol: {no_collision}, noColExceptRear: {no_col_exceptrear}, noColStatic: {no_col_withstatic}, r: {reward:.2f}, mADE: {m_ade:.2f}, mFDE: {m_fde:.2f}"
                logger.info(log_info)

                # 构造类似rewards_eval的数据结构
                common_eval_info = {"scenario": "ALL", "dataset_type": "ALL"}  # 由于eval_rewards_info是None，设为ALL

                # 构造指标结果字典，包含所有指标，使用完整的reward_results
                metric_results = {
                    "no_collision": no_collision,
                    "no_col_exceptrear": no_col_exceptrear,
                    "no_col_withstatic": no_col_withstatic,
                    "reward": reward,  # 保留原始的总reward
                    "mADE": m_ade,
                    "mFDE": m_fde,
                    "over_ax": over_ax,
                    "over_ay": over_ay,
                    "over_speed": over_speed,
                    "tld_fault": tld_fault,
                    "brake": brake,
                    "laneline_reward_mean": laneline_reward_mean,
                    "roadsign_fault": roadsign_fault,
                    "min_dis": min_dis,
                    "navilane_fault": navilane_fault,
                    "navilane_good": navilane_good,
                    "gt_mileage": gt_mileage,
                    "pred_mileage": pred_mileage,
                    "dones": np.ones_like(rewards),  # 添加dones信息，用于后续处理
                    **log_infos,  # 包含完整的reward信息
                }

                self.gather_all_data.append(
                    (
                        ego_gt_state_polygon,
                        ego_state_polygon,  # 添加预测轨迹
                        metric_results,
                        raw_env[data_idx : data_idx + 1],
                        idx,
                        common_eval_info,
                    )
                )

                if self._need_plot:
                    self._plot_close_loop(
                        env,
                        {
                            **self.plot_cfg,
                            "plot_badcase": False,
                            "no_col_withstatic": no_col_withstatic,
                            "no_col_exceptrear": no_col_exceptrear,
                            "navilane_fault": navilane_fault,
                            "tld_fault": tld_fault,
                            "over_speed": over_speed,
                            "roadsign_fault": roadsign_fault,
                            "over_ax": over_ax,
                            "over_ay": over_ay,
                        },
                        idx,
                        ego_state_polygon,
                        [0],
                        latitude_label[data_idx],
                        longitude_label[data_idx],
                        latitude_gt_labels,
                        longitude_gt_labels,
                        ego_gt_state_polygon,
                        pred_polygons_draw[data_idx],
                        log_infos,
                    )

    def rewards_eval(
        self,
        model_outputs: Dict[str, Any],
        model_inputs: Dict[str, Any],
    ):

        env_block_size = self.dataset_kwargs["env_block_size"]
        replan_time = self.dataset_kwargs["replan_time"]
        history_size = self.dataset_kwargs["history_size"]
        closedloop_simu_time = model_outputs["closedloop_simu_time"]

        polygon = model_inputs["ego_polygon"].cpu().numpy()
        property = model_inputs["ego_property"].cpu().numpy()
        raw_env_list = model_outputs["raw_env_list"]
        raw_env_list_gt = model_outputs["raw_env_list_gt"]

        pred_polygons = model_outputs["pred_polygons"].cpu().numpy() * self.dataset_kwargs.state_range
        pred_propertys = model_outputs["pred_propertys"].cpu().numpy()
        _input_polygon = model_outputs["_input_polygon"].cpu().numpy() * self.dataset_kwargs.state_range
        _input_polyline = model_outputs["_input_polyline"].cpu().numpy() * self.dataset_kwargs.state_range
        _input_polymask = model_outputs["_input_polymask"].cpu().numpy()
        _input_property = model_outputs["_input_property"].cpu().numpy()

        # 对每个clip计算所有reward相关信息
        for data_idx in range(polygon.shape[0]):
            state_polygon = np.concatenate(
                [_input_polygon[data_idx : data_idx + 1], pred_polygons[data_idx : data_idx + 1]],
                axis=1,
            )
            state_property = np.concatenate(
                [
                    _input_property[data_idx : data_idx + 1],
                    pred_propertys[data_idx : data_idx + 1],
                ],
                axis=1,
            )
            ego_state_polygon = state_polygon[:, state_property[0, :, 3] == 1]

            gt_state_polygon = polygon[data_idx : data_idx + 1] * self.dataset_kwargs.state_range
            gt_state_property = property[data_idx : data_idx + 1]

            # 过滤，只保留自车
            ego_gt_state_polygon = gt_state_polygon[:, gt_state_property[0, :, 3] == 1]
            raw_env = raw_env_list[data_idx : data_idx + 1]
            raw_env_gt = raw_env_list_gt[data_idx : data_idx + 1]

            # metric reward
            eval_num_steps = min(len(raw_env[0]), ego_gt_state_polygon.shape[1])
            raw_env[0] = raw_env[0][:eval_num_steps]
            raw_env_gt[0] = raw_env_gt[0][:eval_num_steps]
            ego_gt_state_polygon = ego_gt_state_polygon[:, :eval_num_steps]
            ego_state_polygon = ego_state_polygon[:, :eval_num_steps]
            _, _, _, reward_results_pred, reward_results_gt = self.get_reward_infos(
                ego_state_polygon, ego_gt_state_polygon, raw_env, raw_env_gt, eval_type="rewards"
            )

            # 过滤多余key value
            reward_results_pred_filtered = defaultdict()
            reward_results_gt_filtered = defaultdict()
            keep_keys = []

            for key in reward_results_pred.keys():
                if key.endswith("reward"):
                    keep_keys.append(key)
                    for info_type in self.reward_eval_infos:
                        keep_keys.append(f"{key}_{info_type}")
            for key in reward_results_pred.keys():
                if not key in keep_keys and not key in DEFAULT_REWARD_KEYS:
                    continue
                reward_results_pred_filtered[key] = reward_results_pred[key]
                reward_results_gt_filtered[key] = reward_results_gt[key]
            del reward_results_pred, reward_results_gt
            idx = model_inputs["idx"][data_idx]
            eval_rewards_info = model_inputs["cpu_data"]["eval_rewards_info"][data_idx]
            clip_id = eval_rewards_info.get("clip_id", None)

            self.gather_all_data.append(
                (
                    ego_state_polygon,
                    ego_gt_state_polygon,
                    reward_results_pred_filtered,
                    reward_results_gt_filtered,
                    raw_env,
                    raw_env_gt,
                    idx,
                    eval_rewards_info,
                    clip_id,
                )
            )

    def calcu_reward_one_timestep(self, idx, pred_polygons, gt_polygons, tmp_env_list):
        rewards, dones, result, log_infos, _ = self.get_reward_infos(
            pred_polygons, gt_polygons, tmp_env_list, None, eval_type='eval_gt_pred'
        )  # tmp_env_list为列表外面还套了一层

        rewards = rewards[0, 1:]
        reward = np.nansum(rewards)
        log_infos["cumr"] = np.zeros_like(log_infos["overspeed"])
        log_infos["cumr"][1:] = np.cumsum(rewards)
        no_collision = log_infos["collision"] == 0  # 没有任何碰撞
        no_col_exceptrear = log_infos["collision_except_rear"] == 0  # 没有与静态目标发生碰撞、没有排除他车追尾后的其他碰撞
        no_col_withstatic = log_infos["collision_static"] == 0  # 没有与静态目标发生碰撞

        # 构造指标结果字典，包含所有指标，使用完整的reward_results
        metric_results = {
            "no_collision": no_collision,
            "no_col_exceptrear": no_col_exceptrear,
            "no_col_withstatic": no_col_withstatic,
            "reward_sum": reward,  # 保留原始的总reward
            "dones": np.ones_like(rewards),  # 添加dones信息，用于后续处理
            **log_infos,  # 包含完整的reward信息
        }
        plot_cfg = {
            **self.plot_cfg,
            "plot_badcase": False,
            "no_col_withstatic": no_col_withstatic,
            "no_col_exceptrear": no_col_exceptrear,
        }
        return idx, plot_cfg, metric_results

    def reward_eval_gt_cluster(
        self,
        model_outputs: Dict[str, Any],
        model_inputs: Dict[str, Any],
    ):
        """Eval. 对开环每帧轨迹计算reward"""
        debug_mode = False  # debug指定id的轨迹

        # pred
        logger.info(f"dist.get_rank():{dist.get_rank()}")

        # openloop
        env_block_size = self.dataset_kwargs["env_block_size"]
        replan_time = self.dataset_kwargs["replan_time"]
        history_size = self.dataset_kwargs["history_size"]
        closedloop_simu_time = model_outputs["closedloop_simu_time"]

        pred_long_polygons = model_outputs["pred_long_polygons"]
        gt_long_polygons = model_outputs["gt_long_polygons"]
        T0_cluster_polygons = model_outputs["T0_cluster_polygons"]
        raw_env_list = model_outputs["raw_env_list"]  # 用于可视化
        raw_env_list_gt = model_outputs["raw_env_list_gt"]
        raw_env_list_gt_openloop = model_outputs["raw_env_list_gt_openloop"]
        rollout_num = pred_long_polygons[0].shape[0]
        uuid = raw_env_list[0][0]['uuid'] if 'uuid' in raw_env_list[0][0].keys() else None
        ego_gt_polygons_all = model_outputs["ego_gt_polygons_all"][:, : closedloop_simu_time * replan_time + history_size]

        # 合并所有轨迹，一个for循环里算出所有结果。gt/pred/cluster
        pred_long_polygons_new = []  # 第一个位置为gt
        for gt, pred, cluster_polygons in zip(gt_long_polygons, pred_long_polygons, T0_cluster_polygons):
            print(gt.shape, pred.shape, cluster_polygons.shape)
            if gt.shape[1] == pred.shape[1]:
                pred_long_polygons_new.append(np.concatenate([gt, pred, cluster_polygons], axis=0))
        pred_long_polygons = pred_long_polygons_new

        if debug_mode:
            target_frame = 15
            target_idxs = [12]  # 填入log里的origin_id

        plot_cfgs, logs, top_reward_list = [], [], []
        for step_idx in range(len(pred_long_polygons)):
            pred_polygons = pred_long_polygons[step_idx]
            gt_polygons = gt_long_polygons[step_idx]
            if pred_polygons.shape[1] != gt_polygons.shape[1]:
                break

            pred_times = pred_long_polygons[step_idx].shape[1] - history_size
            if pred_times < 20:
                self.rl_reward_model._pred_t_num = pred_times
            tmp_env_list = raw_env_list_gt_openloop[step_idx]
            tmp_env_list = [d[0] for d in tmp_env_list]  # 0为batch_size维度
            env = PlannerEnv(
                tmp_env_list,  # 直接的一个列表
                pred_long_polygons[step_idx].shape[1],
                self.history_size,
                self.dataset_fps,
                self.vehicle_tokenizer,
                input_tensor_data=(None),
            )

            if debug_mode and target_frame == step_idx:
                for target_idx in target_idxs:
                    print(f'--------------> start idx: {step_idx}')
                    target_idx, plot_cfg, metric_results = self.calcu_reward_one_timestep(target_idx, pred_polygons[target_idx : target_idx + 1],
                                                                                   gt_polygons[0:1], [tmp_env_list])
                    print('pred_traj:', pred_polygons[target_idx : target_idx + 1].mean(axis=-2))
                    print('reward_sum:', step_idx, metric_results['reward_sum'], metric_results['reward'])
                    print('progress:', metric_results['progress_reward'], metric_results['progress_reward'].sum(), metric_results['progress_reward_sub_path'])
                    print('\n\n')
                    # if target_idx == target_idxs[-1]:
                    #     import pdb; pdb.set_trace()
            else:
                pass
                # continue

            # 轨迹数量可能非常大，几千条。加速计算
            total_samples = pred_polygons.shape[0]
            chunk_size = 100

            if torch.cuda.is_available():
                max_workers = min(8, os.cpu_count())
            else:
                max_workers = min(16, os.cpu_count())

            print(f"开始并行计算: 总数据 {total_samples} 条, 分块大小 {chunk_size}, 进程数 {max_workers}")

            # 2. 准备分块任务 (Batching)
            chunks = []
            env_wrapper = [tmp_env_list]  # 保持原有的 list 包裹结构
            gt_poly_slice = gt_polygons[0:1] # 保持原有的切片结构

            for start_idx in range(0, total_samples, chunk_size):
                end_idx = min(start_idx + chunk_size, total_samples)

                batch_indices = list(range(start_idx, end_idx))
                batch_preds = pred_polygons[start_idx : end_idx]

                # 打包参数：(self, 索引列表, 预测数据块, GT, 环境)
                chunks.append((
                    self,
                    batch_indices,
                    batch_preds,
                    gt_poly_slice,
                    env_wrapper
                ))

            # 3. 初始化结果容器
            onestep_plotcfg = [None] * total_samples
            onestep_logs = [None] * total_samples

            # 4. 执行多进程
            ctx = mp.get_context("spawn")
            torch.cuda.empty_cache() # 清理显存，防止 spawn 时 OOM

            with ProcessPoolExecutor(max_workers=max_workers, mp_context=ctx) as pool:
                futures = [pool.submit(worker_process_batch, *chunk) for chunk in chunks]

                # 5. 收集结果
                for fut in as_completed(futures):
                    try:
                        batch_results = fut.result()
                        # 将批次结果拆解并填回列表
                        for (idx, plot_cfg, metric_result) in batch_results:
                            onestep_plotcfg[idx] = plot_cfg
                            onestep_logs[idx] = metric_result
                    except Exception as e:
                        print(f"Error in batch execution: {e}")
                        import traceback
                        traceback.print_exc()
                        exit()

            # 选择有意义的轨迹做统计和展示，gt+rollout+cluster_top10
            r_list = np.array([d["reward_sum"] for d in onestep_logs])
            gt_start_idx = 0
            pred_start_idx = gt_start_idx + 1
            pred_end_idx = gt_start_idx + 1 + rollout_num

            # 获取rollout轨迹索引
            pred_sorted_idx = np.argsort(r_list[pred_start_idx:pred_end_idx])[::-1]
            pred_sorted_idx += pred_start_idx
            cluster_sorted_idx = np.argsort(r_list[pred_end_idx:])[::-1][:10]  # 聚类轨迹太多了只取前10
            cluster_sorted_idx += pred_end_idx
            final_idxs = np.concatenate([[0], pred_sorted_idx, cluster_sorted_idx])

            polygons = np.asarray(pred_long_polygons[step_idx])
            pred_long_polygons[step_idx] = polygons[final_idxs]
            onestep_logs = [onestep_logs[i] for i in final_idxs]
            onestep_plotcfg = [onestep_plotcfg[i] for i in final_idxs]
            sorted_r = [r_list[i] for i in final_idxs]

            idx = model_inputs["idx"][0]
            logger.info(f"step_idx: {step_idx}, final_idxs: {final_idxs}, sorted_r: {sorted_r}")
            self.print_traj_rewards(
                idx, step_idx, pred_long_polygons[step_idx], onestep_logs, history_size, sorted_r, final_idxs, uuid
            )

            plot_cfgs.append(onestep_plotcfg)
            logs.append(onestep_logs)
            top_reward_list.append(sorted_r)

        idx = model_inputs["idx"][0]

        env = PlannerEnv(
            raw_env_list[0],  # 直接的一个列表
            pred_long_polygons[step_idx].shape[1],
            self.history_size,
            self.dataset_fps,
            self.vehicle_tokenizer,
            input_tensor_data=(None),
        )

        # 绘制两个视频，一个显示top1,一个显示top20
        # 全部转为list传进去
        self._plot_multitraj_open_loop(
            env,
            plot_cfgs,
            idx,
            pred_long_polygons,
            None,
            ego_gt_polygons_all[0],
            logs,
            None,
            None,
            topk_traj=pred_long_polygons[0].shape[0],
            top_reward_list=top_reward_list,
            show_top_traj=True,
        )

        self._plot_multitraj_open_loop(
            env,
            plot_cfgs,
            idx,
            pred_long_polygons,
            None,
            ego_gt_polygons_all[0],
            logs,
            None,
            None,
            topk_traj=pred_long_polygons[0].shape[0],
            top_reward_list=top_reward_list,
            show_top_traj=False,
        )

    def get_nearest_traj_id(self, trajs):
        trajs = np.array(trajs)
        N = trajs.shape[0]

        diff = trajs[:, None] - trajs[None, :]  # shape (N, N, 20, 2)
        dist = np.linalg.norm(diff, axis=3).mean(axis=2)  # shape (N, N)
        np.fill_diagonal(dist, np.inf)
        nearest_ids = dist.argmin(axis=1)  # shape (N,)

        pairs = [(i, int(nearest_ids[i])) for i in range(N)]
        return pairs

    def get_nearest_farthest_traj_id(self, trajs):
        trajs = np.asarray(trajs)
        N = trajs.shape[0]

        diff = trajs[:, None] - trajs[None, :]  # (N, N, 20, 2)
        dist = np.linalg.norm(diff, axis=3).mean(axis=2)  # (N, N)
        np.fill_diagonal(dist, np.inf)  # 排除自身

        # 2. 最近 & 最远
        nearest_ids = dist.argmin(axis=1)  # (N,)
        farthest_ids = dist.argmax(axis=1)  # (N,)

        # 3. 组装结果：(原始id, 最近id, 最远id)
        triples = [(i, int(nearest_ids[i]), int(farthest_ids[i])) for i in range(N)]
        return triples

    def print_traj_rewards(self, data_idx, sim_idx, pred_polygons, logs, history_size, sorted_r, reward_idxs, uuid):
        pred_trajs = [d.mean(axis=-2)[history_size:] for d in pred_polygons]
        nearest_ids = self.get_nearest_farthest_traj_id(pred_trajs)

        datas = []
        headers = [
            "gt",
            "traj_id",
            "origin_id",
            "end_points",
            "nearest_traj_id",
            "farthest_traj_id",
            "reward_sum",
            "no_collision",
            "no_col_exceptrear",
            "no_col_withstatic",
            "collision_reward",
            "ttc_reward",
            "progress_reward",
            "progress_reward_spd",
            "progress_reward_sub_path",
            "centralization_reward",
            "toggle_reward",
            "ax_penalty",
            "ay_penalty",
            "acc_reward",
            "speed_limit_reward",
            "navi_lane_reward",
            "navi_reward",
            "navi_lane_change_reward",
            "wrong_way_reward",
            "cross_solid_line_reward",
            "traffic_light_reward",
            "min_distance_reward",
            "virtual_wall_reward",
        ]
        table = PrettyTable()
        table.field_names = headers
        table.float_format = ".3"
        for idx, (pred_traj, metric, pair) in enumerate(zip(pred_trajs, logs, nearest_ids)):
            gt_flag = True if idx == 0 else False
            one_line = [gt_flag, idx, reward_idxs[idx], pred_traj[-1], pair[1], pair[2], metric["reward_sum"]]
            mask = metric["dones"] >= 0
            for r_key in headers[7:]:
                value = metric[r_key]
                if ("penalty" in r_key or "reward" in r_key) and isinstance(metric[r_key], np.ndarray):
                    value = value[mask].sum()
                one_line.append(round(float(value), 1))
            datas.append(one_line)

        table.add_rows(datas)
        table_txt = str(table)
        logger.info(f"data_idx:{data_idx}, uuid:{uuid}, sim_time:{sim_idx} : ")
        logger.info("\n%s", table_txt)

    def get_reward_infos(self, ego_polygon, gt_polygon, raw_env, raw_env_gt, eval_type="common"):
        """
        获取完整的奖励信息，返回rl_reward_model的所有输出

        Args:
            ego_polygon: 预测轨迹
            gt_polygon: 真值轨迹
            raw_env: 环境数据

        Returns:
            tuple: (rewards, dones, result, processed_reward_results, log_infos)
            - rewards: 奖励序列
            - dones: 完成标志
            - result: 结果
            - processed_reward_results: 处理后的奖励统计信息
            - log_infos: 日志信息（原始reward_results[0]）
        """
        input_dict_pred = {
            "pred_polygon": ego_polygon,
            "gt_polygon": gt_polygon,
            "raw_env": raw_env,
            "eval_type": eval_type
        }
        rewards_pred, dones_pred, result_pred, reward_results_pred = self.rl_reward_model(
            input_dict_pred, train_mode=False
        )

        # 处理奖励统计信息
        reward_types = []
        # TODO: get multi rollout
        processed_reward_results_pred = reward_results_pred[0].copy()
        processed_reward_results_gt = None

        if (eval_type != "common") and (eval_type != 'eval_gt_pred'):
            input_dict_gt = {
                "pred_polygon": gt_polygon,
                "gt_polygon": gt_polygon,
                "raw_env": raw_env,
                "eval_type": eval_type
            }
            if self.eval_rewards_cfg["gt_env_enable"]:
                input_dict_gt["raw_env"] = raw_env_gt
            _, dones_gt, _, reward_results_gt = self.rl_reward_model(input_dict_gt, train_mode=False)

            # 将reward_results_pred和reward_results_gt中dones为0的reward设置为0
            pred_mask = dones_pred >= 0
            gt_mask = dones_gt >= 0
            reward_results_pred[0]["reward"] *= gt_mask[0]
            reward_results_gt[0]["reward"] *= pred_mask[0]
            processed_reward_results_gt = reward_results_gt[0].copy()

        for key in processed_reward_results_pred.keys():
            if key.endswith("reward"):
                reward_types.append(key)
        for reward_type in reward_types:
            reward_extra_infos_pred = self.get_reward_extra(processed_reward_results_pred, reward_type)
            processed_reward_results_pred.update(reward_extra_infos_pred)
            if processed_reward_results_gt is not None:
                reward_extra_infos_gt = self.get_reward_extra(processed_reward_results_gt, reward_type)
                processed_reward_results_gt.update(reward_extra_infos_gt)
        return rewards_pred, dones_pred, result_pred, processed_reward_results_pred, processed_reward_results_gt

    def get_reward_extra(self, reward_results, reward_type):
        sub_reward = reward_results[reward_type]
        dones = reward_results["dones"]
        mask = dones >= 0

        extra_infos = {}
        sub_reward_masked = sub_reward * mask
        sub_reward_sum = sub_reward_masked.sum()
        sub_reward_mean = sub_reward_sum / (mask.sum() + 1e-8)
        sub_reward_std = sub_reward[mask].std()
        sub_reward_sparsity = ((sub_reward_masked != 0).sum()) / (mask.sum() + 1e-8)

        extra_infos.update(
            {
                f"{reward_type}_sum": sub_reward_sum.item(),
                f"{reward_type}_mean": sub_reward_mean.item(),
                f"{reward_type}_std": sub_reward_std.item(),
                f"{reward_type}_sparsity": sub_reward_sparsity.item(),
                f"{reward_type}_max": sub_reward.max().item(),
                f"{reward_type}_min": sub_reward.min().item(),
            }
        )
        return extra_infos

    @staticmethod
    def _decode_meta_action_labels(
        pred_meta_action_label: np.ndarray,
        traj_vocab_size: int,
    ):
        """Decode sampled meta-action token ids to lateral/longitudinal label ids."""
        labels = np.asarray(pred_meta_action_label)
        if labels.size == 0:
            return None, None
        if labels.ndim == 1:
            labels = labels.reshape(1, -1)
        latitude = labels[:, 0:1].astype(np.int64) - int(traj_vocab_size)
        longitude = (
            labels[:, 1:2].astype(np.int64)
            - int(traj_vocab_size)
            - MetaActionManager.LATITUDE_LABEL_NUM
        )
        return latitude, longitude

    @staticmethod
    def _append_openloop_meta_action_vis_args(
        vis_args: Dict[str, Any],
        latitude_gt_labels: np.ndarray = None,
        longitude_gt_labels: np.ndarray = None,
        pred_latitude_labels: np.ndarray = None,
        pred_longitude_labels: np.ndarray = None,
        rollout_id: int = None,
    ) -> Dict[str, Any]:
        """Attach meta-action GT/pred labels for open-loop visualization."""
        if latitude_gt_labels is not None and latitude_gt_labels.size > 0:
            vis_args["latitude_gt_labels"] = latitude_gt_labels
        if longitude_gt_labels is not None and longitude_gt_labels.size > 0:
            vis_args["longitude_gt_labels"] = longitude_gt_labels
        if (
            rollout_id is not None
            and pred_latitude_labels is not None
            and pred_longitude_labels is not None
            and rollout_id < len(pred_latitude_labels)
        ):
            vis_args["latitude_label"] = pred_latitude_labels[rollout_id]
            vis_args["longitude_label"] = pred_longitude_labels[rollout_id]
        return vis_args

    def _plot_open_loop(
        self,
        i,
        env,
        plot_cfg,
        ego_state_polygon,
        pred_label,
        ego_gt_state_polygon,
        bestFDE_idx,
        latitude_gt_labels=None,
        longitude_gt_labels=None,
        pred_latitude_labels=None,
        pred_longitude_labels=None,
    ):
        plot_all = plot_cfg["plot_all"]
        plot_best = plot_cfg["plot_best"]
        save_gt = plot_cfg.get("save_gt", False)
        dump_pkl_only = plot_cfg.get("dump_pkl_only", False)

        vis_out_dir = os.path.join(self._get_export_dir(), "vis")
        os.makedirs(vis_out_dir, exist_ok=True)
        rollout_num = min(10, len(ego_state_polygon))  # batch size

        if plot_all or plot_best:
            if save_gt:
                savename = os.path.join(vis_out_dir, f"{i:0>5}_gt.mcap")
                tmp_savename = os.path.join(self._get_temp_export_dir(), f"{i:0>5}_gt.pkl")
                vis_args = self._append_openloop_meta_action_vis_args(
                    dict(
                        env=env,
                        savename=savename,
                        ego_polygon=ego_gt_state_polygon[0],
                        actions=None,
                        gt_polygon=ego_gt_state_polygon[0],
                        vis_reward=False,
                    ),
                    latitude_gt_labels=latitude_gt_labels,
                    longitude_gt_labels=longitude_gt_labels,
                )
                if not dump_pkl_only:
                    with open(tmp_savename, "wb") as f:
                        pickle.dump(vis_args, f)
                    self.vis_proc_pool.starmap_async(Plannn2Evaluator._vis_pkl, [(tmp_savename,)])
                else:
                    with open(savename.replace('.mcap', '.pkl'), "wb") as f:
                        pickle.dump(vis_args, f)
                    logger.info(f"Saved visualization pkl to {savename.replace('.mcap', '.pkl')}")
            if plot_all:
                for rollout_id in range(rollout_num):
                    savename = os.path.join(vis_out_dir, f"{i:0>5}_{rollout_id:0>2}.mcap")
                    tmp_savename = os.path.join(self._get_temp_export_dir(), f"{i:0>5}_{rollout_id:0>2}.pkl")
                    vis_args = self._append_openloop_meta_action_vis_args(
                        dict(
                            env=env,
                            savename=savename,
                            ego_polygon=ego_state_polygon[rollout_id],
                            actions=pred_label[rollout_id],
                            gt_polygon=ego_gt_state_polygon[0],
                            vis_reward=False,
                        ),
                        latitude_gt_labels=latitude_gt_labels,
                        longitude_gt_labels=longitude_gt_labels,
                        pred_latitude_labels=pred_latitude_labels,
                        pred_longitude_labels=pred_longitude_labels,
                        rollout_id=rollout_id,
                    )
                    if not dump_pkl_only:
                        with open(tmp_savename, "wb") as f:
                            pickle.dump(vis_args, f)
                        self.vis_proc_pool.starmap_async(Plannn2Evaluator._vis_pkl, [(tmp_savename,)])
                    else:
                        with open(savename.replace('.mcap', '.pkl'), "wb") as f:
                            pickle.dump(vis_args, f)
                        logger.info(f"Saved visualization pkl to {savename.replace('.mcap', '.pkl')}")
            if plot_best:
                for key, rollout_id in {"bestFDE": bestFDE_idx}.items():
                    savename = os.path.join(vis_out_dir, f"{i:0>5}_{key}_{rollout_id:0>2}.mcap")
                    tmp_savename = os.path.join(self._get_temp_export_dir(), f"{i:0>5}_{key}_{rollout_id:0>2}.pkl")
                    vis_args = self._append_openloop_meta_action_vis_args(
                        dict(
                            env=env,
                            savename=savename,
                            ego_polygon=ego_state_polygon[rollout_id],
                            actions=pred_label[rollout_id],
                            gt_polygon=ego_gt_state_polygon[0],
                            vis_reward=False,
                        ),
                        latitude_gt_labels=latitude_gt_labels,
                        longitude_gt_labels=longitude_gt_labels,
                        pred_latitude_labels=pred_latitude_labels,
                        pred_longitude_labels=pred_longitude_labels,
                        rollout_id=rollout_id,
                    )
                    if not dump_pkl_only:
                        with open(tmp_savename, "wb") as f:
                            pickle.dump(vis_args, f)
                        self.vis_proc_pool.starmap_async(Plannn2Evaluator._vis_pkl, [(tmp_savename,)])
                    else:
                        with open(savename.replace('.mcap', '.pkl'), "wb") as f:
                            pickle.dump(vis_args, f)
                        logger.info(f"Saved visualization pkl to {savename.replace('.mcap', '.pkl')}")

    def _plot_close_loop(
        self,
        env,
        plot_cfg,
        idx,
        ego_state_polygon,
        pred_label,
        latitude_label,
        longitude_label,
        latitude_gt_labels,
        longitude_gt_labels,
        ego_gt_state_polygon,
        pred_polygons_draw,
        log_infos,
    ):
        plot = True
        plot_badcase = plot_cfg["plot_badcase"]
        no_col_withstatic = plot_cfg["no_col_withstatic"]
        no_col_exceptrear = plot_cfg["no_col_exceptrear"]
        navilane_fault = plot_cfg["navilane_fault"]
        tld_fault = plot_cfg["tld_fault"]
        over_speed = plot_cfg["over_speed"]
        roadsign_fault = plot_cfg["roadsign_fault"]
        over_ax = plot_cfg["over_ax"]
        over_ay = plot_cfg["over_ay"]
        dump_pkl_only = plot_cfg.get("dump_pkl_only", False)
        vis_out_dir = os.path.join(self._get_export_dir(), "vis")
        os.makedirs(vis_out_dir, exist_ok=True)

        if plot or plot_badcase:
            if not plot_badcase:
                savename = os.path.join(vis_out_dir, f"{idx:0>5}.mcap")
                tmp_savename = os.path.join(self._get_temp_export_dir(), f"{idx:0>5}.pkl")
                vis_args = dict(
                    env = env,
                    savename = savename,
                    ego_polygon = ego_state_polygon[0],
                    actions = pred_label[0],
                    gt_polygon = ego_gt_state_polygon[0],
                    pred_polygons_draw = pred_polygons_draw,
                    latitude_label = latitude_label,
                    longitude_label = longitude_label,
                    latitude_gt_labels = latitude_gt_labels,
                    longitude_gt_labels = longitude_gt_labels,
                    log_infos = log_infos,
                )
                if not dump_pkl_only:
                    with open(tmp_savename, "wb") as f:
                        pickle.dump(vis_args, f)
                    self.vis_proc_pool.starmap_async(Plannn2Evaluator._vis_pkl, [(tmp_savename,)])
                else:
                    with open(savename.replace('.mcap', '.pkl'), "wb") as f:
                        pickle.dump(vis_args, f)
                    logger.info(f"Saved visualization pkl to {savename.replace('.mcap', '.pkl')}")
        else:
            if not no_col_withstatic:
                savename = os.path.join(vis_out_dir, f"{idx:0>5}_colwithstatic.mcap")
            elif not no_col_exceptrear:
                savename = os.path.join(vis_out_dir, f"{idx:0>5}_colexceptrear.mcap")
            elif navilane_fault:
                savename = os.path.join(vis_out_dir, f"{idx:0>5}_navilane.mcap")
            elif tld_fault:
                savename = os.path.join(vis_out_dir, f"{idx:0>5}_runredlight.mcap")
            elif roadsign_fault:
                savename = os.path.join(vis_out_dir, f"{idx:0>5}_roadsignfault.mcap")
            elif over_speed:
                savename = os.path.join(vis_out_dir, f"{idx:0>5}_overspeed.mcap")
            elif over_ax:
                savename = os.path.join(vis_out_dir, f"{idx:0>5}_overax.mcap")
            elif over_ay:
                savename = os.path.join(vis_out_dir, f"{idx:0>5}_overay.mcap")
            elif plot:
                savename = os.path.join(vis_out_dir, f"{idx:0>5}.mcap")
            # else:
            #     continue
            tmp_savename = os.path.join(self._get_temp_export_dir(), f"{idx:0>5}.pkl")
            vis_args = dict(
                env=env,
                savename=savename,
                ego_polygon=ego_state_polygon[0],
                actions=pred_label[0],
                gt_polygon=ego_gt_state_polygon[0],
                pred_polygons_draw=pred_polygons_draw,
                log_infos=log_infos,
            )
            if not dump_pkl_only:
                with open(tmp_savename, "wb") as f:
                    pickle.dump(vis_args, f)
                self.vis_proc_pool.starmap_async(Plannn2Evaluator._vis_pkl, [(tmp_savename,)])
            else:
                with open(savename.replace('.mcap', '.pkl'), "wb") as f:
                    pickle.dump(vis_args, f)
                logger.info(f"Saved visualization pkl to {savename.replace('.mcap', '.pkl')}")
    def _plot_multitraj_open_loop(self, env, plot_cfg, idx, ego_state_polygon, pred_label, ego_gt_state_polygon, log_infos, turnlightsignal_pred,
                         turnlightsignal_gt, topk_traj=10, top_reward_list=None, show_top_traj=False):
        vis_out_dir = os.path.join(FileManager.get_export_dir(), "vis")
        os.makedirs(vis_out_dir, exist_ok=True)
        # 可视化每步轨迹的reward结果
        if show_top_traj:
            savename = os.path.join(vis_out_dir, f"{idx:0>5}_top_reward_traj.mcap")
        else:
            savename = os.path.join(vis_out_dir, f"{idx:0>5}.mcap")
        env.vis_eachstep(
            savename=savename,
            ego_polygon=None,
            actions=None,
            gt_polygon=ego_gt_state_polygon,
            pred_polygons_draw=ego_state_polygon,
            topk_traj=topk_traj,
            log_infos=log_infos,
            top_reward_list=top_reward_list,
            show_top_traj=show_top_traj,
        )
        logger.warning(f"Saved visualization to {savename}")

    @staticmethod
    def _vis_pkl(pkl_path):
        with open(pkl_path, "rb") as f:
            args = pickle.load(f)
        env = args["env"]
        vis_kwargs = dict(args.get("log_infos") or {})
        for key, value in (
            ("pred_polygons_draw", args.get("pred_polygons_draw")),
            ("reward_keys", args.get("reward_keys")),
            ("turnlightsignal_pred", args.get("turnlightsignal_pred")),
            ("latitude_pred_labels", args.get("latitude_label")),
            ("longitude_pred_labels", args.get("longitude_label")),
            ("latitude_gt_labels", args.get("latitude_gt_labels")),
            ("longitude_gt_labels", args.get("longitude_gt_labels")),
        ):
            if value is not None:
                vis_kwargs[key] = value
        try:
            env.vis(
                savename=args.get("savename"),
                ego_polygon=args.get("ego_polygon"),
                actions=args.get("actions", None),
                gt_polygon=args.get("gt_polygon", None),
                **vis_kwargs,
            )
            logger.info("Visualization saved for %s", args.get("savename"))
        except Exception:
            logger.exception("Visualization failed for %s", pkl_path)
            raise

    def set_zero(self):
        """Set init evaluator."""
        self.gather_all_data = []

    def save_rank_data(self, data_to_save: Any, filename_prefix: str = "rank_data") -> None:
        """
        保存每个rank的评测数据到本地文件

        @param {Any} data_to_save - 要保存的数据
        @param {str} filename_prefix - 文件名前缀，默认为'rank_data'
        """
        try:
            # 获取当前rank和总rank数
            rank = dist.get_rank() if dist.is_initialized() else 0
            world_size = dist.get_world_size() if dist.is_initialized() else 1

            # 创建保存目录
            save_dir = os.path.join(self._get_export_dir(), "rank_eval_data")
            os.makedirs(save_dir, exist_ok=True)

            # 构建文件名，包含rank信息
            filename = f"{filename_prefix}_rank{rank}_of_{world_size}.pkl"
            filepath = os.path.join(save_dir, filename)

            # 保存数据到pickle文件
            with open(filepath, "wb") as f:
                pickle.dump(data_to_save, f)

            logger.info(f"Rank {rank}: Successfully saved evaluation data to {filepath}")

        except Exception as e:
            logger.error(
                f"Rank {dist.get_rank() if dist.is_initialized() else 0}: " f"Failed to save evaluation data: {str(e)}"
            )

    def dist_all_reduce(
        self,
        eval_results: Dict[Any, Any],
    ) -> Dict[Any, Any]:
        if self.skip_eval_rewards:
            return eval_results
        elif self.eval_rewards_cfg.get("eval_rewards_mode", None):
            return self.dist_all_reduce_rewards(eval_results)
        elif self.eval_meta_action:
            return self.dist_all_reduce_metaaction(eval_results)
        else:
            return self.dist_all_reduce_common(eval_results)


    def dist_all_reduce_metaaction(
        self,
        eval_results: Dict[Any, Any],
    ) -> Dict[Any, Any]:
        """All reduce by torch.distributed as dist.

        See example at ::class::ImageNetEvaluator.

        Args:
            eval_results (Dict[Any, Any]): Eval results of all epoch.

        Returns:
            eval_results.
        """

        # 在gather之前，先保存当前rank的数据
        self.save_rank_data(self.gather_all_data, "common_eval_data")

        dist.barrier()
        gather_all_data_all = mpi_gather(self.gather_all_data, chunk_size=32)

        try:
            if dist.get_rank() == 0:
                gather_all_data_all = sum(gather_all_data_all, [])
                # 使用新的数据结构处理
                ego_gt_state_polygons = [data[0] for data in gather_all_data_all]
                ego_state_polygons = [data[1] for data in gather_all_data_all]  # 预测轨迹
                metric_results = [data[2] for data in gather_all_data_all]
                raw_env = [data[3] for data in gather_all_data_all]
                data_idx_list = [data[4] for data in gather_all_data_all]
                common_eval_info_list = [data[5] for data in gather_all_data_all]

                # 构建类似rewards_eval的数据结构
                eval_results = {}

                meta_action_results = {}
                for longitude_key, longitude_val in MetaActionManager.LONGITUDE_LABELS_MAP.items():
                    fp = 0
                    fn = 0
                    tp = 0
                    for metric in metric_results:
                        fp += metric["longitude_metaaction_metrics"][longitude_val]["fp"]
                        fn += metric["longitude_metaaction_metrics"][longitude_val]["fn"]
                        tp += metric["longitude_metaaction_metrics"][longitude_val]["tp"]
                    meta_action_results[longitude_val] = {"recall": float(fp) / (fp + fn + 1e-6),
                                                            "precision": float(tp) / (tp + fp + 1e-6)}
                eval_results["meta_action_results"] = meta_action_results
        except Exception as error:
            raise error

        logger.info("finish dist_all_reduce.")
        return eval_results




    def dist_all_reduce_rewards(
        self,
        eval_results: Dict[Any, Any],
    ) -> Dict[Any, Any]:
        # 在gather之前，先保存当前rank的数据
        self.save_rank_data(self.gather_all_data, "rewards_eval_data")

        dist.barrier()
        gather_all_data_all = mpi_gather(self.gather_all_data)

        # try:
        if dist.get_rank() == 0:
            gather_all_data_all = sum(gather_all_data_all, [])

            ego_state_polygons = [data[0] for data in gather_all_data_all]
            ego_gt_state_polygons = [data[1] for data in gather_all_data_all]
            reward_results_pred = [data[2] for data in gather_all_data_all]
            reward_results_gt = [data[3] for data in gather_all_data_all]
            raw_env = [data[4] for data in gather_all_data_all]
            raw_env_gt = [data[5] for data in gather_all_data_all]
            data_idx_list = [data[6] for data in gather_all_data_all]
            eval_rewards_info_list = [data[7] for data in gather_all_data_all]
            clip_id_list = [data[8] for data in gather_all_data_all]
            # 结构: eval_results[scenario][dataset_type][reward_type][data_type]
            eval_results = defaultdict(
                lambda: defaultdict(
                    lambda: defaultdict(
                        lambda: {
                            "ids": [],
                            "clip_ids": [],
                            "pred": [],
                            "gt": [],
                            "raw_env": [],
                            "raw_env_gt": [],
                            "reward_logs_pred": [],
                            "reward_logs_gt": [],
                            "property": [],
                            **{info_type: {"pred": [], "gt": []} for info_type in self.reward_eval_infos},
                        }
                    )
                )
            )
            for idx, eval_rewards_info in enumerate(eval_rewards_info_list):
                reward_result_pred = reward_results_pred[idx]
                reward_result_gt = reward_results_gt[idx]
                scenario = eval_rewards_info["scenario"]
                reward_list = self.eval_rewards_cfg.eval_rewards_mode[scenario]["reward_list"]
                dataset_type = eval_rewards_info.get("dataset_type", "unknown")  # Get dataset_type
                if reward_list is None or len(reward_list) == 0:
                    reward_list = [
                        dict(type=i[: -len("_mean")], property="bonus")
                        for i in reward_result_pred.keys()
                        if i.endswith("_mean")
                    ]
                    self.eval_rewards_cfg.eval_rewards_mode[scenario] = reward_list

                process_reward_types = ["reward"] + [reward_cfg["type"] for reward_cfg in reward_list]
                for reward_type in process_reward_types:
                    # New data structure: eval_results[scenario][dataset_type][reward_type][data_type]
                    eval_results[scenario][dataset_type][reward_type]["ids"].append(data_idx_list[idx])
                    eval_results[scenario][dataset_type][reward_type]["clip_ids"].append(clip_id_list[idx])
                    eval_results[scenario][dataset_type][reward_type]["raw_env"].append(raw_env[idx])
                    eval_results[scenario][dataset_type][reward_type]["raw_env_gt"].append(raw_env_gt[idx])
                    eval_results[scenario][dataset_type][reward_type]["pred"].append(ego_state_polygons[idx])
                    eval_results[scenario][dataset_type][reward_type]["gt"].append(ego_gt_state_polygons[idx])
                    eval_results[scenario][dataset_type][reward_type]["reward_logs_pred"].append(reward_result_pred)
                    eval_results[scenario][dataset_type][reward_type]["reward_logs_gt"].append(reward_result_gt)
                    # General results without distinguishing good/bad cases
                    for info_type in self.reward_eval_infos:
                        eval_results[scenario][dataset_type][reward_type][info_type]["pred"].append(
                            reward_result_pred[f"{reward_type}_{info_type}"]
                        )
                        eval_results[scenario][dataset_type][reward_type][info_type]["gt"].append(
                            reward_result_gt[f"{reward_type}_{info_type}"]
                        )

            # Calculate statistics and aggregate
            self._calculate_reward_statistics(eval_results)

            # Display multi-level results using prettytable
            self._display_eval_results_with_prettytable(eval_results)

            # 使用多进程版本进行可视化，如果失败则回退到单进程版本
            if self.vis_topk < 0:
                self.vis_all_scenario(eval_results)
            elif self.vis_topk > 0:
                if self.use_multiprocessing:
                    self.vis_eval_reward_multiprocessing(eval_results)
                else:
                    self.vis_eval_reward(eval_results)

        # except Exception as error:
        #     raise error

    def vis_all_scenario(self, eval_results):
        """可视化数据的全部样本"""
        logger.info("=" * 100)
        logger.info("Visualizing ALL Dataset")
        logger.info("=" * 100)

        for scenario in sorted(eval_results.keys()):
            for dataset_type in eval_results[scenario].keys():
                if dataset_type == "ALL":
                    continue
                vis_reward_keys = [
                    *[k for k in eval_results[scenario][dataset_type].keys() if k not in ["ALL", "reward"]],
                ]
                for reward_type in eval_results[scenario][dataset_type].keys():
                    if reward_type in ["ALL", "reward"]:
                        continue
                    group_data = eval_results[scenario][dataset_type][reward_type]
                    if "mean" not in group_data or not group_data["mean"]:
                        continue
                    rewards = group_data["mean"].get("gt", [])
                    # 创建文件夹结构
                    vis_out_dir = os.path.join(
                        self._get_export_dir(),
                        f"vis/{scenario}/{dataset_type}",
                    )
                    os.makedirs(vis_out_dir, exist_ok=True)
                    for idx in range(len(rewards)):
                        logger.info(_visualize_single_sample(self._make_reward_vis_task(
                            group_data, idx, vis_out_dir, 0, "all", 0, vis_reward_keys, vis_type="gt"
                        )))
                        logger.info(_visualize_single_sample(self._make_reward_vis_task(
                            group_data, idx, vis_out_dir, 0, "all", 0, vis_reward_keys, vis_type="pred"
                        )))
                    break

    def vis_eval_reward(self, eval_results):
        """
        对每个eval_results[scenario][dataset_type][reward_type]组，
        找出该组中reward得分最高和最低的self.vis_topk个sample进行可视化
        """
        vis_topk = self.vis_topk

        # 可视化expert数据集中gt低于pred的样本
        self.vis_expert_gt_lower_than_pred(eval_results)

        if self.eval_gt_lower_only_cross:
            return

        for scenario in eval_results.keys():
            for dataset_type in eval_results[scenario].keys():
                if dataset_type == "ALL":
                    # visualize penalty_all_zero ids if present
                    zero_info_indices = eval_results[scenario][dataset_type].get("penalty_all_zero_indices", [])
                    if zero_info_indices:
                        vis_out_dir_zero = os.path.join(
                            self._get_export_dir(),
                            f"vis/{scenario}/{dataset_type}/penalty_all_zero",
                        )
                        os.makedirs(vis_out_dir_zero, exist_ok=True)
                        chosen = zero_info_indices[:vis_topk]
                        # choose a reference reward_type group's data containers
                        rt_keys = [
                            k
                            for k in eval_results[scenario][dataset_type].keys()
                            if k not in ["ALL", "penalty_all_zero_indices"]
                        ]
                        if rt_keys:
                            ref_group = eval_results[scenario][dataset_type][rt_keys[0]]
                            vis_reward_keys = [
                                *[k for k in eval_results[scenario][dataset_type].keys() if k != "ALL"],
                            ]
                            for rank, idx in enumerate(chosen):
                                if idx >= len(ref_group.get("ids", [])):
                                    continue
                                # single-process wrapper
                                self._vis_reward_sample_single(
                                    ref_group, idx, vis_out_dir_zero, "zero", 0.0, vis_reward_keys, rank
                                )
                    continue
                for reward_type in eval_results[scenario][dataset_type].keys():
                    if reward_type in ["ALL", "reward"]:
                        continue
                    for reward_property in eval_results[scenario][dataset_type][reward_type].keys():
                        group_data = eval_results[scenario][dataset_type][reward_type]

                        # 检查是否有rewards数据
                        if "mean" not in group_data or not group_data["mean"]:
                            logger.warning(
                                f"No rewards data for {scenario}/{dataset_type}/{reward_type}/{reward_property}"
                            )
                            continue

                        # 默认使用gt数据类型进行可视化

                        rewards = group_data["mean"].get("gt", [])
                        sample_count = len(rewards)

                        # 处理样本数量不足的情况
                        actual_topk = min(vis_topk, sample_count)
                        if actual_topk == 0:
                            continue

                        # 创建文件夹结构
                        vis_out_dir = os.path.join(
                            self._get_export_dir(),
                            f"vis/{scenario}/{dataset_type}/{reward_type}/{reward_property}",
                        )
                        os.makedirs(vis_out_dir, exist_ok=True)

                        # 获取排序索引
                        sorted_indices = group_data["argsort_gt"]

                        # 获取最高和最低得分的索引
                        top_indices = sorted_indices[-actual_topk:]  # 最高得分
                        bottom_indices = sorted_indices[:actual_topk]  # 最低得分

                        logger.info(
                            f"Visualizing {scenario}/{dataset_type}/{reward_type}/{reward_property}: "
                            f"top {actual_topk} and bottom {actual_topk} samples out of {sample_count}"
                        )

                        vis_reward_keys = [
                            *[k for k in eval_results[scenario][dataset_type].keys() if k != "ALL"],
                        ]

                        # 可视化最高得分的样本
                        for rank, idx in enumerate(top_indices):
                            self._vis_reward_sample_single(
                                group_data, idx, vis_out_dir, "top", rewards[idx], vis_reward_keys, rank
                            )

                        # 可视化最低得分的样本
                        for rank, idx in enumerate(bottom_indices):
                            self._vis_reward_sample_single(
                                group_data, idx, vis_out_dir, "bottom", rewards[idx], vis_reward_keys, rank
                            )

        logger.info("Finished reward visualization for all groups")

    def vis_eval_reward_multiprocessing(self, eval_results, num_processes=None):
        """
        对每个eval_results[scenario][dataset_type][reward_type]组，
        找出该组中reward得分最高和最低的self.eval_rewards_cfg.vis_topk个sample进行可视化
        使用多进程加速可视化过程，使用spawn启动方法避免CUDA在fork子进程中的问题

        @param {dict} eval_results - 评估结果字典，包含所有场景和数据类型的结果
        @param {int|None} num_processes - 进程数量，默认为None使用CPU核心数（最大限制为8）
        @returns {None} 无返回值，直接保存可视化文件
        """
        if num_processes is None:
            num_processes = mp.cpu_count()

        logger.info(f"Starting multiprocessing reward visualization with {num_processes} processes")

        vis_topk = self.vis_topk
        vis_tasks = []  # 存储所有可视化任务

        # 可视化expert数据集中gt低于pred的样本 - 使用多进程
        self._vis_expert_gt_lower_than_pred_multiprocessing(eval_results, num_processes)

        if self.eval_gt_lower_only_cross:
            return

        # 收集所有可视化任务
        for scenario in eval_results.keys():
            for dataset_type in eval_results[scenario].keys():
                # penalty_all_zero multiprocessing visualization via helper
                if dataset_type == "ALL":
                    tasks_zero, num_zero_all = self._collect_penalty_all_zero_tasks(
                        eval_results, scenario, dataset_type, vis_topk
                    )
                    if tasks_zero:
                        vis_tasks.extend(tasks_zero)
                        logger.info(
                            f"Preparing visualization tasks for {scenario}/{dataset_type}/penalty_all_zero: top {vis_topk} samples out of {num_zero_all}"
                        )
                    # Skip standard per-reward-type tasks for this dataset_type to mirror single-process behavior
                    continue
                for reward_type in eval_results[scenario][dataset_type].keys():
                    if reward_type in ["ALL", "reward"]:
                        continue
                    group_data = eval_results[scenario][dataset_type][reward_type]

                    # 检查是否有rewards数据
                    if "mean" not in group_data or not group_data["mean"]:
                        logger.warning(f"No rewards data for {scenario}/{dataset_type}/{reward_type}")
                        continue

                    rewards = group_data["mean"].get("gt", [])
                    sample_count = len(rewards)

                    # 处理样本数量不足的情况
                    actual_topk = min(vis_topk, sample_count)
                    if actual_topk == 0:
                        continue

                    # 创建文件夹结构
                    vis_out_dir = os.path.join(
                        self._get_export_dir(),
                        f"vis/{scenario}/{dataset_type}/{reward_type}",
                    )
                    os.makedirs(vis_out_dir, exist_ok=True)

                    # 获取排序索引
                    if "argsort_gt" in group_data:
                        sorted_indices = group_data["argsort_gt"]
                    else:
                        sorted_indices = np.argsort(rewards)

                    # 获取最高和最低得分的索引
                    top_indices = sorted_indices[-actual_topk:]  # 最高得分
                    bottom_indices = sorted_indices[:actual_topk]  # 最低得分

                    logger.info(
                        f"Preparing visualization tasks for {scenario}/{dataset_type}/{reward_type}: "
                        f"top {actual_topk} and bottom {actual_topk} samples out of {sample_count}"
                    )

                    vis_reward_keys = [
                        *[k for k in eval_results[scenario][dataset_type].keys() if k != "ALL"],
                    ]

                    # 准备最高得分样本的可视化任务
                    for rank, idx in enumerate(top_indices):
                        raw_env = group_data["raw_env"][idx]
                        assert len(raw_env) == 1, "raw_env should be a list of length 1, means batch only one sample"
                        vis_task = self._make_reward_vis_task(
                            group_data, idx, vis_out_dir, rank, "top", rewards[idx], vis_reward_keys
                        )
                        vis_tasks.append(vis_task)

                    # 准备最低得分样本的可视化任务
                    for rank, idx in enumerate(bottom_indices):
                        vis_task = self._make_reward_vis_task(
                            group_data, idx, vis_out_dir, rank, "bottom", rewards[idx], vis_reward_keys
                        )
                        vis_tasks.append(vis_task)

        # 使用通用的多进程处理函数
        self._run_multiprocessing_visualization(vis_tasks, num_processes, "reward", _visualize_single_sample)

        logger.info("Finished multiprocessing reward visualization for all groups")

    def dist_all_reduce_common(
        self,
        eval_results: Dict[Any, Any],
    ) -> Dict[Any, Any]:
        """All reduce by torch.distributed as dist.

        See example at ::class::ImageNetEvaluator.

        Args:
            eval_results (Dict[Any, Any]): Eval results of all epoch.

        Returns:
            eval_results.
        """
        if self._open_loop:
            mADE_all = np.array([data["mADE"] for data in self.gather_all_data])
            mFDE_all = np.array([data["mFDE"] for data in self.gather_all_data])
            df = pd.DataFrame(self.gather_all_data)
            result = df.groupby("scene_type").mean().to_dict("index")
            scene_list = list(result.keys())
            tab_data = [
                [scene, int((df.scene_type == scene).sum()), result[scene]["mADE"], result[scene]["mFDE"]]
                for scene in scene_list
            ]
            tab_data.insert(0, ["ALL", len(mADE_all), mADE_all.mean().item(), mFDE_all.mean().item()])
            scene_eval_table = tabulate(
                tab_data,
                headers=["Scene Type", "Count", "mADE", "mFDE"],
                floatfmt=".4f",
                tablefmt="grid",
            )
            logger.warning("Evaluation result scene: \n %s" % (scene_eval_table))

        if self._close_loop:

            # 在gather之前，先保存当前rank的数据
            self.save_rank_data(self.gather_all_data, "common_eval_data")

            dist.barrier()
            gather_all_data_all = mpi_gather(self.gather_all_data, chunk_size=32)

            try:
                if dist.get_rank() == 0:
                    gather_all_data_all = sum(gather_all_data_all, [])

                    if self._open_loop:
                        mADE_all = np.array([data["mADE"] for data in gather_all_data_all])
                        mFDE_all = np.array([data["mFDE"] for data in gather_all_data_all])
                        logger.warning("Evaluation result: mADE: %.4f, mFDE: %.4f" % (mADE_all.mean(), mFDE_all.mean()))
                    else:
                        # 使用新的数据结构处理
                        ego_gt_state_polygons = [data[0] for data in gather_all_data_all]
                        ego_state_polygons = [data[1] for data in gather_all_data_all]  # 预测轨迹
                        metric_results = [data[2] for data in gather_all_data_all]
                        raw_env = [data[3] for data in gather_all_data_all]
                        data_idx_list = [data[4] for data in gather_all_data_all]
                        common_eval_info_list = [data[5] for data in gather_all_data_all]

                        # 构建类似rewards_eval的数据结构
                        eval_results = defaultdict(
                            lambda: defaultdict(
                                lambda: defaultdict(
                                    lambda: {
                                        "ids": [],
                                        "gt": [],
                                        "pred": [],  # 添加预测轨迹
                                        "raw_env": [],
                                        "metric_logs": [],
                                        "values": [],
                                    }
                                )
                            )
                        )

                        # 定义基础指标类型及其属性，按Property分组排序
                        base_metric_types = [
                            # Performance - 总体性能指标
                            {"type": "reward", "property": "performance", "higher_better": True},
                            # Accuracy - 精度指标
                            {"type": "mADE", "property": "accuracy", "higher_better": False},
                            {"type": "mFDE", "property": "accuracy", "higher_better": False},
                            # Safety - 安全指标
                            {"type": "no_collision", "property": "safety", "higher_better": True},
                            {"type": "no_col_exceptrear", "property": "safety", "higher_better": True},
                            {"type": "no_col_withstatic", "property": "safety", "higher_better": True},
                            {"type": "min_dis", "property": "safety", "higher_better": True},
                            # Comfort - 舒适性指标
                            {"type": "over_ax", "property": "comfort", "higher_better": False},
                            {"type": "over_ay", "property": "comfort", "higher_better": False},
                            {"type": "brake", "property": "comfort", "higher_better": False},
                            # Compliance - 合规性指标
                            {"type": "over_speed", "property": "compliance", "higher_better": False},
                            {"type": "tld_fault", "property": "compliance", "higher_better": False},
                            {"type": "roadsign_fault", "property": "compliance", "higher_better": False},
                            {"type": "navilane_fault", "property": "compliance", "higher_better": False},
                            {"type": "navilane_good", "property": "compliance", "higher_better": True},
                            {"type": "laneline_reward_mean", "property": "compliance", "higher_better": True},
                            # Distance - 距离指标
                            {"type": "gt_mileage", "property": "distance", "higher_better": True},
                            {"type": "pred_mileage", "property": "distance", "higher_better": True},
                        ]

                        # 动态添加从reward_results中获得的奖励类型
                        metric_types = base_metric_types.copy()
                        if metric_results and metric_results[0]:
                            # 从第一个样本中获取所有奖励类型
                            sample_reward_result = metric_results[0]
                            for key in sample_reward_result.keys():
                                if key.endswith("_reward") and key not in [m["type"] for m in metric_types]:
                                    # 添加各种reward类型
                                    metric_types.append(
                                        {"type": key, "property": "reward_component", "higher_better": True}
                                    )
                                elif key.endswith("_mean") and key.replace("_mean", "") not in [
                                    m["type"] for m in metric_types
                                ]:
                                    # 添加各种reward的mean值
                                    metric_types.append(
                                        {"type": key, "property": "reward_statistic", "higher_better": True}
                                    )
                                elif key.endswith("_std") and key.replace("_std", "") not in [
                                    m["type"] for m in metric_types
                                ]:
                                    # 添加各种reward的std值
                                    metric_types.append(
                                        {"type": key, "property": "reward_statistic", "higher_better": False}  # std越小越好
                                    )
                                elif key.endswith("_sparsity") and key.replace("_sparsity", "") not in [
                                    m["type"] for m in metric_types
                                ]:
                                    # 添加各种reward的sparsity值
                                    metric_types.append(
                                        {
                                            "type": key,
                                            "property": "reward_statistic",
                                            "higher_better": True,  # sparsity可能越高越好，取决于具体情况
                                        }
                                    )
                                elif key.endswith("_max") and key.replace("_max", "") not in [
                                    m["type"] for m in metric_types
                                ]:
                                    # 添加各种reward的max值
                                    metric_types.append(
                                        {"type": key, "property": "reward_statistic", "higher_better": True}
                                    )
                                elif key.endswith("_min") and key.replace("_min", "") not in [
                                    m["type"] for m in metric_types
                                ]:
                                    # 添加各种reward的min值
                                    metric_types.append(
                                        {
                                            "type": key,
                                            "property": "reward_statistic",
                                            "higher_better": True,  # 对于reward，min也是越高越好
                                        }
                                    )

                        for idx, common_eval_info in enumerate(common_eval_info_list):
                            metric_result = metric_results[idx]
                            scenario = common_eval_info["scenario"]  # "ALL"
                            dataset_type = common_eval_info["dataset_type"]  # "ALL"

                            for metric_info in metric_types:
                                metric_type = metric_info["type"]
                                if metric_type in metric_result:
                                    eval_results[scenario][dataset_type][metric_type]["ids"].append(data_idx_list[idx])
                                    eval_results[scenario][dataset_type][metric_type]["raw_env"].append(raw_env[idx])
                                    eval_results[scenario][dataset_type][metric_type]["gt"].append(
                                        ego_gt_state_polygons[idx]
                                    )
                                    eval_results[scenario][dataset_type][metric_type]["pred"].append(
                                        ego_state_polygons[idx]
                                    )  # 添加预测轨迹
                                    eval_results[scenario][dataset_type][metric_type]["metric_logs"].append(
                                        metric_result
                                    )
                                    eval_results[scenario][dataset_type][metric_type]["values"].append(
                                        metric_result[metric_type]
                                    )
                                    eval_results[scenario][dataset_type][metric_type]["higher_better"] = metric_info[
                                        "higher_better"
                                    ]
                                    eval_results[scenario][dataset_type][metric_type]["property"] = metric_info[
                                        "property"
                                    ]

                        # 计算统计信息
                        self._calculate_common_statistics(eval_results)

                        # 显示表格结果
                        self._display_common_eval_results_with_prettytable(eval_results)

                        # 可视化top5 good/bad样本，使用多进程版本进行可视化，如果失败则回退到单进程版本
                        if self.vis_topk > 0:
                            if self.use_multiprocessing:
                                self.vis_common_eval_metrics_multiprocessing(eval_results)
                            else:
                                self.vis_common_eval_metrics(eval_results)

            except Exception as error:
                raise error

        logger.info("finish dist_all_reduce.")
        # return eval_results
        return None

    def _calculate_common_statistics(self, eval_results):
        """Calculate common evaluation statistics

        Args:
            eval_results: Evaluation results dict with structure eval_results[scenario][dataset_type][metric_type][data_type]
        """
        for scenario in eval_results.keys():
            for dataset_type in eval_results[scenario].keys():
                for metric_type in eval_results[scenario][dataset_type].keys():
                    values = eval_results[scenario][dataset_type][metric_type]["values"]
                    if values:
                        # 处理数组值的情况：将数组转换为标量值
                        processed_values = []
                        for value in values:
                            if isinstance(value, (np.ndarray, list)):
                                # 如果是数组，取平均值作为标量
                                if len(value) > 0:
                                    processed_values.append(np.nanmean(value))
                                else:
                                    processed_values.append(0.0)
                            else:
                                # 如果已经是标量，直接使用
                                processed_values.append(value)

                        if processed_values:
                            eval_results[scenario][dataset_type][metric_type]["mean"] = np.nanmean(processed_values)
                            eval_results[scenario][dataset_type][metric_type]["std"] = np.nanstd(processed_values)
                            eval_results[scenario][dataset_type][metric_type]["max"] = np.nanmax(processed_values)
                            eval_results[scenario][dataset_type][metric_type]["min"] = np.nanmin(processed_values)
                            eval_results[scenario][dataset_type][metric_type]["count"] = len(processed_values)

                            # 根据higher_better决定排序方向
                            higher_better = eval_results[scenario][dataset_type][metric_type].get("higher_better", True)
                            if higher_better:
                                eval_results[scenario][dataset_type][metric_type]["argsort"] = np.argsort(
                                    processed_values
                                )[
                                    ::-1
                                ]  # 降序
                            else:
                                eval_results[scenario][dataset_type][metric_type]["argsort"] = np.argsort(
                                    processed_values
                                )  # 升序

                            # 更新values为处理后的标量值，用于后续可视化
                            eval_results[scenario][dataset_type][metric_type]["values"] = processed_values

    def _display_common_eval_results_with_prettytable(self, eval_results):
        """Display common evaluation results using prettytable

        Args:
            eval_results: Evaluation results dictionary
        """
        logger.info("=" * 100)
        logger.info("Common Evaluation Results Report")
        logger.info("=" * 100)

        # Create table
        table = PrettyTable()
        table.field_names = [
            "Scenario",
            "Dataset Type",
            "Metric Type",
            "Property",
            "Mean",
            "Std",
            "Max",
            "Min",
            "Count",
        ]

        # 定义Property的显示顺序
        property_order = [
            "performance",
            "accuracy",
            "safety",
            "comfort",
            "compliance",
            "distance",
            "reward_component",
            "reward_statistic",
        ]

        for scenario in sorted(eval_results.keys()):
            for dataset_type in sorted(eval_results[scenario].keys()):
                # 按Property分组并排序
                metrics_by_property = {}
                for metric_type in eval_results[scenario][dataset_type].keys():
                    metric_data = eval_results[scenario][dataset_type][metric_type]
                    prop = metric_data.get("property", "unknown")
                    if prop not in metrics_by_property:
                        metrics_by_property[prop] = []
                    metrics_by_property[prop].append((metric_type, metric_data))

                # 按预定义的Property顺序显示
                for prop in property_order:
                    if prop in metrics_by_property:
                        # 对每个Property内的指标按名称排序
                        sorted_metrics = sorted(metrics_by_property[prop], key=lambda x: x[0])
                        for metric_type, metric_data in sorted_metrics:
                            row = [
                                scenario,
                                dataset_type,
                                metric_type,
                                prop,
                                f"{metric_data.get('mean', 0):.6f}",
                                f"{metric_data.get('std', 0):.6f}",
                                f"{metric_data.get('max', 0):.6f}",
                                f"{metric_data.get('min', 0):.6f}",
                                str(metric_data.get("count", 0)),
                            ]
                            table.add_row(row)

                # 处理未在预定义顺序中的Property
                for prop, metrics in metrics_by_property.items():
                    if prop not in property_order:
                        sorted_metrics = sorted(metrics, key=lambda x: x[0])
                        for metric_type, metric_data in sorted_metrics:
                            row = [
                                scenario,
                                dataset_type,
                                metric_type,
                                prop,
                                f"{metric_data.get('mean', 0):.6f}",
                                f"{metric_data.get('std', 0):.6f}",
                                f"{metric_data.get('max', 0):.6f}",
                                f"{metric_data.get('min', 0):.6f}",
                                str(metric_data.get("count", 0)),
                            ]
                            table.add_row(row)

        logger.info(f"\n{table}")

    def _vis_reward_sample_single(
        self, group_data, idx, vis_out_dir, label, score_value, vis_reward_keys, rank, vis_type="gt"
    ):
        """Single-process rendering for a reward sample (shared by top/bottom/zero)."""
        sample_id = group_data["ids"][idx]
        if hasattr(sample_id, "item"):
            sample_id = sample_id.item()
        clip_id = None
        if "clip_ids" in group_data and idx < len(group_data.get("clip_ids", [])):
            clip_id = group_data["clip_ids"][idx]
        name_id = clip_id if clip_id is not None else sample_id
        if label in ("top", "bottom"):
            savename = os.path.join(vis_out_dir, f"{label}_rank{rank+1}_id_{name_id}_reward{score_value:.4f}.mcap")
        else:
            savename = os.path.join(vis_out_dir, f"zero_rank{rank+1}_id_{name_id}.mcap")
        if self.eval_rewards_cfg["gt_env_enable"] and vis_type == "gt":
            raw_env = group_data["raw_env_gt"][idx]
        else:
            raw_env = group_data["raw_env"][idx]
        raw_env = group_data["raw_env"][idx]

        reward_logs = group_data[f"reward_logs_{vis_type}"][idx]
        ego_gt_state_polygon = group_data[vis_type][idx]

        env = PlannerEnv(
            raw_env[0],
            self.timestamp_size,
            self.history_size,
            self.dataset_fps,
            self.vehicle_tokenizer,
            input_tensor_data=None,
        )
        env.vis(
            savename=savename,
            ego_polygon=ego_gt_state_polygon[0],
            actions=None,
            gt_polygon=ego_gt_state_polygon[0],
            pred_polygons_draw=None,
            reward_keys=vis_reward_keys,
            **reward_logs,
        )
        logger.info(f"Saved {label} visualization: {savename}")

    def vis_common_eval_metrics(self, eval_results):
        """
        对每个eval_results[scenario][dataset_type][metric_type]组，
        找出该组中指标得分最高和最低的vis_topk个sample进行可视化
        """
        vis_topk = self.vis_topk
        for scenario in eval_results.keys():
            for dataset_type in eval_results[scenario].keys():
                for metric_type in eval_results[scenario][dataset_type].keys():
                    group_data = eval_results[scenario][dataset_type][metric_type]

                    # 检查是否有values数据
                    if "values" not in group_data or not group_data["values"]:
                        logger.warning(f"No values data for {scenario}/{dataset_type}/{metric_type}")
                        continue

                    values = group_data["values"]
                    sample_count = len(values)

                    # 处理样本数量不足的情况
                    actual_topk = min(vis_topk, sample_count)
                    if actual_topk == 0:
                        continue

                    # 创建文件夹结构
                    vis_out_dir = os.path.join(
                        self._get_export_dir(),
                        f"vis_common/{scenario}/{dataset_type}/{metric_type}",
                    )
                    os.makedirs(vis_out_dir, exist_ok=True)

                    # 获取排序索引
                    sorted_indices = group_data["argsort"]
                    higher_better = group_data.get("higher_better", True)

                    # 获取最好和最差的索引
                    if higher_better:
                        best_indices = sorted_indices[:actual_topk]  # 最高得分（降序排列，所以取前面）
                        worst_indices = sorted_indices[-actual_topk:]  # 最低得分
                        best_label, worst_label = "best", "worst"
                    else:
                        best_indices = sorted_indices[:actual_topk]  # 最低得分（升序排列，所以取前面）
                        worst_indices = sorted_indices[-actual_topk:]  # 最高得分
                        best_label, worst_label = "best", "worst"

                    logger.info(
                        f"Visualizing {scenario}/{dataset_type}/{metric_type}: "
                        f"top {actual_topk} {best_label} and {actual_topk} {worst_label} samples out of {sample_count}"
                    )

                    # 可视化最好的样本
                    for rank, idx in enumerate(best_indices):
                        sample_id = group_data["ids"][idx]
                        if hasattr(sample_id, "item"):
                            sample_id = sample_id.item()

                        clip_id = None
                        if "clip_ids" in group_data and idx < len(group_data.get("clip_ids", [])):
                            clip_id = group_data["clip_ids"][idx]
                        name_id = clip_id if clip_id is not None else sample_id
                        savename = os.path.join(
                            vis_out_dir, f"{best_label}_rank{rank+1}_id_{name_id}_value{values[idx]:.4f}.mcap"
                        )
                        raw_env = group_data["raw_env"][idx]
                        metric_logs = group_data["metric_logs"][idx]
                        ego_gt_state_polygon = group_data["gt"][idx]
                        ego_state_polygon = group_data["pred"][idx]  # 获取预测轨迹

                        assert len(raw_env) == 1, "raw_env should be a list of length 1"

                        env = PlannerEnv(
                            raw_env[0],
                            self.timestamp_size,
                            self.history_size,
                            self.dataset_fps,
                            self.vehicle_tokenizer,
                            input_tensor_data=None,
                        )

                        # 从metric_logs中提取可视化所需的log_infos
                        vis_reward_keys = [metric_type]
                        log_infos_for_vis = {
                            k: v
                            for k, v in metric_logs.items()
                            if isinstance(v, (np.ndarray, list, float, int))
                            and k
                            not in [
                                "no_collision",
                                "no_col_exceptrear",
                                "no_col_withstatic",
                                "reward",
                                "mADE",
                                "mFDE",
                                "over_ax",
                                "over_ay",
                                "over_speed",
                                "tld_fault",
                                "brake",
                                "laneline_reward_mean",
                                "roadsign_fault",
                                "min_dis",
                                "navilane_fault",
                                "navilane_good",
                                "gt_mileage",
                                "pred_mileage",
                            ]
                        }

                        env.vis(
                            savename=savename,
                            ego_polygon=ego_state_polygon[0],  # 使用预测轨迹
                            actions=None,
                            gt_polygon=ego_gt_state_polygon[0],  # 使用真值轨迹
                            pred_polygons_draw=None,
                            reward_keys=vis_reward_keys,
                            **metric_logs,
                        )
                        logger.info(f"Saved {best_label} visualization: {savename}")

                    # 可视化最差的样本
                    for rank, idx in enumerate(worst_indices):
                        sample_id = group_data["ids"][idx]
                        if hasattr(sample_id, "item"):
                            sample_id = sample_id.item()

                        clip_id = None
                        if "clip_ids" in group_data and idx < len(group_data.get("clip_ids", [])):
                            clip_id = group_data["clip_ids"][idx]
                        name_id = clip_id if clip_id is not None else sample_id
                        savename = os.path.join(
                            vis_out_dir, f"{worst_label}_rank{rank+1}_id_{name_id}_value{values[idx]:.4f}.mcap"
                        )
                        raw_env = group_data["raw_env"][idx]
                        metric_logs = group_data["metric_logs"][idx]
                        ego_gt_state_polygon = group_data["gt"][idx]
                        ego_state_polygon = group_data["pred"][idx]  # 获取预测轨迹

                        env = PlannerEnv(
                            raw_env[0],
                            self.timestamp_size,
                            self.history_size,
                            self.dataset_fps,
                            self.vehicle_tokenizer,
                            input_tensor_data=None,
                        )

                        # 从metric_logs中提取可视化所需的log_infos
                        vis_reward_keys = [metric_type]
                        log_infos_for_vis = {
                            k: v
                            for k, v in metric_logs.items()
                            if isinstance(v, (np.ndarray, list, float, int))
                            and k
                            not in [
                                "no_collision",
                                "no_col_exceptrear",
                                "no_col_withstatic",
                                "reward",
                                "mADE",
                                "mFDE",
                                "over_ax",
                                "over_ay",
                                "over_speed",
                                "tld_fault",
                                "brake",
                                "laneline_reward_mean",
                                "roadsign_fault",
                                "min_dis",
                                "navilane_fault",
                                "navilane_good",
                                "gt_mileage",
                                "pred_mileage",
                            ]
                        }

                        env.vis(
                            savename=savename,
                            ego_polygon=ego_state_polygon[0],  # 使用预测轨迹
                            actions=None,
                            gt_polygon=ego_gt_state_polygon[0],  # 使用真值轨迹
                            pred_polygons_draw=None,
                            reward_keys=vis_reward_keys,
                            **log_infos_for_vis,
                        )
                        logger.info(f"Saved {worst_label} visualization: {savename}")

        logger.info("Finished common evaluation metrics visualization for all groups")

    def vis_common_eval_metrics_multiprocessing(self, eval_results, num_processes=None):
        """
        对每个eval_results[scenario][dataset_type][metric_type]组，
        找出该组中指标得分最高和最低的vis_topk个sample进行可视化
        使用多进程加速可视化过程，使用spawn启动方法避免CUDA在fork子进程中的问题

        @param {dict} eval_results - 评估结果字典，包含所有场景和数据类型的结果
        @param {int} vis_topk - 可视化top k个样本，默认为5
        @param {int|None} num_processes - 进程数量，默认为None使用CPU核心数（最大限制为8）
        @returns {None} 无返回值，直接保存可视化文件
        """
        if num_processes is None:
            num_processes = mp.cpu_count()

        logger.info(f"Starting multiprocessing common evaluation visualization with {num_processes} processes")

        vis_topk = self.vis_topk
        vis_tasks = []  # 存储所有可视化任务

        # 收集所有可视化任务
        for scenario in eval_results.keys():
            for dataset_type in eval_results[scenario].keys():
                for metric_type in eval_results[scenario][dataset_type].keys():
                    group_data = eval_results[scenario][dataset_type][metric_type]

                    # 检查是否有values数据
                    if "values" not in group_data or not group_data["values"]:
                        logger.warning(f"No values data for {scenario}/{dataset_type}/{metric_type}")
                        continue

                    values = group_data["values"]
                    sample_count = len(values)

                    # 处理样本数量不足的情况
                    actual_topk = min(vis_topk, sample_count)
                    if actual_topk == 0:
                        continue

                    # 创建文件夹结构
                    vis_out_dir = os.path.join(
                        self._get_export_dir(),
                        f"vis_common/{scenario}/{dataset_type}/{metric_type}",
                    )
                    os.makedirs(vis_out_dir, exist_ok=True)

                    # 获取排序索引
                    sorted_indices = group_data["argsort"]
                    higher_better = group_data.get("higher_better", True)

                    # 获取最好和最差的索引
                    if higher_better:
                        best_indices = sorted_indices[:actual_topk]  # 最高得分（降序排列，所以取前面）
                        worst_indices = sorted_indices[-actual_topk:]  # 最低得分
                        best_label, worst_label = "best", "worst"
                    else:
                        best_indices = sorted_indices[:actual_topk]  # 最低得分（升序排列，所以取前面）
                        worst_indices = sorted_indices[-actual_topk:]  # 最高得分
                        best_label, worst_label = "best", "worst"

                    logger.info(
                        f"Preparing visualization tasks for {scenario}/{dataset_type}/{metric_type}: "
                        f"top {actual_topk} {best_label} and {actual_topk} {worst_label} samples out of {sample_count}"
                    )

                    # 准备最好样本的可视化任务
                    for rank, idx in enumerate(best_indices):
                        sample_id = group_data["ids"][idx]
                        if hasattr(sample_id, "item"):
                            sample_id = sample_id.item()

                        clip_id = None
                        if "clip_ids" in group_data and idx < len(group_data.get("clip_ids", [])):
                            clip_id = group_data["clip_ids"][idx]
                        name_id = clip_id if clip_id is not None else sample_id
                        savename = os.path.join(
                            vis_out_dir, f"{best_label}_rank{rank+1}_id_{name_id}_value{values[idx]:.4f}.mcap"
                        )
                        raw_env = group_data["raw_env"][idx]
                        metric_logs = group_data["metric_logs"][idx]
                        ego_gt_state_polygon = group_data["gt"][idx]
                        ego_state_polygon = group_data["pred"][idx]  # 获取预测轨迹

                        assert len(raw_env) == 1, "raw_env should be a list of length 1"

                        # 从metric_logs中提取可视化所需的log_infos
                        vis_reward_keys = [metric_type]
                        log_infos_for_vis = {
                            k: v
                            for k, v in metric_logs.items()
                            if isinstance(v, (np.ndarray, list, float, int))
                            and k
                            not in [
                                "no_collision",
                                "no_col_exceptrear",
                                "no_col_withstatic",
                                "reward",
                                "mADE",
                                "mFDE",
                                "over_ax",
                                "over_ay",
                                "over_speed",
                                "tld_fault",
                                "brake",
                                "laneline_reward_mean",
                                "roadsign_fault",
                                "min_dis",
                                "navilane_fault",
                                "navilane_good",
                                "gt_mileage",
                                "pred_mileage",
                            ]
                        }

                        # 创建可视化任务
                        vis_task = {
                            "savename": savename,
                            "raw_env": raw_env,
                            "reward_logs": log_infos_for_vis,
                            "ego_gt_state_polygon": ego_gt_state_polygon,
                            "ego_state_polygon": ego_state_polygon,  # 添加预测轨迹
                            "vis_reward_keys": vis_reward_keys,
                            "timestamp_size": self.timestamp_size,
                            "history_size": self.history_size,
                            "dataset_fps": self.dataset_fps,
                        }
                        vis_tasks.append(vis_task)

                    # 准备最差样本的可视化任务
                    for rank, idx in enumerate(worst_indices):
                        sample_id = group_data["ids"][idx]
                        if hasattr(sample_id, "item"):
                            sample_id = sample_id.item()

                        clip_id = None
                        if "clip_ids" in group_data and idx < len(group_data.get("clip_ids", [])):
                            clip_id = group_data["clip_ids"][idx]
                        name_id = clip_id if clip_id is not None else sample_id
                        savename = os.path.join(
                            vis_out_dir, f"{worst_label}_rank{rank+1}_id_{name_id}_value{values[idx]:.4f}.mcap"
                        )
                        raw_env = group_data["raw_env"][idx]
                        metric_logs = group_data["metric_logs"][idx]
                        ego_gt_state_polygon = group_data["gt"][idx]
                        ego_state_polygon = group_data["pred"][idx]  # 获取预测轨迹

                        # 从metric_logs中提取可视化所需的log_infos
                        vis_reward_keys = [metric_type]
                        log_infos_for_vis = {
                            k: v
                            for k, v in metric_logs.items()
                            if isinstance(v, (np.ndarray, list, float, int))
                            and k
                            not in [
                                "no_collision",
                                "no_col_exceptrear",
                                "no_col_withstatic",
                                "reward",
                                "mADE",
                                "mFDE",
                                "over_ax",
                                "over_ay",
                                "over_speed",
                                "tld_fault",
                                "brake",
                                "laneline_reward_mean",
                                "roadsign_fault",
                                "min_dis",
                                "navilane_fault",
                                "navilane_good",
                                "gt_mileage",
                                "pred_mileage",
                            ]
                        }

                        # 创建可视化任务
                        vis_task = {
                            "savename": savename,
                            "raw_env": raw_env,
                            "reward_logs": log_infos_for_vis,
                            "ego_gt_state_polygon": ego_gt_state_polygon,
                            "ego_state_polygon": ego_state_polygon,  # 添加预测轨迹
                            "vis_reward_keys": vis_reward_keys,
                            "timestamp_size": self.timestamp_size,
                            "history_size": self.history_size,
                            "dataset_fps": self.dataset_fps,
                        }
                        vis_tasks.append(vis_task)

        # 使用通用的多进程处理函数
        self._run_multiprocessing_visualization(
            vis_tasks,
            num_processes,
            "common",
            _visualize_single_sample,
        )

        logger.info("Finished multiprocessing common evaluation visualization for all groups")

    def _calculate_reward_statistics(self, eval_results):
        """Calculate reward statistics and aggregate results

        Args:
            eval_results: Evaluation results dict with structure eval_results[scenario][dataset_type][reward_type][data_type]
            reward_types: List of reward types
        """
        for scenario in eval_results.keys():
            reward_list = self.eval_rewards_cfg.eval_rewards_mode[scenario]["reward_list"]
            for dataset_type in eval_results[scenario].keys():
                process_reward_types = ["reward"] + [reward_cfg["type"] for reward_cfg in reward_list]
                for reward_type in process_reward_types:
                    # reward_property = reward_info["property"]

                    # Process both pred and gt data types
                    for eval_type in ["pred", "gt"]:
                        for info_type in self.reward_eval_infos:
                            if info_type in eval_results[scenario][dataset_type][reward_type]:
                                values = eval_results[scenario][dataset_type][reward_type][info_type].get(eval_type, [])
                                if values:
                                    if info_type == "min":
                                        summary_value = min(values)
                                    elif info_type == "max":
                                        summary_value = max(values)
                                    else:
                                        summary_value = np.nanmean(values)
                                    eval_results[scenario][dataset_type][reward_type][
                                        f"{info_type}_{eval_type}_mean"
                                    ] = summary_value

                        # Calculate rewards statistics for each data type
                        rewards_mean = (
                            eval_results[scenario][dataset_type][reward_type].get("mean", {}).get(eval_type, [])
                        )
                        rewards_sum = (
                            eval_results[scenario][dataset_type][reward_type].get("sum", {}).get(eval_type, [])
                        )
                        eval_results[scenario][dataset_type][reward_type][f"all_rewards_count_{eval_type}"] = len(
                            rewards_sum
                        )
                        if rewards_sum and rewards_mean:
                            eval_results[scenario][dataset_type][reward_type][f"argsort_{eval_type}"] = np.argsort(
                                rewards_sum
                            )
                            valid_rewards_count = np.count_nonzero(rewards_sum)
                            valid_rewards_sum = sum(rewards_sum) / (valid_rewards_count + 1e-8)
                            valid_rewards_mean = sum(rewards_mean) / (valid_rewards_count + 1e-8)
                            eval_results[scenario][dataset_type][reward_type][
                                f"valid_rewards_count_{eval_type}"
                            ] = valid_rewards_count
                            eval_results[scenario][dataset_type][reward_type][
                                f"valid_rewards_sum_{eval_type}"
                            ] = valid_rewards_sum
                            eval_results[scenario][dataset_type][reward_type][
                                f"valid_rewards_mean_{eval_type}"
                            ] = valid_rewards_mean

        # Add "ALL" dataset type that combines expert and failure data
        self._create_all_dataset_type(eval_results)

    def _create_all_dataset_type(self, eval_results):
        """Create 'ALL' dataset type by combining expert and failure data

        Args:
            eval_results: Evaluation results dictionary
            reward_types: List of reward types
        """
        for scenario in eval_results.keys():
            reward_list = self.eval_rewards_cfg.eval_rewards_mode[scenario]["reward_list"]
            # Check if both expert and failure exist for this scenario
            available_dataset_types = list(eval_results[scenario].keys())
            if "expert" in available_dataset_types and "failure" in available_dataset_types:
                # Initialize ALL dataset type structure
                if "ALL" not in eval_results[scenario]:
                    eval_results[scenario]["ALL"] = defaultdict(
                        lambda: defaultdict(
                            lambda: {
                                "ids": [],
                                "clip_ids": [],
                                "pred": [],
                                "gt": [],
                                "raw_env": [],
                                "reward_logs_pred": [],
                                "reward_logs_gt": [],
                                **{info_type: {"pred": [], "gt": []} for info_type in self.reward_eval_infos},
                            }
                        )
                    )

                # Combine data from expert and failure
                process_reward_types = ["reward"] + [reward_cfg["type"] for reward_cfg in reward_list]
                for reward_type in process_reward_types:
                    # Get all reward properties from both expert and failure

                    combined_data = {
                        "ids": [],
                        "clip_ids": [],
                        "pred": [],
                        "gt": [],
                        "raw_env": [],
                        "reward_logs_pred": [],
                        "reward_logs_gt": [],
                        **{info_type: {"pred": [], "gt": []} for info_type in self.reward_eval_infos},
                    }

                    # Add expert data if exists
                    if reward_type in eval_results[scenario]["expert"]:
                        expert_data = eval_results[scenario]["expert"][reward_type]
                        for key in combined_data.keys():
                            if key in expert_data and expert_data[key]:
                                if key in self.reward_eval_infos:
                                    # Handle pred and gt data separately
                                    if "pred" in expert_data[key]:
                                        combined_data[key]["pred"].extend(expert_data[key]["pred"])
                                    if "gt" in expert_data[key]:
                                        combined_data[key]["gt"].extend(expert_data[key]["gt"])
                                else:
                                    combined_data[key].extend(expert_data[key])

                    # Add failure data if exists
                    if reward_type in eval_results[scenario]["failure"]:
                        failure_data = eval_results[scenario]["failure"][reward_type]
                        for key in combined_data.keys():
                            if key in failure_data and failure_data[key]:
                                if key in self.reward_eval_infos:
                                    # Handle pred and gt data separately
                                    if "pred" in failure_data[key]:
                                        combined_data[key]["pred"].extend(failure_data[key]["pred"])
                                    if "gt" in failure_data[key]:
                                        combined_data[key]["gt"].extend(failure_data[key]["gt"])
                                else:
                                    combined_data[key].extend(failure_data[key])

                    eval_results[scenario]["ALL"][reward_type] = combined_data
                    # Calculate statistics for combined data
                    for eval_type in ["pred", "gt"]:
                        for info_type in self.reward_eval_infos:
                            values = combined_data[info_type].get(eval_type, [])
                            if values:
                                if info_type == "min":
                                    summary_value = min(values)
                                elif info_type == "max":
                                    summary_value = max(values)
                                else:
                                    summary_value = np.nanmean(values)
                                eval_results[scenario]["ALL"][reward_type][info_type][eval_type] = values
                                eval_results[scenario]["ALL"][reward_type][
                                    f"{info_type}_{eval_type}_mean"
                                ] = summary_value

                        # Calculate rewards statistics for combined data
                        rewards_sum = combined_data["sum"].get(eval_type, [])
                        rewards_mean = combined_data["mean"].get(eval_type, [])
                        if rewards_sum and rewards_mean:
                            eval_results[scenario]["ALL"][reward_type][f"rewards_argsort_{eval_type}"] = np.argsort(
                                rewards_sum
                            )
                            valid_rewards_count = np.count_nonzero(rewards_sum)
                            valid_rewards_sum = sum(rewards_sum) / (valid_rewards_count + 1e-8)
                            valid_rewards_mean = sum(rewards_mean) / (valid_rewards_count + 1e-8)
                            eval_results[scenario]["ALL"][reward_type][
                                f"valid_rewards_count_{eval_type}"
                            ] = valid_rewards_count
                            eval_results[scenario]["ALL"][reward_type][
                                f"valid_rewards_sum_{eval_type}"
                            ] = valid_rewards_sum
                            eval_results[scenario]["ALL"][reward_type][
                                f"valid_rewards_mean_{eval_type}"
                            ] = valid_rewards_mean
                            eval_results[scenario]["ALL"][reward_type][f"all_rewards_count_{eval_type}"] = len(
                                rewards_sum
                            )

                for dataset_type in eval_results[scenario].keys():
                    all_rewards_count_pred = None
                    all_rewards_count_gt = None
                    if "ALL" not in eval_results[scenario][dataset_type]:
                        eval_results[scenario][dataset_type]["ALL"] = defaultdict()
                    # Get all reward count from reward_types for both pred and gt
                    final_valid_rewards_count_pred = None
                    final_valid_rewards_count_gt = None

                    for reward_type in eval_results[scenario][dataset_type].keys():

                        if reward_type == "ALL":
                            continue

                        # Process pred data
                        rewards_sum_pred = eval_results[scenario][dataset_type][reward_type]["sum"].get("pred", [])
                        if rewards_sum_pred:
                            rewards_sum_pred = np.array(rewards_sum_pred)
                            if final_valid_rewards_count_pred is None:
                                final_valid_rewards_count_pred = rewards_sum_pred != 0
                                all_rewards_count_pred = eval_results[scenario][dataset_type][reward_type].get(
                                    "all_rewards_count_pred", 0
                                )
                            else:
                                final_valid_rewards_count_pred = np.bitwise_or(
                                    final_valid_rewards_count_pred != 0, rewards_sum_pred != 0
                                )

                        # Process gt data
                        rewards_sum_gt = eval_results[scenario][dataset_type][reward_type]["sum"].get("gt", [])
                        if rewards_sum_gt:
                            rewards_sum_gt = np.array(rewards_sum_gt)
                            if final_valid_rewards_count_gt is None:
                                final_valid_rewards_count_gt = rewards_sum_gt != 0
                                all_rewards_count_gt = eval_results[scenario][dataset_type][reward_type].get(
                                    "all_rewards_count_gt", 0
                                )
                            else:
                                final_valid_rewards_count_gt = np.bitwise_or(
                                    final_valid_rewards_count_gt != 0, rewards_sum_gt != 0
                                )

                    # Set combined statistics for pred
                    if all_rewards_count_pred is not None:
                        eval_results[scenario][dataset_type]["ALL"]["all_rewards_count_pred"] = all_rewards_count_pred
                    if final_valid_rewards_count_pred is not None:
                        eval_results[scenario][dataset_type]["ALL"][
                            "valid_rewards_count_pred"
                        ] = final_valid_rewards_count_pred.sum()

                    # Set combined statistics for gt
                    if all_rewards_count_gt is not None:
                        eval_results[scenario][dataset_type]["ALL"]["all_rewards_count_gt"] = all_rewards_count_gt
                    if final_valid_rewards_count_gt is not None:
                        eval_results[scenario][dataset_type]["ALL"][
                            "valid_rewards_count_gt"
                        ] = final_valid_rewards_count_gt.sum()

                    # Identify IDs whose penalty-type rewards all have sum == 0 when all reward_types are penalties
                    # 1) Determine reward types present for this dataset_type and their properties
                    present_reward_types = [
                        rt for rt in eval_results[scenario][dataset_type].keys() if rt not in ["ALL", "reward"]
                    ]
                    if dataset_type == "ALL" and len(present_reward_types) > 0:
                        # Build a mapping from reward type -> property from reward_list
                        reward_type_to_property = {}
                        for rinfo in reward_list:
                            reward_type_to_property[rinfo["type"]] = rinfo.get("property", None)

                        all_penalty = all(
                            reward_type_to_property.get(rt, None) == "penalty" for rt in present_reward_types
                        )
                        if all_penalty:
                            # 2) Find positions where all penalty reward_type sums are in failure data
                            zero_mask_all = None
                            for rt in present_reward_types:
                                sums = eval_results[scenario]["failure"][rt].get("sum", [])
                                sums_np = np.array(sums)
                                cur_zero_mask = sums_np == 0
                                if zero_mask_all is None:
                                    zero_mask_all = cur_zero_mask
                                else:
                                    zero_mask_all = np.logical_and(zero_mask_all, cur_zero_mask)
                            if zero_mask_all is not None and zero_mask_all.size > 0:
                                zero_indices = np.where(zero_mask_all)[0].tolist()
                                eval_results[scenario][dataset_type]["penalty_all_zero_indices"] = zero_indices

    def _display_eval_results_with_prettytable(self, eval_results):
        """Display multi-level evaluation results using prettytable

        Args:
            eval_results: Evaluation results dictionary
            reward_types: List of reward types
        """
        logger.info("=" * 100)
        logger.info("Comprehensive Evaluation Results Report")
        logger.info("=" * 100)

        # Display unified comprehensive results table
        self._display_comprehensive_results(eval_results)

        # Display pred vs gt comparison table
        self._display_pred_gt_comparison_table(eval_results)

    def _display_comprehensive_results(self, eval_results):
        """Display comprehensive results table with global, scenario, and detailed levels"""
        # Create unified table with all dimensions as columns
        table = PrettyTable()
        table.field_names = (
            ["Level", "Scenario", "Reward Type", "Dataset Type", "Reward Property"]
            + self.reward_eval_infos
            + ["Clip_Count", "Valid_Count", "Valid_Percent", "Valid_Sum", "Valid_Mean"]
        )

        # 1. Add global aggregated results
        global_data = defaultdict(lambda: defaultdict(list))
        for scenario in eval_results.keys():
            reward_list = self.eval_rewards_cfg.eval_rewards_mode[scenario]["reward_list"]
            for dataset_type in eval_results[scenario].keys():
                for reward_info in reward_list:
                    reward_type = reward_info["type"]
                    reward_property = reward_info["property"]
                    for info_type in self.reward_eval_infos:
                        # 只使用gt数据，pred仅作为记录
                        mean_key = f"{info_type}_gt_mean"
                        if mean_key in eval_results[scenario][dataset_type][reward_type]:
                            global_data[dataset_type][info_type].append(
                                eval_results[scenario][dataset_type][reward_type][mean_key]
                            )

        # Add global rows for each dataset type
        all_dataset_types = set()
        for scenario in eval_results.keys():
            all_dataset_types.update(eval_results[scenario].keys())

        for dataset_type in sorted(all_dataset_types):
            global_row = ["GLOBAL", "ALL", "ALL", dataset_type, "ALL"]
            for info_type in self.reward_eval_infos:
                if info_type in global_data[dataset_type] and global_data[dataset_type][info_type]:
                    values = global_data[dataset_type][info_type]
                    if info_type == "min":
                        summary_value = min(values)
                    elif info_type == "max":
                        summary_value = max(values)
                    else:
                        summary_value = np.nanmean(values)
                    global_row.append(f"{summary_value:.6f}")
                else:
                    global_row.append("N/A")

            # Add placeholder for rewards statistics (not meaningful at global level)
            global_row.extend(["N/A", "N/A", "N/A", "N/A", "N/A"])
            table.add_row(global_row)

        # 2. Add scenario-level aggregated results
        scenario_data = {}
        for scenario in eval_results.keys():
            scenario_data[scenario] = defaultdict(lambda: defaultdict(list))
            reward_list = self.eval_rewards_cfg.eval_rewards_mode[scenario]["reward_list"]
            for dataset_type in eval_results[scenario].keys():
                for reward_info in reward_list:
                    reward_type = reward_info["type"]
                    reward_property = reward_info["property"]
                    for info_type in self.reward_eval_infos:
                        # 只使用gt数据，pred仅作为记录
                        mean_key = f"{info_type}_gt_mean"
                        if mean_key in eval_results[scenario][dataset_type][reward_type]:
                            scenario_data[scenario][dataset_type][info_type].append(
                                eval_results[scenario][dataset_type][reward_type][mean_key]
                            )
                scenario_data[scenario][dataset_type]["ALL"] = defaultdict()
                for key in eval_results[scenario][dataset_type]["ALL"].keys():
                    scenario_data[scenario][dataset_type]["ALL"][key] = eval_results[scenario][dataset_type]["ALL"][key]

        # Add scenario-level rows
        for scenario in sorted(scenario_data.keys()):
            for dataset_type in sorted(all_dataset_types):
                if dataset_type in scenario_data[scenario]:
                    row = ["SCENARIO", scenario, "ALL", dataset_type, "ALL"]
                    for info_type in self.reward_eval_infos:
                        if (
                            info_type in scenario_data[scenario][dataset_type]
                            and scenario_data[scenario][dataset_type][info_type]
                        ):
                            value = np.nanmean(scenario_data[scenario][dataset_type][info_type])
                            row.append(f"{value:.6f}")
                        else:
                            row.append("N/A")

                    # Add placeholder for rewards statistics (not meaningful at scenario level)
                    # Add count (只使用gt数据，pred仅作为记录)
                    if (
                        "all_rewards_count_gt" in scenario_data[scenario][dataset_type]["ALL"]
                        and "valid_rewards_count_gt" in scenario_data[scenario][dataset_type]["ALL"]
                    ):
                        count_all = scenario_data[scenario][dataset_type]["ALL"]["all_rewards_count_gt"]
                        row.append(str(count_all))
                        count_valid = scenario_data[scenario][dataset_type]["ALL"]["valid_rewards_count_gt"]
                        row.append(str(count_valid))
                        count_percent = count_valid / count_all
                        row.append(str(count_percent))
                        row.append(str("N/A"))
                        row.append(str("N/A"))
                    else:
                        row.append(str("N/A"))
                        row.append(str("N/A"))
                        row.append(str("N/A"))
                        row.append(str("N/A"))
                        row.append(str("N/A"))

                    table.add_row(row)

        # 3. Add detailed results (original detailed level)
        for scenario in sorted(eval_results.keys()):
            reward_list = self.eval_rewards_cfg.eval_rewards_mode[scenario]["reward_list"]
            for reward_info in reward_list:
                reward_type = reward_info["type"]
                reward_property = reward_info["property"]
                for dataset_type in sorted(eval_results[scenario].keys()):
                    if reward_type in eval_results[scenario][dataset_type]:

                        row = ["DETAILED", scenario, reward_type, dataset_type, reward_property]

                        # Add basic statistics (只使用gt数据，pred仅作为记录)
                        for info_type in self.reward_eval_infos:
                            mean_key = f"{info_type}_gt_mean"
                            if mean_key in eval_results[scenario][dataset_type][reward_type]:
                                value = eval_results[scenario][dataset_type][reward_type][mean_key]
                                row.append(f"{value:.6f}")
                            else:
                                row.append("N/A")

                        # Add count (只使用gt数据，pred仅作为记录)
                        if (
                            "all_rewards_count_gt" in eval_results[scenario][dataset_type][reward_type]
                            and "valid_rewards_count_gt" in eval_results[scenario][dataset_type][reward_type]
                        ):
                            count_all = eval_results[scenario][dataset_type][reward_type]["all_rewards_count_gt"]
                            row.append(str(count_all))
                            count_valid = eval_results[scenario][dataset_type][reward_type]["valid_rewards_count_gt"]
                            row.append(str(count_valid))
                            count_percent = count_valid / count_all
                            row.append(str(count_percent))
                            valid_rewards_sum = eval_results[scenario][dataset_type][reward_type][
                                "valid_rewards_sum_gt"
                            ]
                            row.append(str(valid_rewards_sum))
                            valid_rewards_mean = eval_results[scenario][dataset_type][reward_type][
                                "valid_rewards_mean_gt"
                            ]
                            row.append(str(valid_rewards_mean))
                        else:
                            row.append(str("N/A"))
                            row.append(str("N/A"))
                            row.append(str("N/A"))
                            row.append(str("N/A"))
                            row.append(str("N/A"))

                        table.add_row(row)

        logger.info(f"\n{table}")

    def _make_reward_vis_task(
        self, group_data, idx, vis_out_dir, rank, label, score_value, vis_reward_keys, vis_type="gt"
    ):
        """Build a visualization task dict for multiprocessing reward visualization."""
        sample_id = group_data["ids"][idx]
        if hasattr(sample_id, "item"):
            sample_id = sample_id.item()
        clip_id = "Unknown"
        if "clip_ids" in group_data and idx < len(group_data.get("clip_ids", [])):
            clip_id = group_data["clip_ids"][idx]
        name_id = clip_id if clip_id is not None else sample_id
        savename = os.path.join(
            vis_out_dir, f"{label}_rank{rank+1}_id_{name_id}_reward{score_value:.4f}_{vis_type}.mcap"
        )
        raw_env = group_data["raw_env"][idx]
        reward_logs = group_data[f"reward_logs_{vis_type}"][idx]
        ego_gt_state_polygon = group_data[vis_type][idx]
        vis_task = {
            "savename": savename,
            "raw_env": raw_env,
            "reward_logs": reward_logs,
            "ego_gt_state_polygon": ego_gt_state_polygon,
            "vis_reward_keys": vis_reward_keys,
            "timestamp_size": self.timestamp_size,
            "history_size": self.history_size,
            "dataset_fps": self.dataset_fps,
        }
        return vis_task

    def _collect_penalty_all_zero_tasks(self, eval_results, scenario, dataset_type, vis_topk):
        """Collect vis tasks for penalty_all_zero samples for multiprocessing path.

        Returns a list of vis_task dicts or an empty list if not applicable.
        """
        tasks = []
        # check flags
        zero_info_indices = eval_results[scenario][dataset_type].get("penalty_all_zero_indices", [])
        num_zero_all = len(zero_info_indices)
        if not zero_info_indices:
            return tasks, num_zero_all

        vis_out_dir_zero = os.path.join(
            self._get_export_dir(), f"vis/{scenario}/{dataset_type}/failure_penalty_all_zero"
        )
        os.makedirs(vis_out_dir_zero, exist_ok=True)
        chosen = zero_info_indices[:vis_topk]

        # choose a reference reward_type group's data containers
        rt_keys = [
            k for k in eval_results[scenario][dataset_type].keys() if k not in ["ALL", "penalty_all_zero_indices"]
        ]
        if not rt_keys:
            return tasks, num_zero_all

        ref_group = eval_results[scenario]["failure"][rt_keys[0]]
        vis_reward_keys = [
            *[k for k in eval_results[scenario][dataset_type].keys() if k not in ["ALL", "penalty_all_zero_indices"]],
        ]

        for rank, idx in enumerate(chosen):
            vis_task = self._make_reward_vis_task(
                ref_group, idx, vis_out_dir_zero, rank, "zero", 0.0, vis_reward_keys, vis_type="gt"
            )
            # 修改文件名为 penalty_all_zero 的特殊格式
            clip_id = "Unknown"
            if "clip_ids" in ref_group and idx < len(ref_group.get("clip_ids", [])):
                clip_id = ref_group["clip_ids"][idx]
            vis_task["savename"] = os.path.join(vis_out_dir_zero, f"zero_rank{rank+1}_id_{clip_id}.mcap")
            tasks.append(vis_task)

        return tasks, num_zero_all

    def _display_pred_gt_comparison_table(self, eval_results):
        """Display pred vs gt comparison table for reward_type='reward'"""
        logger.info("=" * 100)
        logger.info("Pred vs GT Comparison Table (reward_type='reward')")
        logger.info("=" * 100)

        # Create comparison table
        table = PrettyTable()
        table.field_names = [
            "Scenario",
            "Dataset Type",
            "GT_Sum",
            "GT_Mean",
            "Pred_Sum",
            "Pred_Mean",
            "Clip_Count",
            "GT >= Pred Count",
            "GT < Pred Count",
        ]

        # Initialize overall statistics collection
        overall_stats = {}  # key: dataset_type, value: {stat_name: [values]}

        # Process each scenario and dataset_type
        for scenario in sorted(eval_results.keys()):
            for dataset_type in sorted(eval_results[scenario].keys()):
                if "reward" not in eval_results[scenario][dataset_type]:
                    continue

                reward_data = eval_results[scenario][dataset_type]["reward"]
                gt_rewards_sum = reward_data.get("sum", {}).get("gt", [])
                gt_rewards_mean = reward_data.get("mean", {}).get("gt", [])
                pred_rewards_sum = reward_data.get("sum", {}).get("pred", [])
                pred_rewards_mean = reward_data.get("mean", {}).get("pred", [])

                # Initialize overall_stats for this dataset_type if not exists
                if dataset_type not in overall_stats:
                    overall_stats[dataset_type] = {
                        "gt_sums": [],
                        "gt_means": [],
                        "pred_sums": [],
                        "pred_means": [],
                        "gt_total_clip_counts": [],
                        "gt_higher_counts": [],
                        "gt_lower_counts": [],
                    }

                # Get gt statistics
                gt_avg_reward_sum = np.nanmean(gt_rewards_sum) if len(gt_rewards_sum) > 0 else "N/A"
                gt_avg_reward_mean = np.nanmean(gt_rewards_mean) if len(gt_rewards_mean) > 0 else "N/A"
                gt_total_clip_count = reward_data.get("all_rewards_count_gt", "N/A")

                # Get pred statistics
                pred_avg_reward_sum = np.nanmean(pred_rewards_sum) if len(pred_rewards_sum) > 0 else "N/A"
                pred_avg_reward_mean = np.nanmean(pred_rewards_mean) if len(pred_rewards_mean) > 0 else "N/A"

                # Calculate comparison counts and record indices
                gt_higher_count = 0
                gt_lower_count = 0
                gt_lower_indices = []  # 记录gt < pred的样本索引

                # Get individual reward sums for comparison
                if gt_rewards_sum and pred_rewards_sum and len(gt_rewards_sum) == len(pred_rewards_sum):
                    for idx, (gt_sum, pred_sum) in enumerate(zip(gt_rewards_sum, pred_rewards_sum)):
                        if gt_sum >= pred_sum:
                            gt_higher_count += 1
                        else:
                            gt_lower_count += 1
                            gt_lower_indices.append(idx)

                # 记录gt_lower_indices到reward_data中，供可视化使用
                if gt_lower_indices:
                    reward_data["gt_lower_indices"] = gt_lower_indices

                # Collect data for overall statistics
                overall_stats[dataset_type]["gt_sums"].extend(gt_rewards_sum)
                overall_stats[dataset_type]["gt_means"].extend(gt_rewards_mean)
                overall_stats[dataset_type]["pred_sums"].extend(pred_rewards_sum)
                overall_stats[dataset_type]["pred_means"].extend(pred_rewards_mean)
                overall_stats[dataset_type]["gt_total_clip_counts"].append(
                    gt_total_clip_count if gt_total_clip_count != "N/A" else 0
                )
                overall_stats[dataset_type]["gt_higher_counts"].append(gt_higher_count)
                overall_stats[dataset_type]["gt_lower_counts"].append(gt_lower_count)

                # Format values for display
                def format_value(value):
                    if value == "N/A":
                        return "N/A"
                    elif isinstance(value, (int, float)):
                        return f"{value:.6f}"
                    else:
                        return str(value)

                # Add row to table
                row = [
                    scenario,
                    dataset_type,
                    format_value(gt_avg_reward_sum),
                    format_value(gt_avg_reward_mean),
                    format_value(pred_avg_reward_sum),
                    format_value(pred_avg_reward_mean),
                    format_value(gt_total_clip_count),
                    str(gt_higher_count),
                    str(gt_lower_count),
                ]
                table.add_row(row)

        # Calculate and add overall statistics at the end
        if overall_stats:
            # Add a separator row
            table.add_row(["-" * 10] * len(table.field_names))

            # Calculate overall statistics for each dataset type
            for dataset_type, data in overall_stats.items():
                # Calculate averages (only for numeric values)
                gt_avg_sum = np.nanmean(data["gt_sums"]) if data["gt_sums"] else "N/A"
                gt_avg_mean = np.nanmean(data["gt_means"]) if data["gt_means"] else "N/A"
                pred_avg_sum = np.nanmean(data["pred_sums"]) if data["pred_sums"] else "N/A"
                pred_avg_mean = np.nanmean(data["pred_means"]) if data["pred_means"] else "N/A"
                total_clip_count = sum(data["gt_total_clip_counts"])
                total_gt_higher = sum(data["gt_higher_counts"])
                total_gt_lower = sum(data["gt_lower_counts"])

                # Format values for display
                def format_value(value):
                    if value == "N/A":
                        return "N/A"
                    elif isinstance(value, (int, float)):
                        return f"{value:.6f}"
                    else:
                        return str(value)

                # Add overall statistics row
                row = [
                    "ALL",
                    dataset_type,
                    format_value(gt_avg_sum),
                    format_value(gt_avg_mean),
                    format_value(pred_avg_sum),
                    format_value(pred_avg_mean),
                    format_value(total_clip_count),
                    str(total_gt_higher),
                    str(total_gt_lower),
                ]
                table.add_row(row)

        logger.info(f"\n{table}")

    def vis_expert_gt_lower_than_pred(self, eval_results):
        """可视化expert数据集中gt reward_sum低于pred reward_sum的样本"""
        logger.info("=" * 100)
        logger.info("Visualizing Expert Dataset: GT Lower Than Pred Samples")
        logger.info("=" * 100)

        # 1. 按场景分别可视化
        logger.info("Processing per-scenario visualization...")
        collected_data = self._collect_expert_gt_lower_than_pred_data(eval_results)

        if collected_data:
            # 可视化每个场景选中的样本
            for (
                scenario,
                reward_data,
                chosen_indices,
                gt_sums,
                pred_sums,
                vis_out_dir,
                vis_reward_keys,
            ) in collected_data:
                for rank, idx in enumerate(chosen_indices):
                    score_diff = pred_sums[rank] - gt_sums[rank]
                    self._vis_reward_sample_single(
                        reward_data, idx, vis_out_dir, "gt_lower_gt", score_diff, vis_reward_keys, rank, vis_type="gt"
                    )
                    self._vis_reward_sample_single(
                        reward_data,
                        idx,
                        vis_out_dir,
                        "gt_lower_pred",
                        score_diff,
                        vis_reward_keys,
                        rank,
                        vis_type="pred",
                    )

                    logger.info(
                        f"Visualized {scenario} sample {rank+1}/{len(chosen_indices)}: "
                        f"Sum(Pred-GT)={score_diff:.4f}"
                    )
        else:
            logger.info("No expert gt_lower_than_pred data to visualize per scenario")

        # 2. 跨场景可视化（不区分scenario）
        logger.info("Processing cross-scenario visualization...")
        cross_scenario_data = self._collect_expert_gt_lower_than_pred_data(eval_results, cross_scenario=True)

        if cross_scenario_data:
            (
                chosen_reward_data,
                chosen_scenarios,
                chosen_indices,
                chosen_gt_sums,
                chosen_pred_sums,
                vis_out_dir,
                vis_reward_keys,
            ) = cross_scenario_data

            # 可视化跨场景选中的样本
            for rank, (reward_data, scenario, idx, gt_sum, pred_sum) in enumerate(
                zip(chosen_reward_data, chosen_scenarios, chosen_indices, chosen_gt_sums, chosen_pred_sums)
            ):
                score_diff = pred_sum - gt_sum
                self._vis_reward_sample_single(
                    reward_data, idx, vis_out_dir, "gt_lower_gt", score_diff, vis_reward_keys, rank, vis_type="gt"
                )
                self._vis_reward_sample_single(
                    reward_data,
                    idx,
                    vis_out_dir,
                    "gt_lower_pred",
                    score_diff,
                    vis_reward_keys,
                    rank,
                    vis_type="pred",
                )

                logger.info(
                    f"Visualized cross-scenario sample {rank+1}/{len(chosen_indices)} ({scenario}): "
                    f"Sum(Pred-GT)={score_diff:.4f}"
                )
        else:
            logger.info("No expert gt_lower_than_pred data to visualize cross scenario")

        logger.info("Finished expert gt_lower_than_pred visualization")

    def _vis_expert_gt_lower_than_pred_multiprocessing(self, eval_results, num_processes=None):
        """使用多进程可视化expert数据集中gt reward_sum低于pred reward_sum的样本"""
        logger.info("=" * 100)
        logger.info("Visualizing Expert Dataset: GT Lower Than Pred Samples (Multiprocessing)")
        logger.info("=" * 100)

        if num_processes is None:
            num_processes = mp.cpu_count()

        vis_tasks = []  # 存储所有可视化任务

        # 1. 按场景分别收集数据
        collected_data = []
        if not self.eval_gt_lower_only_cross:
            logger.info("Processing per-scenario visualization...")
            collected_data = self._collect_expert_gt_lower_than_pred_data(eval_results)

        if collected_data:
            # 为每个场景的选中样本创建可视化任务
            for (
                scenario,
                reward_data,
                chosen_indices,
                gt_sums,
                pred_sums,
                vis_out_dir,
                vis_reward_keys,
            ) in collected_data:
                for rank, idx in enumerate(chosen_indices):
                    # 为gt类型创建任务
                    gt_sum = gt_sums[rank]
                    pred_sum = pred_sums[rank]
                    vis_task_gt = self._make_reward_vis_task(
                        reward_data, idx, vis_out_dir, rank, "gt_lower", gt_sum, vis_reward_keys, vis_type="gt"
                    )
                    vis_tasks.append(vis_task_gt)

                    # 为pred类型创建任务
                    vis_task_pred = self._make_reward_vis_task(
                        reward_data, idx, vis_out_dir, rank, "gt_lower", pred_sum, vis_reward_keys, vis_type="pred"
                    )
                    vis_tasks.append(vis_task_pred)
        else:
            logger.info("No expert gt_lower_than_pred data to visualize per scenario")

        # 2. 跨场景收集数据
        logger.info("Processing cross-scenario visualization...")
        cross_scenario_data = self._collect_expert_gt_lower_than_pred_data(eval_results, cross_scenario=True)

        if cross_scenario_data:
            (
                chosen_reward_data,
                chosen_scenarios,
                chosen_indices,
                chosen_gt_sums,
                chosen_pred_sums,
                vis_out_dir,
                vis_reward_keys,
            ) = cross_scenario_data

            # 为跨场景选中的样本创建可视化任务
            for rank, (reward_data, scenario, idx, gt_sum, pred_sum) in enumerate(
                zip(chosen_reward_data, chosen_scenarios, chosen_indices, chosen_gt_sums, chosen_pred_sums)
            ):
                # 为gt类型创建任务
                vis_task_gt = self._make_reward_vis_task(
                    reward_data, idx, vis_out_dir, rank, "gt_lower", gt_sum, vis_reward_keys, vis_type="gt"
                )
                vis_tasks.append(vis_task_gt)

                # 为pred类型创建任务
                vis_task_pred = self._make_reward_vis_task(
                    reward_data, idx, vis_out_dir, rank, "gt_lower", pred_sum, vis_reward_keys, vis_type="pred"
                )
                vis_tasks.append(vis_task_pred)
        else:
            logger.info("No expert gt_lower_than_pred data to visualize cross scenario")

        # 使用通用的多进程处理函数
        if vis_tasks:
            self._run_multiprocessing_visualization(
                vis_tasks, num_processes, "expert gt_lower_than_pred", _visualize_single_sample
            )
        else:
            logger.info("No expert gt_lower_than_pred visualization tasks to process")

        logger.info("Finished expert gt_lower_than_pred multiprocessing visualization")

    def _collect_expert_gt_lower_than_pred_data(self, eval_results, cross_scenario=False):
        """收集expert gt_lower_than_pred可视化的数据

        Args:
            eval_results: 评估结果
            cross_scenario: 是否进行跨场景收集。False为按场景分别收集，True为跨场景收集

        Returns:
            如果cross_scenario=False: list，包含所有场景的可视化数据的列表，每个元素为 (scenario, reward_data, chosen_indices, gt_sums, pred_sums, vis_out_dir, vis_reward_keys)
            如果cross_scenario=True: tuple，包含跨场景数据的元组 (chosen_reward_data, chosen_scenarios, chosen_indices, chosen_gt_sums, chosen_pred_sums, vis_out_dir, vis_reward_keys)
        """
        vis_topk = self.vis_topk
        if vis_topk <= 0:
            return [] if not cross_scenario else None

        # 收集所有场景的原始数据
        all_scenario_data = []

        for scenario in sorted(eval_results.keys()):
            # 检查是否有expert数据集
            if "expert" not in eval_results[scenario]:
                continue

            expert_data = eval_results[scenario]["expert"]
            if "reward" not in expert_data:
                continue

            reward_data = expert_data["reward"]

            # 获取gt_lower_indices
            gt_lower_indices = reward_data.get("gt_lower_indices", [])
            if not gt_lower_indices:
                if not cross_scenario:
                    logger.info(f"No samples found where GT < Pred for {scenario}/expert/reward")
                continue

            if not cross_scenario:
                logger.info(f"Found {len(gt_lower_indices)} samples where GT < Pred for {scenario}/expert/reward")

            # 获取reward sum数据
            gt_rewards_sum = reward_data.get("sum", {}).get("gt", [])
            pred_rewards_sum = reward_data.get("sum", {}).get("pred", [])

            # 收集该场景的gt_lower数据
            scenario_gt_lower_data = []
            for idx in gt_lower_indices:
                gt_sum = gt_rewards_sum[idx]
                pred_sum = pred_rewards_sum[idx]
                score_diff = pred_sum - gt_sum
                scenario_gt_lower_data.append((idx, gt_sum, pred_sum, score_diff))

            all_scenario_data.append((scenario, expert_data, reward_data, scenario_gt_lower_data))

        if not all_scenario_data:
            if cross_scenario:
                logger.info("No samples found where GT < Pred across all scenarios")
                return None
            else:
                return []

        if cross_scenario:
            # 跨场景模式：合并所有数据并全局排序
            all_gt_lower_data = []
            all_reward_data = []
            all_scenarios = []
            all_indices = []

            for scenario, expert_data, reward_data, scenario_gt_lower_data in all_scenario_data:
                for idx, gt_sum, pred_sum, score_diff in scenario_gt_lower_data:
                    all_gt_lower_data.append((scenario, idx, gt_sum, pred_sum, score_diff))
                    all_reward_data.append(reward_data)
                    all_scenarios.append(scenario)
                    all_indices.append(idx)

            logger.info(f"Found {len(all_gt_lower_data)} samples where GT < Pred across all scenarios")

            # 按score_diffs降序排序，选择top vis_topk个
            all_gt_lower_data.sort(key=lambda x: x[4], reverse=True)
            if not self.eval_gt_lower_only_cross:
                chosen_data = all_gt_lower_data[:vis_topk]
            else:
                chosen_data = all_gt_lower_data[:]

            # 分离数据
            chosen_scenarios = [data[0] for data in chosen_data]
            chosen_indices = [data[1] for data in chosen_data]
            chosen_gt_sums = [data[2] for data in chosen_data]
            chosen_pred_sums = [data[3] for data in chosen_data]
            chosen_reward_data = []
            for scenario in chosen_scenarios:
                # 找到对应场景的reward_data
                for s, rd in zip(all_scenarios, all_reward_data):
                    if s == scenario:
                        chosen_reward_data.append(rd)
                        break

            # 创建可视化输出目录
            vis_out_dir = os.path.join(self._get_export_dir(), "vis/cross_scenario/expert/gt_lower")
            os.makedirs(vis_out_dir, exist_ok=True)

            # 准备可视化奖励键（使用第一个场景的keys）
            if chosen_reward_data:
                expert_data = eval_results[chosen_scenarios[0]]["expert"]
                vis_reward_keys = [k for k in expert_data.keys() if k != "ALL"]
            else:
                vis_reward_keys = []

            return (
                chosen_reward_data,
                chosen_scenarios,
                chosen_indices,
                chosen_gt_sums,
                chosen_pred_sums,
                vis_out_dir,
                vis_reward_keys,
            )

        else:
            # 按场景模式：为每个场景分别处理
            collected_data = []

            for scenario, expert_data, reward_data, scenario_gt_lower_data in all_scenario_data:
                # 按score_diffs降序排序，选择top vis_topk个
                scenario_gt_lower_data.sort(key=lambda x: x[3], reverse=True)  # 按score_diff排序
                chosen_scenario_data = scenario_gt_lower_data[:vis_topk]

                # 分离数据
                chosen_indices = [data[0] for data in chosen_scenario_data]
                gt_sums = [data[1] for data in chosen_scenario_data]
                pred_sums = [data[2] for data in chosen_scenario_data]

                # 创建可视化输出目录
                vis_out_dir = os.path.join(self._get_export_dir(), f"vis/{scenario}/expert/gt_lower")
                os.makedirs(vis_out_dir, exist_ok=True)

                # 准备可视化奖励键
                vis_reward_keys = [k for k in expert_data.keys() if k != "ALL"]

                collected_data.append(
                    (scenario, reward_data, chosen_indices, gt_sums, pred_sums, vis_out_dir, vis_reward_keys)
                )

            return collected_data

    def _run_multiprocessing_visualization(self, vis_tasks, num_processes, task_name, visualize_func):
        """通用的多进程可视化处理函数

        Args:
            vis_tasks: 可视化任务列表
            num_processes: 进程数量
            task_name: 任务名称，用于日志输出
            visualize_func: 可视化函数 (_visualize_single_sample)
            fallback_func: 回退函数，多进程失败时调用
        """
        if not vis_tasks:
            logger.warning(f"No {task_name} visualization tasks to process")
            return

        logger.info(f"Total {task_name} visualization tasks prepared: {len(vis_tasks)}")

        # 使用多进程池处理所有可视化任务
        try:
            # 设置多进程启动方法为spawn以避免CUDA在fork子进程中的问题
            ctx = mp.get_context("spawn")
            with ctx.Pool(processes=num_processes) as pool:
                # 使用imap_unordered来获得进度反馈
                results = []
                for i, result in enumerate(pool.imap_unordered(visualize_func, vis_tasks)):
                    results.append(result)
                    if (i + 1) % 10 == 0 or (i + 1) == len(vis_tasks):
                        logger.info(f"Processed {i + 1}/{len(vis_tasks)} {task_name} visualization tasks")

            # 输出结果统计
            success_count = sum(1 for result in results if "Successfully saved" in result)
            error_count = len(results) - success_count

            logger.info(
                f"{task_name.title()} multiprocessing visualization completed: {success_count} successful, {error_count} errors"
            )

            # 输出错误信息（如果有）
            for result in results:
                if "Error processing" in result:
                    logger.error(result)

        except Exception as e:
            logger.error(f"Error in {task_name} multiprocessing visualization: {str(e)}")
