# -*- coding: utf-8 -*-
"""Astra Planner Metrics Aggregater."""
import json
import logging
import os
from typing import Dict

import numpy as np
import pandas as pd
import torch
import torch.distributed as dist
from torchpilot.utils.file_manager import FileManager
from tqdm import tqdm

from tpp_onemodel.evaluator.metric_on_clip import mass_update
from tpp_onemodel.evaluator.metrics_on_tag import MetricsOnDaTag
from tpp_onemodel.utils.common_utils import timer


VIS = True
logger = logging.getLogger(__name__)


class MetricsAggregater:
    """Metrics Aggregater."""

    def __init__(
        self,
        aggregate_cfg=None,
        eval_common_cfg=None,
        save_dir=None,
    ):
        """Init."""
        self.aggregate_cfg = aggregate_cfg
        self.eval_common_cfg = eval_common_cfg
        self.batch_size = self.eval_common_cfg["batch_size"]
        # self.save_dir = self.aggregate_cfg["save_dir"]
        self.save_dir = save_dir
        if self.save_dir is None:
            self.save_dir = FileManager.get_export_dir()
        self.agent_class_eval = self.aggregate_cfg["agent_class_eval"]
        self.save_single_gpu_scene_metric_dir = os.path.join(self.save_dir, "eval_single_scene_metrics")
        self.save_single_gpu_scene_count_dir = os.path.join(self.save_dir, "eval_single_scene_count")
        self.save_single_gpu_clip_metric_dir = os.path.join(self.save_dir, "eval_single_scene_bad_cases")
        self.save_bad_metric_dir = os.path.join(self.save_dir, "eval_bad_metrics")

        self.key_metrics = dict()
        for key_metric in self.aggregate_cfg["key_metrics"]:
            self.key_metrics[key_metric["tag"]] = key_metric["metrics"]
        self.scene_da_tag_relation = self.aggregate_cfg["scene_da_tag_relation"]

        self.eval_scenes = self.aggregate_cfg["eval_scenes"]
        if "FullScene" not in self.eval_scenes:
            self.eval_scenes.append("FullScene")
        if self.aggregate_cfg["eval_scenes_agent_type"]:
            self.eval_scenes_agent_type = self.aggregate_cfg["eval_scenes_agent_type"]
            self.eval_scenes += list(self.eval_scenes_agent_type.keys())
        self.scene_eval_infos: Dict[str, MetricsOnDaTag] = dict()
        for scene in self.eval_scenes:
            if scene not in self.scene_eval_infos:
                self.scene_eval_infos[scene] = MetricsOnDaTag(
                    tag_name=scene,
                    common_metrics=self.aggregate_cfg["common_metrics"],
                    key_metrics=self.key_metrics.get(scene, None),
                    special_metrics=self.aggregate_cfg["special_metrics"].get(scene, None),
                    save_clip_id=True,
                )

    def scene_level_update(self, metric_results, metrics_input):
        """Update scene level metrics."""
        da_tags_list = metrics_input["tags"]
        subclip_id_list = np.array(metrics_input["subclip_ids"])
        timestamp_list = np.array(metrics_input["timestamp"])[:, -1]
        batch_agent_valid_mask = metrics_input["non_padding_mask"]
        eval_scenes_list = []
        for batch_idx in range(len(da_tags_list)):
            # da_tags = [list(f.values())[0] for f in da_tags_list[batch_idx]["objs"]]
            da_tags = da_tags_list[batch_idx]
            da_scenes = [
                self.scene_da_tag_relation[da_tag] for da_tag in da_tags if da_tag in self.scene_da_tag_relation
            ]
            da_scenes += self.eval_scenes_agent_type
            eval_scenes = set(da_scenes) & set(self.eval_scenes)
            eval_scenes.add("FullScene")
            eval_scenes_list.append(eval_scenes)
            for scene in eval_scenes:
                self.scene_eval_infos[scene].update_tag_cnt()

        for metric_name, metric_res in metric_results.items():
            if metric_res is None or metric_res[0] is None:
                continue
            else:
                if metric_name in [
                    "marginal/agent/prior_precision_based_recall",
                    "marginal/agent/track_recall_based_precision",
                ]:
                    od_prior_pred = metric_res[0]
                    od_prior_gt_map = metric_res[1]
                    recall_thr = metric_res[2]
                    for batch_idx in range(len(od_prior_pred)):
                        metric_item = {metric_name: (od_prior_pred[batch_idx], od_prior_gt_map[batch_idx], recall_thr)}
                        eval_scenes = eval_scenes_list[batch_idx]
                        for scene in eval_scenes:
                            self.scene_eval_infos[scene].update(
                                metric_item, clip_id=subclip_id_list[batch_idx], timestamp=timestamp_list[batch_idx]
                            )
                elif metric_name in [
                    "marginal/agent/prior_precision",
                    "marginal/agent/prior_recall",
                    "marginal/agent/track_precision",
                    "marginal/agent/track_recall",
                ]:
                    metric_val_default = metric_res[0]
                    metric_cnt_default = metric_res[1]
                    for batch_idx in range(len(metric_val_default)):
                        metric_item = {metric_name: (metric_val_default[batch_idx], metric_cnt_default[batch_idx])}
                        eval_scenes = eval_scenes_list[batch_idx]
                        for scene in eval_scenes:
                            self.scene_eval_infos[scene].update(
                                metric_item, clip_id=subclip_id_list[batch_idx], timestamp=timestamp_list[batch_idx]
                            )
                else:
                    metric_val_orig = metric_res[0]  # [32, 1] or [32, D]
                    metric_cnt_orig = metric_res[1]  # [32, 1] or [32, D]

                    metric_val_default = metric_res[0]
                    metric_cnt_default = metric_res[1]
                    # squeeze last dimension
                    has_multiple_metric_target = metric_val_orig.shape[1] != 1
                    if has_multiple_metric_target:
                        batch_metric_mask = torch.logical_and(batch_agent_valid_mask, metric_cnt_orig)
                        metric_val_default = torch.mul(metric_val_orig, batch_metric_mask).sum(-1)
                        metric_cnt_default = batch_metric_mask.sum(-1)

                    for batch_idx in range(len(metric_cnt_orig)):
                        # default metric_item
                        if not metric_cnt_default[batch_idx].item():
                            continue
                        metric_item = {
                            metric_name: (metric_val_default[batch_idx].item(), metric_cnt_default[batch_idx].item())
                        }
                        eval_scenes = eval_scenes_list[batch_idx]
                        for scene in eval_scenes:
                            # if is agent related metric, 细分
                            if metric_name.startswith("marginal/agent/") and has_multiple_metric_target:
                                if scene in self.eval_scenes_agent_type.keys():
                                    agent_valid_mask = batch_agent_valid_mask[batch_idx]
                                    metric_valid_mask = metric_cnt_orig[batch_idx]
                                    tgt_agent_mask = (
                                        metrics_input["bboxes"][batch_idx, -1, :, 7].unsqueeze(-1)
                                        == torch.tensor(
                                            self.eval_scenes_agent_type[scene], device=metrics_input["bboxes"].device
                                        )
                                    ).any(-1)

                                    mask_all = agent_valid_mask * metric_valid_mask * tgt_agent_mask
                                    valid_cnt_all = mask_all.sum().item()
                                    if not valid_cnt_all:
                                        continue
                                    metric_val_pred = (metric_val_orig[batch_idx] * mask_all).sum().item()
                                    metric_item = {metric_name: (metric_val_pred, valid_cnt_all)}

                            self.scene_eval_infos[scene].update(
                                metric_item, clip_id=subclip_id_list[batch_idx], timestamp=timestamp_list[batch_idx]
                            )

    def tensor_to_json(self, obj):
        """tensor_to_json."""
        if isinstance(obj, torch.Tensor):
            return obj.tolist()  # 标量变 float，张量变 list
        elif isinstance(obj, dict):
            return {k: self.tensor_to_json(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self.tensor_to_json(v) for v in obj]
        else:
            return obj  # 其他类型直接返回

    def _dump_single_eval_metrics(self, results):
        """Dump single gpu eval metrics."""
        save_dir = os.path.join(self.save_dir, "eval_single_metrics")
        os.makedirs(save_dir, exist_ok=True)
        save_path = os.path.join(save_dir, f"eval_single_metrics_{dist.get_rank()}.json")
        with open(save_path, "w") as f_id:
            json.dump(results, f_id, indent=4)

    def _dump_single_scene_eval_metrics(self, scene_name, scene_eval_info):
        """Dump single gpu eval metrics."""
        scene_metrics, scene_bad_cases = scene_eval_info.export_result()
        scene_metrics = self.tensor_to_json(scene_metrics)
        scene_bad_cases = self.tensor_to_json(scene_bad_cases)

        save_dir = self.save_single_gpu_scene_metric_dir
        os.makedirs(save_dir, exist_ok=True)
        scene_metrics_save_path = os.path.join(
            save_dir, f"eval_single_scene_metrics_{scene_name}_{dist.get_rank()}.json"
        )
        with open(scene_metrics_save_path, "w") as f_id:
            json.dump(scene_metrics, f_id, indent=4)

        save_dir = self.save_single_gpu_scene_count_dir
        os.makedirs(save_dir, exist_ok=True)
        scene_count_save_path = os.path.join(save_dir, f"eval_single_scene_count_{scene_name}_{dist.get_rank()}.json")
        with open(scene_count_save_path, "w") as f_id:
            f_id.write(str(scene_eval_info.tag_cnt))
        f_id.close()

        save_dir = self.save_single_gpu_clip_metric_dir
        os.makedirs(save_dir, exist_ok=True)
        scene_bad_cases_save_path = os.path.join(
            save_dir, f"eval_single_scene_bad_cases_{scene_name}_{dist.get_rank()}.json"
        )
        with open(scene_bad_cases_save_path, "w") as f_id:
            json.dump(scene_bad_cases, f_id, indent=4)
        f_id.close()
        scene_eval_info.reset()

    def _load_scene_and_clip_eval_metrics(self):
        """Save results."""
        scene_eval_metrics = dict()
        scene_save_dir = self.save_single_gpu_scene_metric_dir
        scene_eval_count = dict()
        scene_count_save_dir = self.save_single_gpu_scene_count_dir
        clip_eval_metrics = dict()
        clip_save_dir = self.save_single_gpu_clip_metric_dir
        for scene_name in self.scene_eval_infos:
            # scene_metrics
            scene_eval_metrics_list = []
            scene_dumps_names = [file_name for file_name in os.listdir(scene_save_dir) if scene_name in file_name]
            scene_dumps_names = sorted(
                scene_dumps_names,
                key=lambda x: int(x.split(".")[0].split("_")[-1]),
            )
            for dumps_name in tqdm(scene_dumps_names):
                dump_path = os.path.join(scene_save_dir, dumps_name)
                with open(dump_path, "r") as f_id:
                    eval_metrics = json.load(f_id)
                    scene_eval_metrics_list.append(eval_metrics)
                f_id.close()
            scene_eval_metrics[scene_name] = scene_eval_metrics_list

            # scene_count
            scene_count_list = []
            scene_count_dumps_names = [
                file_name for file_name in os.listdir(scene_count_save_dir) if scene_name in file_name
            ]
            scene_count_dumps_names = sorted(
                scene_count_dumps_names,
                key=lambda x: int(x.split(".")[0].split("_")[-1]),
            )
            for dumps_name in tqdm(scene_count_dumps_names):
                dump_path = os.path.join(scene_count_save_dir, dumps_name)
                with open(dump_path, "r") as f_id:
                    scene_count = int(f_id.read())
                    scene_count_list.append(scene_count)
                f_id.close()
            scene_eval_count[scene_name] = scene_count_list

            # clip
            clip_eval_metrics_list = []
            clip_dumps_names = [file_name for file_name in os.listdir(clip_save_dir) if scene_name in file_name]
            clip_dumps_names = sorted(
                clip_dumps_names,
                key=lambda x: int(x.split(".")[0].split("_")[-1]),
            )
            for dumps_name in tqdm(clip_dumps_names):
                dump_path = os.path.join(clip_save_dir, dumps_name)
                with open(dump_path, "r") as f_id:
                    eval_metrics = json.load(f_id)
                    clip_eval_metrics_list.append(eval_metrics)
                f_id.close()
            clip_eval_metrics[scene_name] = clip_eval_metrics_list

        return scene_eval_metrics, scene_eval_count, clip_eval_metrics

    @staticmethod
    def cal_metrics_avg(metrics_list):
        """Calculate avg evaluation metrics."""
        aggregated_data = {}
        for metric_dict in metrics_list:
            for key, stats in metric_dict.items():
                if key in [
                    "marginal/agent/prior_precision",
                    "marginal/agent/prior_recall",
                    "marginal/agent/track_precision",
                    "marginal/agent/track_recall",
                    "marginal/agent/prior_precision_based_recall",
                    "marginal/agent/track_recall_based_precision",
                ]:
                    if key not in aggregated_data:
                        aggregated_data[key] = {
                            "sum": torch.zeros_like(torch.tensor(stats["sum"]), dtype=torch.float),
                            "count": torch.zeros_like(torch.tensor(stats["count"]), dtype=torch.float),
                        }
                    aggregated_data[key]["sum"] += torch.tensor(stats["sum"])
                    aggregated_data[key]["count"] += torch.tensor(stats["count"])
                else:
                    if key not in aggregated_data:
                        aggregated_data[key] = {"sum": 0, "count": 0}
                    aggregated_data[key]["sum"] += stats["sum"]
                    aggregated_data[key]["count"] += stats["count"]

        weighted_averages = {}
        for key, aggregated_stats in aggregated_data.items():
            if key in [
                "marginal/agent/prior_precision",
                "marginal/agent/prior_recall",
                "marginal/agent/track_precision",
                "marginal/agent/track_recall",
                "marginal/agent/prior_precision_based_recall",
                "marginal/agent/track_recall_based_precision",
            ]:
                mean = aggregated_stats["sum"] / (
                    aggregated_stats["count"] + torch.ones_like(aggregated_stats["count"]) * 1e-6
                )
            else:
                if aggregated_stats["count"] > 0:
                    mean = aggregated_stats["sum"] / aggregated_stats["count"]
                else:
                    mean = 0
            if isinstance(mean, torch.Tensor):
                mean = mean.tolist()
            weighted_averages[key] = mean
        return weighted_averages

    def sort_bad_case(self, all_bad_clip_res, key_metrics):
        """Sort badcase."""
        res = {}
        if len(all_bad_clip_res) == 0:
            return res
        if len(key_metrics) == 0:
            return res

        # default sort by first metric's average value, decreasing order
        first_metric_name, first_metric_cfg = list(key_metrics.items())[0]
        is_decreasing = (
            first_metric_cfg["sort_method"]["order"] == "dec"
            if first_metric_cfg.get("sort_method") and first_metric_cfg["sort_method"].get("order")
            else True
        )
        sort_attr = (
            first_metric_cfg["sort_method"]["attr"]
            if first_metric_cfg.get("sort_method") and first_metric_cfg["sort_method"].get("attr")
            else "avg"
        )
        default_value = -1e9 if is_decreasing else 1e9

        res = dict(
            sorted(
                all_bad_clip_res.items(),
                reverse=is_decreasing,
                key=lambda item: (
                    default_value
                    if (not item[1].get(first_metric_name)) or (not item[1][first_metric_name].get(sort_attr))
                    else item[1][first_metric_name][sort_attr]
                ),
            )
        )
        return res

    @timer(VIS)
    def multi_node_aggregate(self):
        """Multi node metrics aggregate."""
        for scene_name, scene_eval_info in self.scene_eval_infos.items():
            self._dump_single_scene_eval_metrics(scene_name, scene_eval_info)
        dist.barrier()

        eval_results_all = {}
        if dist.get_rank() == 0:
            scene_eval_metrics, scene_eval_count, clip_eval_metrics = self._load_scene_and_clip_eval_metrics()
            eval_results_all = self.scene_metrics_aggregate(scene_eval_metrics, scene_eval_count)
            self.clip_metrics_aggregate(clip_eval_metrics)
        return eval_results_all

    def scene_metrics_aggregate(self, scene_eval_metrics, scene_eval_count):
        """Scene metrics aggregate."""
        prior_pr_max_length = 0
        precision_based_recall_max_length = 0
        track_pr_max_length = 0
        recall_based_precision_max_length = 0
        for scene_name, scene_metrics in scene_eval_metrics.items():
            for metric_dict in scene_metrics:
                if (
                    "marginal/agent/prior_precision" in list(metric_dict.keys())
                    and len(torch.tensor(metric_dict["marginal/agent/prior_precision"]["sum"]).shape) > 0
                ):
                    prior_pr_max_length = max(
                        prior_pr_max_length, torch.tensor(metric_dict["marginal/agent/prior_precision"]["sum"]).shape[0]
                    )
                    prior_pr_max_length = max(
                        prior_pr_max_length, torch.tensor(metric_dict["marginal/agent/prior_recall"]["sum"]).shape[0]
                    )
                if (
                    "marginal/agent/track_precision" in list(metric_dict.keys())
                    and len(torch.tensor(metric_dict["marginal/agent/track_precision"]["sum"]).shape) > 0
                ):
                    track_pr_max_length = max(
                        track_pr_max_length, torch.tensor(metric_dict["marginal/agent/track_precision"]["sum"]).shape[0]
                    )
                    track_pr_max_length = max(
                        track_pr_max_length, torch.tensor(metric_dict["marginal/agent/track_recall"]["sum"]).shape[0]
                    )
                if (
                    "marginal/agent/prior_precision_based_recall" in list(metric_dict.keys())
                    and len(torch.tensor(metric_dict["marginal/agent/prior_precision_based_recall"]["sum"]).shape) > 0
                ):
                    precision_based_recall_max_length = max(
                        precision_based_recall_max_length,
                        torch.tensor(metric_dict["marginal/agent/prior_precision_based_recall"]["sum"]).shape[0],
                    )
                if (
                    "marginal/agent/track_recall_based_precision" in list(metric_dict.keys())
                    and len(torch.tensor(metric_dict["marginal/agent/track_recall_based_precision"]["sum"]).shape) > 0
                ):
                    recall_based_precision_max_length = max(
                        recall_based_precision_max_length,
                        torch.tensor(metric_dict["marginal/agent/track_recall_based_precision"]["sum"]).shape[0],
                    )
        for scene_name, scene_metrics in scene_eval_metrics.items():
            for scene_index, metric_dict in enumerate(scene_metrics):
                if (
                    "marginal/agent/prior_precision" in list(metric_dict.keys())
                    and len(torch.tensor(metric_dict["marginal/agent/prior_precision"]["sum"]).shape) == 0
                    and prior_pr_max_length > 0
                ):
                    scene_eval_metrics[scene_name][scene_index]["marginal/agent/prior_precision"]["sum"] = torch.zeros(
                        [prior_pr_max_length]
                    )
                    scene_eval_metrics[scene_name][scene_index]["marginal/agent/prior_precision"][
                        "count"
                    ] = torch.zeros([prior_pr_max_length])
                    scene_eval_metrics[scene_name][scene_index]["marginal/agent/prior_precision"]["mean"] = torch.zeros(
                        [prior_pr_max_length]
                    )
                if (
                    "marginal/agent/prior_recall" in list(metric_dict.keys())
                    and len(torch.tensor(metric_dict["marginal/agent/prior_recall"]["sum"]).shape) == 0
                    and prior_pr_max_length > 0
                ):
                    scene_eval_metrics[scene_name][scene_index]["marginal/agent/prior_recall"]["sum"] = torch.zeros(
                        [prior_pr_max_length]
                    )
                    scene_eval_metrics[scene_name][scene_index]["marginal/agent/prior_recall"]["count"] = torch.zeros(
                        [prior_pr_max_length]
                    )
                    scene_eval_metrics[scene_name][scene_index]["marginal/agent/prior_recall"]["mean"] = torch.zeros(
                        [prior_pr_max_length]
                    )
                if (
                    "marginal/agent/prior_recall" in list(metric_dict.keys())
                    and len(torch.tensor(metric_dict["marginal/agent/prior_recall"]["sum"]).shape) == 0
                    and prior_pr_max_length > 0
                ):
                    scene_eval_metrics[scene_name][scene_index]["marginal/agent/prior_recall"]["sum"] = torch.zeros(
                        [prior_pr_max_length]
                    )
                    scene_eval_metrics[scene_name][scene_index]["marginal/agent/prior_recall"]["count"] = torch.zeros(
                        [prior_pr_max_length]
                    )
                    scene_eval_metrics[scene_name][scene_index]["marginal/agent/prior_recall"]["mean"] = torch.zeros(
                        [prior_pr_max_length]
                    )
                if (
                    "marginal/agent/track_recall" in list(metric_dict.keys())
                    and len(torch.tensor(metric_dict["marginal/agent/track_recall"]["sum"]).shape) == 0
                    and track_pr_max_length > 0
                ):
                    scene_eval_metrics[scene_name][scene_index]["marginal/agent/track_recall"]["sum"] = torch.zeros(
                        [track_pr_max_length]
                    )
                    scene_eval_metrics[scene_name][scene_index]["marginal/agent/track_recall"]["count"] = torch.zeros(
                        [track_pr_max_length]
                    )
                    scene_eval_metrics[scene_name][scene_index]["marginal/agent/track_recall"]["mean"] = torch.zeros(
                        [track_pr_max_length]
                    )
                if (
                    "marginal/agent/track_precision" in list(metric_dict.keys())
                    and len(torch.tensor(metric_dict["marginal/agent/track_precision"]["sum"]).shape) == 0
                    and track_pr_max_length > 0
                ):
                    scene_eval_metrics[scene_name][scene_index]["marginal/agent/track_precision"]["sum"] = torch.zeros(
                        [track_pr_max_length]
                    )
                    scene_eval_metrics[scene_name][scene_index]["marginal/agent/track_precision"][
                        "count"
                    ] = torch.zeros([track_pr_max_length])
                    scene_eval_metrics[scene_name][scene_index]["marginal/agent/track_precision"]["mean"] = torch.zeros(
                        [track_pr_max_length]
                    )
                if (
                    "marginal/agent/prior_precision_based_recall" in list(metric_dict.keys())
                    and len(torch.tensor(metric_dict["marginal/agent/prior_precision_based_recall"]["sum"]).shape) == 0
                    and precision_based_recall_max_length > 0
                ):
                    scene_eval_metrics[scene_name][scene_index]["marginal/agent/prior_precision_based_recall"][
                        "sum"
                    ] = torch.zeros([precision_based_recall_max_length])
                    scene_eval_metrics[scene_name][scene_index]["marginal/agent/prior_precision_based_recall"][
                        "count"
                    ] = torch.zeros([precision_based_recall_max_length])
                    scene_eval_metrics[scene_name][scene_index]["marginal/agent/prior_precision_based_recall"][
                        "mean"
                    ] = torch.zeros([precision_based_recall_max_length])
                if (
                    "marginal/agent/track_recall_based_precision" in list(metric_dict.keys())
                    and len(torch.tensor(metric_dict["marginal/agent/track_recall_based_precision"]["sum"]).shape) == 0
                    and recall_based_precision_max_length > 0
                ):
                    scene_eval_metrics[scene_name][scene_index]["marginal/agent/track_recall_based_precision"][
                        "sum"
                    ] = torch.zeros([recall_based_precision_max_length])
                    scene_eval_metrics[scene_name][scene_index]["marginal/agent/track_recall_based_precision"][
                        "count"
                    ] = torch.zeros([recall_based_precision_max_length])
                    scene_eval_metrics[scene_name][scene_index]["marginal/agent/track_recall_based_precision"][
                        "mean"
                    ] = torch.zeros([recall_based_precision_max_length])

        eval_results_all = dict()
        for scene_name, scene_metris in scene_eval_metrics.items():
            scene_metris = self.cal_metrics_avg(scene_metris)
            scene_metris["scene_count"] = sum(scene_eval_count[scene_name])
            # if scene_name == "FullScene":
            #     scene_metris["cal_metrics_time"] = self.eval_metrics_time
            #     self.eval_metrics_time = 0
            eval_results_all[scene_name] = scene_metris
        return eval_results_all

    def clip_metrics_aggregate(self, clip_eval_metrics):
        """Clip metrics aggregate."""
        for scene_name, multi_gpu_res_files in clip_eval_metrics.items():
            clip_2_multi_gpu_res_list_map = {}  # clip -> list of dict(metric_name: MetricAttributes)
            for single_gpu_res in multi_gpu_res_files:
                for clip_id, metrics in single_gpu_res.items():
                    if clip_id not in clip_2_multi_gpu_res_list_map.keys():
                        clip_2_multi_gpu_res_list_map.update({clip_id: []})

                    clip_2_multi_gpu_res_list_map[clip_id].append(metrics)

            all_bad_clip_res = {}
            all_bad_metric_res = {}
            for clip_id, multi_gpu_res_list in clip_2_multi_gpu_res_list_map.items():
                aggregated_res, has_bad_metric = mass_update(
                    multi_gpu_res_list,
                    key_metrics=self.key_metrics.get(scene_name, None),
                )
                if not has_bad_metric:
                    continue

                # clip centered
                all_bad_clip_res.update({clip_id: aggregated_res})

                # metric centered
                for metric_name, attrs in aggregated_res.items():
                    if metric_name not in all_bad_metric_res:
                        all_bad_metric_res.update({metric_name: dict()})
                    all_bad_metric_res[metric_name].update({clip_id: attrs})

            key_metrics = self.key_metrics.get(scene_name, None)
            bad_clip_res_to_save = self.sort_bad_case(all_bad_clip_res, key_metrics)
            bad_metric_res_to_save = all_bad_metric_res

            # save clip centered result as json
            bad_clip_save_dir = os.path.join(self.save_single_gpu_clip_metric_dir, "aggregated")
            os.makedirs(bad_clip_save_dir, exist_ok=True)
            if bad_clip_res_to_save:
                scene_bad_clip_save_path = os.path.join(
                    bad_clip_save_dir, f"eval_single_scene_bad_clip_{scene_name}_all.json"
                )
                with open(scene_bad_clip_save_path, "w") as f_id:
                    json.dump(bad_clip_res_to_save, f_id, indent=4)

            # save metric centered result as json
            bad_metric_scene_save_dir = os.path.join(self.save_bad_metric_dir, f"{scene_name}")
            os.makedirs(bad_metric_scene_save_dir, exist_ok=True)
            if bad_metric_res_to_save:
                scene_bad_metric_save_path = os.path.join(
                    bad_metric_scene_save_dir, f"eval_single_scene_bad_metric_{scene_name}_all.json"
                )
                with open(scene_bad_metric_save_path, "w") as f_id:
                    json.dump(bad_metric_res_to_save, f_id, indent=4)

            # save metric centered result in separated csv files.
            for metric_name, clips_dict in bad_metric_res_to_save.items():
                # move list item to end, for readability
                col_name_move_to_end_list = []
                for clip_id, attrs in clips_dict.items():
                    for attr_name, attr_val in attrs.items():
                        if isinstance(attr_val, list):
                            col_name_move_to_end_list.append(attr_name)
                    break

                df = pd.DataFrame.from_dict(clips_dict, orient="index")
                columns = [
                    col for col in df.columns if col not in col_name_move_to_end_list
                ] + col_name_move_to_end_list
                df = df[columns]
                df.index.name = "Clips"

                # sort
                if metric_name in key_metrics:
                    metric_cfg = key_metrics[metric_name]
                    is_ascending = (
                        metric_cfg["sort_method"]["order"] == "inc"
                        if metric_cfg.get("sort_method") and metric_cfg["sort_method"].get("order")
                        else False
                    )
                    sort_attr = (
                        metric_cfg["sort_method"]["attr"]
                        if metric_cfg.get("sort_method") and metric_cfg["sort_method"].get("attr")
                        else "avg"
                    )
                    if sort_attr in df.columns.tolist():
                        df.sort_values(by=sort_attr, ascending=is_ascending)

                save_path = os.path.join(
                    os.path.join(bad_metric_scene_save_dir, f"{metric_name.replace('/', '_')}.csv")
                )
                df.to_csv(save_path)


if __name__ == "__main__":
    pass
