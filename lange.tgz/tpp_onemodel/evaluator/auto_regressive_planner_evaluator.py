# -*- coding: utf-8 -*-
"""Auto Regressive Planner Evaluator."""

import itertools
import logging
import os
from typing import Any
from typing import Callable
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.distributed as dist
from torchpilot.evaluator.base_evaluator import BaseEvaluator
from torchpilot.utils.file_manager import FileManager

from tpp_onemodel.evaluator.metrics_io_adaptor import MetricsIoAdaptor
from tpp_onemodel.tools.astra_planner.visualization.frame_sample import (
    visualization_filter,
)
from tpp_onemodel.tools.astra_planner.visualization.frame_sample import (
    visualize_single_frame_sample,
)


logger = logging.getLogger(__name__)


def cal_fde(agent_preds: torch.Tensor, agent_gts: torch.Tensor) -> torch.Tensor:
    """Calculate Final Displacement Error (FDE) between predicted and ground truth trajectories.

    Handles invalid trajectories (all zeros) in ground truth and finds last valid point in partial
    trajectories. Returns FDE for each valid agent across all predictions.

    Args:
        agent_preds: Predicted trajectories for multiple agents and predictions.
            shape: (n_preds, n_agents, n_pts, 2)
        agent_gts: Ground truth trajectories for multiple agents.
            shape: (n_agents, n_pts, 2)

    Returns:
        Tensor containing FDE distances for each valid agent and prediction.
            shape: (n_preds, n_valid_agents)

    Note:
        - Invalid agents (all-zero ground truth) are filtered from output
        - For partial trajectories, uses last non-zero point in ground truth
    """
    # Filter out invalid agents with all-zero ground truth trajectories
    mask_valid = (agent_gts != 0).any(dim=1).any(dim=1)  # shape: (n_agents,)
    valid_indices = torch.where(mask_valid)[0]  # shape: (n_valid_agents,)
    n_valid_agents = valid_indices.size(0)

    if n_valid_agents == 0:
        return torch.empty(agent_preds.size(0), 0, device=agent_preds.device)

    # Extract valid subset of data
    agent_gts_valid = agent_gts[valid_indices]  # shape: (n_valid_agents, n_pts, 2)
    agent_preds_valid = agent_preds[:, valid_indices, :, :]  # shape: (n_preds, n_valid_agents, n_pts, 2)

    # Find last valid point index for each ground truth trajectory
    non_zero_mask = (agent_gts_valid != 0).any(dim=2)  # shape: (n_valid_agents, n_pts)
    # Reverse and find first True occurrence to get last valid index
    flipped = torch.flip(non_zero_mask, dims=[1])  # shape: (n_valid_agents, n_pts)
    first_true_rev = flipped.int().argmax(dim=1)  # shape: (n_valid_agents,)
    last_indices = (non_zero_mask.size(1) - 1) - first_true_rev  # shape: (n_valid_agents,)

    # Extract ground truth endpoints
    gt_endpoints = agent_gts_valid[
        torch.arange(n_valid_agents, device=agent_gts_valid.device), last_indices, :
    ]  # shape: (n_valid_agents, 2)

    # Gather corresponding predicted endpoints
    # Expand indices for broadcasting: (1, n_valid_agents, 1, 1) -> (n_preds, n_valid_agents, 1, 2)
    index = last_indices.view(1, n_valid_agents, 1, 1).expand(
        agent_preds_valid.size(0), -1, -1, 2
    )  # shape: (n_preds, n_valid_agents, 1, 2)
    pred_endpoints = torch.gather(agent_preds_valid, dim=2, index=index).squeeze(
        2
    )  # shape: (n_preds, n_valid_agents, 2)

    # Calculate L2 distance between endpoints
    diff = pred_endpoints - gt_endpoints.unsqueeze(0)  # shape: (n_preds, n_valid_agents, 2)
    fdes = torch.norm(diff, p=2, dim=-1)  # shape: (n_preds, n_valid_agents)

    return fdes


def cal_ade(agent_preds: torch.Tensor, agent_gts: torch.Tensor) -> torch.Tensor:
    """Calculate Average Displacement Error (ADE) between predicted and ground truth trajectories.

    Handles invalid trajectories (all zeros) in ground truth and computes average over valid points.
    Returns ADE for each valid agent across all predictions.

    Args:
        agent_preds: Predicted trajectories for multiple agents and predictions.
            shape: (n_preds, n_agents, n_pts, 2)
        agent_gts: Ground truth trajectories for multiple agents.
            shape: (n_agents, n_pts, 2)

    Returns:
        Tensor containing ADE values for each valid agent and prediction.
            shape: (n_preds, n_valid_agents)

    Note:
        - Invalid agents (all-zero ground truth) are filtered from output
        - For partial trajectories, only valid time steps are considered in average
    """
    # Filter out invalid agents with all-zero ground truth trajectories
    mask_valid = (agent_gts != 0).any(dim=1).any(dim=1)  # shape: (n_agents,)
    valid_indices = torch.where(mask_valid)[0]  # shape: (n_valid_agents,)
    n_valid_agents = valid_indices.size(0)

    if n_valid_agents == 0:
        return torch.empty(agent_preds.size(0), 0, device=agent_preds.device)

    # Extract valid subset of data
    agent_gts_valid = agent_gts[valid_indices]  # shape: (n_valid_agents, n_pts, 2)
    agent_preds_valid = agent_preds[:, valid_indices, :, :]  # shape: (n_preds, n_valid_agents, n_pts, 2)

    # Create validity mask for each timestep (non-zero points)
    non_zero_mask = (agent_gts_valid != 0).any(dim=2)  # shape: (n_valid_agents, n_pts)

    # Calculate point-wise L2 errors
    diff = agent_preds_valid - agent_gts_valid.unsqueeze(0)  # shape: (n_preds, n_valid_agents, n_pts, 2)
    point_errors = torch.norm(diff, p=2, dim=-1)  # shape: (n_preds, n_valid_agents, n_pts)

    # Mask out invalid timesteps and sum errors
    masked_errors = point_errors * non_zero_mask.unsqueeze(0)  # shape: (n_preds, n_valid_agents, n_pts)
    sum_errors = masked_errors.sum(dim=2)  # shape: (n_preds, n_valid_agents)

    # Calculate valid timestep counts and compute average
    valid_counts = non_zero_mask.sum(dim=1).float()  # shape: (n_valid_agents,)
    ades = sum_errors / valid_counts.unsqueeze(0)  # shape: (n_preds, n_valid_agents)

    return ades


class AutoRegressivePlannerEvaluator(BaseEvaluator):
    """Auto regressive planner evaluator."""

    def __init__(
        self,
        adapter_cfg,
        do_eval: bool = False,
        dump_image: bool = False,
        draw_keys=None,
        use_gpu: bool = False,
    ):
        """Initialize evaluator."""
        super().__init__(use_gpu=use_gpu)
        self.do_eval = do_eval
        self.dump_image = dump_image
        self.draw_keys = draw_keys

        self.adapter_cfg = adapter_cfg
        self.metrics_io_adapter = MetricsIoAdaptor("auto_regressive_planner", self.adapter_cfg)

        self.k_values = np.linspace(1, 5, 5, dtype=int)
        self.match_func = cal_fde
        self.thresholds = [0.5, 1.0, 2.0]

        self.gather_all_data: List[Any] = []

        self.export_dir = FileManager.get_export_dir()

    def cal_agents_pr(
        self,
        agent_states: torch.Tensor,
        agent_gt: torch.Tensor,
        batch_mapping: torch.Tensor,
        k_values: np.ndarray,
        match_func: Callable,
        thresholds: List[float],
    ) -> Tuple[np.ndarray, int]:
        """Calculate agent recall metrics across multiple K values.

        Args:
            agent_states: Concatenated predicted trajectories for all samples
                shape: (total_preds, n_agents, n_pts, 2)
            agent_gt: Ground truth trajectories for the batch
                shape: (batch_size, n_agents, n_pts, 2)
            batch_mapping: Batch indices mapping for predictions
                shape: (total_preds,)
            k_values: K values generated by np.linspace for evaluation
                example: np.linspace(1, 5, 5) for K=1,2,3,4,5
            match_func: Matching function (cal_fde, cal_ade, ...)
            thresholds: Success thresholds in meters

        Returns:
            Tuple containing:
            - result_matrix: Hit count matrix with dimensions (thresholds * K values)
                shape: (num_thresholds, num_k_values), dtype=torch.int32
            - total_valid_agents: Total number of valid agents across all samples
        """
        # Device setup
        device = torch.device("cuda")

        # Convert parameters to GPU tensors
        thresholds_t = torch.tensor(sorted(thresholds), device=device, dtype=torch.float32)
        k_values = np.unique(np.round(k_values).astype(int))
        k_tensor = torch.tensor(k_values, device=device, dtype=torch.int32)

        # Initialize result matrix on GPU
        num_thresholds = len(thresholds)
        num_k = len(k_values)
        result_matrix = torch.zeros((num_thresholds, num_k), dtype=torch.int32, device=device)

        # Batch processing
        sample_ids, counts = torch.unique(batch_mapping, return_counts=True)
        agent_preds_split = torch.split(agent_states, counts.tolist(), dim=0)
        total_valid = 0

        for sample_idx in range(len(sample_ids)):
            # Sample data remains on GPU
            n_preds = counts[sample_idx].item()
            preds = agent_preds_split[sample_idx]
            gts = agent_gt[sample_idx]

            # Compute scores on GPU
            scores = match_func(preds, gts)
            num_valid = scores.shape[1]
            total_valid += num_valid

            # Vectorized threshold comparison
            matches = scores.unsqueeze(0) < thresholds_t.view(-1, 1, 1)

            # First hit calculation
            cum_matches = matches.cumsum(dim=1)
            pred_indices = torch.arange(1, n_preds + 1, device=device).view(1, -1, 1)

            first_hit_pos = (
                torch.where(cum_matches > 0, pred_indices.expand_as(cum_matches), n_preds + 1).min(dim=1).values
            )

            # K-value processing
            clamped_k = torch.minimum(k_tensor, torch.tensor(n_preds, device=device))
            hit_matrix = first_hit_pos.unsqueeze(-1) <= clamped_k.view(1, 1, -1)
            result_matrix += hit_matrix.sum(dim=1)

        # Convert final results to NumPy while preserving device data
        return result_matrix.cpu().numpy(), total_valid

    def eval(
        self,
        model_outputs: Dict[str, Any],
        model_inputs: Dict[str, Any],
    ):
        """Implement of Evaluator.

        Args:
            model_outputs (Dict[str, Any]): Model_outputs.
            model_inputs (Dict[str, Any]): Model_inputs, i.e. ground truth.

        Returns:
            Evaluation result.
        """
        cal_metrics_input = self.metrics_io_adapter(model_inputs, model_outputs)

        if self.do_eval:
            agent_states = cal_metrics_input["auto_regressive_planner_output"]["dynamic_states"]["agents"][
                :, :, 15:, :2
            ]  # (5, 64, 35, 2)
            ego_states = cal_metrics_input["auto_regressive_planner_output"]["dynamic_states"]["ego"][
                :, :, 15:, :2
            ]  # (5, 1, 35, 2)
            batch_mapping = cal_metrics_input["auto_regressive_planner_output"]["batch_mapping"]  # (5,)

            agent_gt = cal_metrics_input["agent_trajectory_gt"]  # (1, 64, 35, 2)
            ego_gt = cal_metrics_input["egos_pred_gt"]  # (1, 1, 35, 2)

            agent_k_tp_map, agent_valid_agents = self.cal_agents_pr(
                agent_states,
                agent_gt,
                batch_mapping,
                k_values=self.k_values,
                match_func=self.match_func,
                thresholds=self.thresholds,
            )
            ego_k_tp_map, ego_valid_agents = self.cal_agents_pr(
                ego_states,
                ego_gt,
                batch_mapping,
                k_values=self.k_values,
                match_func=self.match_func,
                thresholds=self.thresholds,
            )
            eval_results = {
                "ego_k_tp_map": ego_k_tp_map,
                "agent_k_tp_map": agent_k_tp_map,
                "ego_valid_agents": ego_valid_agents,
                "agent_valid_agents": agent_valid_agents,
            }

            self.gather_all_data.append(eval_results)

        if self.dump_image:
            batch_sample_for_visualization = visualization_filter(cal_metrics_input, model_outputs)
            dump_folder = os.path.join(FileManager.get_run_dir(), "visualize")
            for frame_sample in batch_sample_for_visualization:
                visualize_single_frame_sample(
                    dump_folder=dump_folder,
                    frame_sample=frame_sample,
                    draw_keys=self.draw_keys,
                )

        return self.gather_all_data

    def dist_all_reduce(
        self,
        eval_results: Dict[str, Any],
    ) -> Optional[Dict[str, Any]]:
        """All reduce by torch.distributed as dist.

        Args:
            eval_results (Dict[Any, Any]): Eval results of all epoch.

        Returns:
            results.
        """
        if not self.do_eval:
            return None

        if dist.get_world_size() > 1:
            all_rank_eval_result_list: List[Any] = [[] for _ in range(dist.get_world_size())]
            dist.barrier()

            if dist.get_rank() == 0:
                logger.info("Gatherring all rank data.")
            dist.all_gather_object(all_rank_eval_result_list, self.gather_all_data)
        else:
            all_rank_eval_result_list = [self.gather_all_data]

        all_rank_eval_result_list = list(itertools.chain(*all_rank_eval_result_list))
        num_thresholds, num_k = all_rank_eval_result_list[0]["ego_k_tp_map"].shape[-2:]

        merged_eval_results = {
            "ego_k_tp_map": np.zeros([num_thresholds, num_k]),
            "agent_k_tp_map": np.zeros([num_thresholds, num_k]),
            "ego_valid_agents": 0,
            "agent_valid_agents": 0,
        }

        for result in all_rank_eval_result_list:
            # Accumulate valid agent counts
            merged_eval_results["ego_k_tp_map"] += result["ego_k_tp_map"]
            merged_eval_results["agent_k_tp_map"] += result["agent_k_tp_map"]
            merged_eval_results["ego_valid_agents"] += result["ego_valid_agents"]
            merged_eval_results["agent_valid_agents"] += result["agent_valid_agents"]

        # Extract local results
        ego_hits = merged_eval_results["ego_k_tp_map"]
        agent_hits = merged_eval_results["agent_k_tp_map"]
        ego_valid = merged_eval_results["ego_valid_agents"]
        agent_valid = merged_eval_results["agent_valid_agents"]

        # Calculate recall rates (handle division by zero)
        def calculate_recall(hits: np.ndarray, valid_count: int) -> np.ndarray:
            """Safely compute recall percentage matrix."""
            # Convert to float for division
            valid = float(valid_count)
            # Use np.divide's where parameter to avoid division by zero
            return np.divide(hits, valid, out=np.zeros_like(hits, dtype=np.float32), where=(valid > 0))

        # Compute recall matrices for ego and agents
        # shape: (num_thresholds, num_k)
        ego_recall = calculate_recall(ego_hits, ego_valid)  # type: ignore[arg-type]
        agent_recall = calculate_recall(agent_hits, agent_valid)  # type: ignore[arg-type]

        metric_results = {
            "ego_recall": ego_recall,
            "agent_recall": agent_recall,
            "ego_hit": ego_hits,
            "agent_hit": agent_hits,
            "ego_valid": ego_valid,
            "agent_valid": agent_valid,
        }

        self.generate_report(metric_results, export_dir=self.export_dir)
        return metric_results

    def set_zero(self):
        """Set init evaluator."""
        self.gather_all_data = []

    def generate_report(self, metric_results: Dict[str, Any], export_dir: str) -> None:
        """Generate comprehensive evaluation report with tables and visualizations.

        Args:
            metric_results: Dictionary containing evaluation metrics:
                - ego_recall: np.ndarray, shape=(num_thresholds, num_k)
                - agent_recall: np.ndarray, shape=(num_thresholds, num_k)
                - ego_hit: np.ndarray, shape=(num_thresholds, num_k)
                - agent_hit: np.ndarray, shape=(num_thresholds, num_k)
                - ego_valid: Total valid ego agents
                - agent_valid: Total valid agents
            export_dir: Output directory path for report files
        """
        # Validate dimension consistency
        assert metric_results["ego_recall"].shape[0] == len(
            self.thresholds
        ), f"Threshold count mismatch: {len(self.thresholds)} vs {metric_results['ego_recall'].shape[0]}"
        assert metric_results["ego_recall"].shape[1] == len(
            self.k_values
        ), f"K-value count mismatch: {len(self.k_values)} vs {metric_results['ego_recall'].shape[1]}"

        # Create output directories
        os.makedirs(export_dir, exist_ok=True)
        fig_dir = os.path.join(export_dir, "figures")
        os.makedirs(fig_dir, exist_ok=True)

        # Build markdown content
        md_content = [
            "# Eval Report of Auto Regressive Planner\n",
            "## Evaluation Configuration\n",
            f"- **Evaluation Metric**: {self.match_func.__name__.upper()}\n",
            f"- **Success Thresholds (m)**: {', '.join(map(str, self.thresholds))}\n",
            f"- **Prediction Horizons (K)**: {', '.join(map(str, self.k_values))}\n",
            "- **Valid Samples**:\n",
            f"  - Ego Vehicles: {metric_results['ego_valid']}\n",
            f"  - Other Agents: {metric_results['agent_valid']}\n\n",
            "## Detailed Results\n",
        ]

        # Generate content for each threshold
        for th_idx, threshold in enumerate(self.thresholds):
            # Generate visualization
            fig_name = f"threshold_{threshold}m_recall.jpg"
            fig_path = os.path.join(fig_dir, fig_name)
            self._plot_recall_curves(
                ego_data=metric_results["ego_recall"][th_idx],
                agent_data=metric_results["agent_recall"][th_idx],
                save_path=fig_path,
                threshold=threshold,
            )

            # Add section header
            md_content.extend(
                [
                    f"### {threshold}m Threshold Results\n",
                    f"![Recall Curves](figures/{fig_name})\n",
                    "#### Numerical Metrics\n",
                    "| K Value | Ego Recall | Agent Recall |\n",
                    "|---------|------------|--------------|\n",
                ]
            )

            # Populate table rows
            for k_idx, k in enumerate(self.k_values):
                ego_rec = metric_results["ego_recall"][th_idx, k_idx]
                agent_rec = metric_results["agent_recall"][th_idx, k_idx]
                md_content.append(f"| {k} | {ego_rec:.6f} | {agent_rec:.6f} |\n")

            md_content.append("\n---\n")

        # Write final report
        report_path = os.path.join(export_dir, "eval_report.md")
        with open(report_path, "w", encoding="utf-8") as f:
            f.writelines(md_content)

    def _plot_recall_curves(
        self, ego_data: np.ndarray, agent_data: np.ndarray, save_path: str, threshold: float
    ) -> None:
        """Generate comparative recall rate visualization.

        Args:
            ego_data: Recall rates for ego vehicles across K values
            agent_data: Recall rates for other agents across K values
            save_path: Full path to save output figure
            threshold: Current success threshold
        """
        plt.figure(figsize=(12, 7))

        # Plot both recall curves with styling
        plt.plot(
            self.k_values, ego_data, marker="o", linestyle="--", linewidth=2, color="#2c7bb6", label="Ego Vehicles"
        )
        plt.plot(
            self.k_values, agent_data, marker="s", linestyle="-.", linewidth=2, color="#d7191c", label="Other Agents"
        )

        # Configure plot elements
        plt.title(f"{self.match_func.__name__.upper()} Metric Recall (Threshold={threshold}m)", fontsize=14, pad=20)
        plt.xlabel("Prediction Horizon (K)", fontsize=12)
        plt.ylabel("Recall Rate (%)", fontsize=12)
        plt.xticks(self.k_values, fontsize=10)
        plt.yticks(fontsize=10)
        plt.ylim(0, 1)
        plt.grid(True, alpha=0.3)

        # Add and style legend
        plt.legend(loc="lower right", frameon=True, fontsize=10, shadow=True)

        # Save high-quality output
        plt.tight_layout()
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
        plt.close()
