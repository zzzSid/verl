# -*- coding: utf-8 -*-
"""Torchpilot Metrics on different property."""
from tpp_onemodel.evaluator.metrics_on_tag import SingleMetric


class MetricsOnProperty:
    """Metrics on Property."""

    def __init__(
        self,
        tag_name="all",
        common_metrics=["agent_mFDE", "ego_mFDE"],
        key_metrics={"mFDE": {"thresh": 1.5, "cmp_method": "larger"}},
        save_clip_id=False,
    ):
        """Initialize."""
        self.tag_name = tag_name
        self.common_metrics = common_metrics
        self.key_metrics = key_metrics
        self.frame_cnt = 0
        self.obs_cnt = 0
        self.save_clip_id = save_clip_id
        self.tag_cnt = 0
        if self.save_clip_id:
            self.clips = dict()  # {clip_id: clip_instance}
        self._init_metric_table()

    def _init_metric_table(self):
        """Init metric table."""
        self.metric_table = dict()
        for metric_name in self.common_metrics:
            self.metric_table[metric_name] = SingleMetric(name=metric_name)

    def update_tag_cnt(self):
        """Update_tag_cnt."""
        self.tag_cnt += 1

    def reset(self):
        """Reset metrics on tag."""
        self.tag_cnt = 0
        self.frame_cnt = 0
        self.obs_cnt = 0
        if self.save_clip_id:
            self.clips = dict()  # {clip_id: clip_instance}
        self._init_metric_table()

    def update(self, metrics, clip_id=None, timestamp=None):
        """For single frame/agent_level update."""
        pass

    def export_result(self):
        """Export metrics, counts, clip list."""
        pass
