# -*- coding: utf-8 -*-
import copy
from typing import Any
from typing import Dict

import numpy as np
import torch


class MetricsIoAdaptor:
    """Metrics Input Output Adaptor."""

    def __init__(self, enable_task=None, adapter_cfg=None) -> None:
        """Init."""
        self._enable_task = enable_task
        self.adapter_cfg = adapter_cfg
        self._ego_num_pred_frames = self.adapter_cfg["ego_num_pred_frames"]
        self._agent_num_pred_frames = self.adapter_cfg["agent_num_pred_frames"]
        self._k_traj_num = self.adapter_cfg["k_traj_num"]
        self._ego_k_traj_num = self.adapter_cfg["ego_k_traj_num"]
        self._pred_dim = self.adapter_cfg["pred_dim"]
        self._num_pad_box = self.adapter_cfg["num_pad_box"]
        self._num_frame = self.adapter_cfg["num_frame"]
        self._max_guesses = self.adapter_cfg["max_guesses"]
        self._scene_modality = self.adapter_cfg["scene_modality"]
        self._dump_input = adapter_cfg.get("dump_input", None)
        return

    def __call__(self, model_inputs, model_outputs):
        """Call fun."""
        input_res = copy.deepcopy(model_inputs)
        output_res = copy.deepcopy(model_outputs)
        input_res = self.input_adapter(model_inputs, model_outputs, input_res)
        output_res = self.output_adapter(model_inputs, output_res)
        input_res.update(output_res)
        return input_res

    def input_adapter(self, model_inputs, model_outputs, input_res):
        """Input Adaptor."""
        batch_size, num_frame, num_pad_box, _ = input_res["bboxes"].shape
        if "bboxes_asso_gt" in input_res:  # for tracker, TODO: remove, seems useless
            # reshape bboxes_asso_gt and bboxes_asso_weight
            input_res["bboxes_asso_gt"] = input_res["bboxes_asso_gt"].reshape(batch_size, num_pad_box, num_frame)
            input_res["bboxes_asso_weight"] = input_res["bboxes_asso_weight"].reshape(
                batch_size, num_pad_box, num_frame
            )
        padding_masks = model_inputs["bboxes_padding_mask"].reshape((batch_size, num_frame, num_pad_box)).bool()
        non_padding_mask = ~padding_masks[:, -1]
        input_res["non_padding_mask"] = non_padding_mask
        bboxes_pred_mask = self.cal_bboxes_pred_mask(model_inputs, non_padding_mask=None)
        input_res["bboxes_pred_mask"] = bboxes_pred_mask
        input_res["drive_path_gt"] = model_inputs["drive_path"]
        input_res["drive_path_mask"] = model_inputs["drive_path_mask"]

        # use modified egos_pred_mask to overwrite the original one
        # inorder to filter out the invalid navilane data
        return input_res

    def output_adapter(self, model_inputs, output_res):
        """Output Adaptor."""
        if "astra_planner" in self._enable_task:
            batch_size, _, _, _ = output_res["marginal_ego_pred_pos"].shape

            k_marginal_mod_ego = output_res["marginal_ego_pred_pos"].shape[2]
            output_res["sorted_marginal_ego_traj"] = output_res["marginal_ego_pred_pos"].reshape(
                batch_size, 1, k_marginal_mod_ego, self._ego_num_pred_frames, 2
            )
            output_res["sorted_marginal_ego_score"] = output_res["marginal_ego_pred_score"]

            output_res["sorted_marginal_ego_vel"] = output_res["pred_output"]["marginal_output"][
                "ego_pred_vel"
            ].reshape(batch_size, 1, k_marginal_mod_ego, self._ego_num_pred_frames, 2)
            output_res["sorted_marginal_ego_yaw"] = output_res["pred_output"]["marginal_output"][
                "ego_pred_yaw"
            ].reshape(batch_size, 1, k_marginal_mod_ego, self._ego_num_pred_frames, 1)

            output_res["marginal_ego_best_traj"] = output_res["sorted_marginal_ego_traj"][:, :, 0, :, :]  # [B, 1, T, 2]
            output_res["marginal_ego_best_vel"] = output_res["sorted_marginal_ego_vel"][:, :, 0, :, :]  # [B, 1, T, 2]
            output_res["marginal_ego_best_yaw"] = output_res["sorted_marginal_ego_yaw"][:, :, 0, :, :]  # [B, 1, T, 1]

            marginal_ego_min_fde_traj, min_fde_idx = self.cal_min_fde_idx(
                output_res["sorted_marginal_ego_traj"],
                model_inputs["egos_pred_gt"][:, :, : self._ego_num_pred_frames, :],
                model_inputs["egos_pred_mask"][..., : self._ego_num_pred_frames],
            )
            marginal_ego_min_vel = torch.gather(
                output_res["sorted_marginal_ego_vel"].squeeze(1),
                1,
                min_fde_idx.unsqueeze(-1).unsqueeze(-1).expand(-1, -1, self._ego_num_pred_frames, 2),
            ).squeeze(1)

            marginal_ego_min_yaw = torch.gather(
                output_res["sorted_marginal_ego_yaw"].squeeze(1),
                1,
                min_fde_idx.unsqueeze(-1).unsqueeze(-1).expand(-1, -1, self._ego_num_pred_frames, 1),
            ).squeeze(1)

            output_res["marginal_ego_min_fde_traj"] = marginal_ego_min_fde_traj  # [B, 1, T, 2]
            output_res["marginal_ego_min_vel"] = marginal_ego_min_vel  # [B, 1, T, 2]
            output_res["marginal_ego_min_yaw"] = marginal_ego_min_yaw  # [B, 1, T, 1]

        if "prediction" in self._enable_task:
            batch_size, agent_num, k_marginal_mod_agent, _ = output_res["marginal_agent_pred_pos"].shape

            # assume sorted by contract
            output_res["sorted_marginal_agent_traj"] = output_res["marginal_agent_pred_pos"].reshape(
                batch_size, agent_num, k_marginal_mod_agent, self._agent_num_pred_frames, 2
            )
            output_res["sorted_marginal_agent_score"] = output_res["marginal_agent_pred_score"]
            output_res["marginal_agent_best_traj"] = output_res["sorted_marginal_agent_traj"][
                :, :, 0, :, :
            ]  # [B, A, T, 2]
            marginal_agent_min_fde_traj, _ = self.cal_min_fde_idx(
                output_res["sorted_marginal_agent_traj"],
                model_inputs["bboxes_pred_gt"][:, :, : self._agent_num_pred_frames, :],
                model_inputs["bboxes_pred_mask"][..., : self._agent_num_pred_frames],
            )
            output_res["marginal_agent_min_fde_traj"] = marginal_agent_min_fde_traj  # [B, A, T, 2]
            output_res["od_prior_pred"] = output_res["pred_output"]["od_prior_pred"]
            output_res["agent_index"] = output_res["pred_output"]["agent_index"]
            batch_size = marginal_agent_min_fde_traj.shape[0]
            output_res["od_track_pred"] = output_res["pred_output"]["trackable_output"]["trackable_pred"].reshape(
                batch_size, -1
            )

        return output_res

    def reorder_trajectories_core(self, traj_pred, traj_score):
        """Sort traj by score.

        Args:
        traj_pred: [B * A, K, T, 2]
        traj_score: [B * A, K]
        """
        # descened sort
        sorted_indices = torch.argsort(traj_score, dim=1, descending=True)

        A, K, T, _ = traj_pred.shape  # noqa: N806
        sorted_traj = traj_pred[torch.arange(A).unsqueeze(1), sorted_indices]
        sorted_score = traj_score[torch.arange(A).unsqueeze(1), sorted_indices]

        return sorted_traj, sorted_score

    def cal_min_fde_idx(self, sorted_pred, gt, mask):
        """Get traj with min fde with GT.

        Args:
        sorted_pred: [B, A, K, 30, 2]
        gt: [B, A, 30, 2]
        mask: [B, A, 30]
        """
        assert len(sorted_pred.shape) == 5
        assert len(gt.shape) == 4
        assert len(mask.shape) == 3
        batch_size, agent_num, mod_num, pred_num, ft_len = sorted_pred.shape

        batch_indices = torch.arange(batch_size * agent_num)
        final_idx = torch.sum(mask, dim=2, dtype=torch.int64) - 1
        final_idx = final_idx.reshape(batch_size * agent_num)

        sorted_pred = sorted_pred.reshape(batch_size * agent_num, mod_num, pred_num, 2)  # [B * A, 6, 30, 2]
        gt_expanded = (
            gt.unsqueeze(2).expand(-1, -1, mod_num, -1, -1).reshape(batch_size * agent_num, mod_num, pred_num, 2)
        )  # [B * A, 6, 30, 2]

        de_xy = (
            sorted_pred[batch_indices, :, final_idx, :] - gt_expanded[batch_indices, :, final_idx, :]
        )  # [B*A, 6, 1, 2]

        de = de_xy[:, :, 0] ** 2 + de_xy[:, :, 1] ** 2
        min_fde_idx = torch.argmin(de, dim=1)

        min_fde_idx = min_fde_idx.view(-1, 1)
        min_fde_traj = torch.gather(
            sorted_pred,
            1,
            min_fde_idx.unsqueeze(-1).unsqueeze(-1).expand(-1, -1, pred_num, 2),
        )  # .squeeze(1)

        min_fde_traj = min_fde_traj.reshape(batch_size, agent_num, pred_num, 2)

        return min_fde_traj, min_fde_idx  # [B, A, T, 2]

    def cal_bboxes_pred_mask(self, model_inputs, non_padding_mask):
        """Cal bboxes pred mask."""
        if "asso_index" in model_inputs:
            selected_index = model_inputs["asso_index"]
            asso_index_valid = selected_index.bool().sum(-1)
            invalid_asso_mask = (asso_index_valid < 3).float()
        else:
            if non_padding_mask is None:
                invalid_asso_mask = ((1 - model_inputs["bboxes_padding_mask"]).sum(1) < 3).float()
            else:
                invalid_asso_mask = ((1 - model_inputs["bboxes_padding_mask"].transpose(1, 0)).sum(1) < 3).float()
        bboxes_pred_mask = model_inputs["bboxes_pred_mask"] * (1 - invalid_asso_mask.unsqueeze(-1))
        return (
            bboxes_pred_mask
            if non_padding_mask is None
            else bboxes_pred_mask[non_padding_mask][:, : self._agent_num_pred_frames]
        )

    # pylint: disable=too-many-locals, too-many-branches, too-many-statements
    def gen_dump_pkl_info(
        self,
        model_inputs: Dict[str, Any],
        model_outputs: Dict[str, Any],
    ):
        """Generate dump pkl info."""
        batch_size = model_inputs["bboxes"].shape[0]

        results_list = list()
        for batch_idx in range(batch_size):
            results = {}
            cur_model_inputs: Dict[str, Any] = dict()
            cur_model_outputs: Dict[str, Any] = dict()
            for key, val in model_inputs.items():
                if key == "feature_results":
                    cur_model_inputs[key] = {}
                    for k, v in val.items():
                        cur_model_inputs[key][k] = v[batch_idx].detach().cpu().numpy()
                else:
                    cur_model_inputs[key] = val[batch_idx]

            for key, val in model_outputs.items():
                if key == "pred_output":
                    pred_output = model_outputs["pred_output"]
                    marginal_output = pred_output.get("marginal_output", None)
                    if marginal_output is not None:

                        top1_index = marginal_output["ego_top1_index"][batch_idx]
                        if "ego_pred_vel" in marginal_output:
                            ego_pred_vel = marginal_output["ego_pred_vel"]  # (batch_size, 1, mode, T, 1)
                            cur_model_outputs["ego_pred_vel"] = ego_pred_vel[batch_idx, 0, top1_index, :]

                        if "ego_pred_long_vel" in marginal_output:
                            ego_pred_long_vel = marginal_output["ego_pred_long_vel"]
                            cur_model_outputs["ego_pred_long_vel"] = ego_pred_long_vel[batch_idx, 0, top1_index, :]

                        if "ego_pred_long_acc" in marginal_output:
                            ego_pred_long_acc = marginal_output["ego_pred_long_acc"]
                            cur_model_outputs["ego_pred_long_acc"] = ego_pred_long_acc[batch_idx, 0, top1_index, :]

                        if "ego_pred_yaw" in marginal_output:
                            ego_pred_yaw = marginal_output["ego_pred_yaw"]
                            cur_model_outputs["ego_pred_yaw"] = ego_pred_yaw[batch_idx, 0, top1_index, :]

                        if "ego_pred_yaw_rate" in marginal_output:
                            ego_pred_yaw_rate = marginal_output["ego_pred_yaw_rate"]
                            cur_model_outputs["ego_pred_yaw_rate"] = ego_pred_yaw_rate[batch_idx, 0, top1_index, :]

                    continue
                if val is not None:
                    cur_model_outputs[key] = val[batch_idx]

            padding_bboxes = cur_model_inputs["bboxes"]
            padding_masks = cur_model_inputs["bboxes_padding_mask"].reshape((self._num_frame, self._num_pad_box)).bool()
            slim_bboxes_list = []
            for pad_box, pad_mask in zip(padding_bboxes, padding_masks):
                slim_bboxes_list.append(pad_box[~pad_mask].cpu().numpy())

            non_padding_mask = ~padding_masks[-1]
            if "asso_index" in cur_model_inputs:
                slim_asso_gt = cur_model_inputs["asso_index"][non_padding_mask]
                results.update({"bboxes_asso_gt": slim_asso_gt.cpu().numpy()})  # [M, T]}
            bboxes_pred_mask = self.cal_bboxes_pred_mask(cur_model_inputs, non_padding_mask)
            bboxes_pred_gt = cur_model_inputs["bboxes_pred_gt"][non_padding_mask][:, : self._ego_num_pred_frames]

            pred_traj_output = cur_model_outputs["marginal_agent_pred_pos"]
            pred_traj_output = pred_traj_output.reshape(
                self._num_pad_box,
                self._k_traj_num,
                self._agent_num_pred_frames,
                self._pred_dim,
            )

            pred_coordinates = pred_traj_output[..., :2]
            cur_model_outputs["pred_traj_coor"] = pred_coordinates

            egos = cur_model_inputs["egos"].cpu().numpy()
            egos_padding_mask = cur_model_inputs["egos_padding_mask"].cpu().numpy()
            ego_pred_traj_output = cur_model_outputs["marginal_ego_pred_pos"]
            ego_pred_traj_output = ego_pred_traj_output.reshape(
                1,
                self._ego_k_traj_num * self._scene_modality,
                self._ego_num_pred_frames,
                self._pred_dim,
            )
            ego_pred_coordinates = ego_pred_traj_output[..., :2]
            cur_model_outputs["ego_pred_traj_coor"] = ego_pred_coordinates

            for key, val in cur_model_outputs.items():
                if "ego" in key or "joint_scene_probs" in key or key == "intention_points":
                    cur_model_outputs[key] = val.cpu().numpy()
                elif "navi_line" in key and val is not None:
                    cur_model_outputs[key] = val.cpu().numpy()
                elif val is None:
                    continue
                else:
                    cur_model_outputs[key] = val[non_padding_mask].cpu().numpy()

            # scene_modality = self._k_traj_num * self._scene_modality
            # joint_ego_pred_pos = cur_model_outputs.get("joint_ego_pred_pos", None)
            # if joint_ego_pred_pos is not None:
            #     joint_ego_pred_pos = joint_ego_pred_pos.reshape(1, scene_modality, self._num_pred_frames, 2)
            # joint_agent_pred_pos = cur_model_outputs.get("joint_agent_pred_pos", None)
            # if joint_agent_pred_pos is not None:
            #     joint_agent_pred_pos = joint_agent_pred_pos.reshape(-1, scene_modality, self._num_pred_frames, 2)
            # joint_scene_probs = cur_model_outputs.get("joint_scene_probs", None)

            result = {
                "ids": [cur_model_inputs["ids"]],
                "car_poses": cur_model_inputs["car_poses"].cpu().numpy(),
                "model_outputs": cur_model_outputs,
                "4dgt_bboxes": cur_model_inputs["4dgt_bboxes"],  # current frame gt
                "bboxes": slim_bboxes_list,  # [T of [M, D]]
                "image_bytes": cur_model_inputs.get("image_bytes"),
                "timestamp": cur_model_inputs.get("timestamp"),
                "bboxes_pred_gt": bboxes_pred_gt.cpu().numpy(),  # [n, 30, 2]
                "bboxes_pred_mask": bboxes_pred_mask.cpu().numpy(),  # [n, 30]
                "egos": egos,
                "egos_padding_mask": egos_padding_mask,
                "egos_pred_gt": cur_model_inputs["egos_pred_gt"].cpu().numpy(),
                "tld": cur_model_inputs["tld"].cpu().numpy(),
                "egos_pred_mask": cur_model_inputs["egos_pred_mask"].cpu().numpy(),
                "future_traj_pred": cur_model_outputs["pred_traj_coor"],  # [n, 6, 30, 2]
                "ego_future_traj_pred": cur_model_outputs["ego_pred_traj_coor"],  # [1, 6, 30, 2]
                "lane_points": (
                    cur_model_inputs["lane_points"].cpu().numpy() if "lane_points" in cur_model_inputs else None
                ),
                "lane_types": (
                    cur_model_inputs["lane_types"].cpu().numpy() if "lane_points" in cur_model_inputs else None
                ),
                "scene_type": cur_model_inputs["scene_type"].split("_split_")[0],
                "subclip_id": cur_model_inputs["subclip_ids"],
                # TODO: joint 需要保留，在adviz可视化中需要用到这个接口，将marginal的输出cp到joint key里
                "joint_future_traj_pred": cur_model_outputs["pred_traj_coor"],  # [n,MG,T,2]
                "joint_ego_future_traj_pred": cur_model_outputs["ego_pred_traj_coor"],  # [1,MG,T,2]
                "joint_scene_probs": cur_model_outputs["marginal_ego_pred_score"].squeeze(0),  # [MG]
                "bboxes_info": cur_model_inputs["bboxes"][:, non_padding_mask, :].cpu().numpy(),
                "da_tag": cur_model_inputs["tags"],
                "navi_ego_chosen_idx_k": cur_model_outputs["navi_ego_chosen_idx_k"],
                "navi_line_points": cur_model_outputs["sampled_navi_line_points"],
                "navi_line_types": cur_model_outputs["sampled_navi_line_types"],
                "navi_path_points": cur_model_inputs["navi_path_points"].cpu().numpy(),
                "navi_path_types": cur_model_inputs["navi_path_types"].cpu().numpy(),
                # "navi_line_gt_index": cur_model_outputs.get("navi_line_gt_index", None),
                "origin_bboxes": cur_model_inputs["bboxes"].cpu().numpy(),
                "origin_bboxes_padding_mask": cur_model_inputs["bboxes_padding_mask"].cpu().numpy(),
                "origin_bboxes_pred_gt": cur_model_inputs["bboxes_pred_gt"].cpu().numpy(),  # [n, 30, 2]
                "origin_bboxes_pred_mask": cur_model_inputs["bboxes_pred_mask"].cpu().numpy(),  # [n, 30]
                "atlas": cur_model_inputs["atlas"].cpu().numpy(),
                "sod_poly_pts": cur_model_inputs["sod_poly_pts"].cpu().numpy(),
                "sod_poly_pts_padding_mask": cur_model_inputs["sod_poly_pts_padding_mask"].cpu().numpy(),
                "ego_pred_vel": cur_model_outputs.get("ego_pred_vel", None),
                "ego_pred_long_vel": cur_model_outputs.get("ego_pred_long_vel", None),
                "ego_pred_long_acc": cur_model_outputs.get("ego_pred_long_acc", None),
                "ego_pred_yaw": cur_model_outputs.get("ego_pred_yaw", None),
                "ego_pred_yaw_rate": cur_model_outputs.get("ego_pred_yaw_rate", None),
            }

            if "feature_results" in cur_model_inputs.keys():
                result.update({"feature_results": cur_model_inputs["feature_results"]})

            if self._dump_input:
                cur_model_inputs_np = dict()
                for k, v in cur_model_inputs.items():
                    if torch.is_tensor(v):
                        cur_model_inputs_np[k] = np.copy(v.detach().cpu().numpy())
                    else:
                        cur_model_inputs_np[k] = v
                result.update({"model_inputs": cur_model_inputs_np})
            results.update(result)
            results_list.append(results)
        return results_list
