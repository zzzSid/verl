# -*- coding: utf-8 -*-
"""Astra Planner evaluation similarity metrics."""
import torch
from torch.nn import functional as torch_nn_func


EPS = 1e-6


def cal_prediction_offset(
    predictions,
    bboxes,
):
    """Compute prediction offsets.

    Args:
        predictions: [B, A, K, T_future, 2]
        bboxes: [B, T_past, A, D], D == 40
        A = 1 if ego
    """
    offset = predictions - bboxes[:, -1, :, :2].unsqueeze(2).unsqueeze(2)

    return offset


def cal_scene_similarity(
    bboxes_padding_mask,
    fde_mask,
    ego_offset,
    agent_offset,
    ego_speed,
    agent_speed,
    target="all_point",
    future_num_used=30,
):
    """Compute scene similarity of predictions.

    Args:
        bboxes_padding_mask: [B, T, A]
        fde_mask: [B, 1]
        ego_offset: [B, 1, K, T_future, 2]
        agent_offset: [B, A, K, T_future, 2]
        ego_speed: [B, 1]
        agent_speed: [B, A]
        target: str, either calculate end point or all trajectory waypoints
        future_num_used: int, the num of prediction points used to cal metric
    """
    batch_size = agent_offset.shape[0]
    # total_offset = torch.cat([ego_offset, agent_offset], dim=1)  # [B, 1 + A, K, T, 2]
    total_offset = agent_offset
    total_speed = torch.cat([ego_speed, agent_speed], dim=1)  # [B, 1 + A]
    padding_mask = bboxes_padding_mask[:, -1]
    supplement_mask = torch.ones([batch_size, 1]).to(padding_mask.device)
    total_mask = torch.cat([supplement_mask, 1 - padding_mask], dim=1)  # [B, 1 + A]

    similarity = _cal_similarity(total_offset, total_speed, target, future_num_used)  # [B, 1 + A]
    if similarity is None:
        return None, None

    similarity = (similarity * total_mask).sum(-1) / (total_mask.sum(-1) + EPS)  # [B]

    return similarity.unsqueeze(1), fde_mask  # [B, 1], [B, 1]


def cal_ego_mode_similarity(
    fde_mask,
    ego_offset,
    ego_speed,
    target="all_point",
    future_num_used=30,
):
    """Compute ego mode similarity of predictions.

    Args:
        fde_mask: [B, 1]
        ego_offset: [B, 1, K, T_future, 2]
        target: str, either calculate end point or all trajectory waypoints
        future_num_used: int, the num of prediction points used to cal metric
    """
    similarity = _cal_similarity(ego_offset, ego_speed, target, future_num_used)  # [B, 1]
    if similarity is None:
        return None, None
    return similarity, fde_mask  # [B, 1], [B, 1]


def _cal_similarity(
    offset,
    speed,
    target="all_point",
    future_num_used=30,
):
    """Compute similarity of predictions.

    Args:
        offset: [B, A, K, T_future, 2]
        speed: [B, A]
        target: str, either calculate end point or all trajectory waypoints
        future_num_used: int, the num of prediction points used to cal metric
    """
    if (target != "all_point") and (target != "final_point"):
        raise AssertionError("Must Specify Input Target when calculating Scene Similarity")

    batch_size, agent_num, modality_num, future_step, pred_dim = offset.shape

    speed = speed.view(batch_size, agent_num, 1, 1, 1).expand_as(offset)
    offset = offset / (speed + EPS)

    if future_num_used > future_step:
        return None

    offset = offset.unsqueeze(2).broadcast_to(
        batch_size, agent_num, modality_num, modality_num, future_step, pred_dim
    )  # [B, A, K, K, T, 2]

    if target == "all_point":
        offset = offset[:, :, :, :, :future_num_used, :].view([batch_size, agent_num, modality_num, modality_num, -1])
    else:  # final point
        offset = offset[:, :, :, :, future_num_used - 1, :]

    similarity = torch_nn_func.cosine_similarity(
        offset,
        offset.transpose(2, 3),
        dim=-1,
    )  # [B, A, K, K]

    similarity = torch.reshape(similarity, [batch_size, agent_num, -1]).mean(-1)  # [B, A]

    return similarity  # [B, A]
