# -*- coding: utf-8 -*-
import torch


def compute_ego_circle_positions(ego_traj, egos_size):
    """
    计算自车三个内切圆的圆心位置.

    参数:
    - ego_traj: Tensor, 形状为(batch, num_mode, time_length, 2), 包含自车的轨迹 (x, y)。
    - egos_size: Tensor, 形状为(batch, 2), 包含自车的长度 l 和宽度 w。

    返回:
    - ego_circle_x: Tensor, 形状为(batch, num_mode, time_length, 3), 三个圆心的x坐标。
    - ego_circle_y: Tensor, 形状为(batch, num_mode, time_length, 3), 三个圆心的y坐标。
    """
    ego_l = egos_size[:, 0]  # 自车的长度 l (b, 1)
    ego_w = egos_size[:, 1]  # 自车的宽度 w (b, 1)

    # # 计算自车的heading（基于轨迹点的差分法）
    # diff_x = torch.diff(ego_traj[..., 0], dim=2, prepend=ego_traj[..., 0, :1])
    # diff_y = torch.diff(ego_traj[..., 1], dim=2, prepend=ego_traj[..., 1, :1])
    # heading = torch.atan2(diff_y, diff_x)  # 计算自车的方向角 (b, num_mode, time_length)

    batch_size, num_mode, time_length, _ = ego_traj.shape
    zero_padding = torch.zeros(batch_size, 1, 1, 2, device=ego_traj.device)  # 形状为 (batch, 1, 1, 2)
    padded_traj = torch.cat((zero_padding, ego_traj), dim=2)  # 插入后的形状为 (batch, 1, time_length+1, 2)
    delta = torch.diff(padded_traj, dim=2)  # 计算差分，形状为 (batch, 1, time_length, 2)
    # 计算 heading (以x轴正方向为参考)
    heading = torch.atan2(delta[..., 1], delta[..., 0])  # 形状为 (batch, 1, time_length)

    # 圆的半径
    radius = ego_w.unsqueeze(1).unsqueeze(2) / 2.0  # (b, 1, 1)

    # 计算车头和车尾圆心的位置
    head_offset_x = (ego_l.unsqueeze(1).unsqueeze(2) / 2.0 - ego_w.unsqueeze(1).unsqueeze(2) / 2.0) * torch.cos(
        heading
    )  # (b, num_mode, time_length)
    head_offset_y = (ego_l.unsqueeze(1).unsqueeze(2) / 2.0 - ego_w.unsqueeze(1).unsqueeze(2) / 2.0) * torch.sin(
        heading
    )  # (b, num_mode, time_length)

    tail_offset_x = -head_offset_x  # 车尾的偏移在反方向上
    tail_offset_y = -head_offset_y

    # 计算三个圆心的x和y坐标
    ego_circle_x = torch.stack(
        [
            ego_traj[..., 0],  # 当前轨迹点
            ego_traj[..., 0] + head_offset_x,  # 车头圆心
            ego_traj[..., 0] + tail_offset_x,  # 车尾圆心
        ],
        dim=-1,
    )  # 连接成形状为 (batch, num_mode, time_length, 3)

    ego_circle_y = torch.stack(
        [
            ego_traj[..., 1],  # 当前轨迹点
            ego_traj[..., 1] + head_offset_y,  # 车头圆心
            ego_traj[..., 1] + tail_offset_y,  # 车尾圆心
        ],
        dim=-1,
    )  # 连接成形状为 (batch, num_mode, time_length, 3)

    return ego_circle_x, ego_circle_y, radius


def point_to_segment_dist(px, py, ax, ay, bx, by):
    """计算点(px, py)到线段(ax, ay) - (bx, by)的最小距离."""
    abx = bx - ax
    aby = by - ay
    apx = px - ax
    apy = py - ay
    ab_ap = abx * apx + aby * apy
    ab_ab = abx * abx + aby * aby
    t = torch.clamp(ab_ap / (ab_ab + 1e-6), 0.0, 1.0)
    closest_x = ax + t * abx
    closest_y = ay + t * aby
    dist = torch.sqrt((px - closest_x) ** 2 + (py - closest_y) ** 2)
    return dist


def point_to_segment_dist_sqr(px, py, ax, ay, bx, by):
    """计算点(px, py)到线段(ax, ay) - (bx, by)的最小距离的平方，减少运算."""
    abx = bx - ax
    aby = by - ay
    apx = px - ax
    apy = py - ay
    ab_ap = abx * apx + aby * apy
    ab_ab = abx * abx + aby * aby
    t = torch.clamp(ab_ap / (ab_ab + 1e-6), 0.0, 1.0)
    closest_x = ax + t * abx
    closest_y = ay + t * aby
    dist_sqr = (px - closest_x) ** 2 + (py - closest_y) ** 2
    return dist_sqr


def compute_collision_metric(ego_traj, ego_size, bboxes, bboxes_padding_mask, _collision_thres=0.0):
    """
    计算静态障碍物与自车轨迹的碰撞loss.

    参数:
    - bbox: Tensor, 形状为(batch, t_history, agent_num, 40), 包含障碍物的位置信息。
    - ego_traj: Tensor, 形状为(batch, num_mode, time_length, 2), 包含自车的轨迹。
    - bboxes_padding_mask: Tensor, 形状为(batch, t_history, agent_num), 用于表示无效的障碍物。

    返回:
    - collision_loss: Tensor, 自车轨迹基于静止障碍物的碰撞loss。
    """
    # 参数设置
    batch_size, _, _, _ = bboxes.shape
    _, num_mode, length = ego_traj.shape[1:]
    time_length = length // 2

    ego_traj = ego_traj.reshape(batch_size, num_mode, time_length, 2)

    # 1. 选择当前帧 (t_history = -1) 的障碍物
    current_bbox = bboxes[:, -1, :, :]  # shape: (batch, agent_num, 40)
    current_mask = bboxes_padding_mask[:, -1, :]  # shape: (batch, agent_num)

    # 2. 筛选静止障碍物 (vx, vy < 0.1)
    vx = current_bbox[..., 10]
    vy = current_bbox[..., 11]
    static_mask = (vx.abs() < 0.1) & (vy.abs() < 0.1) & (~current_mask.bool())  # shape: (batch, agent_num)

    # 3. 获取静止障碍物的中心位置和尺寸 (x, y, l, w, heading)
    obstacles_x = current_bbox[..., 0]  # 中心x坐标 (纵向, 对应l)
    obstacles_y = current_bbox[..., 1]  # 中心y坐标 (横向, 对应w)
    obstacles_l = current_bbox[..., 3]  # 长度 l
    obstacles_w = current_bbox[..., 4]  # 宽度 w
    obstacles_heading = current_bbox[..., 6]  # 转向角 heading (弧度制)

    # 计算障碍物的半尺寸
    half_l = obstacles_l / 2
    half_w = obstacles_w / 2

    # 计算障碍物未旋转时的四个顶点相对中心的偏移量
    # 按照顺序计算顶点：top-left, top-right, bottom-right, bottom-left
    offsets = torch.stack(
        [
            torch.stack([-half_l, half_w], dim=-1),  # top-left
            torch.stack([half_l, half_w], dim=-1),  # top-right
            torch.stack([half_l, -half_w], dim=-1),  # bottom-right
            torch.stack([-half_l, -half_w], dim=-1),  # bottom-left
        ],
        dim=-2,
    )  # shape: (batch, agent_num, 4, 2)

    # 计算旋转矩阵
    cos_heading = torch.cos(obstacles_heading)  # (batch, agent_num)
    sin_heading = torch.sin(obstacles_heading)  # (batch, agent_num)

    rotation_matrix = torch.stack(
        [torch.stack([cos_heading, -sin_heading], dim=-1), torch.stack([sin_heading, cos_heading], dim=-1)], dim=-2
    )  # shape: (batch, agent_num, 2, 2)

    # 应用旋转矩阵计算旋转后的顶点位置
    rotated_offsets = torch.matmul(rotation_matrix.unsqueeze(2), offsets.unsqueeze(-1)).squeeze(
        -1
    )  # (batch, agent_num, 4, 2)

    # 将旋转后的偏移量应用到中心位置上, 得到旋转后的顶点位置
    center_positions = torch.stack([obstacles_x, obstacles_y], dim=-1).unsqueeze(-2)  # shape: (batch, agent_num, 1, 2)
    rotated_vertices = center_positions + rotated_offsets  # shape: (batch, agent_num, 4, 2)

    # 分别提取旋转后的顶点的x和y坐标
    top_left_x, top_left_y = rotated_vertices[..., 0, 0], rotated_vertices[..., 0, 1]
    top_right_x, top_right_y = rotated_vertices[..., 1, 0], rotated_vertices[..., 1, 1]
    bottom_right_x, bottom_right_y = rotated_vertices[..., 2, 0], rotated_vertices[..., 2, 1]
    bottom_left_x, bottom_left_y = rotated_vertices[..., 3, 0], rotated_vertices[..., 3, 1]

    # 4. 计算自车轨迹上三个圆心的位置
    ego_x, ego_y, _ = compute_ego_circle_positions(ego_traj, ego_size)
    # 将三个圆心的坐标连接起来以简化计算
    ego_x = ego_x.reshape(batch_size, num_mode, time_length, 3)  # shape: (batch, num_mode, time_length, 3)
    ego_y = ego_y.reshape(batch_size, num_mode, time_length, 3)  # shape: (batch, num_mode, time_length, 3)

    # 5. 计算每个圆心到障碍物4条边的最小距离
    d1 = point_to_segment_dist(
        ego_x.unsqueeze(-2),
        ego_y.unsqueeze(-2),
        top_left_x.unsqueeze(1).unsqueeze(1).unsqueeze(-1),
        top_left_y.unsqueeze(1).unsqueeze(1).unsqueeze(-1),
        top_right_x.unsqueeze(1).unsqueeze(1).unsqueeze(-1),
        top_right_y.unsqueeze(1).unsqueeze(1).unsqueeze(-1),
    )

    d2 = point_to_segment_dist(
        ego_x.unsqueeze(-2),
        ego_y.unsqueeze(-2),
        top_right_x.unsqueeze(1).unsqueeze(1).unsqueeze(-1),
        top_right_y.unsqueeze(1).unsqueeze(1).unsqueeze(-1),
        bottom_right_x.unsqueeze(1).unsqueeze(1).unsqueeze(-1),
        bottom_right_y.unsqueeze(1).unsqueeze(1).unsqueeze(-1),
    )

    d3 = point_to_segment_dist(
        ego_x.unsqueeze(-2),
        ego_y.unsqueeze(-2),
        bottom_right_x.unsqueeze(1).unsqueeze(1).unsqueeze(-1),
        bottom_right_y.unsqueeze(1).unsqueeze(1).unsqueeze(-1),
        bottom_left_x.unsqueeze(1).unsqueeze(1).unsqueeze(-1),
        bottom_left_y.unsqueeze(1).unsqueeze(1).unsqueeze(-1),
    )

    d4 = point_to_segment_dist(
        ego_x.unsqueeze(-2),
        ego_y.unsqueeze(-2),
        bottom_left_x.unsqueeze(1).unsqueeze(1).unsqueeze(-1),
        bottom_left_y.unsqueeze(1).unsqueeze(1).unsqueeze(-1),
        top_left_x.unsqueeze(1).unsqueeze(1).unsqueeze(-1),
        top_left_y.unsqueeze(1).unsqueeze(1).unsqueeze(-1),
    )

    # 找出最小距离
    min_dist = torch.min(torch.min(d1, d2), torch.min(d3, d4))  # shape: (batch, num_mode, time_length, agent_num, 3)
    _, num_mode, time_length, num_agent, circle_num = min_dist.shape

    # 计算侵入距离, 并累计loss
    ego_w = ego_size[:, 1]
    collision_radius = (ego_w / 2.0).unsqueeze(1).unsqueeze(2).unsqueeze(3).unsqueeze(4)  # 形状变为 (batch, 1, 1, 1, 1)
    collision_radius = collision_radius.expand(
        -1, num_mode, time_length, num_agent, circle_num
    )  # 形状变为 (batch, num_mode, time_length, num_agent, circle_num)

    # 减去圆的半径, 计算侵入深度
    penetration_depth_add_thr = _collision_thres + collision_radius - min_dist
    penetration_depth_pos = torch.relu(penetration_depth_add_thr)  # 只保留侵入的部分

    all_collision_loss = penetration_depth_pos

    all_collision_loss_circle_max = torch.max(all_collision_loss, dim=-1)[0]
    all_collision_loss_circle_time_max = torch.max(all_collision_loss_circle_max, dim=2)[0]

    # 仅对静止的障碍物计算loss
    collision_loss = all_collision_loss_circle_time_max * static_mask.unsqueeze(1)
    collision_loss_agent_max = torch.max(collision_loss, dim=2)[0]

    return collision_loss_agent_max


def compute_atlas_collision_loss(atlas, ego_traj_best, ego_size):
    """
    计算Atlas与自车轨迹的碰撞loss.

    参数:
    - Atlas: Tensor, 形状为(batch, t_history, agent_num, 40), 包含障碍物的位置信息。
    - ego_traj: Tensor, 形状为(batch, num_mode, time_length, 2), 包含自车的轨迹。
    - ego_size: Tensor, 形状为(batch, t_history, agent_num), 用于表示无效的障碍物。

    返回:
    - collision_loss: Tensor, 自车轨迹基于静止障碍物的碰撞loss。
    """
    # 参数设置
    # Atlas shape [batch_size, num_poly, num_points, xy+type]
    batch_size, _, _, _ = atlas.shape
    # only take into account the atlas point where the last point type is 1
    atlas_mask1 = (atlas[..., -1] == 1).unsqueeze(-1)  # 【batch, num_poly, num_pts, 1]
    atlas_mask2 = (atlas[..., -1] == 2).unsqueeze(-1)
    atlas_mask = torch.logical_or(atlas_mask1, atlas_mask2)
    # atlas front [batch, num_poly, num_points-1,xy]
    atlas_front = atlas[:, :, :-1, 0:2]
    batch_size, poly_size, seg_size, _ = atlas_front.shape
    # atlas front [batch, num_poly, num_points-1,xy]
    atlas_back = atlas[:, :, 1:, 0:2]
    atlas_front_mask = atlas_mask[:, :, :-1]
    atlas_back_mask = atlas_mask[:, :, 1:]

    # Atlas mask if a complete seg exists
    atlas_mask = atlas_front_mask * atlas_back_mask
    ego_traj_best = ego_traj_best.reshape(batch_size, 1, -1, 2)  # [batch,mode,time,xy]
    ego_traj_best = ego_traj_best[:, :, 1:, :]
    _, _, time_length, _ = ego_traj_best.shape
    ego_x_origin, ego_y_origin, _ = compute_ego_circle_positions(ego_traj_best, ego_size)  # [batch, mode, time, 3]
    # 将三个圆心的坐标连接起来以简化计算
    ego_x = ego_x_origin.reshape(batch_size, 1, time_length * 3, 1).expand(
        -1, -1, -1, poly_size * seg_size
    )  # shape: (batch, num_mode, time_length * 3, poly_size*seg_size)
    ego_y = ego_y_origin.reshape(batch_size, 1, time_length * 3, 1).expand(
        -1, -1, -1, poly_size * seg_size
    )  # shape: (batch, num_mode, time_length * 3, poly_size*seg_size)
    afx = (
        atlas_front[:, :, :, 0].reshape(batch_size, 1, 1, -1).expand(-1, -1, time_length * 3, -1)
    )  # shape: (batch, num_mode, time_length * 3, poly_size*seg_size)
    afy = atlas_front[:, :, :, 1].reshape(batch_size, 1, 1, -1).expand(-1, -1, time_length * 3, -1)
    abx = atlas_back[:, :, :, 0].reshape(batch_size, 1, 1, -1).expand(-1, -1, time_length * 3, -1)
    aby = atlas_back[:, :, :, 1].reshape(batch_size, 1, 1, -1).expand(-1, -1, time_length * 3, -1)
    # dimension becomes batch_size, num_mode, time_length*3, segs
    d1_sqr = point_to_segment_dist_sqr(
        ego_x,
        ego_y,
        afx,
        afy,
        abx,
        aby,
    )
    # batch_size,num_mode,cycles,poly_size, seg_size
    batch_size, num_mode, cycle_num, _ = d1_sqr.shape
    d1_sqr = d1_sqr.reshape(batch_size, num_mode, cycle_num, poly_size, seg_size)
    atlas_mask = atlas_mask.reshape(batch_size, 1, 1, poly_size, seg_size).expand(-1, num_mode, cycle_num, -1, -1)
    # atlas mask shape: [batch_size, num_mode, time_length*3, poly_size, seg_size]
    # # 计算侵入距离, 并累计loss
    ego_w = ego_size[:, 1]
    collision_radius = (ego_w / 2.0).reshape(batch_size, 1, 1, 1, 1)  # 形状变为 (batch, 1, 1, 1, 1)
    collision_radius = collision_radius.expand(
        -1, num_mode, cycle_num, poly_size, seg_size
    )  # 形状变为 (batch, num_mode, cycle_num, poly_size, seg_size)

    # # 减去圆的半径, 计算侵入深度
    penetration_depth_add_thr = collision_radius**2 - d1_sqr
    penetration_depth_pos = torch.relu(penetration_depth_add_thr)  # 只保留侵入的部分
    penetration_depth_pos = penetration_depth_pos * atlas_mask
    all_collision_loss = penetration_depth_pos.reshape(batch_size, num_mode, cycle_num, -1)
    all_collision_loss, poly_seg_index = torch.max(all_collision_loss, dim=-1)  # max over all poly & seg
    all_collision_loss = all_collision_loss.reshape(batch_size, -1)
    all_collision_loss_circle_time_max, circle_time_idx = torch.max(
        all_collision_loss, dim=-1
    )  # max over mode & time, only keep per batch result.
    all_collision_loss_circle_time_max = all_collision_loss_circle_time_max.unsqueeze(-1)
    # if (all_collision_loss_circle_time_max > 0).any():
    #     print(ego_w, all_collision_loss_circle_time_max, poly_seg_index, circle_time_idx,ego_x_origin, ego_y_origin)

    collision_mask = all_collision_loss_circle_time_max > 0.0
    mask = torch.ones_like(collision_mask)
    return collision_mask, mask


def cal_static_agent_collision_metric(
    bboxes,
    bboxes_padding_mask,
    ego_traj_best,
    ego_size,
    get_rate=False,
):
    """Planner static agent loss."""
    ego_traj_best = ego_traj_best[:, :, 0, :, :]
    batch_size, _, time_length, _ = ego_traj_best.shape
    ego_traj_best = ego_traj_best.reshape(batch_size, 1, 1, time_length * 2)

    ego_size = ego_size.squeeze(1)
    orign_metric = compute_collision_metric(ego_traj_best, ego_size, bboxes, bboxes_padding_mask)
    if get_rate:
        metric = orign_metric > 0.0
        mask = torch.ones_like(metric)
    else:
        metric = orign_metric
        mask = metric > 0.0
    return metric, mask


def cal_atlas_collision_metric(
    atlas,
    ego_traj_best,
    ego_size,
):
    """Planner Atlas collision metric."""
    # Input ego_traj_best dim [batch_size, 1, 36(all ego traj?), time_length, 2(xy)]
    # Pick the best traj, current shape [batch_size, 1, 1, time_length, 2]
    ego_traj_best = ego_traj_best[:, :, 0, :, :]
    batch_size, _, time_length, _ = ego_traj_best.shape

    # Becomes [batch_size, 1, 1, time_length * 2]
    ego_traj_best = ego_traj_best.reshape(batch_size, 1, 1, time_length * 2)

    ego_size = ego_size.squeeze(1)
    metric, mask = compute_atlas_collision_loss(atlas, ego_traj_best, ego_size)
    # loss_dict = {"static_agent_collision_loss": loss}
    return metric, mask
