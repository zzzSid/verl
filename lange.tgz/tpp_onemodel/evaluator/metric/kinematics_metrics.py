# -*- coding: utf-8 -*-
"""Astra Planner evaluation kinematics metrics."""
import torch


def cal_ego_velocity_by_traj(trajs, time_interval=0.1):
    """Calculate ego velocity by traj.

    Args:
        trajs: [B, 1, T, 2]
        time_interval: float, time span per point, with second as unit
    """
    velocities = (
        torch.diff(
            trajs,
            dim=2,
        )
        / time_interval
    )
    return torch.norm(velocities, dim=-1)  # [B, 1, T - 1]


def cal_ego_acc_by_velocity(velocity, time_interval=0.1):
    """Calculate ego acc by velocity.

    Args:
        velocity: [B, 1, T]
        time_interval: float, time span per point, with second as unit
    """
    acc = (
        torch.diff(
            velocity,
            dim=2,
        )
        / time_interval
    )

    return acc  # [B, 1, T - 1]


def cal_ego_jerk_by_acc(acc, time_interval=0.1):
    """Calculate ego jerk by acc.

    Args:
        acc: [B, 1, T]
        time_interval: float, time span per point, with second as unit
    """
    jerk = (
        torch.diff(
            acc,
            dim=2,
        )
        / time_interval
    )

    return jerk  # [B, 1, T - 1]


def cal_ego_kinematics_metrics(pred_kinematics, gt_kinematics):
    """Calculate ego kinematics metrics.

    Args:
        pred_kinematics: [B, 1, T]
        gt_kinematics: [B, 1, T]
        kinematics inputs could be velocity/acc/jerk
    """
    diff = torch.abs(pred_kinematics - gt_kinematics)

    metric = diff.mean(-1)  # [B, 1]
    return metric, torch.ones_like(metric)  # [B, 1], [B, 1]
