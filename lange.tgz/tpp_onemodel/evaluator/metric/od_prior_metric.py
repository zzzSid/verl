# -*- coding: utf-8 -*-
import torch


def cal_prior_precision_obs(od_prior_pred, od_prior_gt, agent_index, confidence_thr):
    """cal_prior_precision_obs."""
    agent_index = agent_index.int()
    batch_size = od_prior_pred.shape[0]
    od_prior_gt_map = torch.zeros_like(od_prior_pred)
    for bs_index in range(batch_size):
        od_prior_gt_map[bs_index, :] = od_prior_gt[bs_index, agent_index[bs_index, :]]
    tp_list = []
    pred_prior_list = []
    for confidence_thr_index in confidence_thr:
        prior_pred_mask = od_prior_pred > confidence_thr_index
        prior_gt_mask = od_prior_gt_map == 1
        tp = torch.sum(prior_pred_mask * prior_gt_mask, dim=1, keepdim=True)
        valid_mask = od_prior_gt_map != -1
        prior_pred_mask = prior_pred_mask * valid_mask
        pred_prior = torch.sum(prior_pred_mask, dim=1, keepdim=True)
        tp_list.append(tp)
        pred_prior_list.append(pred_prior)
    return torch.cat(tp_list, dim=1), torch.cat(pred_prior_list, dim=1)


def cal_prior_recall_obs(od_prior_pred, od_prior_gt, agent_index, confidence_thr):
    """cal_prior_recall_obs."""
    agent_index = agent_index.int()
    batch_size = od_prior_pred.shape[0]
    od_prior_gt_map = torch.zeros_like(od_prior_pred)
    for bs_index in range(batch_size):
        od_prior_gt_map[bs_index, :] = od_prior_gt[bs_index, agent_index[bs_index, :]]
    tp_list = []
    pred_prior_list = []
    for confidence_thr_index in confidence_thr:
        prior_pred_mask = od_prior_pred > confidence_thr_index
        prior_gt_mask = od_prior_gt_map == 1
        tp = torch.sum(prior_pred_mask * prior_gt_mask, dim=1, keepdim=True)
        gt_prior = torch.sum(prior_gt_mask, dim=1, keepdim=True)
        tp[gt_prior == 1e-6] = 0
        tp_list.append(tp)
        pred_prior_list.append(gt_prior)
    return torch.cat(tp_list, dim=1), torch.cat(pred_prior_list, dim=1)


def cal_prior_precision_based_recall_obs(od_prior_pred, od_prior_gt, agent_index, recall_thr):
    """cal_prior_precision_based_recall_obs."""
    agent_index = agent_index.int()
    batch_size = od_prior_pred.shape[0]
    od_prior_gt_map = torch.zeros_like(od_prior_pred)
    for bs_index in range(batch_size):
        od_prior_gt_map[bs_index, :] = od_prior_gt[bs_index, agent_index[bs_index, :]]
    return od_prior_pred, od_prior_gt_map, recall_thr
