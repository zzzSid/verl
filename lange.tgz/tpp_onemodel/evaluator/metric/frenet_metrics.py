# -*- coding: utf-8 -*-
"""Astra Planner evaluation frenet metrics."""
import torch


def get_frenet_result(pred_traj, gt_traj, timestamp):
    """Transform Euclidean coordinates to frenet coordinates.

    Args:
        pred_traj (torch.tensor): [B, 1, T, 2]
        gt_traj (torch.tensor): [B, 1, T, 2]
        timestamp: int, the num of pred point used
    """
    batch_size, _, future_step, _ = gt_traj.shape
    if timestamp > future_step:
        return None

    pred_traj = pred_traj.squeeze(1)[:, :timestamp, :]  # [B, T, 2]
    gt_traj = gt_traj.squeeze(1)[:, :timestamp, :]  # [B, T, 2]

    # pad a big value for end point to avoid out of ref path
    end_heading = torch.atan2(gt_traj[:, -1, 1] - gt_traj[:, -2, 1], gt_traj[:, -1, 0] - gt_traj[:, -2, 0])
    end_padded_pos = torch.stack(
        [gt_traj[:, -1, 0] + 1000 * torch.cos(end_heading), gt_traj[:, -1, 1] + 1000 * torch.sin(end_heading)],
        dim=-1,
    )
    gt_traj = torch.cat([gt_traj, end_padded_pos.unsqueeze(1)], dim=1)

    # padding last observation state, and let it be the start point
    start_heading = torch.atan2(gt_traj[:, 1, 1] - gt_traj[:, 0, 1], gt_traj[:, 1, 0] - gt_traj[:, 0, 0])
    start_padded_pos = torch.stack(
        [gt_traj[:, 0, 0] - 1000 * torch.cos(start_heading), gt_traj[:, 0, 1] - 1000 * torch.sin(start_heading)],
        dim=-1,
    )
    gt_traj = torch.cat([start_padded_pos.unsqueeze(1), gt_traj], dim=1)

    seg_x = gt_traj[:, 1:, 0] - gt_traj[:, :-1, 0]
    seg_y = gt_traj[:, 1:, 1] - gt_traj[:, :-1, 1]

    seg_len = torch.sqrt(seg_x**2 + seg_y**2)  # [B, T - 1]

    # if the ego's velocity is less than 1 m/s, the trajectory will be masked
    length_valid = torch.sum(seg_len[:, 1:-1], dim=-1) > 0.1 * pred_traj.shape[1]  # [B]

    # pad for select segment
    accumulate_s = torch.cat([torch.zeros((batch_size, 1), device=gt_traj.device), torch.cumsum(seg_len, dim=1)], dim=1)

    repeat_points = pred_traj.unsqueeze(2).repeat(1, 1, gt_traj.shape[1], 1)  # [B, T, T, 2]
    repeat_lines = gt_traj.unsqueeze(1).repeat(1, pred_traj.shape[1], 1, 1)  # [B, T, T, 2]

    line_to_point_x = repeat_points[:, :, :, 0] - repeat_lines[:, :, :, 0]  # [B, T, T]
    line_to_point_y = repeat_points[:, :, :, 1] - repeat_lines[:, :, :, 1]

    point_distance_square = (repeat_lines[:, :, :, 0] - repeat_points[:, :, :, 0]) ** 2 + (
        repeat_lines[:, :, :, 1] - repeat_points[:, :, :, 1]
    ) ** 2

    p_x = line_to_point_x[:, :, :-1]  # [B, T, T - 1]
    p_y = line_to_point_y[:, :, :-1]

    seg_x = seg_x.unsqueeze(1)
    seg_y = seg_y.unsqueeze(1)

    dot_prod = p_x * seg_x + p_y * seg_y  # [B, T, T - 1]
    # normalize
    ss = dot_prod / (seg_len.unsqueeze(1) + 1e-6)  # [B, T, T - 1]
    foot_is_on_seg = torch.bitwise_and(ss >= 0, ss <= seg_len.unsqueeze(1))

    # if point can't locate in any segment, return false
    valid_trajs = foot_is_on_seg.any(-1).all(-1)  # [B]
    valid_trajs = valid_trajs & length_valid

    cross_prod_len = p_x * seg_y - seg_x * p_y
    l_dist = torch.abs(cross_prod_len / (seg_len.unsqueeze(1) + 1e-6))

    # get lateral distance
    l_dist = torch.where(foot_is_on_seg, l_dist, torch.tensor(1e6, device=l_dist.device))
    foot_dist_idx = torch.argmin(l_dist, dim=2)

    foot_dist = l_dist.gather(2, foot_dist_idx.unsqueeze(-1)).squeeze(-1)
    point_dist_idx = torch.argmin(point_distance_square, dim=2)
    point_dist = torch.sqrt(point_distance_square.gather(2, point_dist_idx.unsqueeze(-1)).squeeze(-1))
    mask = foot_dist < point_dist
    dist_idx = torch.where(mask, foot_dist_idx, point_dist_idx)
    d = torch.where(mask, foot_dist, point_dist)

    s_coord = accumulate_s.gather(1, dist_idx) + ss.gather(2, foot_dist_idx.unsqueeze(-1)).squeeze(-1) * mask
    l_coord = torch.sign(cross_prod_len.gather(2, foot_dist_idx.unsqueeze(-1)).squeeze(-1)) * d

    # s diff between gt and pred
    delta_s = torch.abs(s_coord - accumulate_s[:, 1:-1])
    delta_l = torch.abs(l_coord)
    # mask non valid trajs
    delta_s = delta_s.mean(-1) * valid_trajs  # [B]
    delta_l = delta_l.mean(-1) * valid_trajs

    delta_frenet_metric = (delta_s.unsqueeze(1), delta_l.unsqueeze(1), valid_trajs.unsqueeze(1))

    return delta_frenet_metric


def get_frenet_s_error(fde_mask, delta_frenet_metric):
    """Get frenet s error.

    Args:
        fde_mask: [B, 1]
        delta_frenet_metric: (delta_s, delta_l, valid_mask)
            where:
            delta_s: [B, 1]
            delta_l: [B, 1]
            valid_mask: [B, 1]
    """
    if fde_mask is None or delta_frenet_metric is None:
        return None, None
    return delta_frenet_metric[0], delta_frenet_metric[2] * fde_mask


def get_frenet_l_error(fde_mask, delta_frenet_metric):
    """Get frenet l error.

    Args:
        fde_mask: [B, 1]
        delta_frenet_metric: (delta_s, delta_l, valid_mask)
            where:
            delta_s: [B, 1]
            delta_l: [B, 1]
            valid_mask: [B, 1]
    """
    if fde_mask is None or delta_frenet_metric is None:
        return None, None
    return delta_frenet_metric[1], delta_frenet_metric[2] * fde_mask


# if __name__ == "__main__":
#     ref_path_x = torch.arange(0, 100, 10).unsqueeze(1)
#     ref_path_y = ref_path_x + 10
#     ref_path = torch.concat([ref_path_x, ref_path_y], dim=-1).view(1, 1, -1, 2)
#
#     point_x = torch.arange(5, 55, 5).unsqueeze(1)
#     point_y = point_x * 1.5 - 10
#     points = torch.concat([point_x, point_y], dim=-1).view(1, 1, -1, 2)
#
#     res = get_frenet_displacement_error(points, ref_path)
#     print(res[0])
#     print(res[1])
#     print(res[2])
