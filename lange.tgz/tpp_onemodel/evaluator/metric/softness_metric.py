# -*- coding: utf-8 -*-
import torch


def bicycle_model(state, control, dt, wheel_base):
    """
    Bicycle model dynamics.

    Parameters:
    state (tensor): shape (batch, num_traj, 4) -> (x, y, heading, speed)
    control (tensor): shape (batch, num_traj, 2) -> (acc, steer)
    dt (float): time step
    wheel_base (float): wheelbase of the bicycle model

    Returns:
    tensor: Updated state
    """
    _, _, heading, speed = state[..., 0], state[..., 1], state[..., 2], state[..., 3]
    acc, steer = control[..., 0], control[..., 1]

    cos_heading = torch.cos(heading)
    sin_heading = torch.sin(heading)

    dx = speed * cos_heading
    dy = speed * sin_heading
    dheading = (speed / wheel_base) * torch.tan(steer)
    dspeed = acc
    return torch.stack([dx, dy, dheading, dspeed], dim=-1) * dt


def rk4_step(state, control, dt, wheel_base):
    """
    Perform one RK4 step.

    Parameters:
    state (tensor): shape (batch, 1, num_traj, 4)
    control (tensor): shape (batch, 1, num_traj, 2)
    dt (float): time step
    wheel_base (float): wheelbase of the bicycle model

    Returns:
    tensor: Updated state after one RK4 step
    """
    k1 = bicycle_model(state, control, dt, wheel_base)
    k2 = bicycle_model(state + 0.5 * k1, control, dt, wheel_base)
    k3 = bicycle_model(state + 0.5 * k2, control, dt, wheel_base)
    k4 = bicycle_model(state + k3, control, dt, wheel_base)

    return state + (k1 + 2 * k2 + 2 * k3 + k4) / 6.0


def transform_2_rear(joint_get_egos, bs, wheel_base=2.888):
    """
    Transform state to rear axle representation.

    Parameters:
    joint_get_egos (tensor): Input ego states
    cmd_pred (tensor): Predicted commands
    wheel_base (float): Wheelbase of the bicycle model

    Returns:
    tensor: Transformed initial state
    """
    velocity = torch.sqrt(
        joint_get_egos[:, :, 10] * joint_get_egos[:, :, 10] + joint_get_egos[:, :, 11] * joint_get_egos[:, :, 11]
    )
    velocity = torch.nan_to_num(velocity, nan=0.0)
    init_state = torch.zeros((bs, 1, 4), dtype=joint_get_egos.dtype, device=joint_get_egos.device)
    init_state[:, :, :2] = joint_get_egos[:, :, :2]  # [x, y]
    init_state[:, :, 2] = joint_get_egos[:, :, 6]  # heading
    init_state[:, :, 3] = velocity  # speed, scalar
    init_state = torch.nan_to_num(init_state, nan=0.0)
    cos_init_heading = torch.cos(init_state[..., 2])
    sin_init_heading = torch.sin(init_state[..., 2])

    # Set the initial state values, translate geometric center to real axle
    init_state[..., 0] = init_state[..., 0] - cos_init_heading * wheel_base / 2
    init_state[..., 1] = init_state[..., 1] - sin_init_heading * wheel_base / 2
    return init_state


def transform_2_center(traj, wheel_base=2.888):
    """
    Transform trajectory to center representation.

    Parameters:
    traj (tensor): Trajectory
    wheel_base (float): Wheelbase of the bicycle model

    Returns:
    tensor: Transformed trajectory
    """
    cos_heading = torch.cos(traj[..., 2])
    sin_heading = torch.sin(traj[..., 2])

    # Set the initial state values, translate geometric center to real axle
    traj[..., 0] = traj[..., 0] + cos_heading * wheel_base / 2
    traj[..., 1] = traj[..., 1] + sin_heading * wheel_base / 2
    return traj


def cal_ego_trajectory_rk4(joint_get_egos, cmd_pred, wheel_steering_ratio=16.0, wheel_base=2.888, dt=0.1):
    """
    Estimate the ego vehicle trajectory.

    Parameters:
    joint_get_egos (tensor): Input ego states
    cmd_pred (tensor): Predicted commands  [B, 1, N, T, 2]
    wheel_base (float): Wheelbase of the bicycle model
    dt (float): Time step

    Returns:
    tensor: Estimated trajectory
    """
    joint_get_egos = joint_get_egos.transpose(1, 2)[:, :, -1]  # [B, T, 15]
    batch_size, _, k_traj_num, time_length, _ = cmd_pred.shape

    init_state = transform_2_rear(joint_get_egos, batch_size, wheel_base)
    init_state = init_state.unsqueeze(2).expand(-1, 1, k_traj_num, -1)

    # Initialize trajectory storage tensor (x, y, theta, vel)
    traj = torch.zeros(batch_size, 1, k_traj_num, time_length + 1, 4, device=init_state.device)
    traj[..., 0, :] = init_state  # Store initial state as the first time step

    # Current state
    state = init_state
    for t in range(1, time_length + 1):
        cmd = cmd_pred[..., t - 1, :]
        state_4th = rk4_step(state, cmd, dt, wheel_base)
        state = state_4th
        traj[..., t, :] = state
    traj_center = transform_2_center(traj)  # [B, 1, N, T+1, 4]
    traj_center_without_current = traj_center[:, :, :, 1:, :]  # [B, 1, N, T, 4]

    current_acc = (
        torch.sqrt(
            joint_get_egos[:, :, 12] * joint_get_egos[:, :, 12] + joint_get_egos[:, :, 13] * joint_get_egos[:, :, 13]
        )
        .reshape(batch_size, 1, 1, 1, 1)
        .expand(batch_size, 1, k_traj_num, 1, 1)
    )  # [B, 1, N, 1, 1]
    current_acc = torch.nan_to_num(current_acc, nan=0.0)  # [B, 1, N, 1, 1]
    acc = torch.cat([current_acc, cmd_pred[..., 0:1]], dim=-2)  # [B, 1, N, T+1, 1]
    jerk = compute_difference(acc, dt=dt)

    current_steering = (
        (joint_get_egos[:, :, 8].reshape(batch_size, 1, 1, 1, 1).expand(batch_size, 1, k_traj_num, 1, 1))
        / wheel_steering_ratio
        / 180
        * torch.pi
    )  # [B, 1, N, 1, 1]
    steering = torch.cat([current_steering, cmd_pred[..., 1:2]], dim=-2)  # [B, 1, N, T+1, 1]
    steering_rate = compute_difference(steering, dt=dt)  # [B, 1, N, T, 1]

    curvature = torch.tan(steering) / wheel_base
    centrifugal_acc = torch.square(traj_center[..., 3:]) * curvature
    centrifugal_acc = centrifugal_acc[:, :, :, 1:, :]

    traj_center = torch.cat(
        [traj_center_without_current, steering_rate, cmd_pred[..., 0:1], jerk, centrifugal_acc], dim=-1
    )

    return traj_center


def compute_difference(trajs_with_init_point, dt=0.1):
    """Compute the difference of the trajs.

    Args:
        trajs_with_init_point: torch.tensor, [B, 1, N, T+1, 1]
    """
    diff_trajs = (trajs_with_init_point[..., 1:, :] - trajs_with_init_point[..., :-1, :]) / dt
    return diff_trajs


def compute_gt_traj_tensor(
    joint_get_egos, future_acc, future_vel, future_steering, wheel_base=2.888, dt=0.1, whl_ratio=16.5
):
    """Gt traj tensor.

    Args:
        trajs_with_init_point: torch.tensor, [B, 1, N, T+1, 1]
    """
    joint_get_egos = joint_get_egos.transpose(1, 2)[:, :, -1]
    batch_size, _, _ = joint_get_egos.shape

    current_acc = torch.sqrt(
        joint_get_egos[:, :, 12] * joint_get_egos[:, :, 12] + joint_get_egos[:, :, 13] * joint_get_egos[:, :, 13]
    ).reshape(
        batch_size, 1, 1
    )  # [B, 1, 1]

    current_steering = joint_get_egos[:, :, 8].reshape(batch_size, 1, 1)

    future_vel = torch.norm(future_vel.unsqueeze(1), dim=-1)  # (B, 1, T)
    future_acc = torch.norm(future_acc.unsqueeze(1), dim=-1)  # (B, 1, T)
    future_steering = future_steering.unsqueeze(1)  # (B, 1, T)

    acc_sequence = torch.cat([current_acc, future_acc], dim=-1).unsqueeze(1).unsqueeze(-1)
    steering_sequence = torch.cat([current_steering, future_steering], dim=-1).unsqueeze(1).unsqueeze(-1)

    steering_rate = compute_difference(steering_sequence, dt=dt)
    jerk = compute_difference(acc_sequence, dt=dt)
    steering_rate = future_steering.unsqueeze(1).unsqueeze(-1) / whl_ratio / 180 * torch.pi
    curvature = torch.tan(steering_rate) / wheel_base
    future_vel_sqr_sequence = torch.square(future_vel).unsqueeze(1).unsqueeze(-1)
    centrifugal_acc = future_vel_sqr_sequence * curvature

    res = torch.cat([steering_rate, future_acc.unsqueeze(1).unsqueeze(-1), jerk, centrifugal_acc], dim=-1).squeeze(2)
    return res
