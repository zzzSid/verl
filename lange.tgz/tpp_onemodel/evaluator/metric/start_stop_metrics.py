# -*- coding: utf-8 -*-
"""Astra Planner evaluation start and stop metrics."""
import torch


TLD_CONFIG = {
    "start_window": 10,
    "start_history_threshold": 0.05,
    "start_future_threshold": 0.1,
    "stop_window": 10,
    "stop_history_threshold": 0.1,
    "stop_future_threshold": 0.05,
}


def cal_start_stop_metric(
    egos_history,
    egos_pred_gt,
    sorted_traj_pred,
):
    """Compute start & stop Metric."""
    start_all, start_recall, start_precision, start_tp = _count_start(egos_history, egos_pred_gt, sorted_traj_pred)
    stop_all, stop_recall, stop_precision, stop_tp = _count_stop(egos_history, egos_pred_gt, sorted_traj_pred)
    start_stop_result = {
        "start_all": start_all,
        "start_recall": start_recall,
        "start_precision": start_precision,
        "start_tp": start_tp,
        "stop_all": stop_all,
        "stop_recall": stop_recall,
        "stop_precision": stop_precision,
        "stop_tp": stop_tp,
    }
    return start_stop_result


def _count_start(
    egos_history,
    egos_pred_gt,
    sorted_traj_pred,
):
    """Compute Start Metric."""
    start_window = TLD_CONFIG.get("start_window", 10)
    history_threshold = TLD_CONFIG.get("start_history_threshold", 0.05) * start_window
    future_threshold = TLD_CONFIG.get("start_future_threshold", 0.05) * start_window

    history_len = egos_history.shape[1]
    pred_len = egos_pred_gt.shape[2]
    start_window = min(start_window, history_len - 1)
    assert history_len > start_window
    assert pred_len > start_window

    history_move = egos_history[:, history_len - start_window, 0, :2]
    history_move = torch.norm(history_move, dim=-1)  # B,1
    history_condition = history_move < history_threshold

    future_move = egos_pred_gt[:, 0, start_window - 1, :]
    future_move = torch.norm(future_move, dim=-1)
    future_condition = future_move > future_threshold

    pred_move = sorted_traj_pred[:, 0, start_window - 1, :]
    pred_move = torch.norm(pred_move, dim=-1)  # B,num_K,1
    pred_condition = pred_move > future_threshold

    start_all = history_condition  # all start frame num
    start_recall = future_condition & start_all  # all positive sample, recall base num
    start_presition = pred_condition & start_all  # all pred positive sample, presition base num
    start_tp = pred_condition & future_condition & start_all  # True Positive num

    return start_all, start_recall, start_presition, start_tp


def _count_stop(
    egos_history,  # [B,T,1,D]
    egos_pred_gt,  # [B, 1, T, 2]
    sorted_traj_pred,
):
    """Compute Stop Metric."""
    start_window = TLD_CONFIG.get("stop_window", 10)
    history_threshold = TLD_CONFIG.get("stop_history_threshold", 0.05) * start_window
    future_threshold = TLD_CONFIG.get("stop_future_threshold", 0.05) * start_window

    history_len = egos_history.shape[1]
    pred_len = egos_pred_gt.shape[2]
    start_window = min(start_window, history_len - 1)
    assert history_len > start_window
    assert pred_len > start_window

    history_move = egos_history[:, history_len - start_window, 0, :2]
    history_move = torch.norm(history_move, dim=-1)  # B,1
    history_condition = history_move > history_threshold

    future_move = egos_pred_gt[:, 0, start_window - 1, :]
    future_move = torch.norm(future_move, dim=-1)
    future_condition = future_move < future_threshold

    pred_move = sorted_traj_pred[:, 0, start_window - 1, :]
    pred_move = torch.norm(pred_move, dim=-1)  # B,num_K,1
    pred_condition = pred_move < future_threshold

    start_all = history_condition  # all start frame num
    start_recall = future_condition & start_all  # all positive sample, recall base num
    start_presition = pred_condition & start_all  # all pred positive sample, presition base num
    start_tp = pred_condition & future_condition & start_all  # True Positive num
    return start_all, start_recall, start_presition, start_tp


def cal_start_recall(start_stop_result):
    """Cal start recall."""
    start_recall = start_stop_result["start_recall"].unsqueeze(-1)
    start_tp = start_stop_result["start_tp"].unsqueeze(-1)
    return start_tp, start_recall


def cal_start_precision(start_stop_result):
    """Cal start precisio."""
    start_precision = start_stop_result["start_precision"].unsqueeze(-1)
    start_tp = start_stop_result["start_tp"].unsqueeze(-1)
    return start_tp.int(), start_precision


def cal_start_tp(start_stop_result):
    """Cal start ture positive."""
    start_recall = start_stop_result["start_recall"].unsqueeze(-1)
    start_all = start_stop_result["start_all"].unsqueeze(-1)
    return start_recall.int(), start_all


def cal_stop_recall(start_stop_result):
    """Cal stop recall."""
    stop_recall = start_stop_result["stop_recall"].unsqueeze(-1)
    stop_tp = start_stop_result["stop_tp"].unsqueeze(-1)
    return stop_tp.int(), stop_recall


def cal_stop_precision(start_stop_result):
    """Cal stop precision."""
    stop_precision = start_stop_result["stop_precision"].unsqueeze(-1)
    stop_tp = start_stop_result["stop_tp"].unsqueeze(-1)
    return stop_tp.int(), stop_precision


def cal_stop_tp(start_stop_result):
    """Cal start ture positive."""
    stop_recall = start_stop_result["stop_recall"].unsqueeze(-1)
    stop_all = start_stop_result["stop_all"].unsqueeze(-1)
    return stop_recall.int(), stop_all
