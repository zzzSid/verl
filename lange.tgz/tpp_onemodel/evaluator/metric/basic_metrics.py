# -*- coding: utf-8 -*-
"""Astra Planner evaluation basic metrics."""
import torch


def cal_l2_dist(pred_trajs, gts, mask):
    """Cal l2 dist between ego/agent pred trajs and gt.

    Args:
        pred_trajs: [B, A, K_mode, T_future, 2]
        gts: [B, A, T_future, 2]
        mask: [B, A, T_future]
    """
    return torch.norm(gts.unsqueeze(2) - pred_trajs, dim=-1) * mask.unsqueeze(2)  # [B,A+1,k,T]


def cal_joint_best_l2_dist(l2_dist, timestamp):
    """Cal best l2 dist between ego/agent pred trajs and gt.

    Args:
        pred_trajs: [B, A, K_mode, T_future, 2]
        gts: [B, A, T_future, 2]
        mask: [B, A, T_future]
    """
    error_sum = l2_dist[..., 0 : timestamp - 1].sum(1).sum(-1)
    min_idx = error_sum.min(-1)[1]
    return l2_dist[torch.arange(l2_dist.shape[0]), :, min_idx, :]  # [B,A,T]


def cal_dist_mask(l2_dist):
    """Cal dist mask.

    Args:
        l2_dist: [B, A, K_mode, T_future]
    """
    return l2_dist != 0


def cal_fde_mask(dist_mask, timestamp):
    """Cal fde mask.

    Args:
        dist_mask: [B, A, K_mode, T_future]
        timestamp: int, the num of pred point used
    """
    if timestamp > dist_mask.shape[3]:
        return None
    return (dist_mask)[:, :, 0, timestamp - 1]


def cal_gt_mask(dist_mask, timestamp):
    """Cal fde mask.

    Args:
        dist_mask: [B, A, K_mode, T_future]
        timestamp: int, the num of pred point used
    """
    if timestamp > dist_mask.shape[3]:
        return None
    return (torch.ones_like(dist_mask))[:, :, 0, timestamp - 1]


def cal_fde_1(l2_dist, fde_mask, timestamp):
    """Cal fde metric of traj with best score.

    Args:
        l2_dist: [B, A, K_mode, T_future]
        fde_mask: [B, A]
        timestamp: int, the num of pred point used
    """
    if fde_mask is None:
        return None, None
    fde_1 = l2_dist[:, :, 0, timestamp - 1]
    return fde_1, fde_mask  # torch.ones_like(fde_1) #[B,1]


# def cal_navi_fde_l_top1(l2_dist, fde_mask, timestamp):
def cal_navi_fde_l_top1(
    egos_pred_mask,
    gt_navi_dist_s,
    gt_navi_dist_l,
    traj_navi_dist_s,
    traj_navi_dist_l,
    gt_navi_dist_s_selected,
    gt_navi_dist_l_selected,
    navi_point_mask,
    navi_line_valid_mask,
    navi_miss_rate_threshold=1.0,
    timestamp=70,
    # topk=False,
):
    """Cal fde metric of traj with best score.

    Args:
        egos_pred_mask: [B, 1, T]
        gt_navi_dist_s: [B, N, T]
        gt_navi_dist_l: [B, N, T]
        traj_navi_dist_s: [B, N, T]
        traj_navi_dist_l: [B, N, T]
        navi_point_mask: [B, N,T]
        navi_line_valid_mask: [B, N]
        navi_miss_rate_threshold: float
        timestamp: int, the num of pred point used
    """
    fde_mask = egos_pred_mask[:, :, timestamp - 1]  # [B,1]
    fde_mask = (navi_line_valid_mask.sum(-1) > 0)[:, None] * fde_mask  # [B,1]
    fde_1 = fde_mask * traj_navi_dist_l[..., timestamp - 1]  # [B,1]

    # fde_mask = egos_pred_mask[:, :, timestamp - 1]  # [B,1]
    # fde_mask = (navi_line_valid_mask.sum(-1) > 0)[:, None] * fde_mask  # [B,1]
    # dist_l = torch.clip(traj_navi_dist_l - gt_navi_dist_l_selected, 0)  # [B, N1 T]
    # fde_1 = fde_mask * dist_l[..., timestamp - 1]  # [B,1]
    return fde_1, fde_mask  # torch.ones_like(fde_1)


def cal_accuracy(l2_dist, fde_mask, timestamp):
    """Cal accuracy metric of traj.

    Args:
        l2_dist: [B, A, K_mode, T_future]
        fde_mask: [B, A]
        timestamp: int, the num of pred point used
    """
    if fde_mask is None:
        return None, None
    error_sum = l2_dist[..., 0 : timestamp - 1].sum(-1)
    min_idx = error_sum.min(-1)[1]
    accuracy = min_idx == 0
    return accuracy, fde_mask  # [B,1] , [B,1]


def cal_navi_accuracy(marginal_ego_score, gt_navi_index, navi_line_valid_mask, fde_mask):
    """Cal accuracy metric of traj.

    Args:
        l2_dist: [B, A, K_mode, T_future]
        fde_mask: [B, A]
        timestamp: int, the num of pred point used
    """
    if fde_mask is None:
        return None, None
    marginal_pred_index = marginal_ego_score.max(-1)[1]
    gt_navi_index = gt_navi_index.unsqueeze(-1)
    accuracy = marginal_pred_index == gt_navi_index
    navi_exsist_mask = (navi_line_valid_mask.sum(-1) > 0).unsqueeze(-1)
    accuracy = accuracy * navi_exsist_mask
    final_mask = fde_mask * navi_exsist_mask
    return accuracy, final_mask  # torch.ones_like(fde_1)


def cal_joint_accuracy(l2_dist, fde_mask, timestamp):
    """Cal joint accuracy metric.

    Args:
        l2_dist: [B, A, K_mode, T_future]
        fde_mask: [B, A]
        timestamp: int, the num of pred point used
    """
    if fde_mask is None:
        return None, None
    error_sum = l2_dist[..., 0 : timestamp - 1].sum(1).sum(-1)
    min_idx = error_sum.min(-1)[1]
    accuracy = min_idx == 0
    accuracy = accuracy[:, None] * fde_mask
    return accuracy, fde_mask  # torch.ones_like(fde_1)


def cal_mr_1(fde_mask, fde_1, missing_distance):
    """Cal missing rate of traj with best score.

    Args:
        fde_mask: [B, A]
        fde_1: [B, A]
        missing_distance: missing rate cal threshold
    """
    if fde_mask is None:
        return None, None
    mr_1 = fde_1 > missing_distance
    return mr_1, fde_mask  # torch.ones_like(mr_1)


def cal_fde_k(l2_dist, fde_mask, timestamp):
    """Cal fde metric of top k highest score pred traj.

    Args:
        l2_dist: [B, A, K_mode, T_future]
        fde_mask: [B, A]
        timestamp: int, the num of pred point used
    """
    if fde_mask is None:
        return None, None
    fde_k = l2_dist[:, :, :, timestamp - 1].min(-1)[0]
    return fde_k, fde_mask  # torch.ones_like(fde_k)


def cal_joint_fde_k(l2_dist, fde_mask, timestamp):
    """Cal fde metric of top k highest score pred traj.

    Args:
        l2_dist: [B, A, K_mode, T_future]
        fde_mask: [B, A]
        timestamp: int, the num of pred point used
    """
    if fde_mask is None:
        return None, None
    fde_k = l2_dist[:, :, timestamp - 1]
    return fde_k, fde_mask  # torch.ones_like(fde_k)


def cal_mr_k(fde_mask, fde_k, missing_distance):
    """Cal missing rate of top k highest score pred traj.

    Args:
        fde_mask: [B, A]
        fde_k: [B, A]
        missing_distance: missing rate cal threshold
    """
    if fde_mask is None:
        return None, None
    mr_k = fde_k > missing_distance
    return mr_k, fde_mask  # torch.ones_like(mr_k)


def cal_ade_1(l2_dist, dist_mask, fde_mask, timestamp):
    """Cal ade metric of traj with best score.

    Args:
        l2_dist: [B, A, K_mode, T_future]
        dist_mask: [B, A, K_mode, T_future]
        fde_mask: [B, A]
        timestamp: int, the num of pred point used
    """
    if fde_mask is None:
        return None, None
    # dist_mask = l2_dist != 0
    # fde_mask = (dist_mask)[:, :, 0, timestamp - 1]
    ade_1 = (
        l2_dist[:, :, 0, 0:timestamp].sum(-1)
        * fde_mask
        / ((dist_mask * fde_mask[:, :, None, None])[:, :, 0, 0:timestamp].sum(-1) + 1e-6)
    )
    return ade_1, fde_mask  # torch.ones_like(ade_1)


def cal_ade_k(l2_dist, dist_mask, fde_mask, timestamp):
    """Cal ade metric of top k highest score pred traj.

    Args:
        l2_dist: [B, A, K_mode, T_future]
        dist_mask: [B, A, K_mode, T_future]
        fde_mask: [B, A]
        timestamp: int, the num of pred point used
    """
    if fde_mask is None:
        return None
    ade_k = (
        l2_dist[:, :, :, 0:timestamp].sum(-1).min(-1)[0]
        * fde_mask
        / ((dist_mask * fde_mask[:, :, None, None])[:, :, 0, 0:timestamp].sum(-1) + 1e-6)
    )
    return ade_k, fde_mask  # torch.ones_like(ade_k)


def cal_joint_ade_k(best_l2_dist, dist_mask, fde_mask, timestamp):
    """Cal ade metric of top k highest score pred traj.

    Args:
        best_l2_dist: [B, A, T_future]
        dist_mask: [B, A, K_mode, T_future]
        fde_mask: [B, A]
        timestamp: int, the num of pred point used
    """
    if fde_mask is None:
        return None
    ade_k = (best_l2_dist[:, :, 0:timestamp].sum(-1) * fde_mask) / (
        (dist_mask[:, :, 0] * fde_mask[:, :, None])[:, :, 0:timestamp].sum(-1) + 1e-6
    )
    return ade_k, fde_mask  # torch.ones_like(ade_k)


def cal_current_speed_from_vxvy(egos):
    """Calculate ego current speed from vxvy.

    Args:
        egos: [B, T_past, A, 15]

    Returns:
        current_speed (torch.tensor): [B, A]
        fde_mask (torch.tensor): [B, A]
    """
    init_vx = egos[:, -1, :, 10]  # [B, A]
    init_vy = egos[:, -1, :, 11]  # [B. A]
    current_speed = torch.sqrt(init_vx**2 + init_vy**2)  # [B, A]

    return current_speed


def get_unmasked_ego_num(egos_pred_mask):
    """Get the number of unmasked ego in the batch.

    Args:
        egos_pred_mask: [B, 1, T], 1 for unmasked, 0 for masked

    Returns:
        unmasked_ego_num (torch.tensor): [B]
    """
    unmasked_ego_num = egos_pred_mask.sum(-1) > 0  # [B,1]

    return unmasked_ego_num, torch.ones([egos_pred_mask.shape[0], 1])


if __name__ == "__main__":
    B = 4
    A = 50
    T_f = 30
    T_p = 15
    D = 40
    N = 10
    M = 20
    K = 36

    # ego_trajs = torch.rand([B, 1, K, T_f, 2])  # v marginal_ego_min_fde_traj
    # ego_traj_mask = torch.ones([B, 1, T_f])  # v egos_pred_mask
    # ego_gt = torch.rand([B, 1, T_f, 2])
    # l2_dist = cal_l2_dist(ego_trajs, ego_gt, ego_traj_mask)
    # # fde_1 = cal_fde_1(l2_dist, 30)
    # ade_1 = cal_ade_1(l2_dist, 30)
    # # mr_1 = cal_mr_1(fde_1, 30)

    # dist_mask = l2_dist != 0
    # fde_mask = (dist_mask)[:, :, 0, 30 - 1]
    # # print(fde_mask.shape)
    # # print(l2_dist[:, :, 0, 0:30].sum(-1))
    # # print(fde_mask.shape)
    # # print(l2_dist[:, :, 0, 0:30].sum(-1)* fde_mask)
    # # print(dist_mask.shape)
    # # print((dist_mask * fde_mask[:, None, None]).shape)
    # ade_1 = (
    #     l2_dist[:, :, 0, 0:30].sum(-1)
    #     * fde_mask
    #     / ((dist_mask * fde_mask[:, None, None])[:, :, 0, 0:30].sum(-1) + 1e-6)
    # )

    # torch.Size([4, 191, 6, 30])
    # torch.Size([4, 191])
    # torch.Size([4, 191, 6, 30])

    ego_trajs = torch.rand([B, 191, K, T_f, 2])  # v marginal_ego_min_fde_traj
    ego_traj_mask = torch.ones([B, 191, T_f])  # v egos_pred_mask
    ego_gt = torch.rand([B, 191, T_f, 2])
    l2_dist = cal_l2_dist(ego_trajs, ego_gt, ego_traj_mask)

    dist_mask = l2_dist != 0
    fde_mask = (dist_mask)[:, :, 0, 30 - 1]
    # print(dist_mask.shape)
    # print(fde_mask.shape)
    # print(l2_dist.shape)

    # print(l2_dist[:, :, 0, 0:30].sum(-1).shape)
    # print((l2_dist[:, :, 0, 0:30].sum(-1) * fde_mask).shape)
    # print((dist_mask * fde_mask[:, :, None, None]).shape)
    # print(fde_mask.shape)
    # print(l2_dist[:, :, 0, 0:30].sum(-1))
    # print(fde_mask.shape)
    # print(l2_dist[:, :, 0, 0:30].sum(-1)* fde_mask)
    # print(dist_mask.shape)
    # print((dist_mask * fde_mask[:, None, None]).shape)
    ade_1 = (
        l2_dist[:, :, 0, 0:30].sum(-1)
        * fde_mask
        / ((dist_mask * fde_mask[:, :, None, None])[:, :, 0, 0:30].sum(-1) + 1e-6)
    )
