# -*- coding: utf-8 -*-
# pylint:disable=invalid-name
"""UD Metrics."""
import copy
import math
from collections import OrderedDict

import numba as nb
import numpy as np
import torch
from tabulate import tabulate  # noqa: I900


# flake8: noqa: S101

EPS = 1e-6


class UniDecisionMetric:
    """UniDecisionMetric.

    Calculate uni decision metric, including
    score_bias, accuracy, precision, recall
    """

    def __init__(self, eval_cfg):
        self._eval_class = eval_cfg.get("eval_class", [])
        self._eval_class_agnostic = eval_cfg.get("eval_class_agnostic", True)  # TODO(ian.xu): apply metric on class
        if not (len(self._eval_class) != 0 or self._eval_class_agnostic):
            raise ValueError("eval class must not be empty if class awareness")

        self.min_num_future_gt_point = eval_cfg.get("min_num_future_gt_point", 15)
        self.best_traj_ade_thres = eval_cfg.get("best_traj_ade_thres", 1.0)
        self.best_traj_max_de_thres = eval_cfg.get("best_traj_max_de_thres", 1.5)

        self.score_threshes = [0.5]  # list, the precision limit of each item is 3 decimal places.
        self.confidence_threshes = [0.1]  # list, the precision limit of each item is 3 decimal places.
        # TODO(ian.xu): add class dimension

        self.base_metric_keys = {
            "s_bias_pos",
            "s_bias_neg",
            "acc",
            "pr",
            "re",
            "ego_traj_match_hit_rate",
            "obs_traj_match_hit_rate",
        }
        base_metrics = {key: [0, 0] for key in self.base_metric_keys}

        self.all_metrics_single_batch = {}
        for conf_th in self.confidence_threshes:
            for score_th in self.score_threshes:
                if conf_th not in self.all_metrics_single_batch.keys():
                    self.all_metrics_single_batch.update({conf_th: {}})
                self.all_metrics_single_batch[conf_th][score_th] = copy.deepcopy(base_metrics)
        self.reset_state()

    @torch.no_grad()
    def batched_index_select(self, input, dim, index):
        """
        For batch index select.

        Args:
            input(Tensor),
            dim(int),
            index(Tensor)
        """
        views = [input.shape[0]] + [1 if i != dim else -1 for i in range(1, len(input.shape))]
        expanse = list(input.shape)
        expanse[0] = -1
        expanse[dim] = -1
        index = index.view(views).expand(expanse)
        return torch.gather(input, dim, index)

    @torch.no_grad()
    def select_best_traj(self, ego_pred_trajs, agent_pred_trajs, ego_gt, agent_gts, ego_gt_mask, agent_gt_masks):
        """
        Select best traj from K trajs modals of each agent & ego.

        Args:
            ego_pred_trajs: [B, K, T, 2]
            agent_pred_trajs: [B, A, K, T, 2]
            ego_gt: [B, T, 2]
            agent_gts: [B, A, T, 2]
            ego_gt_mask: [B, T]
            agent_gt_masks: [B, A, T]
        """
        batch_size, agent_num, modality_num, time_step, _ = agent_pred_trajs.shape

        ego_traj_err_xy = ego_pred_trajs.detach() - ego_gt.unsqueeze(1).expand([-1, modality_num, -1, -1])
        ego_expand_gt_mask = ego_gt_mask.unsqueeze(1).expand([-1, modality_num, -1])
        ego_traj_err = (
            ego_traj_err_xy[:, :, :, 0] ** 2 + ego_traj_err_xy[:, :, :, 1] ** 2
        ) * ego_expand_gt_mask  # B, K, T
        ego_traj_ade = torch.sum(ego_traj_err, dim=-1) / (torch.sum(ego_expand_gt_mask, dim=-1) + EPS)  # B, K
        ego_traj_max_de, _ = torch.max(ego_traj_err, dim=-1)  # B, K
        ego_best_index = torch.argmin(ego_traj_ade, dim=-1)  # B
        ego_select_ade = self.batched_index_select(ego_traj_ade, dim=1, index=ego_best_index).squeeze()
        ego_select_max_de = self.batched_index_select(ego_traj_max_de, dim=1, index=ego_best_index).squeeze()
        ego_future_points = torch.sum(ego_gt_mask, dim=-1)
        ego_ade_mask = ego_select_ade < self.best_traj_ade_thres  # todo: use dynamic threshold according to future num
        ego_max_de_mask = ego_select_max_de < self.best_traj_max_de_thres
        ego_point_mask = ego_future_points > self.min_num_future_gt_point
        ego_mask = ego_ade_mask * ego_max_de_mask * ego_point_mask

        agent_traj_err_xy = agent_pred_trajs.detach() - agent_gts.unsqueeze(2).expand([-1, -1, modality_num, -1, -1])
        agent_expand_gt_masks = agent_gt_masks.unsqueeze(2).expand([-1, -1, modality_num, -1])
        agent_traj_err = (
            agent_traj_err_xy[..., 0] ** 2 + agent_traj_err_xy[..., 1] ** 2
        ) * agent_expand_gt_masks  # B, N, K, T
        agent_traj_ade = torch.sum(agent_traj_err, dim=-1) / (torch.sum(agent_expand_gt_masks, dim=-1) + EPS)  # B, A, K
        agent_traj_ade = agent_traj_ade.view([batch_size * agent_num, modality_num])  # B*A, K
        agent_traj_max_de, _ = torch.max(agent_traj_err, dim=-1)  # B, A, K
        agent_traj_max_de = agent_traj_max_de.view([batch_size * agent_num, modality_num])  # B*A, K
        agent_best_index = torch.argmin(agent_traj_ade, dim=-1)  # B*A
        agent_select_ade = self.batched_index_select(agent_traj_ade, dim=1, index=agent_best_index).squeeze()
        agent_select_max_de = self.batched_index_select(agent_traj_max_de, dim=1, index=agent_best_index).squeeze()
        agent_future_points = torch.sum(agent_gt_masks, dim=-1).view([batch_size * agent_num])
        agent_ade_mask = agent_select_ade < self.best_traj_ade_thres
        agent_max_de_mask = agent_select_max_de < self.best_traj_max_de_thres
        agent_point_mask = agent_future_points > self.min_num_future_gt_point
        agent_mask = agent_ade_mask * agent_max_de_mask * agent_point_mask

        selected_index = ego_best_index.unsqueeze(1).expand([-1, agent_num]) * modality_num + agent_best_index.view(
            [batch_size, agent_num]
        )
        selected_mask = ego_mask.unsqueeze(1).expand([-1, agent_num]) * agent_mask.view([batch_size, agent_num])

        return selected_index, selected_mask, ego_mask, agent_mask

    @torch.no_grad()
    def __call__(self, model_inputs, model_outputs):
        """
        Calculate metrics, return a list of dicts.
        """

        # marginal prediction
        ego_pred_trajs = model_outputs["ego_pred_traj_output"]
        agent_pred_trajs = model_outputs["pred_traj_output"]
        batch_size, _, modality_num, feat_dim = ego_pred_trajs.shape
        ego_pred_trajs = ego_pred_trajs[..., :-1].reshape(batch_size, modality_num, feat_dim // 2, 2)
        batch_size, agent_num, modality_num, feat_dim = agent_pred_trajs.shape
        agent_pred_trajs = agent_pred_trajs[..., :-1].reshape(batch_size, agent_num, modality_num, feat_dim // 2, 2)

        # gt
        agent_gts = model_inputs["bboxes_pred_gt"]
        ego_gt = model_inputs["egos_pred_gt"].squeeze()

        # marginal uni decision
        # TODO(ian.xu): for debug, remove after merge with UD decoders
        if ("decision_score" not in model_outputs) or ("decision_confidence" not in model_outputs):
            return
            model_outputs["decision_score"] = torch.rand(batch_size, agent_num, modality_num * modality_num).to(
                ego_pred_trajs.device
            )
            model_outputs["decision_confidence"] = torch.ones(batch_size, agent_num, modality_num * modality_num).to(
                ego_pred_trajs.device
            )

        decision_score = model_outputs["decision_score"]  # [B, A, K*K]
        decision_confidence = model_outputs["decision_confidence"]  # [B, A, K*K]

        # gt_mask
        agent_gt_masks = model_inputs["bboxes_pred_mask"]  # 1: valid [B, A, 30]
        ego_gt_mask = model_inputs["egos_pred_mask"].squeeze()  # 1: valid [B, 30]
        # agent_padding_masks = model_inputs["bboxes_padding_mask"].permute(0, 2, 1)  # 0: valid [B, A, 15]
        # _, _, history_num = agent_padding_masks.shape
        # history_mask = agent_padding_masks.sum(-1) < history_num

        metric_results_list = [{} for batch_idx in range(batch_size)]
        if "agent_decision_label" not in model_inputs:
            return
            # TODO(ian.xu): for debug, return empty list after UD data is ready
            agent_decision_label = torch.zeros([batch_size, agent_num]).to(agent_gt_masks.device)
            agent_decision_mask = torch.ones([batch_size, agent_num]).to(agent_gt_masks.device)
            for batch_index in range(batch_size):
                for agent_index in range(agent_num):
                    if torch.rand(1) < 0.8:
                        agent_decision_label[batch_index][agent_index] = 1
                    # if torch.rand(1) < 0.2:
                    #     agent_decision_mask[batch_index][agent_index] = 1
        else:
            agent_decision_label = model_inputs["agent_decision_label"]  # [B, A]
            agent_decision_mask = model_inputs["agent_decision_mask"]  # [B, A]

        selected_index, has_best_traj_mask, ego_matched_mask, agent_matched_mask = self.select_best_traj(
            ego_pred_trajs, agent_pred_trajs, ego_gt, agent_gts, ego_gt_mask, agent_gt_masks
        )
        valid_and_has_best_traj_agent_mask = agent_decision_mask * has_best_traj_mask  # [B*A]

        agent_matched_mask = agent_matched_mask.reshape(batch_size, agent_num)  # [B, A]
        agent_gt_has_valid_frame_num = (agent_gt_masks.sum(-1) > 0).sum(-1)
        agent_matched_ratio = agent_matched_mask.sum(1) / (agent_gt_has_valid_frame_num + EPS)  # [B]

        raw_metric_list = [copy.deepcopy(self.all_metrics_single_batch) for batch_idx in range(batch_size)]

        # get score and confidence
        selected_agent_decision_score = self.batched_index_select(
            decision_score.view([batch_size * agent_num, -1]), dim=-1, index=selected_index  # [B*A, 1]
        )  # [B*A]
        selected_agent_decision_score = selected_agent_decision_score.view([batch_size, agent_num])

        selected_agent_decision_confi = self.batched_index_select(
            decision_confidence.view([batch_size * agent_num, -1]), dim=-1, index=selected_index  # [B*A, 1]
        )  # [B*A]
        selected_agent_decision_confi = selected_agent_decision_confi.view([batch_size, agent_num])

        score_bias = (
            selected_agent_decision_score - agent_decision_label
        ) * valid_and_has_best_traj_agent_mask  # [B*A]
        for conf_th in self.confidence_threshes:
            confi_mask = selected_agent_decision_confi > conf_th
            # calc score bias
            score_bias_tmp = score_bias * confi_mask

            positive_mask = score_bias_tmp > 0
            count_positive_values = positive_mask.sum(dim=1)
            positive_values = score_bias_tmp * positive_mask
            sum_positive_values = positive_values.sum(dim=1)
            # average_positive_values = torch.where(
            #     count_positive_values > 0,
            #     sum_positive_values / count_positive_values,
            #     torch.tensor(0.0).to(agent_gt_masks.device),
            # )

            negative_mask = score_bias_tmp < 0
            count_negative_values = negative_mask.sum(dim=1)
            negative_values = score_bias_tmp * negative_mask
            sum_negative_values = negative_values.sum(dim=1)
            # average_negative_values = torch.where(
            #     count_negative_values > 0,
            #     sum_negative_values / count_negative_values,
            #     torch.tensor(0.0).to(agent_gt_masks.device),
            # )

            for batch_idx in range(batch_size):
                for score_th in self.score_threshes:
                    raw_metric_list[batch_idx][conf_th][score_th]["s_bias_pos"] = [
                        sum_positive_values[batch_idx].item(),
                        count_positive_values[batch_idx].item(),
                    ]
                    raw_metric_list[batch_idx][conf_th][score_th]["s_bias_neg"] = [
                        abs(sum_negative_values[batch_idx].item()),
                        count_negative_values[batch_idx].item(),
                    ]

                    raw_metric_list[batch_idx][conf_th][score_th]["ego_traj_match_hit_rate"] = [
                        1.0 if ego_matched_mask[batch_idx].item() else 0.0,
                        1,
                    ]

                    raw_metric_list[batch_idx][conf_th][score_th]["obs_traj_match_hit_rate"] = [
                        agent_matched_ratio[batch_idx].item(),
                        1,
                    ]

        # cal acc, pr, re, in different threholds
        for conf_th in self.confidence_threshes:
            confi_mask = selected_agent_decision_confi > conf_th

            for score_th in self.score_threshes:
                agent_decision_pred = selected_agent_decision_score > score_th

                TP_matrix = (
                    (agent_decision_pred == 1) * (agent_decision_label == 1) * confi_mask
                ) * valid_and_has_best_traj_agent_mask  # TODO(ian.xu) # [B, A]
                TN_matrix = (
                    (agent_decision_pred == 0) * (agent_decision_label == 0) * confi_mask
                ) * valid_and_has_best_traj_agent_mask
                FP_matrix = (
                    (agent_decision_pred == 1) * (agent_decision_label == 0) * confi_mask
                ) * valid_and_has_best_traj_agent_mask
                FN_matrix = (
                    (agent_decision_pred == 0) * (agent_decision_label == 1) * confi_mask
                ) * valid_and_has_best_traj_agent_mask

                TP_cnt = TP_matrix.sum(dim=1)  # [B, 1]
                TN_cnt = TN_matrix.sum(dim=1)
                FP_cnt = FP_matrix.sum(dim=1)
                FN_cnt = FN_matrix.sum(dim=1)

                for batch_idx in range(batch_size):
                    cnt_sum = (
                        TP_cnt[batch_idx].item()
                        + TN_cnt[batch_idx].item()
                        + FP_cnt[batch_idx].item()
                        + FN_cnt[batch_idx].item()
                    )
                    if cnt_sum == 0:
                        raw_metric_list[batch_idx][conf_th][score_th]["acc"] = [0, 0]
                    else:
                        raw_metric_list[batch_idx][conf_th][score_th]["acc"] = [
                            (TP_cnt[batch_idx].item() + TN_cnt[batch_idx].item()) / cnt_sum,
                            cnt_sum,
                        ]

                    pred_pos_cnt = TP_cnt[batch_idx].item() + FP_cnt[batch_idx].item()
                    if pred_pos_cnt == 0:
                        raw_metric_list[batch_idx][conf_th][score_th]["pr"] = [0, 0]
                    else:
                        raw_metric_list[batch_idx][conf_th][score_th]["pr"] = [
                            TP_cnt[batch_idx].item() / pred_pos_cnt,
                            pred_pos_cnt,
                        ]

                    gt_pos_cnt = TP_cnt[batch_idx].item() + FN_cnt[batch_idx].item()
                    if gt_pos_cnt == 0:
                        raw_metric_list[batch_idx][conf_th][score_th]["re"] = [0, 0]
                    else:
                        raw_metric_list[batch_idx][conf_th][score_th]["re"] = [
                            TP_cnt[batch_idx].item() / gt_pos_cnt,
                            gt_pos_cnt,
                        ]

        self.calculate_and_store_metrics(raw_metric_list, metric_results_list)

        return metric_results_list

    def calculate_and_store_metrics(self, all_metrics, metric_results_list):
        """Calculate and store metrics.
        Input:
        all_metrics: raw metrics
        [ batch dim
            { confidence dim
                { score dim
                    {
                        "m1": ()
                        "m2": ()
                        "m3": ()
                    }
                }
            }
        ]

        Output:
        metric_results: List of Dict
        [ batch dim
            {
                "score1_conf1_m1": (val, num)
                "score1_conf1_m2": (val, num)
                "score1_conf1_m3": (val, num)
                "score1_conf1_m2": (val, num)
                .
                .
                "score3_conf3_m3": (val, num)
            },
        ]
        """
        for batch_idx in range(len(metric_results_list)):
            for conf_th in self.confidence_threshes:
                for score_th in self.score_threshes:
                    for m_key in self.base_metric_keys:
                        atomic_metric = all_metrics[batch_idx][conf_th][score_th][m_key]
                        metric_results_list[batch_idx][f"ud_c_th_{conf_th}_s_th_{score_th}_{m_key}"] = atomic_metric

    def reset_state(self):
        """Reset metric state."""
        self.metric_results = {}

    def calc_metric(self, metric_results):
        """Calc metrics."""

        return

    def generate_tensorboard_info(self, summaries):  # pylint: disable=no-self-use
        """Generate tensorboard info from summaries."""
        tb_dicts = OrderedDict()
        for metric_key, metric_val in summaries.items():
            new_k = metric_key
            tb_dicts.update({new_k: metric_val})

        return tb_dicts

    def generate_table_info(self, summaries):
        """Generate table info from summaries."""
        if self._eval_class_agnostic:
            table_data = [[key, val] for key, val in summaries.items()]
        else:
            keys_total = []
            for key in self.metric_results:
                item = key.split("@")[0]
                if item not in keys_total:
                    keys_total.append(item)
            table_data = []
            for key in keys_total:
                table_data.append([key] + [summaries[key + f"@{cls}"] for cls in self._eval_class] + [summaries[key]])

        # generate table data
        if not self._eval_class_agnostic:
            headers = ["metrics|class"] + [f"Cls@{idx}" for idx in self._eval_class] + ["All"]
        else:
            headers = ["metrics|class", "All"]
        table_vis = tabulate(
            headers=headers,
            tabular_data=table_data,
            tablefmt="grid",
            stralign="right",
            numalign="right",
        )
        return table_vis

    def get_summary(self):
        """Get overall metric summary."""
        summaries = {}

        summaries = self.metric_results
        # summaries in dict of "measure" - "value"
        table_vis = self.generate_table_info(summaries)
        tensorboard_vis = self.generate_tensorboard_info(summaries)

        results = {
            "lidar_table_vis": "UniDecisionMetric:\n" + table_vis,
            "lidar_tensorboard": tensorboard_vis,
        }
        return results
