# -*- coding: utf-8 -*-
"""Astra Planner evaluation smoothness metrics."""
import torch


def cal_gt_ego_curvature(steering_wheel, fde_mask, timestamp=30, wheel_base=2.888):
    """Calculate curvature of trajectory.

    Args:
        steering_wheel: [B, T]
        fde_mask: [B, 1]
        egos: [B, T_past, 1, 15]
        egos_pred_gt: [B, 1, T_pred, 2]

    Returns:
        curvature (torch.tensor): [B, 1]
        fde_mask (torch.tensor): [B, 1]
    """
    if fde_mask is None:
        return None, None

    curvature = torch.tan(steering_wheel / 16.5 / 180 * torch.pi) / wheel_base
    curvature = curvature[:, :timestamp].abs().mean(dim=-1, keepdim=True)

    return curvature, fde_mask


def cal_pred_ego_curvature(sorted_joint_ego_cmd, fde_mask, best_or_min, timestamp=30, wheel_base=2.888):
    """Calculate curvature of trajectory.

    Args:
        fde_mask: [B, 1]
        sorted_joint_ego_cmd: [B, 1, K, T_pred, 2]

    Returns:
        curvature (torch.tensor):
    """
    if fde_mask is None:
        return None, None

    cmd_steering = sorted_joint_ego_cmd[..., 1]  # [B, 1, K, T]
    curvature = torch.tan(cmd_steering) / wheel_base  # [B, 1, K, T]
    curvature = curvature[..., :timestamp].abs().mean(dim=-1)  # [B, 1, K]

    if best_or_min == "best":
        curvature = curvature[..., 0]  # [B, 1]
    elif best_or_min == "min":
        curvature = curvature.min(dim=-1)[0]

    return curvature, fde_mask
