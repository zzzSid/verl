# -*- coding: utf-8 -*-
"""Astra Planner evaluation hard constraint overload metrics."""


import torch


def get_ego_best_rk4_traj(
    sorted_pred_traj,
) -> torch.Tensor:
    """Get the best RK4 trajectory. The first one in the sorted list.

    Args:
        sorted_pred_traj: torch.Tensor, [B, 1, K, T, 4]

    Returns:
        best_traj: torch.Tensor, [B, 1, T, 4]
    """
    best_traj = sorted_pred_traj[:, :, 0]

    return best_traj  # [B, 1, T, 4]


def get_ego_closest_rk4_traj(
    gt_traj,
    gt_mask,
    pred_traj,
) -> torch.Tensor:
    """Get the closest RK4 trajectory to the ground truth trajectory. l2 distance.

    Args:
        gt_traj: torch.Tensor, [B, 1, T, 2]
        pred_traj: torch.Tensor, [B, 1, K, T, 4]
        gt_mask: torch.Tensor, [B, 1, T]

    Returns:
        closest_traj: torch.Tensor, [B, 1, T+1, 4]
    """
    b, _, k, t, d = pred_traj.shape

    gt_traj = gt_traj.unsqueeze(2).repeat(1, 1, k, 1, 1)
    gt_mask = gt_mask.unsqueeze(2).repeat(1, 1, k, 1)

    l2_dist = torch.norm(gt_traj - pred_traj[..., :2], dim=-1)  # [B, 1, K, T]
    l2_dist = torch.sum(l2_dist * gt_mask, dim=-1)  # [B, 1, K]
    closest_traj_idx = torch.argmin(l2_dist, dim=-1)  # [B, 1]

    closest_traj_idx_expand = closest_traj_idx.view(b, 1, 1, 1, 1).repeat(1, 1, 1, t, d)
    closest_traj = torch.gather(pred_traj, 2, closest_traj_idx_expand).squeeze(2)

    return closest_traj


def cal_ego_hard_constraint_overload_cnt(
    selected_traj_metric,
    fde_mask,
    threshold,
    timestamp,
):
    """Count the number of overload points in the selected trajectory metric.

    Args:
        selected_traj: torch.Tensor, [B, 1, T]
        threshold: float
        timestamp: int
    """
    return torch.sum((selected_traj_metric[..., :timestamp].abs() > threshold), dim=-1), fde_mask


def cal_mean(
    selected_traj_metric,
    fde_mask,
    timestamp,
):
    """Count the number of overload points in the selected trajectory metric.

    Args:
        selected_traj: torch.Tensor, [B, 1, T]
        threshold: float
        timestamp: int
    """
    return torch.mean((selected_traj_metric[..., :timestamp].abs()), dim=-1), fde_mask


def cal_ego_hard_constraint_underload_cnt(
    selected_traj_metric,
    fde_mask,
    threshold,
    timestamp,
):
    """Count the number of underload points in the selected trajectory metric.

    Args:
        selected_traj: torch.Tensor, [B, 1, T]
        threshold: float
        timestamp: int
    """
    return torch.sum((selected_traj_metric[..., :timestamp] < threshold), dim=-1), fde_mask


def decomp_rk4_result(input_traj, dim=0):
    """Count the number of underload points in the selected trajectory metric.

    Args:
        selected_traj: torch.Tensor, [B, 1, T]
        threshold: float
        timestamp: int
    """
    return input_traj[..., dim]
