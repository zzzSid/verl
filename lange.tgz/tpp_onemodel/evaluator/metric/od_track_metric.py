# -*- coding: utf-8 -*-
import torch


def cal_track_precision_obs(od_track_pred, od_track_gt, ego_trackable_agent_gt_mask, agent_index, confidence_thr):
    """cal_track_precision_obs."""
    agent_index = agent_index.to(dtype=torch.int32)
    od_track_gt[ego_trackable_agent_gt_mask == 0] = -1
    batch_size = od_track_pred.shape[0]
    od_track_gt_map = torch.zeros_like(od_track_pred)
    for bs_index in range(batch_size):
        od_track_gt_map[bs_index, :] = od_track_gt[bs_index, agent_index[bs_index, :]]
    tp_list = []
    pred_track_list = []
    for confidence_thr_index in confidence_thr:
        track_pred_mask = od_track_pred > confidence_thr_index
        track_gt_mask = od_track_gt_map == 1
        tp = torch.sum(track_pred_mask * track_gt_mask, dim=1, keepdim=True)
        valid_mask = od_track_gt_map != -1
        track_pred_mask = track_pred_mask * valid_mask
        pred_track = torch.sum(track_pred_mask, dim=1, keepdim=True)
        tp_list.append(tp)
        pred_track_list.append(pred_track)
    return torch.cat(tp_list, dim=1), torch.cat(pred_track_list, dim=1)


def cal_track_recall_obs(od_track_pred, od_track_gt, ego_trackable_agent_gt_mask, agent_index, confidence_thr):
    """cal_track_recall_obs."""
    agent_index = agent_index.to(dtype=torch.int32)
    od_track_gt[ego_trackable_agent_gt_mask == 0] = -1
    batch_size = od_track_pred.shape[0]
    od_track_gt_map = torch.zeros_like(od_track_pred)
    for bs_index in range(batch_size):
        od_track_gt_map[bs_index, :] = od_track_gt[bs_index, agent_index[bs_index, :]]
    tp_list = []
    pred_track_list = []
    for confidence_thr_index in confidence_thr:
        track_pred_mask = od_track_pred > confidence_thr_index
        track_gt_mask = od_track_gt_map == 1
        tp = torch.sum(track_pred_mask * track_gt_mask, dim=1, keepdim=True)
        gt_track = torch.sum(track_gt_mask, dim=1, keepdim=True)
        tp[gt_track == 1e-6] = 0
        tp_list.append(tp)
        pred_track_list.append(gt_track)
    return torch.cat(tp_list, dim=1), torch.cat(pred_track_list, dim=1)


def cal_track_recall_based_precision_obs(
    od_track_pred, od_track_gt, ego_trackable_agent_gt_mask, agent_index, precision_thr
):
    """cal_track_recall_based_precision_obs."""
    agent_index = agent_index.to(dtype=torch.int32)
    od_track_gt[ego_trackable_agent_gt_mask == 0] = -1
    batch_size = od_track_pred.shape[0]
    od_track_gt_map = torch.zeros_like(od_track_pred)
    for bs_index in range(batch_size):
        od_track_gt_map[bs_index, :] = od_track_gt[bs_index, agent_index[bs_index, :]]
    return od_track_pred, od_track_gt_map, precision_thr
