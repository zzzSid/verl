# -*- coding: utf-8 -*-
"""Astra Planner evaluation collision metrics."""
import torch

from tpp_onemodel.utils import vehicle_param
from tpp_onemodel.utils.collision_utils import sod_collision


C_OUTOFSIGHT_DIST = 1.0e6


def cal_ego_multi_circle_centers(
    ego_traj,
    egos_bbox_info,
    headings=None,
    circle_num=3,
):
    """Cal ego multi circle centers.

    Args:
        ego_traj: [B, 1, T_future, 2]
        egos_bbox_info: [B, T_past, 1, D_info]
        circle_num: int, should not less than 3
    """
    circle_num = max(3, circle_num)
    batch_size, _, future_step, dim = ego_traj.shape
    ego_bbox_info = egos_bbox_info[:, -1]  # [B, 1, D]
    circle_step = ego_bbox_info[:, :, 3] - ego_bbox_info[:, :, 4]  # length - width
    circle_step = torch.ones_like(circle_step) * (vehicle_param.ET5_length - vehicle_param.ET5_width_wo_mirror)

    if headings is None:
        ego_headings = _get_heading_from_traj(ego_traj)  # [B, 1, T_f - 1
    else:
        headings = torch.reshape(headings.squeeze(), (batch_size, future_step))
        ego_headings = headings[:, :-1].unsqueeze(1)  # [B, 1, T_f - 1]

    ego_headings = torch.reshape(ego_headings, [batch_size, 1, future_step - 1, 1, 1])
    sin_heading = torch.sin(ego_headings)
    cos_heading = torch.cos(ego_headings)
    # use multi circles to represent ego bounding box, default num: 3
    ego_traj = torch.reshape(ego_traj, (batch_size, 1, future_step, 1, dim))
    ego_traj = ego_traj[:, :, 1:]
    circle_step = torch.reshape(circle_step, [batch_size, 1, 1, 1, 1]).repeat(1, 1, future_step - 1, 1, 1)

    rear_offset = vehicle_param.ET5_length / 2.0 - vehicle_param.ET5_rear_overhang
    ego_points = [
        torch.concat(
            [
                (circle_step * (1 / 2 - i / (circle_num - 1)) + rear_offset) * cos_heading,
                (circle_step * (1 / 2 - i / (circle_num - 1)) + rear_offset) * sin_heading,
            ],
            dim=-1,
        )
        + ego_traj
        for i in range(circle_num)
    ]
    multi_ego_points = torch.concat(ego_points, dim=3)

    return multi_ego_points


def cal_multi_obs_multi_circle_centers(
    trajs,
    bbox_infos,
    circle_num=5,
):
    """Cal multi obs multi circle centers.

    Args:
        trajs: [B, A, T_future, 2]
        bbox_infos: [B, A, T_future, D_info]
        circle_num: int, should not less than 3
    """
    circle_num = max(3, circle_num)
    batch_size, agent_num, future_step, dim = trajs.shape
    circle_step = bbox_infos[:, :, 1:, 3] - bbox_infos[:, :, 1:, 4]  # length - width
    trajs = torch.reshape(trajs, (batch_size, agent_num, future_step, 1, dim))
    obj_headings = bbox_infos[:, :, 1:, 6]
    obj_headings = torch.reshape(obj_headings, (batch_size, agent_num, future_step - 1, 1, 1))
    sin_heading = torch.sin(obj_headings)
    cos_heading = torch.cos(obj_headings)
    # use multi circles to represent obs bounding box, default num: 5
    trajs = trajs[:, :, 1:]
    circle_step = torch.reshape(circle_step, (batch_size, agent_num, future_step - 1, 1, 1))
    obs_points = [
        torch.concat(
            [
                circle_step * (1 / 2 - i / (circle_num - 1)) * cos_heading,
                circle_step * (1 / 2 - i / (circle_num - 1)) * sin_heading,
            ],
            dim=-1,
        )
        + trajs
        for i in range(circle_num)
    ]

    multi_obs_points = torch.concat(obs_points, dim=3)

    return multi_obs_points


def get_sod_collision(
    sod_padding_mask,
    ego_pred_traj_output,
    sod_corners,
    sod_corners_padding_mask,
    marginal_ego_best_traj,
    egos,
    time_step,
    min=False,
):
    """Sod collision."""
    return sod_collision(
        sod_padding_mask,
        ego_pred_traj_output,
        sod_corners,
        sod_corners_padding_mask,
        marginal_ego_best_traj,
        egos,
        time_step,
        min,
    )


def obs_collision_rate(
    egos_pred_mask,
    egos_bbox_info,
    agent_bbox_infos,
    agent_gt_masks,
    ego_vel_pred,
    fde_mask,
    multi_ego_points,
    multi_obs_points,
    collision_thres=0.0,
    timestamp=30,
    low_speed_thres=1.0,
):
    """Obs collision rate for ego pred traj.

    Args:
        egos_pred_mask: [B, 1, T_future]
        egos_bbox_info: [B, T_past, 1, D]
        agent_bbox_infos: [B, A, T_future, D]
        agent_gt_masks: [B, A, T_future]
        fde_mask: [B, 1]
        multi_ego_points: [B, 1, T_future - 1, M_ego, 2]
        multi_obs_points: [B, A, T_future - 1, M_obs, 2]
        collision_thres: float
        timestamp: int, the num of pred point used
    """
    if fde_mask is None:
        return None, None

    batch_size, agent_num, future_step = agent_gt_masks.shape
    if timestamp > future_step:
        return None, None

    ego_bbox_info = egos_bbox_info[:, -1]  # [B, 1, D]
    agent_circle_num = multi_obs_points.shape[3]
    ego_circle_num = multi_ego_points.shape[3]

    obj_widths = agent_bbox_infos[:, :, 1:timestamp, 4]
    ego_widths = ego_bbox_info[:, :, 4].reshape(batch_size, 1, 1).repeat(1, agent_num, timestamp - 1)
    safe_distance = (obj_widths + ego_widths) / 2 + collision_thres
    safe_distance = torch.reshape(safe_distance, (batch_size, agent_num, timestamp - 1, 1))
    safe_distance = safe_distance.repeat(1, 1, 1, agent_circle_num * ego_circle_num)

    egos_pred_mask = torch.reshape(egos_pred_mask[:, :, 1:timestamp], (batch_size, 1, timestamp - 1, 1))
    egos_pred_mask = egos_pred_mask.repeat(1, agent_num, 1, agent_circle_num * ego_circle_num)

    agent_gt_masks = torch.reshape(agent_gt_masks[:, :, 1:timestamp], (batch_size, agent_num, timestamp - 1, 1))
    agent_gt_masks = agent_gt_masks.repeat(1, 1, 1, agent_circle_num * ego_circle_num)
    valid_mask = egos_pred_mask * agent_gt_masks

    multi_points_de_xy = multi_ego_points[:, :, : timestamp - 1].repeat(1, agent_num, 1, 1, 1).reshape(
        batch_size, agent_num, timestamp - 1, ego_circle_num, 1, 2
    ) - multi_obs_points[:, :, : timestamp - 1].reshape(batch_size, agent_num, timestamp - 1, 1, agent_circle_num, 2)

    multi_points_de_xy[
        :, :, :, ego_circle_num - 1, 0, :
    ] += C_OUTOFSIGHT_DIST  # rear ended accident, the last circle of ego, the first circle of obs
    # no liability for rear ended accident at low speed
    if ego_vel_pred is not None:
        multi_points_de_xy[:, :, :, 2, :, :] += (
            torch.norm(ego_vel_pred.squeeze(1)[:, : timestamp - 1], dim=-1) < low_speed_thres
        ).reshape(batch_size, 1, timestamp - 1, 1, 1,).repeat(1, agent_num, 1, agent_circle_num, 2) * C_OUTOFSIGHT_DIST

    multi_points_de_xy = multi_points_de_xy.reshape(batch_size, agent_num, timestamp - 1, -1, 2)
    multi_points_de_sq = multi_points_de_xy[:, :, :, :, 0] ** 2 + multi_points_de_xy[:, :, :, :, 1] ** 2

    has_collision_check = (safe_distance * safe_distance > multi_points_de_sq) * valid_mask
    has_collision_check = torch.reshape(has_collision_check, [batch_size, -1])
    has_collision_check = has_collision_check.bool().any(-1, keepdim=True)
    return has_collision_check, fde_mask  # [B, 1], [B, 1]


def lane_boundary_collision_rate(selected_trajs_pred, bboxes_info, lane_points, lane_types, fde_mask, timestamp):
    """Lane boundary collision rate.

    Args:
        selected_trajs_pred: [B, A, T_future, 2]
        bboxes_info: [B, T_past, A, D], D == 40
        lane_points: [B, N, M, 2]
        lane_types: [B, N, M]
        fde_mask: [B, A]
        timestamp:  int, the num of pred point used
        A == 1 if ego
    """
    if fde_mask is None:
        return None, None

    batch_size, agent_num, future_step, _ = selected_trajs_pred.shape
    if timestamp > future_step:
        return None, None

    speed = torch.norm(bboxes_info[:, -1, :, 10:12], dim=-1)  # [B, A]
    bboxes_size = bboxes_info[:, -1, :, 3:5]  # [B, A, 2], 2 for length and width
    traj_headings = _get_heading_from_traj(selected_trajs_pred[:, :, :timestamp, :])  # [B, A, T-1]
    traj_rotated_bbox = _rotate_bbox(bboxes_size, traj_headings)  # [B, A, T-1, 2]

    # calculate collision
    lane_points_expanded = lane_points.unsqueeze(1).unsqueeze(3)  # [B, 1, N, 1, M, 2]
    bbox_half = traj_rotated_bbox / 2  # [B, A, T-1, 2]
    trajs_expanded_centers = selected_trajs_pred[:, :, 1:timestamp, :].unsqueeze(2)  # [B, A, 1, T-1, 2]
    xmin = trajs_expanded_centers[..., 0] - bbox_half[..., 0].unsqueeze(2)  # [B, A, 1, T-1]
    xmax = trajs_expanded_centers[..., 0] + bbox_half[..., 0].unsqueeze(2)  # [B, A, 1, T-1]
    ymin = trajs_expanded_centers[..., 1] - bbox_half[..., 1].unsqueeze(2)  # [B, A, 1, T-1]
    ymax = trajs_expanded_centers[..., 1] + bbox_half[..., 1].unsqueeze(2)  # [B, A, 1, T-1]

    lane_points_x = lane_points_expanded[..., 0]  # [B, 1, N, 1, M]
    lane_points_y = lane_points_expanded[..., 1]  # [B, 1, N, 1, M]

    within_x = (lane_points_x >= xmin.unsqueeze(-1)) & (lane_points_x <= xmax.unsqueeze(-1))  # [B, A, N, T-1, M]
    within_y = (lane_points_y >= ymin.unsqueeze(-1)) & (lane_points_y <= ymax.unsqueeze(-1))  # [B, A, N, T-1, M]

    road_edge_mask = (lane_types == 1).unsqueeze(-2).unsqueeze(1)  # [B, 1, N, 1, M] valid 1 represent boundary
    collision = (within_x & within_y) * road_edge_mask  # [B, A, N, T-1, M]
    collision = collision.any(-1)  # M points in one line [B, A, N, T-1]
    collision = collision.any(-2)  # N lines fuse [B, A, T-1]
    collision = collision.any(-1)  # future step fuse [B, A]

    speed_mask = speed > 1  # [B, A]

    traj_collision = collision * speed_mask * fde_mask

    return traj_collision, speed_mask * fde_mask  # [B, A], [B, A]


def unsafe_area_collision_rate(selected_trajs_pred, bboxes_info, atlas, fde_mask, timestamp):
    """Unsafe area collision rate.

    Args:
        selected_trajs_pred: [B, A, T_future, 2]
        bboxes_info: [B, T_past, A, D], D == 40
        atlas: [B, N, M, 3]
        fde_mask: [B, A]
        timestamp:  int, the num of pred point used
        A == 1 if ego
    """
    if fde_mask is None:
        return None, None
    batch_size, agent_num, future_step, _ = selected_trajs_pred.shape
    if timestamp > future_step:
        return None, None
    bboxes_size = bboxes_info[:, -1, :, 3:5]  # [B, A, 2], 2 for length and width
    traj_headings = _get_heading_from_traj(selected_trajs_pred[:, :, :timestamp, :])  # [B, A, T-1]
    traj_rotated_bbox = _rotate_bbox(bboxes_size, traj_headings)  # [B, A, T-1, 2]

    # calculate collision
    bbox_half = traj_rotated_bbox / 2  # [B, A, T-1, 2]
    trajs_expanded_centers = selected_trajs_pred[:, :, 1:timestamp, :].unsqueeze(2)  # [B, A, 1, T-1, 2]
    xmin = trajs_expanded_centers[..., 0] - bbox_half[..., 0].unsqueeze(2)  # [B, A, 1, T-1]
    xmax = trajs_expanded_centers[..., 0] + bbox_half[..., 0].unsqueeze(2)  # [B, A, 1, T-1]
    ymin = trajs_expanded_centers[..., 1] - bbox_half[..., 1].unsqueeze(2)  # [B, A, 1, T-1]
    ymax = trajs_expanded_centers[..., 1] + bbox_half[..., 1].unsqueeze(2)  # [B, A, 1, T-1]

    ufa_typeid = 1
    ufa_points = atlas[:, :, :, :2]
    ufa_points_expanded = ufa_points.unsqueeze(1).unsqueeze(3)  # [B, 1, N, 1, M, 2]
    ufa_points_x = ufa_points_expanded[..., 0]  # [B, 1, N, 1, M]
    ufa_points_y = ufa_points_expanded[..., 1]  # [B, 1, N, 1, M]
    within_x = (ufa_points_x >= xmin.unsqueeze(-1)) & (ufa_points_x <= xmax.unsqueeze(-1))  # [B, A, N, T-1, M]
    within_y = (ufa_points_y >= ymin.unsqueeze(-1)) & (ufa_points_y <= ymax.unsqueeze(-1))  # [B, A, N, T-1, M]

    ufa_mask = (atlas[:, :, :, 2] == ufa_typeid).unsqueeze(-2).unsqueeze(1)  # [B, 1, N, 1, M]
    collision = (within_x & within_y) * ufa_mask  # [B, A, N, T-1, M]
    collision = collision.any(-1)  # M points in one line [B, A, N, T-1]
    collision = collision.any(-2)  # N lines fuse [B, A, T-1]
    collision = collision.any(-1)  # future step fuse [B, A]

    speed = torch.norm(bboxes_info[:, -1, :, 10:12], dim=-1)  # [B, A]
    speed_mask = speed >= 2.7  # [B, A]
    traj_collision = collision * speed_mask * fde_mask
    return traj_collision, speed_mask * fde_mask  # [B, A], [B, A]


def unsafe_area_except_lane_collision_rate(
    selected_trajs_pred, bboxes_info, atlas, lane_points, lane_types, fde_mask, timestamp
):
    """Unsafe area collision rate.

    Args:
        selected_trajs_pred: [B, A, T_future, 2]
        bboxes_info: [B, T_past, A, D], D == 40
        atlas: [B, N, M, 3]
        fde_mask: [B, A]
        timestamp:  int, the num of pred point used
        A == 1 if ego
    """
    if fde_mask is None:
        return None, None
    batch_size, agent_num, future_step, _ = selected_trajs_pred.shape
    if timestamp > future_step:
        return None, None
    bboxes_size = bboxes_info[:, -1, :, 3:5]  # [B, A, 2], 2 for length and width
    traj_headings = _get_heading_from_traj(selected_trajs_pred[:, :, :timestamp, :])  # [B, A, T-1]
    traj_rotated_bbox = _rotate_bbox(bboxes_size, traj_headings)  # [B, A, T-1, 2]

    # calculate collision
    bbox_half = traj_rotated_bbox / 2  # [B, A, T-1, 2]
    trajs_expanded_centers = selected_trajs_pred[:, :, 1:timestamp, :].unsqueeze(2)  # [B, A, 1, T-1, 2]
    xmin = trajs_expanded_centers[..., 0] - bbox_half[..., 0].unsqueeze(2)  # [B, A, 1, T-1]
    xmax = trajs_expanded_centers[..., 0] + bbox_half[..., 0].unsqueeze(2)  # [B, A, 1, T-1]
    ymin = trajs_expanded_centers[..., 1] - bbox_half[..., 1].unsqueeze(2)  # [B, A, 1, T-1]
    ymax = trajs_expanded_centers[..., 1] + bbox_half[..., 1].unsqueeze(2)  # [B, A, 1, T-1]

    # unsafe area collision
    ufa_typeid = 1
    ufa_points = atlas[:, :, :, :2]
    ufa_points_expanded = ufa_points.unsqueeze(1).unsqueeze(3)  # [B, 1, N, 1, M, 2]
    ufa_points_x = ufa_points_expanded[..., 0]  # [B, 1, N, 1, M]
    ufa_points_y = ufa_points_expanded[..., 1]  # [B, 1, N, 1, M]
    within_x = (ufa_points_x >= xmin.unsqueeze(-1)) & (ufa_points_x <= xmax.unsqueeze(-1))  # [B, A, N, T-1, M]
    within_y = (ufa_points_y >= ymin.unsqueeze(-1)) & (ufa_points_y <= ymax.unsqueeze(-1))  # [B, A, N, T-1, M]

    ufa_mask = (atlas[:, :, :, 2] == ufa_typeid).unsqueeze(-2).unsqueeze(1)  # [B, 1, N, 1, M]
    ufa_collision = (within_x & within_y) * ufa_mask  # [B, A, N, T-1, M]
    ufa_collision = ufa_collision.any(-1)  # M points in one line [B, A, N, T-1]
    ufa_collision = ufa_collision.any(-2)  # N lines fuse [B, A, T-1]
    ufa_collision = ufa_collision.any(-1)  # future step fuse [B, A]

    # lane collision
    lane_points_expanded = lane_points.unsqueeze(1).unsqueeze(3)  # [B, 1, N, 1, M, 2]
    lane_points_x = lane_points_expanded[..., 0]  # [B, 1, N, 1, M]
    lane_points_y = lane_points_expanded[..., 1]  # [B, 1, N, 1, M]
    within_x = (lane_points_x >= xmin.unsqueeze(-1)) & (lane_points_x <= xmax.unsqueeze(-1))  # [B, A, N, T-1, M]
    within_y = (lane_points_y >= ymin.unsqueeze(-1)) & (lane_points_y <= ymax.unsqueeze(-1))  # [B, A, N, T-1, M]

    road_edge_mask = (lane_types == 1).unsqueeze(-2).unsqueeze(1)  # [B, 1, N, 1, M] valid 1 represent boundary
    lane_collision = (within_x & within_y) * road_edge_mask  # [B, A, N, T-1, M]
    lane_collision = lane_collision.any(-1)  # M points in one line [B, A, N, T-1]
    lane_collision = lane_collision.any(-2)  # N lines fuse [B, A, T-1]
    lane_collision = lane_collision.any(-1)  # future step fuse [B, A]

    speed = torch.norm(bboxes_info[:, -1, :, 10:12], dim=-1)  # [B, A]
    speed_mask = speed >= 2.7  # [B, A]
    traj_collision = (ufa_collision & (~lane_collision)) * speed_mask * fde_mask
    return traj_collision, speed_mask * fde_mask  # [B, A], [B, A]


def _get_heading_from_traj(trajs):
    """Get heading from trajs.

    Args:
        trajs: [B, A, T, 2]
    """
    delta = trajs[:, :, 1:, :] - trajs[:, :, :-1, :]
    headings = torch.atan2(delta[..., 1], delta[..., 0])  # [B, A, T-1]
    return headings


def _rotate_bbox(agents_size, headings):
    """Get future rotated bbox.

    Args:
        agents_size: [B, A, 2]
        headings: [B, A, T]
    """
    batch_size, agent_num, future_step = headings.shape

    cos_h = torch.cos(headings)  # [B, A, T]
    sin_h = torch.sin(headings)  # [B, A, T]

    # [B, A, T, 2, 2]
    rotation_matrices = torch.stack([cos_h, -sin_h, sin_h, cos_h], dim=-1).view(
        batch_size, agent_num, future_step, 2, 2
    )

    # size: [B, A, 2] -> [B, A, T, 2, 1]
    size_expanded = agents_size[:, :, None, :, None].expand(batch_size, agent_num, future_step, -1, -1)

    # Rotated bounding box vertices
    rotated_bbox = torch.matmul(rotation_matrices, size_expanded)  # [B, A, T, 2, 1]
    return rotated_bbox.squeeze(-1)  # [B, A, T, 2]


if __name__ == "__main__":
    B = 2
    A = 50
    T_f = 30
    T_p = 15
    D = 40
    N = 10
    M = 20

    # cal_metrics_output["marginal_ego_min_fde_traj"].shape
    # torch.Size([4, 1, 30, 2])
    # cal_metrics_output["egos_pred_gt"].shape
    # torch.Size([4, 1, 30, 2])
    # cal_metrics_output["bboxes_pred_gt"].shape
    # torch.Size([4, 191, 30, 2])
    # cal_metrics_input["bboxes_pred_gt"].shape
    # torch.Size([4, 191, 30, 2])
    # cal_metrics_input["egos_pred_mask"].shape
    # torch.Size([4, 1, 30])
    # cal_metrics_output["ego_pred_traj_output"].shape
    # torch.Size([4, 1, 6, 61])
    # cal_metrics_input["bboxes_pred_mask"].shape
    # torch.Size([4, 191, 30])
    # cal_metrics_input["egos"].shape
    # torch.Size([4, 15, 1, 15])

    trajs = torch.rand([B, A, T_f, 2])  # v bboxes_pred_gt
    traj_mask = torch.ones([B, A, T_f])  # v bboxes_pred_mask
    ego_trajs = torch.rand([B, 1, T_f, 2])  # v marginal_ego_min_fde_traj
    ego_traj_mask = torch.ones([B, 1, T_f])  # v egos_pred_mask

    bboxes = torch.rand([B, A, T_f, D])  # v bboxes_det_pred_full_info_gt
    past_bboxes = torch.rand([B, T_p, A, D])
    ego_bboxes = torch.rand([B, T_p, 1, D])  # v egos
    bboxes[:, :, :, 10:12] = torch.tensor([2.0, 3.0])
    bboxes[:, :, :, 3:5] = torch.tensor([5.5, 2.6])
    past_bboxes[:, :, :, 10:12] = torch.tensor([5.5, 2.6])
    past_bboxes[:, :, :, 3:5] = torch.tensor([5.5, 2.6])
    # ego_bboxes[:, :, :, 10: 12] = torch.tensor([2.0, 3.0])
    # ego_bboxes[:, :, :, 3: 5] = torch.tensor([5.5, 2.6])

    lane_p = torch.rand([B, N, M, 2])
    lane_t = torch.ones([B, N, M])

    # res = lane_boundary_collision_rate(trajs, past_bboxes, lane_p, lane_t)
    # ego_res = lane_boundary_collision_rate(ego_trajs, ego_bboxes, lane_p, lane_t)
    ego_points = cal_ego_multi_circle_centers(ego_trajs, ego_bboxes, 5)
    obs_points = cal_multi_obs_multi_circle_centers(trajs, bboxes, 7)
    # collision = obs_collision_rate(ego_traj_mask, ego_bboxes, bboxes, traj_mask, ego_points, obs_points)

    # print(res)
    # print(ego_res)
    # print(collision)
