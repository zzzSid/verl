# -*- coding: utf-8 -*-
"""Astra Planner Lateral Incentive metrics."""
import torch

from tpp_onemodel.evaluator.metric.frenet_metrics import get_frenet_result


def cal_lateral_incentive(da_tag, gt, pred_traj, threshold=0.1, timestamp=30, chose_best=False):
    """Calculate odometry metric.

    Args:
        da_tag:
        pred_traj: (B, 1, K, T, 2)
        gt: (B, 1, T, 2)
        gt_mask: (B, 1, T)

    Return: ()
    """
    valid_l = torch.zeros(pred_traj.shape[0], 1)
    valid_mask = torch.zeros([pred_traj.shape[0], 1])

    if chose_best:
        for mode in range(pred_traj.shape[2]):
            cur_traj = pred_traj[:, :, mode, :, :]
            delta_metric = get_frenet_result(cur_traj, gt, timestamp=timestamp)
            valid_l[:, mode : (mode + 1)] = delta_metric[1]
            valid_mask[:, mode : (mode + 1)] = delta_metric[2]
    else:
        cur_traj = pred_traj[:, :, 0, :, :]
        delta_metric = get_frenet_result(cur_traj, gt, timestamp=timestamp)
        valid_l[:, 0:1] = delta_metric[1]
        valid_mask[:, 0:1] = delta_metric[2]

    more_active = torch.zeros((pred_traj.shape[0], 1), dtype=pred_traj.dtype)
    all_mask = torch.ones((pred_traj.shape[0], 1), dtype=pred_traj.dtype)

    for b in range(pred_traj.shape[0]):
        is_left_change, is_right_change = False, False
        for tag in da_tag[b]:
            if tag == "astra_planner.fft_hw.sidepass.lanechange_left":
                is_left_change = True
            if tag == "astra_planner.fft_hw.sidepass.lanechange_right":
                is_right_change = True

        if is_left_change:
            more_active[b, 0] = (((valid_l[b] > threshold).float() * valid_mask[b].float()) > 0).float()
        elif is_right_change:
            more_active[b, 0] = (((valid_l[b] < -threshold).float() * valid_mask[b].float()) > 0).float()
        else:
            more_active[b, 0] = 0.0
            all_mask[b, 0] = 0.0
    return more_active, all_mask
