# -*- coding: utf-8 -*-
"""Astra Planner evaluation navi lane metrics."""
import torch


def get_navi_nearest_dist(
    navi_line_points,
    navi_line_types,
    selected_traj_pred_all,
):
    """Get the nearest distance to navi lane.

    Args:
        navi_line_points (torch.Tensor): The coordinates of the navigation lane points. Shape: [B, N, M, 2].
        navi_line_types (torch.Tensor): The types of the navigation lane points. Shape: [B, N, M].
        selected_traj_pred_all (torch.Tensor): The predicted trajectories for all agents. Shape: [batch_size,A, k, T, 2].

    Returns:
        nearest_dist_to_navi (torch.Tensor): The nearest distance from each trajectory to the navigation lane. Shape: [B, K, T].
    """
    if (navi_line_types == -1).all():
        return -torch.ones(
            selected_traj_pred_all.shape[0], selected_traj_pred_all.shape[2], selected_traj_pred_all.shape[3]
        )
    if len(selected_traj_pred_all.shape) == 4:
        selected_traj_pred_all = selected_traj_pred_all.unsqueeze(2)  # [B,A,k=1,T,2]
    batch_size = navi_line_points.shape[0]
    navi_line_mask = navi_line_types != -1  # valid = 1

    navi_line_points = navi_line_points.reshape(batch_size, -1, 2)  # [B,N*M,2]
    navi_line_mask = navi_line_mask.reshape(batch_size, -1)  # [B,N*M]

    masked_traj_ego = selected_traj_pred_all[:, -1]  # [batch_size,k,T,2]
    ego_dist_to_navi = masked_traj_ego[:, :, :, None, :] - navi_line_points[:, None, None, ...]  # [B,K,T,N*M,2]
    navi_line_mask_expanded = navi_line_mask[:, None, None, ..., None].float()  # [B,1,1,N*M,1]
    ego_dist_to_navi = ego_dist_to_navi + (1 - navi_line_mask_expanded) * 1e6  # [B,K,T,N*M,2]
    nearest_dist_to_navi = torch.norm(ego_dist_to_navi, dim=-1).min(dim=-1).values  # [B,K,T]
    return nearest_dist_to_navi  # [B,K,T]


def get_navi_missing_rate(
    egos_pred_mask,
    gt_navi_dist_s,
    gt_navi_dist_l,
    traj_navi_dist_s,
    traj_navi_dist_l,
    navi_point_mask,
    navi_line_valid_mask,
    navi_miss_rate_threshold=1.0,
    timestamp=70,
    topk=False,
):
    """Get the navigation missing rate.

    This function calculates the navigation missing rate, which represents the percentage of trajectories that are
    missing the navigation lane. It takes the following inputs:

    Args:
        nearest_dist_to_navi (torch.Tensor): The nearest distance from each trajectory to the navigation lane. Shape: [B, K, T].
        egos_pred_mask (torch.Tensor): The mask indicating the presence of the ego agent in each trajectory. Shape: [B, 1, T].
        navi_miss_rate_threshold (float): The threshold distance for considering a trajectory missing the navigation lane.
        timestamp (int): Target timestamp.

    Returns:
        navi_missing_rate (torch.Tensor): The navigation missing rate for each trajectory. Shape: [B, K, T].
    """
    # print(1)
    if egos_pred_mask.shape[-1] < timestamp or (navi_point_mask == 0).all() or (navi_line_valid_mask == 0).all():
        return None, None
    navi_missing_rate = (traj_navi_dist_l > navi_miss_rate_threshold).float()  # [B,M,T]
    gt_navi_missing_rate = (gt_navi_dist_l > navi_miss_rate_threshold).float()  # [B,M,T]
    navi_missing_rate = (navi_missing_rate * (1 - gt_navi_missing_rate) * egos_pred_mask)[..., 0:timestamp]  # [B,M,T]
    navi_missing_rate = navi_missing_rate * navi_line_valid_mask[..., None]  # [B,M,T]
    if topk:
        navi_missing_rate = navi_missing_rate.any(-1).any(-1).float()[:, None]  # [B,1]
    else:  # top1
        navi_missing_rate = navi_missing_rate.any(-1)[:, 0:1].float()  # [B,1]
    return navi_missing_rate, egos_pred_mask[:, :, timestamp - 1] * (navi_line_valid_mask.sum(-1) > 0)[..., None]


def test_get_navi_missing_rate():
    """Test get_navi_missing_rate."""
    B = 4  # noqa: N806
    A = 17  # noqa: N806
    N = 10  # noqa: N806
    M = 15  # noqa: N806
    k = 6
    T = 30  # noqa: N806

    navi_line_points = torch.rand([B, N, M, 2])
    navi_line_types = torch.rand([B, N, M])
    selected_traj_pred_all = torch.rand([B, A, k, T, 2])
    egos_pred_mask = torch.rand([B, 1, T])
    navi_miss_rate_threshold = 1.0

    nearest_dist_to_navi = get_navi_nearest_dist(
        navi_line_points,
        navi_line_types,
        selected_traj_pred_all,
    )
    navi_missing_rate = get_navi_missing_rate(nearest_dist_to_navi, egos_pred_mask, navi_miss_rate_threshold)

    assert navi_missing_rate.shape == (B, k, T), f"navi_missing_rate shape mismatch: {navi_missing_rate.shape}"
    assert nearest_dist_to_navi.shape == (B, k, T), f"nearest_dist_to_navi shape mismatch: {nearest_dist_to_navi.shape}"
    assert torch.all(navi_missing_rate >= 0) and torch.all(
        navi_missing_rate <= 1
    ), "navi_missing_rate values out of range"
    assert torch.all(nearest_dist_to_navi >= 0), "nearest_dist_to_navi values out of range"


if __name__ == "__main__":
    test_get_navi_missing_rate()
