# -*- coding: utf-8 -*-
"""Astra Planner evaluation efficiency metrics."""
import torch


def calc_ego_odometry(sorted_traj_pred):
    """Calculate odometry metric.

    Args: (B, 1, K, T, 2)
    Return: (B, K, T)
    """
    pred_step_distance = torch.norm(
        sorted_traj_pred[:, :, :, 1:] - sorted_traj_pred[:, :, :, :-1], dim=-1
    )  # (B, 1, K, T-1)
    pred_pre_padding = torch.norm(sorted_traj_pred[:, :, :, 0], dim=-1).unsqueeze(-1)
    pred_step_distance = torch.cat([pred_pre_padding, pred_step_distance], dim=-1)  # (B, 1, K, T)
    pred_odometry = torch.cumsum(pred_step_distance, dim=-1).squeeze(1)  # (B, K, T)
    return pred_odometry


def calc_gt_odometry(traj_gt):
    """GT odom.

    Args: (B, 1, T, 2)
    Return: (B, 1, T)
    """
    gt_step_distance = torch.norm(traj_gt[:, :, 1:] - traj_gt[:, :, :-1], dim=-1).unsqueeze(1)  # (B, 1, 1, T-1)
    gt_pre_padding = torch.norm(traj_gt[:, :, 0], dim=-1).unsqueeze(1).unsqueeze(-1)
    gt_step_distance = torch.cat([gt_pre_padding, gt_step_distance], dim=-1)  # (B, 1, 1, T)
    gt_odometry = torch.cumsum(gt_step_distance, dim=-1).squeeze(1)  # (B, 1, T)
    return gt_odometry


def best_traj_odometry_metric(fde_mask, pred_odometry, tgt_timestamp=30):
    """Odom of best traj.

    Args: (B, K, T)
    Return: (B, 1)
    """
    batch_size, _, future_length = pred_odometry.shape
    if tgt_timestamp > future_length:
        return torch.zeros(batch_size, 1), torch.zeros(batch_size, 1)

    res = pred_odometry[:, 0, tgt_timestamp - 1].unsqueeze(1)  # Input sorted, first is best. Default use last frame.
    return res, torch.ones_like(res) * fde_mask


def min_odometry_metric(fde_mask, pred_odometry, tgt_timestamp=30):
    """Min odom.

    Args: (B, K, T)
    Return: (B, 1)
    """
    batch_size, _, future_length = pred_odometry.shape
    if tgt_timestamp > future_length:
        return torch.zeros(batch_size, 1), torch.zeros(batch_size, 1)

    res = pred_odometry[:, :, tgt_timestamp - 1].min(dim=1)[0].unsqueeze(1)
    return res, torch.ones_like(res) * fde_mask


def gt_odometry_metric(fde_mask, gt_odometry, tgt_timestamp=30):
    """Gt odom.

    Args: (B, 1, T)
    Return: (B, 1)
    """
    batch_size, _, future_length = gt_odometry.shape
    if tgt_timestamp > future_length:
        return torch.zeros(batch_size, 1), torch.zeros(batch_size, 1)

    res = gt_odometry[:, 0, tgt_timestamp - 1].unsqueeze(1)
    return res, torch.ones_like(res) * fde_mask


def calc_reference_speed(v_limit):
    """Calc ego ref spd and mask.

    Args:
        v_limit: (B, 8)
    Returns:
        reference_speed: (B, )
        mask_no_limit_info: (B, )
    """
    # Get Reference Speed
    road_speed, camera_speed, other_speed = v_limit[:, 1], v_limit[:, 2], v_limit[:, 3]

    reference_speed = torch.zeros_like(camera_speed)

    # Condition 1: Use camera speed if it's not zero
    mask_camera_speed = camera_speed != 0
    reference_speed[mask_camera_speed] = camera_speed[mask_camera_speed]

    # Condition 2: Use average of non-zero road and other speed limits if camera speed is zero
    mask_average_speed = camera_speed == 0
    non_zero_road_speed = road_speed.clone()
    non_zero_road_speed[non_zero_road_speed == 0] = float("nan")
    non_zero_other_speed = other_speed.clone()
    non_zero_other_speed[non_zero_other_speed == 0] = float("nan")

    average_speed = torch.nanmean(torch.stack([non_zero_road_speed, non_zero_other_speed]), dim=0)
    reference_speed[mask_average_speed] = average_speed[mask_average_speed]

    mask_no_limit_info = (camera_speed == 0) & (road_speed == 0) & (other_speed == 0)

    return reference_speed, mask_no_limit_info


def best_traj_time_to_vref(
    ego_pred_gt_mask, fde_mask, reference_speed_tuple, pred_odometry, tgt_timestamp=30, acc_time_max=60.0
):
    """Best traj time to verf.

    Args:
        ego_pred_gt_mask: (B, K, T)
        pred_odometry: (B, 1, T)
    Return:
        ego_time_to_vref: (B, 1)
        time_to_vref_mask: (B, 1)
    """
    batch_size, _, gt_length = ego_pred_gt_mask.shape
    if tgt_timestamp > gt_length:
        return torch.zeros(batch_size, 1), torch.zeros(batch_size, 1)
    if tgt_timestamp > pred_odometry.shape[-1]:
        return torch.zeros(batch_size, 1), torch.zeros(batch_size, 1)

    reference_speed, mask_no_limit_info = reference_speed_tuple  # (B, ), (B, )
    time_to_vref_mask = torch.logical_not(mask_no_limit_info) * ego_pred_gt_mask[:, 0, tgt_timestamp - 1]

    time_step = 0.1
    if batch_size == 1:
        ego_approx_speed = torch.gradient(pred_odometry.squeeze(0), spacing=time_step, dim=-1)[0].unsqueeze(
            0
        )  # (B, K, T)
        ego_approx_acceleration = torch.gradient(ego_approx_speed.squeeze(0), spacing=time_step, dim=-1)[0].unsqueeze(
            0
        )  # (B, K, T)
    else:
        ego_approx_speed = torch.gradient(pred_odometry, spacing=time_step, dim=-1)[0]  # (B, K, T)
        ego_approx_acceleration = torch.gradient(ego_approx_speed, spacing=time_step, dim=-1)[0]  # (B, K, T)

    ego_end_point_speed = ego_approx_speed[:, :, tgt_timestamp - 1]  # (B, K)
    ego_mean_pred_acc = torch.mean(ego_approx_acceleration[:, :, :tgt_timestamp], dim=-1).clamp(min=1e-6)  # (B, K)
    ego_time_to_vref = ((reference_speed.unsqueeze(1) - ego_end_point_speed) / ego_mean_pred_acc).clamp(
        min=0.0
    )  # (B, K)

    best_traj_time_to_vref = ego_time_to_vref[:, 0].clamp(max=acc_time_max)  # (B,)

    return best_traj_time_to_vref.unsqueeze(1), time_to_vref_mask.unsqueeze(1) * fde_mask


def min_time_to_vref(
    ego_pred_gt_mask, fde_mask, reference_speed_tuple, pred_odometry, tgt_timestamp=30, acc_time_max=60.0
):
    """Min traj time to verf.

    Args:
        ego_pred_gt_mask: (B, K, T)
        pred_odometry: (B, 1, T)
    Return:
        ego_time_to_vref_k: (B, 1)
        time_to_vref_mask: (B, 1)
    """
    batch_size, _, gt_length = ego_pred_gt_mask.shape
    if tgt_timestamp > gt_length:
        return torch.zeros(batch_size, 1), torch.zeros(batch_size, 1)
    if tgt_timestamp > pred_odometry.shape[-1]:
        return torch.zeros(batch_size, 1), torch.zeros(batch_size, 1)

    reference_speed, mask_no_limit_info = reference_speed_tuple  # (B, ), (B, )
    time_to_vref_mask = torch.logical_not(mask_no_limit_info) * ego_pred_gt_mask[:, 0, tgt_timestamp - 1]

    time_step = 0.1
    if batch_size == 1:
        ego_approx_speed = torch.gradient(pred_odometry.squeeze(0), spacing=time_step, dim=-1)[0].unsqueeze(
            0
        )  # (B, K, T)
        ego_approx_acceleration = torch.gradient(ego_approx_speed.squeeze(0), spacing=time_step, dim=-1)[0].unsqueeze(
            0
        )  # (B, K, T)
    else:
        ego_approx_speed = torch.gradient(pred_odometry, spacing=time_step, dim=-1)[0]  # (B, K, T)
        ego_approx_acceleration = torch.gradient(ego_approx_speed, spacing=time_step, dim=-1)[0]  # (B, K, T)
    ego_end_point_speed = ego_approx_speed[:, :, tgt_timestamp - 1]  # (B, K)
    ego_mean_pred_acc = torch.mean(ego_approx_acceleration[:, :, :tgt_timestamp], dim=-1).clamp(min=1e-6)  # (B, K)
    ego_time_to_vref = ((reference_speed.unsqueeze(1) - ego_end_point_speed) / ego_mean_pred_acc).clamp(
        min=0.0
    )  # (B, K)

    min_time_to_vref = ego_time_to_vref.min(dim=1)[0].clamp(max=acc_time_max)  # (B,)

    return min_time_to_vref.unsqueeze(1), time_to_vref_mask.unsqueeze(1) * fde_mask


def gt_time_to_vref(
    ego_pred_gt_mask, fde_mask, reference_speed_tuple, gt_odometry, tgt_timestamp=30, acc_time_max=60.0
):
    """Gt time to ref spd.

    Args:
        ego_pred_gt_mask: (B, K, T)
        gt_odometry: (B, 1, T)
    Return:
        gt_time_to_vref: (B, 1)
        gt_time_to_vref_mask: (B, 1)
    """
    batch_size, _, gt_length = ego_pred_gt_mask.shape
    if tgt_timestamp > gt_length:
        return torch.zeros(batch_size, 1), torch.zeros(batch_size, 1)
    if tgt_timestamp > gt_odometry.shape[-1]:
        return torch.zeros(batch_size, 1), torch.zeros(batch_size, 1)

    reference_speed, mask_no_limit_info = reference_speed_tuple  # (B, ), (B, )
    time_step = 0.1

    if batch_size == 1:
        gt_approx_speed = torch.gradient(gt_odometry.squeeze(1).squeeze(0), spacing=time_step, dim=-1)[0].unsqueeze(
            0
        )  # (B, T)
        gt_approx_acceleration = torch.gradient(gt_approx_speed.squeeze(0), spacing=time_step, dim=-1)[0].unsqueeze(
            0
        )  # (B, T)
    else:
        gt_approx_speed = torch.gradient(gt_odometry.squeeze(1), spacing=time_step, dim=-1)[0]  # (B, T)
        gt_approx_acceleration = torch.gradient(gt_approx_speed, spacing=time_step, dim=-1)[0]  # (B, T)

    gt_time_to_vref_mask = torch.logical_not(mask_no_limit_info) * ego_pred_gt_mask[:, 0, tgt_timestamp - 1]  # (B, )

    gt_end_point_speed = gt_approx_speed[:, tgt_timestamp - 1]  # (B, )
    gt_mean_pred_acc = torch.mean(gt_approx_acceleration[:, :tgt_timestamp], dim=-1).clamp(min=1e-6)  # (B, )
    gt_time_to_vref = ((reference_speed - gt_end_point_speed) / gt_mean_pred_acc).clamp(min=0.0, max=acc_time_max)

    return gt_time_to_vref.unsqueeze(1), gt_time_to_vref_mask.unsqueeze(1) * fde_mask
