# -*- coding: utf-8 -*-
"""Prediction evaluation metrics config."""
# todo: import all metric/util func
from tpp_onemodel.evaluator.metric.basic_metrics import cal_accuracy
from tpp_onemodel.evaluator.metric.basic_metrics import cal_ade_1
from tpp_onemodel.evaluator.metric.basic_metrics import cal_ade_k
from tpp_onemodel.evaluator.metric.basic_metrics import cal_dist_mask
from tpp_onemodel.evaluator.metric.basic_metrics import cal_fde_1
from tpp_onemodel.evaluator.metric.basic_metrics import cal_fde_k
from tpp_onemodel.evaluator.metric.basic_metrics import cal_fde_mask
from tpp_onemodel.evaluator.metric.basic_metrics import cal_l2_dist
from tpp_onemodel.evaluator.metric.basic_metrics import cal_mr_1
from tpp_onemodel.evaluator.metric.basic_metrics import cal_mr_k
from tpp_onemodel.evaluator.metric.od_prior_metric import (
    cal_prior_precision_based_recall_obs,
)
from tpp_onemodel.evaluator.metric.od_prior_metric import cal_prior_precision_obs
from tpp_onemodel.evaluator.metric.od_prior_metric import cal_prior_recall_obs
from tpp_onemodel.evaluator.metric.od_track_metric import cal_track_precision_obs
from tpp_onemodel.evaluator.metric.od_track_metric import (
    cal_track_recall_based_precision_obs,
)
from tpp_onemodel.evaluator.metric.od_track_metric import cal_track_recall_obs


MISSING_DISTANCE_THRES = 2.0
NAVI_MISSING_RATE_THRESH = 2
TIMESTAMP_70 = 35
TIMESTAMP_30 = 15
TIMESTAMP_10 = 5
Freq = 5
Dt = 1 / Freq
PRORITY_THRES = [0.3, 0.5]
PRORITY_RECALL_THRES = [0.8, 0.9]
TRACK_THRES = [0.5, 0.6]
TRACK_PRECISION_THRES = [0.8, 0.9]

common_metrics = [
    "marginal/agent/ade_1_3s",
    "marginal/agent/ade_k_3s",
    "marginal/agent/fde_1_3s",
    "marginal/agent/fde_k_3s",
    "marginal/agent/mr_1_3s",
    "marginal/agent/mr_k_3s",
    "marginal/agent/acc_3s",
    "marginal/agent/ade_1_7s",
    "marginal/agent/ade_k_7s",
    "marginal/agent/fde_1_7s",
    "marginal/agent/fde_k_7s",
    "marginal/agent/mr_1_7s",
    "marginal/agent/mr_k_7s",
    "marginal/agent/acc_7s",
    "marginal/agent/prior_precision",
    "marginal/agent/prior_recall",
    "marginal/agent/prior_precision_based_recall",
    "marginal/agent/track_precision",
    "marginal/agent/track_recall",
    "marginal/agent/track_recall_based_precision",
]

util_func_dict = {
    "cal_l2_dist": cal_l2_dist,
    "cal_dist_mask": cal_dist_mask,
    "cal_fde_mask": cal_fde_mask,
}

metric_func_dict = {
    "cal_fde_1": cal_fde_1,
    "cal_fde_k": cal_fde_k,
    "cal_ade_1": cal_ade_1,
    "cal_ade_k": cal_ade_k,
    "cal_mr_1": cal_mr_1,
    "cal_mr_k": cal_mr_k,
    "cal_accuracy": cal_accuracy,
    "cal_prior_precision": cal_prior_precision_obs,
    "cal_prior_recall": cal_prior_recall_obs,
    "cal_prior_precision_based_recall": cal_prior_precision_based_recall_obs,
    "cal_track_precision": cal_track_precision_obs,
    "cal_track_recall": cal_track_recall_obs,
    "cal_track_recall_based_precision": cal_track_recall_based_precision_obs,
}

tmp_outputs = {
    "marginal/agent/l2_dist": {
        "input_keys": ["sorted_marginal_agent_traj", "bboxes_pred_gt", "bboxes_pred_mask"],
        "tmp_keys": [],
        "kwargs": {},
        "util_func": "cal_l2_dist",
    },
    "marginal/agent/dist_mask": {
        "input_keys": [],
        "tmp_keys": ["marginal/agent/l2_dist"],
        "kwargs": {},
        "util_func": "cal_dist_mask",
    },
    "marginal/agent/fde_mask_3s": {
        "input_keys": [],
        "tmp_keys": ["marginal/agent/dist_mask"],
        "kwargs": {"timestamp": TIMESTAMP_30},
        "util_func": "cal_fde_mask",
    },
    "marginal/agent/fde_mask_7s": {
        "input_keys": [],
        "tmp_keys": ["marginal/agent/dist_mask"],
        "kwargs": {"timestamp": TIMESTAMP_70},
        "util_func": "cal_fde_mask",
    },
}

single_metrics = {
    "marginal/agent/ade_1_3s": {
        "input_keys": [],
        "tmp_keys": ["marginal/agent/l2_dist", "marginal/agent/dist_mask", "marginal/agent/fde_mask_3s"],
        "output_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_30},
        "metric_func": "cal_ade_1",
    },
    "marginal/agent/ade_k_3s": {
        "input_keys": [],
        "tmp_keys": ["marginal/agent/l2_dist", "marginal/agent/dist_mask", "marginal/agent/fde_mask_3s"],
        "output_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_30},
        "metric_func": "cal_ade_k",
    },
    "marginal/agent/fde_1_3s": {
        "input_keys": [],
        "tmp_keys": ["marginal/agent/l2_dist", "marginal/agent/fde_mask_3s"],
        "output_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_30},
        "metric_func": "cal_fde_1",
    },
    "marginal/agent/fde_k_3s": {
        "input_keys": [],
        "tmp_keys": ["marginal/agent/l2_dist", "marginal/agent/fde_mask_3s"],
        "output_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_30},
        "metric_func": "cal_fde_k",
    },
    "marginal/agent/acc_3s": {
        "input_keys": [],
        "tmp_keys": ["marginal/agent/l2_dist", "marginal/agent/fde_mask_3s"],
        "output_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_30},
        "metric_func": "cal_accuracy",
    },
    "marginal/agent/mr_1_3s": {
        "input_keys": [],
        "tmp_keys": ["marginal/agent/fde_mask_3s"],
        "output_keys": ["marginal/agent/fde_1_3s"],
        "kwargs": {"missing_distance": MISSING_DISTANCE_THRES},
        "metric_func": "cal_mr_1",
    },
    "marginal/agent/mr_k_3s": {
        "input_keys": [],
        "tmp_keys": ["marginal/agent/fde_mask_3s"],
        "output_keys": ["marginal/agent/fde_k_3s"],
        "kwargs": {"missing_distance": MISSING_DISTANCE_THRES},
        "metric_func": "cal_mr_k",
    },
    "marginal/agent/ade_1_7s": {
        "input_keys": [],
        "tmp_keys": ["marginal/agent/l2_dist", "marginal/agent/dist_mask", "marginal/agent/fde_mask_7s"],
        "output_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_70},
        "metric_func": "cal_ade_1",
    },
    "marginal/agent/ade_k_7s": {
        "input_keys": [],
        "tmp_keys": ["marginal/agent/l2_dist", "marginal/agent/dist_mask", "marginal/agent/fde_mask_7s"],
        "output_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_70},
        "metric_func": "cal_ade_k",
    },
    "marginal/agent/fde_1_7s": {
        "input_keys": [],
        "tmp_keys": ["marginal/agent/l2_dist", "marginal/agent/fde_mask_7s"],
        "output_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_70},
        "metric_func": "cal_fde_1",
    },
    "marginal/agent/fde_k_7s": {
        "input_keys": [],
        "tmp_keys": ["marginal/agent/l2_dist", "marginal/agent/fde_mask_7s"],
        "output_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_70},
        "metric_func": "cal_fde_k",
    },
    "marginal/agent/acc_7s": {
        "input_keys": [],
        "tmp_keys": ["marginal/agent/l2_dist", "marginal/agent/fde_mask_7s"],
        "output_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_70},
        "metric_func": "cal_accuracy",
    },
    "marginal/agent/mr_1_7s": {
        "input_keys": [],
        "tmp_keys": ["marginal/agent/fde_mask_7s"],
        "output_keys": ["marginal/agent/fde_1_7s"],
        "kwargs": {"missing_distance": MISSING_DISTANCE_THRES},
        "metric_func": "cal_mr_1",
    },
    "marginal/agent/mr_k_7s": {
        "input_keys": [],
        "tmp_keys": ["marginal/agent/fde_mask_7s"],
        "output_keys": ["marginal/agent/fde_k_7s"],
        "kwargs": {"missing_distance": MISSING_DISTANCE_THRES},
        "metric_func": "cal_mr_k",
    },
    "marginal/agent/prior_precision": {
        "input_keys": ["od_prior_pred", "od_prior_gt", "agent_index"],
        "tmp_keys": [],
        "output_keys": [],
        "kwargs": {"confidence_thr": PRORITY_THRES},
        "metric_func": "cal_prior_precision",
    },
    "marginal/agent/prior_recall": {
        "input_keys": ["od_prior_pred", "od_prior_gt", "agent_index"],
        "tmp_keys": [],
        "output_keys": [],
        "kwargs": {"confidence_thr": PRORITY_THRES},
        "metric_func": "cal_prior_recall",
    },
    "marginal/agent/prior_precision_based_recall": {
        "input_keys": ["od_prior_pred", "od_prior_gt", "agent_index"],
        "tmp_keys": [],
        "output_keys": [],
        "kwargs": {"recall_thr": PRORITY_RECALL_THRES},
        "metric_func": "cal_prior_precision_based_recall",
    },
    "marginal/agent/track_precision": {
        "input_keys": ["od_track_pred", "ego_trackable_agent_gt", "ego_trackable_agent_gt_mask", "agent_index"],
        "tmp_keys": [],
        "output_keys": [],
        "kwargs": {"confidence_thr": TRACK_THRES},
        "metric_func": "cal_track_precision",
    },
    "marginal/agent/track_recall": {
        "input_keys": ["od_track_pred", "ego_trackable_agent_gt", "ego_trackable_agent_gt_mask", "agent_index"],
        "tmp_keys": [],
        "output_keys": [],
        "kwargs": {"confidence_thr": TRACK_THRES},
        "metric_func": "cal_track_recall",
    },
    "marginal/agent/track_recall_based_precision": {
        "input_keys": ["od_track_pred", "ego_trackable_agent_gt", "ego_trackable_agent_gt_mask", "agent_index"],
        "tmp_keys": [],
        "output_keys": [],
        "kwargs": {"precision_thr": TRACK_PRECISION_THRES},
        "metric_func": "cal_track_recall_based_precision",
    },
}
