EVAL_DATASET = {
        "CUTIN": {
            "list_files": [
                "/share-global/xiangwei.geng/plannn2/data/1118/matched/CUTIN_expert.txt"
            ],
        },
        "main_side_dymaic": {
            "list_files": [
                "/share-global/xiangwei.geng/plannn2/data/1118/matched/main_side_dymaic_expert.txt"
            ],
        },
         "start": {
            "list_files": [
                "/share-global/xiangwei.geng/plannn2/data/1118/matched/start_expert.txt"
            ],
        },
         "main_side_static": {
            "list_files": [
                "/share-global/xiangwei.geng/plannn2/data/1118/matched/main_side_static_expert.txt"
            ],
        },
         "u_turn": {
            "list_files": [
                "/share-global/xiangwei.geng/plannn2/data/1118/matched/u_turn_expert.txt"
            ],
        },
        "follow_stop": {
            "list_files": [
                "/share-global/xiangwei.geng/plannn2/data/1118/matched/follow_stop_expert.txt"
            ],
        },
        "turn_dymaic": {
            "list_files": [
                "/share-global/xiangwei.geng/plannn2/data/1118/matched/turn_dymaic_expert.txt"
            ],
        },
         "turn_static": {
            "list_files": [
                "/share-global/xiangwei.geng/plannn2/data/1118/matched/turn_static_expert.txt"
            ],
        },
         "lane_change": {
            "list_files": [
                "/share-global/xiangwei.geng/plannn2/data/1118/matched/lane_change_expert.txt"
            ],
        },
         "nudge": {
            "list_files": [
                "/share-global/xiangwei.geng/plannn2/data/1118/matched/nudge_expert.txt"
            ],
        },

    }
