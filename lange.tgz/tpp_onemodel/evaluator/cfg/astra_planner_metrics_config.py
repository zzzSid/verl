# -*- coding: utf-8 -*-
"""Astra Planner evaluation metrics config."""
# todo: import all metric/util func
from tpp_onemodel.evaluator.metric.basic_metrics import cal_accuracy
from tpp_onemodel.evaluator.metric.basic_metrics import cal_ade_1
from tpp_onemodel.evaluator.metric.basic_metrics import cal_ade_k
from tpp_onemodel.evaluator.metric.basic_metrics import cal_current_speed_from_vxvy
from tpp_onemodel.evaluator.metric.basic_metrics import cal_dist_mask
from tpp_onemodel.evaluator.metric.basic_metrics import cal_fde_1
from tpp_onemodel.evaluator.metric.basic_metrics import cal_fde_k
from tpp_onemodel.evaluator.metric.basic_metrics import cal_fde_mask
from tpp_onemodel.evaluator.metric.basic_metrics import cal_l2_dist
from tpp_onemodel.evaluator.metric.basic_metrics import cal_mr_1
from tpp_onemodel.evaluator.metric.basic_metrics import cal_mr_k
from tpp_onemodel.evaluator.metric.collision_metrics import cal_ego_multi_circle_centers
from tpp_onemodel.evaluator.metric.collision_metrics import (
    cal_multi_obs_multi_circle_centers,
)
from tpp_onemodel.evaluator.metric.collision_metrics import lane_boundary_collision_rate
from tpp_onemodel.evaluator.metric.collision_metrics import obs_collision_rate
from tpp_onemodel.evaluator.metric.frenet_metrics import get_frenet_l_error
from tpp_onemodel.evaluator.metric.frenet_metrics import get_frenet_result
from tpp_onemodel.evaluator.metric.frenet_metrics import get_frenet_s_error
from tpp_onemodel.evaluator.metric.similarity_metrics import cal_ego_mode_similarity
from tpp_onemodel.evaluator.metric.similarity_metrics import cal_prediction_offset


MISSING_DISTANCE_THRES = 2.0
NAVI_MISSING_RATE_THRESH = 2
TIMESTAMP_70 = 35
TIMESTAMP_30 = 15
TIMESTAMP_10 = 5
Freq = 5
Dt = 1 / Freq

common_metrics = [
    "marginal/ego/ade_1_3s",
    "marginal/ego/ade_k_3s",
    "marginal/ego/fde_1_3s",
    "marginal/ego/fde_k_3s",
    "marginal/ego/mr_1_3s",
    "marginal/ego/mr_k_3s",
    "marginal/ego/acc_3s",
    "marginal/ego/min_od_collision_rate_3s",
    "marginal/ego/best_od_collision_rate_3s",
    "marginal/ego/min_lane_collision_rate_3s",
    "marginal/ego/best_lane_collision_rate_3s",
    "marginal/ego/min_s_error_3s",
    "marginal/ego/min_l_error_3s",
    "marginal/ego/best_s_error_3s",
    "marginal/ego/best_l_error_3s",
    "marginal/ego/ego_mode_AWP_similarity_3s",
    "marginal/ego/ego_mode_FWP_similarity_3s",
    "marginal/ego/ade_1_7s",
    "marginal/ego/ade_k_7s",
    "marginal/ego/fde_1_7s",
    "marginal/ego/fde_k_7s",
    "marginal/ego/mr_1_7s",
    "marginal/ego/mr_k_7s",
    "marginal/ego/acc_7s",
    "marginal/ego/min_od_collision_rate_7s",
    "marginal/ego/best_od_collision_rate_7s",
    "marginal/ego/min_lane_collision_rate_7s",
    "marginal/ego/best_lane_collision_rate_7s",
    "marginal/ego/min_s_error_7s",
    "marginal/ego/min_l_error_7s",
    "marginal/ego/best_s_error_7s",
    "marginal/ego/best_l_error_7s",
    "marginal/ego/ego_mode_AWP_similarity_7s",
    "marginal/ego/ego_mode_FWP_similarity_7s",
]

util_func_dict = {
    "cal_l2_dist": cal_l2_dist,
    "cal_ego_multi_circle_centers": cal_ego_multi_circle_centers,
    "cal_multi_obs_multi_circle_centers": cal_multi_obs_multi_circle_centers,
    "get_frenet_result": get_frenet_result,
    "cal_prediction_offset": cal_prediction_offset,
    "cal_dist_mask": cal_dist_mask,
    "cal_fde_mask": cal_fde_mask,
    "cal_current_speed_from_vxvy": cal_current_speed_from_vxvy,
}

metric_func_dict = {
    "cal_fde_1": cal_fde_1,
    "cal_fde_k": cal_fde_k,
    "cal_ade_1": cal_ade_1,
    "cal_ade_k": cal_ade_k,
    "cal_mr_1": cal_mr_1,
    "cal_mr_k": cal_mr_k,
    "od_collision": obs_collision_rate,
    "lb_collision": lane_boundary_collision_rate,
    "get_frenet_s_error": get_frenet_s_error,
    "get_frenet_l_error": get_frenet_l_error,
    "cal_ego_mode_similarity": cal_ego_mode_similarity,
    "cal_accuracy": cal_accuracy,
}

tmp_outputs = {
    "marginal/ego/l2_dist": {
        "input_keys": ["sorted_marginal_ego_traj", "egos_pred_gt", "egos_pred_mask"],
        "tmp_keys": [],
        "kwargs": {},
        "util_func": "cal_l2_dist",
    },
    "marginal/ego/dist_mask": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/l2_dist"],
        "kwargs": {},
        "util_func": "cal_dist_mask",
    },
    "marginal/ego/fde_mask_3s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/dist_mask"],
        "kwargs": {"timestamp": TIMESTAMP_30},
        "util_func": "cal_fde_mask",
    },
    "marginal/ego/fde_mask_7s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/dist_mask"],
        "kwargs": {"timestamp": TIMESTAMP_70},
        "util_func": "cal_fde_mask",
    },
    "marginal/ego/min_pred_circle_centers": {
        "input_keys": ["marginal_ego_min_fde_traj", "egos", "marginal_ego_min_yaw"],
        "tmp_keys": [],
        "kwargs": {"circle_num": 3},
        "util_func": "cal_ego_multi_circle_centers",
    },
    "marginal/ego/best_pred_circle_centers": {
        "input_keys": ["marginal_ego_best_traj", "egos", "marginal_ego_best_yaw"],
        "tmp_keys": [],
        "kwargs": {"circle_num": 3},
        "util_func": "cal_ego_multi_circle_centers",
    },
    "gt/agent/circle_centers": {
        "input_keys": ["bboxes_pred_gt", "bboxes_det_pred_full_info_gt"],
        "tmp_keys": [],
        "kwargs": {"circle_num": 5},
        "util_func": "cal_multi_obs_multi_circle_centers",
    },
    "marginal/ego/min_frenet_result_3s": {
        "input_keys": ["marginal_ego_min_fde_traj", "egos_pred_gt"],
        "tmp_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_30},
        "util_func": "get_frenet_result",
    },
    "marginal/ego/best_frenet_result_3s": {
        "input_keys": ["marginal_ego_best_traj", "egos_pred_gt"],
        "tmp_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_30},
        "util_func": "get_frenet_result",
    },
    "marginal/ego/min_frenet_result_7s": {
        "input_keys": ["marginal_ego_min_fde_traj", "egos_pred_gt"],
        "tmp_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_70},
        "util_func": "get_frenet_result",
    },
    "marginal/ego/best_frenet_result_7s": {
        "input_keys": ["marginal_ego_best_traj", "egos_pred_gt"],
        "tmp_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_70},
        "util_func": "get_frenet_result",
    },
    "marginal/ego/prediction_offset": {
        "input_keys": ["sorted_marginal_ego_traj", "egos"],
        "tmp_keys": [],
        "kwargs": {},
        "util_func": "cal_prediction_offset",
    },
    "ego/gt_init_speed": {
        "input_keys": ["egos"],
        "tmp_keys": [],
        "kwargs": {},
        "util_func": "cal_current_speed_from_vxvy",
    },
}

single_metrics = {
    "marginal/ego/ade_1_3s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/l2_dist", "marginal/ego/dist_mask", "marginal/ego/fde_mask_3s"],
        "output_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_30},
        "metric_func": "cal_ade_1",
    },
    "marginal/ego/ade_k_3s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/l2_dist", "marginal/ego/dist_mask", "marginal/ego/fde_mask_3s"],
        "output_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_30},
        "metric_func": "cal_ade_k",
    },
    "marginal/ego/fde_1_3s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/l2_dist", "marginal/ego/fde_mask_3s"],
        "output_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_30},
        "metric_func": "cal_fde_1",
    },
    "marginal/ego/fde_k_3s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/l2_dist", "marginal/ego/fde_mask_3s"],
        "output_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_30},
        "metric_func": "cal_fde_k",
    },
    "marginal/ego/acc_3s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/l2_dist", "marginal/ego/fde_mask_3s"],
        "output_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_30},
        "metric_func": "cal_accuracy",
    },
    "marginal/ego/mr_1_3s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/fde_mask_3s"],
        "output_keys": ["marginal/ego/fde_1_3s"],
        "kwargs": {"missing_distance": MISSING_DISTANCE_THRES},
        "metric_func": "cal_mr_1",
    },
    "marginal/ego/mr_k_3s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/fde_mask_3s"],
        "output_keys": ["marginal/ego/fde_k_3s"],
        "kwargs": {"missing_distance": MISSING_DISTANCE_THRES},
        "metric_func": "cal_mr_k",
    },
    "marginal/ego/min_od_collision_rate_3s": {
        "input_keys": [
            "egos_pred_mask",
            "egos",
            "bboxes_det_pred_full_info_gt",
            "bboxes_pred_mask",
            "marginal_ego_min_vel",
        ],
        "tmp_keys": ["marginal/ego/fde_mask_3s", "marginal/ego/min_pred_circle_centers", "gt/agent/circle_centers"],
        "output_keys": [],
        "kwargs": {"collision_thres": 0.0, "timestamp": TIMESTAMP_30},
        "metric_func": "od_collision",
    },
    "marginal/ego/best_od_collision_rate_3s": {
        "input_keys": [
            "egos_pred_mask",
            "egos",
            "bboxes_det_pred_full_info_gt",
            "bboxes_pred_mask",
            "marginal_ego_best_vel",
        ],
        "tmp_keys": ["marginal/ego/fde_mask_3s", "marginal/ego/best_pred_circle_centers", "gt/agent/circle_centers"],
        "output_keys": [],
        "kwargs": {"collision_thres": 0.0, "timestamp": TIMESTAMP_30},
        "metric_func": "od_collision",
    },
    "marginal/ego/min_lane_collision_rate_3s": {
        "input_keys": ["marginal_ego_min_fde_traj", "egos", "lane_points", "lane_types"],
        "tmp_keys": ["marginal/ego/fde_mask_3s"],
        "output_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_30},
        "metric_func": "lb_collision",
    },
    "marginal/ego/best_lane_collision_rate_3s": {
        "input_keys": ["marginal_ego_best_traj", "egos", "lane_points", "lane_types"],
        "tmp_keys": ["marginal/ego/fde_mask_3s"],
        "output_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_30},
        "metric_func": "lb_collision",
    },
    "marginal/ego/min_s_error_3s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/fde_mask_3s", "marginal/ego/min_frenet_result_3s"],
        "output_keys": [],
        "kwargs": {},
        "metric_func": "get_frenet_s_error",
    },
    "marginal/ego/min_l_error_3s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/fde_mask_3s", "marginal/ego/min_frenet_result_3s"],
        "output_keys": [],
        "kwargs": {},
        "metric_func": "get_frenet_l_error",
    },
    "marginal/ego/best_s_error_3s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/fde_mask_3s", "marginal/ego/best_frenet_result_3s"],
        "output_keys": [],
        "kwargs": {},
        "metric_func": "get_frenet_s_error",
    },
    "marginal/ego/best_l_error_3s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/fde_mask_3s", "marginal/ego/best_frenet_result_3s"],
        "output_keys": [],
        "kwargs": {},
        "metric_func": "get_frenet_l_error",
    },
    "marginal/ego/ego_mode_AWP_similarity_3s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/fde_mask_3s", "marginal/ego/prediction_offset", "ego/gt_init_speed"],
        "output_keys": [],
        "kwargs": {"target": "all_point", "future_num_used": TIMESTAMP_30},
        "metric_func": "cal_ego_mode_similarity",
    },
    "marginal/ego/ego_mode_FWP_similarity_3s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/fde_mask_3s", "marginal/ego/prediction_offset", "ego/gt_init_speed"],
        "output_keys": [],
        "kwargs": {"target": "final_point", "future_num_used": TIMESTAMP_30},
        "metric_func": "cal_ego_mode_similarity",
    },
    "marginal/ego/ade_1_7s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/l2_dist", "marginal/ego/dist_mask", "marginal/ego/fde_mask_7s"],
        "output_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_70},
        "metric_func": "cal_ade_1",
    },
    "marginal/ego/ade_k_7s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/l2_dist", "marginal/ego/dist_mask", "marginal/ego/fde_mask_7s"],
        "output_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_70},
        "metric_func": "cal_ade_k",
    },
    "marginal/ego/fde_1_7s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/l2_dist", "marginal/ego/fde_mask_7s"],
        "output_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_70},
        "metric_func": "cal_fde_1",
    },
    "marginal/ego/fde_k_7s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/l2_dist", "marginal/ego/fde_mask_7s"],
        "output_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_70},
        "metric_func": "cal_fde_k",
    },
    "marginal/ego/acc_7s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/l2_dist", "marginal/ego/fde_mask_7s"],
        "output_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_70},
        "metric_func": "cal_accuracy",
    },
    "marginal/ego/mr_1_7s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/fde_mask_7s"],
        "output_keys": ["marginal/ego/fde_1_7s"],
        "kwargs": {"missing_distance": MISSING_DISTANCE_THRES},
        "metric_func": "cal_mr_1",
    },
    "marginal/ego/mr_k_7s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/fde_mask_7s"],
        "output_keys": ["marginal/ego/fde_k_7s"],
        "kwargs": {"missing_distance": MISSING_DISTANCE_THRES},
        "metric_func": "cal_mr_k",
    },
    "marginal/ego/min_od_collision_rate_7s": {
        "input_keys": [
            "egos_pred_mask",
            "egos",
            "bboxes_det_pred_full_info_gt",
            "bboxes_pred_mask",
            "marginal_ego_min_vel",
        ],
        "tmp_keys": ["marginal/ego/fde_mask_7s", "marginal/ego/min_pred_circle_centers", "gt/agent/circle_centers"],
        "output_keys": [],
        "kwargs": {"collision_thres": 0.0, "timestamp": TIMESTAMP_70},
        "metric_func": "od_collision",
    },
    "marginal/ego/best_od_collision_rate_7s": {
        "input_keys": [
            "egos_pred_mask",
            "egos",
            "bboxes_det_pred_full_info_gt",
            "bboxes_pred_mask",
            "marginal_ego_best_vel",
        ],
        "tmp_keys": ["marginal/ego/fde_mask_7s", "marginal/ego/best_pred_circle_centers", "gt/agent/circle_centers"],
        "output_keys": [],
        "kwargs": {"collision_thres": 0.0, "timestamp": TIMESTAMP_70},
        "metric_func": "od_collision",
    },
    "marginal/ego/min_lane_collision_rate_7s": {
        "input_keys": ["marginal_ego_min_fde_traj", "egos", "lane_points", "lane_types"],
        "tmp_keys": ["marginal/ego/fde_mask_7s"],
        "output_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_70},
        "metric_func": "lb_collision",
    },
    "marginal/ego/best_lane_collision_rate_7s": {
        "input_keys": ["marginal_ego_best_traj", "egos", "lane_points", "lane_types"],
        "tmp_keys": ["marginal/ego/fde_mask_7s"],
        "output_keys": [],
        "kwargs": {"timestamp": TIMESTAMP_70},
        "metric_func": "lb_collision",
    },
    "marginal/ego/min_s_error_7s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/fde_mask_7s", "marginal/ego/min_frenet_result_7s"],
        "output_keys": [],
        "kwargs": {},
        "metric_func": "get_frenet_s_error",
    },
    "marginal/ego/min_l_error_7s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/fde_mask_7s", "marginal/ego/min_frenet_result_7s"],
        "output_keys": [],
        "kwargs": {},
        "metric_func": "get_frenet_l_error",
    },
    "marginal/ego/best_s_error_7s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/fde_mask_7s", "marginal/ego/best_frenet_result_7s"],
        "output_keys": [],
        "kwargs": {},
        "metric_func": "get_frenet_s_error",
    },
    "marginal/ego/best_l_error_7s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/fde_mask_7s", "marginal/ego/best_frenet_result_7s"],
        "output_keys": [],
        "kwargs": {},
        "metric_func": "get_frenet_l_error",
    },
    "marginal/ego/ego_mode_AWP_similarity_7s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/fde_mask_7s", "marginal/ego/prediction_offset", "ego/gt_init_speed"],
        "output_keys": [],
        "kwargs": {"target": "all_point", "future_num_used": TIMESTAMP_70},
        "metric_func": "cal_ego_mode_similarity",
    },
    "marginal/ego/ego_mode_FWP_similarity_7s": {
        "input_keys": [],
        "tmp_keys": ["marginal/ego/fde_mask_7s", "marginal/ego/prediction_offset", "ego/gt_init_speed"],
        "output_keys": [],
        "kwargs": {"target": "final_point", "future_num_used": TIMESTAMP_70},
        "metric_func": "cal_ego_mode_similarity",
    },
}
