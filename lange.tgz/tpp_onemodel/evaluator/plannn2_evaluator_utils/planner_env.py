# -*- coding: utf-8 -*-
import logging
import math
import os
import re
import tempfile
import textwrap
import time
import urllib.parse
import json

import cv2
import matplotlib.pyplot as plt
import numpy as np
import torch
from uuid import uuid4
from mcap_protobuf.writer import Writer as McapWriter
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation as R
from shapely.geometry import LineString
from shapely.geometry import MultiLineString
from shapely.geometry import MultiPolygon
from shapely.geometry import Polygon
from matplotlib.cm import ScalarMappable
from matplotlib.colors import Normalize
from torchpilot.utils.file_manager import FileManager

from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import get_map_cls_to_3cls
from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import (
    lane_direction_to_tld_id_mapping,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import (
    road_arrow_to_lane_direction_mapping,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import ASSIST_ACTION_MAPPING
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import COLORS_ID
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import MAIN_ACTION_MAPPING
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import MATPLOTLIB_COLOR_MAP
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import CollisionComputer
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import Turntype
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import calc_path_length
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import (
    calc_path_length_from_point,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import (
    calc_path_point_heading,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import (
    check_ego_gt_connection_cross_road_edge,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import (
    compute_center_distance,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import cut_sub_path
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import (
    determine_path_turn_type,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import (
    determine_road_sign_turn_type,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import (
    filter_stopline_pos_behind_ego,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import find_local_minima
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import find_nearest_point
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import get_chinese_font
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import get_gt_polygons
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import get_lane_direction
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import get_lane_direction_str
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import get_lat_distance
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import get_lines_distance
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import (
    get_projection_on_segment,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import (
    get_relative_pose_from_obj,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import get_rotated_rectangle
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import (
    get_turn_type_from_path,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import get_vector_angle
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import get_xyyaw_from_polygon
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import interpolate_points
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import kLaneTypeMap
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import (
    line_intersection_point,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import (
    match_road_sign_from_path,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import (
    match_road_sign_with_lanenr,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import polygon_to_segments
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import segment_intersect
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import split_line
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import (
    split_points_to_segments,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import transform_polygon
from tpp_onemodel.tools.adviz.foxglove.ArrowPrimitive_pb2 import (
    ArrowPrimitive as AdvizArrowPrimitive,
)
from tpp_onemodel.tools.adviz.foxglove.CubePrimitive_pb2 import (
    CubePrimitive as AdvizCubePrimitive,
)
from tpp_onemodel.tools.adviz.foxglove.FrameTransform_pb2 import (
    FrameTransform as AdvizFrameTransform,
)
from tpp_onemodel.tools.adviz.foxglove.FrameTransforms_pb2 import (
    FrameTransforms as AdvizFrameTransforms,
)
from tpp_onemodel.tools.adviz.foxglove.Grid_pb2 import Grid as AdvizGrid
from tpp_onemodel.tools.adviz.foxglove.LinePrimitive_pb2 import (
    LinePrimitive as AdvizLinePrimitive,
)
from tpp_onemodel.tools.adviz.foxglove.SceneEntity_pb2 import (
    SceneEntity as AdvizSceneEntity,
)
from tpp_onemodel.tools.adviz.foxglove.SceneUpdate_pb2 import (
    SceneUpdate as AdvizSceneUpdate,
)
from tpp_onemodel.tools.adviz.foxglove.SpherePrimitive_pb2 import (
    SpherePrimitive as AdvizSpherePrimitive,
)
from tpp_onemodel.tools.adviz.foxglove.TextPrimitive_pb2 import (
    TextPrimitive as AdvizTextPrimitive,
)
from tpp_onemodel.tools.adviz.visualization_msg_pb2 import (
    GeneralFloatPair as AdvizFloatPair,
)
from tpp_onemodel.tools.adviz.visualization_msg_pb2 import (
    GeneralIntPair as AdvizIntPair,
)
from tpp_onemodel.tools.adviz.visualization_msg_pb2 import (
    GeneralStrPair as AdvizStrPair,
)
from tpp_onemodel.tools.adviz.visualization_msg_pb2 import PlanNN2NavigationMsg
from tpp_onemodel.tools.adviz.visualization_msg_pb2 import PlanNN2VisualizationMsg
from tpp_onemodel.tools.loader.ceph import client as niofs_client

logger = logging.getLogger(__name__)

np.set_printoptions(suppress=True, precision=6)

DEFAULT_REWARD_KEYS = [
    "reward",
    "ax_penalty",
    "ay_penalty",
    "jx_penalty",
    "jy_penalty",
    "wrong_way_reward",
    "progress_reward",
    # "yaw_penalty",
    "ttc_reward",
    "min_distance_reward",
    "navi_roadsign",
    "navi_lane_reward",
    "virtual_wall_reward",
    "cross_solid_line_reward",
    "traffic_light_reward",
    "humanoid_reward",
    "humanoid_nudge_reward",
    "continuous_lane_change_reward",
    "dones",
    "centralization_reward",
    "slow_follow_reward",
]

class AdvizRenderer:
    def __init__(self, uuid):
        self.common_msgs = {}
        self.frame_linestrings = {}
        self.frame_cubes = {}
        self.frame_spheres = {}
        self.frame_texts = {}
        self.navi_msgs = {}
        self.ego_transforms = {}
        self.uuid = uuid
        self.cos_bucket = "ad-cn-hlidc-fdm-algo3-infra"
        self.topic_prefix = "v"+str(uuid4().hex)
        self.cos_path = f"plannn2_visualization/{os.environ.get('USER', 'anon')}/{uuid}-{self.topic_prefix}.mcap"

    def save(self):
        with niofs_client.open(self.cos_bucket, self.cos_path, "wb") as fd, McapWriter(fd) as adviz_writer:
            for ts, transforms in self.ego_transforms.items():
                adviz_writer.write_message(
                    topic=f"{self.topic_prefix}/adviz/frame",
                    message=transforms,
                    log_time=ts,
                    publish_time=ts,
                )
                ego_center = AdvizSpherePrimitive(
                    pose={"position": {"x": 0, "y": 0, "z": 0}, "orientation": {"x": 0, "y": 0, "z": 0, "w": 1}},
                    size={"x": 1.0, "y": 1.0, "z": 1.0},
                    color={"r": 1.0, "g": 0.0, "b": 0.0, "a": 0.5},
                )
                ego_entity = AdvizSceneEntity(
                    timestamp={"seconds": ts // int(1E9), "nanos": ts % int(1E9)},
                    frame_id="ego_link",
                    id="ego_center",
                    spheres=[ego_center],
                )
                ego_update = AdvizSceneUpdate(entities=[ego_entity])
                adviz_writer.write_message(
                    topic=f"{self.topic_prefix}/adviz/ego_center",
                    message=ego_update,
                    log_time=ts,
                    publish_time=ts,
                )
            timestamps = sorted(list(set(list(self.frame_linestrings.keys()) + list(self.frame_cubes.keys()) + list(self.common_msgs.keys()))))
            for ts in timestamps:
                navi_msg = self.navi_msgs.get(ts, None)
                if navi_msg:
                    adviz_writer.write_message(
                        topic=f"{self.topic_prefix}/navigation",
                        message=navi_msg,
                        log_time=ts,
                        publish_time=ts,
                    )

                # compose common msg
                common_msg = self.common_msgs.get(ts, None)
                if common_msg:
                    common_msg.uuid = self.uuid
                    common_msg.timestamp = ts
                    adviz_writer.write_message(
                        topic=f"{self.topic_prefix}/common_info",
                        message=common_msg,
                        log_time=ts,
                        publish_time=ts,
                    )
                # compose 3D geometrys
                lines = self.frame_linestrings.get(ts, [])
                cubes = self.frame_cubes.get(ts, [])
                spheres = self.frame_spheres.get(ts, [])
                texts = self.frame_texts.get(ts, [])
                topics = set([t for t, _ in lines] + [t for t, _ in cubes] + [t for t, _ in spheres] + [t for t, _ in texts])
                ts_sec = ts // int(1E9)
                ts_nano = ts - ts_sec * int(1E9)
                topic_entities = {t: AdvizSceneEntity(timestamp={"seconds": ts_sec, "nanos": ts_nano}, frame_id="base_link", id="vis") for t in topics}
                for topic, line in lines:
                    topic_entities[topic].lines.append(line)
                for topic, cube in cubes:
                    topic_entities[topic].cubes.append(cube)
                for topic, sphere in spheres:
                    topic_entities[topic].spheres.append(sphere)
                for topic, text in texts:
                    topic_entities[topic].texts.append(text)
                for topic, entity in topic_entities.items():
                    update = AdvizSceneUpdate(entities=[entity])
                    adviz_writer.write_message(
                        topic=f"{self.topic_prefix}/adviz/{topic}",
                        message=update,
                        log_time=ts,
                        publish_time=ts,
                    )
        prefix_mapping_arg = urllib.parse.quote(json.dumps({self.topic_prefix:"plannn2"}, separators=(',', ':')))
        access_url = niofs_client.generate_presigned_url(self.cos_bucket, self.cos_path, expiration=604800)
        access_url = f"https://adviz.nioint.com/?ds=mcap-remote-file&mapping={prefix_mapping_arg}&ds.url={urllib.parse.quote(access_url)}"
        return (access_url, f"huailai:{self.cos_bucket}/{self.cos_path}")

    @staticmethod
    def frameid2ts(fid):
        return (fid+1)*200*int(1E6)

    @staticmethod
    def convert_color(color):
        c = dict(r=1.0,g=0.0,b=1.0,a=1.0)
        if type(color) is str:
            c=MATPLOTLIB_COLOR_MAP.get(color, c)
        elif type(color) is tuple or type(color) is list:
            c=dict(r=color[0]/255.0, g=color[1]/255.0, b=color[2]/255.0, a=1.0)
        elif type(color) is dict:
            c=color
        c = {k: float(v) for k, v in c.items()}
        return c

    def draw_line(self, frame_id, topic, x, y, color, alpha=1.0, thickness=0.2, dashed=False):
        ts = self.frameid2ts(frame_id)
        pts = [dict(x=xx, y=yy, z=0) for xx, yy in zip(x, y)]
        c = self.convert_color(color)
        c["a"] = alpha
        line_primitive = AdvizLinePrimitive(
            type=AdvizLinePrimitive.Type.LINE_LIST if dashed else  AdvizLinePrimitive.Type.LINE_STRIP,
            thickness=thickness,
            points=pts,
            color=c,
        )
        if ts not in self.frame_linestrings:
            self.frame_linestrings[ts] = []
        self.frame_linestrings[ts].append((topic, line_primitive))

    def draw_polygon(self, frame_id, topic, x, y, color, alpha=1.0, thickness=0.2):
        ts = self.frameid2ts(frame_id)
        pts = [dict(x=xx, y=yy, z=0) for xx, yy in zip(x, y)]
        c = self.convert_color(color)
        c["a"] = alpha
        line_primitive = AdvizLinePrimitive(
            type=AdvizLinePrimitive.Type.LINE_LOOP,
            thickness=thickness,
            points=pts,
            color=c,
        )
        if ts not in self.frame_linestrings:
            self.frame_linestrings[ts] = []
        self.frame_linestrings[ts].append((topic, line_primitive))

    def draw_box(self, frame_id, topic, polygon, color, alpha=1.0):
        if len(polygon.shape) == 2:
            polygon = polygon[None, :]
        xyz_lwh_yaw = get_xyyaw_from_polygon(polygon)[0]
        quat = R.from_euler("zyx", [xyz_lwh_yaw[6], 0, 0]).as_quat()

        ts = self.frameid2ts(frame_id)
        c = self.convert_color(color)
        c["a"] = alpha
        cube_primitive = AdvizCubePrimitive(
            pose=dict(
                position=dict(x=xyz_lwh_yaw[0], y=xyz_lwh_yaw[1], z=0.9),
                orientation=dict(x=quat[0], y=quat[1], z=quat[2], w=quat[3])),
            size=dict(x=xyz_lwh_yaw[3], y=xyz_lwh_yaw[4], z=1.8),
            color=c,
        )
        if ts not in self.frame_cubes:
            self.frame_cubes[ts] = []
        self.frame_cubes[ts].append((topic, cube_primitive))

    def draw_sphere(self, frame_id, topic, pos, size, color, alpha=1.0):
        ts = self.frameid2ts(frame_id)
        c = self.convert_color(color)
        c["a"] = alpha
        cube_primitive = AdvizSpherePrimitive(
            pose=dict(
                position=dict(x=pos[0], y=pos[1], z=0),
                orientation=dict(x=0, y=0, z=0, w=1)),
            size=dict(x=size, y=size, z=size),
            color=c,
        )
        if ts not in self.frame_spheres:
            self.frame_spheres[ts] = []
        self.frame_spheres[ts].append((topic, cube_primitive))

    def set_ego_transform(self, frame_id, position, yaw):
        ts = self.frameid2ts(frame_id)
        ts_sec = ts // int(1E9)
        ts_nano = ts - ts_sec * int(1E9)
        orientation = R.from_euler("zyx", [yaw, 0, 0]).as_quat()
        self.ego_transforms[ts] = AdvizFrameTransform(
            parent_frame_id="base_link",
            child_frame_id="ego_link",
            translation=dict(x=position[0], y=position[1], z=position[2]),
            rotation=dict(x=orientation[0], y=orientation[1], z=orientation[2], w=orientation[3]),
            timestamp={"seconds": ts_sec, "nanos": ts_nano},
        )

    def draw_points(self, frame_id, topic, points, size=0.5, color="white", alpha=1.0):
        for p in points:
            self.draw_sphere(frame_id, topic, p, size, color, alpha)

    def draw_text(self, frame_id, topic, pos, text, color, alpha=1.0, fontsize=0.5):
        ts = self.frameid2ts(frame_id)
        c = self.convert_color(color)
        c["a"] = alpha
        text_primitive = AdvizTextPrimitive(
            pose=dict(
                position=dict(x=pos[0], y=pos[1], z=0.0 if len(pos) <3 else pos[2]),
                orientation=dict(x=0, y=0, z=0, w=1)),
            text=text,
            billboard=True,
            font_size=fontsize,
            color=c,
        )
        if ts not in self.frame_texts:
            self.frame_texts[ts] = []
        self.frame_texts[ts].append((topic, text_primitive))

    def add_rewards(self, frame_id, reward_dict):
        ts = self.frameid2ts(frame_id)
        if ts not in self.common_msgs:
            self.common_msgs[ts] = PlanNN2VisualizationMsg()
        msg = self.common_msgs.get(ts, PlanNN2VisualizationMsg())
        msg.timestamp = ts
        msg.rewards.extend([AdvizFloatPair(id=k, value=v) for k, v in reward_dict.items()])

    def add_action(self, frame_id, action_dict):
        ts = self.frameid2ts(frame_id)
        if ts not in self.common_msgs:
            self.common_msgs[ts] = PlanNN2VisualizationMsg()
        msg = self.common_msgs.get(ts, PlanNN2VisualizationMsg())
        msg.timestamp = ts
        msg.metaaction.extend(
            [
                AdvizIntPair(id=k, value=int(v))
                for k, v in action_dict.items()
                if v is not None and not (isinstance(v, float) and np.isnan(v))
            ]
        )

    def add_speeds(self, frame_id, speed_dict):
        ts = self.frameid2ts(frame_id)
        if ts not in self.common_msgs:
            self.common_msgs[ts] = PlanNN2VisualizationMsg()
        msg = self.common_msgs.get(ts, PlanNN2VisualizationMsg())
        msg.timestamp = ts
        msg.speeds.extend([AdvizFloatPair(id=k, value=v) for k, v in speed_dict.items()])

    def add_diags(self, frame_id, diag_dict):
        ts = self.frameid2ts(frame_id)
        if ts not in self.common_msgs:
            self.common_msgs[ts] = PlanNN2VisualizationMsg()
        msg = self.common_msgs.get(ts, PlanNN2VisualizationMsg())
        msg.timestamp = ts
        msg.diags.extend([AdvizFloatPair(id=k, value=v) for k, v in diag_dict.items()])

    def add_tags(self, frame_id, tags):
        ts = self.frameid2ts(frame_id)
        if ts not in self.common_msgs:
            self.common_msgs[ts] = PlanNN2VisualizationMsg()
        msg = self.common_msgs.get(ts, PlanNN2VisualizationMsg())
        msg.timestamp = ts
        msg.tags.extend(tags)

    def add_metadatas(self, frame_id, metadata_dict):
        ts = self.frameid2ts(frame_id)
        if ts not in self.common_msgs:
            self.common_msgs[ts] = PlanNN2VisualizationMsg()
        msg = self.common_msgs.get(ts, PlanNN2VisualizationMsg())
        msg.timestamp = ts
        msg.metadata.extend([AdvizStrPair(id=k, value=v) for k, v in metadata_dict.items()])

    def add_navigation_msg(self, frame_id, lane_nr_str, main_action_1, sub_action_1, main_action_1_dist, main_action_2, sub_action_2, main_action_2_dist):
        ts = self.frameid2ts(frame_id)
        nav_msg = PlanNN2NavigationMsg(
            timestamp=ts,
            lane_nr=lane_nr_str,
            main_action_1=main_action_1,
            sub_action_1=sub_action_1,
            main_action_1_dist=main_action_1_dist,
            main_action_2=main_action_2,
            sub_action_2=sub_action_2,
            main_action_2_dist=main_action_2_dist,
        )
        self.navi_msgs[ts] = nav_msg


class PlannerEnv:
    def __init__(
        self,
        raw_env,
        timestamp_size,
        history_size,
        fps,
        pedestrian_tokenizer=None,
        input_tensor_data=None,
        eval_only=False,
        use_ttc=True,
    ):
        self.raw_env = raw_env
        if not isinstance(self.raw_env, list):
            self.raw_env = [self.raw_env] * timestamp_size
        self.timestamp_size = timestamp_size
        self.history_size = history_size
        self.fps = fps
        self.pedestrian_tokenizer = pedestrian_tokenizer
        self.input_tensor_data = input_tensor_data

        self.collision_computer = CollisionComputer()
        self.eval_only = eval_only
        self.use_ttc = use_ttc

    def metric(self, state_polygons, gt_state_polygons, gt_state_propertys):
        """
        state_polygons: K x timestamp_size x 4 x 2
        gt_state_polygons: 1 x timestamp_size x 4 x 2
        gt_state_propertys: 1 x timestamp_size x 5
        """
        pred_traj_polygon = state_polygons[:, self.history_size :]
        gt_traj_polygon = gt_state_polygons[:, self.history_size : self.history_size+20]
        gt_state_propertys = gt_state_propertys[:, self.history_size :]
        gt_length = gt_traj_polygon.shape[1]
        gt_mask = gt_state_propertys[:, :, 3] > 0  # gt轨迹可能提前终止

        if gt_mask.sum() == 0:
            return np.nan, np.nan, 0, 0
        displacement = np.linalg.norm(pred_traj_polygon[:, :gt_length] - gt_traj_polygon, axis=-1).mean(
            axis=-1
        )  # K x t

        # ade
        displacement_mask_avg = np.sum(displacement * gt_mask, axis=-1) / np.sum(gt_mask)  # K
        minADE = np.min(displacement_mask_avg)
        best_ade_idx = np.argmin(displacement_mask_avg)

        # fde
        final_t = np.where(gt_mask[0])[0][-1]
        minFDE = np.min(displacement[:, final_t])
        best_fde_idx = np.argmin(displacement[:, final_t])

        return minADE, minFDE, best_ade_idx, best_fde_idx

    def metric_2(self, state_polygons, gt_state_polygons, gt_state_propertys):
        """
        state_polygons: K x timestamp_size x 4 x 2
        gt_state_polygons: 1 x timestamp_size x 4 x 2
        gt_state_propertys: 1 x timestamp_size x 5
        """
        pred_traj_polygon = state_polygons[:, self.history_size :]
        gt_traj_polygon = gt_state_polygons[:, self.history_size :]
        gt_state_propertys = gt_state_propertys[:, self.history_size :]
        gt_length = gt_traj_polygon.shape[1]
        gt_mask = gt_state_propertys[:, :, 3] > 0  # gt轨迹可能提前终止

        if gt_mask.sum() == 0:
            return np.nan, np.nan, 0, 0
        displacement = np.linalg.norm(pred_traj_polygon[:, :gt_length] - gt_traj_polygon, axis=-1).mean(
            axis=-1
        )  # K x t

        # ade
        displacement_mask_avg = np.sum(displacement * gt_mask, axis=-1) / np.sum(gt_mask)  # K
        minADE = np.min(displacement_mask_avg)
        best_ade_idx = np.argmin(displacement_mask_avg)

        # fde
        final_t = np.where(gt_mask[0])[0][-1]
        minFDE = np.min(displacement[:, final_t])
        best_fde_idx = np.argmin(displacement[:, final_t])

        return minADE, minFDE, best_ade_idx, best_fde_idx

    def _vis_raw_env(self, raw_env, ts, adviz, dobj_start_size):
        navi_info = raw_env[ts]["navi_infos"]
        # draw sub_path
        sub_path = navi_info["sub_path_main_path_points"]
        if sub_path is not None:
            adviz.draw_line(ts, "sub_path_main", sub_path[:, 0], sub_path[:, 1], color="green", alpha=0.2, thickness=1.0)
        else:
            adviz.add_tags(ts, ["no_sub_path"])

        sub_sub_paths = navi_info["sub_path_sub_path_points"]
        for j, sub_sub_path in enumerate(sub_sub_paths):
            adviz.draw_line(ts, f"sub_path_sub", sub_sub_path[:, 0], sub_sub_path[:, 1], color="orange", alpha=0.2, thickness=1.0)

        # draw action lane_nr_info
        main_action_1 = navi_info["main_action_1"]
        main_action_str_1 = MAIN_ACTION_MAPPING[main_action_1] if main_action_1 > 0 else "-"
        assistant_action_1 = navi_info["assistant_action_1"]
        assistant_action_str_1 = ASSIST_ACTION_MAPPING[assistant_action_1] if assistant_action_1 > 0 else "-"
        main_action_2 = navi_info["main_action_2"]
        main_action_str_2 = MAIN_ACTION_MAPPING[main_action_2] if main_action_2 > 0 else "-"
        assistant_action_2 = navi_info["assistant_action_2"]
        assistant_action_str_2 = ASSIST_ACTION_MAPPING[assistant_action_2] if assistant_action_2 > 0 else "-"
        link_main_distance_1 = navi_info["link_main_distance_1"]
        link_main_distance_2 = navi_info["link_main_distance_2"]
        lane_nr_distance = navi_info["lane_nr_remain_distance"]

        text2 = f"NextLane距: {lane_nr_distance:.1f}"
        for info in navi_info["lane_infos"]:
            lane_direction, lane_highline_direction, lane_is_drivable, lane_is_highline, lane_type = info
            lane_type_str = kLaneTypeMap[lane_type]
            lane_direction_str = get_lane_direction_str(lane_direction)
            lane_direction_highline_str = get_lane_direction_str(lane_highline_direction)

            prefix = ""
            postfix = ""
            if not lane_is_drivable:
                prefix += "X"
                postfix += "X"
            if lane_is_highline or lane_direction_highline_str:
                postfix = f"[{lane_direction_highline_str}]" + postfix
            text2 += f" {prefix}{lane_direction_str}{lane_type_str}{postfix}"

        adviz.add_navigation_msg(ts, text2, main_action_str_1, assistant_action_str_1, link_main_distance_1, main_action_str_2, assistant_action_str_2, link_main_distance_2)

        # draw tld # ["k", "red", "yellow", "green", "gray"]
        tld = raw_env[ts]["tld"]
        tldcolor = ["black", "red", "yellow", "green", "gray"]
        for i, c in enumerate(tld):
            c = tldcolor[c]
            adviz.add_metadatas(ts, {f"TLD {i}": f"{'↓←↑→'[i]} {c}"})

        # spd_limit
        spd_limit = raw_env[ts]["spd_limit"]
        adviz.add_speeds(ts, {"spd_limit": spd_limit})

        sobjs = raw_env[ts]["sobjs_polygon"]
        for d in sobjs:
            adviz.draw_box(ts, "static_objects", d, color="darkkhaki")

        road_sign = raw_env[ts]["road_sign"]
        for p, ptype in road_sign:
            adviz.draw_polygon(ts, "road_sign", p[:, 0], p[:, 1], color="seagreen", alpha=0.8, thickness=0.2)
            adviz.draw_text(ts, "road_sign_text", p.mean(axis=0)[:2], f"{ptype}", color="seagreen", alpha=1.0)

        lane_lines = raw_env[ts]["lane_lines"]
        linecmap = {1: "white", 2: "orange"}
        for p, a in lane_lines:
            # split the lane
            split_a = split_line(a)
            split_p = split_line(p)
            for a, p in zip(split_a, split_p):
                t, c = a[len(a) // 2][:2]
                c = linecmap.get(c, "w")
                adviz.draw_line(ts, "lane_lines", p[:, 0], p[:, 1], color=c, dashed=(t in [2, 8, 9]))

        centerline = raw_env[ts]["centerlines"]
        for p, t, c in centerline:
            if t in [2, 16]:
                adviz.draw_line(ts, "centerlines", p[:, 0], p[:, 1], color="green", thickness=0.1)

        # road_edge = raw_env[ts]["road_edge_vis"]
        # for p in road_edge:
            # adviz.draw_line(ts, "road_edge", p[:, 0], p[:, 1], color="yellow", thickness=0.2)
        road_edge = raw_env[ts]["road_edge"]
        for p in road_edge:
            adviz.draw_line(ts, "road_edge", p[:, 0], p[:, 1], color="purple", thickness=0.3)
        nomap_road_edge = raw_env[ts]["nomap_road_edge"]
        for p in nomap_road_edge:
            adviz.draw_line(ts, "nomap_road_edge", p[:, 0], p[:, 1], color="lightblue", thickness=0.3)

        god_polygon = raw_env[ts]["god_polygon_vis"]
        for p in god_polygon:
            if p.shape[0]>0:
                adviz.draw_polygon(ts, "god_polygon_vis", p[:, 0], p[:, 1], color="green", thickness=0.1)

        god_polygon = raw_env[ts]["god_polygon"]
        for p in god_polygon:
            adviz.draw_polygon(ts, "god_polygon", p[:, 0], p[:, 1], color="red", alpha=0.8, thickness=0.1)

        stop_line = raw_env[ts]["stop_line"]
        for p in stop_line:
            adviz.draw_line(ts, "stop_line", p[:, 0], p[:, 1], color="mediumslateblue")

        # add wmstoplines and waitzones
        areazones = self.raw_env[ts].get("waitzones", [])
        for polygon_point in areazones:
            adviz.draw_polygon(ts, "waitzones", polygon_point[:, 0], polygon_point[:, 1], color="yellow")
        ##增加待转区
        wm_stoplines = self.raw_env[ts].get("egopath_stoplines", [])
        for wm_stopline_junc in wm_stoplines:
            p = wm_stopline_junc[0]
            id = wm_stopline_junc[1]
            t = wm_stopline_junc[2]
            cx, cy = p.mean(axis=0)[:2]
            adviz.draw_line(ts, "wm_stoplines", p[:, 0], p[:, 1], color="red" if t==2 else "green")
            adviz.draw_text(ts, "wm_stoplines_text", (cx, cy), f"{id}_{t}", color="red" if t==2 else "green")

        checkpoints = raw_env[ts]["navi_infos"]["checkpoints"]
        for start_p, end_p, color in checkpoints:
            c = "green" if color == 1 else "blue" if color == 2 else "red"
            adviz.draw_line(ts, "checkpoints", [start_p[0], end_p[0]], [start_p[1], end_p[1]], color=c, alpha=0.3, thickness=0.5, dashed=True)

        navi_centerlins = raw_env[0]["navi_infos"]["navi_centerlines"]
        for navi_lane in navi_centerlins:
            if navi_lane[2] == 0:
                if navi_lane[1] is not None:
                    solid_line_start_index = navi_lane[1]
                    adviz.draw_points(ts, "navi_centerlines", navi_lane[0][solid_line_start_index:], color="red")
                    adviz.draw_points(ts, "navi_centerlines", navi_lane[0][:solid_line_start_index], color="green")
                else:
                    adviz.draw_points(ts, "navi_centerlines", navi_lane[0][:], color="green")
            else:
                adviz.draw_points(ts, "navi_centerlines", navi_lane[0][:], color="yellow")

        if "virtual_wall" in raw_env[ts]["navi_infos"]:
            virtual_wall = raw_env[ts]["navi_infos"]["virtual_wall"]
            for wall_coords in virtual_wall:
                adviz.draw_line(ts, "virtual_wall", [wall_coords[0][0], wall_coords[1][0]], [wall_coords[0][1], wall_coords[1][1]], color="red", thickness=0.4)

        # draw roadedge driving space
        if (
            "navi_road_driving_space" in raw_env[ts]["navi_infos"]
            and len(raw_env[ts]["navi_infos"]["navi_road_driving_space"]) > 0
        ):
            road_driving_space = raw_env[ts]["navi_infos"]["navi_road_driving_space"]
            if road_driving_space["drivable_polygon"] is not None:
                adviz.draw_polygon(ts, "road_driving_space", road_driving_space["drivable_polygon"][:, 0], road_driving_space["drivable_polygon"][:, 1], color="lightgray", alpha=0.5)
            if road_driving_space["left_boundary"] is not None:
                adviz.draw_line(ts, "road_driving_space", road_driving_space["left_boundary"][:, 0], road_driving_space["left_boundary"][:, 1], color="blue")
                adviz.draw_points(ts, "road_driving_space", [road_driving_space["left_boundary"][0]], color="red")
            if road_driving_space["right_boundary"] is not None:
                adviz.draw_line(ts, "road_driving_space", road_driving_space["right_boundary"][:, 0], road_driving_space["right_boundary"][:, 1], color="red")
                adviz.draw_points(ts, "road_driving_space", [road_driving_space["right_boundary"][0]], color="blue")

            left_start_index = road_driving_space.get("left_start_index", None)
            if left_start_index is not None and road_driving_space["left_boundary"] is not None:
                left_start_point = road_driving_space["left_boundary"][left_start_index]
                adviz.draw_points(ts, "road_driving_space", [left_start_point], color="green")

        # 从 raw_data中读取其他动态物
        if len(raw_env[0]["dobjs_full"]) > ts:
            _, dobjs = raw_env[0]["dobjs_full"][ts]  # 相对于最初的原点的位置
            dobjs_polygon = raw_env[0]["dobjs_polygon"][ts]
            select_raw_tids = raw_env[ts]["select_raw_tids"]
            static_raw_tids = select_raw_tids["static"]
            dynamic_raw_tids = select_raw_tids["dynamic"]
            trackids = dobjs[:, 9].astype(np.int32)
            cids = [get_map_cls_to_3cls(cid) for cid in dobjs[:, 7].astype(int)]
            cxcy = dobjs_polygon.mean(axis=1)
            pxpy = dobjs_polygon[:, 1:3, :].mean(axis=1)
            parked_vehicle_infos = raw_env[ts]["parked_vehicle"]
            parked_vehicle_id = []
            for parked_vehicle_info in parked_vehicle_infos:
                if parked_vehicle_info["object_stop_info"] == 1:
                    parked_vehicle_id.append(parked_vehicle_info["object_id"])
            for d, (x1, y1), (x2, y2), tid, cid in zip(dobjs_polygon, cxcy, pxpy, trackids, cids):
                if tid in parked_vehicle_id:
                    adviz.draw_text(ts, "parked_vehicle", (x1, y1), "P", color="red")
                if tid in static_raw_tids or (tid in dynamic_raw_tids and ts >= dobj_start_size):
                    adviz.draw_box(ts, "dynamic_objects", d, color=COLORS_ID[tid % len(COLORS_ID)], alpha=0.7)
                else:
                    adviz.draw_box(ts, "dynamic_objects", d, color=(10, 10, 10), alpha=0.3)
                # if tid in raw_env[ts]["select_raw_tids"]["dynamic"] and cid == 'vehicle':
                #     ax.text(x1, y1, str(tid), fontsize=7, color='black', ha='center', va='center')
        else:
            adviz.add_tags(ts, ["NoMoreGT"])

    def _vis_input_env(self, input_polygon, input_polyline, input_poly_mask, input_property, ts, adviz):
        # cls id: 0 pad, 1 ego, 2 vehicle, 3 bicycle, 4 pedistrian, 5 static_vehicle, 6 static_bicycle,
        # 7 static_pedestrian, 8 sobjs, 9 road_sign, 10 road_arrow, 11 lane_lines, 12 road_edge, 13 stop_line,
        # 14 tld, 15 spd_limit, 16 action_1, 17 action_2, 18 sub_path, 19 lane_info, 20 lane_highline_info
        # draw navi path
        navi_path_index = input_property[:, 0] == 18
        navi_path = input_polyline[navi_path_index]  # n x 4 x 2
        navi_mask = input_poly_mask[navi_path_index, 1]  # n
        assert np.all(input_poly_mask[navi_path_index, 0] == 0)
        for p, m in zip(navi_path, navi_mask):
            p = p[:m, :2]
            adviz.draw_line(ts, "navi_path", p[:, 0], p[:, 1], color="green", alpha=0.2, thickness=1.0)

        # draw tld # ["k", "red", "yellow", "green", "gray"]
        tld_index = input_property[:, 0] == 14
        tld = input_property[tld_index, 1] - 56
        assert np.all(input_poly_mask[tld_index] == 0)
        if len(tld) > 0:
            tldcolor = ["black", "red", "yellow", "green", "gray"]
            c = tldcolor[tld[0]]
            adviz.add_metadatas(ts, {"TLD": f"{c}"})

        # spd_limit
        spd_limit_index = input_property[:, 0] == 15
        assert np.all(input_poly_mask[spd_limit_index] == 0)
        spd_limit = input_property[spd_limit_index, 1] - 61
        if len(spd_limit) > 0:
            adviz.add_speeds(ts, {"spd_limit": spd_limit})

        # draw sobjs
        sobjs_index = input_property[:, 0] == 8
        assert np.all(input_poly_mask[sobjs_index, 1] == 0)
        sobjs = input_polygon[sobjs_index]  # n x 4 x 2
        for d in sobjs:
            adviz.draw_box(ts, "static_objects", d, color="olive")

        # draw road_sign
        road_sign_index = input_property[:, 0] == 9
        assert np.all(input_poly_mask[road_sign_index, 1] == 0)
        road_sign = input_polygon[road_sign_index]  # n x 4 x 2
        ptypes = input_property[road_sign_index, 1]
        for p, ptype in zip(road_sign, ptypes):
            px, py = p.mean(axis=0)[:2]
            adviz.draw_box(ts, "road_sign", p, color="seagreen", alpha=0.8)
            adviz.draw_text(ts, "road_sign_text", (px, py), f"{ptype}", color="seagreen")

        # draw lane_lines
        lane_lines_index = input_property[:, 0] == 11
        assert np.all(input_poly_mask[lane_lines_index, 0] == 0)
        lane_lines = input_polyline[lane_lines_index]  # n x 4 x 2
        lane_line_mask = input_poly_mask[lane_lines_index, 1]  # n
        lane_line_type = input_property[lane_lines_index, 1] - 41  # n
        lane_line_color = input_property[lane_lines_index, 2]  # n
        linecmap = {1: "white", 2: "orange"}
        for p, a, c, m in zip(lane_lines, lane_line_type, lane_line_color, lane_line_mask):
            c = linecmap.get(c, "w")
            p = p[:m, :2]
            adviz.draw_line(ts, "lane_lines", p[:, 0], p[:, 1], color=c, thickness=0.2, dashed=(a in [2, 8, 9]))

        # draw road_edge
        road_edge_index = input_property[:, 0] == 12
        assert np.all(input_poly_mask[road_edge_index, 0] == 0)
        road_edge = input_polyline[road_edge_index]  # n x 4 x 2
        road_edge_mask = input_poly_mask[road_edge_index, 1]  # n
        for p, m in zip(road_edge, road_edge_mask):
            p = p[:m, :2]
            adviz.draw_line(ts, "road_edge", p[:, 0], p[:, 1], color="purple", thickness=0.2)

        # draw stop_line
        stop_line_index = input_property[:, 0] == 13
        assert np.all(input_poly_mask[stop_line_index, 0] == 0)
        stop_line = input_polyline[stop_line_index]  # n x 4 x 2
        stop_line_mask = input_poly_mask[stop_line_index, 1]  # n
        for p, m in zip(stop_line, stop_line_mask):
            p = p[:m, :2]
            adviz.draw_line(ts, "stop_line", p[:, 0], p[:, 1], color="mediumslateblue", thickness=0.2)

        # draw dobjs
        dobjs_index = (input_property[:, 0] > 1) & (input_property[:, 0] < 8)
        dobjs = input_polygon[dobjs_index]  # n x 4 x 2
        assert np.all(input_poly_mask[dobjs_index, 1] == 0)
        trackids = input_property[dobjs_index, 3]  # n
        timestamps = input_property[dobjs_index, 4]  # n
        dobjs = dobjs[timestamps == ts]
        trackids = trackids[timestamps == ts]
        cxcy = dobjs.mean(axis=1)
        pxpy = dobjs[:, 1:3, :].mean(axis=1)
        edge = "darkgreen"
        for d, (x1, y1), (x2, y2), tid in zip(dobjs, cxcy, pxpy, trackids):
            adviz.draw_box(ts, "dynamic_objects", d, color=np.array(COLORS_ID[tid % len(COLORS_ID)]) / 255.0, alpha=0.7)

    def vis(
        self,
        savename,
        ego_polygon,
        actions=None,
        gt_polygon=None,
        pred_polygons_draw=None,
        reward_keys=None,
        turnlightsignal_pred=None,
        turnlightsignal_gt=None,
        **kwargs,
    ):
        """
        savename: str
        ego_polygon: timestamp_size x 4 x 2
        actions: (timestamp_size - history_size) x 1
        self.raw_env: list
        """
        # ego traj
        gt_traj = None if gt_polygon is None else gt_polygon.mean(axis=1)  # n x 2
        ego_traj = ego_polygon.mean(axis=1)  # n x 2
        dobj_start_size = self.raw_env[0]["dobj_start_size"]

        # 速度曲线
        velocity = ego_traj[1:] - ego_traj[:-1]
        velocity = np.linalg.norm(velocity, axis=1) * self.fps * 3.6
        velocity = np.insert(velocity, 0, velocity[0])
        gt_velocity = gt_traj[1:] - gt_traj[:-1]
        gt_velocity = np.linalg.norm(gt_velocity, axis=1) * self.fps * 3.6
        gt_velocity = np.insert(gt_velocity, 0, gt_velocity[0])
        gt_egomotion_velocity = np.array(self.raw_env[0]["gt_vehspeeds"])[:-1]
        v_min = min(velocity.min(), gt_velocity.min(), gt_egomotion_velocity.min())
        v_max = max(velocity.max(), gt_velocity.max(), gt_egomotion_velocity.max())
        v_diff = v_max - v_min
        timestamps = np.arange(self.timestamp_size)

        uuid_pattern1 = r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}'
        uuid_pattern2 = r'\d{8}T\d{6}_[A-Z0-9]+_\d+\.\d+_\d+\.\d'
        uuid = self.raw_env[0]["v3_ceph"] if "v3_ceph" in self.raw_env[0].keys() else None
        uuid = (re.findall(uuid_pattern1, str(uuid)) + re.findall(uuid_pattern2, str(uuid)))
        uuid = uuid[-1] if len(uuid) > 0 else None

        adviz = AdvizRenderer(uuid=uuid)

        # 检查reward_keys是否需要使用默认值
        if reward_keys is None:
            reward_keys = DEFAULT_REWARD_KEYS
        else:
            # 检查reward_keys中的所有元素是否都不在kwargs中
            valid_keys = [key for key in reward_keys if key in kwargs]
            if not valid_keys:  # 如果没有任何有效的key
                reward_keys = DEFAULT_REWARD_KEYS
        if "reward" not in reward_keys:
            reward_keys.append("reward")
        _reward_keys = []
        for reward_key in reward_keys:
            if reward_key not in kwargs:
                continue
            _reward_keys.append(reward_key)
        reward_keys = _reward_keys

        rewards_list = []
        for reward_key in reward_keys:
            if kwargs.get(reward_key) is None:
                continue
            rewards = [0.0 for _ in range(self.history_size - 1)] + kwargs[reward_key].tolist()  # 66帧补全到80帧
            if len(rewards) < len(timestamps):
                pad_len = len(timestamps) - len(rewards)
                rewards += [np.nan] * pad_len
            rewards_list.append(rewards)


        action_label_key = []
        action_label_list = []

        for key in ["latitude_pred_labels", "latitude_gt_labels", "longitude_pred_labels", "longitude_gt_labels"]:
            if key not in kwargs or kwargs.get(key) is None:
                continue

            action_label_key.append(key)

            labels = [0 for _ in range(self.history_size)] + kwargs[key].tolist()
            if len(labels) < len(timestamps):
                pad_len = len(timestamps) - len(labels)
                labels += [np.nan] * pad_len
            action_label_list.append(labels)

        # 画图
        for ts in range(ego_polygon.shape[0]):
            state_polygon_at_t = ego_polygon[ts]
            if gt_polygon is not None and ts < len(gt_polygon):
                gt_state_polygon_at_t = gt_polygon[ts]

            # raw env
            if self.input_tensor_data is None:
                self._vis_raw_env(self.raw_env, ts, adviz, dobj_start_size)
            else:
                self._vis_input_env(*self.input_tensor_data, ts, adviz)

            # draw ego turnlightsignal
            if turnlightsignal_pred is not None and ts > self.history_size:
                index = ts - self.history_size
                cursignal = turnlightsignal_pred[index] if index < len(turnlightsignal_pred) else "none"
                cursignal_gt = turnlightsignal_gt[ts] if ts < len(turnlightsignal_gt) else "none"
                adviz.add_metadatas(ts, {"turnlight_signal": str(cursignal) + " | " + str(cursignal_gt)})
            # draw ego
            ego_pose = get_xyyaw_from_polygon(state_polygon_at_t[None, :])[0]
            adviz.draw_box(ts, "ego", state_polygon_at_t, color="red", alpha=0.8)
            adviz.draw_text(ts, "ego", [ego_pose[0], ego_pose[1], 2.0], "EGO", color="white", fontsize=0.8)
            adviz.set_ego_transform(ts, [ego_pose[0], ego_pose[1], 0.0], ego_pose[6])

            passageway = kwargs.get("passageway", None)
            if passageway:
                adviz.draw_line(ts, "passageway", passageway[0][:, 0], passageway[0][:, 1], color="deepskyblue", dashed=True)
                adviz.draw_line(ts, "passageway", passageway[1][:, 0], passageway[1][:, 1], color="deepskyblue", dashed=True)

            # draw gt ego
            if gt_polygon is not None and ts < len(gt_polygon):
                gt_state_polygon_at_t = gt_polygon[ts]
                if ts >= self.history_size - 1:
                    gt_ego_pose = get_xyyaw_from_polygon(gt_state_polygon_at_t[None, :])[0]
                    adviz.draw_box(ts, "gt_ego", gt_state_polygon_at_t, color="blue", alpha=0.4)
                    adviz.draw_text(ts, "gt_ego", [gt_ego_pose[0], gt_ego_pose[1], 2.0], "GT", color="white", fontsize=0.8)

            gtv = gt_velocity[ts] if ts < len(gt_velocity) else np.nan
            gt_ego_v = gt_egomotion_velocity[ts] if ts < len(gt_egomotion_velocity) else np.nan
            adviz.add_speeds(ts, {
                "spd_pred": velocity[ts],
                "spd_gt": gtv,
                "spd_gt_egomotion": gt_ego_v,
            })

            # other infos, starts from s0 (history_size - 1)
            reward_dict = {k:v[ts] for k, v in zip(reward_keys, rewards_list)}
            adviz.add_rewards(ts, reward_dict)

            action_dict = {k:v[ts] for k, v in zip(action_label_key, action_label_list)}
            adviz.add_action(ts, action_dict)

            diags_dict = {}
            if ts >= self.history_size - 1:
                for k, v in kwargs.items():
                    if k in reward_keys:
                        continue
                    try:
                        diags_dict[k] = float(v[ts - self.history_size + 1])
                    except:
                        pass
            logger.info(f"reward {reward_dict}")
            logger.info(f"diag {diags_dict}")
            adviz.add_diags(ts, diags_dict)

            # ego traj
            if ts < self.history_size:
                adviz.draw_line(ts, "ego_traj_history", ego_traj[: self.history_size, 0], ego_traj[: self.history_size, 1], color="blue", alpha=0.3, thickness=0.8)
            adviz.draw_line(ts, "ego_traj", ego_traj[max(ts, self.history_size) :, 0], ego_traj[max(ts, self.history_size) :, 1], color="deeppink", alpha=0.4, thickness=0.8)
            if ts >= self.history_size and pred_polygons_draw is not None:
                # pred traj to draw
                pred_traj_draw = pred_polygons_draw[ts - self.history_size].mean(axis=1)  # ndraw x 2
                adviz.draw_line(ts, "pred_ego_traj", pred_traj_draw[:, 0], pred_traj_draw[:, 1], color="orange", alpha=1.0, thickness=0.4)

            # ego gt traj(dynamic)
            if gt_traj is not None:
                if ts >= self.history_size - 1:
                    gt_traj_15 = gt_traj[ts : ts + self.history_size + 1]
                    adviz.draw_line(ts, "gt_ego_traj", gt_traj_15[:, 0], gt_traj_15[:, 1], color="blue", alpha=0.3, thickness=0.4)

        access_url, cos_path  = adviz.save()
        save_path = savename.replace(".mcap", ".txt")
        with open(save_path, "w") as f:
            f.write(cos_path)
            f.write("\n")
            f.write(access_url)
        print(f"Visualization saved to {save_path}, access: {access_url}", flush=True)

        return save_path

    def vis_eachstep(
        self,
        savename,
        ego_polygon,
        actions=None,
        gt_polygon=None,
        hidpi=True,
        vis_reward=True,
        pred_polygons_draw=None,
        reward_keys=None,
        log_infos=None,
        topk_traj=12,
        top_reward_list=None,
        show_top_traj=False,
        **kwargs,
    ):
        """
        savename: str
        ego_polygon: timestamp_size x 4 x 2
        actions: (timestamp_size - history_size) x 1
        self.raw_env: list
        """
        # ego traj
        gt_traj = None if gt_polygon is None else gt_polygon.mean(axis=1)  # n x 2
        # ego_traj = ego_polygon.mean(axis=1)  # n x 2
        dobj_start_size = self.raw_env[0]["dobj_start_size"]

        uuid_pattern1 = r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}'
        uuid_pattern2 = r'\d{8}T\d{6}_[A-Z0-9]+_\d+\.\d+_\d+\.\d'
        uuid = self.raw_env[0]["v3_ceph"] if "v3_ceph" in self.raw_env[0].keys() else None
        uuid = (re.findall(uuid_pattern1, str(uuid)) + re.findall(uuid_pattern2, str(uuid)))
        uuid = uuid[-1] if len(uuid) > 0 else None

        adviz = AdvizRenderer(savename, uuid=uuid, save_to_cos=True)

        gt_velocity = gt_traj[1:] - gt_traj[:-1]
        gt_velocity = np.linalg.norm(gt_velocity, axis=1) * self.fps * 3.6
        gt_velocity = np.insert(gt_velocity, 0, gt_velocity[0])
        gt_egomotion_velocity = np.array(self.raw_env[0]["gt_vehspeeds"])[:-1]
        timestamps = np.arange(self.timestamp_size)
        use_timestamps = self.raw_env[0]['use_timestamps']

        # reward曲线
        if vis_reward:
            # 检查reward_keys是否需要使用默认值
            if reward_keys is None:
                reward_keys = DEFAULT_REWARD_KEYS
            else:
                # 检查reward_keys中的所有元素是否都不在kwargs中
                valid_keys = [key for key in reward_keys if key in kwargs]
                if not valid_keys:  # 如果没有任何有效的key
                    reward_keys = DEFAULT_REWARD_KEYS
        if "reward" not in reward_keys:
            reward_keys.append("reward")
        _reward_keys = []
        for reward_key in reward_keys:
            if reward_key not in kwargs:
                logger.warning(f"reward_key {reward_key} not in kwargs")
                continue
            _reward_keys.append(reward_key)
        reward_keys = _reward_keys

        cmap_name = "viridis"
        cmap = plt.get_cmap(cmap_name)
        colors = [cmap(i) for i in np.linspace(0, 1, topk_traj)]

        data_length = min(gt_traj.shape[0], self.history_size + len(pred_polygons_draw))
        for ts in range(data_length):
            # state_polygon_at_t = ego_polygon[ts]
            if gt_polygon is not None and ts < len(gt_polygon):
                gt_state_polygon_at_t = gt_polygon[ts]

            ego_pose = gt_state_polygon_at_t.mean(axis=0)
            adviz.draw_box(ts, "ego", gt_state_polygon_at_t, color="red", alpha=0.8)
            adviz.draw_text(ts, "ego", [ego_pose[0], ego_pose[1], 2.0], "EGO", color="white", fontsize=0.8)
            adviz.set_ego_transform(ts, [ego_pose[0], ego_pose[1], 0.0], ego_pose[6])

            # raw env
            if self.input_tensor_data is None:
                disptext = self._vis_raw_env(self.raw_env, ts, adviz, dobj_start_size)
            else:
                disptext = self._vis_input_env(*self.input_tensor_data, ts, adviz)

            # draw gt ego
            if gt_polygon is not None and ts < len(gt_polygon):
                gt_state_polygon_at_t = gt_polygon[ts]
                gt_ego_pose = get_xyyaw_from_polygon(gt_state_polygon_at_t[None, :])[0]
                adviz.draw_box(ts, "gt_ego", gt_state_polygon_at_t, color="blue", alpha=0.4)
                adviz.draw_text(ts, "gt_ego", [gt_ego_pose[0], gt_ego_pose[1], 2.0], "GT", color="white", fontsize=0.8)

            gtv = gt_velocity[ts] if ts < len(gt_velocity) else np.nan
            gt_ego_v = gt_egomotion_velocity[ts] if ts < len(gt_egomotion_velocity) else np.nan
            adviz.add_speeds(ts, {
                "spd_gt": gtv,
                "spd_gt_egomotion": gt_ego_v,
            })

            if ts >= self.history_size - 1 and pred_polygons_draw is not None:
                # pred traj to draw
                idx = ts - (self.history_size - 1)
                if idx >= len(pred_polygons_draw):
                    continue

                reward_list = top_reward_list[idx]
                top1_idx = np.argmax(reward_list)
                pred_traj_draws = pred_polygons_draw[idx][:, self.history_size :].mean(axis=-2)  # ndraw x 2
                num_traj = pred_traj_draws.shape[0]
                for traj_id, pred_traj_draw in enumerate(pred_traj_draws):
                    if show_top_traj and traj_id != top1_idx:
                        continue
                    color = "red" if traj_id == top1_idx else colors[traj_id]
                    linestyle = "-" if traj_id <= num_traj - 10 else "--"
                    adviz.draw_line(ts, f"pred_ego_traj_{traj_id}", pred_traj_draw[:, 0], pred_traj_draw[:, 1], color=color, alpha=0.9, thickness=1.5, dashed=(linestyle=="--"))
                    if traj_id == top1_idx:
                        adviz.draw_points(ts, f"pred_ego_traj_{traj_id}", pred_traj_draw, color=color, size=1.8)

            # ego gt traj(dynamic)
            if gt_traj is not None:
                if ts >= self.history_size - 1:
                    gt_traj_15 = gt_traj[ts : ts + self.history_size + 1]
                    adviz.draw_points(ts, "gt_ego_traj", gt_traj_15, color="blue", size=1.5)

        access_url, cos_path  = adviz.save()
        save_path = savename.replace(".mcap", ".txt")
        with open(save_path, "w") as f:
            f.write(cos_path)
            f.write("\n")
            f.write(access_url)
        logger.info(f"Visualization saved to {save_path}, access: {access_url}")
        return save_path


class PlannerEnvSimplified(PlannerEnv):
    def __init__(
        self,
        raw_env,
        timestamp_size,
        history_size,
        fps,
        pedestrian_tokenizer=None,
        input_tensor_data=None,
        eval_only=False,
        use_ttc=True,
    ):
         super().__init__(
        raw_env,
        timestamp_size,
        15,
        fps,
        pedestrian_tokenizer,
        input_tensor_data,
        eval_only,
        use_ttc,
        )

    def _vis_raw_env(self, raw_env, ts, ax, dobj_start_size):
        navi_info = raw_env[ts]["navi_infos"]
        # draw sub_path
        sub_path = navi_info["sub_path_main_path_points"]
        if sub_path is not None:
            ax.plot(sub_path[:, 0], sub_path[:, 1], color="green", linewidth=3, alpha=0.2)
            disptext = ""
        else:
            disptext = "no sub_path "

        # draw action lane_nr_info
        main_action_1 = navi_info["main_action_1"]
        main_action_str_1 = MAIN_ACTION_MAPPING[main_action_1] if main_action_1 > 0 else "-"
        assistant_action_1 = navi_info["assistant_action_1"]
        assistant_action_str_1 = ASSIST_ACTION_MAPPING[assistant_action_1] if assistant_action_1 > 0 else "-"
        main_action_2 = navi_info["main_action_2"]
        main_action_str_2 = MAIN_ACTION_MAPPING[main_action_2] if main_action_2 > 0 else "-"
        assistant_action_2 = navi_info["assistant_action_2"]
        assistant_action_str_2 = ASSIST_ACTION_MAPPING[assistant_action_2] if assistant_action_2 > 0 else "-"
        link_main_distance_1 = navi_info["link_main_distance_1"]
        link_main_distance_2 = navi_info["link_main_distance_2"]
        lane_nr_distance = navi_info["lane_nr_remain_distance"]

        text = (
            f"主1: {main_action_str_1} 辅1: {assistant_action_str_1} 距1: {link_main_distance_1}"
            f"  主2: {main_action_str_2} 辅2: {assistant_action_str_2} 距2: {link_main_distance_2}"
        )
        text2 = f"NextLane距: {lane_nr_distance}"
        for info in navi_info["lane_infos"]:
            lane_direction, lane_highline_direction, lane_is_drivable, lane_is_highline, lane_type = info
            lane_type_str = kLaneTypeMap[lane_type]
            lane_direction_str = get_lane_direction_str(lane_direction)
            lane_direction_highline_str = get_lane_direction_str(lane_highline_direction)

            prefix = ""
            postfix = ""
            if not lane_is_drivable:
                prefix += "X"
                postfix += "X"
            if lane_is_highline or lane_direction_highline_str:
                postfix = f"[{lane_direction_highline_str}]" + postfix
            text2 += f" {prefix}{lane_direction_str}{lane_type_str}{postfix}"

        xmin, xmax = ax.get_xlim()
        ymin, ymax = ax.get_ylim()
        # plt.figtext(0.1, 0.96, text, color='k', ha='left', va='top', fontproperties="SimHei_Plannn2")
        # plt.figtext(0.1, 0.92, text2, color='k', ha='left', va='top', fontproperties="SimHei_Plannn2")

        # draw text on right
        ax.text(xmax - 5, ymax - 1, text, color="k", ha="right", va="top", fontproperties="SimHei_Plannn2")
        ax.text(xmax - 5, ymax - 6, text2, color="k", ha="right", va="top", fontproperties="SimHei_Plannn2")

        # draw tld # ["k", "red", "yellow", "green", "gray"]
        tld = raw_env[ts]["tld"]
        tldcolor = ["k", "red", "yellow", "green", "gray"]
        for i, c in enumerate(tld):
            c = tldcolor[c]
            ax.scatter(xmin + 5 + i * 5, ymax - 5, color=c, s=100)
            ax.text(xmin + 4 + i * 5, ymax - 6, "↓←↑→"[i], color="k")

        # spd_limit
        spd_limit = raw_env[ts]["spd_limit"]
        disptext += f", limit: {spd_limit}"

        sobjs = raw_env[ts]["sobjs_polygon"]
        for d in sobjs:
            ax.fill(d[:, 0], d[:, 1], color="olive", alpha=0.7, edgecolor="darkkhaki", linewidth=0.5)

        road_sign = raw_env[ts]["road_sign"]
        for p, ptype in road_sign:
            cx, cy = p.mean(axis=0)[:2]
            ax.fill(p[:, 0], p[:, 1], color="slateblue", alpha=0.5, edgecolor="seagreen", linewidth=0.5)
            ax.text(cx, cy, f"{ptype}", fontsize=5, color="seagreen", ha="center", va="center")

        lane_lines = raw_env[ts]["lane_lines"]
        linecmap = {1: "k", 2: "orange"}
        for p, a in lane_lines:
            # split the lane
            split_a = split_line(a)
            split_p = split_line(p)
            for a, p in zip(split_a, split_p):
                t, c = a[len(a) // 2][:2]
                c = linecmap.get(c, "w")
                s = "--" if t in [2, 8, 9] else "-"
                ax.plot(p[:, 0], p[:, 1], color=c, linestyle=s, linewidth=1)

        centerline = raw_env[ts]["centerlines"]
        for p, t, c in centerline:
            if t in [2, 16]:
                ax.plot(p[:, 0], p[:, 1], color="green", linestyle="-", linewidth=1)

        road_edge = raw_env[ts]["road_edge_vis"]
        for p in road_edge:
            ax.plot(p[:, 0], p[:, 1], color="yellow", linestyle="-.", linewidth=1)

        road_edge = raw_env[ts]["road_edge"]
        for p in road_edge:
            ax.plot(p[:, 0], p[:, 1], color="purple", linestyle="-.", linewidth=1)
        nomap_road_edge = raw_env[ts]["nomap_road_edge"]
        for p in nomap_road_edge:
            ax.plot(p[:, 0], p[:, 1], color="lightblue", linestyle="-.", linewidth=1)

        god_polygon = raw_env[ts]["god_polygon_vis"]
        for p in god_polygon:
            if p.shape[0]>0:
                ax.plot(p[:, 0], p[:, 1], color="green", linestyle="-", linewidth=1)

        god_polygon = raw_env[ts]["god_polygon"]
        for p in god_polygon:
            ax.plot(p[:, 0], p[:, 1], color="red", linestyle="-", linewidth=1)

        stop_line = raw_env[ts]["stop_line"]
        for p in stop_line:
            ax.plot(p[:, 0], p[:, 1], color="mediumslateblue")

        checkpoints = raw_env[ts]["navi_infos"]["checkpoints"]
        for start_p, end_p, color in checkpoints:
            if color == 1:
                ax.plot([start_p[0], end_p[0]], [start_p[1], end_p[1]], "g:")
            elif color == 2:
                ax.plot([start_p[0], end_p[0]], [start_p[1], end_p[1]], "b-")
            elif color == 3:
                ax.plot([start_p[0], end_p[0]], [start_p[1], end_p[1]], "r-")

        navi_centerlins = raw_env[ts]["navi_infos"]["navi_centerlines"]
        for navi_lane in navi_centerlins:
            if navi_lane[1] is not None:
                solid_line_start_index = navi_lane[1]
                ax.plot(navi_lane[0][solid_line_start_index:, 0], navi_lane[0][solid_line_start_index:, 1], "r*")
                ax.plot(navi_lane[0][:solid_line_start_index, 0], navi_lane[0][:solid_line_start_index:, 1], "g*")
            else:
                ax.plot(navi_lane[0][:, 0], navi_lane[0][:, 1], "g*")

        # 从 raw_data中读取其他动态物
        if len(raw_env[0]["dobjs_full"]) > ts:
            _, dobjs = raw_env[0]["dobjs_full"][ts]  # 相对于最初的原点的位置
            dobjs_polygon = raw_env[0]["dobjs_polygon"][ts]
            select_raw_tids = raw_env[ts]["select_raw_tids"]
            static_raw_tids = select_raw_tids["static"]
            dynamic_raw_tids = select_raw_tids["dynamic"]
            trackids = dobjs[:, 9].astype(np.int32)
            cids = [get_map_cls_to_3cls(cid) for cid in dobjs[:, 7].astype(int)]
            cxcy = dobjs_polygon.mean(axis=1)
            pxpy = dobjs_polygon[:, 1:3, :].mean(axis=1)
            edge = "darkgreen"
            for d, (x1, y1), (x2, y2), tid, cid in zip(dobjs_polygon, cxcy, pxpy, trackids, cids):
                if tid in static_raw_tids or (tid in dynamic_raw_tids and ts >= dobj_start_size):
                    ax.fill(
                        d[:, 0],
                        d[:, 1],
                        color=np.array(COLORS_ID[tid % len(COLORS_ID)]) / 255.0,
                        alpha=0.7,
                        edgecolor=edge,
                        linewidth=0.8,
                    )
                    ax.plot([x1, x2], [y1, y2], color=edge, linewidth=0.5)
                else:
                    ax.fill(
                        d[:, 0],
                        d[:, 1],
                        color=np.array([10, 10, 10]) / 255.0,
                        alpha=0.3,
                        edgecolor="lightgray",
                        linewidth=0.2,
                    )
                # if tid in raw_env[ts]["select_raw_tids"]["dynamic"] and cid == 'vehicle':
                #     ax.text(x1, y1, str(tid), fontsize=7, color='black', ha='center', va='center')
        else:
            disptext += ", NoMoreGT!"
        return disptext

    def vis(
        self,
        savename,
        ego_polygon,
        gt_polygon=None,
        hidpi=True,
        pred_polygons_draw=None,
        turnlightsignal_pred=None,
        turnlightsignal_gt=None,
        CE_loss=None,
        navi_loss=None,
        perp_dist=None,
        dist=None,
        best_pts_list=None,
        navi_loss_l=None,
        perp_dist_l=None,
        dist_l=None,
        best_pts_list_l=None,
        navi_loss_r=None,
        perp_dist_r=None,
        dist_r=None,
        best_pts_list_r=None,
        active_walls_bt=None,
        angle=None,
        loss_angle=None
    ):
        """
        savename: str
        ego_polygon: timestamp_size x 4 x 2
        actions: (timestamp_size - history_size) x 1
        self.raw_env: list
        """
        tmpdir = tempfile.TemporaryDirectory()
        # ego traj
        gt_traj = None if gt_polygon is None else gt_polygon.mean(axis=1)  # n x 2
        ego_traj = ego_polygon.mean(axis=1)  # n x 2
        dobj_start_size = self.raw_env[0]["dobj_start_size"]
        if hidpi:
            global_xmin, global_xmax = (-75, 75)
            global_ymin, global_ymax = (-25, 25)
        else:
            global_xmin, global_xmax = (-100, 200)
            global_ymin, global_ymax = (-50, 50)
        assert (global_xmax - global_xmin) / (global_ymax - global_ymin) == 3.0

        # 速度曲线
        velocity = ego_traj[1:] - ego_traj[:-1]
        velocity = np.linalg.norm(velocity, axis=1) * self.fps * 3.6
        velocity = np.insert(velocity, 0, velocity[0])
        gt_velocity = gt_traj[1:] - gt_traj[:-1]
        gt_velocity = np.linalg.norm(gt_velocity, axis=1) * self.fps * 3.6
        gt_velocity = np.insert(gt_velocity, 0, gt_velocity[0])
        gt_egomotion_velocity = np.array(self.raw_env[0]["gt_vehspeeds"])[:-1]
        v_min = min(velocity.min(), gt_velocity.min(), gt_egomotion_velocity.min())
        v_max = max(velocity.max(), gt_velocity.max(), gt_egomotion_velocity.max())
        v_diff = v_max - v_min
        timestamps = np.arange(self.timestamp_size)


        # 画图
        for ts in range(gt_polygon.shape[0]):
            state_polygon_at_t = ego_polygon[ts]
            if gt_polygon is not None and ts < len(gt_polygon):
                gt_state_polygon_at_t = gt_polygon[ts]

            fig, ax = plt.subplots(figsize=(15, 6))

            ego_pose = state_polygon_at_t.mean(axis=0)
            xmin, xmax = (global_xmin + ego_pose[0], global_xmax + ego_pose[0])
            ymin, ymax = (global_ymin + ego_pose[1], global_ymax + ego_pose[1])
            ax.set_xlim(xmin, xmax)
            ax.set_ylim(ymin, ymax)  # vis limit
            ax.set_aspect("equal")
            ax.grid(linestyle="--")

            # raw env
            if self.input_tensor_data is None:
                disptext = self._vis_raw_env(self.raw_env, ts, ax, dobj_start_size)
            else:
                disptext = self._vis_input_env(*self.input_tensor_data, ts, ax)

            # draw ego turnlightsignal
            if turnlightsignal_pred is not None and ts > self.history_size:
                index = ts - self.history_size
                cursignal = turnlightsignal_pred[index]
                cursignal_gt = turnlightsignal_gt[ts]
                x, y = ego_traj[ts]
                ax.text(
                    x,
                    y,
                    str(cursignal) + " | " + str(cursignal_gt),
                    fontsize=12,
                    color="blue",
                    ha="center",
                    va="center",
                )
            # draw ego
            x1, y1 = state_polygon_at_t.mean(axis=0)
            x2, y2 = state_polygon_at_t[1:3, :].mean(axis=0)
            ax.fill(
                state_polygon_at_t[:, 0],
                state_polygon_at_t[:, 1],
                color=np.array(COLORS_ID[0]) / 255.0,
                alpha=0.7,
                edgecolor="red",
                linewidth=1.0,
            )
            ax.plot([x1, x2], [y1, y2], color="red", linewidth=0.5)

            # draw gt ego
            if gt_polygon is not None and ts < len(gt_polygon):
                gt_state_polygon_at_t = gt_polygon[ts]
                if ts >= self.history_size - 1:
                    x3, y3 = gt_state_polygon_at_t.mean(axis=0)
                    x4, y4 = gt_state_polygon_at_t[1:3, :].mean(axis=0)
                    ax.fill(
                        gt_state_polygon_at_t[:, 0],
                        gt_state_polygon_at_t[:, 1],
                        edgecolor="blue",
                        alpha=0.7,
                        facecolor="none",
                        linewidth=1.0,
                    )
                    ax.plot([x3, x4], [y3, y4], color="blue", linewidth=0.5)
            if CE_loss is not None and ts >= self.history_size and ts - self.history_size < len(CE_loss) and CE_loss[ts - self.history_size] is not None:
                disptext += f", CE_loss:{CE_loss[ts-self.history_size]:.1f}"
            if best_pts_list is not None and ts >= self.history_size and ts - self.history_size < len(best_pts_list) and best_pts_list[ts-self.history_size] is not None:
                ax.plot(best_pts_list[ts-self.history_size][0], best_pts_list[ts-self.history_size][1], "b*", alpha=0.5, markersize=20)
            if navi_loss is not None and ts >= self.history_size and ts - self.history_size < len(navi_loss) and navi_loss[ts - self.history_size] is not None:
                disptext += f"\ncenterline loss:{navi_loss[ts-self.history_size]:.1f}"
            if perp_dist is not None and ts >= self.history_size and ts - self.history_size < len(perp_dist) and perp_dist[ts - self.history_size] is not None:
                disptext += f", perp_dist:{perp_dist[ts-self.history_size]:.1f}; "
            # if dist is not None and ts >= self.history_size and ts - self.history_size < len(dist) and dist[ts - self.history_size] is not None:
            #     disptext += f", dist:{dist[ts-self.history_size]:.1f}\n"
            if angle is not None and ts >= self.history_size and ts - self.history_size < len(angle) and angle[ts - self.history_size] is not None:
                disptext += f"angle:{angle[ts-self.history_size]:.1f}"
            if loss_angle is not None and ts >= self.history_size and ts - self.history_size < len(loss_angle) and loss_angle[ts - self.history_size] is not None:
                disptext += f", loss_angle:{loss_angle[ts-self.history_size]:.3f}"

            if best_pts_list_l is not None and ts >= self.history_size and ts - self.history_size < len(best_pts_list_l) and best_pts_list_l[ts-self.history_size] is not None:
                ax.plot(best_pts_list_l[ts-self.history_size][0], best_pts_list_l[ts-self.history_size][1], "y*", alpha=0.5, markersize=20)
            if navi_loss_l is not None and ts >= self.history_size and ts - self.history_size < len(navi_loss_l) and navi_loss_l[ts - self.history_size] is not None:
                disptext += f"\nleft solid line loss:{navi_loss_l[ts-self.history_size]:.1f}"
            if perp_dist_l is not None and ts >= self.history_size and ts - self.history_size < len(perp_dist_l) and perp_dist_l[ts - self.history_size] is not None:
                disptext += f", perp_dist:{perp_dist_l[ts-self.history_size]:.1f}; "
            # if dist_l is not None and ts >= self.history_size and ts - self.history_size < len(dist_l) and dist_l[ts - self.history_size] is not None:
            #     disptext += f", dist_l:{dist_l[ts-self.history_size]:.1f}"

            if best_pts_list_r is not None and ts >= self.history_size and ts - self.history_size < len(best_pts_list_r) and best_pts_list_r[ts-self.history_size] is not None:
                ax.plot(best_pts_list_r[ts-self.history_size][0], best_pts_list_r[ts-self.history_size][1], "r*", alpha=0.5, markersize=20)
            if navi_loss_r is not None and ts >= self.history_size and ts - self.history_size < len(navi_loss_r) and navi_loss_r[ts - self.history_size] is not None:
                disptext += f"right solid line loss:{navi_loss_r[ts-self.history_size]:.1f}"
            if perp_dist_r is not None and ts >= self.history_size and ts - self.history_size < len(perp_dist_r) and perp_dist_r[ts - self.history_size] is not None:
                disptext += f", perp_dist:{perp_dist_r[ts-self.history_size]:.1f}\n"


            # if dist_r is not None and ts >= self.history_size and ts - self.history_size < len(dist_r) and dist_r[ts - self.history_size] is not None:
            #     disptext += f", dist:{dist_r[ts-self.history_size]:.1f}"
            gtv = gt_velocity[ts] if ts < len(gt_velocity) else np.nan
            gt_ego_v = gt_egomotion_velocity[ts] if ts < len(gt_egomotion_velocity) else np.nan
            disptext += f", speed:{velocity[ts]:.1f}/{gtv:.1f}/{gt_ego_v:.1f}km/h"

            if len(disptext) > 200:
                rows = math.ceil(len(disptext) / 200)
                disptext = "\n".join(textwrap.wrap(disptext, width=len(disptext) // rows + 10))
            plt.figtext(0.5, 0.99, disptext, color="k", ha="center", va="top")

            # ego traj
            if ts < self.history_size:
                ax.plot(
                    ego_traj[: self.history_size, 0],
                    ego_traj[: self.history_size, 1],
                    color="blue",
                    alpha=0.3,
                    linewidth=4,
                )
            ax.plot(
                ego_traj[max(ts, self.history_size) :, 0],
                ego_traj[max(ts, self.history_size) :, 1],
                color="deeppink",
                alpha=0.3,
                linewidth=4,
            )
            if ts >= self.history_size and pred_polygons_draw is not None:
                # pred traj to draw
                pred_traj_draw = pred_polygons_draw[ts - self.history_size].mean(axis=1)  # ndraw x 2
                ax.plot(
                    pred_traj_draw[:, 0],
                    pred_traj_draw[:, 1],
                    color="navy",
                    alpha=0.5,
                    linewidth=2,
                )
            if active_walls_bt is not None and ts >= self.history_size and ts - self.history_size < len(active_walls_bt) and active_walls_bt[ts - self.history_size] is not None:
                virtual_wall = active_walls_bt[ts - self.history_size]
                for wall_coords in virtual_wall:
                    if wall_coords["is_parallel"]:
                        color = "y"
                    else:
                        color = "b"
                    ax.plot(
                        [wall_coords["start"][0], wall_coords["end"][0]], [wall_coords["start"][1], wall_coords["end"][1]], color, linewidth=4
                    )

            # ego gt traj(dynamic)
            if gt_traj is not None:
                if ts >= self.history_size - 1:
                    gt_traj_15 = gt_traj[ts : ts + self.history_size + 1]
                    ax.scatter(
                        gt_traj_15[:, 0],
                        gt_traj_15[:, 1],
                        marker="*",
                        s=2,
                        facecolor="none",
                        edgecolor="blue",
                        alpha=0.5,
                        linewidths=1.5,
                    )
            uuid = self.raw_env[0]["uuid"] if "uuid" in self.raw_env[0].keys() else None
            if ts < self.history_size:
                plt.figtext(0.5, 0.86, f"History {ts}, uuid:{uuid}", color="k", ha="center", va="top")
            else:
                plt.figtext(
                    0.5, 0.86, f"Prediction {ts - self.history_size}, uuid:{uuid}", color="k", ha="center", va="top"
                )

            # make picture
            plt.subplots_adjust(left=0.03, right=0.99, top=0.90, bottom=0.05)
            fig.canvas.draw()
            image1 = np.frombuffer(fig.canvas.buffer_rgba(), dtype=np.uint8)
            w, h = fig.canvas.get_width_height()
            image1 = image1.reshape((h, w, 4))
            plt.close(fig)

            # 速度曲线
            n = len(gt_polygon)
            fig, axes = plt.subplots(nrows=1, ncols=2, figsize=(15, 3))
            ax = axes[0]
            ax.set_title("Speed Curve")
            ax.set_ylim(math.floor(v_min - v_diff * 0.1), math.ceil(v_max + v_diff * 0.1))
            ax.plot(timestamps[:n], velocity[:n], "r", label="model")  # 速度
            ax.plot(timestamps[:n], gt_velocity[:n], "b", label="carpose")  # 真实速度
            # ax.plot(timestamps[:n], gt_egomotion_velocity[:n], "g", label="egomotion")  # 自车运动速度
            ax.legend(loc="upper left")
            if ts > 0:
                ax.axvline(x=timestamps[ts - 1], color="red")
                ax.scatter(timestamps[ts - 1], velocity[ts - 1], color="red", s=30, zorder=5)

            plt.subplots_adjust(left=0.02, right=0.98, top=0.90, bottom=0.10, wspace=0.05)
            fig.canvas.draw()
            image2 = np.frombuffer(fig.canvas.buffer_rgba(), dtype=np.uint8)
            w, h = fig.canvas.get_width_height()
            image2 = image2.reshape((h, w, 4))
            plt.close(fig)

            image = np.concatenate([image1, image2], axis=0)
            image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
            cv2.imwrite(os.path.join(tmpdir.name, f"{ts:0>5}.png"), image)

        os.system(
            f'ffmpeg -y -r 5 -i {tmpdir.name}"/%05d.png" -loglevel error -threads 4 -c:v libx264 -crf 20 -preset:v veryfast -pix_fmt yuv420p {savename}'
        )
        tmpdir.cleanup()
