import numpy as np

from matplotlib.path import Path
from shapely.geometry import Point
from shapely.geometry import Polygon
from shapely.geometry import LineString

from tpp_onemodel.utils.reward_utils import normalize_angle
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import calc_path_point_heading
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import distance_ranges_to_target_scene
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import find_nearest_point
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import get_lat_distance
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import get_long_distance
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import get_xyyaw_from_polygon
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import is_segments_intersection
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import distance_ranges_to_current_link_only
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import signed_distance
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import ROAD_SPLIT_MAIN_ACTION_MAPPING
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import ROAD_SPLIT_ASSIST_ACTION_MAPPING
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import CHECKER_TYPE_LACK_NAVI_GT
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import CHECKER_TYPE_INVALID_SCENE
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import CHECKER_TYPE_NOT_ARRIVED
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import CHECKER_TYPE_DEVIATION
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import CHECKER_TYPE_STATIC
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import CHECKER_TYPE_NORMAL
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import CHECKER_TYPE_DEVIATION_SPECIAL
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import CHECKER_TYPE_FOCUS
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import LEFT_RIGHT_TURN_MAIN_ACTION_MAPPING
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import NONE_ASSIST_ACTION_MAPPING
from tpp_onemodel.constant import LANE_DIRECTION_TO_TLD_ID_MAPPING


class PlannerEnvChecker:
    @staticmethod
    def checker_road_split(env, dataset_kwargs):
        raw_env = env.raw_env[env.history_size :]
        navi_info = raw_env[0]["navi_infos"]
        ego_polygon = dataset_kwargs["ego_state_polygon"]
        pred_polygon = ego_polygon[env.history_size :]

        navi_centerline_list = [navi_lane for navi_lane in navi_info["navi_centerlines"] if navi_lane[2] == 1]
        if len(navi_centerline_list) < 1:
            return CHECKER_TYPE_LACK_NAVI_GT

        ego_path_info = get_xyyaw_from_polygon(pred_polygon)

        distance_ranges = distance_ranges_to_target_scene(
            navi_info=navi_info,
            main_actions=ROAD_SPLIT_MAIN_ACTION_MAPPING,
            assist_actions=ROAD_SPLIT_ASSIST_ACTION_MAPPING,
            action_distance_range=(0, 70),
        )

        # 预处理导航中心线
        points_x_y_yaw_list = []
        for navi_lane in navi_centerline_list:
            points_x_y_yaw = calc_path_point_heading(navi_lane[0][:, :2])
            points_x_y_yaw_list.append(points_x_y_yaw)

        # ego轨迹下采样
        cum_distance, ego_path_downsample = 0, []
        ego_path_downsample.append([0, ego_path_info[0], cum_distance])
        for i in range(1, len(ego_path_info)):
            c_distance = np.linalg.norm(ego_path_info[i, :2] - ego_path_downsample[-1][1][:2])
            if c_distance > 3.0 or i + 1 == len(ego_path_info):
                cum_distance += c_distance
                ego_path_downsample.append([i, ego_path_info[i], cum_distance])

        if len(distance_ranges) == 0:
            return CHECKER_TYPE_INVALID_SCENE

        if distance_ranges[0][0] > cum_distance:
            return CHECKER_TYPE_NOT_ARRIVED

        for i in range(len(ego_path_downsample) - 1, -1, -1):
            is_in_valid_range = False
            for action_valid_min_distance, action_valid_max_distance, _ in distance_ranges:
                if action_valid_min_distance < ego_path_downsample[i][2] < action_valid_max_distance:
                    is_in_valid_range = True
                    break

            if not is_in_valid_range:
                continue

            pos = np.squeeze(np.array([ego_path_downsample[i][1][[0, 1, 6]]]))
            min_projection_distance, is_valid = 1e6, False
            for navi_centerline_points in points_x_y_yaw_list:
                min_point_index, _ = find_nearest_point(pos, navi_centerline_points, 1.047)

                if min_point_index < 0:
                    continue

                # 投影到点链外部，则不使用
                production_distance = get_long_distance(pos, navi_centerline_points[min_point_index])
                if (min_point_index == 0 and production_distance < 0) or (
                    min_point_index == len(navi_centerline_points) - 1 and production_distance > 0
                ):
                    continue

                is_begin_point = min_point_index < 2
                is_end_point = min_point_index > (len(navi_centerline_points) - 3)

                if not is_begin_point and not is_end_point:
                    is_valid = True

                projection_distance = get_lat_distance(pos, navi_centerline_points[min_point_index])
                min_projection_distance = min(abs(projection_distance), min_projection_distance)

            if is_valid:
                if min_projection_distance <= 2.0:
                    return CHECKER_TYPE_NORMAL
                else:
                    return CHECKER_TYPE_DEVIATION

        return CHECKER_TYPE_DEVIATION

    @staticmethod
    def checker_gt_boundary(env, dataset_kwargs):
        def has_passed_point(pos, start_point, next_point, margin=0.5):
            tangent = next_point - start_point
            vec = pos - start_point

            tangent_len = np.linalg.norm(tangent)
            if tangent_len < 1e-6:
                return False

            proj_len = np.dot(vec, tangent) / tangent_len

            return proj_len > margin

        raw_env = env.raw_env[env.history_size :]
        ego_polygon = dataset_kwargs["ego_state_polygon"]
        pred_polygon = ego_polygon[env.history_size :]
        ego_path_info = get_xyyaw_from_polygon(pred_polygon)

        pred_num = len(ego_path_info)
        last_ego_pose = None
        for i in range(1, pred_num):
            pos_ego = ego_path_info[i][:2]
            navi_road_driving_space = raw_env[i]["navi_infos"].get("navi_road_driving_space", None)

            if navi_road_driving_space is None or len(navi_road_driving_space) == 0:
                continue

            left_boundary = np.asarray(navi_road_driving_space.get("left_boundary", []))
            left_start_index = navi_road_driving_space.get("left_start_index", -1)

            if left_boundary.shape[0] > 1 and 0 <= left_start_index < left_boundary.shape[0]:
                # 找到 ego 对应的左边界最近点
                left_xy = left_boundary[:, :2]
                dists = np.linalg.norm(left_xy - pos_ego, axis=1)
                min_idx = np.argmin(dists)

                # 判断是否已经经过入口点
                if left_start_index < left_boundary.shape[0] - 1:
                    next_point_start = left_boundary[left_start_index + 1, :2]
                else:
                    next_point_start = left_boundary[left_start_index - 1, :2]
                passed_by_index = min_idx > left_start_index
                passed_by_proj = has_passed_point(pos_ego, left_boundary[left_start_index, :2], next_point_start)
                has_passed = passed_by_index or passed_by_proj
                if not has_passed:
                    continue

            poly_points = np.asarray(navi_road_driving_space["drivable_polygon"])[:, :2]
            drivable_path = Path(poly_points)
            in_road = drivable_path.contains_point(pos_ego, radius=1e-6)

            if not in_road:
                # 判断是否从轨迹前边界穿出
                left_boundary_pts = np.asarray(navi_road_driving_space.get("left_boundary", []))
                right_boundary_pts = np.asarray(navi_road_driving_space.get("right_boundary", []))
                exit_line = None
                if left_boundary_pts.shape[0] > 0 and right_boundary_pts.shape[0] > 0:
                    exit_line = LineString([left_boundary_pts[-1][:2], right_boundary_pts[-1][:2]])
                if last_ego_pose is not None and exit_line is not None:
                    ego_line = LineString([last_ego_pose, pos_ego])
                    if ego_line.intersects(exit_line):  # 合法出口
                        continue
                return CHECKER_TYPE_DEVIATION

            last_ego_pose = pos_ego

        # 一直未进入过drivable_polygon
        if last_ego_pose is None:
            return CHECKER_TYPE_NOT_ARRIVED

        return CHECKER_TYPE_NORMAL

    @staticmethod
    def checker_virtual_wall(env, dataset_kwargs):
        raw_env = env.raw_env[env.history_size :]
        ego_polygon = dataset_kwargs["ego_state_polygon"]
        pred_polygon = ego_polygon[env.history_size :]

        if len(raw_env[0]["navi_infos"]["virtual_wall"]) < 1:
            return CHECKER_TYPE_LACK_NAVI_GT

        # 撞虚拟墙
        ego_path_info = get_xyyaw_from_polygon(pred_polygon)
        for i in range(1, len(ego_path_info)):
            virtual_wall = raw_env[i]["navi_infos"]["virtual_wall"]
            ego_point1, ego_point2 = ego_path_info[i - 1, :2], ego_path_info[i, :2]
            for wall_coords in virtual_wall:
                wall_point1, wall_point2 = wall_coords[0], wall_coords[1]
                if is_segments_intersection(ego_point1, ego_point2, wall_point1, wall_point2):
                    return CHECKER_TYPE_DEVIATION

        # 不起步、异常刹停，排除红灯场景
        static_count = 0
        tldcolor = ["k", "red", "yellow", "green", "gray"]
        for i in range(1, len(ego_path_info)):
            tld = raw_env[i]["tld"]  # [掉头、左转、直行、右转]
            curr_dobjs_full = raw_env[i]["dobjs_full"][-1]
            lane_infos = raw_env[i]["navi_infos"]["lane_infos"]
            if len(lane_infos) > 0:
                highline_directions = [info[1] for info in lane_infos if info[1]]
                if highline_directions:
                    highline_direction = highline_directions[0]
                    direct_light = LANE_DIRECTION_TO_TLD_ID_MAPPING[highline_direction]
                    tld_select = tld[direct_light]
                    tld_color_select = tldcolor[tld_select]
                else:
                    tld_color_select = "gray"
                    direct_light = 4
            else:
                tld_color_select = "gray"  # 还没到路口
                direct_light = 4
            is_select_light_red = tld_color_select == "red"

            ego_point1, ego_point2 = ego_path_info[i - 1, :2], ego_path_info[i, :2]
            ego_vel = np.linalg.norm(ego_point2 - ego_point1) / 0.2
            is_ego_static = ego_vel < 0.1
            is_no_front_od = True
            is_front_od_moving = False
            for dobj in curr_dobjs_full[1]:
                x, y, vx, vy = dobj[0], dobj[1], dobj[10], dobj[11]
                od_vel = np.sqrt(vx**2 + vy**2)
                in_front_ego = x - ego_point2[0] > 0.0 and x - ego_point2[0] < 10.0 and abs(y - ego_point2[1]) < 1.5
                is_no_front_od |= in_front_ego
                if in_front_ego and od_vel > 0.5:
                    is_front_od_moving = True

            if is_ego_static and (is_front_od_moving or is_no_front_od) and not is_select_light_red:
                static_count += 1
                if static_count > 5:  # 刹停时间持续1s以上
                    return CHECKER_TYPE_STATIC
            else:
                static_count = 0

        return CHECKER_TYPE_NORMAL

    @staticmethod
    def checker_deviation(env, dataset_kwargs):
        """检查是否偏离导航车道

        判定标准：基于 traj_is_in_navi_lane 的逻辑
        1. 未到达检查区域（predict_reach_check_region=False）
        2. 到达检查区域但不在导航车道内（predict_in_navi_lane=False）

        检查区域定义：
        - 前方区域：纵向距离 (0, 10.0]，横向距离阈值 1.5m
        - 后方区域：纵向距离 [-10.0, 0]，横向距离阈值 2.5m

        Returns:
            bool: True表示存在偏航问题
        """
        raw_env = env.raw_env[env.history_size :]
        ego_polygon = dataset_kwargs["ego_state_polygon"]
        pred_polygon = ego_polygon[env.history_size :]

        # 原始的 navi_centerlines 列表，包含 source=0 和 source=1 的数据
        full_navi_centerlines = raw_env[0]["navi_infos"]["navi_centerlines"]

        # 过滤列表：只保留 source=0 的 navi_centerline
        # 假设 navi_lane 的 source 字段在每个元素的索引 2 (即 navi_lane[2])
        navi_centerlines_source_0 = [navi_lane for navi_lane in full_navi_centerlines if navi_lane[2] == 0]

        # 传入过滤后的列表
        (
            navi_centerline_reward,
            last_ego_traj_index_in_navi_area,
            navi_lon_lat_dis,
        ) = PlannerEnvChecker.calc_navi_lane_reward_by_navi_centerline_v2(pred_polygon, navi_centerlines_source_0)
        predict_reach_check_region = False
        predict_in_navi_lane = True
        predict_lon_lat_dist = np.array(list(navi_lon_lat_dis.values()))
        if len(predict_lon_lat_dist) > 0:
            predict_lon_lat_dist = PlannerEnvChecker.drop_invalid_data(predict_lon_lat_dist)
            predict_reach_check_region, predict_in_navi_lane = PlannerEnvChecker.traj_is_in_navi_lane(
                predict_lon_lat_dist
            )

        # 判定偏航：到达检查区域 and 不在导航车道内
        has_deviation = (predict_reach_check_region) and (not predict_in_navi_lane)

        if has_deviation:
            return CHECKER_TYPE_DEVIATION

        return CHECKER_TYPE_NORMAL

    @staticmethod
    def traj_is_in_navi_lane(
        lon_lat_dist, front_check_length=10.0, back_check_length=-10.0, front_lat_thresh=1.5, back_lat_thresh=2.5
    ):
        lon = lon_lat_dist[:, 0]
        lat = lon_lat_dist[:, 1]

        lon_back_ok = (lon >= back_check_length) & (lon <= 0)
        lon_front_ok = (lon > 0) & (lon <= front_check_length)

        if lon_back_ok.any() or lon_front_ok.any():
            lat_in_back_region = lat[lon_back_ok]
            lat_in_front_region = lat[lon_front_ok]

            lat_ok = (lat_in_front_region <= front_lat_thresh).all() and (lat_in_back_region <= back_lat_thresh).all()

            return True, lat_ok.all()
        else:
            # 未到达检查区 默认返回true
            return False, True

    @staticmethod
    def drop_invalid_data(lon_lat_dist):
        sign_change_idx_list = np.where(lon_lat_dist[:-1] * lon_lat_dist[1:] < 0)[0].tolist()
        if len(sign_change_idx_list) == 0:
            return lon_lat_dist
        if lon_lat_dist[sign_change_idx_list[0], 0] > 0:
            if len(sign_change_idx_list) <= 2:
                return lon_lat_dist[(sign_change_idx_list[0] + 1) :]
            else:
                return lon_lat_dist[(sign_change_idx_list[0] + 1) : (sign_change_idx_list[2] + 1)]
        else:
            if len(sign_change_idx_list) < 2:
                return lon_lat_dist[0:]
            else:
                return lon_lat_dist[0 : (sign_change_idx_list[1] + 1)]

    @staticmethod
    def calc_navi_lane_reward_by_navi_centerline_v2(pred_polygon, navi_centerline_list):

        ego_path_info = get_xyyaw_from_polygon(pred_polygon)

        pred_num = len(ego_path_info)
        navi_lane_reward = [0.0] * pred_num
        last_ego_traj_index_in_navi_area = None

        if len(navi_centerline_list) < 1:
            return navi_lane_reward, last_ego_traj_index_in_navi_area, {}

        points_x_y_yaw_list = []
        dist_to_lc_point_list = []
        for index, navi_lane in enumerate(navi_centerline_list):
            points_x_y_yaw = calc_path_point_heading(navi_lane[0][:, :2])
            segment_length = np.linalg.norm(points_x_y_yaw[1:, :2] - points_x_y_yaw[:-1, :2], axis=1)
            accumulate_dist = np.cumsum(np.insert(segment_length, 0, 0))
            if navi_lane[1] is not None:
                dist_to_lc_point = accumulate_dist - accumulate_dist[navi_lane[1]]
                dist_to_lc_point_list.append([True, dist_to_lc_point])
            else:
                dist_to_lc_point_list.append([False, None])
            points_x_y_yaw_list.append(points_x_y_yaw)

        # ego_traj downsample by distance
        ego_path_downsample = []  # [[ego_traj_index, [x, y, z, l, w, h, yaw]], ...]
        ego_path_downsample.append([0, ego_path_info[0]])
        for i in range(1, len(ego_path_info)):
            c_distance = np.linalg.norm(ego_path_info[i, :2] - ego_path_downsample[-1][1][:2])
            if c_distance > 0.5:
                ego_path_downsample.append([i, ego_path_info[i]])

        # 计算自车每一个采样点到所有的navi centerline的投影
        last_search_result_cache = {}  # 缓存上一帧搜索结果，加速当前帧搜索
        lat_dist_info_all_time = []

        for i in range(len(ego_path_downsample)):
            pos = np.squeeze(np.array([ego_path_downsample[i][1][[0, 1, 6]]]))
            lat_dist_info_all_lane = []
            for index, navi_centerline_points in enumerate(points_x_y_yaw_list):
                if index not in last_search_result_cache:
                    min_point_index, min_dist = find_nearest_point(pos, navi_centerline_points, 1.047)
                else:
                    last_min_point_index = last_search_result_cache[index]
                    min_point_index, min_dist = find_nearest_point(
                        pos, navi_centerline_points, 1.047, last_min_point_index
                    )

                if min_point_index < 0:
                    continue

                last_search_result_cache[index] = min_point_index
                min_projection_distance = get_lat_distance(pos, navi_centerline_points[min_point_index])
                min_direction_distance = get_long_distance(pos, navi_centerline_points[min_point_index])
                is_begin_point = min_point_index < 2
                is_end_point = min_point_index > (len(navi_centerline_points) - 3)

                is_force = False
                if navi_centerline_list[index][1] is not None:
                    solid_line_start_index = navi_centerline_list[index][1]
                    is_force = min_point_index >= solid_line_start_index

                lat_dist_info = {
                    "lane_index": index,
                    "min_point_index": min_point_index,
                    "min_l2_distance": min_dist,
                    "min_projection_distance": min_projection_distance,
                    "in_force_area": is_force,
                    "is_begin": is_begin_point,
                    "is_end": is_end_point,
                }

                if dist_to_lc_point_list[index][0]:
                    lat_dist_info["lon_dist_to_lc_point"] = (
                        dist_to_lc_point_list[index][1][min_point_index] + min_direction_distance
                    )
                else:
                    lat_dist_info["lon_dist_to_lc_point"] = 1e6

                lat_dist_info_all_lane.append(lat_dist_info)

            lat_dist_info_all_time.append(lat_dist_info_all_lane)

        # ego pos to nearest navi lane distance
        recommend_dis = {}  # {ego_traj_index: dis, ...}
        force_dis = {}  # {ego_traj_index: dis, ...}
        navi_lon_lat_dis = {}

        # 每一个采样点距离导航车道的横向距离
        for i in range(len(ego_path_downsample)):
            rec_min = 1e6
            force_min = 1e6
            lon_lat_min = [1e6, 1e6]
            for lat_info in lat_dist_info_all_time[i]:
                # 1. 过滤距离起止点过远的车道
                if (lat_info["is_begin"] or lat_info["is_end"]) and lat_info["min_l2_distance"] > 2.0:
                    continue
                if lat_info["in_force_area"]:
                    force_min = min(force_min, abs(lat_info["min_projection_distance"]))
                else:
                    rec_min = min(rec_min, abs(lat_info["min_projection_distance"]))
                if lon_lat_min[-1] > abs(lat_info["min_projection_distance"]):
                    lon_lat_min = [lat_info["lon_dist_to_lc_point"], abs(lat_info["min_projection_distance"])]

            if abs(rec_min - 1e6) > 1e-3:
                recommend_dis[ego_path_downsample[i][0]] = rec_min

            if abs(force_min - 1e6) > 1e-3:
                force_dis[ego_path_downsample[i][0]] = force_min

            if abs(lon_lat_min[-1] - 1e6) > 1e-3:
                navi_lon_lat_dis[ego_path_downsample[i][0]] = lon_lat_min

        # reward arb
        # 如果自车已经在实线区域偏航，则reward赋特殊值 -19
        # 如果自车处于虚线区域，线性奖励，根据min\max dis截断
        for ego_traj_index, _ in ego_path_downsample:
            if ego_traj_index in recommend_dis:
                dist = abs(recommend_dis[ego_traj_index])
                min_dist_reward = [0.5, 2.0]
                max_dist_reward = [5.0, 0.0]
                if dist < min_dist_reward[0]:
                    navi_lane_reward[ego_traj_index] = min_dist_reward[1]
                elif dist > max_dist_reward[0]:
                    navi_lane_reward[ego_traj_index] = max_dist_reward[1]
                else:
                    navi_lane_reward[ego_traj_index] = np.interp(
                        dist,
                        np.array([min_dist_reward[0], max_dist_reward[0]]),
                        np.array([min_dist_reward[1], max_dist_reward[1]]),
                    )
            elif ego_traj_index in force_dis:
                dist = abs(force_dis[ego_traj_index])
                min_dist_reward = [0.5, 4.0]
                max_dist_reward = [2.0, -5.0]
                if dist < min_dist_reward[0]:
                    navi_lane_reward[ego_traj_index] = min_dist_reward[1]
                elif dist > max_dist_reward[0]:
                    navi_lane_reward[ego_traj_index] = -19  # 偏航，done，特值
                else:
                    navi_lane_reward[ego_traj_index] = np.interp(
                        dist,
                        np.array([min_dist_reward[0], max_dist_reward[0]]),
                        np.array([min_dist_reward[1], max_dist_reward[1]]),
                    )

        # 穿过导航区域的最终的点
        # 返回最后一个能匹配到navi centerline的index
        recommend_last_ego_traj_index = force_last_ego_traj_index = None
        if len(recommend_dis):
            recommend_last_ego_traj_index, _ = list(recommend_dis.items())[-1]
        if len(force_dis):
            force_last_ego_traj_index, _ = list(force_dis.items())[-1]

        if recommend_last_ego_traj_index is not None and force_last_ego_traj_index is not None:
            last_ego_traj_index_in_navi_area = max(recommend_last_ego_traj_index, force_last_ego_traj_index)
        elif recommend_last_ego_traj_index is not None:
            last_ego_traj_index_in_navi_area = recommend_last_ego_traj_index
        elif force_last_ego_traj_index is not None:
            last_ego_traj_index_in_navi_area = force_last_ego_traj_index
        if last_ego_traj_index_in_navi_area is not None and last_ego_traj_index_in_navi_area >= pred_num - 1:
            last_ego_traj_index_in_navi_area = None

        return navi_lane_reward, last_ego_traj_index_in_navi_area, navi_lon_lat_dis

    @staticmethod
    def checker_continuous_lane_change(env, dataset_kwargs):
        """
        检查是否出现连续换道（跳过中间车道）
        判定标准：ContinuousLaneChangeReward 任一帧惩罚 < 0
        Returns:
            bool: True 表示存在连续换道问题
        """
        raw_env = env.raw_env[env.history_size :]
        ego_polygon = dataset_kwargs["ego_state_polygon"]
        pred_polygon = ego_polygon[env.history_size :]

        # 1. 直接调用已写好的 reward 函数
        lc_reward = PlannerEnvChecker.calc_continuous_lc_reward(pred_polygon, raw_env)

        # 2. 只要出现过惩罚（<0）即判 True
        if any(r < 0 for r in lc_reward):
            return CHECKER_TYPE_FOCUS

        return CHECKER_TYPE_NORMAL

    @staticmethod
    def calc_continuous_lc_reward(pre_ego_polygon, raw_env):
        """
        计算整段轨迹中，跨过车道线的ts_idx，用于计算横跨一个车道的停留时间，来惩罚连续换道
        """
        ego_path_info = get_xyyaw_from_polygon(pre_ego_polygon)
        pred_num = len(ego_path_info)
        continuous_lc_reward = [0.0] * pred_num

        # 1. 有导航中心线不生效
        if len(raw_env[0]["navi_infos"]["navi_centerlines"]) >= 1:
            return continuous_lc_reward

        # 2. ODD 命中检查
        for i in range(1, pred_num):
            if not PlannerEnvChecker.trigger_list_by_scene_lc(raw_env[i]["navi_infos"]):
                return continuous_lc_reward

        penalty_mag = 8.0  # 连续换道惩罚幅度
        angle_threshold = np.radians(30)
        ego_path_info = get_xyyaw_from_polygon(pre_ego_polygon)
        is_cross_lanelines = []
        for i, polygon in enumerate(pre_ego_polygon):
            ego_polygon = Polygon(polygon)
            ego_yaw = ego_path_info[i, 6]
            ego_point = polygon.mean(axis=0).reshape(1, 2)
            is_cross_lanelines.append([0, None, 0.0])
            lane_lines = raw_env[i]["lane_lines"]
            for j, lane_line in enumerate(lane_lines):
                polyline = LineString(lane_line[0][:, :2])
                if not polyline.intersects(ego_polygon):
                    continue
                # 方向夹角过滤
                pts = lane_line[0][:, :2]
                line_vec = pts[-1] - pts[0]
                line_yaw = np.arctan2(line_vec[1], line_vec[0])
                delta_yaw = abs(normalize_angle(ego_yaw - line_yaw))
                if delta_yaw > angle_threshold:
                    continue  # 非平行，跳过
                # 有一个车道线与ego交互
                # is_cross_lanelines[i][0] = 1
                x = ego_point[0][0]
                y = ego_point[0][1]
                distance_signed = signed_distance(Point(x, y), polyline)
                is_cross_lanelines[i][2] = distance_signed
                is_cross_lanelines[i][1] = polyline
                if abs(distance_signed) < 0.1:
                    is_cross_lanelines[i][0] = 1
                if i > 0 and abs(is_cross_lanelines[i - 1][2]) > 1e-6:
                    # 防止自车偏一侧压线也被误判为cross
                    if (distance_signed * is_cross_lanelines[i - 1][2]) < 0:
                        is_cross_lanelines[i][0] = 1
        continuous_lc_reward = [0] * len(pre_ego_polygon)
        cross_idx = []
        for i, [is_cross, _, _] in enumerate(is_cross_lanelines):
            if is_cross == 1:
                cross_idx.append(i)
        if len(cross_idx) < 2:
            return continuous_lc_reward

        for i in range(1, len(cross_idx)):
            if abs(is_cross_lanelines[cross_idx[i]][1].distance(is_cross_lanelines[cross_idx[i - 1]][1])) < 2.5:
                continue
            if cross_idx[i] - cross_idx[i - 1] < 25:
                start = cross_idx[i - 1]
                end = min(cross_idx[i], len(continuous_lc_reward))
                for j in range(start, end):
                    continuous_lc_reward[j] -= penalty_mag
        return continuous_lc_reward

    @staticmethod
    def trigger_list_by_scene_lc(navi_info):
        """
        输出场景触发的距离
        """
        trigger_list = []
        # 左转/右转 + 无辅动作 + ≥200 m
        trigger_list.extend(
            distance_ranges_to_current_link_only(
                navi_info,
                main_actions=LEFT_RIGHT_TURN_MAIN_ACTION_MAPPING,
                assist_actions=NONE_ASSIST_ACTION_MAPPING,
                trigger_distance=200,
            )
        )

        return trigger_list

    @staticmethod
    def match_lanenr_action(frame, lanenr_action_bias=20):
        """LaneNR与Action进行配对"""
        lanenr_action_map = {}

        lanenr_list = frame["navi_infos"]["lanenr_list"]
        action_list = frame["navi_infos"]["action_list"]

        # 匹配方案：
        #     若lanenr与action的距离相同，直接匹配
        #     若lanenr无相同距离的action，找其距离最近的action（贪婪算法）
        for lanenr_idx, lanenr_info in enumerate(lanenr_list):
            lanenr_distance = lanenr_info["distance"]
            for action_idx, action_info in enumerate(action_list):
                if abs(lanenr_distance - action_info[2]) < 1e-6:
                    lanenr_action_map[lanenr_idx] = action_idx
                    break

        remain_lanenrs = [
            lanenr_idx for lanenr_idx in range(len(lanenr_list)) if lanenr_idx not in lanenr_action_map.keys()
        ]
        remain_actions = [
            action_idx for action_idx in range(len(action_list)) if action_idx not in lanenr_action_map.values()
        ]

        for lanenr_idx in remain_lanenrs:
            lanenr_distance = lanenr_list[lanenr_idx]["distance"]
            lanenr_best_match, lanenr_best_diff = None, lanenr_action_bias
            # 找到最近的action
            for action_idx in remain_actions:
                action_distance = action_list[action_idx][2]
                diff = abs(lanenr_distance - action_distance)
                if diff > lanenr_best_diff:
                    continue
                lanenr_best_match = action_idx
                lanenr_best_diff = diff

            if lanenr_best_match is None:
                continue

            action_distance = action_list[lanenr_best_match][2]
            action_best_match, action_best_diff = lanenr_idx, lanenr_best_diff
            # 最近的action找其最近的lanenr
            for lanenr_idx2 in remain_lanenrs:
                if lanenr_idx2 == lanenr_idx:
                    continue
                lanenr_distance2 = lanenr_list[lanenr_idx2]["distance"]
                diff = abs(lanenr_distance2 - action_distance)
                if diff > action_best_diff:
                    continue
                action_best_match = lanenr_idx2
                action_best_diff = diff

            if lanenr_idx == action_best_match:
                lanenr_action_map[lanenr_idx] = lanenr_best_match

        return lanenr_action_map

    @staticmethod
    def get_continuous_lanenr(frame, dist_thresh=130, min_dist=10):
        """找到阈值范围内的连续LaneNR"""
        continuous_lanenrs = []

        # 当前无LaneNR信息
        if len(frame["navi_infos"]["lanenr_list"]) == 0:
            return continuous_lanenrs

        valid_lanenr_infos = []
        # LaneNR与Action进行匹配
        lanenr_action_map = PlannerEnvChecker.match_lanenr_action(frame)

        for lanenr_idx, lanenr_item in enumerate(frame["navi_infos"]["lanenr_list"]):
            # 离开始时刻太近的路口不考虑
            if lanenr_item["distance"] < min_dist:
                continue

            lanenr_directions = [info[1] for info in lanenr_item["infos"] if info[2]]
            if len(lanenr_directions) == 0:
                continue

            # 获取LaneNR的导航方向
            lanenr_direction = lanenr_directions[0]

            # 获取LaneNR匹配的Action
            main_action, assist_action = 0, 0
            if lanenr_idx in lanenr_action_map:
                action_info = frame["navi_infos"]["action_list"][lanenr_action_map[lanenr_idx]]
                main_action, assist_action = action_info[:2]

            # 非直行且无Action的LaneNR，视为无效LaneNR
            if lanenr_direction != 0b0100 and main_action == 0:
                continue

            is_not_single = False in [info[2] for info in lanenr_item["infos"]]

            valid_lanenr_infos.append(
                {
                    "is_single": not is_not_single,
                    "lanenr_direction": lanenr_direction,
                    "main_action": main_action,
                    "assist_action": assist_action,
                    "distance": lanenr_item["distance"],
                }
            )

        # 找到连续LaneNR的配对
        for i in range(1, len(valid_lanenr_infos)):
            # 所有车道均可通行，非目标场景
            if valid_lanenr_infos[i]["is_single"]:
                continue

            if valid_lanenr_infos[i]["distance"] < valid_lanenr_infos[i - 1]["distance"] + dist_thresh:
                continuous_lanenrs.append(valid_lanenr_infos[i - 1 : i + 1])

        return continuous_lanenrs

    @staticmethod
    def arrive_to_ped_cross(frame, pos):
        """判断当前模型轨迹是否处在人行横道上"""
        for road_sign in frame["road_sign"]:
            if road_sign[1] != 300:
                continue
            ped_cross = road_sign[0][:, :2] - pos
            if min(ped_cross[:, 0]) * max(ped_cross[:, 0]) <= 0 and min(ped_cross[:, 1]) * max(ped_cross[:, 1]) <= 0:
                return True
        return False

    @staticmethod
    def is_continuous_junction(frames, pred_traj, continuous_lanenr, back_bias=30, fore_bias=10, move_bias=30):
        """判断连续LaneNR是否为一个轨迹经过的连续路口"""
        cum_distance, is_valid_junction, anchor_distance = 0, False, continuous_lanenr[0]["distance"]
        for i in range(1, len(pred_traj)):
            cum_distance += np.linalg.norm(pred_traj[i] - pred_traj[i - 1])

            # 当靠近第一个LaneNR结束区域时，判断是否经过人行横道
            if not is_valid_junction and anchor_distance - back_bias < cum_distance < anchor_distance + fore_bias:
                is_valid_junction = PlannerEnvChecker.arrive_to_ped_cross(frames[i], pred_traj[i])

            if is_valid_junction and anchor_distance + move_bias < cum_distance:
                return True
        return False

    @staticmethod
    def is_deviated_continuous_lanenr(navi_centerline_list, pred_polygon, continuous_lanenr, bias=30):
        """判断自车轨迹在给定的连续LaneNR范围内是否偏航"""
        if len(navi_centerline_list) == 0:
            return False

        ego_path_info = get_xyyaw_from_polygon(pred_polygon)
        distance_ranges = (continuous_lanenr[0]["distance"] - bias, continuous_lanenr[1]["distance"])

        # 预处理导航中心线
        points_x_y_yaw_list = []
        for navi_lane in navi_centerline_list:
            points_x_y_yaw = calc_path_point_heading(navi_lane[0][:, :2])
            points_x_y_yaw_list.append(points_x_y_yaw)

        # ego轨迹下采样
        cum_distance, ego_path_downsample = 0, []
        ego_path_downsample.append([0, ego_path_info[0], cum_distance])
        for i in range(1, len(ego_path_info)):
            c_distance = np.linalg.norm(ego_path_info[i, :2] - ego_path_downsample[-1][1][:2])
            if c_distance > 3.0 or i + 1 == len(ego_path_info):
                cum_distance += c_distance
                ego_path_downsample.append([i, ego_path_info[i], cum_distance])

        for i in range(len(ego_path_downsample)):
            if ego_path_downsample[i][2] < distance_ranges[0]:
                continue

            if ego_path_downsample[i][2] > distance_ranges[1]:
                break

            pos = np.squeeze(np.array([ego_path_downsample[i][1][[0, 1, 6]]]))
            min_projection_distance, is_valid = 1e6, False
            for lane_index, navi_centerline_points in enumerate(points_x_y_yaw_list):
                min_point_index, _ = find_nearest_point(pos, navi_centerline_points, None)

                # 投影段在最晚换道点之前，忽略
                if min_point_index < 0:
                    continue

                if abs(normalize_angle(pos[2] - navi_centerline_points[min_point_index][2])) > 1.047:
                    continue

                is_begin_point = min_point_index < 2
                is_end_point = min_point_index > (len(navi_centerline_points) - 3)

                projection_distance = get_lat_distance(pos, navi_centerline_points[min_point_index])
                if (is_begin_point or is_end_point) and projection_distance < 2:
                    min_projection_distance = min(abs(projection_distance), min_projection_distance)
                elif not is_begin_point and not is_end_point:
                    if navi_centerline_list[lane_index][1] is None:
                        solid_line_start_index = len(navi_centerline_list[lane_index][0])
                    else:
                        solid_line_start_index = navi_centerline_list[lane_index][1]
                    is_valid |= min_point_index > solid_line_start_index
                    min_projection_distance = min(abs(projection_distance), min_projection_distance)

            # 当前在任一navi_centerlines的惩罚区间，且距离所有navi_centerlines横向距离都大于阈值，则偏航
            if is_valid and min_projection_distance > 2:
                return True

        return False

    @staticmethod
    def checker_continuous_junction(env, dataset_kwargs):
        """
        检查连续路口场景是否偏航
        条件1: 是否连续路口场景
            - 两连续LaneNR距离小于阈值
            - 第一个LaneNR附近有人行横道
        条件2: 是否偏航
            - 基于navi_centerlines判断是否偏航
        条件3: 场景分类
            - 第二个LaneNR是否为主辅路/一分多场景
        备注：
            - 多个连续路口场景，以第一个连续路口偏航场景为准
        Returns:
            分类1: 非连续路口场景（未到达场景生效区间）
            分类2: 未偏航
            分类3: 特殊场景偏航（第二个LaneNR为主辅路/一分多场景）
            分类4: 普通场景偏航
        """

        raw_env = env.raw_env[env.history_size :]
        ego_polygon = dataset_kwargs["ego_state_polygon"]
        pred_polygon = ego_polygon[env.history_size :]
        pred_traj = pred_polygon.mean(axis=1)

        # *** 判断是否有连续路口场景 ***
        # 找到连续LaneNR
        continuous_lanenrs = PlannerEnvChecker.get_continuous_lanenr(raw_env[0])

        # 找到连续路口
        continuous_junctions = []
        for continuous_lanenr in continuous_lanenrs:
            if PlannerEnvChecker.is_continuous_junction(raw_env, pred_traj, continuous_lanenr):
                continuous_junctions.append(continuous_lanenr)

        # 无连续路口，非目标场景
        if len(continuous_junctions) == 0:
            return CHECKER_TYPE_INVALID_SCENE

        # *** 判断轨迹是否偏航 ***
        navi_centerline_list = [one for one in raw_env[0]["navi_infos"]["navi_centerlines"] if one[2] == 0]
        for continuous_junction in continuous_junctions:
            if not PlannerEnvChecker.is_deviated_continuous_lanenr(
                navi_centerline_list, pred_polygon, continuous_junction
            ):
                continue

            # 对于偏航轨迹，进行场景分类
            if (
                continuous_junction[1]["main_action"] in ROAD_SPLIT_MAIN_ACTION_MAPPING
                and continuous_junction[1]["assist_action"] in ROAD_SPLIT_ASSIST_ACTION_MAPPING
            ):
                return CHECKER_TYPE_DEVIATION_SPECIAL

            return CHECKER_TYPE_DEVIATION

        return CHECKER_TYPE_NORMAL
