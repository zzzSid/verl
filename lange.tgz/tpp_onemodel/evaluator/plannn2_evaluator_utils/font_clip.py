#!/usr/bin/env python
# -*- coding: utf-8 -*-
from fontTools import subset
from fontTools import ttLib
import time

save_font_path = "tpp_onemodel/evaluator/plannn2_evaluator_utils/SimHei_Plannn2.ttf"


def file_as_string(file_path):
    """Read a file and return its content as a string."""
    with open(file_path, "r", encoding="utf-8") as file:
        code = file.read()
    return "".join(set(code))


target_text = "0123456789:-,.abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
target_text += "“”‘’"
target_text += file_as_string("tpp_onemodel/data/dataset/plannn2_dataset_utils/utils/misc.py")
target_text += file_as_string("tpp_onemodel/evaluator/plannn2_evaluator_utils/planner_env.py")

opt = subset.Options()
font = subset.load_font("/share-global/xin.li25/share/SimHei.ttf", opt)
subsetter = subset.Subsetter()
subsetter.populate(text=target_text)
subsetter.subset(font)
subset.save_font(font, save_font_path, opt)

time.sleep(3)

tt = ttLib.TTFont(save_font_path)

for idx, name in enumerate(tt["name"].names):
    if "SimHei" in str(name):
        name_str = str(name)
        replaced_name_str = name_str.replace("SimHei", "SimHei_Plannn2")
        tt["name"].names[idx].string = replaced_name_str.encode(name.getEncoding())

tt.save(save_font_path)
