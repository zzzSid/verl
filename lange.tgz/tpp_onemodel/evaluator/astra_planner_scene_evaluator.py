# -*- coding: utf-8 -*-
"""Astra Planner Scene Evaluator."""
import logging
import os
from typing import Any
from typing import Dict
from typing import List

import cv2
import numpy as np
import torch
import torch.distributed as dist
from torchpilot.evaluator.base_evaluator import BaseEvaluator
from torchpilot.utils.cfg_parser import PyConfig
from torchpilot.utils.file_manager import FileManager
from torchpilot.utils.registries import EVALUATOR

from tpp_onemodel.evaluator.evaluation_report import EvaluationReportManager
from tpp_onemodel.evaluator.evaluation_result_saver import EvaluationSaver
from tpp_onemodel.evaluator.metrics_aggregater import MetricsAggregater
from tpp_onemodel.evaluator.metrics_io_adaptor import MetricsIoAdaptor
from tpp_onemodel.evaluator.metrics_manager import MetricsManager
from tpp_onemodel.tools.astra_planner.visualization.frame_sample import (
    visualization_filter,
)
from tpp_onemodel.tools.astra_planner.visualization.frame_sample import (
    visualize_single_frame_sample,
)
from tpp_onemodel.tools.astra_planner.visualization.frame_sample import (
    visualize_single_frame_sample_2stage,
)
from tpp_onemodel.utils.common_utils import timer


VIS = True
logger = logging.getLogger(__name__)


class AstraPlannerSceneEvaluator(BaseEvaluator):
    """Astra planner scene evaluator."""

    def __init__(
        self,
        enable_task,
        config,
        adapter_cfg,
        eval_common_cfg,
        dump_image: bool = False,
        draw_keys=None,
        draw_2stage_cfg=None,
        use_gpu: bool = False,
    ):
        """Init."""
        super().__init__(use_gpu=use_gpu)
        self._enable_task = enable_task

        if self._enable_task == "astra_planner":
            metric_cfg = PyConfig.fromfile("tpp_onemodel/evaluator/cfg/astra_planner_metrics_config.py")
        elif self._enable_task == "prediction":
            metric_cfg = PyConfig.fromfile("tpp_onemodel/evaluator/cfg/prediction_metrics_config.py")
        else:
            metric_cfg = None

        if metric_cfg is not None:
            base_cfg = config
            base_cfg.update(
                {
                    "metric_func_dict": metric_cfg.metric_func_dict,
                    "single_metrics": metric_cfg.single_metrics,
                    "tmp_outputs": metric_cfg.tmp_outputs,
                    "util_func_dict": metric_cfg.util_func_dict,
                    "common_metrics": metric_cfg.common_metrics,
                }
            )
            base_config = EVALUATOR.build(base_cfg)

            self.metrics_cfg = base_config.metrics_cfg
            self.util_func_dict = base_config.util_func_dict
            self.metric_func_dict = base_config.metric_func_dict
            self.aggregate_cfg = base_config.aggregate_cfg
            self.evaluation_report_cfg = base_config.report_cfg
            self.eval_common_cfg = eval_common_cfg

            self.metrics_manager = MetricsManager(
                self.metrics_cfg, self.util_func_dict, self.metric_func_dict, self.aggregate_cfg["common_metrics"]
            )
            self.metrics_aggregater_manager = MetricsAggregater(self.aggregate_cfg, self.eval_common_cfg)
            self.evaluation_saver = EvaluationSaver()
            self.evaluation_report_manager = EvaluationReportManager(self.evaluation_report_cfg)
            self.gather_all_data: List[Any] = []

        self.adapter_cfg = adapter_cfg
        self.metrics_io_adapter = MetricsIoAdaptor(self._enable_task, self.adapter_cfg)

        self.dump_image = dump_image
        self.draw_keys = draw_keys
        self.draw_2stage_cfg = draw_2stage_cfg
        self.metric_agg_list = [
            "marginal/agent/track_recall_based_precision",
            "marginal/agent/prior_precision_based_recall",
        ]

    def eval(
        self,
        model_outputs: Dict[str, Any],
        model_inputs: Dict[str, Any],
    ):
        """Eval."""
        cal_metrics_input = self.metrics_io_adapter(model_inputs, model_outputs)

        if self._enable_task == "astra_planner" or self._enable_task == "prediction":
            metric_results = self.metrics_manager(cal_metrics_input)
            self.metrics_aggregater_manager.scene_level_update(metric_results, cal_metrics_input)

        if "aligned_trajectory" in model_inputs:
            cal_metrics_input["aligned_trajectory"] = model_inputs["aligned_trajectory"]
        else:
            cal_metrics_input["aligned_trajectory"] = None

        if self.draw_2stage_cfg and (
            self.draw_2stage_cfg["dump_image_2stage"] or self.draw_2stage_cfg["dump_output_2stage"]
        ):
            model_outputs["bboxes_pred_gt"] = model_inputs["bboxes_pred_gt"]
            model_outputs["bboxes_det_pred_full_info_gt"] = model_inputs["bboxes_det_pred_full_info_gt"]

            batch_sample_for_visualization = visualization_filter(
                cal_metrics_input, model_outputs, draw_2stage_cfg=self.draw_2stage_cfg
            )

            if self.draw_2stage_cfg["dump_output_2stage"]:
                stage2_output_dump_folder = os.path.join(
                    FileManager.get_run_dir(), "export", "stage2", f"rank{dist.get_rank():03d}"
                )
                os.makedirs(stage2_output_dump_folder, exist_ok=True)
                for frame_sample in batch_sample_for_visualization:
                    torch.save(
                        dict(
                            traj_pred_agent_collision_sigmoid=frame_sample["ego_traj_sample_agents_collision_reward"],
                            traj_pred_lane_collision_sigmoid=frame_sample["ego_traj_sample_lane_collision_reward"],
                            ego_od_collision_check=frame_sample["ego_traj_sample_agents_collision_label"],
                            ego_lane_collision_check=frame_sample["ego_traj_sample_lane_collision_label"],
                        ),
                        os.path.join(
                            stage2_output_dump_folder, f"{frame_sample['clip_id']}-{frame_sample['timestamp']}.pth"
                        ),
                    )

            if self.draw_2stage_cfg["dump_image_2stage"]:
                dump_folder = os.path.join(FileManager.get_run_dir(), "visualize_2stage")

                for frame_sample in batch_sample_for_visualization:
                    draw_flag = True
                    if self.draw_2stage_cfg["zero_shot_aug_enable"]:
                        all_clip_ids = []
                        all_ts = []
                        for each_aug_info in self.draw_2stage_cfg["zero_shot_aug_state"]:
                            aug_clip_id, aug_ts, aug_bbox_id, aug_x_y_yaw = each_aug_info
                            all_clip_ids.append(aug_clip_id)
                            all_ts.append(str(aug_ts))

                        if (
                            frame_sample["clip_id"].split("_")[0] in all_clip_ids
                            and frame_sample["timestamp"] in all_ts
                        ):
                            draw_flag = True
                        else:
                            draw_flag = False

                    if draw_flag:
                        pred_img = visualize_single_frame_sample_2stage(
                            dump_folder=dump_folder,
                            frame_sample=frame_sample,
                            draw_2stage_cfg=self.draw_2stage_cfg,
                            plot_reward_type="pred",
                        )

                        gt_img = visualize_single_frame_sample_2stage(
                            dump_folder=dump_folder,
                            frame_sample=frame_sample,
                            draw_2stage_cfg=self.draw_2stage_cfg,
                            plot_reward_type="gt",
                        )

                        image_path = os.path.join(
                            dump_folder,
                            frame_sample["clip_id"],
                            f"{frame_sample['clip_id']}-{frame_sample['timestamp']}.jpg",
                        )

                        concat_img = np.concatenate([gt_img, pred_img], axis=1)

                        os.makedirs(os.path.dirname(image_path), exist_ok=True)
                        cv2.imwrite(image_path, concat_img)
                        logger.warning("Dump image %s", image_path)

        if self.dump_image:
            batch_sample_for_visualization = visualization_filter(cal_metrics_input, model_outputs)
            dump_folder = os.path.join(FileManager.get_run_dir(), "visualize")
            for frame_sample in batch_sample_for_visualization:
                visualize_single_frame_sample(
                    dump_folder=dump_folder,
                    frame_sample=frame_sample,
                    gt_range=(-40, 200, -150, 150),
                    draw_keys=self.draw_keys,
                )

    def cal_precision(self, od_prior_pred, od_prior_gt_map, recall_thr):
        """cal_precision."""
        if recall_thr is None:
            return 0.0, 0.0
        valid_mask = od_prior_gt_map != -1
        od_prior_pred = od_prior_pred[valid_mask]
        od_prior_gt_map = od_prior_gt_map[valid_mask]

        if len(od_prior_gt_map) == 0:
            return 0.0, 0.0

        sorted_indices = torch.argsort(od_prior_pred, descending=True)
        od_gt_sorted = od_prior_gt_map[sorted_indices]
        od_prior_pred = od_prior_pred[sorted_indices]

        tp = (od_gt_sorted == 1).cumsum(0).float()
        fp = (od_gt_sorted == 0).cumsum(0).float()

        precision = tp / (tp + fp)  # precision = TP / (TP + FP)
        recall = tp / (od_prior_gt_map == 1).sum().float()  # recall = TP / (TP + FN)

        valid_indices = recall >= recall_thr
        if valid_indices.any():
            precision_at_thr = precision[valid_indices][0].item()
            pred_score = od_prior_pred[valid_indices][0].item()
        else:
            precision_at_thr = 0.0
            pred_score = 0.0
        return precision_at_thr, pred_score

    def cal_recall(self, od_prior_pred, od_prior_gt_map, precision_thr):
        """cal_precision."""
        if precision_thr is None:
            return 0.0, 0.0
        valid_mask = od_prior_gt_map != -1
        od_prior_pred = od_prior_pred[valid_mask]
        od_prior_gt_map = od_prior_gt_map[valid_mask]

        if len(od_prior_gt_map) == 0:
            return 0.0, 0.0

        sorted_indices = torch.argsort(od_prior_pred, descending=True)
        od_gt_sorted = od_prior_gt_map[sorted_indices]
        od_prior_pred = od_prior_pred[sorted_indices]

        tp = (od_gt_sorted == 1).cumsum(0).float()
        fp = (od_gt_sorted == 0).cumsum(0).float()

        precision = tp / (tp + fp)  # precision = TP / (TP + FP)
        recall = tp / (od_prior_gt_map == 1).sum().float()  # recall = TP / (TP + FN)

        valid_indices = precision >= precision_thr
        if valid_indices.any():
            recall_at_thr = recall[valid_indices][-1].item()
            pred_score = od_prior_pred[valid_indices][-1].item()
        else:
            recall_at_thr = 0.0
            pred_score = 1.0
        return recall_at_thr, pred_score

    @timer(VIS)
    def dist_all_reduce(self, table_n_tensorboard_res):  # pylint: disable=arguments-renamed
        """Aggregate distributed evaluation results."""
        if self._enable_task == "astra_planner" or self._enable_task == "prediction":
            scene_list = list(self.metrics_aggregater_manager.scene_eval_infos.keys())
            metric_list = list(self.metrics_aggregater_manager.scene_eval_infos[scene_list[0]].metric_table.keys())
            for metric_agg_index in self.metric_agg_list:
                if metric_agg_index in metric_list:
                    rank_recall_max_shape = torch.tensor(0)
                    world_size = dist.get_world_size()
                    dist.barrier()
                    for scene_index in scene_list:
                        od_prior_pred = (
                            self.metrics_aggregater_manager.scene_eval_infos[scene_index]
                            .metric_table[metric_agg_index]
                            .val_sum
                        )
                        od_prior_gt_map = (
                            self.metrics_aggregater_manager.scene_eval_infos[scene_index]
                            .metric_table[metric_agg_index]
                            .index_cnt
                        )
                        if isinstance(od_prior_pred, float):
                            od_prior_pred = torch.tensor([torch.inf], device="cuda")
                            od_prior_gt_map = torch.tensor([torch.inf], device="cuda")
                        recall_thr = getattr(
                            self.metrics_aggregater_manager.scene_eval_infos[scene_index].metric_table[
                                metric_agg_index
                            ],
                            "buffer",
                            0.0,
                        )
                        if isinstance(recall_thr, float):
                            recall_thr = torch.tensor([recall_thr], dtype=torch.float32, device="cuda")
                        else:
                            recall_thr = torch.tensor(recall_thr, dtype=torch.float32, device="cuda")

                        dist.barrier()
                        od_prior_pred_shape = torch.tensor(od_prior_pred.shape, device="cuda")
                        recall_thr_shape = torch.tensor(recall_thr.shape, dtype=torch.int64, device="cuda")
                        all_od_prior_pred_shape = [
                            torch.zeros((1), dtype=torch.int64, device="cuda") for _ in range(world_size)
                        ]
                        all_recall_thr_shape = [
                            torch.zeros((1), dtype=torch.int64, device="cuda") for _ in range(world_size)
                        ]
                        dist.all_gather(all_od_prior_pred_shape, od_prior_pred_shape)
                        dist.all_gather(all_recall_thr_shape, recall_thr_shape)
                        all_recall_thr_shape = torch.tensor(all_recall_thr_shape)
                        rank_recall_max_shape = torch.max(rank_recall_max_shape, all_recall_thr_shape.max())
                        all_od_prior_pred_shape = torch.tensor(all_od_prior_pred_shape)
                        rank_max_shape = all_od_prior_pred_shape.max()
                        od_prior_pred = torch.cat(
                            (od_prior_pred, torch.zeros(rank_max_shape - od_prior_pred.shape[0], device="cuda"))
                        )
                        od_prior_gt_map = torch.cat(
                            (od_prior_gt_map, torch.zeros(rank_max_shape - od_prior_gt_map.shape[0], device="cuda"))
                        )
                        recall_thr = torch.cat(
                            (
                                recall_thr,
                                torch.zeros(rank_recall_max_shape - torch.tensor(recall_thr).shape[0], device="cuda"),
                            )
                        )
                        if dist.get_rank() == 0:
                            od_prior_pred_gather_list = [
                                torch.zeros(rank_max_shape, dtype=torch.float32, device="cuda")
                                for _ in range(world_size)
                            ]
                            od_prior_gt_map_gather_list = [
                                torch.zeros(rank_max_shape, dtype=torch.float32, device="cuda")
                                for _ in range(world_size)
                            ]
                            recall_thr_gather_list = [
                                torch.tensor(recall_thr, dtype=torch.float32, device="cuda") for _ in range(world_size)
                            ]
                        else:
                            od_prior_pred_gather_list = None
                            od_prior_gt_map_gather_list = None
                            recall_thr_gather_list = None
                        dist.gather(od_prior_pred, od_prior_pred_gather_list, dst=0)
                        dist.gather(od_prior_gt_map, od_prior_gt_map_gather_list, dst=0)
                        dist.gather(recall_thr, recall_thr_gather_list, dst=0)
                        dist.barrier()
                        if dist.get_rank() == 0:
                            od_prior_pred_gathered = torch.cat(
                                [
                                    od_prior_rank[:od_prior_shape_rand]
                                    for od_prior_rank, od_prior_shape_rand in zip(
                                        od_prior_pred_gather_list, all_od_prior_pred_shape
                                    )
                                ]
                            )
                            od_prior_gt_gathered = torch.cat(
                                [
                                    od_prior_gt_rank[:od_prior_shape_rand]
                                    for od_prior_gt_rank, od_prior_shape_rand in zip(
                                        od_prior_gt_map_gather_list, all_od_prior_pred_shape
                                    )
                                ]
                            )
                            recall_thr_gather_list = torch.cat(recall_thr_gather_list)
                            recall_thr_gather_list = recall_thr_gather_list.view(-1, rank_recall_max_shape)
                            recall_thr_gather_list, _ = torch.max(recall_thr_gather_list, dim=0)
                            valid_od_prior_pred_gathered_mask = torch.isinf(od_prior_pred_gathered)
                            od_prior_pred_gathered = od_prior_pred_gathered[
                                torch.logical_not(valid_od_prior_pred_gathered_mask)
                            ]
                            od_prior_gt_gathered = od_prior_gt_gathered[
                                torch.logical_not(valid_od_prior_pred_gathered_mask)
                            ]

                            precision = torch.zeros_like(recall_thr_gather_list)
                            pred_score = torch.zeros_like(recall_thr_gather_list)
                            for num_index, recall_thr_index in enumerate(recall_thr_gather_list.tolist()):
                                if metric_agg_index == "marginal/agent/track_recall_based_precision":
                                    precision[num_index], pred_score[num_index] = self.cal_recall(
                                        od_prior_pred_gathered, od_prior_gt_gathered, recall_thr_index
                                    )
                                elif metric_agg_index == "marginal/agent/prior_precision_based_recall":
                                    precision[num_index], pred_score[num_index] = self.cal_precision(
                                        od_prior_pred_gathered, od_prior_gt_gathered, recall_thr_index
                                    )
                            precision = torch.cat((precision, pred_score))
                            self.metrics_aggregater_manager.scene_eval_infos[scene_index].metric_table[
                                metric_agg_index
                            ].val_sum = precision
                            self.metrics_aggregater_manager.scene_eval_infos[scene_index].metric_table[
                                metric_agg_index
                            ].index_cnt = torch.ones_like(precision)
                    dist.barrier()

                    for scene_index in scene_list:
                        if dist.get_rank() != 0:
                            self.metrics_aggregater_manager.scene_eval_infos[scene_index].metric_table[
                                metric_agg_index
                            ].val_sum = torch.zeros(rank_recall_max_shape * 2, device="cuda")
                            self.metrics_aggregater_manager.scene_eval_infos[scene_index].metric_table[
                                metric_agg_index
                            ].index_cnt = torch.zeros(rank_recall_max_shape * 2, device="cuda")

            aggregated_metric_results = self.metrics_aggregater_manager.multi_node_aggregate()
            table_n_tensorboard_res = self.evaluation_report_manager(aggregated_metric_results)
            self.evaluation_saver.save_scene_metrics_to_csv_file(self.evaluation_report_manager.scene_metric_df)
            return table_n_tensorboard_res
        return {}

    def set_zero(self):
        """Set init evaluator."""
        self.gather_all_data = []
