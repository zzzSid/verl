# -*- coding: utf-8 -*-
"""Astra Planner Metrics Manager."""
import copy
import logging


logger = logging.getLogger(__name__)


class MetricsManager:
    """MetricsManager.

    An interface for calculating all single metrics
    """

    def __init__(self, cfg, util_func_dict, metric_func_dict, selected_metrics=None):
        """Init."""
        self.cfg = cfg
        self.util_func_dict = util_func_dict
        self.metric_func_dict = metric_func_dict
        self._build_selected_metrics_table(selected_metrics)

    def __call__(self, metric_inputs):
        """Call."""
        # tmp outputs calculated for final metrics calculations, saved for efficiency
        tmp_outputs = dict()
        for output_key in self.cfg["tmp_outputs"]:
            if output_key not in self.required_tmp_outputs:
                continue
            metric_cfg = self.cfg["tmp_outputs"][output_key]
            input_keys = metric_cfg.get("input_keys", [])
            tmp_keys = metric_cfg.get("tmp_keys", [])
            kwargs = metric_cfg.get("kwargs", {})
            util_func = metric_cfg["util_func"]
            inputs = [metric_inputs[key] for key in input_keys]
            # other tmp outputs used as input for this tmp output, e.g. acc calculation uses velocity
            tmp = [tmp_outputs[key] for key in tmp_keys]
            output = self.util_func_dict[util_func](*inputs, *tmp, **kwargs)
            tmp_outputs.update({output_key: output})

        result = dict()
        for output_key in self.cfg["single_metrics"]:
            if output_key not in self.selected_metrics:
                continue
            metric_cfg = self.cfg["single_metrics"][output_key]
            input_keys = metric_cfg.get("input_keys", [])
            tmp_keys = metric_cfg.get("tmp_keys", [])
            output_keys = metric_cfg.get("output_keys", [])
            kwargs = metric_cfg.get("kwargs", {})
            metric_func = metric_cfg["metric_func"]
            inputs = [metric_inputs[key] for key in input_keys]
            tmp = [tmp_outputs[key] for key in tmp_keys]
            # other output metric result used as input for this metric, e.g. MR calculation uses FDE
            other_outputs = [result[key][0] for key in output_keys]
            output = self.metric_func_dict[metric_func](*inputs, *tmp, *other_outputs, **kwargs)
            result.update({output_key: output})

        return result

    def _build_selected_metrics_table(self, selected_metrics):
        """Build selected metrics table."""
        # if user does not select any metrics, using all metrics as default
        if selected_metrics is None or len(selected_metrics) == 0:
            logger.info("User does not select any metrics, using all metrics as default...")
            self.selected_metrics = set(self.cfg["single_metrics"].keys())
            self.required_tmp_outputs = set(self.cfg["tmp_outputs"].keys())
            return

        self.required_tmp_outputs = set()
        self.selected_metrics = set()

        required_other_outputs = set(selected_metrics)
        while len(required_other_outputs) > 0:
            required_metrics = copy.deepcopy(required_other_outputs)
            required_other_outputs.clear()
            for metric in required_metrics:
                if metric not in self.cfg["single_metrics"]:
                    logger.warning("Metric %s is not implemented, skip it!!!!", metric)
                    continue

                metric_cfg = self.cfg["single_metrics"][metric]
                tmp_keys = metric_cfg.get("tmp_keys", [])
                required_tmp = set()
                if not self._dfs_tmp_keys(tmp_keys, required_tmp, metric):
                    continue

                self.required_tmp_outputs.update(required_tmp)

                self.selected_metrics.add(metric)
                output_keys = metric_cfg.get("output_keys", [])
                for other_output in output_keys:
                    if other_output not in self.selected_metrics:
                        required_other_outputs.add(other_output)

    def _dfs_tmp_keys(self, candidate_keys, required_tmp_keys, metric):
        """Dfs tmp keys.

        Args:
            candidate_keys: list
            required_tmp_keys: set
            metric: str
        """
        all_tmp_key_available = True
        for key in candidate_keys:
            if key in required_tmp_keys or key in self.required_tmp_outputs:
                continue
            if key not in self.cfg["tmp_outputs"]:
                logger.warning("Tmp output %s is not implemented for metric % s, skip the metric!!!!", key, metric)
                return False

            required_tmp_keys.add(key)
            other_tmp = self.cfg["tmp_outputs"][key].get("tmp_keys", [])
            if len(other_tmp) > 0:
                all_tmp_key_available = all_tmp_key_available and self._dfs_tmp_keys(
                    other_tmp, required_tmp_keys, metric
                )

        return all_tmp_key_available
