# -*- coding: utf-8 -*-
import pandas as pd
import torch.distributed as dist
from tabulate import tabulate  # noqa: I900


class EvaluationReportManager:
    def __init__(self, eval_report_cfg):
        """Init."""
        default_req_report_scenes_list = [
            "FullScene",
            "Straight",
            "TurnRight",
            "TurnLeft",
        ]
        default_report_metrics_list = [
            "joint/ego/1.0s_best_ade",
            "marginal/ego/min_od_collision_rate_3s",
            "marginal/agent/min_od_collision_rate_3s",
        ]

        self.req_report_scenes_list = eval_report_cfg.get("report_scenes_name", default_req_report_scenes_list)
        self.req_report_metrics_list = eval_report_cfg.get("report_metrics_name", default_report_metrics_list)
        self.req_report_metrics_list.append("scene_count")

        self.init_scene_metric_df()

    @property
    def scene_metric_df(self):
        """Get df."""
        return self._scene_metric_df

    def init_scene_metric_df(self):
        """Init df."""
        req_scene_names = self.req_report_scenes_list
        req_metric_names = self.req_report_metrics_list

        data = {}
        data.update({"MetricNames": req_metric_names})
        for req_name in req_scene_names:
            all_metric = [None for _ in req_metric_names]
            data.update({req_name: all_metric})

        self._scene_metric_df = pd.DataFrame(data)

    def generate_table_info(self, summaries):
        """Generate table info from summaries."""
        keys_total = []
        for key in summaries:
            item = key.split("@")[0]
            if item not in keys_total:
                keys_total.append(item)

        table_data = []
        for key in keys_total:
            if key not in self.req_report_metrics_list:
                continue
            table_data.append([key] + [summaries[key]])

        headers = ["metrics|class", "All"]
        table_vis = tabulate(
            headers=headers,
            tabular_data=table_data,
            tablefmt="grid",
            stralign="right",
            numalign="right",
        )
        return table_vis

    def __call__(self, aggregated_metric_results):
        """Call."""
        final_eval_result = {"lidar_table_vis": "", "lidar_tensorboard": {}}
        if dist.get_rank() != 0:
            return final_eval_result

        result_list_by_tag = list()
        for scene_name, metric in aggregated_metric_results.items():
            table_vis = self.generate_table_info(metric)
            eval_results = {
                "lidar_table_vis": f"\n{scene_name} Metric:\n" + table_vis,
                "lidar_tensorboard": {},
            }
            result_list_by_tag.append(eval_results)

            if scene_name in self.req_report_scenes_list:
                for metric_name, val in metric.items():
                    if metric_name not in self.req_report_metrics_list:
                        continue
                    metric_name_idx = self.req_report_metrics_list.index(metric_name)
                    self._scene_metric_df.loc[
                        metric_name_idx, scene_name
                    ] = val  # TODO(ian.xu): key check, better implementation?
        # ensure FullScene in the first column
        if "FullScene" in self._scene_metric_df.columns:
            col = self._scene_metric_df["FullScene"]
            self._scene_metric_df = self._scene_metric_df.drop(columns=["FullScene"])
            self._scene_metric_df.insert(1, "FullScene", col)
        for res in result_list_by_tag:
            # final_eval_result["lidar_table_vis"] += "\n\n" + res["lidar_table_vis"]
            if "FullScene" in res["lidar_table_vis"]:
                final_eval_result["lidar_tensorboard"].update(res["lidar_tensorboard"])
                final_eval_result["lidar_table_vis"] = res["lidar_table_vis"]
        return final_eval_result


def gather_visualization_data():
    """Gather vis data."""
    pass
