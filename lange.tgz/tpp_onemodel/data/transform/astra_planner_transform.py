# -*- coding: utf-8 -*-
"""Astra planner transform."""

import logging
import math
import random

import matplotlib.patches as patches
import matplotlib.pyplot as plt
import numpy as np
import torch
from scipy.interpolate import interp1d
from torchpilot.data.transform.base_transform import BaseTransform

from tpp_onemodel.utils.tld_utils import enable_stop_by_tld
from tpp_onemodel.utils.vehicle_param import ET5_length
from tpp_onemodel.utils.vehicle_param import ET5_width_w_mirror


logger = logging.getLogger(__name__)

__all__ = [
    "Convert2PlannerOldVersionFormat",
    "MannerLane2LaneKey",
    "LaneRemoveStopline",
    "LaneRemoveMarker",
    "ControlPointGen",
    "ControlPointAug",
    "StampGeneratePredLabel",
    "StampGenerateEgoPredLabel",
    "StampGenerateEgoPredVelLabel",
    "StampGenerateEgoPredSteeringWheelLabel",
    "StampGenerateEgoPreAccLabel",
    "StampGenerateEgoPreYawRateLabel",
    "StampTLDDataAug",
    "PlannerAlignEgoToRef",
    "PlannerAlignToRef",
    "PlannerGenStaticTransMat",
    "PlannerShufflePadBox",
    "PlannerShufflePadPolyline2D",
    "PlannerShufflePadPolyline2DLane",
    "PlannerShufflePadPolyline2DAtlas",
    "PlannerShufflePadPolyline2DSdmap",
    "PlannerPadTLD",
    "PlannerGenerateTracklet",
    "PlannerShufflePadPolygonAttr",
    "PlannerStaticDetsPadBox",
    "PlannerShufflePadPolyline2DDynamicGod",
    "PlannerShufflePadPolyline2DNaviLine",
    "PlannerShufflePadPolyline2DNaviPath",
    "PlannerGenerateAlignedGT",
    "PlannerEgoDeltaSpeedAug",
    "EgoGearGen",
    "ODPriorMaskGen",
]


class Convert2PlannerOldVersionFormat(BaseTransform):
    def __init__(self):
        """Init."""
        super().__init__()

    def __call__(self, data_dict):
        """Call."""
        new_data_dict = dict(current={}, history={}, future={}, update_subtasks=["prediction"])

        for temp_state in ["history", "current", "future"]:
            temp_res = {}
            for key in data_dict[temp_state][0]:
                if key in [
                    "dynamic_dets",
                    "static_dets",
                    "tsrs",
                    "crop_images",
                ]:
                    temp_res[key] = np.concatenate([item[key] for item in data_dict[temp_state]], axis=0)
                    temp_res[key + "_splits"] = np.array([len(item[key]) for item in data_dict[temp_state]])
                elif key == "tld":
                    temp_res[key] = np.concatenate([item[key] for item in data_dict[temp_state]], axis=0)
                elif key == "car_poses":
                    temp_res[key] = np.stack([item[key] for item in data_dict[temp_state]])
                elif key == "gt":
                    temp_res["bboxes"] = np.concatenate([item[key] for item in data_dict[temp_state]], axis=0)
                    temp_res["bboxes_splits"] = np.array([len(item[key]) for item in data_dict[temp_state]])
                else:
                    # "ids", "subclip_ids", "timestamps", "ego_motion", "scene_type",
                    # "adas_info", "lane_points", "lane_types", "atlas", "sdmap_geo"
                    temp_res[key] = [item.get(key, None) for item in data_dict[temp_state]]
            new_data_dict[temp_state] = temp_res

        for key in data_dict:
            if key not in ["current", "history", "future"]:
                new_data_dict[key] = data_dict[key]

        return new_data_dict


class MannerLane2LaneKey(BaseTransform):
    """Manner Lane to Lane Key."""

    def __init__(self):
        """Init."""
        super().__init__()

    def __call__(self, data_dict):
        """Call."""
        data_dict["current"]["lane_points"] = data_dict["current"]["manner_lane_points"]
        data_dict["current"]["lane_types"] = data_dict["current"]["manner_lane_types"]
        data_dict["current"]["lane_attr"] = data_dict["current"]["manner_lane_attr"]
        return data_dict


class ODPriorMaskGen(BaseTransform):
    """Manner Lane to Lane Key."""

    def __init__(self):
        """Init."""
        super().__init__()

    def __call__(self, data_dict):
        """Call."""
        od_prior_mask_input = np.zeros((data_dict["current"]["dynamic_dets"].shape[1]), dtype=np.float32)
        agent_padding_num = data_dict["current"]["dynamic_dets"].shape[1]
        priority_type = np.array(data_dict["current"]["priority_type"])
        agent_num = priority_type.shape[1]
        padding_num = agent_padding_num - agent_num
        priority_type = np.concatenate(
            (priority_type[:, :, 0], np.zeros((priority_type.shape[0], padding_num))), axis=1
        )
        od_prior_mask_input[priority_type[0] != 1] = 1
        data_dict["current"]["od_prior_mask_input"] = od_prior_mask_input
        return data_dict


class LaneRemoveStopline(BaseTransform):
    """Manner Lane to Lane Key."""

    def __init__(self):
        """Init."""
        super().__init__()

    def __call__(self, data_dict):
        """Call."""
        lane_points = data_dict["current"]["lane_points"][0]
        lane_types = data_dict["current"]["lane_types"][0]
        lane_attr = data_dict["current"]["lane_attr"][0]

        new_lane_points = []
        new_lane_types = []
        new_lane_attr = []
        for i in range(len(lane_points)):
            if lane_types[i] != 2:
                new_lane_points.append(lane_points[i])
                new_lane_types.append(lane_types[i])
                new_lane_attr.append(lane_attr[i])

        data_dict["current"]["lane_points"] = [new_lane_points]
        data_dict["current"]["lane_types"] = [np.array(new_lane_types)]
        data_dict["current"]["lane_attr"] = [new_lane_attr]
        return data_dict


class LaneRemoveMarker(BaseTransform):
    """Manner Lane to Lane Key."""

    def __init__(self):
        """Init."""
        super().__init__()

    def __call__(self, data_dict):
        """Call."""
        lane_points = data_dict["current"]["lane_points"][0]
        lane_types = data_dict["current"]["lane_types"][0]
        lane_attr = data_dict["current"]["lane_attr"][0]

        new_lane_points = []
        new_lane_types = []
        new_lane_attr = []
        for i in range(len(lane_points)):
            if lane_types[i] != 3:
                new_lane_points.append(lane_points[i])
                new_lane_types.append(lane_types[i])
                new_lane_attr.append(lane_attr[i])

        data_dict["current"]["lane_points"] = [new_lane_points]
        data_dict["current"]["lane_types"] = [np.array(new_lane_types)]
        data_dict["current"]["lane_attr"] = [new_lane_attr]
        return data_dict


class ControlPointGen(BaseTransform):
    """Control Point Generation."""

    def __init__(self, cp_type_list=None, avoid_tld_leakage=True):
        """Init."""
        super().__init__()
        self._cp_type_list = cp_type_list
        self.logger_print = False
        self.avoid_tld_leakage = True

    def __call__(self, data_dict):
        """Call."""
        future_ego_all = self._get_future_ego_all(data_dict)

        control_point = {}
        for cp_type in self._cp_type_list:
            control_point[cp_type] = getattr(self, f"_control_point_gen_{cp_type}")(future_ego_all, data_dict)

        data_dict["current"]["control_point"] = control_point

        return data_dict

    def _control_point_gen_position(self, future_ego_all, *args, **kwargs):
        """Control Point Generation Position."""
        return future_ego_all

    def _control_point_gen_stop_point(self, future_ego_all, *args, **kwargs):
        """Control Point Generation Position."""
        future_vel = np.linalg.norm(future_ego_all[2:, ...] - future_ego_all[:-2, ...], axis=1) / 0.4
        future_vel = np.concatenate([future_vel[:1], future_vel, future_vel[-1:]])
        future_vel_mask = future_vel < 0.005
        future_vel_mask[35:] = False

        stop_point_frame_idx = []
        next_is_stop = False
        for idx, current_is_stop in enumerate(future_vel_mask):
            next_is_stop = future_vel_mask[idx + 1] if idx + 1 < len(future_vel_mask) else False
            if current_is_stop and not next_is_stop:
                stop_point_frame_idx.append(idx)
        return future_ego_all[stop_point_frame_idx]

    def _control_point_gen_pos_vel(self, future_ego_all, *args, **kwargs):
        """Control Point Generation Position Velocity."""
        future_vel = (future_ego_all[2:, ...] - future_ego_all[:-2, ...]) / 0.4
        future_vel = np.concatenate([future_vel[:1], future_vel, future_vel[-1:]], axis=0)

        pos_vel = np.concatenate([future_ego_all, future_vel[:, ...]], axis=1)
        return pos_vel

    def _control_point_gen_pos_heading_vel(self, future_ego_all, *args, **kwargs):
        """Control Point Generation Position Velocity."""
        future_vel = (future_ego_all[2:, ...] - future_ego_all[:-2, ...]) / 0.4
        future_vel = np.concatenate([future_vel[:1], future_vel, future_vel[-1:]], axis=0)

        future_vel_norm = np.linalg.norm(future_vel, axis=1, keepdims=True)

        future_vel_norm[future_vel_norm[..., 0] < 1e-6, :] = 1e-6
        future_vel[future_vel_norm[..., 0] < 1e-6, :] = 0.0

        future_heading = future_vel / future_vel_norm

        if future_heading.shape[0] == 0:
            return np.empty((0, 5))

        pos_heading_vel = np.concatenate([future_ego_all, future_heading, future_vel_norm], axis=1)

        if self.avoid_tld_leakage:
            # 红灯，去除刹停后又起步的数据，防止异常溜车
            ego_stop_vel = 0.01  # 自车速度<0.01 则认为是停车
            if args[0]["current"]["navi_path_tld"][0][0] == 1:
                # 未来轨迹已经有刹停的点
                if pos_heading_vel[:, -1].min() <= ego_stop_vel:
                    # 去掉刹停后起步的数据
                    last_valid_index = np.where(pos_heading_vel[:, -1] <= ego_stop_vel)[0][-1]
                    if self.logger_print and pos_heading_vel.shape[0] > last_valid_index + 1:
                        logger.info("abandon future leakage: %d", pos_heading_vel.shape[0] - last_valid_index)
                    pos_heading_vel = pos_heading_vel[: last_valid_index + 1, :]

        return pos_heading_vel

    def _transform_car_pose(self, car_poses, data_dict):
        """Transform Control Point."""
        current_to_world = data_dict["current"]["car_poses"]
        homo_ego_future = np.zeros((len(car_poses), 4, 1), dtype=np.float32)
        homo_ego_future[:, -1, :] = 1.0
        frame_to_current = np.linalg.inv(current_to_world) @ car_poses

        ego_future = frame_to_current @ homo_ego_future

        return ego_future[:, :2, 0]

    def _get_future_ego_all(self, data_dict):
        """Get all future ego."""
        future_all_meta = data_dict["future-all-meta"]

        carposes = np.array(
            [np.frombuffer(frame["meta"]["car_pose"], np.float32).reshape(4, 4) for frame in future_all_meta]
        )
        timestamps = np.array([frame["timestamps"] for frame in future_all_meta])
        target_timestamps = np.arange(timestamps[0], timestamps[0] + carposes.shape[0] * 0.2 - 0.01, 0.2)

        ego_future = self._transform_car_pose(carposes, data_dict)
        if data_dict["current"]["aligned_trajectory"][0] is not None:
            aligned_trajectory = data_dict["current"]["aligned_trajectory"][0]

            align_len = aligned_trajectory.shape[0]
            raw_len = ego_future.shape[0]
            if align_len < raw_len:
                # ego_future[:align_len, 0:2] = aligned_trajectory[:align_len, 0:2]
                # ego_future[align_len:, 0:2] = aligned_trajectory[-1, 0:2]
                ego_future = aligned_trajectory[:, 0:2]
                timestamps = timestamps[:align_len]
                target_timestamps = target_timestamps[:align_len]
            else:
                ego_future = aligned_trajectory[:raw_len, 0:2]
                timestamps = timestamps[:raw_len]
                target_timestamps = target_timestamps[:raw_len]

        ego_future_interp = PlannerGenerateAlignedGT.interpolate_fut_pred(
            timestamps,
            ego_future[None, None, ...],
            np.ones((1, 1, ego_future.shape[0])),
            target_timestamps,
        )[0, 0]

        return ego_future_interp

    def _control_point_gen_tld_stop_point(self, future_ego_all, *args, **kwargs):
        """Control Point Generation Position."""
        ego_vx = torch.from_numpy(args[0]["current"]["egos"][:, 10])
        navi_path_tld = torch.from_numpy(args[0]["current"]["navi_path_tld"])
        navi_path_stoppoints_x = torch.from_numpy(args[0]["current"]["navi_path_stoppoints"][:, 0, 0])
        tld_color = navi_path_tld[:, 0]
        tld_blink = navi_path_tld[:, 1]
        tld_countdown = navi_path_tld[:, 2]

        stopline_thw = navi_path_stoppoints_x / torch.clamp(ego_vx, min=0.1)

        enable_stoppoints_by_tld = enable_stop_by_tld(
            stopline_thw, navi_path_stoppoints_x, tld_color, tld_blink, tld_countdown
        )
        if not enable_stoppoints_by_tld.item():
            return []

        #   - 头车刹停，使用 gt 轨迹真实的停止点，v=0

        if (
            "astra_planner.ego_state.head_type.first" in args[0]["current"]["tags"][0]
            or "astra_planner.fft_urban.junction.head_pass" in args[0]["current"]["tags"][0]
            or "astra_planner.fft_urban.junction.tld_start" in args[0]["current"]["tags"][0]
            or "astra_planner.fft_urban.junction.tld_stop" in args[0]["current"]["tags"][0]
        ):
            ego_gt_trajectory = future_ego_all
            if ego_gt_trajectory is None or ego_gt_trajectory.shape[0] < 2:
                return []
            if abs(ego_gt_trajectory[-2][0] - ego_gt_trajectory[-1][0]) < 1e-2:
                ego_stoppoint_pos_x_y = ego_gt_trajectory[-1][0:2]
                # 前面有ego的代表自车真实的停车位置，没有ego的代表navi path上的stoppoint
                ego_stop_point_vel = 0.0
                ego_stop_point_pos_heading_vel = [
                    ego_stoppoint_pos_x_y[0],
                    ego_stoppoint_pos_x_y[1],
                    -1,
                    -1,
                    ego_stop_point_vel,
                ]
                if self.logger_print:
                    logger.info("is head car stop_point_pos_heading_vel: %s", ego_stop_point_pos_heading_vel)
                return [ego_stop_point_pos_heading_vel]

        #   - 非头车，使用 stoppoints 作为控制点，不给速度
        else:
            stop_point_x_y = args[0]["current"]["navi_path_stoppoints"][0, 0]
            stop_point_vel = -1
            stop_point_pos_heading_vel = [
                stop_point_x_y[0],
                stop_point_x_y[1],
                -1,
                -1,
                stop_point_vel,
            ]
            if self.logger_print:
                logger.info("not head car stop_point_pos_heading_vel: %s", stop_point_pos_heading_vel)
            return [stop_point_pos_heading_vel]
        return []

    def _move_stoppoints_close_to_ego(self, x, y, distance):
        # Distance to move towards the origin

        # Calculate the direction vector from the point to the origin
        direction_vector = np.array([0 - x, 0 - y])

        # Calculate the magnitude (length) of the direction vector
        magnitude = np.linalg.norm(direction_vector)

        # If the magnitude is zero, the point is already at the origin
        if magnitude == 0:
            # print("The point is already at the origin.")
            new_x, new_y = 0, 0
        else:
            # Normalize the direction vector to get a unit vector
            unit_vector = direction_vector / magnitude

            # Scale the unit vector by the distance
            scaled_vector = unit_vector * distance

            # Subtract the scaled vector from the original point to get the new position
            new_x, new_y = x - scaled_vector[0], y - scaled_vector[1]
        # if self.logger_print:
        #     print("Original position:", (x, y), "New position:", (new_x, new_y))
        return max(new_x, 0.0), new_y


class ControlPointAug(BaseTransform):
    """Augment control points."""

    def __init__(self, aug_func=None, max_point=3, train=True):
        """Init."""
        self._aug_func = aug_func
        self.train_mode = train
        self.logger_print = False
        self.max_point = max_point

    def __call__(self, data_dict):
        """Call."""
        control_point_list = []
        for cp_type in self._aug_func:
            cp = data_dict["current"]["control_point"][cp_type]
            for func in self._aug_func[cp_type]:
                cp = getattr(self, f"_{cp_type}_{func['name']}")(cp, **{k: v for k, v in func.items() if k != "name"})
            control_point_list.append(cp)

        if "tld_stop_point" in self._aug_func:
            # 将 tld_stop_point 放到第一个位置
            tld_stop_point_idx = list(self._aug_func.keys()).index("tld_stop_point")
            tld_stop_point = control_point_list[tld_stop_point_idx]
            if (tld_stop_point.ndim == 2 and tld_stop_point[0][0] != -1.0) or (
                tld_stop_point.ndim == 3 and tld_stop_point[0][0][0] != -1.0
            ):
                del control_point_list[tld_stop_point_idx]
                control_point_list.insert(0, tld_stop_point)

        control_point = np.concatenate(control_point_list, axis=-2)
        # 控制点最多3个
        if control_point.ndim == 2:
            control_point = control_point[: self.max_point]
        else:
            control_point_dim = control_point.shape[-1]
            control_point = control_point[:, : self.max_point, :control_point_dim]

        # if not self.train_mode:
        #     control_point[:] = -1
        data_dict["current"]["control_point"] = control_point

        return data_dict

    def _position_random_sample(self, cp, cp_min, cp_max):
        """Random Sample."""
        randint = np.random.randint(cp_min, cp_max + 1)
        rand_sample_idx = random.sample(range(len(cp)), min(randint, len(cp)))
        return cp[rand_sample_idx]

    def _position_padding(self, cp, length_pad, dim_pad, default_val):
        """Pad."""
        cp_num, cp_dim = cp.shape
        if cp_num > length_pad or cp_dim > dim_pad:
            raise ValueError("Control point dimension is larger than the padding size")

        if cp_dim < dim_pad:
            cp = np.concatenate([cp, np.ones((cp_num, dim_pad - cp_dim), dtype=np.float32) * default_val], axis=1)
        if cp_num < length_pad:
            cp = np.concatenate([cp, np.ones((length_pad - cp_num, dim_pad), dtype=np.float32) * default_val], axis=0)
        return cp

    def _position_add_onehot_type(self, cp, cp_type_idx, cp_type_num):
        """Add Onehot."""
        return np.concatenate([cp, np.repeat([np.eye(cp_type_num)[cp_type_idx]], len(cp), axis=0)], axis=1)

    def _stop_point_padding(self, cp, length_pad, dim_pad, default_val):
        """Pad."""
        cp_num, cp_dim = cp.shape
        if cp_num > length_pad or cp_dim > dim_pad:
            raise ValueError("Control point dimension is larger than the padding size")

        if cp_dim < dim_pad:
            cp = np.concatenate([cp, np.ones((cp_num, dim_pad - cp_dim), dtype=np.float32) * default_val], axis=1)
        if cp_num < length_pad:
            cp = np.concatenate([cp, np.ones((length_pad - cp_num, dim_pad), dtype=np.float32) * default_val], axis=0)
        return cp

    def _stop_point_random_sample(self, cp, cp_min, cp_max):
        """Random Sample."""
        if len(cp) == 0:
            return cp
        if cp_min == 0:
            keep_none = np.random.choice([True, False], p=[0.2, 0.8])
            if keep_none:
                return cp[[], ...]
        sample_idx = list(range(min(len(cp), cp_max)))
        return cp[sample_idx]

    def _stop_point_add_onehot_type(self, cp, cp_type_idx, cp_type_num):
        """Add Onehot."""
        return np.concatenate([cp, np.repeat([np.eye(cp_type_num)[cp_type_idx]], len(cp), axis=0)], axis=1)

    def _pos_vel_random_sample(self, cp, cp_min, cp_max):
        """Random Sample."""
        randint = np.random.randint(cp_min, cp_max + 1)
        rand_sample_idx = random.sample(range(len(cp)), min(randint, len(cp)))
        return cp[rand_sample_idx]

    def _pos_vel_random_drop_vel(self, cp, drop_prob):
        """Random Sample."""
        if len(cp) == 0:
            return cp
        drop_idx = [i for i in range(len(cp)) if random.random() < drop_prob]
        cp[drop_idx, 2:] = -1.0
        return cp

    def _pos_vel_add_onehot_type(self, cp, cp_type_idx, cp_type_num):
        """Add Onehot."""
        return np.concatenate([cp, np.repeat([np.eye(cp_type_num)[cp_type_idx]], len(cp), axis=0)], axis=1)

    def _pos_vel_padding(self, cp, length_pad, dim_pad, default_val):
        """Pad."""
        cp_num, cp_dim = cp.shape
        if cp_num > length_pad or cp_dim > dim_pad:
            raise ValueError("Control point dimension is larger than the padding size")

        if cp_dim < dim_pad:
            cp = np.concatenate([cp, np.ones((cp_num, dim_pad - cp_dim), dtype=np.float32) * default_val], axis=1)
        if cp_num < length_pad:
            cp = np.concatenate([cp, np.ones((length_pad - cp_num, dim_pad), dtype=np.float32) * default_val], axis=0)
        return cp

    def _pos_heading_vel_random_sample(self, cp, cp_min, cp_max, prob_0, prob_1, prob_2, prob_3):
        """Random Sample."""
        if cp_min == 0 and cp_max == 0:
            randint = 0
        else:
            if cp.shape[0] < 10:
                randint = np.random.choice(list(np.arange(cp_min, cp_max + 1)), p=prob_0)
            elif cp.shape[0] < 25:
                randint = np.random.choice(list(np.arange(cp_min, cp_max + 1)), p=prob_1)
            elif cp.shape[0] < 40:
                randint = np.random.choice(list(np.arange(cp_min, cp_max + 1)), p=prob_2)
            else:
                randint = np.random.choice(list(np.arange(cp_min, cp_max + 1)), p=prob_3)
        rand_sample_idx = random.sample(range(len(cp)), min(randint, len(cp)))
        # rand_sample_idx = [24 if len(cp) > 24 else len(cp) - 1]
        sampled_cp = cp[rand_sample_idx]
        sampled_cp = np.concatenate([sampled_cp, np.array(rand_sample_idx).reshape(-1, 1) / 50], axis=-1)
        return sampled_cp

    def _pos_heading_vel_add_onehot_type(self, cp, cp_type_idx, cp_type_num):
        """Add Onehot."""
        return np.concatenate([cp, np.repeat([np.eye(cp_type_num)[cp_type_idx]], len(cp), axis=0)], axis=1)

    def _pos_heading_vel_padding(self, cp, length_pad, dim_pad, default_val):
        """Pad."""
        cp_num, cp_dim = cp.shape
        if cp_num > length_pad or cp_dim > dim_pad:
            raise ValueError("Control point dimension is larger than the padding size")

        if cp_dim < dim_pad:
            cp = np.concatenate([cp, np.ones((cp_num, dim_pad - cp_dim), dtype=np.float32) * default_val], axis=1)
        if cp_num < length_pad:
            cp = np.concatenate([cp, np.ones((length_pad - cp_num, dim_pad), dtype=np.float32) * default_val], axis=0)
        return cp

    def _pos_heading_vel_random_drop_vel(self, cp, drop_prob):
        """Random Sample."""
        if len(cp) == 0:
            return cp
        drop_idx = [i for i in range(len(cp)) if random.random() < drop_prob]
        cp[drop_idx, 4] = -1.0
        return cp

    def _pos_heading_vel_random_drop_time(self, cp, drop_prob):
        """Random Sample."""
        if len(cp) == 0:
            return cp
        drop_idx = [i for i in range(len(cp)) if random.random() < drop_prob]
        cp[drop_idx, 5] = -1.0
        return cp

    def _pos_heading_vel_random_drop_heading(self, cp, drop_prob):
        """Random Sample."""
        if len(cp) == 0:
            return cp
        drop_idx = [i for i in range(len(cp)) if random.random() < drop_prob]
        cp[drop_idx, 2:4] = -1.0
        return cp

    def _pos_heading_vel_batch_repeat(self, cp, repeat_num):
        """Pad."""
        cp = cp[None, ...]
        cp = np.repeat(cp, repeat_num, axis=0)
        return cp

    def _tld_stop_point_default_time(self, cp):
        """Random Sample."""
        if len(cp) == 0:
            return cp
        return np.concatenate([cp, np.array(-1).reshape(-1, 1)], axis=-1)

    def _tld_stop_point_add_onehot_type(self, cp, cp_type_idx, cp_type_num):
        """Add Onehot."""
        if len(cp) == 0:
            return cp
        return self._pos_heading_vel_add_onehot_type(cp, cp_type_idx, cp_type_num)

    def _tld_stop_point_padding(self, cp, length_pad, dim_pad, default_val):
        """Pad."""
        if len(cp) == 0:
            return np.array([[-1] * dim_pad])
        else:
            return cp

    def _tld_stop_point_batch_repeat(self, cp, repeat_num):
        """Pad."""
        cp = cp[None, ...]
        cp = np.repeat(cp, repeat_num, axis=0)
        return cp


class StampGeneratePredLabel(BaseTransform):  # pylint: disable=too-few-public-methods
    """StampGeneratePredLabel."""

    def __init__(
        self,
        num_future=80,
        mask_odd=False,
        priority_filter=-1,
        box_key="dets",
        use_gpu: bool = False,
    ) -> None:
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.box_key = box_key
        self.num_future = num_future
        self.mask_odd = mask_odd
        self.priority_filter = priority_filter

    def __call__(self, inputs):
        """Generate prediction label."""
        box_key = self.box_key
        split_key = f"{self.box_key}_splits"

        cur_bboxes = inputs["current"][box_key][0]  # n_t, D
        cur_bboxes_splits = inputs["current"][split_key]  # 1

        fut_bboxes = inputs["future"][box_key]  # n_t, D
        fut_bboxes_splits = inputs["future"][split_key]  # 1

        cur_gt_bboxes = inputs["current"]["bboxes"]

        fut_frame_id = []
        for frame_id, splits in enumerate(fut_bboxes_splits):
            fut_frame_id.extend([frame_id] * splits)
        fut_frame_id = np.array(fut_frame_id)

        dets_pred_gt = np.zeros((cur_bboxes.shape[0], self.num_future, 2), dtype=cur_bboxes.dtype)  # [n_t, T_f, 2]
        dets_pred_mask = np.zeros((cur_bboxes.shape[0], self.num_future), dtype=cur_bboxes.dtype)  # [n_t, T_f]
        dets_pred_info_gt = np.zeros(
            (cur_bboxes.shape[0], self.num_future, fut_bboxes.shape[1]), dtype=cur_bboxes.dtype
        )  # [n_t, T_f, 5] vx, vy, h, l, w

        for i, src_box in enumerate(cur_bboxes[: cur_bboxes_splits[0]]):
            track_id = src_box[9]

            if cur_gt_bboxes.shape[0] > 0:
                gt_idx = np.where(cur_gt_bboxes[:, 9] == track_id)[0]
                if gt_idx.shape[0] > 1:
                    logger.warning("Multiple gt bboxes found for track_id: %d", track_id)
                if self.priority_filter > -1:
                    obj_priority = cur_gt_bboxes[gt_idx[0], 17]
                    if obj_priority < self.priority_filter:
                        dets_pred_mask[i] = 0
                        continue

            idx = np.where(fut_bboxes[:, 9] == track_id)
            if self.mask_odd:
                ts_falcon = np.round(fut_bboxes[idx][:, -2] * 10)
                idx = idx[0][ts_falcon % 2 == 0]  # select all even index
                # idx = idx[0][idx[0] %2 == 0]  # select all even index
                if idx.shape[0] == 0:
                    continue
            elif idx[0].shape[0] == 0:
                continue

            gts_pred = fut_bboxes[idx]  # [n_satis, 15]
            timeflag = fut_frame_id[idx]  # [n_satis,]

            dets_pred_gt[i, timeflag] = gts_pred[:, :2]
            dets_pred_mask[i, timeflag] = 1

            dets_pred_info_gt[i, timeflag] = gts_pred[:, :]

        inputs["current"][f"{self.box_key}_pred_gt"] = dets_pred_gt
        inputs["current"][f"{self.box_key}_pred_mask"] = dets_pred_mask
        inputs["current"][f"{self.box_key}_pred_full_info_gt"] = dets_pred_info_gt
        return inputs


class StampGenerateEgoPredLabel(BaseTransform):  # pylint: disable=too-few-public-methods
    """StampGenerateEgoPredLabel."""

    def __init__(
        self,
        num_future=80,
        mask_odd=False,
        future_leakage_tags=["change_to_green", "change_to_red"],
        use_gpu: bool = False,
    ) -> None:
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.num_future = num_future
        self.mask_odd = mask_odd
        self.future_leakage_tags = future_leakage_tags

    def __call__(self, inputs):
        """Generate prediction label."""
        egos_pred_gt = np.zeros((1, self.num_future, 2), dtype=inputs["future"]["egos"].dtype)  # [n_t, T_f, 2]
        egos_yaw_pred_gt = np.zeros((1, self.num_future, 1), dtype=inputs["future"]["egos"].dtype)  # [n_t, T_f, 2]

        egos_pred_mask = np.zeros((1, self.num_future), dtype=inputs["future"]["egos"].dtype)  # [n_t, T_f]

        for frame_idx in range(inputs["future"]["egos"].shape[0]):
            if inputs["future"]["scene_type"][frame_idx] == "pad":
                continue
            egos_pred_gt[:, frame_idx] = inputs["future"]["egos"][frame_idx, :2]
            egos_yaw_pred_gt[:, frame_idx] = inputs["future"]["egos"][frame_idx, 6:7]
            # 1 for valid, 0 for invalid
            if self.mask_odd and frame_idx % 2 != 0:
                continue
            is_found_leakage = False
            for tag in self.future_leakage_tags:
                if tag in inputs["future"]["tags"][frame_idx] if "tags" in inputs["future"] else []:
                    is_found_leakage = True
                    break
            if is_found_leakage:
                continue
            egos_pred_mask[:, frame_idx] = 1.0

        inputs["current"]["egos_pred_gt"] = egos_pred_gt
        inputs["current"]["egos_pred_mask"] = egos_pred_mask
        inputs["current"]["egos_yaw_pred_gt"] = egos_yaw_pred_gt

        return inputs


class StampGenerateEgoPredVelLabel(BaseTransform):  # pylint: disable=too-few-public-methods
    """StampGenerateEgoPredVelLabel."""

    def __init__(
        self,
        num_future=80,
        use_gpu: bool = False,
    ) -> None:
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.num_future = num_future

    def __call__(self, inputs):
        """Generate ego prediction velocity label."""
        fut_bboxes = inputs["future"]["egos"]  # T_f, D
        ego_pred_gt = np.zeros((self.num_future, 2), dtype=fut_bboxes.dtype)  # [T_f, 2]

        for frame_idx, src_box in enumerate(fut_bboxes):
            if inputs["future"]["scene_type"][frame_idx] == "pad":
                continue
            ego_pred_gt[frame_idx] = src_box[[10, 11]]

        inputs["current"]["ego_vel_pred_gt"] = ego_pred_gt
        return inputs


class StampGenerateEgoPredSteeringWheelLabel(BaseTransform):  # pylint: disable=too-few-public-methods
    """StampGenerateEgoPredVelLabel."""

    def __init__(
        self,
        num_future=80,
        use_gpu: bool = False,
    ) -> None:
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.num_future = num_future

    def __call__(self, inputs):
        """Generate ego prediction steering-wheel label."""
        fut_bboxes = inputs["future"]["egos"]  # T_f, D
        ego_pred_gt = np.zeros((self.num_future,), dtype=fut_bboxes.dtype)  # [T_f, 1]
        for i, src_box in enumerate(fut_bboxes):
            ego_pred_gt[i] = src_box[8]

        inputs["current"]["ego_steering_wheel_pred_gt"] = ego_pred_gt
        return inputs


class StampGenerateEgoPreAccLabel(BaseTransform):  # pylint: disable=too-few-public-methods
    """StampGenerateEgoPredVelLabel."""

    def __init__(
        self,
        num_future=80,
        use_gpu: bool = False,
    ) -> None:
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.num_future = num_future

    def __call__(self, inputs):
        """Generate ego prediction acc label."""
        fut_bboxes = inputs["future"]["egos"]  # T_f, D
        ego_pred_gt = np.zeros((self.num_future, 2), dtype=fut_bboxes.dtype)  # [T_f, 1]
        for i, src_box in enumerate(fut_bboxes):
            ego_pred_gt[i] = src_box[[12, 13]]

        inputs["current"]["ego_acc_pred_gt"] = ego_pred_gt
        return inputs


class StampGenerateEgoPreYawRateLabel(BaseTransform):  # pylint: disable=too-few-public-methods
    """StampGenerateEgoPredVelLabel."""

    def __init__(
        self,
        num_future=80,
        use_gpu: bool = False,
    ) -> None:
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.num_future = num_future

    def __call__(self, inputs):
        """Generate ego prediction yaw rate label."""
        fut_bboxes = inputs["future"]["egos"]  # T_f, D
        ego_pred_gt = np.zeros((self.num_future,), dtype=fut_bboxes.dtype)  # [T_f, 1]
        for i, src_box in enumerate(fut_bboxes):
            ego_pred_gt[i] = src_box[14]

        inputs["current"]["ego_yaw_rate_pred_gt"] = ego_pred_gt
        return inputs


class StampTLDDataAug(BaseTransform):  # pylint: disable=too-few-public-methods
    """StampTLDDataAug."""

    def __init__(self, ego_future_frame_num=25, dis_to_stopline=[25, 50], use_gpu=False):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.ego_future_frame_num = ego_future_frame_num
        self.tld_data_aug = True
        self.logger_print = False
        self.dis_to_stopline = dis_to_stopline

    def draw_img(self, inputs, save_path):
        """Draw img."""
        # 示例数据：框的中心点和长宽
        boxes = [
            # {'center': (1, 1), 'width': 2, 'height': 3},
            # {'center': (-2, -1), 'width': 1, 'height': 2},
            # {'center': (4, 5), 'width': 3, 'height': 1},
        ]
        total_agent_data = inputs["current"]["dynamic_dets"]
        filtered_agent_data = total_agent_data[:, ~inputs["current"]["dynamic_dets_padding_mask"][0], :]
        for i in filtered_agent_data[0]:
            boxes.append({"center": (i[0], i[1]), "width": i[3], "height": i[4]})
        # 创建一个绘图
        fig, ax = plt.subplots()

        # 绘制每个框
        for box in boxes:
            # 计算框的左下角坐标
            center_x, center_y = box["center"]
            width, height = box["width"], box["height"]

            # 左下角坐标 (x - width/2, y - height/2)
            lower_left_x = center_x - width / 2
            lower_left_y = center_y - height / 2

            # 创建矩形框并添加到图中
            rect = patches.Rectangle(
                (lower_left_x, lower_left_y), width, height, linewidth=1, edgecolor="blue", facecolor="none"
            )
            ax.add_patch(rect)

        rect1 = patches.Rectangle(
            (-20, -2),
            inputs["current"]["navi_path_stoppoints"][0][0][0] + 20,
            4,
            linewidth=2,
            edgecolor="black",
            facecolor="none",
            label="Box 1",
        )  # (-10,90) x & (-2,2) y
        rect2 = patches.Rectangle(
            (0, -2),
            inputs["current"]["navi_path_stoppoints"][0][0][0],
            4,
            linewidth=2,
            edgecolor="purple",
            facecolor="none",
            label="Box 2",
        )  # (0,90) x & (-2,2) y
        ax.add_patch(rect1)
        ax.add_patch(rect2)

        # 获取 egos_pred_gt 中的点
        egos_pred_gt = inputs["trans"]["egos_pred_gt"][0, 0]  # 形状 (35,2)

        # 绘制黑色的 egos_pred_gt 点
        ax.scatter(egos_pred_gt[:, 0], egos_pred_gt[:, 1], color="black", marker="o", s=10, label="Egos Pred GT")

        # 绘制绿色的 (0,0) 点
        ax.scatter(0, 0, color="green", marker="o", s=100, label="Ego")

        # 绘制红色的 (1,1) 点
        ax.scatter(
            inputs["current"]["navi_path_stoppoints"][0][0][0], 0, color="red", marker="o", s=100, label="Stoppoint"
        )

        # 设置图的范围
        ax.set_xlim(-40, 80)
        ax.set_ylim(-50, 50)
        ax.set_aspect("equal", "box")

        plt.savefig(save_path)

        # 关闭图形，避免显示
        plt.close()

    def generate_and_fit_trajectory(self, trajectory, v0, a, num_points, time_interval):
        """Generate and fit trajectory."""
        new_point = np.array([[[0.0, 0.0]]])
        trajectory = np.concatenate((new_point, trajectory), axis=1)
        trajectory = trajectory[0]

        # 时间序列
        t = np.arange(num_points) * time_interval

        # 初始化新轨迹坐标
        x_new = np.zeros(num_points)
        y_new = np.zeros(num_points)

        # 累计距离计算
        s_new = v0 * t + 0.5 * a * t**2
        segment_idx = 0

        # 遍历生成轨迹点
        for i in range(num_points):
            while segment_idx < len(trajectory) - 1:
                # 当前线段的起点和终点
                x1, y1 = trajectory[segment_idx]
                x2, y2 = trajectory[segment_idx + 1]

                # 计算线段长度
                segment_length = np.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)

                if s_new[i] <= segment_length:
                    # 计算比例，插值计算当前点
                    ratio = s_new[i] / segment_length
                    x_new[i] = x1 + ratio * (x2 - x1)
                    y_new[i] = y1 + ratio * (y2 - y1)
                    break
                else:
                    s_new[i:] -= segment_length
                    segment_idx += 1
        return np.expand_dims(np.stack((x_new, y_new), axis=1), axis=0)

    def agent_status(self, inputs):
        """Generate agent status."""
        stoppoint_x = inputs["current"]["navi_path_stoppoints"][0][0][0]
        total_agent_data = inputs["current"]["dynamic_dets"]
        filtered_agent_data = total_agent_data[:, ~inputs["current"]["dynamic_dets_padding_mask"][0], :]
        x_coords = filtered_agent_data[:, :, 0]
        y_coords = filtered_agent_data[:, :, 1]
        valid_mask = (x_coords > -20) & (x_coords < stoppoint_x) & (y_coords > -2) & (y_coords < 2)
        valid_data = filtered_agent_data[:, valid_mask[0], :]
        if valid_data.shape[1] == 0 or (
            valid_data.shape[1] > 0 and np.all(valid_data[:, :, 10] == 0) and np.all(valid_data[:, :, 11] == 0)
        ):
            return True
        else:
            return False

    def __call__(self, inputs):
        """Generate prediction label."""
        ego_vel = inputs["current"]["egos"][0][10:12]
        stoppoint_x = inputs["current"]["navi_path_stoppoints"][0][0][0]
        # ego_acceleration = inputs["current"]["egos"][0][12]

        # 1. [red light] avoid future leakage

        if inputs["current"]["navi_path_tld"][0][0] == 1 and ego_vel[0] == 0 and ego_vel[1] == 0:
            if (
                self.agent_status(inputs)
                and stoppoint_x >= self.dis_to_stopline[0]
                and stoppoint_x <= self.dis_to_stopline[1]
            ):
                stoppoint_x = inputs["current"]["navi_path_stoppoints"][0][0][0]
                total_agent_data = inputs["current"]["dynamic_dets"]
                filtered_agent_data = total_agent_data[:, ~inputs["current"]["dynamic_dets_padding_mask"][0], :]
                x_coords = filtered_agent_data[:, :, 0]  # x 坐标
                y_coords = filtered_agent_data[:, :, 1]  # y 坐标

                valid_mask = (x_coords > 0) & (x_coords < stoppoint_x) & (y_coords > -2) & (y_coords < 2)
                valid_data = filtered_agent_data[:, ~valid_mask[0], :]

                padded_data = np.full((1, 191, 40), fill_value=-1, dtype=valid_data.dtype)
                padded_data[:, : valid_data.shape[1], :] = valid_data

                inputs["current"]["dynamic_dets"] = padded_data
                inputs["current"]["dynamic_dets_splits"] = valid_data.shape[1]
                padded_mask = np.ones((1, 191), dtype=bool)
                padded_mask[:, : valid_data.shape[1]] = False
                inputs["current"]["dynamic_dets_padding_mask"] = padded_mask

                t = np.arange(self.ego_future_frame_num) * 0.2  # egos_pred_gt中时间间隔为0.2s
                a = 1  # 1m/s2 匀加速
                # x = a * t + a * t**2 / 2  # 初始位置x0=0 初始速度v0=0 加速度a=1
                # trajectory = np.stack((x, np.zeros_like(x)), axis=-1).reshape(1, self.ego_future_frame_num, 2)
                trajectory = self.generate_and_fit_trajectory(
                    inputs["current"]["navi_path_points"],
                    v0=0,
                    a=a,
                    num_points=self.ego_future_frame_num,
                    time_interval=0.2,
                )
                inputs["current"]["egos_pred_gt"] = trajectory
                inputs["current"]["egos_pred_mask"] = np.ones(
                    (1, self.ego_future_frame_num), dtype=inputs["future"]["egos"].dtype
                )
                v_x = a * t  # 速度公式 v = v0 + a * t
                v_y = np.zeros_like(v_x)  # v_y 设为 0
                ego_vel_pred_gt = np.stack((v_x, v_y), axis=-1).reshape(self.ego_future_frame_num, 2)  # 调整维度匹配
                inputs["current"]["ego_vel_pred_gt"] = ego_vel_pred_gt
                inputs["data_aug"] = "tld_data_aug_red_light_start_fake_gt"
            else:
                if self.logger_print:
                    logger.info("[red light] avoid future leakage")
                inputs["current"]["ego_vel_pred_gt"] = np.zeros(
                    (self.ego_future_frame_num, 2), dtype=inputs["future"]["egos"].dtype
                )
                inputs["current"]["egos_pred_gt"] = np.zeros(
                    (1, self.ego_future_frame_num, 2), dtype=inputs["future"]["egos"].dtype
                )
                inputs["data_aug"] = "tld_data_aug_red_light_stop_fake_gt"

        return inputs


class PlannerAlignEgoToRef(BaseTransform):  # pylint: disable=too-few-public-methods
    """Align ego bbox to current frame. For e2e-planner."""

    def __init__(self, align=True, use_gpu: bool = False, use_future: bool = False):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.align = align
        self.use_future = use_future

    @staticmethod
    def align_yaw(yaw, rt_mat):
        """Align Yaw using RT matrix."""
        return yaw + np.arctan2(rt_mat[1, 0], rt_mat[0, 0])

    def __call__(self, inputs):  # pylint: disable=too-many-statements
        """Only align History Det&GT bbox to current frame."""
        states = ["history", "current"]
        if self.use_future:
            states.append("future")

        _dtype = inputs["current"]["bboxes"].dtype
        ref2world_rt = inputs["current"]["car_poses"][0]
        world2ref_rt = np.linalg.inv(ref2world_rt).astype(_dtype)
        veh2world = np.concatenate([inputs[state]["car_poses"] for state in states], axis=0)
        veh2ref = world2ref_rt @ veh2world
        # vx,vy,acc_x,acc_y,yaw[2],yaw_rate[2],whlag,whlagspd,vehspd,lgta,chassis_yawrate
        ego_motion = np.concatenate([inputs[state]["ego_motion"] for state in states], axis=0)

        # xyz, lwh, yaw, class, whlag, whlagspd, vxvy, acc_x, acc_y, yaw_rate
        if "length" not in inputs[states[0]]["ego_box"][0]:
            logger.info(
                "Warning: 'length' not found in ego_box, using default ET5 length for subclip_id: %s",
                inputs["future-all-meta"][0]["meta"]["subclip_id"],
            )
        xyzlwhyc_pad = np.ones((ego_motion.shape[0], 8)) * [
            0,
            0,
            0,
            inputs[states[0]]["ego_box"][0].get("length", ET5_length),
            inputs[states[0]]["ego_box"][0].get("width_w_mirror", ET5_width_w_mirror),
            1.7,
            0,
            1,
        ]  # TODO: update ego car size
        ego_bbox = np.concatenate([xyzlwhyc_pad, ego_motion[:, [6, 7, 0, 1, 2, 3, 5]]], axis=1)
        # TODO: remind to add pad logic while using padding history/future frames.

        if self.align:
            vel_align = (veh2ref[:, 0:2, 0:2] @ ego_bbox[:, [10, 11], None]).squeeze(axis=-1)
            acc_align = (veh2ref[:, 0:2, 0:2] @ ego_bbox[:, [12, 13], None]).squeeze(axis=-1)
            yaw_align = np.arctan2(veh2ref[:, 1, 0], veh2ref[:, 0, 0])
            ego_pose_homo = np.tile(np.array([0, 0, 0, 1]), (veh2ref.shape[0], 1))
            ego_pose_align = (veh2ref @ ego_pose_homo[..., None])[:, 0:3].squeeze(axis=-1)
            ego_bbox[:, :3] = ego_pose_align
            ego_bbox[:, 6] = yaw_align
            ego_bbox[:, [10, 11]] = vel_align
            ego_bbox[:, [12, 13]] = acc_align
        ego_padding_mask = np.zeros((ego_bbox.shape[0],))

        start_id = 0
        for state in states:
            frame_len = len(inputs[state]["car_poses"])
            inputs[state]["egos_padding_mask"] = ego_padding_mask[start_id : (start_id + frame_len)].tolist()
            for frame_idx in range(frame_len):
                if inputs[state]["scene_type"][frame_idx] == "pad":
                    inputs[state]["egos_padding_mask"][frame_idx] = 1.0
            inputs[state]["egos"] = ego_bbox[start_id : (start_id + frame_len)]
            start_id += frame_len

        return inputs


class PlannerAlignToRef(BaseTransform):  # pylint: disable=too-few-public-methods
    """Align Dynamic/Static object bbox to current frame. For E2E planner."""

    def __init__(
        self,
        states,
        obj_keys,
        velocity_transform_keys,
        yaw_transform_keys,
        index_dict={"default": (0, 3, 6)},
        align=True,
        use_gpu: bool = False,
    ):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.align = align
        self.states = states
        self.keys = obj_keys
        self.velocity_transform_keys = velocity_transform_keys
        self.yaw_transform_keys = yaw_transform_keys
        for box_key in self.keys:
            if box_key not in index_dict and "default" in index_dict:
                index_dict.update({box_key: index_dict["default"]})
        index_dict.pop("default", None)
        self.index_dict = index_dict

    def __call__(self, inputs):
        """Align to current frame."""
        ref2world_rt = inputs["current"]["car_poses"][0]
        world2ref_rt = np.linalg.inv(ref2world_rt)
        veh2world_frm = np.concatenate([inputs[state]["car_poses"] for state in self.states])
        vech2ref_frm = world2ref_rt @ veh2world_frm
        begin = 0
        for state in self.states:
            nfrm = len(inputs[state]["car_poses"])
            inputs[state]["hist2curr_trans"] = vech2ref_frm[begin : begin + nfrm]
            begin += nfrm

        return inputs


class PlannerGenStaticTransMat(BaseTransform):  # pylint: disable=too-few-public-methods
    """Align Dynamic/Static object bbox to current frame. For E2E planner."""

    def __init__(
        self,
        static_keys=("road_detection", "atlas", "road_post"),
        use_gpu: bool = False,
    ):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.static_keys = static_keys

    def __call__(self, inputs):
        """Align to current frame."""
        ref2world_rt = inputs["current"]["car_poses"][0]
        world2ref_rt = np.linalg.inv(ref2world_rt)

        static_sensor_carposes = inputs["current"]["delta_ts_carpose"][0]

        static_corres_veh2world_frm = np.concatenate(
            [static_sensor_carposes[key].reshape(1, 4, 4) for key in self.static_keys]
        )
        static_corres_veh2ref_frm = world2ref_rt @ static_corres_veh2world_frm

        for key, veh2ref in zip(self.static_keys, static_corres_veh2ref_frm):
            inputs["current"][f"{key}_veh2ref"] = veh2ref

        return inputs


class PlannerShufflePadBox(BaseTransform):  # pylint: disable=too-few-public-methods
    """Shuffle dynamic&static box order."""

    def __init__(self, box_key, num_pad_box, shuffle, use_gpu=False):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.shuffle = shuffle
        self.box_key = box_key
        self.num_pad_box = num_pad_box

    def _select_closest_bboxes(self, bboxes):
        """Select closest num_pad_box bboxes."""
        distances = np.linalg.norm(bboxes[:, :2], axis=1)
        sorted_indices = np.argsort(distances)
        selected_indices = sorted_indices[: self.num_pad_box]
        selected_bboxes = bboxes[selected_indices]
        return selected_bboxes

    def __call__(self, inputs):
        """Only align History Det&GT bbox to current frame."""
        states = ["history", "current"]

        for state in states:
            if self.box_key not in inputs[state]:
                continue
            boxes = inputs[state][self.box_key]
            box_dim = boxes.shape[1]
            bboxes_splits = inputs[state][f"{self.box_key}_splits"]
            bboxes_list = np.split(boxes, np.cumsum(bboxes_splits))[:-1]

            t_h = len(bboxes_list)
            reordered_padded_boxes = np.full((t_h, self.num_pad_box, box_dim), -1.0, dtype=boxes.dtype)
            full_padding_mask = np.ones((t_h, self.num_pad_box), dtype=bool)
            for t in range(t_h):
                bboxes = bboxes_list[t]
                if bboxes.shape[0] > self.num_pad_box:  # number of bboxes larger than pad box num
                    bboxes = self._select_closest_bboxes(bboxes)
                if self.shuffle:
                    bboxes = np.random.permutation(bboxes)

                reordered_padded_boxes[t, : bboxes.shape[0]] = bboxes
                full_padding_mask[t, : bboxes.shape[0]] = False

            inputs[state][self.box_key] = reordered_padded_boxes
            inputs[state][f"{self.box_key}_padding_mask"] = full_padding_mask

        return inputs


class PlannerShufflePadPolyline2D(BaseTransform):  # pylint: disable=too-few-public-methods
    """Shuffle and pad polyline."""

    def __init__(self, padded_length, padded_num, type_dim=1, shuffle=False, use_gpu=False):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.padded_length = padded_length
        self.padded_num = padded_num
        self.shuffle = shuffle
        self.type_dim = type_dim

    def _format_inputs(self, inputs):
        raise NotImplementedError("Must implement this method for specified input!")

    def _group_into_padded_polylines(self, inputs):
        polylines, line_types = self._format_inputs(inputs)
        line_idxs = list(range(len(polylines)))
        if self.shuffle:
            random.shuffle(line_idxs)
        # segment lines
        line_segments = []
        raw_polygon_idxs = []
        for idx in line_idxs:
            len_line = len(polylines[idx])
            if len_line <= self.padded_length:
                line_segments.append((polylines[idx], line_types[idx]))
                raw_polygon_idxs.append(idx)
            else:
                nseg = math.ceil(len_line / self.padded_length)
                split_idxs = np.arange(1, nseg) * self.padded_length
                splits = np.split(polylines[idx], split_idxs)
                line_segments.extend(zip(splits, [line_types[idx]] * len(splits)))
                raw_polygon_idxs.extend([idx] * len(splits))
        # sort lines
        sorted_res = sorted(enumerate(line_segments), key=lambda x: np.abs(x[1][0][len(x[1][0]) // 2]).sum())
        sorted_idxs, line_segments = zip(*sorted_res) if sorted_res else ([], [])
        raw_polygon_idxs = np.array(raw_polygon_idxs)[list(sorted_idxs)]
        # pad lines
        padded_lines = np.full((self.padded_num, self.padded_length, 2), -1, np.float32)
        padded_types = np.full((self.padded_num, self.padded_length, self.type_dim), -1, np.float32)
        keep_idxs = []
        for idx in range(min(self.padded_num, len(line_segments))):
            line, line_type = line_segments[idx]
            padded_lines[idx, 0 : len(line)] = line[:, 0:2]
            padded_types[idx, 0 : len(line)] = line_type
            keep_idxs.append(raw_polygon_idxs[idx])

        return padded_lines, padded_types, keep_idxs

    def __call__(self, inputs):
        """Only tranform current input into polylines format."""
        raise NotImplementedError("Must implement this method for specified input!")


class PlannerShufflePadPolyline2DLane(PlannerShufflePadPolyline2D):
    def __init__(
        self, padded_length, padded_num, type_dim=1, shuffle=False, fake_lane_aug=False, mode="train", use_gpu=False
    ):
        """Initialize."""
        super().__init__(padded_length, padded_num, type_dim, shuffle, use_gpu)
        self.fake_lane_aug = fake_lane_aug
        self.mode = mode

    def _format_inputs(self, inputs):
        lane_points = []
        keep_idx = []
        lane_attr = []
        for i, polyline in enumerate(inputs["current"]["lane_points"][0]):
            if len(polyline) == 0:
                continue
            lane_points.append(polyline)
            lane_attr.append(inputs["current"]["lane_attr"][0][i])
            keep_idx.append(i)
        lane_types = inputs["current"]["lane_types"][0][keep_idx]
        return lane_points, lane_types, lane_attr

    def __call__(self, inputs):
        """Only process lane in the current frame."""
        if "lane_points" not in inputs["current"]:
            return inputs
        padded_lines, padded_types, padded_attr, _ = self._group_into_padded_polylines(inputs)
        inputs["current"]["lane_points"] = padded_lines
        inputs["current"]["lane_types"] = padded_types.squeeze()
        inputs["current"]["lane_attr"] = padded_attr
        return inputs

    def _generate_fake_lane(self, polylines, line_types, line_attr):
        if random.random() < 0.2:
            line_number = len(polylines)
            rand_choice_idx = np.random.choice(line_number, 1)
            fake_points = np.copy(polylines[int(rand_choice_idx)])
            if len(fake_points) > 5:
                rand_points_num = np.random.randint(5, min(20, len(fake_points)))
                fake_points = fake_points[: int(rand_points_num)]
            start_x = np.random.uniform(15, 30)
            start_y = np.random.uniform(-2, 2)
            delta_x = fake_points[0][0] - start_x
            delta_y = fake_points[0][1] - start_y
            fake_points -= [delta_x, delta_y]
            y_sign = fake_points[0][1] > 0
            for i in range(len(fake_points)):
                cur_y_sign = fake_points[i][1] > 0
                if cur_y_sign != y_sign:
                    fake_points = fake_points[:i]
                    break
            polylines.append(fake_points)
            line_types = np.concatenate([line_types, np.array([1])])
            line_attr.append([[1, 0]] * len(fake_points))
        return polylines, line_types, line_attr

    def _group_into_padded_polylines(self, inputs):
        polylines, line_types, line_attr = self._format_inputs(inputs)

        # add fake road edge to make collision risk
        if self.fake_lane_aug and self.mode == "train":
            polylines, line_types, line_attr = self._generate_fake_lane(polylines, line_types, line_attr)

        line_idxs = list(range(len(polylines)))
        if self.shuffle:
            random.shuffle(line_idxs)
        # segment lines
        line_segments = []
        raw_polygon_idxs = []
        for idx in line_idxs:
            len_line = len(polylines[idx])
            if len_line <= self.padded_length:
                line_segments.append((polylines[idx], line_types[idx], line_attr[idx]))
                raw_polygon_idxs.append(idx)
            else:
                nseg = math.ceil(len_line / self.padded_length)
                split_idxs = np.arange(1, nseg) * self.padded_length
                splits = np.split(polylines[idx], split_idxs)
                attr_splits = np.split(line_attr[idx], split_idxs)
                line_segments.extend(zip(splits, [line_types[idx]] * len(splits), attr_splits))
                raw_polygon_idxs.extend([idx] * len(splits))
        # sort lines
        sorted_res = sorted(enumerate(line_segments), key=lambda x: np.abs(x[1][0][len(x[1][0]) // 2]).sum())
        sorted_idxs, line_segments = zip(*sorted_res) if sorted_res else ([], [])
        raw_polygon_idxs = np.array(raw_polygon_idxs)[list(sorted_idxs)]
        # pad lines
        padded_lines = np.full((self.padded_num, self.padded_length, 2), -1, np.float32)
        padded_types = np.full((self.padded_num, self.padded_length, self.type_dim), -1, np.float32)
        padded_attr = np.full((self.padded_num, self.padded_length, 2), -1, np.float32)
        keep_idxs = []
        for idx in range(min(self.padded_num, len(line_segments))):
            line, line_type, line_attr = line_segments[idx]
            padded_lines[idx, 0 : len(line)] = line[:, 0:2]
            padded_types[idx, 0 : len(line)] = line_type
            padded_attr[idx, 0 : len(line)] = line_attr
            keep_idxs.append(raw_polygon_idxs[idx])

        return padded_lines, padded_types, padded_attr, keep_idxs


class PlannerShufflePadPolyline2DAtlas(PlannerShufflePadPolyline2D):
    def __init__(self, padded_length, padded_num, keys_used, type_dim=1, shuffle=False, use_gpu=False):
        """Initialize."""
        super().__init__(padded_length, padded_num, type_dim, shuffle, use_gpu)
        self.keys_used = keys_used
        self.key2type = {key: type_id for type_id, key in enumerate(keys_used)}

    def _format_inputs(self, inputs):
        polygons_raw = []
        polygons_type_raw = []
        cur_atlas = inputs["current"]["atlas"][0]
        for key in self.keys_used:
            if not cur_atlas.get(key, []):
                continue
            polygons = [polygon[:, :2] for polygon in cur_atlas[key] if len(polygon) >= 3]
            if not polygons:
                continue
            polygons_raw.extend(polygons)
            polygons_type_raw.extend(len(polygons) * [self.key2type[key]])
        return polygons_raw, polygons_type_raw

    def __call__(self, inputs):
        """Only process atlas in the current frame."""
        if "atlas" not in inputs["current"]:
            return inputs
        padded_lines, padded_types, _ = self._group_into_padded_polylines(inputs)
        inputs["current"]["atlas_polygons"] = padded_lines
        inputs["current"]["atlas_polygons_type"] = padded_types

        return inputs


class PlannerShufflePadPolyline2DSdmap(PlannerShufflePadPolyline2D):
    def __init__(self, padded_length, padded_num, key_used="sdmap_geo", type_dim=1, shuffle=False, use_gpu=False):
        """Initialize."""
        super().__init__(padded_length, padded_num, type_dim, shuffle, use_gpu)
        assert key_used == "sdmap_geo", "Only support sdmap_geo format"
        self.key_used = key_used

    def _format_inputs(self, inputs):
        polylines = list(filter(lambda p: len(p) > 0, inputs["current"][self.key_used][0]))
        return polylines, [0] * len(polylines)

    def __call__(self, inputs):
        """Only process sdmap in the current frame."""
        if self.key_used not in inputs["current"]:
            return inputs
        padded_lines, padded_types, keep_idxs = self._group_into_padded_polylines(inputs)
        inputs["current"]["sdmap_polylines"] = padded_lines
        inputs["current"]["sdmap_polylines_type"] = padded_types.squeeze()
        inputs["current"]["filtered_sd_link_ids"] = inputs["current"]["sd_link_ids"][0][keep_idxs]
        return inputs


class PlannerPadTLD(BaseTransform):  # pylint: disable=too-few-public-methods
    def __init__(self, tld_dim, use_gpu=False):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.tld_dim = tld_dim

    def __call__(self, inputs):
        """Only process sdmap in the current frame."""
        if "tld" not in inputs["current"]:
            return inputs
        tld_padding = np.zeros((1, self.tld_dim))
        tld_padding_mask = np.array([1])  # invalid
        # original valid data shape is (12), original invalid data shape is (0,12)
        # tld expected shape is (1,12)
        if inputs["current"]["tld"].size > 1:
            tld_padding = np.expand_dims(inputs["current"]["tld"], axis=0)
            tld_padding_mask = np.array([0])  # valid
        inputs["current"]["tld"] = tld_padding
        inputs["current"]["tld_padding_mask"] = tld_padding_mask

        return inputs


class PlannerGenerateTracklet(BaseTransform):  # pylint: disable=too-few-public-methods
    """Shuffle and pad atlas."""

    def __init__(self, keys=("dynamic_dets",), track_id_idxes=(9,), use_gpu=False):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.keys = keys
        self.track_id_idxes = track_id_idxes

    def __call__(self, inputs):
        """Only process atlas in the current frame."""
        for key, track_id_idx in zip(self.keys, self.track_id_idxes):
            if key not in inputs["current"]:
                continue
            current_padding_masks = inputs["current"][key + "_padding_mask"]

            valid_idx = np.where(current_padding_masks == 0)[1]
            valid_track_ids = inputs["current"][key][0, valid_idx, track_id_idx]
            tracklet_history_padding = np.ones_like(inputs["history"][key + "_padding_mask"])
            tracklet_history_feature = np.zeros_like(inputs["history"][key])

            if len(valid_track_ids) > 0:
                history_data = inputs["history"][key]
                history_data[inputs["history"][key + "_padding_mask"]] = 0
                mask = valid_track_ids.astype(int)[:, None, None] == history_data[:, :, track_id_idx]
                indices = mask.nonzero()
                new_obj_idxes = valid_idx[indices[0]]
                valid_hits = history_data[indices[1], indices[2]]
                tracklet_history_feature[indices[1], new_obj_idxes] = valid_hits
                tracklet_history_padding[indices[1], new_obj_idxes] = 0

            inputs["history"][key] = tracklet_history_feature
            inputs["history"][key + "_padding_mask"] = tracklet_history_padding

        return inputs


class PlannerShufflePadPolygonAttr(BaseTransform):
    def __init__(
        self,
        use_gpu=False,
        select_dim=None,
        num_pad_poly=64,
        num_pad_attr=50,
        shuffle=True,
    ):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.num_pad_attr = num_pad_attr
        self.select_dim = select_dim
        self.num_pad_poly = num_pad_poly
        self.shuffle = shuffle

    def sort_and_truncate(self, poly):
        """Sort and truncate."""
        poly_pt_dist_sq = poly[:, 0] ** 2 + poly[:, 1] ** 2
        min_pt_idx = np.argmin(poly_pt_dist_sq)
        left_range = min_pt_idx
        right_range = len(poly) - min_pt_idx - 1
        if left_range > self.num_pad_poly // 2 and right_range > self.num_pad_poly // 2:
            return poly[min_pt_idx - self.num_pad_poly // 2 : min_pt_idx + self.num_pad_poly // 2]

        if left_range < right_range:  # implying left range must be smaller than half target length
            return poly[min_pt_idx - left_range : min_pt_idx - left_range + self.num_pad_poly]
        else:
            return poly[min_pt_idx + right_range + 1 - self.num_pad_poly : min_pt_idx + right_range + 1]

    def pad_box(self, attrs, poly_pts, poly_pts_split):
        """Pad box and attr."""
        dist_sq = attrs[:, 0] ** 2 + attrs[:, 1] ** 2
        sorted_indices = np.argsort(dist_sq)
        selected_indices = sorted_indices[: self.num_pad_attr]

        if self.shuffle:
            selected_indices = np.random.permutation(selected_indices)
        selected_attrs = attrs[selected_indices]
        poly_list = np.split(poly_pts, np.cumsum(poly_pts_split))[:-1]
        selected_poly = [poly_list[idx] for idx in selected_indices]

        result_attr_bboxes = np.concatenate(
            [
                selected_attrs,
                np.zeros((self.num_pad_attr - selected_attrs.shape[0], len(self.select_dim)), dtype=np.float32),
            ],
            axis=0,
        )
        result_attr_padding_mask = np.concatenate(
            [
                np.zeros((selected_attrs.shape[0],), dtype=np.bool),
                np.ones((self.num_pad_attr - selected_attrs.shape[0],), dtype=np.bool),
            ],
            axis=0,
        )
        result_poly_pts = np.zeros((self.num_pad_attr, self.num_pad_poly, 2), dtype=np.float32)
        result_poly_pts_padding_mask = np.ones((self.num_pad_attr, self.num_pad_poly), dtype=np.bool)

        attr_count = len(selected_attrs)

        for i in range(attr_count):
            poly_single = selected_poly[i]
            poly_single = self.sort_and_truncate(poly_single) if len(poly_single) > 0 else poly_single
            result_poly_pts[i, : poly_single.shape[0], :] = poly_single
            result_poly_pts_padding_mask[i, : poly_single.shape[0]] = False

        return (result_attr_bboxes, result_attr_padding_mask, result_poly_pts, result_poly_pts_padding_mask)


class PlannerStaticDetsPadBox(PlannerShufflePadPolygonAttr):
    def __init__(self, use_gpu=False, sod_dim=(), sod_poly_len=128, num_pad_box=191, shuffle=True):
        """Initialize."""
        super().__init__(
            use_gpu=use_gpu,
            select_dim=sod_dim,
            num_pad_poly=sod_poly_len,
            num_pad_attr=num_pad_box,
            shuffle=shuffle,
        )

    def __call__(self, inputs):
        """Only process atlas in the current frame."""
        state = "current"
        if (
            "static_dets" not in inputs[state]
            or "static_polys" not in inputs[state]
            or "static_poly_split" not in inputs[state]
        ):
            return inputs

        attrs = inputs[state]["static_dets"]
        poly_pts = inputs[state]["static_polys"][0]
        poly_pts_split = inputs[state]["static_poly_split"][0]

        (static_dets_bboxes, static_dets_padding_mask, sod_poly_pts, sod_poly_pts_padding_mask) = self.pad_box(
            attrs, poly_pts, poly_pts_split
        )

        inputs["current"]["sod_poly_boxes"] = static_dets_bboxes
        inputs["current"]["sod_poly_boxes_padding_mask"] = static_dets_padding_mask
        inputs["current"]["sod_poly_pts"] = sod_poly_pts
        inputs["current"]["sod_poly_pts_padding_mask"] = sod_poly_pts_padding_mask

        return inputs


class PlannerShufflePadPolyline2DDynamicGod(PlannerShufflePadPolygonAttr):
    def __init__(
        self,
        use_gpu=False,
        god_select_dim=(32, 33, 31, 29, 30, 35, 36, 37),
        god_poly_len=64,
        num_pad_box=50,
        shuffle=True,
    ):
        """Initialize."""
        super().__init__(
            use_gpu=use_gpu,
            select_dim=god_select_dim,
            num_pad_poly=god_poly_len,
            num_pad_attr=num_pad_box,
            shuffle=shuffle,
        )

    def __call__(self, inputs):
        """Only process atlas in the current frame."""
        state = "current"
        if "dynamic_gods" not in inputs[state]:
            return inputs

        all_d_god = np.concatenate(inputs[state]["dynamic_gods"], axis=-2)[:, self.select_dim]
        sod_poly_origin = inputs[state]["dynamic_gods_polys"][0]
        sod_poly_split_origin = inputs[state]["dynamic_gods_polys_split"][0]

        (god_attr_bboxes, god_attr_padding_mask, god_poly_pts, god_poly_pts_padding_mask) = self.pad_box(
            all_d_god, sod_poly_origin, sod_poly_split_origin
        )
        inputs["current"]["god_attrs"] = god_attr_bboxes
        inputs["current"]["god_attr_padding_mask"] = god_attr_padding_mask

        inputs["current"]["god_poly_pts"] = god_poly_pts
        inputs["current"]["god_poly_pts_padding_mask"] = god_poly_pts_padding_mask

        return inputs


class PlannerShufflePadPolyline2DNaviLine(PlannerShufflePadPolyline2D):
    def __init__(
        self,
        padded_length,
        padded_num,
        type_dim=1,
        num_navi_line_in_trace=6,
        trace_mode=False,
        shuffle=False,
        use_gpu=False,
    ):
        """Initialize."""
        super().__init__(padded_length, padded_num, type_dim, shuffle, use_gpu)
        self.num_navi_line_in_trace = num_navi_line_in_trace
        self.trace_mode = trace_mode

    def __call__(self, inputs):
        """Only process lane in the current frame."""
        if not self.trace_mode:
            inputs["current"]["navi_line_points"] = np.full(
                (self.padded_num, self.padded_length, 2), fill_value=-1, dtype=np.float32
            )
            inputs["current"]["navi_line_types"] = np.full(
                (self.padded_num, self.padded_length), fill_value=-1, dtype=np.float32
            )
            inputs["current"]["navi_lane_tld"] = np.full((self.padded_num, 3), fill_value=-1, dtype=np.float32)
            inputs["current"]["navi_lane_stoppoints"] = np.full(
                (self.padded_num, self.padded_length, 2), fill_value=-1, dtype=np.float32
            )
        else:
            inputs["current"]["navi_line_points"] = np.full(
                (self.num_navi_line_in_trace, self.padded_length, 2), fill_value=-1, dtype=np.float32
            )
            inputs["current"]["navi_line_types"] = np.full(
                (self.num_navi_line_in_trace, self.padded_length), fill_value=-1, dtype=np.float32
            )
            inputs["current"]["navi_lane_tld"] = np.full(
                (self.num_navi_line_in_trace, 3), fill_value=-1, dtype=np.float32
            )
            inputs["current"]["navi_lane_stoppoints"] = np.full(
                (self.num_navi_line_in_trace, self.padded_length, 2), fill_value=-1, dtype=np.float32
            )
        return inputs


class PlannerShufflePadPolyline2DNaviPath(PlannerShufflePadPolyline2D):
    def __init__(self, padded_length, padded_num, point_intervals=1, type_dim=1, shuffle=False, use_gpu=False):
        """Initialize."""
        super().__init__(padded_length, padded_num, type_dim, shuffle, use_gpu)
        self.point_intervals = point_intervals

    def _format_inputs(self, inputs):
        lane_points = []
        keep_idx = []
        for i, polyline in enumerate(inputs["current"]["navi_path_points"][0]):
            if len(polyline) == 0:
                continue
            lane_points.append(polyline)
            keep_idx.append(i)
        lane_types = inputs["current"]["navi_path_types"][0][keep_idx]
        if self.point_intervals > 0:
            lane_points = [self._downsample(points) for points in lane_points]
        return lane_points, lane_types

    def _downsample(self, points):
        if len(points) < 2:
            raise ValueError("At least two points are required for interpolation.")

        if self.point_intervals <= 0:
            raise ValueError("Interval must be a positive number.")

        # compute segment length
        segment_lengths = np.sqrt(np.sum(np.diff(points, axis=0) ** 2, axis=1))
        cumulative_distances = np.insert(np.cumsum(segment_lengths), 0, 0)

        total_length = cumulative_distances[-1]

        target_distances = np.arange(0, total_length, self.point_intervals)

        segment_indices = np.searchsorted(cumulative_distances, target_distances, side="right") - 1
        segment_lengths_at_indices = np.maximum(segment_lengths[segment_indices], 1e-10)
        segment_start_distances = cumulative_distances[segment_indices]
        proportions = (target_distances - segment_start_distances) / segment_lengths_at_indices

        downsample_points = points[segment_indices] + proportions[:, np.newaxis] * (
            points[segment_indices + 1] - points[segment_indices]
        )
        return downsample_points

    def __call__(self, inputs):
        """Only process lane in the current frame."""
        if "navi_path_points" not in inputs["current"]:
            return inputs
        padded_lines, padded_types, indexs = self._group_into_padded_polylines(inputs)
        inputs["current"]["navi_path_points"] = padded_lines
        inputs["current"]["navi_path_types"] = padded_types.squeeze()

        for key in ["navi_path_tld", "navi_path_stoppoints", "navi_path_speed_limit"]:
            if key in inputs["current"]:
                if key == "navi_path_tld":
                    padded_element = np.full((self.padded_num, 3), 0, np.float32)
                    for i, idx in enumerate(indexs):
                        if idx < len(inputs["current"][key][0]):
                            padded_element[i] = inputs["current"][key][0][idx][:3]
                elif key == "navi_path_stoppoints":
                    padded_element = np.full((self.padded_num, self.padded_length, 2), 0, np.float32)
                    for i, idx in enumerate(indexs):
                        if idx < len(inputs["current"][key][0]):
                            valid_length = len(inputs["current"][key][0][idx])
                            if valid_length > 0:
                                valid_length = min(valid_length, self.padded_length)
                                padded_element[i][:valid_length] = inputs["current"][key][0][idx][:valid_length]
                elif key == "navi_path_speed_limit":
                    padded_element = np.full((self.padded_num, self.padded_length, 2), 0, np.float32)
                    for i, idx in enumerate(indexs):
                        if idx < len(inputs["current"][key][0]):
                            current_idx = 0
                            for j, speed_limit in enumerate(inputs["current"][key][0][idx]):
                                valid_points_num = int(speed_limit[2])
                                end_idx = min(current_idx + valid_points_num, self.padded_length)
                                padded_element[i][current_idx:end_idx, 0] = speed_limit[0]
                                padded_element[i][current_idx:end_idx, 1] = speed_limit[1]
                                current_idx = end_idx
                else:
                    raise NotImplementedError
                inputs["current"][key] = padded_element
        return inputs


class PlannerGenerateAlignedGT(BaseTransform):
    """PlannerGenerateAlignedGT."""

    def __init__(self, ego_box_feat_dims, use_gpu=False):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)

        self.ego_box_feat_dims = ego_box_feat_dims

    @staticmethod
    def interpolate_fut_pred(fut_timestamps, fut_pred_gt, fut_pred_mask, target_timestamps, interp_type="linear"):
        """Interpolate future prediction to target timestamps.

        Args:
            fut_timestamps (numpy.ndarray): shape (N,)
            fut_pred_gt (numpy.ndarray): shape (1, 1, N, dim)
            fut_pred_mask (numpy.ndarray): shape (1, 1, N)
            target_timestamps (numpy.ndarray): shape (M,)

        Returns:
            numpy.ndarray: shape (1, 1, M, dim)
        """
        # 1. 先去掉(1,1)两个维度 => (N, dim) and (N,)
        fut_pred_gt_flat = fut_pred_gt[0, 0]  # shape (N, dim)
        fut_pred_mask_flat = fut_pred_mask[0, 0]  # shape (N,)

        # 2. 取有效值
        valid_idx = fut_pred_mask_flat == 1
        valid_timestamps = fut_timestamps[valid_idx]  # shape (num_valid,)
        valid_pred = fut_pred_gt_flat[valid_idx, :]  # shape (num_valid, dim)

        # 3. 如果有效点数 < 2，没办法插值，只能返回原值
        if valid_timestamps.shape[0] < 2:
            return fut_pred_gt

        # 4. 一次性对所有 dim 通道进行插值
        f_interp = interp1d(
            valid_timestamps,
            valid_pred,  # shape (num_valid, dim)
            axis=0,  # 时间轴在 axis=0，dim 通道在 axis=1
            kind=interp_type,
            bounds_error=False,
            fill_value="extrapolate",
        )
        # 输出形状 (M, dim)
        interp_results = f_interp(target_timestamps)

        # 5. 恢复形状 => (1, 1, M, dim)
        interp_pred = interp_results[None, None, :, :]

        return interp_pred

    @staticmethod
    def align_general_boxes(
        bboxes,
        hist2curr_trans,
        bboxes_padding_mask,
        xyz_range_idx=None,  # (0, 3),
        yaw_idx=None,  # 6,
        vel_idx=None,  # (10, 12),
        acc_idx=None,
    ):
        """Align box from history to current."""
        # flatten bboxes to [B * T, n_t, F]
        batch_size = bboxes.shape[0]
        n_t = bboxes.shape[2]
        f_dim = bboxes.shape[-1]

        bboxes = bboxes.reshape(-1, bboxes.shape[-2], bboxes.shape[-1])
        bboxes_padding_mask = bboxes_padding_mask.reshape(-1, bboxes_padding_mask.shape[-1])
        bboxes_xyz_homo = np.concatenate(
            (
                bboxes[:, :, xyz_range_idx[0] : xyz_range_idx[1]],
                np.ones((bboxes.shape[0], bboxes.shape[1], 1), dtype=bboxes.dtype),
            ),
            axis=2,
        )

        # flatten hist2curr to [B * T, 4, 4]
        hist2curr_trans = hist2curr_trans.reshape(-1, hist2curr_trans.shape[-2], hist2curr_trans.shape[-1])
        hist2curr_trans_transpose = hist2curr_trans.transpose(0, 2, 1)
        bboxes_xyz_homo = np.einsum("bij,bjk->bik", bboxes_xyz_homo, hist2curr_trans_transpose)

        bboxes_padding_mask_bool = np.abs(bboxes_padding_mask) > 0
        bboxes_padding_mask_bool = bboxes_padding_mask_bool[:, :, np.newaxis]
        bboxes_xyz_homo = np.where(bboxes_padding_mask_bool, 0, bboxes_xyz_homo)

        if yaw_idx is not None:
            aligned_yaw = (
                bboxes[:, :, yaw_idx : yaw_idx + 1]
                + np.arctan2(hist2curr_trans[:, 1, 0:1], hist2curr_trans[:, 0, 0:1])[:, np.newaxis]
            )
            aligned_yaw = np.where(bboxes_padding_mask_bool, 0, aligned_yaw)

        if vel_idx is not None:
            aligned_vel = np.einsum(
                "bij,bjk->bik", bboxes[:, :, vel_idx[0] : vel_idx[1]], hist2curr_trans_transpose[:, 0:2, 0:2]
            )
            aligned_vel = np.where(bboxes_padding_mask_bool, 0, aligned_vel)

        if acc_idx is not None:
            aligned_acc = np.einsum(
                "bij,bjk->bik", bboxes[:, :, acc_idx[0] : acc_idx[1]], hist2curr_trans_transpose[:, 0:2, 0:2]
            )
            aligned_acc = np.where(bboxes_padding_mask_bool, 0, aligned_acc)

        bboxes = np.concatenate(
            [
                bboxes[:, :, : xyz_range_idx[0]],
                bboxes_xyz_homo[:, :, xyz_range_idx[0] : xyz_range_idx[1]],  # xyz
                bboxes[:, :, xyz_range_idx[1] : f_dim],
            ],
            axis=2,
        )

        if yaw_idx is not None:
            bboxes = np.concatenate(
                [
                    bboxes[:, :, :yaw_idx],
                    aligned_yaw,
                    bboxes[:, :, yaw_idx + 1 : f_dim],
                ],
                axis=2,
            )

        if vel_idx is not None:
            bboxes = np.concatenate(
                [
                    bboxes[:, :, : vel_idx[0]],
                    aligned_vel,
                    bboxes[:, :, vel_idx[1] : f_dim],
                ],
                axis=2,
            )

        if acc_idx is not None:
            bboxes = np.concatenate(
                [
                    bboxes[:, :, : acc_idx[0]],
                    aligned_acc,
                    bboxes[:, :, acc_idx[1] : f_dim],
                ],
                axis=2,
            )
        bboxes = bboxes.reshape(batch_size, -1, n_t, f_dim)
        return bboxes

    def __call__(self, inputs):
        """Only process lane in the current frame."""
        if "trans" not in inputs.keys():
            inputs["trans"] = {}

        carposes = np.vstack(
            [
                inputs["history"]["car_poses"],
                inputs["current"]["car_poses"],
            ]
        )[np.newaxis, ...]
        inputs["trans"]["carposes"] = carposes

        eye_matrix = np.eye(4)[None]
        hist2curr_trans = np.vstack(
            [
                inputs["history"]["hist2curr_trans"],  # T-1, 4, 4
                eye_matrix,  # 1, 4, 4
            ]
        )[np.newaxis, ...]
        inputs["trans"]["hist2curr_trans"] = hist2curr_trans

        future2curr_trans = np.vstack(
            [
                inputs["future"]["hist2curr_trans"],  # T-1, 4, 4
                eye_matrix,  # 1, 4, 4
            ]
        )[np.newaxis, ...]
        inputs["trans"]["future2curr_trans"] = future2curr_trans

        egos = np.vstack(
            [
                inputs["history"]["egos"][..., self.ego_box_feat_dims],  # [T-1, D]
                inputs["current"]["egos"][..., self.ego_box_feat_dims],  # [1, D]
            ]
        )[np.newaxis, :, np.newaxis]
        inputs["trans"]["egos"] = egos

        egos_padding_mask = np.stack(inputs["history"]["egos_padding_mask"] + inputs["current"]["egos_padding_mask"])[
            np.newaxis, :, np.newaxis
        ]
        inputs["trans"]["egos_padding_mask"] = egos_padding_mask

        bboxes = np.vstack(
            [
                inputs["history"]["dynamic_dets"],  # T-1, n_t, D
                inputs["current"]["dynamic_dets"],  # 1, n_t, D
            ]
        )[np.newaxis, ...]
        inputs["trans"]["bboxes"] = bboxes

        bboxes_track_id = np.vstack(
            [
                inputs["history"]["dynamic_dets"][..., 9],  # T-1, n_t
                inputs["current"]["dynamic_dets"][..., 9],  # 1, n_t
            ]
        )[np.newaxis, ...]
        inputs["trans"]["bboxes_track_id"] = bboxes_track_id

        bboxes_padding_mask = np.vstack(
            [
                inputs["history"]["dynamic_dets_padding_mask"],  # T-1, n_t
                inputs["current"]["dynamic_dets_padding_mask"],  # 1, n_t
            ]
        )[np.newaxis, ...]
        inputs["trans"]["bboxes_padding_mask"] = bboxes_padding_mask

        inputs["trans"]["egos_pred_gt"] = inputs["current"]["egos_pred_gt"][np.newaxis, ...]
        inputs["trans"]["egos_pred_mask"] = inputs["current"]["egos_pred_mask"][np.newaxis, ...]
        inputs["trans"]["ego_vel_pred_gt"] = inputs["current"]["ego_vel_pred_gt"][np.newaxis, ...]
        inputs["trans"]["ego_acc_pred_gt"] = inputs["current"]["ego_acc_pred_gt"][np.newaxis, ...]

        inputs["trans"]["bboxes_pred_gt"] = inputs["current"]["dynamic_dets_pred_gt"][np.newaxis, ...]
        inputs["trans"]["bboxes_pred_mask"] = inputs["current"]["dynamic_dets_pred_mask"][np.newaxis, ...]
        inputs["trans"]["bboxes_det_pred_full_info_gt"] = inputs["current"]["dynamic_dets_pred_full_info_gt"][
            np.newaxis, ...
        ]

        # Align box
        bboxes = self.align_general_boxes(
            bboxes, hist2curr_trans, bboxes_padding_mask, xyz_range_idx=(0, 3), yaw_idx=6, vel_idx=(10, 12)
        )

        egos = self.align_general_boxes(
            egos,
            hist2curr_trans,
            egos_padding_mask,
            xyz_range_idx=(0, 3),
            yaw_idx=6,
            vel_idx=(10, 12),
            acc_idx=(12, 14),
        )

        # gt transform
        batch_size = inputs["trans"]["egos_pred_gt"].shape[0]
        ego_pred_t = inputs["trans"]["egos_pred_gt"].shape[2]
        ego_pred_pos_yaw_vel = np.concatenate(
            (
                inputs["trans"]["egos_pred_gt"].transpose(0, 2, 1, 3),
                np.zeros((batch_size, ego_pred_t, 1, 2), dtype=inputs["trans"]["egos_pred_gt"].dtype),
                inputs["trans"]["ego_vel_pred_gt"][:, :, np.newaxis],
                inputs["trans"]["ego_acc_pred_gt"][:, :, np.newaxis],
            ),
            axis=-1,
        )

        ego_pred_pos_yaw_vel = self.align_general_boxes(
            ego_pred_pos_yaw_vel,
            future2curr_trans[:, :-1, :, :],
            (1 - inputs["trans"]["egos_pred_mask"]).transpose(0, 2, 1),
            xyz_range_idx=(0, 3),
            yaw_idx=3,
            vel_idx=(4, 6),
            acc_idx=(6, 8),
        )
        ego_pred_pos_yaw_vel = ego_pred_pos_yaw_vel.transpose(0, 2, 1, 3)
        egos_pred_gt = ego_pred_pos_yaw_vel[:, :, :, :2]
        egos_heading_gt = ego_pred_pos_yaw_vel[:, :, :, 3:4]
        ego_vel_pred_gt = ego_pred_pos_yaw_vel[:, :, :, 4:6].squeeze(1)
        ego_acc_pred_gt = ego_pred_pos_yaw_vel[:, :, :, 6:8].squeeze(1)

        fut_pred_mask = inputs["trans"]["egos_pred_mask"]

        if inputs["current"]["aligned_trajectory"][0] is not None:
            trans_egos_pred_gt = egos_pred_gt[0, 0]
            aligned_trajectory = inputs["current"]["aligned_trajectory"][0]
            # if aligned_trajectory.shape[0] > 35:
            #     print("aligned_trajectory.shape[0] = ",aligned_trajectory.shape[0])
            #     print("len(inputs[\"future-all-meta\"]) = ",len(inputs["future-all-meta"]))
            align_len = aligned_trajectory.shape[0]
            raw_len = trans_egos_pred_gt.shape[0]
            if align_len < raw_len:
                trans_egos_pred_gt[:align_len, 0:2] = aligned_trajectory[:align_len, 0:2]
                trans_egos_pred_gt[align_len:, 0:2] = 0
                fut_pred_mask[:, :, align_len:] = 0
            else:
                trans_egos_pred_gt = aligned_trajectory[:raw_len, 0:2]
            egos_pred_gt[0, 0] = trans_egos_pred_gt

        bboxes_nt = inputs["trans"]["bboxes_pred_gt"].shape[1]
        bboxes_gt = np.concatenate(
            (
                inputs["trans"]["bboxes_pred_gt"].transpose(0, 2, 1, 3),
                np.zeros((batch_size, ego_pred_t, bboxes_nt, 1), dtype=inputs["trans"]["bboxes_pred_gt"].dtype),
            ),
            axis=-1,
        )
        bboxes_gt = self.align_general_boxes(
            bboxes_gt,
            future2curr_trans[:, :-1, :, :],
            (1 - inputs["trans"]["bboxes_pred_mask"]).transpose(0, 2, 1),
            xyz_range_idx=(0, 3),
            yaw_idx=None,
            vel_idx=None,
        )
        bboxes_pred_gt = bboxes_gt.transpose(0, 2, 1, 3)[:, :, :, :2]
        bboxes_det_pred_full_info_gt = self.align_general_boxes(
            inputs["trans"]["bboxes_det_pred_full_info_gt"].transpose(0, 2, 1, 3),
            future2curr_trans[:, :-1, :, :],
            (1 - inputs["trans"]["bboxes_pred_mask"]).transpose(0, 2, 1),
            xyz_range_idx=(0, 3),
            yaw_idx=6,
            vel_idx=(10, 12),
        ).transpose(0, 2, 1, 3)

        cur_timestamps = inputs["current"]["timestamps"]
        fut_timestamps = inputs["future"]["timestamps"]
        fut_timestamps = np.concatenate([cur_timestamps, fut_timestamps], axis=0)
        # fut_pred_mask = inputs["trans"]["egos_pred_mask"]
        fut_pred_mask = np.concatenate([np.ones((1, 1, 1)), fut_pred_mask], axis=2)
        fut_pred_gt_pos = np.concatenate([np.zeros((1, 1, 1, 2)), egos_pred_gt], axis=2)
        fut_pred_gt_heading = np.concatenate([np.zeros((1, 1, 1, 1)), egos_heading_gt], axis=2)
        fut_pred_gt_vel = np.concatenate([egos[:, -1:, :, 10:12].squeeze(1), ego_vel_pred_gt], axis=1)
        fut_pred_gt_acc = np.concatenate([egos[:, -1:, :, 12:14].squeeze(1), ego_acc_pred_gt], axis=1)

        target_timestamps = np.arange(cur_timestamps[0], cur_timestamps[0] + egos_pred_gt.shape[2] * 0.2 + 0.01, 0.2)
        last_nonzero_index = np.nonzero(fut_pred_mask[0, 0])[0][-1] if np.any(fut_pred_mask[0, 0]) else 0
        last_timestamp = fut_timestamps[last_nonzero_index]
        target_time_mask = target_timestamps <= last_timestamp

        flipped_fut_pred_mask = np.flip(fut_pred_mask, axis=-1)
        cummax_result = np.maximum.accumulate(flipped_fut_pred_mask, axis=-1)
        interp_fut_pred_mask = np.flip(cummax_result, axis=-1)
        interp_fut_pred_mask = interp_fut_pred_mask * target_time_mask[None, None, ...]

        egos_pred_gt = (
            self.interpolate_fut_pred(fut_timestamps, fut_pred_gt_pos, fut_pred_mask, target_timestamps)[:, :, 1:, :]
            * interp_fut_pred_mask[:, :, 1:, None]
        )
        egos_heading_gt = (
            self.interpolate_fut_pred(fut_timestamps, fut_pred_gt_heading, fut_pred_mask, target_timestamps)[
                :, :, 1:, :
            ]
            * interp_fut_pred_mask[:, :, 1:, None]
        )
        ego_vel_pred_gt = (
            self.interpolate_fut_pred(fut_timestamps, fut_pred_gt_vel[None, ...], fut_pred_mask, target_timestamps)[
                :, :, 1:, :
            ]
            * interp_fut_pred_mask[:, :, 1:, None]
        )
        ego_acc_pred_gt = (
            self.interpolate_fut_pred(fut_timestamps, fut_pred_gt_acc[None, ...], fut_pred_mask, target_timestamps)[
                :, :, 1:, :
            ]
            * interp_fut_pred_mask[:, :, 1:, None]
        )

        inputs["trans"]["bboxes"] = bboxes
        inputs["trans"]["egos"] = egos
        inputs["trans"]["bboxes_pred_gt"] = bboxes_pred_gt
        inputs["trans"]["bboxes_det_pred_full_info_gt"] = bboxes_det_pred_full_info_gt
        inputs["trans"]["egos_pred_gt"] = egos_pred_gt
        inputs["trans"]["egos_heading_gt"] = egos_heading_gt
        inputs["trans"]["ego_vel_pred_gt"] = ego_vel_pred_gt
        inputs["trans"]["ego_acc_pred_gt"] = ego_acc_pred_gt[:, 0]

        inputs["trans"]["egos_pred_mask"] = interp_fut_pred_mask[:, :, 1:].astype(np.bool)
        return inputs


class PlannerEgoDeltaSpeedAug(BaseTransform):
    """PlannerEgoDeltaSpeedAug."""

    def __init__(self, min_v_aug=0.5, max_v_aug=0.3, vx_idx=10, train=False, use_gpu=False):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.min_v_aug = min_v_aug
        self.max_v_aug = max_v_aug
        self.vx_idx = vx_idx
        self.train = train

    def __call__(self, inputs):
        """Only process lane in the current frame."""
        vx_current = inputs["current"]["egos"][:, self.vx_idx]
        min_v = vx_current - self.min_v_aug * vx_current  # min = vx - 50% * vx
        max_v = vx_current + self.max_v_aug * vx_current  # max = vx + 30% * vx
        v_aug = np.random.rand(*vx_current.shape) * (max_v - min_v) + min_v
        if not self.train:
            v_aug = vx_current
        delta_v = vx_current - v_aug
        inputs["current"]["egos"][:, self.vx_idx] = v_aug
        inputs["current"]["egos_delta_v"] = delta_v
        inputs["history"]["egos_delta_v"] = np.zeros_like(inputs["history"]["egos"][:, self.vx_idx])

        return inputs


class PlannerEgoFutureTruncate(BaseTransform):
    """PlannerEgoFutureTruncate."""

    def __init__(self, ego_future_frame_num=35):
        """Init."""
        super().__init__()

        self.ego_future_frame_num = ego_future_frame_num

    def __call__(self, inputs):
        """Call."""
        inputs["current"]["egos_pred_gt"] = inputs["current"]["egos_pred_gt"][..., : self.ego_future_frame_num, :]
        inputs["current"]["egos_pred_mask"] = inputs["current"]["egos_pred_mask"][..., : self.ego_future_frame_num]
        inputs["current"]["egos_yaw_pred_gt"] = inputs["current"]["egos_yaw_pred_gt"][
            ..., : self.ego_future_frame_num, :
        ]
        inputs["current"]["ego_vel_pred_gt"] = inputs["current"]["ego_vel_pred_gt"][..., : self.ego_future_frame_num, :]
        inputs["current"]["ego_steering_wheel_pred_gt"] = inputs["current"]["ego_steering_wheel_pred_gt"][
            ..., : self.ego_future_frame_num
        ]
        inputs["current"]["ego_acc_pred_gt"] = inputs["current"]["ego_acc_pred_gt"][..., : self.ego_future_frame_num, :]
        inputs["current"]["ego_yaw_rate_pred_gt"] = inputs["current"]["ego_yaw_rate_pred_gt"][
            ..., : self.ego_future_frame_num
        ]
        if "egos_gt_gear" in inputs.keys():
            inputs["egos_gt_gear"] = inputs["egos_gt_gear"][..., : self.ego_future_frame_num]

        inputs["trans"]["egos_pred_gt"] = inputs["trans"]["egos_pred_gt"][..., : self.ego_future_frame_num, :]
        inputs["trans"]["egos_pred_mask"] = inputs["trans"]["egos_pred_mask"][..., : self.ego_future_frame_num]
        inputs["trans"]["ego_vel_pred_gt"] = inputs["trans"]["ego_vel_pred_gt"][..., : self.ego_future_frame_num, :]
        inputs["trans"]["egos_heading_gt"] = inputs["trans"]["egos_heading_gt"][..., : self.ego_future_frame_num, :]

        return inputs


class EgoGearGen(BaseTransform):  # pylint: disable=too-few-public-methods
    """PaddingTrajectoryByGear."""

    GEAR_N = 0
    GEAR_D = 1
    GEAR_R = 2
    GEAR_P = 3

    def __init__(
        self,
        use_gpu: bool = False,
        output_gear_shift_point: bool = False,
        clamp_gt_by_gear_shift_point: bool = False,
    ) -> None:
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.output_gear_shift_point = output_gear_shift_point
        self.clamp_gt = clamp_gt_by_gear_shift_point

    def _calc_gear_shift_by_gt_gear(self, inputs):
        """
        Compute gear-shift info by gt-gear.

        NOTE: assuming sequence like [D,D,D,(P),R,R,R]. NOT support sequence like [D,R,D,R] .
        Returns:
          gear_shift_idx(int): -1 for no gear shifting.
        """
        gt_mask = inputs["trans"]["egos_pred_mask"][0, 0]  # [1, 1, T] -> [T]

        fut_gears = inputs["future"]["egos_gear"]  # [T]
        gear_d = (fut_gears == EgoGearGen.GEAR_D) * gt_mask  # [T]
        gear_r = (fut_gears == EgoGearGen.GEAR_R) * gt_mask  # [T]
        has_gear_d = np.sum(gear_d) > 0
        has_gear_r = np.sum(gear_r) > 0
        gear_shift_idx = -1
        if has_gear_d and has_gear_r:
            gear_d_first_idx = np.where(gear_d)[0][0]
            gear_r_first_idx = np.where(gear_r)[0][0]
            gear_shift_idx = max(gear_d_first_idx, gear_r_first_idx)
        # print(f"gears {gears.reshape(-1)}")
        # print(f"gear (cur {current_gear} next {next_gear} shift-idx {gear_shift_idx}")
        return gear_shift_idx

    def _concate_gear(self, inputs):
        states = ["history", "current", "future"]
        for s in states:
            gears_raw = [g if g is not None else np.zeros((1), dtype=int) for g in inputs[s]["ego_gears_raw"]]
            inputs[s]["egos_gear"] = np.concatenate(gears_raw, axis=0)

    def __call__(self, inputs):
        """Pad Trajectory by Gear."""
        self._concate_gear(inputs)

        #
        # NOTE: !!! inputs["current"]["egos_pred_gt"] are all zeros now.
        #
        egos_pred_gt = inputs["trans"]["egos_pred_gt"]
        ego_vel_pred_gt = inputs["trans"]["ego_vel_pred_gt"]
        gt_mask = inputs["trans"]["egos_pred_mask"].squeeze(0).squeeze(0)
        ego_fut_gears = inputs["future"]["egos_gear"]
        gt_mask = np.concatenate([np.ones(1), gt_mask])

        gear_shift_idx = -1
        gear_shift_idx = self._calc_gear_shift_by_gt_gear(inputs)

        inputs["egos_gt_gear_shift_idx"] = np.array(gear_shift_idx, dtype=np.int64)

        gear_shift_pnts, gear_shift_pnts_mask = self._gen_gear_shift_point(
            ego_gt=egos_pred_gt, gear_shift_idx=gear_shift_idx
        )
        inputs["egos_gt_gear_shift_points"] = gear_shift_pnts
        inputs["egos_gt_gear_shift_points_mask"] = gear_shift_pnts_mask
        # print(f"gear_shift: idx {gear_shift_idx} mask {gear_shift_pnts_mask} pnt {gear_shift_pnts}")
        assert np.equal(gear_shift_pnts_mask, gear_shift_idx != -1)
        if self.output_gear_shift_point:
            inputs["egos_input_gear_shift_points"] = gear_shift_pnts

        if self.clamp_gt and gear_shift_idx > 0:
            egos_pred_gt[:, :, gear_shift_idx:] = (
                egos_pred_gt[:, :, gear_shift_idx - 1 : gear_shift_idx] if gear_shift_idx > 0 else 0
            )
            ego_vel_pred_gt[:, gear_shift_idx:] = 0

            inputs["egos_gt_gear"] = self._rectify_future_ego_gears(
                ego_fut_gears=ego_fut_gears, ego_gt_mask=gt_mask, gear_shift_idx=gear_shift_idx
            )
        else:
            inputs["egos_gt_gear"] = ego_fut_gears

        egos_gear = np.concatenate([inputs["history"]["egos_gear"], inputs["current"]["egos_gear"]], axis=0)  # [T]
        inputs["egos_gear"] = egos_gear  # [T]

        return inputs

    def _gen_gear_shift_point(self, ego_gt: np.ndarray, gear_shift_idx: int):
        """
        Get gear-shift-point from ego-gt.

        Args:
          egos (Tensor[B=1, 1, F=35, D=16]):
          gear_shift_idx : -1 for not gear point
        Return:
          points (Tensor[B,2]):
          points_mask (Tensor[B]): 0 for invalid, 1 for valid
        """
        assert gear_shift_idx < ego_gt.shape[2], f"gear_shift_idx{gear_shift_idx}, egos {ego_gt.shape}"
        if gear_shift_idx < 1:  # -1 or 0, means not gear-shift-point
            return np.zeros((1, 2), dtype=ego_gt.dtype), np.zeros((ego_gt.shape[0]), dtype=bool)
        return ego_gt[:, 0, gear_shift_idx - 1], np.ones((ego_gt.shape[0]), dtype=bool)

    def _rectify_future_ego_gears(self, ego_fut_gears, ego_gt_mask, gear_shift_idx: int):
        """
        gt-gears after `geat-shift-idx` will be set `Parking` gear.

        Args:
          ego_fut_gears (Tensor[B=1, F=35]):
          ego_gt_mask (Tensor[B, F=35]):
          gear_shift_idx : -1 for not gear point
        Return:
          ego_fut_gears (Tensor[B, F=35]):
        """
        assert gear_shift_idx < ego_fut_gears.shape[0], f"gear_shift_idx{gear_shift_idx}, ego_fut_gears {ego_fut_gears}"
        if gear_shift_idx < 1:  # -1 or 0, means not gear-shift-point
            return ego_fut_gears
        ego_fut_gears[gear_shift_idx:] = EgoGearGen.GEAR_P
        ego_gt_mask = ego_gt_mask[0]  # [1, 1, T] -> [1, T]
        ego_fut_gears = ego_fut_gears * ego_gt_mask
        return ego_fut_gears


class PlannerAlignAgentPrediction(BaseTransform):
    """PlannerAlignAgentPrediction."""

    def __init__(
        self,
        ego_future_frame_num=35,
        use_gpu: bool = False,
    ) -> None:
        """Init."""
        super().__init__(use_gpu=use_gpu)
        self.ego_future_frame_num = ego_future_frame_num
        self.keep_frame_num = 25

    def __call__(self, inputs):
        """Call."""
        num_box = inputs["current"]["dynamic_dets"].shape[1]
        aligned_agent_prediction = np.full((num_box, 1, self.keep_frame_num, 2), fill_value=-1, dtype=np.float32)

        agent_prediction = inputs["current"].pop("agent_prediction")[0]
        if agent_prediction.shape[0] > 0:
            bbox_ids = inputs["current"]["dynamic_dets"][..., 9].reshape(-1, 1)
            pred_ids = agent_prediction[:, 0].flatten()
            pred_trajs = agent_prediction[:, 1:]
            pred_trajs = pred_trajs.reshape(pred_trajs.shape[0], -1, 2)[:, : self.keep_frame_num][:, np.newaxis]

            indices_bbox, indices_pred = np.where(bbox_ids == pred_ids)
            aligned_agent_prediction[indices_bbox] = pred_trajs[indices_pred]
            priority_type = np.array(inputs["current"]["priority_type"])
            inputs["current"]["priority_type"] = priority_type[:, indices_pred, :].tolist()

        inputs["current"]["prediction_traj"] = aligned_agent_prediction
        return inputs


class GetTrackableAgentPrediction(BaseTransform):
    """GetTrackableAgentPrediction."""

    def __init__(
        self,
        use_logical_rule: bool = False,
        selected_agent_dis_thres=70,
    ) -> None:
        """Init."""
        super().__init__()
        self.use_logical_rule = use_logical_rule
        self.selected_agent_dis_thres = selected_agent_dis_thres

    @staticmethod
    def _parse_bytes_from_buffer(bytes, shape, dtype=np.float32):
        """Parse bytes from buffer."""
        return np.frombuffer(bytes, dtype=dtype).reshape(shape)

    def __call__(self, inputs):
        if self.use_logical_rule:
            return self.logical_rules(inputs)
        else:
            return self.labeling_rules(inputs)

    def labeling_rules(self, inputs):
        # 增加人工标注规则
        pass

    def logical_rules(self, inputs):
        """Call.

        Args:
            data_input (_type_): data

        Returns:
            _type_: trackable agent label
        """
        # 利用的字段：current， future， future-all-meta
        future_car_pose = np.array(
            [self._parse_bytes_from_buffer(i["meta"]["car_pose"], (4, 4)) for i in inputs["future-all-meta"]]
        )
        cur_car_pose = inputs["current"]["car_poses"]
        # 这里就不考虑当前车位了，因为其他障碍物肯定在ego车外
        frame_to_current = np.linalg.inv(cur_car_pose) @ future_car_pose
        ego_future = np.zeros((len(frame_to_current), 4, 1)).astype(frame_to_current.dtype)
        ego_future[:, -1, :] = 1.0
        ego_future = frame_to_current @ ego_future
        ego_future = ego_future[:, :2, 0]

        # 增加一个距离判断与时间长度判断：
        future_frames_nums = future_car_pose.shape[0] - 1
        future_ego_driving_distance = np.linalg.norm((ego_future[1:, :] - ego_future[:-1, :]), axis=-1).sum()
        # 获得动态目标的boxes信息
        boxes = inputs["current"]["dynamic_dets"][0]

        # 获取真正包含有效dynamic dets的索引
        learnable_agent_mask = np.logical_not(inputs["current"]["dynamic_dets_padding_mask"][0])
        # 构造跟踪 agent gt
        trackable_agent_gt = np.zeros_like(learnable_agent_mask)
        # 构造valid agent 索引
        boxes_index = np.array(range(boxes.shape[0]))

        boxes = boxes[learnable_agent_mask]
        boxes_index = boxes_index[learnable_agent_mask]
        agent_cls = boxes[:, 7]
        boxes = boxes[:, [0, 1, 3, 4, 6]]
        box_head = boxes[:, -1]
        boxe_xy = boxes[:, [0, 1]]
        boxe_lw = boxes[:, [2, 3]]
        # 宽度适当延长一些，这样可以保留更多合理的trackalbe agent
        boxe_lw[:, 1] = boxe_lw[:, 1] + 0.8
        # 首先选择出车前的车：
        index = boxe_xy[:, 0] > 3.5
        # 选出是车的类别
        index &= agent_cls < 300
        index &= agent_cls > 100

        boxes_index = boxes_index[index]
        box_head = box_head[index]
        boxe_xy = boxe_xy[index, :]
        boxe_lw = boxe_lw[index, :]

        boxe_half_lw = boxe_lw / 2
        corner_flag = np.array([[-1, -1], [1, -1], [1, 1], [-1, 1]])
        # 障碍物在自己坐标系下的角点坐标
        corner = boxe_half_lw[:, None, :] * corner_flag[None, :, :]

        box_head_cos = np.cos(box_head)
        box_head_sin = np.sin(box_head)

        ego_traj_points = ego_future[:, None, :] - boxe_xy[None, :, :]

        x = box_head_cos[None, :] * ego_traj_points[:, :, 0] + box_head_sin[None, :] * ego_traj_points[:, :, 1]
        y = -box_head_sin[None, :] * ego_traj_points[:, :, 0] + box_head_cos[None, :] * ego_traj_points[:, :, 1]

        # 计算款的xy方向的最大和最小情况
        x_min = corner[:, :, 0].min(-1)
        x_max = corner[:, :, 0].max(-1)
        y_min = corner[:, :, 1].min(-1)
        y_max = corner[:, :, 1].max(-1)

        # 查看落在agent box中的轨迹点情况
        index = (x - x_min[None, ...]) >= 0
        index &= (x_max[None, ...] - x) >= 0
        index &= (y - y_min[None, ...]) >= 0
        index &= (y_max[None, ...] - y) >= 0

        # 如果没有一个agent满足
        if index.sum() > 0:
            select_agent = np.where(index.sum(0) > 0)[0]
            points_index = index[:, select_agent]
            points_index = points_index.transpose(1, 0)

            cover_index = np.argwhere(points_index)
            min_cover_index = np.argmin(cover_index[:, 1])
            min_agent_index = cover_index[min_cover_index][0]
            track_agent = select_agent[min_agent_index]
            min_agent_conver_index = np.where(points_index[min_agent_index])[0]

            # 获取agent cover的ego轨迹点，但是会向外延一点，因为有的cover就是1个点或者两个点，用来算方向有点不够准
            min_agent_conver_index_ = np.array([min_agent_conver_index[0], min_agent_conver_index[-1]])
            min_agent_conver_index_[0] = min_agent_conver_index_[0] - 1
            min_agent_conver_index_[-1] = min_agent_conver_index_[-1] + 1
            min_agent_conver_index_ = np.clip(min_agent_conver_index_, 0, len(ego_traj_points) - 1)

            sx = x[:, track_agent][min_agent_conver_index_[0]]
            sy = y[:, track_agent][min_agent_conver_index_[0]]
            ex = x[:, track_agent][min_agent_conver_index_[1]]
            ey = y[:, track_agent][min_agent_conver_index_[1]]

            # 计算agent conver 部分的轨迹点的方向
            theta = math.atan2(ex - sx, ey - sy)
            # 计算轨迹点的方向与当前agent的行驶方向的差值
            theta_gap = abs(theta - math.pi / 2)
            # 这里给一个gap ，目前认为只要0.5pi的角度差内，都可以
            if theta_gap < 0.5:
                real_trake_agent = boxes_index[track_agent]
                trackable_agent_gt[real_trake_agent] = 1

        # 首先判断是否有自车前的agent， 如果有，则进行忽略条件的判断
        if len(boxes_index) > 0:
            # 在没有查到跟车目标车时， 如果剩余帧数小于30，或者自车行驶轨迹小于5m的时候， 则忽略前方车辆
            if (future_frames_nums < 30 or future_ego_driving_distance < 5.0) and trackable_agent_gt.sum() == 0:
                learnable_agent_mask[boxes_index] = 0

        inputs["ego_trackable_agent_gt"] = trackable_agent_gt.astype(np.float32)
        inputs["ego_trackable_agent_gt_mask"] = learnable_agent_mask

        return inputs


class DrivePathGen(BaseTransform):
    """Drive path gen."""

    def __init__(self, num_points=150, interval=1, use_gpu: bool = False) -> None:
        """Init."""
        super().__init__(use_gpu)
        self.num_points = num_points
        self.interval = interval
        self.target_distances = np.arange(interval, num_points + interval, interval)

    def __call__(self, data_dict):
        """Call."""
        future_ego_all = self._get_future_ego_all(data_dict)
        dirve_path, drive_path_mask = self._interpolate(future_ego_all, self.target_distances)
        navi_path_points = data_dict["current"]["navi_path_points"].reshape(-1, 2)
        navi_drive_path, navi_drive_path_mask = self._interpolate(navi_path_points, self.target_distances)
        data_dict["current"]["drive_path"] = dirve_path
        data_dict["current"]["drive_path_mask"] = drive_path_mask
        data_dict["current"]["navi_drive_path"] = navi_drive_path
        data_dict["current"]["navi_drive_path_mask"] = navi_drive_path_mask
        return data_dict

    def _get_future_ego_all(self, data_dict):
        """Get all future ego."""
        future_all_meta = data_dict["future-all-meta"]
        carposes = np.array(
            [np.frombuffer(frame["meta"]["car_pose"], np.float32).reshape(4, 4) for frame in future_all_meta]
        )
        ego_future = self._transform_car_pose(carposes, data_dict)
        if data_dict["current"]["aligned_trajectory"][0] is not None:
            aligned_trajectory = data_dict["current"]["aligned_trajectory"][0]
            align_len = aligned_trajectory.shape[0]
            raw_len = ego_future.shape[0]
            if align_len < raw_len:
                ego_future = aligned_trajectory[:, 0:2]
            else:
                ego_future = aligned_trajectory[:raw_len, 0:2]
        return ego_future

    def _transform_car_pose(self, car_poses, data_dict):
        """Transform Control Point."""
        current_to_world = data_dict["current"]["car_poses"]
        homo_ego_future = np.zeros((len(car_poses), 4, 1), dtype=np.float32)
        homo_ego_future[:, -1, :] = 1.0
        frame_to_current = np.linalg.inv(current_to_world) @ car_poses

        ego_future = frame_to_current @ homo_ego_future

        return ego_future[:, :2, 0]

    def _interpolate(self, coords_2d, target_distances):
        drive_path = np.zeros((self.num_points, 2))
        mask_target = np.zeros_like(self.target_distances)
        last_index = 0
        sample_indices = [last_index]
        for index in range(1, len(coords_2d)):
            if np.linalg.norm(coords_2d[index] - coords_2d[last_index]) > 0.5:
                sample_indices.append(index)
                last_index = index
        sample_coords_2d = coords_2d[sample_indices]
        sample_coords_2d = np.vstack([[0, 0], sample_coords_2d])
        x = sample_coords_2d[:, 0]
        y = sample_coords_2d[:, 1]
        distances = np.sqrt(np.diff(x) ** 2 + np.diff(y) ** 2)
        cumulative_distances = np.insert(np.cumsum(distances), 0, 0)
        invalid_indices = np.where((cumulative_distances[-1] - self.target_distances) < 0)[0]  # [0][0] - 1
        if len(invalid_indices) == 0:
            valid_index = self.num_points
        else:
            valid_index = invalid_indices[0]

        mask_target[:valid_index] = 1
        mask_target_bool = mask_target > 0

        # 允许外插，兼容轨迹末尾
        interp_x = interp1d(cumulative_distances, x, kind="slinear")
        interp_y = interp1d(cumulative_distances, y, kind="slinear")
        # 计算新的插值点
        new_x = interp_x(self.target_distances[mask_target_bool])
        new_y = interp_y(self.target_distances[mask_target_bool])
        coords_target = np.stack([new_x, new_y], axis=1)

        # concat last point
        drive_path[: len(coords_target)] = coords_target
        return drive_path, mask_target
