# -*- coding: utf-8 -*-
"""NN3 image augmentations (ported from plannn3 IL)."""

from __future__ import annotations

import random
from typing import Any
from typing import Dict

import numpy as np
import torch
from torchpilot.data.transform.base_transform import BaseTransform


class Plannn3MaskHistoryImage(BaseTransform):
    """Mask random history frames to -1 on all ``video:*`` tensors (nn3 IL)."""

    def __init__(self, prob: float = 0.2, mode: str = "train"):
        self.prob = prob
        self.mode = mode

    def __call__(self, data_input: Dict[str, Any]) -> Dict[str, Any]:
        if self.mode != "train" or np.random.random() >= self.prob:
            return data_input
        nn3_image = data_input.get("nn3_image")
        if not nn3_image:
            return data_input
        img_keys = [key for key in nn3_image if key.startswith("video")]
        if not img_keys:
            return data_input
        max_num = max(nn3_image[key].shape[1] for key in img_keys)
        if max_num <= 1:
            return data_input
        mask_num = random.randint(1, max_num - 1)
        mask_start = -max_num
        mask_end = -(max_num - mask_num)
        for key in img_keys:
            tensor = nn3_image[key]
            if -tensor.shape[1] >= mask_end:
                continue
            cur_mask_start = max(mask_start, -tensor.shape[1])
            nn3_image[key] = tensor.clone()
            fill_value = 0 if tensor.dtype == torch.uint8 else -1.0
            nn3_image[key][:, cur_mask_start:mask_end] = fill_value
        data_input["nn3_image"] = nn3_image
        return data_input
