# -*- coding: utf-8 -*-
"""Astra planner transform."""
import logging

import numpy as np
from shapely.geometry import LineString
from torchpilot.data.transform.base_transform import BaseTransform


logger = logging.getLogger(__name__)

__all__ = [
    "ODPriorFormat",
]


class ODPriorFormat(BaseTransform):
    def __init__(self):
        """Init."""
        super().__init__()

    def __call__(self, data_dict):
        """Call."""
        od_num = data_dict["current"]["dynamic_dets"].shape[1]
        od_ids = data_dict["current"]["dynamic_dets"][0, :, 9]
        id_ignore_mask = od_ids == -1

        od_prior_res = np.full((od_num), -1.0)

        od_prior = np.array(data_dict["current"]["agent_label"][0].get("priority_objs", []))
        od_prior_mask = np.isin(od_ids, od_prior)
        od_not_prior_mask = np.logical_and(~od_prior_mask, ~id_ignore_mask)
        od_prior_res[od_prior_mask] = 1.0
        intersection_res = self.filter_prior_od_by_roadedge(data_dict, od_prior_mask)
        od_prior_res[od_prior_mask] = np.where(intersection_res, 0.0, od_prior_res[od_prior_mask])
        od_prior_res[od_not_prior_mask] = 0.0

        data_dict["current"]["od_prior"] = od_prior_res
        return data_dict

    def filter_prior_od_by_roadedge(self, data_dict, od_prior_mask):
        """Caculate od out of roadedge."""

        def extract_lane_segments(data_dict):
            """Extract all roadedge segments."""
            # 获取 lane_points 和 lane_types
            lane_points = data_dict["current"]["lane_points"]  # Shape: [100, 50, 2]
            lane_types = data_dict["current"]["lane_types"]  # Shape: [100, 50]

            # 初始化存储所有线段的列表
            all_segments = []

            # 遍历每条车道
            for i in range(lane_points.shape[0]):  # 第一维：车道数量 (100)
                # 提取当前车道的点和类型
                points = lane_points[i]  # Shape: [50, 2]
                types = lane_types[i]  # Shape: [50]

                # 找到 lane_type == 1 的点
                valid_mask = types == 1
                valid_points = points[valid_mask]  # Shape: [n_valid, 2]，其中 n_valid 是有效的点数

                # 去除无效点（NaN）
                valid_points = valid_points[~np.isnan(valid_points).any(axis=1)]

                # 如果有至少两个有效点，则生成相邻点的线段
                if len(valid_points) > 1:
                    segments = [
                        LineString([valid_points[j], valid_points[j + 1]]) for j in range(len(valid_points) - 1)
                    ]
                    all_segments.extend(segments)
            return all_segments

        def check_intersection(od_point, ego_pos, lane_edge_segments):
            """检查每个 od_point 到 ego_pos 的连线是否与任何 lane_edge_segment 相交."""
            # 创建 od_point 到 ego_pos 的连线
            od_to_ego_line = LineString([od_point, ego_pos])
            # 检查是否与任何车道边缘线段相交
            for segment in lane_edge_segments:
                if od_to_ego_line.intersects(segment):
                    return True  # 如果有相交，返回 True
            return False  # 如果没有相交，返回 False

        od_point = data_dict["current"]["dynamic_dets"][0, :, 0:2][od_prior_mask]
        ego_pos = [0.0, 0.0]
        # 将 lane_edge_points 转换为连续的线段
        lane_edge_segments = extract_lane_segments(data_dict)
        # 对每个 od_point 进行检查
        intersection_results = []
        for point in od_point:
            has_intersection = check_intersection(point, ego_pos, lane_edge_segments)
            intersection_results.append(has_intersection)
        return intersection_results

    def get_matches_timestamp(self, wb_agent_data, current_timestamp, thresh=0.2):
        """Get matches timestamp."""
        all_timestamp = list(wb_agent_data["agent_info"].keys())
        all_timestamp_array = np.array([float(ts) for ts in all_timestamp])
        diff = np.abs(all_timestamp_array - current_timestamp)
        idx = np.argmin(diff)
        if diff[idx] < thresh:
            return all_timestamp[idx], diff[idx]
        return None, diff[idx]
