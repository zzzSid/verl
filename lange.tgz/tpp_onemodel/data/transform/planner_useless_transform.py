# -*- coding: utf-8 -*-
"""Planner transform."""
import math

import cv2
import numpy as np
from torchpilot.data.transform.base_transform import BaseTransform


class PlannerShufflePadDynamicBoxwithCropImage(BaseTransform):  # pylint: disable=too-few-public-methods
    """Shuffle dynamic&static box order."""

    def __init__(self, num_pad_box, shuffle, use_gpu=False):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.shuffle = shuffle
        self.num_pad_box = num_pad_box

    def _select_closest_bboxes(self, bboxes):
        """Select closest num_pad_box bboxes."""
        distances = np.linalg.norm(bboxes[:, :2], axis=1)
        sorted_indices = np.argsort(distances)
        selected_indices = sorted_indices[: self.num_pad_box]
        selected_bboxes = bboxes[selected_indices]
        return selected_bboxes

    def __call__(self, inputs):
        """Only align History Det&GT bbox to current frame."""
        states = ["history", "current"]

        for state in states:
            if "dynamic_dets" not in inputs[state]:
                continue
            boxes = inputs[state]["dynamic_dets"]
            dynamic_dim = boxes.shape[1]
            if state == "current":
                crop_images = inputs[state]["crop_images"]
                boxes = np.concatenate((boxes, crop_images), axis=1)

            bboxes_splits = inputs[state]["dynamic_dets_splits"]
            box_dim = boxes.shape[1]
            bboxes_list = np.split(boxes, np.cumsum(bboxes_splits))[:-1]

            t_h = len(bboxes_list)
            reordered_padded_boxes = np.full((t_h, self.num_pad_box, box_dim), 0.0, dtype=boxes.dtype)
            full_padding_mask = np.ones((t_h, self.num_pad_box), dtype=bool)
            for t in range(t_h):
                bboxes = bboxes_list[t]
                if bboxes.shape[0] > self.num_pad_box:  # number of bboxes larger than pad box num
                    bboxes = self._select_closest_bboxes(bboxes)
                if self.shuffle:
                    bboxes = np.random.permutation(bboxes)

                reordered_padded_boxes[t, : bboxes.shape[0]] = bboxes
                full_padding_mask[t, : bboxes.shape[0]] = False

            if state == "history":
                inputs[state]["dynamic_dets"] = reordered_padded_boxes
                inputs[state]["dynamic_dets_padding_mask"] = full_padding_mask
            else:
                inputs[state]["dynamic_dets"] = reordered_padded_boxes[..., :dynamic_dim]
                inputs[state]["crop_images"] = reordered_padded_boxes[..., dynamic_dim:]
                inputs[state]["dynamic_dets_padding_mask"] = full_padding_mask
                inputs[state]["crop_images_padding_mask"] = full_padding_mask

        return inputs


class PlannerShufflePadCropImage(BaseTransform):  # pylint: disable=too-few-public-methods
    """Shuffle crop_image box order follow dynamic box ."""

    def __init__(self, num_pad_box, shuffle=False, use_gpu=False):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.shuffle = shuffle
        self.num_pad_box = num_pad_box

    def _select_closest_bboxes(self, bboxes):
        """Select closest num_pad_box bboxes."""
        distances = np.linalg.norm(bboxes[:, :2], axis=1)
        sorted_indices = np.argsort(distances)
        selected_indices = sorted_indices[: self.num_pad_box]
        selected_bboxes = bboxes[selected_indices]
        return selected_bboxes

    def __call__(self, inputs):
        """Only support NOT shuffle mode."""
        states = ["current"]

        for state in states:
            boxes = inputs[state]["crop_images"]
            box_dim = boxes.shape[1]
            bboxes_splits = inputs[state]["crop_images_splits"]
            bboxes_list = np.split(boxes, np.cumsum(bboxes_splits))[:-1]

            t_h = len(bboxes_list)
            reordered_padded_boxes = np.full((t_h, self.num_pad_box, box_dim), 0.0, dtype=boxes.dtype)
            full_padding_mask = np.ones((t_h, self.num_pad_box), dtype=bool)
            for t in range(t_h):
                bboxes = bboxes_list[t]
                if bboxes.shape[0] > self.num_pad_box:  # number of bboxes larger than pad box num
                    bboxes = self._select_closest_bboxes(bboxes)
                if self.shuffle:
                    bboxes = np.random.permutation(bboxes)

                reordered_padded_boxes[t, : bboxes.shape[0]] = bboxes
                full_padding_mask[t, : bboxes.shape[0]] = False

            inputs[state]["crop_images"] = reordered_padded_boxes
            inputs[state]["crop_images_padding_mask"] = full_padding_mask

        return inputs


class PlannerGenerateAssoIndex(BaseTransform):  # pylint: disable=too-few-public-methods
    """Generate association index for dynamic box."""

    def __init__(self, box_key, num_pad_box, num_frame, track_id_dim=9, use_gpu=False):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.box_key = box_key
        self.num_pad_box = num_pad_box
        self.num_frame = num_frame
        self.track_id_dim = track_id_dim

    def __call__(self, inputs):
        """Call."""
        cur_dets = inputs["current"][self.box_key][0]
        cur_dets_splits = inputs["current"][f"{self.box_key}_splits"][0]
        asso_index = np.zeros((self.num_pad_box, self.num_frame), dtype=int)
        track_ids = cur_dets[:, self.track_id_dim]

        # Create a dictionary to map track_ids to indices for quick lookup
        history_track_id_map = [
            {track_id: idx for idx, track_id in enumerate(frame[:, self.track_id_dim])}
            for frame in inputs["history"][self.box_key]
        ]

        for box_idx in range(min(self.num_pad_box, cur_dets_splits)):
            box_track_id = track_ids[box_idx]
            asso_index[box_idx, -1] = box_idx + 1

            for frame_idx in range(self.num_frame - 1):
                if box_track_id in history_track_id_map[frame_idx]:
                    chosen_idx = history_track_id_map[frame_idx][box_track_id]
                    asso_index[box_idx, frame_idx] = chosen_idx + 1

        inputs["current"]["asso_index"] = asso_index
        return inputs


class PlannerPolarizeAtlas(BaseTransform):
    def __init__(
        self,
        norm_diam,
        keys_used=("main_ground", "foreground", "unsafe_area"),
        use_gpu=False,
        onehot_type=False,
    ):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.norm_diam = norm_diam
        self.keys_used = keys_used
        self.onehot_type = onehot_type
        self.key2type = {key: type_id for type_id, key in enumerate(keys_used)}
        self.feat_dim = 4 + (len(self.keys_used) if self.onehot_type else 1)

    def _get_polar_coords(self, polygon):
        diameters = np.linalg.norm(polygon, axis=-1) / self.norm_diam
        angles = np.arctan2(polygon[:, 1], polygon[:, 0]) / np.pi
        return np.stack([diameters, angles], axis=-1)

    def _group_polygons_np(self, polygons):
        if polygons:
            nmax_pts = max([len(polygon) for polygon in polygons])
        else:
            nmax_pts = 30
        polygons_np = -np.ones((len(polygons), nmax_pts, self.feat_dim), dtype=np.float32)
        for i, polygon in enumerate(polygons):
            polygons_np[i, 0 : len(polygon)] = polygon
        return polygons_np

    def __call__(self, inputs):
        """Only process atlas in the current frame."""
        if "atlas" not in inputs["current"]:
            return inputs
        cur_atlas = inputs["current"]["atlas"][0]
        polygons_in_polar = []
        for key in self.keys_used:
            if key not in cur_atlas:
                continue
            for polygon in cur_atlas[key]:
                if len(polygon) < 3:
                    continue
                polygon = polygon[:, :2]
                polars = self._get_polar_coords(polygon)
                polars_type = np.array(len(polars) * [self.key2type[key]])
                if self.onehot_type:
                    onehot = np.zeros((len(polars_type), len(self.keys_used)), dtype=np.float32)
                    onehot[np.arange(len(polars_type)), polars_type] = 1
                    polars_type = onehot
                else:
                    polars_type = polars_type[..., None]
                polars = np.concatenate([polars, polars_type, polygon], axis=-1)
                polygons_in_polar.append(polars)

        polygons_in_polar = self._group_polygons_np(polygons_in_polar)
        inputs["current"]["atlas_in_polar"] = polygons_in_polar
        return inputs


class PlannerGenAtlasDense(BaseTransform):
    def __init__(
        self,
        keys_used=("main_ground", "foreground", "unsafe_area"),
        use_gpu=False,
    ):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        assert len(keys_used) == 1 and "unsafe_area" in keys_used, "Only support unsafe_area in dense formmat!"
        self.key_used = keys_used

    def __call__(self, inputs):
        """Only process atlas in the current frame."""
        if "atlas_bev" not in inputs["current"]:
            return inputs
        inputs["current"]["atlas_bev_cls"] = inputs["current"]["atlas_bev"][0] & 1
        return inputs


class PlannerDecisionPadding(BaseTransform):  # pylint: disable=too-few-public-methods
    """Transform for planner decision."""

    def __init__(self, use_gpu=False):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)

    def __call__(self, inputs):
        """Only process atlas in the current frame."""
        if "decisions" not in inputs["current"]:
            return inputs
        decisions = np.concatenate(inputs["current"]["decisions"])
        decisions_dict = {int(deci[0]): int(deci[4]) for deci in decisions}

        agent_decision_label = np.zeros(inputs["current"]["dynamic_dets_padding_mask"].shape[1], dtype=np.float32)
        agent_decision_mask = np.zeros(inputs["current"]["dynamic_dets_padding_mask"].shape[1], dtype=np.float32)

        for idx in range(inputs["current"]["dynamic_dets"].shape[1]):
            if (
                inputs["current"]["dynamic_dets"][0, idx, 9] in decisions_dict
                and inputs["current"]["dynamic_dets_padding_mask"][0, idx] == 0
            ):
                agent_decision_label[idx] = decisions_dict[int(inputs["current"]["dynamic_dets"][0, idx, 9])]
                agent_decision_mask[idx] = 1

        inputs["current"]["agent_decision_label"] = agent_decision_label
        inputs["current"]["agent_decision_mask"] = agent_decision_mask
        return inputs


class PlannerBEVImageResize(BaseTransform):  # pylint: disable=too-few-public-methods
    """Transform for planner bev feature resize."""

    def __init__(self, feature_key, bev_size, use_gpu=False):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.feature_key = feature_key
        self.bev_size = bev_size

    def __call__(self, inputs):
        """Only process atlas in the current frame."""
        states = ["current", "history"]
        for state in states:
            if self.feature_key in inputs[state]:
                for frame_idx, bev_feature in enumerate(inputs[state][self.feature_key]):
                    bev_feature = np.transpose(bev_feature, (1, 2, 0))
                    bev_feature = cv2.resize(bev_feature, self.bev_size)
                    bev_feature = np.transpose(bev_feature, (2, 0, 1))
                    inputs[state][self.feature_key][frame_idx] = bev_feature

        return inputs


class PlannerEgoSpeedAug(BaseTransform):
    """PlannerGenerateAlignedGT."""

    def __init__(self, speed_aug_control_points, use_gpu=False):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)

        self.speed_aug_control_points = speed_aug_control_points
        points = np.array(speed_aug_control_points)
        a_matrix = np.stack((points[:, 0] ** 3, points[:, 0] ** 2, points[:, 0], np.ones_like(points[:, 0])), axis=-1)
        b_matrix = points[:, 1]
        self.coefficients = np.linalg.solve(a_matrix, b_matrix)

    def __call__(self, inputs):
        """Only process lane in the current frame."""
        # inputs["future"]["scene_type"]
        scene_type = inputs["current"]["scene_type"][-1]
        if scene_type != "LaneKeep":
            return inputs
        vx_idx = 10
        # navi_lk_type = 0
        # lk_idx = torch.where(model_inputs["navilane_scene_idx"] == navi_lk_type)[0]
        vx = inputs["current"]["egos"][:, vx_idx]
        max_reduce_vx = vx - (
            self.coefficients[0] * vx**3
            + self.coefficients[1] * vx**2
            + self.coefficients[2] * vx
            + self.coefficients[3]
        )
        max_reduce_vx[np.logical_or(vx > 50 / 3.6, max_reduce_vx < 0)] = 0
        inputs["current"]["egos"][:, vx_idx] = vx - np.random.uniform(low=0.0, high=1.0, size=(1)) * max_reduce_vx

        return inputs


class PlannerGenerateLaneHeatmap(BaseTransform):
    """PlannerGenerateLaneHeatmap."""

    def __init__(
        self,
        gt_range=(-40, 100, -50, 50),
        upsample_ratio=4,
        use_gpu=False,
        with_unsafe_area=False,
    ):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)

        self.gt_range = gt_range
        self.upsample_ratio = upsample_ratio
        self.laneline_params = {
            "kernel_size": (13, 13),
            "sigma": 4,
        }
        self.laneline_params["peak_value"] = 1 / (self.laneline_params["sigma"] * math.sqrt(2 * math.pi))

        self.curb_params = {
            "kernel_size": (13, 13),
            "sigma": 4,
        }
        self.curb_params["peak_value"] = 1 / (self.curb_params["sigma"] * math.sqrt(2 * math.pi))

        self.ego_gt_params = {
            "kernel_size": (5, 5),
            "sigma": 2,
        }
        self.ego_gt_params["peak_value"] = 1 / (self.ego_gt_params["sigma"] * math.sqrt(2 * math.pi))

        self.with_unsafe_area = with_unsafe_area

        if self.with_unsafe_area:
            self.unsafe_area_params = {
                "kernel_size": (13, 13),
                "sigma": 4,
            }
            self.unsafe_area_params["peak_value"] = 1 / (self.unsafe_area_params["sigma"] * math.sqrt(2 * math.pi))

    def __call__(self, inputs):
        """Only process lane in the current frame."""
        lane_point_list = inputs["current"]["lane_points"]
        lane_type_list = inputs["current"]["lane_types"]
        ego_gt_list = inputs["trans"]["egos_pred_gt"]

        image_field = np.full(
            (
                (self.gt_range[3] - self.gt_range[2]) * self.upsample_ratio,
                (self.gt_range[1] - self.gt_range[0]) * self.upsample_ratio,
            ),
            fill_value=0.0,
            dtype=np.float32,
        )
        for single_lane_points, single_lane_types in zip(lane_point_list, lane_type_list):
            image_field_per_line = np.zeros_like(image_field)
            cur_lane_type = single_lane_types[0]
            if cur_lane_type == 0:
                gaussian_params = self.laneline_params
            elif cur_lane_type == 1:
                gaussian_params = self.curb_params
            else:
                continue

            selected_lane_points = single_lane_points[single_lane_types == cur_lane_type]
            for i_pt in range(len(selected_lane_points[:-1])):
                new_point_x1 = int((selected_lane_points[i_pt][1] + 50) * 4)
                new_point_y1 = int((selected_lane_points[i_pt][0] + 40) * 4)

                new_point_x2 = int((selected_lane_points[i_pt + 1][1] + 50) * 4)
                new_point_y2 = int((selected_lane_points[i_pt + 1][0] + 40) * 4)

                cv2.line(
                    image_field_per_line,
                    (new_point_y1, new_point_x1),
                    (new_point_y2, new_point_x2),
                    1.0,
                    thickness=1,
                )
            image_field_per_line = cv2.GaussianBlur(
                image_field_per_line, gaussian_params["kernel_size"], gaussian_params["sigma"]
            )
            image_field = np.maximum(image_field, image_field_per_line)
        image_field = np.clip(image_field, 0, max(self.laneline_params["peak_value"], self.curb_params["peak_value"]))
        image_field = (image_field - image_field.min()) / (image_field.max() + 1e-8)

        for ego_gt_line in ego_gt_list[0]:
            image_field_per_line = np.zeros_like(image_field)
            for i_pt in range(len(ego_gt_line[:-1])):
                new_point_x1 = int((ego_gt_line[i_pt][1] + 50) * 4)
                new_point_y1 = int((ego_gt_line[i_pt][0] + 40) * 4)

                new_point_x2 = int((ego_gt_line[i_pt + 1][1] + 50) * 4)
                new_point_y2 = int((ego_gt_line[i_pt + 1][0] + 40) * 4)

                cv2.line(
                    image_field_per_line,
                    (new_point_y1, new_point_x1),
                    (new_point_y2, new_point_x2),
                    1.0,
                    thickness=1,
                )
            image_field_per_line = cv2.GaussianBlur(
                image_field_per_line, self.ego_gt_params["kernel_size"], self.ego_gt_params["sigma"]
            )
            image_field_per_line = (image_field_per_line - image_field_per_line.min()) / (
                image_field_per_line.max() + 1e-8
            )
            image_field_per_line = 1 - image_field_per_line
            image_field_per_line_mask = image_field_per_line != 1
            image_field = np.where(
                image_field_per_line_mask, np.minimum(image_field, image_field_per_line), image_field
            )

        if self.with_unsafe_area:
            image_field_unsafe_area = np.zeros_like(image_field)
            unsafe_area = inputs["current"]["atlas"][0]["unsafe_area"]
            for unsafe_poly in unsafe_area:
                if unsafe_poly.shape[0] == 0:
                    continue
                image_field_unsafe_area = cv2.fillPoly(
                    image_field_unsafe_area,
                    [np.array([self.trans2image_cor(x, y) for x, y, _ in unsafe_poly], dtype=np.int32)],
                    1.0,
                )
            image_field_unsafe_area = cv2.GaussianBlur(
                image_field_unsafe_area, self.unsafe_area_params["kernel_size"], self.unsafe_area_params["sigma"]
            )

            image_field = np.where(
                image_field_unsafe_area != 0,
                np.maximum(image_field, image_field_unsafe_area),
                image_field,
            )

        inputs["current"]["lane_collision_map"] = image_field

        return inputs

    def trans2image_cor(self, x, y):
        """Trans2image_cor."""
        new_x = int((x - self.gt_range[0]) * self.upsample_ratio)
        new_y = int((y - self.gt_range[2]) * self.upsample_ratio)
        return new_x, new_y
