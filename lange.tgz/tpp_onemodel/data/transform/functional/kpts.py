# -*- coding: utf-8 -*-
"""Keypoints Transform Function."""
from typing import Union

import torch
from torch import Tensor


def clip_kpts(
    kpts: Tensor,
    height: Union[int, float],
    width: Union[int, float],
) -> Tensor:
    """Clip the keypoints.

    Args:
        kpts (torch.Tensor): Keypoints tensor, the last axis of keypoints is built with
            [x, y] as its first 2 elements.
        height (int or float): The height of the image.
        width (int or float): The width of the image.

    Returns:
        Clipped keypoints.
    """
    kpts[..., 0].clamp_(0, width)
    kpts[..., 1].clamp_(0, height)
    return kpts


def filter_kpts(
    kpts: Tensor,
    height: Union[int, float],
    width: Union[int, float],
) -> Tensor:
    """Filter the keypoints.

    Args:
        kpts (torch.Tensor): Keypoints tensor, the last axis of keypoints is built with
            [x, y] as its first 2 elements.
        height (int or float): The height of the image.
        width (int or float): The width of the image.

    Returns:
        Filtered keypoints.
    """
    valid_mask_1 = torch.minimum(kpts[..., 0], kpts[..., 1]) >= 0
    valid_mask_2 = kpts[..., 0] < width
    valid_mask_3 = kpts[..., 1] < height
    kpts = kpts[valid_mask_1 & valid_mask_2 & valid_mask_3, :]
    return kpts


def invalid_kpts_mask(
    kpts: Tensor,
    height: Union[int, float],
    width: Union[int, float],
) -> Tensor:
    """Invalid mask of the keypoints.

    Args:
        kpts (torch.Tensor): Keypoints tensor, the last axis of keypoints is built with
            [x, y] as its first 2 elements.
        height (int or float): The height of the image.
        width (int or float): The width of the image.

    Returns:
        Invalid mask.
    """
    invalid_mask_1 = torch.minimum(kpts[..., 0], kpts[..., 1]) < 0
    invalid_mask_2 = kpts[..., 0] >= width
    invalid_mask_3 = kpts[..., 1] >= height
    invalid_mask = invalid_mask_1 | invalid_mask_2 | invalid_mask_3

    return invalid_mask


def flip_kpts(
    kpts: Tensor,
    width: Union[int, float],
) -> Tensor:
    """Flip the keypoints.

    Args:
        kpts (torch.Tensor): Keypoints tensor, the last axis of keypoints is built with
            [x, y] as its first 2 elements.
        width (int or float): The width of the image.

    Returns:
        Flipped keypoints.
    """
    kpts[..., 0] = width - kpts[..., 0]
    return kpts


def offset_kpts(
    kpts: Tensor,
    offset_height: Union[int, float],
    offset_width: Union[int, float],
) -> Tensor:
    """Offset the keypoints.

    Args:
        kpts (torch.Tensor): Keypoints tensor, the last axis of keypoints is built with
            [x, y] as its first 2 elements.
        offset_height (float, int): The height offset to x of the image.
        offset_width (float, int): The width offset to y of the image.

    Returns:
        New data_dict with keypoints after offset.
    """
    # NOTE(xuan.hu): `-=` can not be used directly as the type of `offset` may be
    # different from `kpts`.
    kpts[..., 0] = (kpts[..., 0] - offset_width).type(kpts.dtype)
    kpts[..., 1] = (kpts[..., 1] - offset_height).type(kpts.dtype)
    return kpts


def scale_kpts(
    kpts: Tensor,
    scale_height: Union[int, float],
    scale_width: Union[int, float],
) -> Tensor:
    """Scale the keypoints.

    Args:
        kpts (torch.Tensor): Keypoints tensor, the last axis of keypoints
            is built with [x, y] as its first 2 elements.
        scale_height (int or float): the height scale to x of the image.
        scale_width (int or float): the width scale to y of the image.

    Returns:
        New data_dict with keypoints scaled.
    """
    # NOTE(xuan.hu): `*=` can not be used directly as the type of `scale` may be
    # different from `kpts`.
    kpts[..., 0] = (kpts[..., 0] * scale_width).type(kpts.dtype)
    kpts[..., 1] = (kpts[..., 1] * scale_height).type(kpts.dtype)
    return kpts
