# -*- coding: utf-8 -*-
"""Image Transform Function."""
import math
from typing import List
from typing import Tuple
from typing import Union

import torchvision.transforms.functional as tv_functional
from torch import Tensor


def pad_image(
    image: Tensor,
    target_height: Union[int, float] = -1,
    target_width: Union[int, float] = -1,
    divisor: Union[int, float] = -1,
) -> Tensor:
    """Pad the image.

        pad to a fixed size or multiple of divisor.

    Args:
        image (Tensor): (3, H, W) input image
        target_height (Union[int, float], optional): output height,
            must be >= image height. Defaults to -1.
        target_width (Union[int, float], optional): output width,
            must be >= image width. Defaults to -1
        divisor (Union[int, float], optional):
            target size should be multiple of divisor. Defaults to -1.

    Returns:
        Tensor: padded image
    """
    height, width = image.shape[-2:]

    pad_h, pad_w = None, None
    if target_height > 0 and target_width > 0:
        if target_height < height or target_width < width:
            raise ValueError(
                "target_height or target_width is smaller than image size: "
                + f"({target_height} {target_width}) vs ({height} {width})"
            )
        pad_h = int(target_height - height)
        pad_w = int(target_width - width)
    elif divisor > 0:
        pad_h = multiple_pad(size=height, divisor=divisor)
        pad_w = multiple_pad(size=width, divisor=divisor)

    if pad_h is not None and pad_w is not None:
        image = tv_functional.pad(image, padding=[0, 0, pad_w, pad_h], fill=0)

    return image


def images_max_size(images: List[Tensor]) -> Tuple[int, int]:
    """Compute max height and max width among a list of images.

    Args:
        images (List[Tensor]): [(3, H, W)] a list of images

    Returns:
        Tuple[int, int]: max_height, max_width
    """
    max_height, max_width = 0, 0
    for image in images:
        height, width = image.shape[-2:]
        max_height = max(max_height, height)
        max_width = max(max_width, width)

    return max_height, max_width


def multiple_pad(size: Union[int, float], divisor: Union[int, float]) -> int:
    """Compute padding num for the given size and divisor.

    Args:
        size (Union[int, float]): given size, often be the image height or width.
        divisor (Union[int, float]): be multiple of divisor.

    Returns:
        int: padding num
    """
    size = int(size)
    divisor = int(divisor)

    return int(math.ceil(size / divisor) * divisor) - size


def long_size2target_ratio(
    short_size: Union[int, float],
    ratio: Tuple[Union[int, float], Union[int, float]],
) -> int:
    """Compute target long size based on given ratio and short size.

    Args:
        short_size (Union[int, float]): short size of the image.
        ratio (Tuple[Union[int, float], Union[int, float]]): target image aspect ratio.

    Returns:
        int: target long size.
    """
    ratio_w, ratio_h = max(ratio), min(ratio)
    long_size = int(ratio_w / ratio_h * short_size)

    return long_size


def camera_type2id(camera_type: str) -> int:
    """Map camera type to id."""
    if "FW" in camera_type.upper():
        camera_id = 0
    elif "FN" in camera_type.upper():
        camera_id = 1
    elif "RN" in camera_type.upper():
        camera_id = 2
    elif "FL" in camera_type.upper():
        camera_id = 3
    elif "FR" in camera_type.upper():
        camera_id = 4
    elif "RR" in camera_type.upper():
        camera_id = 5
    elif "RL" in camera_type.upper():
        camera_id = 6
    elif "SFW" in camera_type.upper():
        camera_id = 7
    elif "SLW" in camera_type.upper():
        camera_id = 8
    elif "SRW" in camera_type.upper():
        camera_id = 9
    elif "SRCW" in camera_type.upper():
        camera_id = 10
    else:
        camera_id = -1
    return camera_id
