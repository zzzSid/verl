# -*- coding: utf-8 -*-
"""Bounding Box Transform Function."""
from typing import List
from typing import Optional
from typing import Tuple
from typing import Union

import torch
from torch import Tensor


EPS = 1e-6


def clip_bboxes(
    bboxes: Tensor,
    height: Union[int, float],
    width: Union[int, float],
) -> Tensor:
    """Clip the bounding boxes.

    Args:
        bboxes (Tensor): Bounding box tensor, the last axis of bounding box is built
            with [x1, y1, x2, y2] as its first 4 elements.
        height (int or float): the height of the image.
        width (int or float): the width of the image.

    Returns:
        Clipped bounding boxes.
    """
    bboxes[..., 0].clamp_(0, width)
    bboxes[..., 1].clamp_(0, height)
    bboxes[..., 2].clamp_(0, width)
    bboxes[..., 3].clamp_(0, height)
    return bboxes


def filter_bboxes(
    bboxes: Tensor,
    min_height: Union[int, float],
    min_width: Union[int, float],
) -> Tensor:
    """Filter the bounding boxes.

    Args:
        bboxes (Tensor): Bounding box tensor, the last axis of bounding box is built
            with [x1, y1, x2, y2] as its first 4 elements.
        min_height (int or float): the minimum height of the bounding boxes.
        min_width (int or float): the minimum width of the bounding boxes.

    Returns:
        Filtered bounding boxes.
    """
    valid_mask_2 = bboxes[..., 2] - bboxes[..., 0] > min_width
    valid_mask_1 = bboxes[..., 3] - bboxes[..., 1] > min_height
    bboxes = bboxes[valid_mask_1 & valid_mask_2, :]
    return bboxes


def filter_bboxes_with_mask(
    bboxes: Tensor,
    min_height: Union[int, float],
    min_width: Union[int, float],
) -> Tuple[Tensor, Tensor]:
    """Filter the bounding boxes.

    Args:
        bboxes (Tensor): Bounding box tensor, the last axis of bounding box is built
            with [x1, y1, x2, y2] as its first 4 elements.
        min_height (int or float): the minimum height of the bounding boxes.
        min_width (int or float): the minimum width of the bounding boxes.

    Returns:
        Union[Tensor, Tensor]: Filtered bounding boxes.
    """
    valid_mask_2 = bboxes[..., 2] - bboxes[..., 0] > min_width
    valid_mask_1 = bboxes[..., 3] - bboxes[..., 1] > min_height
    valid_mask = valid_mask_1 & valid_mask_2
    bboxes = bboxes[valid_mask, :]
    return bboxes, valid_mask


def flip_bboxes(
    bboxes: Tensor,
    width: Union[int, float],
) -> Tensor:
    """Flip the bounding boxes.

    Args:
        bboxes (Tensor): Bounding box tensor, the last axis of bounding box is built
            with [x1, y1, x2, y2] as its first 4 elements.
        width (int or float): the width of the image.

    Returns:
        Flipped bounding boxes.
    """
    new_x1 = (width - bboxes[..., 2]).type(bboxes.dtype)
    bboxes[..., 2] = (width - bboxes[..., 0]).type(bboxes.dtype)
    bboxes[..., 0] = new_x1
    return bboxes


def offset_bboxes(
    bboxes: Tensor,
    offset_h1: Union[int, float],
    offset_h2: Union[int, float],
    offset_w1: Union[int, float],
    offset_w2: Union[int, float],
) -> Tensor:
    """Offset the bounding boxes.

    Args:
        bboxes (Tensor): Bounding box tensor, the last axis of bounding box is built
            with [x1, y1, x2, y2] as its first 4 elements.
        offset_h1 (int or float): the height offset to y1 of the image.
        offset_h2 (int or float): the height offset to y2 of the image.
        offset_w1 (int or float): the width offset to x1 of the image.
        offset_w2 (int or float): the width offset to x2 of the image.

    Returns:
        Bounding box after offset.
    """
    # NOTE(xuan.hu): `-=` can not be used directly as the type of `offset` may be
    # different from `bboxes`.
    bboxes[..., 0] = (bboxes[..., 0] - offset_w1).type(bboxes.dtype)
    bboxes[..., 1] = (bboxes[..., 1] - offset_h1).type(bboxes.dtype)
    bboxes[..., 2] = (bboxes[..., 2] - offset_w2).type(bboxes.dtype)
    bboxes[..., 3] = (bboxes[..., 3] - offset_h2).type(bboxes.dtype)
    return bboxes


def scale_bboxes(
    bboxes: Tensor,
    scale_height: Union[int, float],
    scale_width: Union[int, float],
) -> Tensor:
    """Scale the bounding boxes.

    Args:
        bboxes (Tensor): Bounding box tensor, the last axis of bounding box is built
            with [x1, y1, x2, y2] as its first 4 elements.
        scale_height (int or float): the height scale to x of the image.
        scale_width (int or float): the width scale to y of the image.

    Returns:
        New data_dict with bounding box scaled.
    """
    # NOTE(xuan.hu): `*=` can not be used directly as the type of `scale` may be
    # different from `bboxes`.
    bboxes[..., 0] = (bboxes[..., 0] * scale_width).type(bboxes.dtype)
    bboxes[..., 1] = (bboxes[..., 1] * scale_height).type(bboxes.dtype)
    bboxes[..., 2] = (bboxes[..., 2] * scale_width).type(bboxes.dtype)
    bboxes[..., 3] = (bboxes[..., 3] * scale_height).type(bboxes.dtype)
    return bboxes


def ignore_truncated_by_ratio(
    boxes_before_clip: Tensor,
    boxes_after_clip: Tensor,
    boxes_label: Tensor,
    truncate_ratio: float,
) -> Tensor:
    """Reset truncated 2d bboxes class label.

        if boxes_before_clip has negative area or boxes_after_clip is too smaller
        than a specific ratio, it will be allocated a ignore label
    Args:
        boxes_before_clip (Tensor): (N, 4 ), 4 is (x1, y1, x2, y2) of 2d box,
            the last dim is cls label.
        boxes_after_clip (Tensor):  (N, 4), 4 is (x1, y1, x2, y2) of 2d box,
            the last dim is cls label
        boxes_label (Tensor): (N,), class id.
        truncate_ratio (float): the minimum ratio that the boxes will be ignored.

    Returns:
        Tensor: (N,) updated boxes_label.
    """
    boxes_w_before = boxes_before_clip[..., 2] - boxes_before_clip[..., 0]
    boxes_h_before = boxes_before_clip[..., 3] - boxes_before_clip[..., 1]
    boxes_area_before = boxes_w_before * boxes_h_before

    boxes_w_after = boxes_after_clip[..., 2] - boxes_after_clip[..., 0]
    boxes_h_after = boxes_after_clip[..., 3] - boxes_after_clip[..., 1]
    boxes_area_after = boxes_w_after * boxes_h_after

    w_truncate_mask = (boxes_w_before > 0) & (boxes_w_after / (boxes_w_before + EPS) <= truncate_ratio) | (
        boxes_w_before <= 0
    )
    h_truncate_mask = (boxes_h_before > 0) & (boxes_h_after / (boxes_h_before + EPS) <= truncate_ratio) | (
        boxes_h_before <= 0
    )
    area_truncate_mask = (boxes_area_before > 0) & (boxes_area_after / (boxes_area_before + EPS) <= truncate_ratio) | (
        boxes_area_before <= 0
    )

    truncate_mask = w_truncate_mask | h_truncate_mask | area_truncate_mask
    boxes_label_truncate = torch.where(truncate_mask, -torch.ones_like(boxes_label), boxes_label)

    return boxes_label_truncate


def ignore_by_min_edge(
    bboxes: Tensor,
    boxes_label: Tensor,
    boxes_subcls_label: Tensor,
    ignore_min_edge: float = 0.0,
    not_ignore_min_edge_subclass: Optional[List[int]] = None,
):
    """Set boxes to be ignored when its box's edge is smaller than a threshold."""
    ignored_mask1 = bboxes[..., 2] - bboxes[..., 0] <= ignore_min_edge
    ignored_mask2 = bboxes[..., 3] - bboxes[..., 1] <= ignore_min_edge
    if not_ignore_min_edge_subclass is None:
        ignored_mask = ignored_mask1 | ignored_mask2
        boxes_label = torch.where(ignored_mask, -torch.ones_like(boxes_label), boxes_label)
    else:
        subclss_ignore_mask = boxes_label != -1
        for subcls_id in not_ignore_min_edge_subclass:
            subclss_ignore_mask &= boxes_subcls_label != subcls_id
        ignored_mask = (ignored_mask1 | ignored_mask2) & subclss_ignore_mask
        boxes_label = torch.where(ignored_mask, -torch.ones_like(boxes_label), boxes_label)

    return boxes_label


def ignore_by_occlusion(
    occlusion: Tensor,
    boxes_label: Tensor,
    ignore_occlusion_class: Optional[List[int]] = None,
    ignore_occlusion_level: int = 2,
):
    """Set boxes to be ignored when its occlusion label >= ignore_occlusion_level."""
    if ignore_occlusion_class is None:
        return boxes_label

    for cls_id in ignore_occlusion_class:
        condition = (boxes_label == cls_id) & (occlusion >= ignore_occlusion_level)
        boxes_label = torch.where(condition, -torch.ones_like(boxes_label), boxes_label)

    return boxes_label
