# -*- coding: utf-8 -*-
"""Stamp transform."""
import copy
import logging
import math
import random
from typing import List

import numpy as np
from scipy.spatial.distance import pdist
from scipy.spatial.distance import squareform
from scipy.spatial.transform import Rotation as R
from torchpilot.data.transform.base_transform import BaseTransform


logger = logging.getLogger(__name__)

__all__ = [
    "StampAugDropoutBoxByTracklet",
    "StampAugCarposeRT",
    "StampAlignDetGtToRef",
    "StampAlignGT2Ref",
    "StampAlignEgoToRef",
    "StampAugFlipAlongX",
    "StampAugFlipAlongY",
    "StampAugGlobalRT",
    "StampAugGlobalScaling",
    "StampAugCenterSizeNoise",
    "StampShufflePadBox",
    "StampShufflePadLane",
    "StampGenerateAssoLabel",
    "StampGenerateAttnMask",
    "StampGenerateStateLabel",
    "StampIgnorePedestrianYaw",
    "StampAugDropHistFrame",
    "StampAugRandSwapCurrHistFrame",
    "StampAugDropHistCamFrame",
    "StampAugDropGODInfoByObject",
    "StampGeneratePredVelLabel",
    "StampGenerateDangerLabel",
    "StampGenerateDecisionLabel",
    "StampTLDDataAug",
    "StampStopFutureLeakDataAug",
]


# pylint: disable=too-few-public-methods
class StampAugDropoutBoxByTracklet(BaseTransform):
    """StampAugDropoutBoxByTracklet."""

    def __init__(
        self,
        history_drop_prob=0.1,
        current_drop_prob=0.1,
        least_history_frame=2,
        use_gpu: bool = False,
    ):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.history_drop_prob = history_drop_prob
        self.current_drop_prob = current_drop_prob
        self.least_history_frame = least_history_frame

    def __call__(self, inputs):
        """Random delete current and history bboxes."""
        # dropout current query
        if self.current_drop_prob > 0:
            curr_size = inputs["current"]["dets_splits"][0]
            left_idx = np.random.choice(
                curr_size,
                size=int((1 - self.current_drop_prob) * curr_size),
                replace=False,
            )
            left_idx.sort()
            if left_idx.shape[0] > 0:
                inputs["current"]["dets_splits"][0] = left_idx.shape[0]
                inputs["current"]["dets"] = inputs["current"]["dets"][left_idx]

        if self.history_drop_prob > 0:
            # dropout history key
            curr_dets = inputs["current"]["dets"]
            hist_dets = inputs["history"]["dets"]
            hist_dets_splits = inputs["history"]["dets_splits"]
            k_track_ids = hist_dets[:, 9]

            for q_box in curr_dets:
                q_track_id = q_box[9]
                if q_track_id == -1 or np.random.rand() > self.history_drop_prob:
                    continue  # no drop

                k_pos = np.where(q_track_id == k_track_ids)
                num_k = len(k_pos[0])
                if num_k <= self.least_history_frame:  # skip too-short track
                    continue

                num_k_to_erase = np.random.randint(0, num_k - self.least_history_frame + 1)
                hist_dets[k_pos[0][:num_k_to_erase]] = 0  # erase from earlist

            hist_dets_splits = np.cumsum(hist_dets_splits)
            hist_dets_list = np.split(hist_dets, hist_dets_splits)[:-1]

            new_hist_dets_list = []
            for dets in hist_dets_list:
                valid_pos = ~np.all(dets == 0, axis=1)
                new_hist_dets_list.append(dets[valid_pos])

            new_hist_dets_splits = np.array([dets.shape[0] for dets in new_hist_dets_list])
            inputs["history"]["dets_splits"] = new_hist_dets_splits
            new_hist_dets_list = np.vstack(new_hist_dets_list)
            inputs["history"]["dets"] = new_hist_dets_list
        return inputs


class StampAugCarposeRT(BaseTransform):  # pylint: disable=too-few-public-methods
    """Random rotation of carpose."""

    def __init__(
        self,
        probability: float,
        noise_range,
        use_gpu: bool = False,
        use_future: bool = False,
    ) -> None:
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self._probability = probability
        self._noise_range = noise_range
        self.use_future = use_future

    @staticmethod
    def euler_angles_to_rotation_mat(theta):
        """Euler_angles_to_rotation_mat."""
        return R.from_euler("ZYX", theta, degrees=False).as_matrix()

    @staticmethod
    def rotation_matrix_to_euler_angles(rot):
        """Calculates_rotation_matrix_to_euler_angles."""
        tmp = np.sqrt(rot[:, 2, 1] * rot[:, 2, 1] + rot[:, 2, 2] * rot[:, 2, 2])
        yaw = np.arctan2(rot[:, 1, 0], rot[:, 0, 0])  # yaw
        pitch = np.arctan2(-rot[:, 2, 0], tmp)  # pitch
        roll = np.arctan2(rot[:, 2, 1], rot[:, 2, 2])  # roll
        return np.stack([yaw, pitch, roll], axis=1)

    def random_rota_and_shift(self, num, _dtype):
        """Random rota and shift."""
        _noise_range = self._noise_range
        items = []
        # rotax, rotay, rotaz, shiftx, shifty, shiftz
        for i in range(6):
            items.append(
                np.random.uniform(low=_noise_range[i][0], high=_noise_range[i][1], size=(num,)).astype(dtype=_dtype)
            )
        return items

    def carpose_shift_and_rt(self, carpose, _dtype=np.float32):
        (
            rota_yaw,
            rota_pitch,
            rota_roll,
            shiftx,
            shifty,
            shiftz,
        ) = self.random_rota_and_shift(len(carpose), _dtype)
        rotation = carpose[:, :3, :3]
        angles = self.rotation_matrix_to_euler_angles(rotation)
        angles += np.stack([rota_yaw, rota_pitch, rota_roll], axis=1)
        rotation = self.euler_angles_to_rotation_mat(angles)
        carpose[:, :3, :3] = rotation
        carpose[:, :3, 3] += np.stack([shiftx, shifty, shiftz], axis=1)
        return carpose

    def __call__(self, inputs):
        """Call."""
        if np.random.random() <= self._probability:
            states = ["history", "current"]
            if self.use_future:
                states.append("future")
            _dtype = inputs["current"]["bboxes"].dtype

            car_poses = np.concatenate([inputs[state]["car_poses"] for state in states if "car_poses" in inputs[state]])
            car_poses_dist = self.carpose_shift_and_rt(car_poses, _dtype)
            start_id = 0
            for state in states:
                if "car_poses" not in inputs[state]:
                    continue
                frm_len = len(inputs[state]["car_poses"])
                inputs[state]["car_poses"] = car_poses_dist[start_id : start_id + frm_len]
                start_id += frm_len

        return inputs


class StampAlignEgoToRef(BaseTransform):  # pylint: disable=too-few-public-methods
    """Align Det&GT bbox to current frame. For STAMP-Tracker."""

    def __init__(self, align=True, use_gpu: bool = False, use_future: bool = False):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.align = align
        self.use_future = use_future

    @staticmethod
    def align_yaw(yaw, rt_mat):
        """Align Yaw using RT matrix."""
        return yaw + np.arctan2(rt_mat[1, 0], rt_mat[0, 0])

    def __call__(self, inputs):  # pylint: disable=too-many-statements
        """Only align History Det&GT bbox to current frame."""
        states = ["history", "current"]
        if self.use_future:
            states.append("future")

        _dtype = inputs["current"]["bboxes"].dtype
        ref2world_rt = inputs["current"]["car_poses"][0]
        world2ref_rt = np.linalg.inv(ref2world_rt).astype(_dtype)
        # cur_ego_yaw_local = inputs["current"]["ego_motion"][0]["yaw"][2]
        # cur_ego_yaw = self.align_yaw(cur_ego_yaw, world2ref_rt)

        veh2world, vel, acc, yaw_rate, whlag, whlagspd, time_flag, pad_msk = [], [], [], [], [], [], [], []
        for state in states:
            frame_len = len(inputs[state]["car_poses"])
            veh2world.append(inputs[state]["car_poses"].astype(_dtype))
            for frm_idx in range(frame_len):
                ego_motion = inputs[state]["ego_motion"][frm_idx]
                vel.append(ego_motion["velocity"][:2] if ego_motion is not None else [0, 0])
                acc.append(ego_motion["acceleration"][:2] if ego_motion is not None else [0, 0])
                yaw_rate.append(ego_motion["yaw_rate"][2] if ego_motion is not None else 0)
                whlag.append(ego_motion.get("whlag", 0) if ego_motion is not None else 0)
                whlagspd.append(ego_motion.get("whlagspd", 0) if ego_motion is not None else 0)
                time_flag.append(frame_len - frm_idx - 1)
                pad_msk.append(int(inputs[state]["scene_type"][frm_idx] == "pad"))

        veh2world = np.concatenate(veh2world, axis=0)
        veh2ref = world2ref_rt @ veh2world
        vel = np.array(vel)
        acc = np.array(acc)
        yaw_rate = np.array(yaw_rate)
        whlag = np.array(whlag)
        whlagspd = np.array(whlagspd)
        time_flag = np.array(time_flag)
        pad_msk = np.array(pad_msk)

        # xyz, lwh, yaw, class id, subtype_id, track_id, vxvy, motion_state,
        # god_semantic_class, god_semantic_probability, sensor type, time flag,
        # god flag, [acc_x, acc_y, yaw_rate]
        # [whlag, whlagspd]
        ego_bbox = np.zeros((veh2ref.shape[0], 23))
        ego_bbox[:, 3:6] = [4.9, 1.99, 1.7]  # lwh template
        ego_bbox[:, 7] = 1  # class: Car
        ego_bbox[:, 15] = 2  # sensor type: 2
        ego_bbox[:, [8, 9, 12, 13, 14, 17]] = -1
        ego_bbox[:, 16] = time_flag
        ego_bbox[:, 20] = yaw_rate
        ego_bbox[:, 21] = whlag
        ego_bbox[:, 22] = whlagspd

        if self.align:
            vel_align = (veh2ref[:, 0:2, 0:2] @ vel[..., None]).squeeze(axis=-1)
            acc_align = (veh2ref[:, 0:2, 0:2] @ acc[..., None]).squeeze(axis=-1)
            yaw_align = np.arctan2(veh2ref[:, 1, 0], veh2ref[:, 0, 0])
            ego_pose_homo = np.tile(np.array([0, 0, 0, 1]), (veh2ref.shape[0], 1))
            ego_pose_align = (veh2ref @ ego_pose_homo[..., None])[:, 0:3].squeeze(axis=-1)
            ego_bbox[:, :3] = ego_pose_align
            ego_bbox[:, 6] = yaw_align
            ego_bbox[:, 10:12] = vel_align
            ego_bbox[:, 18:20] = acc_align
        else:
            ego_bbox[:, 10:12] = vel
            ego_bbox[:, 18:20] = acc

        if pad_msk.any():
            yidx, xidx = np.meshgrid([0, 1, 2, 6, 10, 11, 18, 19, 20, 21], pad_msk.nonzero()[0])
            ego_bbox[xidx, yidx] = 0

        start_id = 0
        for state in states:
            frame_len = len(inputs[state]["car_poses"])
            inputs[state]["egos_padding_mask"] = pad_msk[start_id : (start_id + frame_len)].tolist()
            inputs[state]["egos"] = ego_bbox[start_id : (start_id + frame_len)]
            start_id += frame_len

        return inputs


class StampAlignDetGtToRef(BaseTransform):  # pylint: disable=too-few-public-methods
    """Align Det&GT bbox to current frame. For STAMP-Tracker."""

    def __init__(self, align=True, use_gpu: bool = False, use_future: bool = False):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.align = align
        self.use_future = use_future

    @staticmethod
    def align_yaw(yaw, rt_mat):
        """Align Yaw using RT matrix."""
        return yaw + np.arctan2(rt_mat[1, 0], rt_mat[0, 0])

    def __call__(self, inputs):
        """Only align History Det&GT bbox to current frame."""
        states = ["history"]
        if self.use_future:
            states.append("future")

        _dtype = inputs["current"]["bboxes"].dtype
        ref2world_rt = inputs["current"]["car_poses"][0]
        world2ref_rt = np.linalg.inv(ref2world_rt).astype(_dtype)

        for state in states:
            vech2world_rts = inputs[state]["car_poses"]
            vech2world_rts = vech2world_rts.astype(_dtype)

            boxes = copy.deepcopy(inputs[state]["dets"])
            # boxes = copy.deepcopy(inputs[state]["dynamic_dets"])

            boxes = boxes.astype(_dtype)
            bboxes_splits = inputs[state]["dets_splits"]
            # bboxes_splits = inputs[state]["dynamic_dets_splits"]

            bboxes_splits = np.cumsum(bboxes_splits)
            bboxes_list = np.split(boxes, bboxes_splits)[:-1]

            trans_list = []
            aligned_bboxes = []
            for bboxes, vech2world_rt in zip(bboxes_list, vech2world_rts):
                vech2ref = np.dot(world2ref_rt, vech2world_rt)  # (4, 4)
                if bboxes.shape[0] != 0:
                    # align bboxes
                    bboxes_xyz_homo = np.hstack([bboxes[:, 0:3], np.ones((len(bboxes), 1), dtype=_dtype)])
                    bboxs_xyz_align = np.dot(bboxes_xyz_homo, vech2ref.T)
                    bboxes[:, 0:3] = bboxs_xyz_align[:, 0:3]
                    bboxes[:, 6] = self.align_yaw(bboxes[:, 6], vech2ref)

                    # align velocity
                    bboxes[:, (10, 11)] = np.dot(bboxes[:, (10, 11)], vech2ref[0:2, 0:2].T)
                aligned_bboxes.append(bboxes)
                trans_list.append(vech2ref)

            trans_list = np.stack(trans_list)  # T-1, 4, 4
            aligned_bboxes = np.vstack(aligned_bboxes)
            if self.align:
                # inputs[state]["dets"] = aligned_bboxes
                inputs[state]["dynamic_dets"] = aligned_bboxes

            inputs[state]["hist2curr_trans"] = trans_list

        return inputs


class StampAlignGT2Ref(StampAlignDetGtToRef):  # pylint: disable=too-few-public-methods
    """Align Det&GT bbox to current frame. For STAMP-Tracker."""

    def __init__(self, align=True, use_gpu: bool = False, use_history=True, use_future=False):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.align = align
        self.use_history = use_history
        self.use_future = use_future

    def __call__(self, inputs):
        """Only align History Det&GT bbox to current frame."""
        states = []
        if self.use_history:
            states.append("history")
        if self.use_future:
            states.append("future")

        _dtype = np.float32
        ref2world_rt = inputs["current"]["car_poses"][0]
        world2ref_rt = np.linalg.inv(ref2world_rt).astype(_dtype)

        for state in states:
            vech2world_rts = inputs[state]["car_poses"]
            vech2world_rts = vech2world_rts.astype(_dtype)

            bboxes = copy.deepcopy(inputs[state]["bboxes"])
            bboxes = bboxes.astype(_dtype)
            bboxes_splits = inputs[state]["bboxes_splits"]
            bboxes_list = np.split(bboxes, np.cumsum(bboxes_splits))[:-1]

            aligned_bboxes = []
            for bboxes, vech2world_rt in zip(bboxes_list, vech2world_rts):
                vech2ref = np.dot(world2ref_rt, vech2world_rt)  # (4, 4)
                if bboxes.shape[0] != 0:
                    # align bboxes
                    bboxes_xyz_homo = np.hstack([bboxes[:, 0:3], np.ones((len(bboxes), 1), dtype=_dtype)])
                    bboxs_xyz_align = np.dot(bboxes_xyz_homo, vech2ref.T)
                    bboxes[:, 0:3] = bboxs_xyz_align[:, 0:3]
                    # bboxes[:, 6] = self.align_yaw(bboxes[:, 6], vech2ref)

                    # # align velocity
                    # with threadpool_limits(limits=1, user_api="blas"):
                    #     bboxes[:, (10, 11)] = np.dot(
                    #         bboxes[:, (10, 11)], vech2ref[0:2, 0:2].T
                    #     )
                aligned_bboxes.append(bboxes)

            aligned_bboxes = np.vstack(aligned_bboxes)
            inputs[state]["bboxes"] = aligned_bboxes

        return inputs


class StampAugFlipAlongX(BaseTransform):  # pylint: disable=too-few-public-methods
    """Aug: flip along x-axis."""

    def __init__(self, probability: float, use_gpu: bool = False, use_future: bool = False) -> None:
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self._probability = probability
        self.use_future = use_future

    @staticmethod
    def flip_box_alongx(bboxes, bbox_type):
        """Flip_box_alongx.

        Args:
            bboxes (numpy.ndarray): A 2D array contains bbox infos.
            bbox_type (string): in {"dets", "bboxes"}
        Returns:
            bboxes (numpy.ndarray): A 2D array contains bbox infos.
        """
        bboxes[:, 1:2] = bboxes[:, 1:2] * -1.0  # y
        bboxes[:, 6:7] = bboxes[:, 6:7] * -1.0  # yaw
        valid_vel_idx = np.where(bboxes[:, 11] != -1)
        bboxes[valid_vel_idx, 11:12] = bboxes[valid_vel_idx, 11:12] * -1.0  # velocity
        if bbox_type == "bboxes":
            # gt bboxes
            bboxes[:, 13:14] = bboxes[:, 13:14] * -1.0  # acceleration
            bboxes[:, 14:15] = bboxes[:, 14:15] * -1.0  # yaw_rate

        return bboxes

    def __call__(self, inputs):
        """Call."""
        if np.random.random() < self._probability:
            states = ["history", "current"]
            if self.use_future:
                states.append("future")
            for state in states:
                for bbox_type in ["dets", "bboxes"]:
                    inputs[state][bbox_type] = self.flip_box_alongx(inputs[state][bbox_type], bbox_type)

        return inputs


class StampAugFlipAlongY(BaseTransform):  # pylint: disable=too-few-public-methods
    """aug: flip along y-axis."""

    def __init__(self, probability: float, use_gpu: bool = False) -> None:
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self._probability = probability

    @staticmethod
    def flip_box_alongy(bboxes, bbox_type):
        """Flip_box_alongy.

        Args:
            bboxes (numpy.ndarray): A 2D array contains bbox infos.
            bbox_type (string): in {"dets", "bboxes"}
        Returns:
            bboxes (numpy.ndarray): A 2D array contains bbox infos.
        """
        bboxes[:, 0:1] = bboxes[:, 0:1] * -1.0  # x
        bboxes[:, 6:7] = bboxes[:, 6:7] * -1.0 + math.pi  # yaw
        valid_vel_idx = np.where(bboxes[:, 10] != -1)
        bboxes[valid_vel_idx, 10:11] = bboxes[valid_vel_idx, 10:11] * -1.0  # velocity
        if bbox_type == "bboxes":
            # gt bboxes
            bboxes[:, 12:13] = bboxes[:, 12:13] * -1.0  # acceleration
            bboxes[:, 14:15] = bboxes[:, 14:15] * -1.0  # yaw_rate

        return bboxes

    def __call__(self, inputs):
        """Call."""
        if np.random.random() < self._probability:
            states = ["history", "current"]
            for state in states:
                for bbox_type in ["dets", "bboxes"]:
                    inputs[state][bbox_type] = self.flip_box_alongy(inputs[state][bbox_type], bbox_type)
        return inputs


class StampAugGlobalRT(BaseTransform):  # pylint: disable=too-few-public-methods
    """aug: random rotation of whole point cloud."""

    def __init__(
        self,
        probability: float,
        yaw: List[float],
        use_gpu: bool = False,
        use_future: bool = False,
    ) -> None:
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self._probability = probability
        self._yaw = yaw
        self.use_future = use_future

    @staticmethod
    def get_transform_rt(_yaw, _dtype):
        """Calculate rota and transform.

        Args:
            _yaw (List[float]): A list contains [lower limit, upper limit].
            _dtype : A type is same as inputs["points"] or inputs["current"]["points"].

        Returns:
            rota (numpy.ndarray): An ndarray
            transform (numpy.ndarray): An ndarray
        """
        rota = np.random.uniform(low=_yaw[0], high=_yaw[1])
        transform = np.array(
            [
                [np.cos(rota), -np.sin(rota)],
                [np.sin(rota), np.cos(rota)],
            ],
            dtype=_dtype,
        )
        return rota, transform

    @staticmethod
    def box_rt(bboxes, rota, transform, bbox_type):
        """Points_and_box_rt.

        Args:
            bboxes (numpy.ndarray): A 2D array contains bbox infos.
            rota (numpy.ndarray): An ndarray
            transform (numpy.ndarray): An ndarray
            bbox_type (string): in {"dets", "bboxes"}
        Returns:
            bboxes (numpy.ndarray): A 2D array contains bbox infos.
        """
        bboxes[:, 0:2] = np.matmul(bboxes[:, 0:2], transform)
        valid_vel_idx = np.where(np.sum(bboxes[:, 10:12], axis=-1) + 2 != 0)  # [-1, -1]
        bboxes[valid_vel_idx, 10:12] = np.matmul(bboxes[valid_vel_idx, 10:12], transform)  # velocity

        if bbox_type == "bboxes":
            # gt bboxes
            bboxes[:, 12:14] = np.matmul(bboxes[:, 12:14], transform)  # acceleration

        bboxes[:, 6:7] = bboxes[:, 6:7] - rota
        return bboxes

    def __call__(self, inputs):
        """Call."""
        if np.random.random() < self._probability:
            states = ["history", "current"]
            if self.use_future:
                states.append("future")
            rota, transform = self.get_transform_rt(self._yaw, _dtype=inputs["current"]["bboxes"].dtype)
            for state in states:
                for bbox_type in ["dets", "bboxes"]:
                    inputs[state][bbox_type] = self.box_rt(inputs[state][bbox_type], rota, transform, bbox_type)
        return inputs


class StampAugGlobalScaling(BaseTransform):  # pylint: disable=too-few-public-methods
    """StampAugGlobalScaling."""

    def __init__(self, scale: List[float], use_gpu: bool = False, use_future: bool = False) -> None:
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self._scale = scale
        self.ues_future = use_future

    @staticmethod
    def scale_box(bboxes, scale):
        """Scale_points_and_box.

        Args:
            bboxes (numpy.ndarray): A 2D array contains bbox infos.
            scale (float): Scale factor.

        Returns:
            bboxes (numpy.ndarray): A 2D array contains bbox infos.
        """
        bboxes[:, 0:6] = bboxes[:, 0:6] * scale

        return bboxes

    def __call__(self, inputs):
        """Call."""
        scale = np.random.uniform(low=self._scale[0], high=self._scale[1])
        states = ["history", "current"]
        if self.ues_future:
            states.append("future")
        for state in states:
            for bbox_type in ["dets", "bboxes"]:
                inputs[state][bbox_type] = self.scale_box(inputs[state][bbox_type], scale)
        return inputs


class StampAugCenterSizeNoise(BaseTransform):  # pylint: disable=too-few-public-methods
    """StampAugCenterSizeNoise. But useless and harmful."""

    def __init__(self, scale: float = 2.0, use_gpu: bool = False) -> None:
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self._scale = scale

    def add_noise_to_box(self, bboxes):
        """Scale_points_and_box.

        Args:
            bboxes (numpy.ndarray): A 2D array contains bbox infos.

        Returns:
            bboxes (numpy.ndarray): A 2D array contains bbox infos.
        """
        center_noise = self._scale * (np.random.rand(bboxes.shape[0], 3) - 0.5)
        size_noise = self._scale * (np.random.rand(bboxes.shape[0], 3) - 0.5)
        bboxes[:, 0:3] = bboxes[:, 0:3] * center_noise
        bboxes[:, 3:6] = bboxes[:, 3:6] * size_noise

        return bboxes

    def __call__(self, inputs):
        """Call."""
        states = ["current"]
        for state in states:
            inputs[state]["dets"] = self.add_noise_to_box(inputs[state]["dets"])
        return inputs


class StampShufflePadBox(BaseTransform):  # pylint: disable=too-few-public-methods
    """Shuffle gt&det box order."""

    def __init__(self, num_pad_box, shuffle, use_gpu=False):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.shuffle = shuffle
        self.num_pad_box = num_pad_box

    def __call__(self, inputs):
        """Only align History Det&GT bbox to current frame."""
        states = ["history", "current"]

        for state in states:
            boxes = copy.deepcopy(inputs[state]["dets"])
            # boxes = copy.deepcopy(inputs[state]["dynamic_dets"])
            box_dim = boxes.shape[1]
            bboxes_splits = inputs[state]["dets_splits"]
            # bboxes_splits = inputs[state]["dynamic_dets_splits"]
            bboxes_list = np.split(boxes, np.cumsum(bboxes_splits))[:-1]

            reorder_bboxes = []
            recorder_padding_mask = []
            for bboxes in bboxes_list:
                if self.shuffle:
                    bboxes = np.random.permutation(bboxes)
                padded_boxes = np.full((self.num_pad_box, box_dim), 0.0, dtype=boxes.dtype)
                padded_boxes[: bboxes.shape[0]] = bboxes
                reorder_bboxes.append(padded_boxes)
                padding_mask = np.zeros(self.num_pad_box, dtype=bool)
                padding_mask[bboxes.shape[0] :] = True
                recorder_padding_mask.append(padding_mask)

            reorder_bboxes = np.stack(reorder_bboxes)  # [T, n_t, D]
            inputs[state]["dets"] = reorder_bboxes
            # inputs[state]["dynamic_dets"] = reorder_bboxes
            recorder_padding_mask = np.stack(recorder_padding_mask)  # [T, n_t]
            inputs[state]["dets_padding_mask"] = recorder_padding_mask

        return inputs


class StampGenerateAssoLabel(BaseTransform):  # pylint: disable=too-few-public-methods
    """StampGenerateAssoLabel."""

    # pylint: disable=dangerous-default-value
    def __init__(
        self,
        num_frame,
        num_pad_box,
        bev_key,
        enable_asso_weight=False,
        asso_weight_opt=None,
        enable_soft_label=False,
        soft_label_opt="reci",
        use_curr_frame_query: bool = True,
        use_gpu: bool = False,
    ):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.num_frame = num_frame
        self.num_pad_box = num_pad_box
        self.bev_key = bev_key
        self.enable_asso_weight = enable_asso_weight
        self.asso_weight_opt = asso_weight_opt
        self.enable_soft_label = enable_soft_label
        self.soft_label_opt = soft_label_opt
        self.use_curr_frame_query = use_curr_frame_query

    def soft_label_act_fun(self, dist):  # pylint:disable=inconsistent-return-statements
        """Activation Func."""
        if dist <= 0.5:
            return 1.0
        if self.soft_label_opt == "reci":
            return 1.0 / (1 + dist)
        if self.soft_label_opt == "exp":
            return np.exp(-dist)
        if self.soft_label_opt == "sig":
            return 2.0 / (1 + np.exp(dist))

    def assign_soft_label(self, q_track_id, tracklet_inds, dets, gt_boxes):
        """Assign single timestep soft label."""
        asso_soft_label = np.ones(self.num_frame, dtype=np.float32)
        for timestep, idx in zip(tracklet_inds[0], tracklet_inds[1]):
            the_det = dets[timestep, idx]
            gt_track_ids = gt_boxes[timestep][:, 9]
            the_gt_bbox = gt_boxes[timestep][gt_track_ids == q_track_id][0]
            dist = np.linalg.norm(the_det[0:2] - the_gt_bbox[0:2], ord=2)
            asso_soft_label[timestep] = self.soft_label_act_fun(dist)
        return asso_soft_label

    def __call__(self, inputs):
        """Only align History Det&GT bbox to current frame."""
        all_dets = np.vstack(
            [
                inputs["history"]["dets"],  # (T-1), n_t, 18
                inputs["current"]["dets"],  # 1, n_t, 18
            ]
        )  # T, n_t, 18
        det_track_ids = all_dets[:, :, 9]
        det_splits = np.concatenate(
            [
                inputs["history"]["dets_splits"],
                inputs["current"]["dets_splits"],
            ]
        )
        # NOTE[lck]:如果要打开soft-label，将以下代码取消注释
        # all_bboxes = np.vstack(
        #     [
        #         inputs["history"]["bboxes"],  # H, 18
        #         inputs["current"]["bboxes"],  # C, 18
        #     ]
        # )
        # bboxes_splits = np.concatenate(
        #     [
        #         inputs["history"]["bboxes_splits"],
        #         inputs["current"]["bboxes_splits"],
        #     ]
        # )
        # bboxes_list = np.split(all_bboxes, np.cumsum(bboxes_splits))[:-1]
        sensor_list = np.array(inputs["history"]["sensors"] + inputs["current"]["sensors"])
        sensor_list = sensor_list[None].repeat(self.num_pad_box, axis=0)

        if self.use_curr_frame_query:
            asso_gt = np.zeros((self.num_pad_box, self.num_frame), dtype=np.int64)
            asso_weight = np.ones((self.num_pad_box, self.num_frame), dtype=np.float32)
            # asso_soft_label = np.ones((self.num_pad_box, self.num_frame), dtype=np.float32)
            for q_idx, q_track_id in enumerate(det_track_ids[-1][: det_splits[-1]]):
                asso_gt[q_idx, -1] = q_idx + 1
                if q_track_id == -1:
                    continue
                tracklet_inds = np.where(det_track_ids == q_track_id)
                asso_gt[q_idx, tracklet_inds[0]] = tracklet_inds[1] + 1
                if "DLB" in inputs["current"]["ids"][0]:
                    asso_weight[np.where(sensor_list == self.bev_key)] = 0.0
                if self.enable_asso_weight:
                    for sensor, weight in self.asso_weight_opt.items():
                        asso_weight[np.where(sensor_list == sensor)] = weight
                # if self.enable_soft_label:
                #     asso_soft_label[q_idx] = self.assign_soft_label(
                #         q_track_id,
                #         tracklet_inds,
                #         all_dets,
                #         bboxes_list,
                #     )
        else:
            raise NotImplementedError()  # NOTE[lck]: asso_soft_label not implemented
            asso_gt = []  # pylint: disable=unreachable
            for timestep, splits in enumerate(det_splits):
                curr_timestep_asso_gt = np.zeros((self.num_pad_box, self.num_frame), dtype=int)  # n_t, T
                for q_idx, q_track_id in enumerate(det_track_ids[timestep, :splits]):
                    if q_track_id == -1:
                        curr_timestep_asso_gt[q_idx, -1] = q_idx + 1
                        continue
                    idxs = np.where(det_track_ids == q_track_id)
                    curr_timestep_asso_gt[q_idx, idxs[0]] = idxs[1] + 1
                asso_gt.append(curr_timestep_asso_gt)
            asso_gt = np.vstack(asso_gt)  # T*n_t, T
        inputs["current"]["dets_asso_gt"] = asso_gt
        inputs["current"]["dets_asso_weight"] = asso_weight
        # inputs["current"]["dets_asso_soft_label"] = asso_soft_label
        return inputs


class StampGenerateAttnMask(BaseTransform):  # pylint: disable=too-few-public-methods
    """StampGenerateAssoLabel."""

    def __init__(
        self,
        max_speed,
        num_frame,
        num_pad_box,
        use_gpu: bool = False,
    ):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.num_frame = num_frame
        self.num_pad_box = num_pad_box
        time_idx = np.array([np.arange(self.num_frame) for i in range(self.num_pad_box)]).transpose(1, 0).reshape(-1, 1)
        self.time_mat = (pdist(time_idx, "euclidean") + 1) / 10
        self.max_speed = max_speed

    def __call__(self, inputs):
        """Only align History Det&GT bbox to current frame."""
        bboxes_feats = np.vstack(  # pos(x,y)
            [
                inputs["history"]["dets"][:, :, [0, 1]],  # (T-1), n_t,2
                inputs["current"]["dets"][:, :, [0, 1]],  # 1, n_t,2
            ]
        ).reshape(
            -1, 2
        )  # T*n_t, 2
        distance_mat = pdist(bboxes_feats, "euclidean")
        speed_mat = squareform(distance_mat / self.time_mat, force="no", checks=True)
        bboxes_padding_mask = np.vstack(
            [
                inputs["history"]["dets_padding_mask"],  # T-1, n_t
                inputs["current"]["dets_padding_mask"],  # 1, n_t
            ]
        ).reshape(
            1, -1
        )  # [1,T*n_t]

        # T*n_t, T*n_t, "True" indicates not allowed to attend
        model_attn_mask = np.logical_or((speed_mat > self.max_speed), bboxes_padding_mask)
        np.fill_diagonal(model_attn_mask, False)
        inputs["current"]["dets_model_attn_mask"] = model_attn_mask

        # n_t, T*n_t, "True" indicates not allowed to attend
        decoder_attn_mask = ~np.dot(
            ~bboxes_padding_mask[:, -self.num_pad_box :].T, ~bboxes_padding_mask
        )  # [n_t, T*n_t]

        inputs["current"]["dets_decoder_attn_mask"] = decoder_attn_mask.astype(np.float32)


class StampGenerateStateLabel(BaseTransform):  # pylint: disable=too-few-public-methods
    """StampGenerateStateLabel."""

    def __init__(
        self,
        state_dim,
        class_weight,
        feature_weight,
        moving_weight=1,
        turning_weight=1,
        moving_thres=0.1,
        motion_frame_thres=2,
        use_gpu: bool = False,
    ) -> None:
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self._use_gpu = use_gpu
        self.state_label_dim = state_dim + 5  # 12+5= 1subtype + 4*motion-label

        self.class_weight = np.array(class_weight)
        self.feature_weight = np.array(feature_weight)
        self.moving_weight = moving_weight
        self.turning_weight = turning_weight
        self.moving_thres = moving_thres
        self.motion_frame_thres = motion_frame_thres
        self.subtype2cls = np.array([1] * 9 + [2] + [3] * 5 + [-1], dtype=np.int64)

    def apply_loss_weight(self, state_mask, subtypes):
        """Generate loss weight mask."""
        for class_id in [1, 2, 3]:  # 1: car, 2: ped, 3: bike
            class_where = np.where(self.subtype2cls[subtypes] == class_id)
            state_mask[class_where] *= self.class_weight[class_id - 1]
            # NOTE[lck]: hack, disable motion loss for ped
            if class_id == 2:  # backing, status, direction
                state_mask[class_where, 14:17] = 0

        state_mask = state_mask * self.feature_weight

        # NOTE[lck]: enable later, disable for faster training
        # moving_idx = np.where(
        #     (np.abs(bboxes[:, 10]) + np.abs(bboxes[:, 11])) > self.moving_thres
        # )
        # state_mask[moving_idx] *= self.moving_weight

        # turning_idx = np.where(np.abs(bboxes[:, 11]) > np.abs(bboxes[:, 10]))
        # state_mask[turning_idx] *= self.turning_weight

        return state_mask

    def __call__(self, inputs):
        """Get GT State in order of bboxes track id."""
        bboxes = inputs["current"]["dets"][0]  # n_t, D
        bboxes_splits = inputs["current"]["dets_splits"]  # 1,
        gt_bboxes = inputs["current"]["bboxes"]
        bboxes_hist_track_id = inputs["history"]["dets"][:, :, 9]

        state_label = np.full((bboxes.shape[0], self.state_label_dim), fill_value=-1, dtype=np.float32)
        state_mask = np.zeros_like(state_label, dtype=np.float32)
        occlusion_label = np.full((bboxes.shape[0],), fill_value=-1, dtype=np.float32)
        for idx, src_box in enumerate(bboxes[: bboxes_splits[0]]):
            q_track_id = src_box[9]
            if q_track_id == -1:
                continue
            enable_motion_loss = np.sum(q_track_id == bboxes_hist_track_id) >= self.motion_frame_thres
            where_idx = np.where(gt_bboxes[:, 9] == q_track_id)
            if where_idx[0].shape[0] != 1:
                continue
            target_gt = gt_bboxes[where_idx][0]

            xyzlwhr = target_gt[:7]  # xyz, lwh, yaw
            motion_state = target_gt[10:15]  # vx, vy, accx, accy, yaw_rate
            subtype = target_gt[8:9]

            # >=0有效，-1无效（none）
            motion_label = target_gt[16:17]
            motion_type_label = np.concatenate(
                [
                    motion_label // 1000 - 1,  # 千位数 {-1, 0, 1} # motion_static
                    motion_label // 100 % 10 - 1,  # 百位数 {-1, 0, 1} # motion_backing
                    motion_label // 10 % 10 - 1,  # 十位数 {-1,0,1,2} # motion_status
                    motion_label % 10 - 1,  # 个位数 {-1,0,1,2} # motion_direction
                ]
            )

            state_label[idx] = np.concatenate(
                [
                    xyzlwhr,
                    motion_state,
                    subtype,
                    motion_type_label,
                ]
            )
            state_mask[idx] = 1  # 0:7 xyzlwhr
            state_mask[idx, 7:12] = np.logical_and(motion_state[0:5] != -1, enable_motion_loss)  # vx,vy,accx,accy
            state_mask[idx, 12] = subtype != -1

            motion_type_mask = motion_type_label >= 0
            if motion_type_label[0] == 1:  # 如果是静止
                motion_type_mask[1:] = False  # 把倒车、速度、转向都置为False
            state_mask[idx, 13:17] = np.logical_and(motion_type_mask, enable_motion_loss)

            occlusion_label[idx] = target_gt[17]
        state_mask = self.apply_loss_weight(state_mask, subtypes=state_label[:, 12].astype(np.int))

        inputs["current"]["dets_state_gt"] = state_label  # n_t, D
        inputs["current"]["dets_state_mask"] = state_mask  # n_t, D
        inputs["current"]["dets_occ_score"] = occlusion_label  # n_t

        return inputs


class StampIgnorePedestrianYaw(BaseTransform):  # pylint: disable=too-few-public-methods
    """StampIgnorePedestrianYaw."""

    def __init__(
        self,
        use_gpu: bool = False,
    ) -> None:
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self._use_gpu = use_gpu

    def __call__(self, inputs):
        """Get GT State in order of bboxes track id."""
        # # debug
        # if len(np.where(inputs["current"]["bboxes"][..., 7] == 2)[0]) > 0:
        #     print('b')
        # set det pedestrian bboxes yaw to zero
        ped_idx = np.where(inputs["history"]["dets"][..., 7] == 2)
        inputs["history"]["dets"][ped_idx[0], 6] = 0
        ped_idx = np.where(inputs["current"]["dets"][..., 7] == 2)
        inputs["current"]["dets"][ped_idx[0], 6] = 0
        # set gt pedestrian bboxes yaw to zero
        ped_idx = np.where(inputs["history"]["bboxes"][..., 7] == 2)
        inputs["history"]["bboxes"][ped_idx[0], 6] = 0
        ped_idx = np.where(inputs["current"]["bboxes"][..., 7] == 2)
        inputs["current"]["bboxes"][ped_idx[0], 6] = 0
        return inputs


class StampAugDropHistFrame(BaseTransform):  # pylint: disable=too-few-public-methods
    """StampAugDropHistFrame."""

    def __init__(
        self,
        probability: float,
        use_gpu: bool = False,
    ) -> None:
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self._probability = probability

    def __call__(self, inputs):
        """Drop hist frame when current frame is camera."""
        current_sensor = inputs["current"]["sensors"][0]
        if current_sensor == "falcon":
            return inputs

        if np.random.random() < self._probability:
            history_sensors = inputs["history"]["sensors"]
            falcon_idxs, bev_idxs = [], []
            for idx, sensor in enumerate(history_sensors):
                if sensor == "falcon":
                    falcon_idxs.append(idx)
                elif "BEV" in sensor:
                    bev_idxs.append(idx)
                else:
                    raise NotImplementedError

            if len(falcon_idxs) > 0:
                drop_idx = random.choice(falcon_idxs)
                inputs["history"]["dets_padding_mask"][drop_idx] = True
                inputs["history"]["dets"][drop_idx] = 0.0
                inputs["history"]["dets_splits"][drop_idx] = 0

            if len(bev_idxs) > 0:
                drop_idx = random.choice(bev_idxs)
                inputs["history"]["dets_padding_mask"][drop_idx] = True
                inputs["history"]["dets"][drop_idx] = 0.0
                inputs["history"]["dets_splits"][drop_idx] = 0

        return inputs


class StampAugRandSwapCurrHistFrame(BaseTransform):  # pylint: disable=too-few-public-methods
    """StampAugRandSwapCurrHistFrame."""

    def __init__(
        self,
        probability: float,
        use_gpu: bool = False,
    ) -> None:
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self._probability = probability

    def __call__(self, inputs):
        """Swap current frame with closest history frame."""
        if np.random.random() < self._probability:
            # swap 'extrinsics', 'car_poses', 'paths', 'ids', 'sensors', 'timestamps'
            rand_swap_hist_idx = int(np.random.randint(len(inputs["history"]["ids"])))
            for key in [
                "extrinsics",
                "car_poses",
                "paths",
                "ids",
                "sensors",
                "timestamps",
            ]:
                tmp_curr_value = copy.deepcopy(inputs["current"][key][0])
                inputs["current"][key][0] = copy.deepcopy(inputs["history"][key][rand_swap_hist_idx])
                inputs["history"][key][rand_swap_hist_idx] = tmp_curr_value

            # swap gt bboxes and det bboxes
            for key in ["bboxes", "dets"]:
                bboxes = copy.deepcopy(inputs["history"][key])
                bboxes_splits = inputs["history"][f"{key}_splits"]
                bboxes_list = np.split(bboxes, np.cumsum(bboxes_splits))[:-1]

                tmp_curr_value = copy.deepcopy(inputs["current"][key])
                inputs["current"][key] = copy.deepcopy(bboxes_list[rand_swap_hist_idx])
                bboxes_list[rand_swap_hist_idx] = tmp_curr_value

                inputs["current"][f"{key}_splits"][0] = inputs["current"][key].shape[0]
                inputs["history"][f"{key}_splits"] = np.array([len(x) for x in bboxes_list], dtype=np.int32)
                inputs["history"][key] = np.vstack(bboxes_list)

            # del history 4dgt-bboxes, to free memory
            stamp_gt_dim = inputs["history"]["bboxes"].shape[1]
            inputs["history"]["bboxes"] = np.empty((0, stamp_gt_dim))
            inputs["history"]["bboxes_split"] = [0] * len(inputs["history"]["bboxes_splits"])

        return inputs


class StampAugDropHistCamFrame(BaseTransform):  # pylint: disable=too-few-public-methods
    """StampAugDropHistFrame."""

    def __init__(
        self,
        probability: float,
        use_gpu: bool = False,
    ) -> None:
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self._probability = probability

    def __call__(self, inputs):
        """Drop hist frame when current frame is camera."""
        current_sensor = inputs["current"]["sensors"][0]
        if current_sensor == "falcon":
            if np.random.random() < self._probability:
                history_sensors = inputs["history"]["sensors"]
                for idx, sensor in enumerate(history_sensors):
                    if "BEV" in sensor:
                        inputs["history"]["dets_padding_mask"][idx] = True
                        inputs["history"]["dets"][idx] = 0.0
                        inputs["history"]["dets_splits"][idx] = 0

        return inputs


class StampAugKeepFP(BaseTransform):  # pylint: disable=too-few-public-methods
    """StampAugDropHistFrame."""

    def __init__(
        self,
        q_keep_ratio: float,
        k_keep_ratio: float,
        sensor: str,
        use_gpu: bool = False,
    ) -> None:
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        assert 0 <= q_keep_ratio <= 1, "q_keep_ratio must be in [0, 1]"  # noqa: S101
        assert 0 <= k_keep_ratio <= 1, "k_keep_ratio must be in [0, 1]"  # noqa: S101
        self._keep_ratio = {
            "current": q_keep_ratio,
            "history": k_keep_ratio,
        }
        self._sensor = sensor

    def __call__(self, inputs):
        """Keep partly track_id -1 FP."""
        for state in ["current", "history"]:
            if self._keep_ratio[state] == 1:
                continue
            if state == "current" and inputs[state]["sensors"][0] != self._sensor:
                continue
            dets = copy.deepcopy(inputs[state]["dets"])
            dets_splits = copy.deepcopy(inputs[state]["dets_splits"])
            sensors = np.repeat(inputs[state]["sensors"], dets_splits)
            sensor_fp_index = np.where(np.logical_and(dets[:, 9] == -1, sensors == self._sensor))[0]
            other_index = np.where(~np.logical_and(dets[:, 9] == -1, sensors == self._sensor))[0]
            sensor_keep_fp_index = np.random.choice(
                sensor_fp_index,
                int(self._keep_ratio[state] * sensor_fp_index.shape[0]),
                replace=False,
            )
            final_keep_index = np.sort(np.concatenate([other_index, sensor_keep_fp_index]))
            if state == "current":
                inputs["current"]["dets_splits"][0] = final_keep_index.shape[0]
            elif state == "history":
                keep_flag = np.zeros(dets.shape[0], dtype=np.int32)
                keep_flag[final_keep_index] = 1
                keep_flag_list = np.split(keep_flag, np.cumsum(dets_splits))[:-1]
                new_dets_splits = np.array([np.sum(x) for x in keep_flag_list], dtype=np.int32)
                inputs["history"]["dets_splits"] = new_dets_splits
            inputs[state]["dets"] = dets[final_keep_index]

        return inputs


class StampAugDropGODInfoByObject(BaseTransform):  # pylint: disable=too-few-public-methods
    """StampAugDropGODInfoByObject."""

    def __init__(
        self,
        probability: float,
        use_gpu: bool = False,
    ) -> None:
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self._probability = probability

    def __call__(self, inputs):
        """Drop hist frame when current frame is camera."""
        if self._probability == 0:
            return inputs

        for state in ["current", "history"]:
            dets = inputs[state]["dets"]
            god_indexes = np.where(dets[:, 17] == 1)[0]
            drop_god_idxes = np.random.choice(
                god_indexes,
                int(god_indexes.shape[0] * self._probability),
                replace=False,
            )
            dets[drop_god_idxes, 10:12] = 0.0  # velocity
            # motion_state, god_semantic_class, god_semantic_prob
            dets[drop_god_idxes, 12:15] = -1.0
            dets[drop_god_idxes, 17] = 0.0  # god-flag
            inputs[state]["dets"] = dets

        return inputs


class StampGeneratePredVelLabel(BaseTransform):  # pylint: disable=too-few-public-methods
    """StampGeneratePredVelLabel."""

    def __init__(
        self,
        num_future=80,
        priority_filter=-1,
        use_gpu: bool = False,
    ) -> None:
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.num_future = num_future
        self.priority_filter = priority_filter

    def __call__(self, inputs):
        """Generate prediction velocity label."""
        cur_bboxes = inputs["current"]["dets"][0]  # n_t, D
        cur_bboxes_splits = inputs["current"]["dets_splits"]  # 1

        fut_bboxes = inputs["future"]["bboxes"]  # n_t, D
        fut_bboxes_splits = inputs["future"]["bboxes_splits"]  # 1

        cur_gt_bboxes = inputs["current"]["bboxes"]

        fut_frame_id = []
        for frame_id, splits in enumerate(fut_bboxes_splits):
            fut_frame_id.extend([frame_id] * splits)
        fut_frame_id = np.array(fut_frame_id)

        dets_pred_gt = np.zeros((cur_bboxes.shape[0], self.num_future, 2), dtype=cur_bboxes.dtype)  # [n_t, T_f, 2]
        dets_pred_mask = np.zeros((cur_bboxes.shape[0], self.num_future), dtype=cur_bboxes.dtype)  # [n_t, T_f]
        for i, src_box in enumerate(cur_bboxes[: cur_bboxes_splits[0]]):
            track_id = src_box[9]

            gt_idx = np.where(cur_gt_bboxes[:, 9] == track_id)[0]
            if self.priority_filter > -1:
                obj_priority = cur_gt_bboxes[gt_idx[0], 17]
                if obj_priority < self.priority_filter:
                    dets_pred_mask[i] = 0
                    continue

            idx = np.where(fut_bboxes[:, 9] == track_id)
            if idx[0].shape[0] == 0:
                continue
            gts_pred = fut_bboxes[idx]  # [n_satis, 15]
            timeflag = fut_frame_id[idx]  # [n_satis,]

            dets_pred_gt[i, timeflag] = gts_pred[:, [10, 11]]
            # 1 for valid, 0 for invalid
            dets_pred_mask[i, timeflag] = 1

        inputs["current"]["dets_vel_pred_gt"] = dets_pred_gt
        inputs["current"]["dets_vel_pred_mask"] = dets_pred_mask

        return inputs


class StampGenerateDangerLabel(BaseTransform):  # pylint: disable=too-few-public-methods
    """StampGenerateDangerLabel."""

    def __init__(
        self,
        lat_thres,
        long_max=1.0,
        distance_max=50.0,
        ttb_max=2.0,
        use_real=True,
        use_gpu: bool = False,
    ) -> None:
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self._use_gpu = use_gpu
        self.long_max = long_max
        self.lat_thres = lat_thres
        self.distance_max = distance_max
        self.ttb_max = ttb_max
        self.use_real = use_real

    @staticmethod
    def align_yaw(yaw, rt_mat):
        """Align Yaw using RT matrix."""
        return yaw + np.arctan2(rt_mat[1, 0], rt_mat[0, 0])

    # def bbox3d_csa2cornoer(self, box, rot):
    #     """
    #     bbox format: [x,y,z,l,w,h,yaw]
    #     coordinate frame:
    #     +z
    #     |
    #     |
    #      ----- +y
    #      \
    #       \
    #        +x

    #     Corner numbering::

    #      l  0------1
    #       e  \      \
    #        n  \      \
    #         g  \      \
    #          t  \      \
    #           h  3------2
    #                width

    #     First four corners are the ones facing front.
    #     The last four are the ones facing back.
    #     """
    #     # x, y, z, l, w, h, yaw
    #     # flatten 3D
    #     box[2], box[5] = 0, 0
    #     vertices = np.zeros([4, 3], dtype=np.float32)
    #     vertices[0] = np.array([0 - float(box[3]) / 2.0, 0 - float(box[4]) / 2.0, 0 - float(box[5]) / 2.0])
    #     vertices[1] = np.array([0 - float(box[3]) / 2.0, 0 + float(box[4]) / 2.0, 0 - float(box[5]) / 2.0])
    #     vertices[2] = np.array([0 + float(box[3]) / 2.0, 0 + float(box[4]) / 2.0, 0 - float(box[5]) / 2.0])
    #     vertices[3] = np.array([0 + float(box[3]) / 2.0, 0 - float(box[4]) / 2.0, 0 - float(box[5]) / 2.0])

    #     # vertices[4] = np.array(
    #     #     [0 - float(box[3]) / 2.0, 0 - float(box[4]) / 2.0, 0 + float(box[5]) / 2.0]
    #     # )
    #     # vertices[5] = np.array(
    #     #     [0 - float(box[3]) / 2.0, 0 + float(box[4]) / 2.0, 0 + float(box[5]) / 2.0]
    #     # )
    #     # vertices[6] = np.array(
    #     #     [0 + float(box[3]) / 2.0, 0 + float(box[4]) / 2.0, 0 + float(box[5]) / 2.0]
    #     # )
    #     # vertices[7] = np.array(
    #     #     [0 + float(box[3]) / 2.0, 0 - float(box[4]) / 2.0, 0 + float(box[5]) / 2.0]
    #     # )

    #     def _points_rot_and_trans(points, rotation, translation):
    #         assert len(points.shape) == 2 and points.shape[-1] == 3, "points must be [N,3]"
    #         R = np.array(
    #             [
    #                 [np.cos(rotation), -np.sin(rotation), 0.0],
    #                 [np.sin(rotation), np.cos(rotation), 0.0],
    #                 [0, 0, 1],
    #             ],
    #             dtype=np.float32,
    #         )
    #         translation = np.reshape(translation, [3, 1])
    #         points_rot = np.add(np.matmul(R, points.transpose()), translation).transpose()

    #         return points_rot

    #     vertices = _points_rot_and_trans(vertices, rot, [box[0], box[1], box[2]])

    #     return (
    #         list(vertices[0][:2]),
    #         list(vertices[1][:2]),
    #         list(vertices[2][:2]),
    #         list(vertices[3][:2]),
    #     )

    # def normalize_angle_rad(self, angle_rad):
    #     while angle_rad > math.pi:
    #         angle_rad -= 2 * math.pi
    #     while angle_rad <= -math.pi:
    #         angle_rad += 2 * math.pi
    #     return angle_rad

    # def get_point_type(self, p, l, w, l_delta, w_delta):
    #     x, y = p[0], p[1]

    #     if -l / 2 + l_delta < x < l / 2 - l_delta:
    #         long = "MIDDLE"
    #     elif x >= l / 2 - l_delta:
    #         long = "FRONT"
    #     else:
    #         long = "REAR"

    #     if -w / 2 + w_delta < y < w / 2 - w_delta:
    #         lat = "CENTER"
    #     elif y >= w / 2 - w_delta:
    #         lat = "LEFT"
    #     else:
    #         lat = "RIGHT"

    #     return (long, lat)

    def parse_danger_gt_annos(self, target_gt, src_box, key="real_8"):
        """Parse danger gt label."""
        danger_output = self.ttb_max
        if np.linalg.norm(src_box[:2]) > self.distance_max:
            return danger_output

        if target_gt is not None and f"min_rt_{key}" in target_gt.keys():
            min_ttb = target_gt[f"min_rt_{key}"] / 50.0
            if (
                target_gt[f"min_rt_dis_info_{key}"]["long_dis"] < self.long_max
                and target_gt[f"min_rt_dis_info_{key}"]["lat_dis"] < self.lat_thres[src_box[7]]
                and min_ttb < self.ttb_max
            ):
                danger_output = min_ttb
            # logger.info(target_gt)
        return danger_output

    @staticmethod
    def parse_scratch_annos(target_gt, src_box, key="real_8"):
        """Parse scratch gt label."""
        center_ratio = 0
        if target_gt is not None and f"center_ratio_{key}" in target_gt:
            center_ratio = target_gt[f"center_ratio_{key}"]
            close_center_ratio = target_gt[f"close_center_ratio_{key}"]
            # yaw_diff = target_gt[f"yaw_diff_{key}"]
            vel_norm = np.linalg.norm(src_box[10:12])
            vel_angle = np.arctan2(src_box[11], src_box[10])

            # 如果是静态障碍物 center_ratio和close_center_ratio都满足才不算剐蹭
            if vel_norm <= 1 and (0.3 <= center_ratio or 0.3 <= close_center_ratio):
                return 1.0, center_ratio
            # 如果是动态障碍物 同向-30/30 对向150～210，center_ratio和close_center_ratio都满足才不算剐蹭
            if vel_norm >= 1:
                if -np.pi / 6 < vel_angle < np.pi / 6 and center_ratio >= 0.3:
                    return 1.0, center_ratio
                if np.pi - np.pi / 6 < vel_angle < np.pi + np.pi / 6 and center_ratio >= 0.3:
                    return 1.0, center_ratio
                return 0.0, center_ratio
            return 0.0, center_ratio

        # 如果是静态障碍物 center_ratio和close_center_ratio都满足才不算剐蹭
        return 0.0, center_ratio

    def check_danger_sanity(self, target_gt, box, inputs):  # pylint: disable=unused-argument
        """Generate danger mask."""
        # 1. mask distance larger than 50m.
        if np.linalg.norm(box[:2]) > self.distance_max:
            return 1.0
        # 2. mask gt tracklets < 3 objects.
        if len(np.where(inputs["history"]["bboxes"][:, 9] == box[9])[0]) < 3:
            return 1.0
        # 3. after_collision and ego_low_speed have checked in check_frame_sanity

        # 5. filter collision position
        # if target_gt is None:
        #     return 0.0

        # # NOTE: use overlap instead
        # ratio_thresh_on_ego, ratio_thresh_on_box = 0.1, 0.1
        # angle_thresh_radian = np.pi / 12

        # min_rt_dis_info = target_gt["min_rt_dis_info"]
        # long_dis = min_rt_dis_info["long_dis"]
        # lat_dis = min_rt_dis_info["lat_dis"]
        # min_ttb = target_gt["min_rt"] / 50.0
        # ego_speed = min_rt_dis_info["curr_speed"]
        # box_speed = np.linalg.norm(box[10:12])

        # # for collision agent
        # if min_ttb < self.ttb_max and long_dis < self.long_max and lat_dis < self.lat_thres[box[7]]:
        #     box_meta = min_rt_dis_info["box_meta"]
        #     ego_meta = min_rt_dis_info["ego_meta"]

        #     # from ref to ego
        #     rot_ego = Rotation.from_euler("z", -ego_meta[6]).as_matrix()
        #     trans_ego = (rot_ego @ np.vstack(ego_meta[:3])).T

        #     new_box_center = (rot_ego @ np.vstack(box_meta[:3])).T - trans_ego
        #     new_box_yaw = self.align_yaw(box_meta[6], rot_ego)
        #     new_box_yaw = self.normalize_angle_rad(new_box_yaw)
        #     new_box_meta = np.concatenate([list(new_box_center[0]), box_meta[3:6], np.array([new_box_yaw])])
        #     new_box_corner = self.bbox3d_csa2cornoer(new_box_meta[:-1], new_box_meta[-1])

        #     max_y, min_y = -1e6, +1e6
        #     for corner in new_box_corner:
        #         max_y = max(max_y, corner[1])
        #         min_y = min(min_y, corner[1])

        #     l_ego, w_ego = ego_meta[3:5]
        #     max_proj = min(+w_ego / 2, max_y)
        #     min_proj = max(-w_ego / 2, min_y)
        #     if max_proj < +w_ego / 2 and min_proj > -w_ego / 2:
        #         # fully in front of ego, do not mask
        #         return 0.0

        #     project_length = max(max_proj - min_proj, 0)
        #     project_ratio_on_ego = project_length / w_ego
        #     if project_ratio_on_ego > ratio_thresh_on_ego:
        #         # large overlap, do not mask
        #         return 0.0

        #     # static scratch, do mask
        #     if -0.1 < box_speed < 0.1 and ego_speed > 0.5:
        #         return 1.0

        #     def is_small_angle(new_box_yaw, thresh=np.pi / 4):
        #         if -thresh < new_box_yaw < thresh:
        #             return True

        #         if new_box_yaw > np.pi - thresh or new_box_yaw < -np.pi + thresh:
        #             return True

        #         return False

        #     small_angle_flag = is_small_angle(new_box_yaw, thresh=angle_thresh_radian)
        #     if not small_angle_flag:
        #         # large angle, do not mask
        #         return 0.0

        #     # from ego to box
        #     rot_box = Rotation.from_euler("z", -new_box_yaw).as_matrix()
        #     trans_box = (rot_box @ np.vstack(new_box_center[0][:3])).T
        #     new_ego_center = (rot_box @ np.zeros((3, 1))).T - trans_box
        #     new_ego_yaw = self.align_yaw(0, rot_box)
        #     new_ego_meta = np.concatenate([list(new_ego_center[0]), ego_meta[3:6], np.array([new_ego_yaw])])
        #     new_ego_corner = self.bbox3d_csa2cornoer(new_ego_meta[:-1], new_ego_meta[-1])

        #     max_y, min_y = -1e6, +1e6
        #     for corner in new_ego_corner:
        #         max_y = max(max_y, corner[1])
        #         min_y = min(min_y, corner[1])

        #     l_box, w_box = box_meta[3:5]
        #     max_proj = min(+w_box / 2, max_y)
        #     min_proj = max(-w_box / 2, min_y)
        #     if max_proj < +w_box / 2 and min_proj > -w_box / 2:
        #         # fully in front of agent, do not mask
        #         return 0.0

        #     project_length = max(max_proj - min_proj, 0)
        #     project_ratio_on_box = project_length / w_box

        #     if project_ratio_on_box < ratio_thresh_on_box:
        #         # two overlap (on ego, on box) lt. thresh, do mask
        #         return 1.0

        # if (
        #     long_dis < self.long_max
        #     and lat_dis < self.lat_thres[box[7]]
        #     and min_ttb < self.ttb_max
        # ):
        #     x, y, z = box[:3]

        # #     box_point = min_rt_dis_info["p1"]
        #     ego_point = min_rt_dis_info["p2"]
        #     box_meta = min_rt_dis_info["box_meta"]
        #     ego_meta = min_rt_dis_info["ego_meta"]

        #     rot = Rotation.from_euler("z", -ego_meta[-1]).as_matrix()
        #     trans = (rot @ np.vstack(ego_meta[:3])).T

        #     new_box_center = (rot @ np.vstack(box_meta[:3])).T - trans
        #     new_box_yaw = self.align_yaw(box_meta[-1], rot)
        #     new_box_yaw = self.normalize_angle_rad(new_box_yaw)

        #     rot1 = Rotation.from_euler("z", -new_box_yaw).as_matrix()
        #     trans1 = (rot1 @ np.vstack(new_box_center[0][:3])).T
        #     new_box_point = (rot1 @ np.vstack(box_point + [0.0])).T - trans1
        #     box_point = list(new_box_point[0])

        #     l_ego, w_ego, _ = ego_meta[3:6]
        #     ego_point_type = self.get_point_type(ego_point, l_ego, w_ego, l_ego / 10, w_ego / 10)
        #     if ego_point_type != ("FRONT", "CENTER"):
        #         return 1.0
        #     # l1, w1, h1 = box_meta[3:6]
        #     # if (
        #     #     (-l / 2 + 0.1 < ego_point[0] < l / 2 - 0.1)
        #     #     and (ego_point[1] < -w / 2 + 0.2 or ego_point[1] > w / 2 - 0.2)
        #     #     and (
        #     #         -0.78 < new_box_yaw < 0.78
        #     #         or new_box_yaw < -2.35
        #     #         or new_box_yaw > 2.35
        #     #     )
        #     # ):
        #     #     return 1.0
        #     # if (
        #     #     (l / 2 - 0.1 <= ego_point[0] <= l / 2 + 0.1)
        #     #     and (ego_point[1] < -w / 2 + 0.2 or ego_point[1] > w / 2 - 0.2)
        #     #     and (box_point[1] < -w1 / 2 + 0.2 or box_point[1] > w1 / 2 - 0.2)
        #     #     and (
        #     #         -0.78 < new_box_yaw < 0.78
        #     #         or new_box_yaw < -2.35
        #     #         or new_box_yaw > 2.35
        #     #     )
        #     # ):
        #     #     return 1.0
        return 0.0

    def __call__(self, inputs):
        """Get GT State in order of bboxes track id."""
        bboxes = inputs["current"]["dets"][0]  # n_t, D
        bboxes_splits = inputs["current"]["dets_splits"]  # 1,
        gt_bboxes = inputs["current"]["bboxes"]
        gt_danger_infos = inputs["current"]["danger_infos"][0]
        assert len(gt_bboxes) == len(gt_danger_infos)  # noqa: S101

        danger_label_real = np.full((bboxes.shape[0],), self.ttb_max, dtype=bboxes.dtype)
        danger_label_motion = np.full((bboxes.shape[0],), self.ttb_max, dtype=bboxes.dtype)
        danger_label_motion_4 = np.full((bboxes.shape[0],), self.ttb_max, dtype=bboxes.dtype)
        danger_label_motion_0 = np.full((bboxes.shape[0],), self.ttb_max, dtype=bboxes.dtype)
        danger_mask = np.full((bboxes.shape[0],), 1, dtype=np.int32)  # default 1, valid 0
        priority_label = np.full((bboxes.shape[0],), 2.0, dtype=bboxes.dtype)  # {0, 1, 2}: 0 is lowest priority
        scratch_label_motion = np.full((bboxes.shape[0],), 0.0, dtype=bboxes.dtype)
        scratch_center_ratio = np.full((bboxes.shape[0],), 0.0, dtype=bboxes.dtype)
        for idx, src_box in enumerate(bboxes[: bboxes_splits[0]]):
            q_track_id = src_box[9]
            if q_track_id == -1:
                continue
            where_idx = np.where(gt_bboxes[:, 9] == q_track_id)
            if where_idx[0].shape[0] != 1:
                continue

            target_gt = gt_danger_infos[where_idx[0][0]]
            danger_label_real[idx] = self.parse_danger_gt_annos(target_gt, src_box, key="real_8")
            danger_label_motion[idx] = self.parse_danger_gt_annos(target_gt, src_box, key="motion_8")
            danger_label_motion_4[idx] = self.parse_danger_gt_annos(target_gt, src_box, key="motion_4")
            danger_label_motion_0[idx] = self.parse_danger_gt_annos(target_gt, src_box, key="motion_0")

            scratch_label_motion[idx], scratch_center_ratio[idx] = self.parse_scratch_annos(
                target_gt, gt_bboxes[where_idx[0][0]], key="motion_8"
            )
            danger_mask[idx] = self.check_danger_sanity(target_gt, src_box, inputs)
            priority_label[idx] = gt_bboxes[where_idx[0][0], 17]
            assert priority_label[idx] in {0, 1, 2}, "priority level must in {0, 1, 2}."
        inputs["current"]["danger_gt_real"] = danger_label_real  # n_t, 1
        inputs["current"]["danger_gt_motion"] = danger_label_motion  # n_t, 1
        inputs["current"]["danger_gt_motion_4"] = danger_label_motion_4  # n_t, 1
        inputs["current"]["danger_gt_motion_0"] = danger_label_motion_0  # n_t, 1

        if self.use_real:
            inputs["current"]["danger_gt"] = danger_label_real  # n_t, 1
        else:
            inputs["current"]["danger_gt"] = danger_label_motion  # n_t, 1

        # 1 for invalid, 0 for valid
        inputs["current"]["danger_mask"] = danger_mask  # n_t, 1
        inputs["current"]["priority_gt"] = priority_label  # n_t, 1
        inputs["current"]["scratch_gt"] = scratch_label_motion  # n_t, 1
        inputs["current"]["scratch_center_ratio_gt"] = scratch_center_ratio  # n_t, 1

        danger_4dgt_label = np.full((len(gt_bboxes),), self.ttb_max, dtype=bboxes.dtype)
        for idx, gt_danger in enumerate(gt_danger_infos):
            danger_4dgt_label[idx] = self.parse_danger_gt_annos(gt_danger, gt_bboxes[idx])
        inputs["current"]["danger_4dgt_label"] = danger_4dgt_label  # n_t, 1

        return inputs


class StampGenerateDecisionLabel(BaseTransform):  # pylint: disable=too-few-public-methods
    """StampGenerateDecisionLabel."""

    def __init__(
        self,
        aeb_uuid_file_list,
        non_aeb_uuid_file_list,
        use_gpu: bool = False,
        ttb_decision_upper_bound=0.8,
        ttb_decision_lower_bound=0.6,
        scale=1.0,
        decision_by_scene=False,
        decision_scene_scale=False,
        scratch_decison_set=False,
        use_brake_4_and_0=False,
    ) -> None:
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self._use_gpu = use_gpu
        self.aeb_uuid_list = []
        for aeb_uuid_file in aeb_uuid_file_list:
            with open(aeb_uuid_file, "r") as fin:  # pylint: disable=unspecified-encoding
                self.aeb_uuid_list += [line.strip() for line in fin.readlines()]
        self.non_aeb_uuid_list = []
        for non_aeb_uuid_file in non_aeb_uuid_file_list:
            with open(non_aeb_uuid_file, "r") as fin:  # pylint: disable=unspecified-encoding
                self.non_aeb_uuid_list += [line.strip() for line in fin.readlines()]
        self.ttb_decision_upper_bound = ttb_decision_upper_bound
        self.ttb_decision_lower_bound = ttb_decision_lower_bound
        self.scale = scale
        self.decision_by_scene = decision_by_scene
        self.decision_scene_scale = decision_scene_scale
        self.scratch_decison_set = scratch_decison_set
        self.use_brake_4_and_0 = use_brake_4_and_0

    def __call__(self, inputs):  # pylint: disable=too-many-branches
        """Get decision score."""
        # collision_timestamp = 0
        # for anno in inputs["future"][0]["annotation"]:
        #     box_key = list(anno.keys())[0]
        #     if anno[box_key]["danger_info"] is not None:
        #         if anno[box_key]["danger_info"].get("after_collision", False):
        #             collision_timestamp = anno[box_key]["timestamp"]
        uuid = inputs["current"]["subclip_ids"][0].split("__")[0]
        if uuid in self.aeb_uuid_list:
            min_idx = np.argmin(inputs["current"]["danger_gt_real"])
            min_danger_gt = inputs["current"]["danger_gt"][min_idx]
            min_danger_gt_real = inputs["current"]["danger_gt_real"][min_idx]
            min_danger_gt_motion_4 = inputs["current"]["danger_gt_motion_4"][min_idx]
            min_danger_gt_motion_0 = inputs["current"]["danger_gt_motion_0"][min_idx]

            # current_timestamp = inputs["current"]["timestamp"]
            # if (
            #     current_timestamp - collision_timestamp > 0.5
            #     and collision_timestamp > 0
            # ):
            #     inputs["current"]["decision_gt"] = np.array([0.0], dtype=np.float32)

            vel_gt = inputs["current"]["dets_state_gt"][min_idx][7:9]

            pos_gt = inputs["current"]["dets_state_gt"][min_idx][0:2]

            vel_angle = np.arctan2(vel_gt[1], vel_gt[0])

            inputs["current"]["decision_scale"] = np.array([1.0], dtype=np.float32)

            min_scratch_center_ratio = inputs["current"]["scratch_center_ratio_gt"][min_idx]
            min_scratch = inputs["current"]["scratch_gt"][min_idx]
            # ###横穿调整阈值
            if (
                self.decision_by_scene
                and np.linalg.norm(vel_gt) > 0.5
                and (np.pi / 4 < vel_angle < np.pi * 3 / 4)
                or (np.pi * 5 / 4 < vel_angle < np.pi * 7 / 4)
            ):
                # ttb_decision_upper_bound = 0.6
                # ttb_decision_lower_bound = 0.3
                if (
                    self.decision_scene_scale
                    and (min_danger_gt < self.ttb_decision_upper_bound)
                    and (min_danger_gt_real < self.ttb_decision_upper_bound)
                ):
                    inputs["current"]["decision_scale"] = np.array([0.66], dtype=np.float32)
                    dis_threshold = max(10, np.linalg.norm(vel_gt) * 2)
                    dis_threshold = min(dis_threshold, 40)
                    if min_danger_gt < 0.3 and np.linalg.norm(pos_gt) < dis_threshold:
                        inputs["current"]["decision_scale"] = np.array([1.0], dtype=np.float32)
            ### 对向来车调整阈值
            elif (
                self.decision_by_scene
                and np.linalg.norm(vel_gt) > 0.5
                and np.pi - np.pi / 6 < vel_angle < np.pi + np.pi / 6
            ):
                # ttb_decision_upper_bound = 0.4
                # ttb_decision_lower_bound = 0.1
                if (
                    self.decision_scene_scale
                    and (min_danger_gt < self.ttb_decision_upper_bound)
                    and (min_danger_gt_real < self.ttb_decision_upper_bound)
                ):
                    inputs["current"]["decision_scale"] = np.array([0.33], dtype=np.float32)
                    dis_threshold = max(10, np.linalg.norm(vel_gt) * 2)
                    dis_threshold = min(dis_threshold, 40)
                    if min_danger_gt < 0.3 and np.linalg.norm(pos_gt) < dis_threshold and abs(pos_gt[1]) < 2:
                        inputs["current"]["decision_scale"] = np.array([1.0], dtype=np.float32)
            ### cutin调整阈值
            elif (
                self.decision_by_scene
                and np.linalg.norm(vel_gt) > 0.5
                and -np.pi / 6 < vel_angle < np.pi / 6
                and abs(pos_gt[1]) > 2
                and np.linalg.norm(pos_gt) < 50
            ):
                # ttb_decision_upper_bound = 0.5
                # ttb_decision_lower_bound = 0.2
                if (
                    self.decision_scene_scale
                    and (min_danger_gt < self.ttb_decision_upper_bound)
                    and (min_danger_gt_real < self.ttb_decision_upper_bound)
                ):
                    inputs["current"]["decision_scale"] = np.array([0.5], dtype=np.float32)
                    dis_threshold = max(5, np.abs(vel_gt[1]) * 2)
                    dis_threshold = min(dis_threshold, 10)
                    if min_danger_gt < 0.3 and np.linalg.norm(pos_gt) < dis_threshold:
                        inputs["current"]["decision_scale"] = np.array([1.0], dtype=np.float32)
            else:
                ttb_decision_upper_bound = self.ttb_decision_upper_bound
                ttb_decision_lower_bound = self.ttb_decision_lower_bound

            if (
                (min_danger_gt > ttb_decision_upper_bound)  # pylint: disable=too-many-boolean-expressions
                or (min_danger_gt_real > ttb_decision_upper_bound)
                or (min_scratch_center_ratio >= 0.4 and self.scratch_decison_set and min_scratch >= 1)
                or (min_danger_gt_motion_4 > ttb_decision_upper_bound and self.use_brake_4_and_0)
                or (min_danger_gt_motion_0 > ttb_decision_upper_bound and self.use_brake_4_and_0)
            ):
                inputs["current"]["decision_gt"] = np.array([0.0], dtype=np.float32)
            else:
                if min_danger_gt < ttb_decision_lower_bound:
                    inputs["current"]["decision_gt"] = np.array([self.scale], dtype=np.float32)
                else:
                    inputs["current"]["decision_gt"] = self.scale * np.array(
                        [
                            (ttb_decision_upper_bound - min_danger_gt)
                            / (ttb_decision_upper_bound - ttb_decision_lower_bound)
                        ],
                        dtype=np.float32,
                    )
            ###对向来车如果横向距离太大超过2，或者总位置大于20m以上，decision score为0
            # if np.linalg.norm(vel_gt)>0.5 and vel_angle<(np.pi + np.pi/6) and vel_angle>(np.pi - np.pi/6):
            #     if abs(pos_gt[1])>2 or np.linalg.norm(pos_gt)>20:
            #          inputs["current"]["decision_gt"] = np.array([0.0], dtype=np.float32)

        elif uuid in self.non_aeb_uuid_list:
            inputs["current"]["decision_gt"] = np.array([0.0], dtype=np.float32)
            inputs["current"]["decision_scale"] = np.array([1.0], dtype=np.float32)
        else:
            # raise NotImplementedError
            inputs["current"]["decision_gt"] = np.array([0.0], dtype=np.float32)
            inputs["current"]["decision_scale"] = np.array([0.0], dtype=np.float32)
        return inputs


class StampShufflePadLane(BaseTransform):  # pylint: disable=too-few-public-methods
    """Shuffle pad lane info."""

    def __init__(self, num_pad_lane, num_lane_points, shuffle, use_gpu=False):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.shuffle = shuffle
        self.num_pad_lane = num_pad_lane
        self.num_lane_points = num_lane_points

    def __call__(self, inputs):
        """Only align History Det&GT bbox to current frame."""
        state = "current"
        if "lane_points" not in inputs[state]:
            return inputs
        lane_points = inputs[state]["lane_points"][0]
        lane_types = inputs[state]["lane_types"][0]
        padded_lanes = np.full((self.num_pad_lane, self.num_lane_points, 2), -1, np.float32)
        padded_lanes_type = np.full((self.num_pad_lane, self.num_lane_points), -1, np.int32)
        lane_points_num = np.full(self.num_pad_lane, 0, np.int32)
        # flake8: noqa
        assert len(lane_points) == len(lane_types)
        lane_idx_list = np.arange(len(lane_types))
        if self.shuffle:
            np.random.shuffle(lane_idx_list)
        for lane_idx in lane_idx_list:
            cur_lane = lane_points[lane_idx]
            # if lane_types[lane_idx] == 2:
            #     # filter stop line data
            #     continue
            if len(cur_lane) > self.num_lane_points:

                lane_num = math.ceil(len(cur_lane) / (self.num_lane_points - 1))

                for lane_num_idx in range(lane_num):
                    cur_idx = lane_points_num.argmin()
                    if min(lane_points_num) != 0:
                        break
                    s_idx = max(0, lane_num_idx * (self.num_lane_points - 1))
                    e_idx = min(
                        (self.num_lane_points - 1) * (lane_num_idx + 1) + 1,
                        len(cur_lane),
                    )
                    padded_lanes[cur_idx, 0 : (e_idx - s_idx)] = cur_lane[s_idx:e_idx]
                    padded_lanes_type[cur_idx, 0 : (e_idx - s_idx)] = lane_types[lane_idx]
                    # padded_lanes_type[cur_idx] = lane_types[lane_idx]
                    lane_points_num[cur_idx] = len(cur_lane[s_idx:e_idx])
            else:
                cur_idx = lane_points_num.argmin()
                padded_lanes[cur_idx] = np.full((self.num_lane_points, 2), -1, np.float32)
                padded_lanes_type[cur_idx] = np.full((self.num_lane_points), -1, np.int32)
                padded_lanes[cur_idx, : len(cur_lane)] = cur_lane
                padded_lanes_type[cur_idx, : len(cur_lane)] = lane_types[lane_idx]
                lane_points_num[cur_idx] = len(cur_lane)

        inputs[state]["lane_points"] = padded_lanes
        inputs[state]["lane_types"] = padded_lanes_type

        return inputs


class StampStopFutureLeakDataAug(BaseTransform):  # pylint: disable=too-few-public-methods
    def __init__(self, use_gpu=False):
        """Initialize."""
        super().__init__(use_gpu=use_gpu)
        self.num_future = 35

    def has_front_static_vehicle(self, inputs):
        """Has front static vehicle."""
        bboxes = inputs["current"]["dynamic_dets"][0]
        has_static_vehicle = (
            (bboxes[:, 0] >= 8)
            & (bboxes[:, 0] <= 10)
            & (abs(bboxes[:, 1]) < 1.6)
            & (bboxes[:, 10] == 0)
            & (bboxes[:, 11] == 0)
            & (bboxes[:, 7] < 300)  # <300 means type is vehicle
        ).any()
        return has_static_vehicle

    def is_future_leak(self, inputs):
        """Future leak."""
        current, future = inputs["current"], inputs["future"]

        ego_vx = current["ego_motion"][0][0]

        current_to_world = current["car_poses"][0]
        frame_to_current = np.linalg.inv(current_to_world) @ future["car_poses"][-1]
        homo_ego_future = np.zeros((4, 1))
        homo_ego_future[-1, :] = 1.0
        ego_future = frame_to_current @ homo_ego_future

        return ego_vx == 0 and ego_future[0] > 0.1 and ego_future[1] < 0.5

    def __call__(self, inputs):
        """Generate prediction label."""
        if self.has_front_static_vehicle(inputs) and self.is_future_leak(inputs):
            # avoid future leakage
            inputs["current"]["ego_vel_pred_gt"] = np.zeros((self.num_future, 2), dtype=inputs["future"]["egos"].dtype)
            inputs["current"]["egos_pred_gt"] = np.zeros((1, self.num_future, 2), dtype=inputs["future"]["egos"].dtype)
            inputs["stop_aug"] = "stop_fake_gt"
        return inputs
