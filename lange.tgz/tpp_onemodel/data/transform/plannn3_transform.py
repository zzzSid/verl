# -*- coding: utf-8 -*-
"""Plannn3 multimodal transforms (navi pack + visual decode)."""

from __future__ import annotations

import os
from typing import Any
from typing import Dict
from typing import List
from typing import Optional

import torch
from torchpilot.data.transform.base_transform import BaseTransform

from tpp_onemodel.data.plannn3.nn3_constants import DEFAULT_MULTIVIEW_CAMS
from tpp_onemodel.data.plannn3.nn3_constants import DEFAULT_TEMPORAL_MULTIVIEW_CONFIGS
from tpp_onemodel.data.plannn3.nn3_shared_decoder import Nn3SharedDecoderService
from tpp_onemodel.data.plannn3.nn3_visual_constants import DEFAULT_VIDEO_SHAPE
from tpp_onemodel.data.plannn3.nn3_visual_constants import compute_cam_temporal_counts
from tpp_onemodel.data.plannn3.nn3_visual_cuda import resolve_vt_device_id
from tpp_onemodel.data.plannn3.nn3_visual_decoder import Nn3VisualDecoder
from tpp_onemodel.data.transform.plannn2_transform import Plannn2InferSliceTransform


class Plannn3MultimodalTransformError(Exception):
    """Raised when nn3 navi/visual sidecar is missing; dataset should resample."""


def _to_temporal_bchw(frame: torch.Tensor) -> torch.Tensor:
    """Normalize VT output layout to ``[T, C, H, W]`` without changing dtype."""
    x = frame.detach().cpu()
    while x.dim() > 4:
        if x.shape[0] == 1:
            x = x.squeeze(0)
        else:
            x = x[-1]
    if x.dim() == 3:
        x = x.unsqueeze(0)
    if x.dim() != 4:
        raise ValueError(f"expected 4D video tensor, got {tuple(frame.shape)}")
    return x


def _placeholder_video_tensor(
    temporal_len: int,
    video_shape: Dict[str, List[int]],
    cam: str,
) -> torch.Tensor:
    """Create a uint8 placeholder that normalizes to -1 on the training GPU."""
    h, w = video_shape[cam][:2]
    return torch.zeros((temporal_len, 3, h, w), dtype=torch.uint8)


def _pad_temporal_bchw(
    tensor: torch.Tensor,
    target_t: int,
    cam: str,
    video_shape: Dict[str, List[int]],
) -> torch.Tensor:
    """Pad or trim ``[T,C,H,W]`` or ``[B,T,C,H,W]`` to fixed per-camera temporal length."""
    if target_t <= 0:
        return tensor
    if tensor.dim() == 5:
        return torch.stack(
            [_pad_temporal_bchw(tensor[i], target_t, cam, video_shape) for i in range(tensor.shape[0])],
            dim=0,
        )
    if tensor.dim() != 4:
        raise ValueError(f"expected 4D/5D video tensor, got {tuple(tensor.shape)}")
    t = tensor.shape[0]
    if t == target_t:
        return tensor
    if t > target_t:
        return tensor[-target_t:]
    pad = _placeholder_video_tensor(target_t - t, video_shape, cam)
    return torch.cat([pad, tensor], dim=0)


class Plannn3NaviPackTransform(BaseTransform):
    """Expand ``raw_data[*].nn3_sidecar['navi_pack']`` into batch tensors."""

    def __call__(self, data_input: Dict[str, Any]) -> Dict[str, Any]:
        raw_data = data_input.get("raw_data")
        if not raw_data:
            return data_input
        navi_infos = []
        subpath_polylines = []
        subpath_masks = []
        navi_labels = []
        traj_min_dist_labels = []
        for rd in raw_data:
            sidecar = rd.get("nn3_sidecar") or {}
            pack = sidecar.get("navi_pack")
            if pack is None:
                raise Plannn3MultimodalTransformError("missing nn3_sidecar navi_pack")
            navi_infos.append(torch.from_numpy(pack["navi_info"]).int())
            subpath_polylines.append(torch.from_numpy(pack["subpath_polylines"]).float())
            subpath_masks.append(torch.from_numpy(pack["subpath_polylines_mask"]).int())
            navi_labels.append(torch.from_numpy(pack["navi_label"]).long())
            label = sidecar.get("traj_min_dist_label", -100)
            traj_min_dist_labels.append(int(label))
        data_input["navi_info"] = torch.stack(navi_infos, dim=0)
        data_input["subpath_polylines"] = torch.stack(subpath_polylines, dim=0)
        data_input["subpath_polylines_mask"] = torch.stack(subpath_masks, dim=0)
        data_input["navi_label"] = torch.stack(navi_labels, dim=0)
        if traj_min_dist_labels:
            data_input["traj_min_dist_label"] = torch.tensor(traj_min_dist_labels, dtype=torch.long)
        return data_input


class Plannn3HistoryTrajPackTransform(BaseTransform):
    """Expand ``raw_data[*].nn3_sidecar['history_traj_pack']`` into batch tensors."""

    def __init__(self, min_waypoints: int = 4):
        self.min_waypoints = min_waypoints

    def __call__(self, data_input: Dict[str, Any]) -> Dict[str, Any]:
        raw_data = data_input.get("raw_data")
        if not raw_data:
            return data_input
        waypoints_list: List[torch.Tensor] = []
        masks_list: List[torch.Tensor] = []
        speed_gaps: List[int] = []
        for rd in raw_data:
            sidecar = rd.get("nn3_sidecar") or {}
            pack = sidecar.get("history_traj_pack")
            if pack is None:
                raise Plannn3MultimodalTransformError("missing nn3_sidecar history_traj_pack")
            waypoints_list.append(torch.from_numpy(pack["his_traj_next_waypoint"]).float())
            masks_list.append(torch.from_numpy(pack["egos_his_mask"]).float())
            speed_gaps.append(int(pack["speed_gap"].reshape(-1)[0]))

        max_len = max(max(w.shape[0] for w in waypoints_list), self.min_waypoints)
        batch_wp: List[torch.Tensor] = []
        batch_mask: List[torch.Tensor] = []
        for wp, mask in zip(waypoints_list, masks_list):
            pad_len = max_len - wp.shape[0]
            if pad_len > 0:
                wp = torch.cat([wp, wp.new_zeros(pad_len, wp.shape[1])], dim=0)
                mask = torch.cat([mask, mask.new_zeros(pad_len)], dim=0)
            batch_wp.append(wp)
            batch_mask.append(mask)

        data_input["his_traj_next_waypoint"] = torch.stack(batch_wp, dim=0)
        data_input["egos_his_mask"] = torch.stack(batch_mask, dim=0)
        data_input["speed_gap"] = torch.tensor(speed_gaps, dtype=torch.long)
        return data_input


class Plannn3VisualDecodeTransform(BaseTransform):
    """Decode ``visual_meta`` to nn3 ``image`` dict ``video:{cam}`` -> ``[B,T,C,H,W]``."""

    _shared_decoder: Optional[Nn3VisualDecoder] = None
    _default_temporal_len = 5

    def __init__(
        self,
        device_id: Optional[int] = None,
        multiview_cams: Optional[List[str]] = None,
        video_shape: Optional[Dict[str, List[int]]] = None,
        crop_shape: Optional[Dict[str, List[int]]] = None,
        inner_resize_crop: bool = False,
        add_black_mask_prob: float = 0.0,
        reuse_decoder: bool = True,
        temporal_len: int = 5,
        temporal_multiview_configs=None,
    ):
        self.device_id = resolve_vt_device_id(device_id)
        self.multiview_cams = list(multiview_cams or DEFAULT_MULTIVIEW_CAMS)
        self.video_shape = video_shape or DEFAULT_VIDEO_SHAPE
        self.crop_shape = crop_shape
        self.inner_resize_crop = inner_resize_crop
        self.add_black_mask_prob = add_black_mask_prob
        self.reuse_decoder = reuse_decoder
        self.temporal_len = temporal_len
        self.temporal_multiview_configs = temporal_multiview_configs or DEFAULT_TEMPORAL_MULTIVIEW_CONFIGS
        self.cam_temporal_counts = compute_cam_temporal_counts(
            self.temporal_multiview_configs,
            self.multiview_cams,
        )
        self._decoder: Optional[Nn3VisualDecoder] = None

    @staticmethod
    def _shared_decoder_required() -> bool:
        return os.getenv("NN3_SHARED_DECODER", "0") in ("1", "true", "True")

    def _get_decoder(self) -> Nn3VisualDecoder:
        if self.reuse_decoder and Plannn3VisualDecodeTransform._shared_decoder is not None:
            return Plannn3VisualDecodeTransform._shared_decoder
        decoder = Nn3VisualDecoder(
            device_id=self.device_id,
            multiview_cams=self.multiview_cams,
            video_shape=self.video_shape,
            crop_shape=self.crop_shape,
            inner_resize_crop=self.inner_resize_crop,
            add_black_mask_prob=self.add_black_mask_prob,
        )
        if self.reuse_decoder:
            Plannn3VisualDecodeTransform._shared_decoder = decoder
        else:
            self._decoder = decoder
        return decoder

    def _decode_one_sample(
        self,
        visual_meta: Optional[Dict[str, Any]],
        index: int,
    ) -> Dict[str, torch.Tensor]:
        """Build per-cam ``[T,C,H,W]`` for one mini-batch item."""
        sample_image: Dict[str, torch.Tensor] = {}
        if visual_meta is None:
            for cam in self.multiview_cams:
                target_t = self.cam_temporal_counts.get(cam, self.temporal_len)
                sample_image[f"video:{cam}"] = _placeholder_video_tensor(
                    target_t, self.video_shape, cam
                )
            return sample_image
        meta_payload = dict(visual_meta)
        meta_payload["index"] = index
        shared_service = Nn3SharedDecoderService.get()
        if shared_service is not None:
            decoded = shared_service.decode(meta_payload)
        else:
            if self._shared_decoder_required():
                raise RuntimeError("NN3 shared decoder is enabled but not attached in this DataLoader worker")
            decoded = self._get_decoder().decode(meta_payload)
        for cam in self.multiview_cams:
            key = f"video:{cam}"
            target_t = self.cam_temporal_counts.get(cam, self.temporal_len)
            if decoded is None or key not in decoded:
                sample_image[key] = _placeholder_video_tensor(target_t, self.video_shape, cam)
            else:
                sample_image[key] = _to_temporal_bchw(decoded[key])
                sample_image[key] = _pad_temporal_bchw(sample_image[key], target_t, cam, self.video_shape)
        return sample_image

    def __call__(self, data_input: Dict[str, Any]) -> Dict[str, Any]:
        raw_data = data_input.get("raw_data")
        if not raw_data:
            return data_input
        if Nn3SharedDecoderService.get() is None:
            if self._shared_decoder_required():
                raise RuntimeError("NN3 shared decoder is enabled but not attached in this DataLoader worker")
            self._get_decoder()
        per_sample_images: List[Dict[str, torch.Tensor]] = []
        decode_ok = []
        traj_min_dist_labels = []
        last_visual_meta = None
        for rd in raw_data:
            sidecar = rd.get("nn3_sidecar") or {}
            traj_min_dist_labels.append(int(sidecar.get("traj_min_dist_label", -100)))
            visual_meta = sidecar.get("visual_meta")
            last_visual_meta = visual_meta
            sample_image = self._decode_one_sample(
                visual_meta,
                rd.get("idx", data_input.get("idx", -1)),
            )
            per_sample_images.append(sample_image)
            decode_ok.append(decoded_ok(sample_image))

        nn3_image: Dict[str, torch.Tensor] = {}
        for cam in self.multiview_cams:
            key = f"video:{cam}"
            nn3_image[key] = torch.stack([sample[key] for sample in per_sample_images], dim=0)
        data_input["nn3_image"] = nn3_image
        data_input["traj_min_dist_label"] = torch.tensor(traj_min_dist_labels, dtype=torch.long)
        data_input["visual_decode_ok"] = torch.tensor(decode_ok, dtype=torch.bool)
        data_input["image_type"] = (
            last_visual_meta.get("image_type", "video") if last_visual_meta else "video"
        )
        return data_input


def decoded_ok(sample_image: Dict[str, torch.Tensor]) -> bool:
    """Return whether at least one decoded pixel is non-placeholder."""
    for tensor in sample_image.values():
        if tensor.dtype == torch.uint8:
            if (tensor > 0).any():
                return True
        elif (tensor > -0.99).any():
            return True
    return False


class Plannn3InferSliceTransform(BaseTransform):
    """Infer slice transform with nn3 navi/visual tensor rollout expansion."""

    _TENSOR_EXPAND_KEYS = (
        "navi_info",
        "subpath_polylines",
        "subpath_polylines_mask",
        "navi_label",
        "traj_min_dist_label",
        "visual_decode_ok",
        "his_traj_next_waypoint",
        "egos_his_mask",
        "speed_gap",
        "ego_polygon_full",
        "ego_polyline_full",
        "ego_property_full",
        "ego_poly_mask_full",
    )

    def __init__(self, rollout_num, env_block_size, history_state_size, history_len):
        self._base = Plannn2InferSliceTransform(
            rollout_num=rollout_num,
            env_block_size=env_block_size,
            history_state_size=history_state_size,
            history_len=history_len,
        )

    def _expand_batch_dim(self, tensor: torch.Tensor, rollout_num: int) -> torch.Tensor:
        if tensor.shape[0] == rollout_num:
            return tensor
        if tensor.shape[0] != 1:
            raise ValueError(
                f"Plannn3InferSliceTransform expects batch size 1 before rollout expand, got {tensor.shape[0]}"
            )
        return tensor.expand(rollout_num, *tensor.shape[1:])

    def __call__(self, data_input: Dict[str, Any]) -> Dict[str, Any]:
        data_input = self._base(data_input)
        rollout_num = self._base.rollout_num

        for key in self._TENSOR_EXPAND_KEYS:
            value = data_input.get(key)
            if isinstance(value, torch.Tensor):
                data_input[key] = self._expand_batch_dim(value, rollout_num)

        nn3_image = data_input.get("nn3_image")
        if isinstance(nn3_image, dict):
            data_input["nn3_image"] = {
                cam_key: self._expand_batch_dim(tensor, rollout_num)
                for cam_key, tensor in nn3_image.items()
                if isinstance(tensor, torch.Tensor)
            }

        return data_input
