# -*- coding: utf-8 -*-

import json
import logging
import os
from typing import ClassVar
from typing import List
from typing import Optional

import numpy as np
import torch
from scipy.fft import dct
from scipy.fft import idct
from sklearn.decomposition import PCA
from tokenizers import ByteLevelBPETokenizer
from tokenizers.trainers import BpeTrainer
from torchpilot.data.transform.base_transform import BaseTransform
from transformers import PreTrainedTokenizerFast
from transformers.processing_utils import ProcessorMixin


class Plannn2InferSliceTransform(BaseTransform):
    """Planner infer slice transform."""

    def __init__(self, rollout_num, env_block_size, history_state_size, history_len):
        """Init."""
        self.drop_ind = env_block_size + history_state_size
        self.rollout_num = rollout_num
        self.history_state_size = history_state_size
        self.history_len = history_len

    def __call__(self, data_input):
        """Call."""
        polygon = data_input["polygons"]
        polyline = data_input["polylines"]
        poly_mask = data_input["polymask"]
        property = data_input["propertys"]

        data_input["polygon_ori"] = polygon.clone()
        data_input["polyline_ori"] = polyline.clone()
        data_input["polymask_ori"] = poly_mask.clone()
        data_input["property_ori"] = property.clone()

        input_polygon = polygon.expand(self.rollout_num, -1, -1, -1)
        input_polyline = polyline.expand(self.rollout_num, -1, -1, -1)
        input_poly_mask = poly_mask.expand(self.rollout_num, -1, -1)
        input_property = property.expand(self.rollout_num, -1, -1)

        data_input["polygons"] = input_polygon
        data_input["polylines"] = input_polyline
        data_input["polymask"] = input_poly_mask
        data_input["propertys"] = input_property

        data_input["dyn_polygons"] = data_input["dyn_polygons"].expand(self.rollout_num, -1, -1, -1, -1)
        data_input["dyn_polylines"] = data_input["dyn_polylines"].expand(self.rollout_num, -1, -1, -1)
        data_input["dyn_polymask"] = data_input["dyn_polymask"].expand(self.rollout_num, -1, -1)
        data_input["dyn_propertys"] = data_input["dyn_propertys"].expand(self.rollout_num, -1, -1)

        data_input["ego_actions"] = data_input["ego_actions"].expand(self.rollout_num, -1)

        data_input["ego_polygon_ori"] = data_input["ego_polygon"].clone()
        data_input["ego_polyline_ori"] = data_input["ego_polyline"].clone()
        data_input["ego_poly_mask_ori"] = data_input["ego_poly_mask"].clone()
        data_input["ego_property_ori"] = data_input["ego_property"].clone()

        data_input["ego_polygon"] = data_input["ego_polygon"][:, : self.history_len].expand(
            self.rollout_num, -1, -1, -1
        )
        data_input["ego_polyline"] = data_input["ego_polyline"][:, : self.history_len].expand(
            self.rollout_num, -1, -1, -1
        )
        data_input["ego_poly_mask"] = data_input["ego_poly_mask"][:, : self.history_len].expand(
            self.rollout_num, -1, -1
        )
        data_input["ego_property"] = data_input["ego_property"][:, : self.history_len].expand(self.rollout_num, -1, -1)

        data_input["ego_actions"] = data_input["ego_actions"][:, []]

        return data_input


class PlannnSegmentMask(BaseTransform):
    """Planner SegmentMask input label transform."""

    def __init__(self, segment_steps=3, history_size=15):
        """Init."""
        self.segment_steps = segment_steps
        self.history_size = history_size

    def __call__(self, data_input):
        """Call."""
        propertys = data_input["ego_property"]  # ego property shape: (B, T, C)
        pred_label = data_input["ego_labels"]
        pred_length = pred_label.shape[1] - self.history_size
        not_keep_indices = [idx for idx in range(pred_length) if (idx + 1) % self.segment_steps != 0]
        pred_not_keep_indices = [idx + self.history_size for idx in not_keep_indices]
        # mask 掉不保留的帧
        propertys[:, pred_not_keep_indices, 0] = 0
        data_input["ego_property"] = propertys
        return data_input


class Plannn2SeqOdIdShuffle(BaseTransform):
    """Planner SeqOdIdShuffle transform."""

    def __init__(self):
        """Init."""
        pass

    def __call__(self, data_input):
        """Call."""
        if "dyn_propertys" not in data_input:
            return data_input
        dyn_propertys = data_input["dyn_propertys"]
        for mini_batch_index in range(dyn_propertys.shape[0]):
            dyn_property = dyn_propertys[mini_batch_index]
            valid_indices = dyn_property[:, 0] != 0
            od_ids = dyn_property[valid_indices, 3]
            od_ids_shuffle = od_ids[torch.randperm(od_ids.shape[0])]
            dyn_property[valid_indices, 3] = od_ids_shuffle
            dyn_propertys[mini_batch_index] = dyn_property
        data_input["dyn_propertys"] = dyn_propertys

        return data_input


class Plannn2MaskHistEgoLabel(BaseTransform):
    """Planner MaskHistEgoLabel transform."""

    def __init__(self, history_len):
        """Init."""
        self.history_len = history_len

    def __call__(self, data_input):
        """Call."""
        ego_labels = data_input["ego_labels"]
        ego_labels[:, : self.history_len - 1] = -1

        data_input["ego_labels"] = ego_labels

        return data_input


class Plannn2DCTTokenGen(BaseTransform):
    """Plannn2 DCT token."""

    def __init__(self, tokenizer_path, max_token_len):
        """Init."""
        self.tokenizer_path = tokenizer_path
        self.max_token_len = max_token_len

        self.vehicle_tokenizer = UniversalActionProcessor.from_pretrained(tokenizer_path, trust_remote_code=True)

        self.vehicle_tokenizer.mean_val = np.array(self.vehicle_tokenizer.mean_val)
        self.vehicle_tokenizer.std_val = np.array(self.vehicle_tokenizer.std_val)

    def __call__(self, data_input):
        """Call."""
        ego_seq = np.array(data_input["ego_seq"])

        label_ids = [self.vehicle_tokenizer(ego_seq_i)[0] for ego_seq_i in ego_seq]
        # 补齐长度

        for label_id in label_ids:
            if len(label_id) < self.max_token_len:
                label_id.append(0)  # 增加<EOS>
                label_id.extend([1] * (self.max_token_len - len(label_id)))  # 补齐长度

        state_labels = np.array(label_ids)

        data_input["ego_labels"] = torch.tensor(state_labels).long()
        data_input["ego_actions"] = torch.tensor(state_labels[:, :-1]).long()

        return data_input


class Plannn2PCATokenGen(BaseTransform):
    """Plannn2 DCT token."""

    def __init__(self, tokenizer_path, max_token_len):
        """Init."""
        self.pca_tokenizer = PCATokenizer(tokenizer_path)
        self.max_token_len = max_token_len

    def __call__(self, data_input):
        """Call."""
        #get future acc/kappa
        ego_seq = np.array(data_input["ego_seq"])
        ego_seq = ego_seq[:,14:,:]
        if ego_seq.shape[1] > 25:
            ego_seq = ego_seq[:, :25, :]

        label_ids = self.pca_tokenizer(ego_seq, num_components=self.max_token_len)

        state_labels = np.array(label_ids)

        motion_label = torch.tensor([[d["latitude_label"],d["longitude_label"]] for d in data_input["raw_data"]]).long()

        ego_labels = torch.tensor(state_labels).long()
        data_input["ego_labels"] = torch.cat((motion_label, ego_labels), dim=1)
        data_input["ego_actions"] = data_input["ego_labels"][:, :-1]

        return data_input


class PadEmptyEgoActions(BaseTransform):
    """Pad empty actions."""

    def __init__(self):
        """Init."""
        pass

    def __call__(self, data_input):
        """Call."""
        data_input["ego_actions"] = data_input["ego_actions"][:, []]

        return data_input


class Plannn2PCAEgoHistoryTokenize(BaseTransform):
    """PCA Ego hist tokenize."""

    def __init__(self, tokenizer_path, max_token_len, state_range, history_length):
        """Init."""
        self.pca_tokenizer = PCATokenizer(tokenizer_path)
        self.max_token_len = max_token_len
        self.state_range = state_range
        self.history_length = history_length

    @staticmethod
    def augment_dxdydyaw(
        seq,
        dt=0.2,
        p_mirror=0.2,
        p_noise=0.5,
        p_dropout=0.1,
        dropout_rate=0.1,          # 每个 time step 被置零的概率（在触发 dropout 后）
        pos_noise_ratio=0.01,      # 位置噪声比例：sigma = pos_noise_ratio * speed_per_step
        yaw_noise_sigma=0.002,     # yaw 噪声（每步，单位 rad）
        vmax_mps=30.0,             # 最大车速 (m/s)，用于 clip
        yaw_rate_max=1.0           # 最大偏航角速度 (rad/s)，用于 clip
    ):
        """
        seq: (T,3) or (B,T,3), last dim is [dx, dy, dyaw] in ego frame
        return: same shape as seq
        """
        x = np.asarray(seq, dtype=np.float32)
        orig_ndim = x.ndim
        if orig_ndim == 2:
            x = x[None, ...]  # -> (1,T,3)
        assert x.ndim == 3 and x.shape[-1] == 3, f"expected (T,3) or (B,T,3), got {x.shape}"

        B, T, _ = x.shape
        dx = x[..., 0]
        dy = x[..., 1]
        dyaw = x[..., 2]

        # ========= 1) 左右镜像（ego 下推荐）=========
        # mirror: dy -> -dy, dyaw -> -dyaw
        mirror_on = (np.random.rand(B, 1) < p_mirror).astype(np.float32)  # (B,1)
        mirror_sign = 1.0 - 2.0 * mirror_on                               # 1 or -1
        dy = dy * mirror_sign
        dyaw = dyaw * mirror_sign

        # ========= 2) 噪声（速度相关）=========
        noise_on = (np.random.rand(B, 1) < p_noise).astype(np.float32)    # (B,1)
        speed = np.sqrt(dx * dx + dy * dy) + 1e-6                         # (B,T)
        pos_sigma = pos_noise_ratio * speed                               # (B,T)

        dx = dx + (np.random.randn(B, T).astype(np.float32) * pos_sigma) * noise_on
        dy = dy + (np.random.randn(B, T).astype(np.float32) * pos_sigma) * noise_on
        dyaw = dyaw + (np.random.randn(B, T).astype(np.float32) * yaw_noise_sigma) * noise_on

        # ========= 3) 时间 dropout（模拟丢帧/卡顿）=========
        dropout_on = (np.random.rand(B, 1) < p_dropout)                   # (B,1) bool
        drop_mask = dropout_on & (np.random.rand(B, T) < dropout_rate)     # (B,T) bool
        keep = (~drop_mask).astype(np.float32)                             # 1 keep, 0 drop

        dx = dx * keep
        dy = dy * keep
        dyaw = dyaw * keep

        # ========= 4) 物理约束 clip（按 dt）=========
        max_step_dist = vmax_mps * dt                # 每步最大位移（m/step）
        max_step_dyaw = yaw_rate_max * dt            # 每步最大 yaw 增量（rad/step）

        speed2 = np.sqrt(dx * dx + dy * dy) + 1e-6
        scale = np.minimum(1.0, max_step_dist / speed2).astype(np.float32)  # (B,T)

        dx = dx * scale
        dy = dy * scale
        dyaw = np.clip(dyaw, -max_step_dyaw, max_step_dyaw)

        out = np.stack([dx, dy, dyaw], axis=-1)  # (B,T,3)
        if orig_ndim == 2:
            out = out[0]
        return out

    def __call__(self, data_input):
        """Call."""

        ego_property_full_origin_history = data_input["ego_property"].clone()

        #get history acc/kappa
        ego_seq = np.array(data_input["ego_seq"])
        ego_seq = ego_seq[:,:14,:]
        ego_history_token = self.pca_tokenizer(ego_seq, num_components=self.max_token_len)[:, :7]

        ego_new_property = ego_property_full_origin_history[:, -7:]
        ego_new_property[:, :, -3] = torch.from_numpy(ego_history_token).long()
        values = torch.from_numpy(np.arange(self.history_length - ego_new_property.shape[1], self.history_length)).long()
        ego_new_property[:, :, 4] = values

        ego_polygon = data_input["ego_polygon"][:, -1:, :, :]
        ego_polygon = torch.cat((ego_polygon, torch.zeros((ego_polygon.shape[0], 7, 4, 2))), dim=1)
        ego_polyline = torch.cat((data_input["ego_polyline"][:, -1:, :, :], data_input["ego_polyline"][:, -7:, :, :]), dim=1)
        ego_property = data_input["ego_property"][:, -1:, :]
        ego_property = torch.cat((ego_property, ego_new_property), dim=1)
        ego_poly_mask = torch.cat((data_input["ego_poly_mask"][:, -1:, :], data_input["ego_poly_mask"][:, -7:, :]), dim=1)

        data_input["ego_polygon"] = ego_polygon
        data_input["ego_property"] = ego_property
        data_input["ego_polyline"] = ego_polyline
        data_input["ego_poly_mask"] = ego_poly_mask

        return data_input

    def polygons_to_incremental_dxdydyaw(self, polygons):
        """
        将绝对坐标的 Polygons 转换为 增量 dxdydyaw (Diff).

        Args:
            polygons: [T+1, 4, 2] numpy array. (例如 [26, 4, 2])
                    包含 t=0 到 t=T 的绝对位置。
                    角点顺序: 0-右下, 1-右上, 2-左上, 3-左下

        Returns:
            deltas:   [T, 3] numpy array. (例如 [25, 3])
                    deltas[t] = pose[t+1] - pose[t]
                    包含了 dx, dy, dyaw
        """
        if polygons.ndim != 3 or polygons.shape[1] != 4 or polygons.shape[2] != 2:
            raise ValueError(f"Input shape must be [T+1, 4, 2], got {polygons.shape}")

        centers = np.mean(polygons, axis=1)

        # 航向角
        # 前边缘中点 (1:FR, 2:FL)
        front_edge = (polygons[:, 1, :] + polygons[:, 2, :]) / 2.0
        # 后边缘中点 (0:RR, 3:RL)
        rear_edge = (polygons[:, 0, :] + polygons[:, 3, :]) / 2.0

        heading_vec = front_edge - rear_edge
        yaws = np.arctan2(heading_vec[:, 1], heading_vec[:, 0])

        dx_global = centers[1:, 0] - centers[:-1, 0]  # [T]
        dy_global = centers[1:, 1] - centers[:-1, 1]  # [T]

        yaws_t = yaws[:-1]
        cos_yaws = np.cos(yaws_t)
        sin_yaws = np.sin(yaws_t)

        dx_local = cos_yaws * dx_global + sin_yaws * dy_global  # [T]
        dy_local = -sin_yaws * dx_global + cos_yaws * dy_global  # [T]

        dyaws_absolute = yaws[1:] - yaws[:-1]
        dyaws = np.arctan2(np.sin(dyaws_absolute), np.cos(dyaws_absolute))  # [T]

        deltas = np.column_stack([dx_local, dy_local, dyaws])  # [T, 3]

        return deltas


class SetOtherTokenPCAProperty(BaseTransform):
    """Set other token property."""

    def __init__(self, fill_num):
        """Init"""
        self.fill_num = fill_num

    def __call__(self, data_dict):
        """Call."""
        env_property = data_dict["propertys"]
        dyn_property = data_dict["dyn_propertys"]

        env_property[:, :, 9] = self.fill_num
        dyn_property[:, :, 9] = self.fill_num

        data_dict["propertys"] = env_property
        data_dict["dyn_propertys"] = dyn_property

        data_dict["ego_property"][:, 0, 9] = self.fill_num

        return data_dict


class PCATokenizer:
    def __init__(self, config_path=None):
        """
        初始化 Tokenizer。
        如果提供了 config_path (json文件路径)，则自动加载模型。
        """
        self.params = {}
        self.is_fitted = False
        self.vocab_size = None

        if config_path:
            self.load_model(config_path)

    def fit(self, data, mean_val, std_val, save_json_path=None, n_components=20, n_bins=1024, scales=(1.0, 1.0)):
        """
        训练 PCA 和量化参数。

        Args:
            data: [N, 25, 2] 的 acc kappa 数据 (numpy array)
            mean_val: [1, 1, 2] 均值
            std_val:  [1, 1, 2] 标准差
            save_json_path: 保存配置的 json 路径
            n_components: 保留的主成分数量
            n_bins: 量化桶数量
            scales: (acc_scale, kappa_scale) 人工设定的缩放因子
        """
        print(f"开始训练 PCATokenizer... 数据形状: {data.shape}")

        # 1. 维度检查
        if data.shape[-1] != 2:
            raise ValueError(f"输入数据最后一维应该是 2 (acc,kappa)，实际是 {data.shape[-1]}")

        # 2. 标准化 (Z-Score)
        data_norm = (data - mean_val) / (std_val + 1e-8)

        # 3. 物理缩放 [1, 1, 2]
        scale_arr = np.array(scales).reshape(1, 1, 2)
        data_scaled = data_norm * scale_arr

        print("\n缩放后数据统计:")
        print(f"ACC.   列 - Min: {np.min(data_scaled[..., 0]):.4f}, Max: {np.max(data_scaled[..., 0]):.4f}")
        print(f"KAPPA  列 - Min: {np.min(data_scaled[..., 1]):.4f}, Max: {np.max(data_scaled[..., 1]):.4f}")

        # 4. 展平 (Flatten) -> [N, 25*3=75]
        N, T, C = data.shape
        data_flat = data_scaled.reshape(N, -1)

        # 5. PCA 拟合
        pca = PCA(n_components=n_components)
        pca.fit(data_flat)

        # 获取 PCA 系数 [N, n_components] 用以计算量化边界
        latent_codes = pca.transform(data_flat)

        # 6. 计算量化边界 (Percentile Clipping)
        q_min = np.quantile(latent_codes, 0.001, axis=0)  # 0.1%
        q_max = np.quantile(latent_codes, 0.999, axis=0)  # 99.9%
        q_max = np.maximum(q_max, q_min + 1e-6)  # 防止除零

        # 7. 保存参数到内存
        self.params = {
            # 基础统计量
            "data_mean": mean_val,
            "data_std": std_val,
            "scales": scale_arr,
            "original_shape": [T, C],  # [25, 3]
            # PCA 核心参数
            "pca_components": pca.components_,  # [n_components, 75] -> npy
            "pca_mean": pca.mean_,  # [75] -> json
            # 量化参数
            "q_min": q_min,
            "q_max": q_max,
            "n_bins": n_bins,
            "n_components": n_components,
        }

        self.is_fitted = True
        self.vocab_size = n_bins
        print(f"训练完成。保留主成分: {n_components}, 解释方差比: {np.sum(pca.explained_variance_ratio_):.4f}")

        if save_json_path:
            self.save_model(save_json_path)

    def __call__(self, trajectory, num_components=7):
        """Encode: [..., 25, 2] -> [..., n_components] (Token IDs)"""
        if not self.is_fitted:
            raise RuntimeError("Tokenizer 未训练")

        x = np.array(trajectory)
        input_shape = x.shape

        target_k = num_components if num_components is not None else self.params["n_components"]

        # 1. 预处理
        x_norm = (x - self.params["data_mean"]) / (self.params["data_std"] + 1e-8)
        x_scaled = x_norm * self.params["scales"]
        x_flat = x_scaled.reshape(*input_shape[:-2], -1)

        # 2. PCA 投影 (纯 Numpy 实现)
        # (X - mu) @ V.T
        x_centered = x_flat - self.params["pca_mean"]
        latent = np.dot(x_centered, self.params["pca_components"][:target_k].T)

        # 3. 量化
        return self._quantize(latent, num_components=target_k)

    def decode(self, token_ids, num_components=None):
        """Decode: [..., n_components] (Token IDs) -> [..., 25, 2]"""
        if not self.is_fitted:
            raise RuntimeError("Tokenizer 未训练")

        token_ids = np.array(token_ids)
        target_k = num_components if num_components is not None else token_ids.shape[-1]

        # 截断输入以匹配 target_k
        token_ids = token_ids[..., :target_k]

        # 1. 反量化
        latent = self._dequantize(token_ids, num_components=target_k)

        # 2. PCA 重构
        # Z @ V + mu
        x_recon_flat = np.dot(latent, self.params["pca_components"][:target_k]) + self.params["pca_mean"]

        # 3. 后处理
        current_batch_dims = list(token_ids.shape[:-1])
        ori_shape_dims = list(self.params["original_shape"])  # [25, 2]
        target_shape = current_batch_dims + ori_shape_dims

        x_recon_scaled = x_recon_flat.reshape(target_shape)

        x_recon_norm = x_recon_scaled / self.params["scales"]
        x_recon = x_recon_norm * (self.params["data_std"] + 1e-8) + self.params["data_mean"]

        return x_recon

    def _quantize(self, latent_codes, num_components):
        q_min = self.q_min
        q_max = self.q_max
        n_bins = self.params["n_bins"]

        codes_clipped = np.clip(latent_codes, q_min, q_max)
        codes_norm = (codes_clipped - q_min) / (q_max - q_min)
        ids = np.round(codes_norm * (n_bins - 1)).astype(np.int32)
        return np.clip(ids, 0, n_bins - 1)

    def _dequantize(self, ids, num_components):
        q_min = self.q_min
        q_max = self.q_max
        n_bins = self.params["n_bins"]

        ids = ids.astype(np.float32)
        codes_norm = ids / (n_bins - 1)
        return codes_norm * (q_max - q_min) + q_min

    def save_model(self, json_path):
        """
        保存模型：
        1. pca_components 保存为同名 _basis.npy
        2. 其他参数保存为 .json
        """
        if not self.is_fitted:
            raise RuntimeError("模型未训练，无法保存")

        # 1. 准备路径
        base_name = os.path.splitext(json_path)[0]
        npy_path = base_name + "_basis.npy"

        # 2. 保存大矩阵到 npy
        np.save(npy_path, self.params["pca_components"])
        print(f"PCA基矩阵已保存至: {npy_path}")

        # 3. 准备 JSON 数据 (numpy -> list)
        json_dict = {}
        for k, v in self.params.items():
            if k == "pca_components":
                continue  # 已经在 npy 里了

            if isinstance(v, np.ndarray):
                json_dict[k] = v.tolist()
            else:
                json_dict[k] = v

        json_dict["basis_file"] = os.path.basename(npy_path)

        with open(json_path, "w") as f:
            json.dump(json_dict, f, indent=4)
        print(f"Token配置已保存至: {json_path}")

    def load_model(self, json_path):
        """
        加载模型
        """
        if not os.path.exists(json_path):
            raise FileNotFoundError(f"找不到配置文件: {json_path}")

        # 1. 加载 JSON
        with open(json_path, "r") as f:
            json_dict = json.load(f)

        self.params = {}
        basis_filename = json_dict.pop("basis_file", None)

        # 2. 还原参数
        for k, v in json_dict.items():
            if k == "original_shape":
                self.params[k] = list(v)
            elif isinstance(v, list):
                self.params[k] = np.array(v)
            else:
                self.params[k] = v

        # 3. 加载 NPY 基矩阵
        if basis_filename:
            npy_path = os.path.join(os.path.dirname(json_path), basis_filename)
            if not os.path.exists(npy_path):
                raise FileNotFoundError(f"配置文件引用了 {basis_filename}，但在 {npy_path} 未找到")

            self.params["pca_components"] = np.load(npy_path)
        else:
            raise ValueError("JSON 文件中缺少 'basis_file' 字段，无法加载 PCA 基")

        self.is_fitted = True
        self.vocab_size = self.params["n_bins"]
        self.time_horizon = self.params["original_shape"][0]
        self.action_dim = self.params["original_shape"][1]
        self.q_min = min(self.params["q_min"])
        self.q_max = max(self.params["q_max"])

        print(f"Tokenizer 加载成功 | Config: {json_path} | Basis: {basis_filename}")


class UniversalActionProcessor(ProcessorMixin):
    attributes: ClassVar[List[str]] = ["bpe_tokenizer"]
    bpe_tokenizer_class: str = "AutoTokenizer"

    def __init__(
        self,
        bpe_tokenizer: PreTrainedTokenizerFast,
        scale: float = 10,
        vocab_size: int = 1024,
        min_token: int = 0,
        *,
        action_dim: Optional[int] = None,
        time_horizon: Optional[int] = None,
        mean_val: Optional[List] = None,
        std_val: Optional[List] = None,
    ):
        self.scale = scale
        self.vocab_size = vocab_size
        self.min_token = min_token

        # Action horizon and dimension needed during decoding. These can be specified
        # in three ways (in order of priority):
        # 1. passed in as kwargs to decode()
        # 2. in the constructor
        # 3. cached from the last time decode() was called
        self.time_horizon = time_horizon
        self.action_dim = action_dim
        self.called_time_horizon = time_horizon
        self.called_action_dim = action_dim

        self.mean_val = mean_val
        self.std_val = std_val

        self.mean_val = mean_val
        self.std_val = std_val

        super().__init__(bpe_tokenizer)

    def __call__(self, action_chunk: np.array) -> np.array:
        assert action_chunk.ndim <= 3, "Only 3 dimensions supported: [batch, timesteps, action_dim]"
        if action_chunk.ndim == 2:
            action_chunk = action_chunk[None, ...]

        # action trunk normalization
        action_chunk_norm = (action_chunk - self.mean_val) / (self.std_val + 1e-8)

        # Cache the time horizon and action dimension for decoding
        self.called_time_horizon = action_chunk_norm.shape[-2]
        self.called_action_dim = action_chunk_norm.shape[-1]

        dct_coeff = dct(action_chunk_norm, axis=1, norm="ortho")
        dct_coeff = np.around(dct_coeff * self.scale)
        dct_coeff = dct_coeff[:, :5]
        tokens = []
        for elem in dct_coeff:
            token_str = "".join(map(chr, np.maximum(elem.flatten() - self.min_token, 0).astype(int)))
            tokens.append(self.bpe_tokenizer(token_str, max_length=40, truncation=True)["input_ids"])
        return tokens

    def decode(
        self,
        tokens: List[List[int]],
        *,
        time_horizon: Optional[int] = None,
        action_dim: Optional[int] = None,
    ) -> np.array:
        self.time_horizon = time_horizon or self.time_horizon or self.called_time_horizon
        self.action_dim = action_dim or self.action_dim or self.called_action_dim

        # Cache the time horizon and action dimension for the next call
        self.called_time_horizon = self.time_horizon
        self.called_action_dim = self.action_dim

        assert (
            self.time_horizon is not None and self.action_dim is not None
        ), "Tokenizer not initialized, call encode() once or pass in time_horizon and action_dim."

        decoded_actions = []
        for token in tokens:
            try:
                decoded_tokens = self.bpe_tokenizer.decode(token)
                decoded_dct_coeff = np.array(list(map(ord, decoded_tokens))) + self.min_token
                # decoded_dct_coeff = decoded_dct_coeff.reshape(-1, self.action_dim)

                target_len = self.time_horizon * self.action_dim
                cur_len = decoded_dct_coeff.size

                if cur_len < target_len:
                    # 不够 → 补 0
                    pad = target_len - cur_len
                    decoded_dct_coeff = np.concatenate(
                        [decoded_dct_coeff, np.zeros(pad, dtype=decoded_dct_coeff.dtype)]
                    )
                # else:
                #     # 太多 → 截断
                #     decoded_dct_coeff = decoded_dct_coeff[:target_len]

                # reshape 成 [T, action_dim]
                decoded_dct_coeff = decoded_dct_coeff.reshape(self.time_horizon, self.action_dim)

                assert decoded_dct_coeff.shape == (
                    self.time_horizon,
                    self.action_dim,
                ), f"Decoded DCT coefficients have shape {decoded_dct_coeff.shape}, expected ({self.time_horizon}, {self.action_dim})"
            except Exception as e:
                print(f"Error decoding tokens: {e}")
                print(f"Tokens: {token}")
                decoded_dct_coeff = np.zeros((self.time_horizon, self.action_dim))
            decoded_actions.append(idct(decoded_dct_coeff / self.scale, axis=0, norm="ortho"))

        decoded_actions = decoded_actions * self.std_val + self.mean_val  # 返归一化

        return np.stack(decoded_actions)

    @classmethod
    def fit(
        cls,
        action_data: List[np.array],
        scale: float = 10,
        vocab_size: int = 1024,
        *,
        time_horizon: Optional[int] = None,
        action_dim: Optional[int] = None,
        n_dct_coeff: int = None,
        mean_val: Optional[List] = None,
        std_val: Optional[List] = None,
    ) -> "UniversalActionProcessor":
        # Run DCT over all inputs and clip
        if n_dct_coeff is None:
            n_dct_coeff = time_horizon

        dct_tokens = [dct(a, axis=0, norm="ortho")[:n_dct_coeff].flatten() for a in action_data]

        # Quantize and find min token
        max_token = int(np.around(np.concatenate(dct_tokens) * scale).max())
        min_token = int(np.around(np.concatenate(dct_tokens) * scale).min())
        min_vocab_size = max_token - min_token

        assert (
            min_vocab_size <= vocab_size
        ), f"Vocab size {vocab_size} is too small for the range of tokens {min_vocab_size}"
        if min_vocab_size + 100 > vocab_size:
            logging.warning(
                f"Initial alphabet size {min_vocab_size} is almost as large as the vocab"
                f"size {vocab_size}, consider increasing vocab size"
            )

        # Make token iterator for BPE training
        def _token_iter():
            for tokens in dct_tokens:
                rounded_tokens = np.around(tokens * scale) - min_token
                rounded_tokens = rounded_tokens.astype(int)
                string = "".join(map(chr, rounded_tokens))
                yield string

        # Train BPE tokenizer
        bpe = ByteLevelBPETokenizer()

        # Set up the entire range of possible tokens as the initial alphabet
        alphabet = [chr(i) for i in range(max_token - min_token + 1)]
        trainer = BpeTrainer(
            vocab_size=vocab_size,
            min_frequency=2,
            show_progress=True,
            special_tokens=["<EOS>", "<PAD>"],
            initial_alphabet=alphabet,
            max_token_length=10000,
        )

        # Train the inner tokenizer (don't use ByteLevelBPETokenizer.train_from_iterator()
        # because it doesn't support custom alphabets)
        bpe._tokenizer.train_from_iterator(_token_iter(), trainer=trainer)

        return cls(
            PreTrainedTokenizerFast(tokenizer_object=bpe, clean_up_tokenization_spaces=False),
            scale=scale,
            vocab_size=vocab_size,
            min_token=min_token,
            time_horizon=time_horizon,
            action_dim=action_dim,
            mean_val=mean_val,
            std_val=std_val,
        )
