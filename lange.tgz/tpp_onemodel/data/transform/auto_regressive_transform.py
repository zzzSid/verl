# -*- coding: utf-8 -*-
import pickle
from copy import copy

import numpy as np
import scipy
import scipy.spatial
from torchpilot.data.transform.base_transform import BaseTransform


class EgoStateTransform(BaseTransform):
    """Ego state transform."""

    def __init__(self):
        """Init."""
        super().__init__()

    def __call__(self, data_input):
        """Call."""
        history_ego_motion = data_input["history"]["ego_motion"]
        current_ego_motion = data_input["current"]["ego_motion"]
        future_ego_motion = data_input["future"]["ego_motion"]

        history_velocity = np.array([em[0] for em in history_ego_motion])
        current_velocity = np.array([em[0] for em in current_ego_motion])
        future_velocity = np.array([em[0] for em in future_ego_motion])

        current_yaw = np.array([em[4] for em in current_ego_motion])
        history_yaw = np.array([em[4] for em in history_ego_motion]) - current_yaw[0]
        future_yaw = np.array([em[4] for em in future_ego_motion]) - current_yaw[0]
        current_yaw = current_yaw - current_yaw[0]

        ego_velocity = {"history": history_velocity, "current": current_velocity, "future": future_velocity}

        ego_pos = self.get_ego_pos_traj(data_input)

        ego_state_velocity = np.concatenate([ego_velocity["history"], ego_velocity["current"], ego_velocity["future"]])
        ego_state_yaw = np.concatenate([history_yaw, current_yaw, future_yaw])
        ego_state_pos = np.concatenate([ego_pos["history"], ego_pos["current"], ego_pos["future"]])

        # pos_x, pos_y, velocity
        data_input["ar_ego_state"] = np.concatenate(
            [ego_state_pos, ego_state_yaw[:, None], ego_state_velocity[:, None]], axis=1
        )[
            None, :, :
        ]  # [A(1), T, 4]

        egos_future_padding_mask = np.array(data_input["future"]["egos_padding_mask"])
        data_input["ar_ego_future_mask"] = egos_future_padding_mask

        return data_input

    def get_ego_pos_traj(self, data_input):
        """Get ego position trajectory."""
        current_car_pose = data_input["current"]["car_poses"]
        future_car_pose = data_input["future"]["car_poses"]
        history_car_pose = data_input["history"]["car_poses"]

        hist2cur_trans_mat = np.einsum("ijk, mkl->mjl", np.linalg.inv(current_car_pose), history_car_pose)
        fur2cur_trans_mat = np.einsum("ijk, mkl->mjl", np.linalg.inv(current_car_pose), future_car_pose)

        history_ego_pos_zeros = np.zeros((history_car_pose.shape[0], 1, 3))
        future_ego_pos_zeros = np.zeros((future_car_pose.shape[0], 1, 3))

        history_ego_pos_zeros_padding = np.concatenate(
            (history_ego_pos_zeros, np.ones((history_ego_pos_zeros.shape[0], history_ego_pos_zeros.shape[1], 1))),
            axis=2,
        )
        future_ego_pos_zeros_padding = np.concatenate(
            (future_ego_pos_zeros, np.ones((future_ego_pos_zeros.shape[0], future_ego_pos_zeros.shape[1], 1))), axis=2
        )

        hist_traj = np.einsum("ijk,imk->imj", hist2cur_trans_mat, history_ego_pos_zeros_padding)[:, 0, :2]
        fur_traj = np.einsum("ijk,imk->imj", fur2cur_trans_mat, future_ego_pos_zeros_padding)[:, 0, :2]
        cur_traj = np.zeros((current_car_pose.shape[0], 2))

        return {"history": hist_traj, "current": cur_traj, "future": fur_traj}


class EgoActionTransform(BaseTransform):
    """Ego action transform."""

    def __init__(self, kmeans_path=None, soft_label_sigma=0.01):
        """Init."""
        super().__init__()
        self.soft_label_sigma = soft_label_sigma
        with open(kmeans_path, "rb") as f:
            pkl_content = pickle.load(f)
            if "kdisk" not in pkl_content:
                self.kmeans = pkl_content["kmeans"]
            else:
                self.kmeans = None
                self.kmeans_centers = pkl_content["merge_center"]
            self.ratio = pkl_content["ratio"]
            self.acc_range_min = pkl_content["acc_range"][0]
            self.acc_range_max = pkl_content["acc_range"][1]
            self.yaw_rate_range_min = pkl_content["yaw_rate_range"][0]
            self.yaw_rate_range_max = pkl_content["yaw_rate_range"][1]
        if self.kmeans is not None:
            self.kmeans_centers = self.kmeans.cluster_centers_

    def __call__(self, data_input):
        """Call."""
        history_ego_motion = data_input["history"]["ego_motion"]
        current_ego_motion = data_input["current"]["ego_motion"]
        future_ego_motion = data_input["future"]["ego_motion"]

        history_yaw = np.array([em[4] for em in history_ego_motion])
        current_yaw = np.array([em[4] for em in current_ego_motion])
        future_yaw = np.array([em[4] for em in future_ego_motion])
        yaw = np.concatenate([current_yaw, future_yaw])
        yaw_all = np.concatenate([history_yaw, current_yaw, future_yaw])

        history_vx = np.array([em[0] for em in history_ego_motion])
        current_vx = np.array([em[0] for em in current_ego_motion])
        future_vx = np.array([em[0] for em in future_ego_motion])
        vx = np.concatenate([current_vx, future_vx])
        vx_all = np.concatenate([history_vx, current_vx, future_vx])

        history_timestamp = data_input["history"]["timestamps"]
        current_timestamp = data_input["current"]["timestamps"]
        future_timestamp = data_input["future"]["timestamps"]
        timestamps = np.array(current_timestamp + future_timestamp)
        timestamp_diff = timestamps[1:] - timestamps[:-1]
        timestamps_all = np.array(history_timestamp + current_timestamp + future_timestamp)
        timestamp_diff_all = timestamps_all[1:] - timestamps_all[:-1]

        acc = (vx[1:] - vx[:-1]) / timestamp_diff
        acc_all = (vx_all[1:] - vx_all[:-1]) / timestamp_diff_all

        delta_yaw = np.mod((yaw[1:] - yaw[:-1]) + np.pi, 2 * np.pi) - np.pi
        yaw_rate = delta_yaw / timestamp_diff
        delta_yaw_all = np.mod((yaw_all[1:] - yaw_all[:-1]) + np.pi, 2 * np.pi) - np.pi
        yaw_rate_all = delta_yaw_all / timestamp_diff_all

        acc_norm = (acc - self.acc_range_min) / (self.acc_range_max - self.acc_range_min)
        yaw_rate_norm = (yaw_rate - self.yaw_rate_range_min) / (self.yaw_rate_range_max - self.yaw_rate_range_min)
        acc_norm_all = (acc_all - self.acc_range_min) / (self.acc_range_max - self.acc_range_min)
        yaw_rate_norm_all = (yaw_rate_all - self.yaw_rate_range_min) / (
            self.yaw_rate_range_max - self.yaw_rate_range_min
        )

        action = np.stack([acc_norm, yaw_rate_norm], axis=1)
        action_all = np.stack([acc_norm_all, yaw_rate_norm_all], axis=1)

        # Raw Label
        relative_to_center = scipy.spatial.distance.cdist(action, self.kmeans_centers)
        relative_to_center_all = scipy.spatial.distance.cdist(action_all, self.kmeans_centers)
        ego_action_vocab = np.argmin(relative_to_center, axis=1)
        ego_action_vocab_all = np.argmin(relative_to_center_all, axis=1)

        # Soft Label
        yaw_rate_weight = 1
        relative_to_center_l1 = np.abs(action[:, None, :] - self.kmeans_centers[None, :, :])
        relative_to_center = relative_to_center_l1[..., 0] + yaw_rate_weight * relative_to_center_l1[..., 1]  # [T,512]
        relative_to_center_l1_all = np.abs(action_all[:, None, :] - self.kmeans_centers[None, :, :])
        relative_to_center_all = relative_to_center_l1_all[..., 0] + yaw_rate_weight * relative_to_center_l1_all[..., 1]

        # For debug:
        # import torch
        # center_yaw_rate = (
        #     self.kmeans_centers[:, 1] * (self.yaw_rate_range_max - self.yaw_rate_range_min) + self.yaw_rate_range_min
        # )
        # center_acc = self.kmeans_centers[:, 0] * (self.acc_range_max - self.acc_range_min) + self.acc_range_min
        # center_acc_yaw_rate = np.stack([center_acc, center_yaw_rate], axis=1)
        # center_acc_yaw_rate[torch.tensor(-relative_to_center).topk(10, -1)[1][20].cpu().numpy()]

        # Gaussian kernel: exp(-d^2 / (2 * sigma^2))
        sigma = self.soft_label_sigma  # sigma越大，越soft
        soft_labels = np.exp(-(relative_to_center**2) / (2 * sigma**2))
        # Normalize to sum to 1 across each row (each timestep)
        soft_labels /= np.sum(soft_labels, axis=1, keepdims=True) + 1e-8
        # torch.tensor(soft_labels)[20].topk(10, -1)
        soft_labels_all = np.exp(-(relative_to_center_all**2) / (2 * sigma**2))
        soft_labels_all /= np.sum(soft_labels_all, axis=1, keepdims=True) + 1e-8

        if np.any(np.isnan(acc)):  # for infer with clip padding
            acc_norm[np.isnan(acc)] = 0.0
            yaw_rate_norm[np.isnan(yaw_rate)] = 0.0
            ego_action_vocab[np.isnan(acc)] = 0
            ego_action_vocab_all[np.isnan(acc_all)] = 0
            acc_norm_all[np.isnan(acc_all)] = 0.0
            yaw_rate_norm_all[np.isnan(yaw_rate_all)] = 0.0
            soft_labels[np.isnan(acc)] = 0.0
            soft_labels_all[np.isnan(acc_all)] = 0.0

        data_input["ar_ego_action_vocab"] = ego_action_vocab
        data_input["ar_ego_action_norm"] = np.stack([acc_norm, yaw_rate_norm], axis=1)
        data_input["ar_ego_action_vocab_all"] = ego_action_vocab_all
        data_input["ar_ego_action_norm_all"] = np.stack([acc_norm_all, yaw_rate_norm_all], axis=1)
        data_input["ar_ego_action_soft_labels"] = soft_labels
        data_input["ar_ego_action_soft_labels_all"] = soft_labels_all
        # data_input["kmeans_centers"] = self.kmeans_centers
        assert (ego_action_vocab_all[14:] == ego_action_vocab).all()
        assert (data_input["ar_ego_action_norm_all"][14:] == data_input["ar_ego_action_norm"]).all()

        return data_input


class AgentsStateTransform(BaseTransform):
    """Agents state transform."""

    def __init__(self, dis_keep_num=64):
        """Init."""
        super().__init__()
        self.dis_keep_num = dis_keep_num

    def __call__(self, data_input):
        """Call."""
        ar_agents_state = []

        dynamic_dets = self.preprocess_dynamic_dets(data_input)
        ar_agents_state = self.foramt_agent_state(dynamic_dets)
        ar_agents_state = np.transpose(ar_agents_state, axes=(1, 0, 2))

        data_input["ar_agents_state"] = np.concatenate(
            (
                ar_agents_state,
                np.zeros(
                    (self.dis_keep_num - ar_agents_state.shape[0], ar_agents_state.shape[1], ar_agents_state.shape[2])
                ),
            )
        )  # [A, T, dim]

        return data_input

    def preprocess_dynamic_dets(self, data_input):
        """Get dynamic detections."""
        history_dynamic_dets = data_input["ar_agents_dynamic_dets"]["history"]
        current_dynamic_dets = data_input["ar_agents_dynamic_dets"]["current"]
        future_dynamic_dets = data_input["ar_agents_dynamic_dets"]["future"]

        range_filter_current_dynamic_dets = self.current_dis_filter(current_dynamic_dets)

        dynamic_dets = self.concat_dynamic_dets(
            history_dynamic_dets, range_filter_current_dynamic_dets, future_dynamic_dets
        )

        dynamic_dets = dynamic_dets[:, :, [0, 1, 2, 3, 4, 5, 6, 10, 11]]  # [x, y, z,  l, w, h,  heading,  vx, vy]
        dynamic_dets = np.concatenate(
            (dynamic_dets[:, :, :-2], np.linalg.norm(dynamic_dets[:, :, -2:], axis=2, keepdims=True)), axis=2
        )  # [x, y, z,  l, w, h,  heading,  v]

        history_carposes = data_input["history"]["car_poses"]
        current_carposes = data_input["current"]["car_poses"]
        future_carposes = data_input["future"]["car_poses"]

        dynamic_dets = self.cor_trans(dynamic_dets, history_carposes, current_carposes, future_carposes)
        dynamic_dets = dynamic_dets[:, :, [0, 1, 3, 4, 5, 6, 7]]  # [x, y, l, w, h, heading, v]

        return dynamic_dets

    def cor_trans(self, dynamic_dets, history_carposes, current_carposes, future_carposes):
        """Transform dynamic detections to global coordinates."""
        hist2cur = np.einsum("ijk, mkl->mjl", np.linalg.inv(current_carposes), history_carposes)
        fur2cur = np.einsum("ijk, mkl->mjl", np.linalg.inv(current_carposes), future_carposes)
        cur2cur = np.einsum("ijk, mkl->mjl", np.linalg.inv(current_carposes), current_carposes)

        trans_mat = np.concatenate((hist2cur, cur2cur, fur2cur), axis=0)

        dynamic_dets_xyz = dynamic_dets[:, :, :3]
        dynamic_dets_xyz_padding = np.concatenate(
            (dynamic_dets_xyz, np.ones((dynamic_dets_xyz.shape[0], dynamic_dets_xyz.shape[1], 1))), axis=2
        )
        dynamic_dets_xyz_trans = np.einsum("ijk, imk->imj", trans_mat, dynamic_dets_xyz_padding)

        dynamic_dets_heading = dynamic_dets[:, :, 6]
        dynamic_dets_heading_trans = np.einsum(
            "ijk, imk->imj",
            trans_mat[:, :3, :3],
            np.stack(
                (np.cos(dynamic_dets_heading), np.sin(dynamic_dets_heading), np.zeros_like(dynamic_dets_heading)),
                axis=2,
            ),
        )
        dynamic_dets_heading_trans = np.arctan2(
            dynamic_dets_heading_trans[:, :, 1], dynamic_dets_heading_trans[:, :, 0]
        )

        dynamic_dets[:, :, :3] = dynamic_dets_xyz_trans[:, :, :3]
        dynamic_dets[:, :, 6] = dynamic_dets_heading_trans

        return dynamic_dets

    def current_dis_filter(self, current_dynamic_dets):
        """Filter current dynamic detections."""
        dis = np.linalg.norm(current_dynamic_dets[0][:, :2], axis=1)
        dis_sorted = np.argsort(dis)
        dis_keep = sorted(dis_sorted[: self.dis_keep_num])

        filtered_dynamic_dets = current_dynamic_dets[0][dis_keep]

        return filtered_dynamic_dets

    def concat_dynamic_dets(self, history_dynamic_dets, current_dynamic_dets, future_dynamic_dets):
        """Concat dynamic detections."""
        dets_ids = current_dynamic_dets[:, 9]
        current_dynamic_dets4cat = current_dynamic_dets[None, :, :]

        history_dynamic_dets4cat = self.dynamic_matching(history_dynamic_dets, dets_ids)
        future_dynamic_dets4cat = self.dynamic_matching(future_dynamic_dets, dets_ids)

        dynamic_concated = np.concatenate(
            [history_dynamic_dets4cat, current_dynamic_dets4cat, future_dynamic_dets4cat], axis=0
        )

        return dynamic_concated

    def dynamic_matching(self, dynamic_dets, dets_ids):
        """Dynamic matching."""
        matched_dets = np.full((len(dynamic_dets), dets_ids.shape[0], dynamic_dets[0].shape[-1]), np.nan)
        for frame_idx, frame_dets in enumerate(dynamic_dets):
            frame_dets_ids = frame_dets[:, 9]
            matching_cost = scipy.spatial.distance.cdist(frame_dets_ids[:, None], dets_ids[:, None])
            match_det_idx, det_id_index = np.where(matching_cost == 0)
            matched_dets[frame_idx, det_id_index] = frame_dets[match_det_idx]

        return matched_dets

    def foramt_agent_state(self, dynamic_dets):
        """Format agent state."""
        agents_states = np.nan_to_num(dynamic_dets, 0.0)
        return agents_states


class SaveDynamicDets4AR(BaseTransform):
    """Agents state transform."""

    def __init__(self):
        """Init."""
        super().__init__()

    def __call__(self, data_input):
        """Call."""
        history_dynamic_dets = [copy(item["dynamic_dets"]) for item in data_input["history"]]
        current_dynamic_dets = [copy(item["dynamic_dets"]) for item in data_input["current"]]
        future_dynamic_dets = [copy(item["dynamic_dets"]) for item in data_input["future"]]

        data_input["ar_agents_dynamic_dets"] = {
            "history": history_dynamic_dets,
            "current": current_dynamic_dets,
            "future": future_dynamic_dets,
        }

        return data_input


class AgentsActionTransform(BaseTransform):
    """Agents action transform."""

    def __init__(self, history_num=14):
        """Init."""
        super().__init__()
        self.history_num = history_num

    def __call__(self, data_input):
        """Call."""
        agents_states = data_input["ar_agents_state"]  # [A, T, dim], x, y, l, w, h, heading, v
        agents_mask = (agents_states == 0.0).all(axis=2)
        agents_mask = agents_mask[:, 1:] | agents_mask[:, :-1]

        agents_v = agents_states[:, self.history_num :, 6]
        agents_heading = agents_states[:, self.history_num :, 5]

        current_timestamp = data_input["current"]["timestamps"]
        future_timestamp = data_input["future"]["timestamps"]
        timestamps = np.array(current_timestamp + future_timestamp)
        timestamp_diff = timestamps[1:] - timestamps[:-1]

        agents_acc = (agents_v[:, 1:] - agents_v[:, :-1]) / timestamp_diff
        agents_delta_heading = np.mod((agents_heading[:, 1:] - agents_heading[:, :-1]) + np.pi, 2 * np.pi) - np.pi
        agents_yaw_rate = agents_delta_heading / timestamp_diff

        agents_action = np.stack([agents_acc, agents_yaw_rate], axis=2)

        if np.any(np.isnan(agents_action)):
            agents_action[np.isnan(agents_action)] = 0.0  # for infer with clip padding

        data_input["ar_agents_action"] = agents_action

        return data_input
