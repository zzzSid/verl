# -*- coding: utf-8 -*-
import gzip
import hashlib
import json
import os
import pickle
import random
import gc
import re
import time
from collections import defaultdict
from functools import lru_cache
from functools import reduce
from itertools import chain
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Union

import numpy as np
import torch
from read_cache_op_py import read_cache_op_py
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation as R
from shapely.geometry import LineString
from shapely.geometry import Point
from shapely.strtree import STRtree
from torchpilot import logger
from torchpilot.data.dataset.base_dataset import BaseDataset
from torchpilot.utils.registries import MODULE
from torchpilot import logger

from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import ScenarioEnum
from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import cls_mapping
from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import (
    get_action_cls2_mapping,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import (
    get_action_cls3_mapping,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import (
    get_lane_id_cls2_mapping,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import (
    get_lane_line_cls2_mapping,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import (
    get_lane_type_cls3_mapping,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import (
    get_map_cls2_to_sub_path,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import get_map_cls_to_3cls
from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import (
    get_remain_distance_cls4_mapping,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import (
    get_road_sign_cls2_mapping,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import (
    get_spd_limit_cls2_mapping,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import (
    get_map_cls2_to_sub_path,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import (
    get_gate_machine_cls2_mapping,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import get_tld_cls2_mapping
from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import (
    road_arrow_to_lane_direction_mapping,
    etc_sematic_to_road_sign,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import (
    tld_to_lane_direction_mapping,
)
from tpp_onemodel.data.config.common import train_data_tag_config, pretrain_meta_label_path, sft_meta_label_path
from tpp_onemodel.data.config.longitudinal import LongitudinalChecker
from tpp_onemodel.data.config.lateral import EffectiveChangeLaneChecker
from tpp_onemodel.data.config.humanoid import HumanoidChecker
from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import ScenarioEnum
from tpp_onemodel.data.dataset.plannn2_dataset_utils.data_navi_centerline import (
    global_navi_centerline,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.data_navi_roadedge import (
    RoadBoundaryBuilder,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.data_parser import (
    global_data_parser,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import (
    tldcolor,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import (
    lane_direction_to_tld_id_mapping,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.data_parser import parse_waitzone
from tpp_onemodel.data.dataset.plannn2_dataset_utils.data_toll_gate_centerline import (
    global_toll_gate_centerline,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import cut_sub_path
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import cut_sub_path_spec
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import ego2global
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import filter_etc_staticobj
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import filter_points_by_dis
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import get_corner
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import get_corners
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import (
    get_relative_pose_from_obj,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import get_rotated_rectangle
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import interpolate_angles
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import interpolate_points
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import norm_yaw
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import parse_dynamicobj_v2
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import parse_frame
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import parse_staticobj_v2
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import parse_stopline
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import transform_obj

from tpp_onemodel.data.dataset.plannn2_dataset_utils.meta_action_manager import (
    MetaActionManager,
)
from tpp_onemodel.tools.plannn2.beam_search_optimizer import BeamSearchConfig
from tpp_onemodel.tools.plannn2.beam_search_optimizer import BeamSearchTrajectoryOptimizer

def find_uuid(text, md5_ok=False):
    pattern = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", re.IGNORECASE)
    res = pattern.findall(text)
    if md5_ok and len(res) == 0:
        res = hashlib.md5(text.split(' ')[0].hexdigest())
    return res[0] if len(res) > 0 else ""


def find_closest_index(nums: List[float], target: float) -> int:

    min_diff = float('inf')
    closest_idx = -1

    for i, num in enumerate(nums):
        diff = abs(num - target)
        if diff < min_diff:
            min_diff = diff
            closest_idx = i

    return closest_idx

from tpp_onemodel.data.dataset.plannn2_dataset_utils.meta_action_storge import TagStorage


# 读取标签信息：
tags_info = json.load(open("/share-global/weidong.shi1/data/planner/tagsinfo.json"))

with open("/share-global/weidong.shi1/data/planner/intersection_clipid.txt", "r") as f:
    intersection_clipid = [i.strip() for i in f.readlines()]

with open(
    "/share-global/mccree.zhao/data/planner/plannn2/rl_1118_mapV5/filtered_output/rl_clip_ids_104686_1107_93890_updated.txt",
    "r",
) as f:
    stalk_lcc_clips = [i.strip() for i in f.readlines()]
    for i, data_path in enumerate(stalk_lcc_clips):
        content = data_path.split()
        stalk_lcc_clips[i] = f"{content[0]} {content[1]}"


@MODULE.register_module()
class AccKappaVehicleTokenizer:
    def __init__(self, template_set_path, device=None, use_euler=False, use_corners=False):
        if isinstance(template_set_path, str):
            self.template_set = np.load(template_set_path, allow_pickle=True)
        else:
            self.template_set = template_set_path
        if device is not None:
            self.template_set_torch = torch.tensor(self.template_set, dtype=torch.float32, device=device)
        self.use_euler = use_euler
        self.use_corners = use_corners


    def __call__(
        self,
        init_state,
        target_states,   # (H,4)
        with_error=False,
        dt=0.2,
        horizon=3,
        error_type="final",
    ):
        if self.use_corners:
            return self.cal_min_dis_by_corners_traj(
                init_state, target_states,
                with_error, dt, horizon, error_type
            )
        else:
            return self.cal_min_dis_by_center_traj(
                init_state, target_states,
                with_error, dt, horizon, error_type
            )


    def rollout(self, init_state, control, dt, horizon):
        """
        init_state: (4,)
        control:    (N, 2)
        return:     (N, horizon, 4)
        """
        states = []
        state = init_state

        for _ in range(horizon):
            if self.use_euler:
                state = AccKappaVehicleTokenizer.euler_step(state, control, dt)
            else:
                state = AccKappaVehicleTokenizer.rk4_step(state, control, dt)
            states.append(state)

        # (N, H, 4)
        return np.stack(states, axis=1)


    def cal_min_dis_by_center_traj(
        self,
        init_state,
        target_states,   # (4,) 或 (N, 4)
        with_error,
        dt,
        horizon,
        error_type,
    ):
        init_state = np.asarray(init_state[:4])
        target_states = np.asarray(target_states)
        if target_states.ndim == 1:
            target_states = target_states[None, :]

        H = target_states.shape[0]
        horizon = horizon or H

        traj = self.rollout(init_state, self.template_set, dt, horizon)
        # traj: (N,H,4)

        if error_type == "final":
            diff = traj[:, -1, :2] - target_states[-1, :2]
            dist = np.linalg.norm(diff, axis=1)

        elif error_type == "mean":
            diff = traj[:, :, :2] - target_states[None, :, :2]
            dist = np.linalg.norm(diff, axis=2).mean(axis=1)

        else:
            raise ValueError(error_type)

        valid_mask = traj[:, -1, 3] >= 0.0
        if np.any(valid_mask):
            masked_dist = np.where(valid_mask, dist, np.inf)
            argidx = np.argmin(masked_dist)
        else:
            argidx = np.argmin(dist)
        return (argidx, dist[argidx]) if with_error else argidx


    def cal_min_dis_by_corners_traj(
        self,
        init_state,
        target_states,   # (4,) 或 (N, 4)
        with_error,
        dt,
        horizon,
        error_type,
    ):
        init_state = np.asarray(init_state)
        target_states = np.asarray(target_states)
        if target_states.ndim == 1:
            target_states = target_states[None, :]

        H = target_states.shape[0]
        horizon = horizon or H

        traj = self.rollout(init_state, self.template_set, dt, horizon)
        # (N,H,4)

        target_corners = get_corners(target_states[:, :3])     # (H,4,2)

        N, H, _ = traj.shape
        pred_states = traj[:, :, :3].reshape(-1, 3)   # (N*H,3)
        pred_corners = get_corners(pred_states)       # (N*H,4,2)
        pred_corners = pred_corners.reshape(N, H, 4, 2)

        diff = pred_corners - target_corners[None]
        dists = np.linalg.norm(diff, axis=3)   # (N,H,4)

        if error_type == "final":
            dist = dists[:, -1].mean(axis=1)
        elif error_type == "mean":
            dist = dists.mean(axis=(1, 2))
        else:
            raise ValueError(error_type)

        valid_mask = traj[:, -1, 3] >= 0.0
        if np.any(valid_mask):
            masked_dist = np.where(valid_mask, dist, np.inf)
            argidx = np.argmin(masked_dist)
        else:
            argidx = np.argmin(dist)
        return (argidx, dist[argidx]) if with_error else argidx

    @staticmethod
    def euler_step(state, control, dt):
        """
        state:    (4,) 或 (N, 4)
        control: (N, 2)
        return:   (N, 4)
        """
        # -------- 统一 batch size --------
        if state.ndim == 1 and control.ndim == 1:
            # (4,) + (2,) -> (1,4), (1,2)
            state = state[None, :]
            control = control[None, :]
        elif state.ndim == 1 and control.ndim == 2:
            # (4,) + (N,2) -> (N,4)
            state = np.broadcast_to(state, (len(control), 4))
        elif state.ndim == 2 and control.ndim == 1:
            # (N,4) + (2,) -> (N,2)
            control = np.broadcast_to(control, (len(state), 2))
        elif state.ndim == 2 and control.ndim == 2:
            assert len(state) == len(control), \
                f"state and control batch mismatch: {state.shape}, {control.shape}"
        else:
            raise ValueError(f"Invalid shapes: state {state.shape}, control {control.shape}")

        state_dot = AccKappaVehicleTokenizer.vehicle_dynamics(state, control)
        return state + dt * state_dot


    @staticmethod
    def rk4_step(state, control, dt):
        """
        state:   (4,) or (N, 4)
        control: (2,) or (N, 2)
        return:  (N, 4)
        """
        state = np.asarray(state)
        control = np.asarray(control)

        # -------- 统一 batch size --------
        if state.ndim == 1 and control.ndim == 1:
            # (4,) + (2,) -> (1,4), (1,2)
            state = state[None, :]
            control = control[None, :]
        elif state.ndim == 1 and control.ndim == 2:
            # (4,) + (N,2) -> (N,4)
            state = np.broadcast_to(state, (len(control), 4))
        elif state.ndim == 2 and control.ndim == 1:
            # (N,4) + (2,) -> (N,2)
            control = np.broadcast_to(control, (len(state), 2))
        elif state.ndim == 2 and control.ndim == 2:
            assert len(state) == len(control), \
                f"state and control batch mismatch: {state.shape}, {control.shape}"
        else:
            raise ValueError(f"Invalid shapes: state {state.shape}, control {control.shape}")

        # -------- RK4 --------
        k1 = AccKappaVehicleTokenizer.vehicle_dynamics(state, control)
        k2 = AccKappaVehicleTokenizer.vehicle_dynamics(state + 0.5 * dt * k1, control)
        k3 = AccKappaVehicleTokenizer.vehicle_dynamics(state + 0.5 * dt * k2, control)
        k4 = AccKappaVehicleTokenizer.vehicle_dynamics(state + dt * k3, control)

        return state + (dt / 6.0) * (k1 + 2*k2 + 2*k3 + k4)

    @staticmethod
    def vehicle_dynamics(state, control):
        x, y, theta, v = state.T
        acc, kappa = control.T

        dx = v * np.cos(theta)
        dy = v * np.sin(theta)
        dtheta = v * kappa
        dv = acc

        return np.stack([dx, dy, dtheta, dv], axis=1)


    def step(self, state, control, dt):
        # state:   [x, y, theta, v]
        if self.use_euler:
            return AccKappaVehicleTokenizer.euler_step(state, control, dt)
        else:
            return AccKappaVehicleTokenizer.rk4_step(state, control, dt)


    def decode(self, token_id):
        return self.template_set[token_id]


    def vehicle_dynamics_torch(self, state, control):
        """
        state:   [x, y, theta, v]
        control: [acc, kappa]
        return:  state_dot
        """
        x, y, theta, v = state.unbind(-1)
        acc, kappa = control.unbind(-1)

        dx = v * torch.cos(theta)
        dy = v * torch.sin(theta)
        dtheta = v * kappa
        dv = acc

        return torch.stack([dx, dy, dtheta, dv], dim=-1)


    def euler_step_torch(self, state, control, dt):
        """
        state:   [x, y, theta, v]
        control: [acc, kappa]
        return:  next_state
        """
        state_dot = self.vehicle_dynamics_torch(state, control)
        return state + dt * state_dot


    def rk4_step_torch(self, state, control, dt):
        """
        state:   [x, y, theta, v]
        control: [acc, kappa]
        return:  next_state
        """
        k1 = self.vehicle_dynamics_torch(state, control)
        k2 = self.vehicle_dynamics_torch(state + 0.5 * dt * k1, control)
        k3 = self.vehicle_dynamics_torch(state + 0.5 * dt * k2, control)
        k4 = self.vehicle_dynamics_torch(state + dt * k3, control)

        return state + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)


    def step_torch(self, state, control, dt):
        # state:   [x, y, theta, kappa, v, a]
        if self.use_euler:
            return self.euler_step_torch(state, control, dt)
        else:
            return self.rk4_step_torch(state, control, dt)


    def decode_torch(self, token_ids):
        if not hasattr(self, "template_set_torch") or self.template_set_torch.device != token_ids.device:
            self.template_set_torch = torch.tensor(self.template_set, dtype=torch.float32, device=token_ids.device)
        return self.template_set_torch[token_ids]


    def __getitem__(self, token_id):
        return self.template_set[token_id]


    def __len__(self):
        return len(self.template_set)


@MODULE.register_module()
class MTVehicleTokenizer:
    def __init__(self, template_set_path, device=None):
        if isinstance(template_set_path, str):
            self.template_set = np.load(template_set_path, allow_pickle=True)
        else:
            self.template_set = template_set_path
        self.template_corners = np.array([get_corners(t) for t in self.template_set])  # n x segment x 4 x 2
        if device is not None:
            self.template_set_torch = torch.tensor(self.template_set, dtype=torch.float32, device=device)

    def __call__(self, target, with_error=False):
        # target: [x, y, yaw]
        target_corner = get_corners(target)[None, ...]
        distances = np.mean(np.linalg.norm(self.template_corners - target_corner, axis=-1), axis=(-2, -1))
        if with_error:
            argidx = np.argmin(distances)
            return argidx, distances[argidx]
        return np.argmin(distances)

    def batch_tokenize(self, targets, with_error=False):
        target_corners = get_corners(targets)  # b x 4 x 2
        diff = target_corners[:, None, :, :] - self.template_corners[None, :, :, :]  # b x n x 4 x 2
        distances = np.mean(np.linalg.norm(diff, axis=3), axis=2)  # b x n
        if with_error:
            argidx = np.argmin(distances, axis=1)  # b
            return argidx, np.min(distances, axis=1)  # b
        return np.argmin(distances, axis=1)  # b

    def distance(self, target):
        target_corner = get_corners(target)[None, ...]
        distances = np.mean(np.linalg.norm(self.template_corners - target_corner, axis=-1), axis=(-2, -1))
        return np.min(distances)

    def decode(self, token_id):
        return self.template_set[token_id]

    def decode_torch(self, token_ids):
        return self.template_set_torch[token_ids]

    def __getitem__(self, token_id):
        return self.template_set[token_id]

    def __len__(self):
        return len(self.template_set)


@MODULE.register_module()
class VehicleTokenizer:
    def __init__(self, template_set_path, device=None):
        self.template_set = np.load(template_set_path, allow_pickle=True)
        self.template_corners = np.array([get_corner(t) for t in self.template_set])  # n x 4 x 2
        if device is not None:
            self.template_set_torch = torch.tensor(self.template_set, dtype=torch.float32, device=device)

    def __call__(self, target, with_error=False):
        # target: [x, y, yaw]
        target_corner = get_corner(target)[None, ...]  # 1 x 4 x 2
        distances = np.mean(np.linalg.norm(self.template_corners - target_corner, axis=2), axis=1)
        if with_error:
            argidx = np.argmin(distances)
            return argidx, distances[argidx]
        return np.argmin(distances)

    def batch_tokenize(self, targets, with_error=False):
        target_corners = get_corners(targets)  # b x 4 x 2
        diff = target_corners[:, None, :, :] - self.template_corners[None, :, :, :]  # b x n x 4 x 2
        distances = np.mean(np.linalg.norm(diff, axis=3), axis=2)  # b x n
        if with_error:
            argidx = np.argmin(distances, axis=1)  # b
            return argidx, np.min(distances, axis=1)  # b
        return np.argmin(distances, axis=1)  # b

    def distance(self, target):
        target_corner = get_corner(target)[None, ...]  # 1 x 4 x 2
        distances = np.mean(np.linalg.norm(self.template_corners - target_corner, axis=2), axis=1)
        return np.min(distances)

    def decode(self, token_id):
        return self.template_set[token_id]

    def decode_torch(self, token_ids):
        return self.template_set_torch[token_ids]

    def __getitem__(self, token_id):
        return self.template_set[token_id]

    def __len__(self):
        return len(self.template_set)


def _load_data(fname, need_road_boundary=False):
    """
    数据加载入口函数（带进程内LRU缓存）

    先标准化fname再缓存，确保相同文件的不同格式fname都能命中缓存
    """
    fname = fname.replace("\t", " ").strip()
    return _load_data_impl(fname, need_road_boundary)

    # TODO: 无法读取issue key


def extract_uuid(text):
    pattern = r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"

    matches = re.findall(pattern, text)
    if matches:
        return matches[-1]  # 返回列表中的最后一个
    else:
        return None

def extract_minium_uuid(s: str) -> str:
    # 匹配最后一个 '/' 之后、'.pkl' 之前的部分
    return s.rpartition('/')[-1]



def unique_lanes(lanes, types, attrs):
    hash_value = [l.sum() + t + a.sum() for l, t, a in zip(lanes, types, attrs)]
    filter_idx = np.unique(hash_value, return_index=True)[1]
    filter_idx = np.sort(filter_idx)
    lanes = [lanes[i] for i in filter_idx]
    types = [types[i] for i in filter_idx]
    attrs = [attrs[i] for i in filter_idx]
    return lanes, types, attrs



@lru_cache(maxsize=32)
def _load_data_impl(fname, need_road_boundary=False):
    """数据加载实现函数（带LRU缓存）"""
    # TODO: 无法读取issue key
    clipid = fname.split("/")[3]
    use_turnlightsignal = False
    if clipid in intersection_clipid:
        use_turnlightsignal = True
    stalk_lcc_tag = False
    if fname in stalk_lcc_clips:
        stalk_lcc_tag = True
    tagsinfo = None
    if clipid in tags_info:
        tagsfile = tags_info[clipid]
        tagsinfo = read_cache_op_py([tagsfile])[0]
        tagsinfo = pickle.loads(gzip.decompress(tagsinfo))["sec_tags"]
    is_pkl = fname.endswith(".pkl") or ".pkl " in fname
    if " " in fname:
        fname = "/" + fname.split(":")[-1]
        content = read_cache_op_py([fname])[0]
        data = pickle.loads(content) if is_pkl else global_data_parser.parse(content)
    else:
        data = pickle.load(open(fname, "rb")) if is_pkl else global_data_parser.parse(fname)
    data["stalk_lcc_tag"] = stalk_lcc_tag
    if "uuid" not in data.keys() or data["uuid"] is None:
        data["uuid"] = extract_uuid(fname)

    is_simplified = False
    break_outer = False
    for k in list(data.keys()):
        if isinstance(k, float) and "manner_lane_center_lines" in data[k]:
            tem = data[k]["manner_lane_center_lines"]
            for centerline in tem:
                for point in centerline["points"]:
                    if isinstance(point, dict):
                        is_simplified = False
                    else:
                        is_simplified = True
                    break_outer = True
                    break
                if break_outer:
                    break  # 跳出中层循环
            if break_outer:
                break  # 跳出外层循环

    if not is_simplified:
        for k, item in data.items():
            if isinstance(k, float) and (centerline_list := item.get("manner_lane_center_lines")):
                manner_lane_center_lines = []
                for centerline in centerline_list:
                    centerline["points"] = np.array(
                        [[point["x"], point["y"], point["z"]] for point in centerline["points"]], dtype=np.float32
                    )
                    manner_lane_center_lines.append(centerline)
                item["manner_lane_center_lines"] = manner_lane_center_lines

    timestamps = sorted(data["timestamp_list"])
    trajpose0 = data[timestamps[0]]["car_pose"]
    waitzone_flag = False
    for ts in timestamps:
        if "preproc_data" in data[ts]:
            if "wm_stoplines" in data[ts]["preproc_data"]:
                if len(data[ts]["preproc_data"]["wm_stoplines"]) > 0:
                    waitzone_flag = True
                    break

    if waitzone_flag:
        for ts in timestamps:
            if "preproc_data" in data[ts]:
                if "wm_stoplines" in data[ts]["preproc_data"]:
                    frame_ts_info_updata = parse_waitzone(data[ts])
                    data[ts] = frame_ts_info_updata
    # checkpoints
    for ts in timestamps:
        data[ts]["checkpoints"] = []
        if "relative_reward_data" in data[timestamps[0]]:
            relative_reward_data = data[timestamps[0]]["relative_reward_data"]["data"]
            inv_car_pose = np.linalg.inv(data[ts]["car_pose"])
            convert_mat = inv_car_pose @ trajpose0
            for d in relative_reward_data:
                start_point = np.array(d["start_point"])
                start_point_in_ego = convert_mat[:3, :3] @ start_point + convert_mat[:3, 3]
                end_point = np.array(d["end_point"])
                end_point_in_ego = convert_mat[:3, :3] @ end_point + convert_mat[:3, 3]
                data[ts]["checkpoints"].append([start_point_in_ego, end_point_in_ego, d["value"]])
    data = global_toll_gate_centerline.calc_toll_gate_centerline(data, timestamps)
    if "manner_scene_info" in data[timestamps[0]]:
        data = global_navi_centerline.calc_navi_centerline_v4(data, timestamps)

    if need_road_boundary:
        roadedge_builder = RoadBoundaryBuilder(res=0.2, min_count=3)
        data = roadedge_builder.process(data, timestamps)

    # 基于manner构造的navi_centerlines，给定source:0 - manner, 1 - GT, 2 - mock adjacent
    for ts in timestamps:
        if "navi_centerlines" not in data[ts]:
            continue

        for navi_lane in data[ts]["navi_centerlines"]:
            if navi_lane.get("is_adjacent", False):
                navi_lane["source"] = 2
            else:
                navi_lane["source"] = 0

    if "recommended_gt_info" in data[timestamps[0]] and "virtual_wall" in data[timestamps[0]]["recommended_gt_info"]:
        for ts in timestamps:
            if "navi_centerlines" not in data[ts]:
                data[ts]["navi_centerlines"] = []
            for navi_lane in data[ts]["recommended_gt_info"]["navi_centerline"]:
                navi_lane["points"] = np.array(navi_lane["points"])
                navi_lane["source"] = 1
                data[ts]["navi_centerlines"].append(navi_lane)

            if "virtual_wall" not in data[ts]:
                data[ts]["virtual_wall"] = []
            data[ts]["virtual_wall"].extend(data[ts]["recommended_gt_info"]["virtual_wall"])

    # Specific HD-GT for highway.
    data = calc_highway_least_lc_dist(data, timestamps)
    if "hd_info" in data[timestamps[0]]:
        data = global_navi_centerline.calc_highway_navi_centerline(data, timestamps)

    data = address_turnlight_single(data, tagsinfo, clipid, fname, use_turnlightsignal)
    return data


def calc_highway_least_lc_dist(data, timestamps):
    # least_lc_dist
    for ts in timestamps:
        # merge point dist
        hd_info = data[ts].get("hd_info", {})
        merge_point_dist = 10000
        if len(hd_info) > 0:
            for index, navi_centerline in enumerate(hd_info.get("navi_centerline", {})):  # dict
                if navi_centerline["confidence"] != 1.0 or navi_centerline["type"] == 99:
                    continue
                points = np.array(navi_centerline["points"])
                if len(points) < 1:
                    continue
                merge_in = navi_centerline.get("merge_in", False)
                if merge_in and points[-1][0] < merge_point_dist and points[-1][0] > -10:
                    merge_point_dist = points[-1][0]
        # nearest_stub_dist
        nearest_stub_dist = 10000
        target_lane_infos = data[ts].get("target_lane_infos", {})
        for target_lane_info in target_lane_infos:
            least_lc_dist = target_lane_info.get("least_lc_dist", 10000)
            if least_lc_dist < nearest_stub_dist:
                nearest_stub_dist = least_lc_dist
        # least split dist
        least_split_dist = 10000
        sub_path = data[ts].get("sub_path", {})
        if len(sub_path) > 0 and (len(hd_info) > 0 or len(target_lane_infos) > 0):
            for sub_path_points in sub_path.get("sub_path_sub_path_points", {}):
                if sub_path_points[0][0] < -10:
                    continue
                if sub_path_points[0][0] < least_split_dist:
                    least_split_dist = sub_path_points[0][0]
        # main_action_dist
        main_action_dist = 10000
        nav_input = data[ts].get("nav_input", {})
        action_input = []
        if len(hd_info) > 0 or len(target_lane_infos) > 0:
            if nav_input is not None:
                action_input = nav_input.get("action_input", {})
            for i in range(len(action_input)):
                guide_action = action_input[i].get("guide_action", {})
                if (
                    guide_action == "MainActionContinue"
                    or guide_action == "MainActionSlightLeft"
                    or guide_action == "MainActionTurnLeft"
                    or guide_action == "MainActionMergeLeft"
                    or guide_action == "MainActionSlightRight"
                    or guide_action == "MainActionTurnRight"
                    or guide_action == "MainActionMergeRight"
                ):
                    main_action_dist = min(action_input[i].get("offset", {}), main_action_dist)

        map_loc = data[ts]["map_loc"]
        link_info = data[ts]["link_info"]
        is_in_ramp = False
        if link_info and "link_index" in map_loc:
            link_index = map_loc["link_index"]
            link = link_info[link_index]
            cur_formway = link.get("formway", 1)
            if cur_formway == 3 or cur_formway == 4 or cur_formway == 6 or cur_formway == 8:
                is_in_ramp = True
        if True or is_in_ramp:
            least_lc_dist = min(merge_point_dist, nearest_stub_dist, least_split_dist, main_action_dist)
        else:
            least_lc_dist = min(nearest_stub_dist, least_split_dist, main_action_dist)
        data[ts]["is_in_ramp"] = is_in_ramp
        data[ts]["least_lc_dist"] = least_lc_dist
    return data


def address_turnlight_single(data, tagsinfo=None, clipid=None, fname=None, use_turnlightsignal=None):
    data["use_turnlightsignal"] = use_turnlightsignal
    if use_turnlightsignal:
        timestamps = sorted(data["timestamp_list"])
        turnlightsigle = [data[ts]["vehicle_50ms"]["TurnIndcrLiSts"] for ts in timestamps]
        turnlightsigle = np.array(turnlightsigle)
        turnlightsigle = turnlightsigle * np.array([1, 2])
        turnlightsigle = turnlightsigle.sum(-1)
        turnlightsigle[turnlightsigle >= 3] = 0
        data[timestamps[0]]["turnlight"] = turnlightsigle[0]
        data[timestamps[1]]["turnlight"] = turnlightsigle[1]
        for i in range(2, len(turnlightsigle)):
            if turnlightsigle[i] == 0:
                data[timestamps[i]]["turnlight"] = turnlightsigle[i - 2]
            else:
                data[timestamps[i]]["turnlight"] = turnlightsigle[i]

    return data

    # if tagsinfo is None:
    #     timestamps = sorted(data["timestamp_list"])
    #     turnlightsigle = [data[ts]["vehicle_50ms"]["TurnIndcrLiSts"] for ts in timestamps]
    #     turnlightsigle = np.array(turnlightsigle)
    #     turnlightsigle = turnlightsigle * np.array([1, 2])
    #     turnlightsigle = turnlightsigle.sum(-1)
    #     turnlightsigle[turnlightsigle>=3] = 0
    #     data[timestamps[0]]["turnlight"] = turnlightsigle[0]
    #     data[timestamps[1]]["turnlight"] = turnlightsigle[1]
    #     for i in range(2, len(turnlightsigle)):
    #         if turnlightsigle[i] == 0:
    #             data[timestamps[i]]["turnlight"] = turnlightsigle[i-2]
    #         else:
    #             data[timestamps[i]]["turnlight"]= turnlightsigle[i]
    # else:
    #     timestamps = sorted(data["timestamp_list"])
    #     turnlightsigle = np.zeros((len(timestamps)))
    #     lanechange = {}
    #     for ts in tagsinfo:
    #         if "attrs" in tagsinfo[ts]["objs"][2] and "start_timestamp" in tagsinfo[ts]["objs"][2]["attrs"]:
    #             start_timestamp = tagsinfo[ts]["objs"][2]["attrs"]["start_timestamp"]
    #             end_timestamp = tagsinfo[ts]["objs"][2]["attrs"]["end_timestamp"]
    #             # 计算一下是左变道还是右变道
    #             startindex = np.searchsorted(timestamps, start_timestamp)
    #             endindex = np.searchsorted(timestamps, end_timestamp)
    #             if endindex > len(timestamps) - 1:
    #                 endindex = len(timestamps) -1
    #             T_start = data[timestamps[startindex]]["car_pose"]
    #             T_end = data[timestamps[endindex]]["car_pose"]

    #             R0 = T_start[:3,:3]; t0 = T_start[:3,3]
    #             T_start_inv = np.eye(4)
    #             T_start_inv[:3,:3] = R0.T
    #             T_start_inv[:3,3] = -R0.T @ t0
    #             T_rel = T_start_inv @ T_end
    #             y_local = float(T_rel[1,3])
    #             for tts in np.arange(int(start_timestamp), int(end_timestamp) + 1):
    #                 if tts not in lanechange:
    #                     lanechange[str(tts)] = 1 if y_local > 0 else 2

    #     for ts in timestamps:
    #         tts = str(int(round(ts)))
    #         if tts in lanechange:
    #             data[ts]["turnlight"] = lanechange[tts]
    #         else:
    #             data[ts]["turnlight"] = 0
    # return data


def cal_acc_kappa_ego_labels(
    x_y_yaw_k,
    vehicle_tokenizer,
    use_filter=True,
    use_trajectory_optimizer=False,
    history_size=15,
    timestamp_size=41,
    segment_labels=2,
):
    def empty_result():
        return np.empty((0,2)), np.empty((0,6)), np.empty((0,4)), np.empty((0,4))

    dt = 0.2
    trajectory_optimizer_cfg = BeamSearchConfig(
        dt=dt,
        x_weight=5.0,
        y_weight=10.0,
        yaw_weight=10.0,
        v_weight=1.0,
        acc_weight=0.0,
        kappa_weight=1.0,
        jerk_weight=0.1,
        dkappa_weight=1.0,
        ref_control_topk=256,
        ref_acc_weight=0.0,
        ref_kappa_weight=1.0,
    )
    trajectory_optimizer = BeamSearchTrajectoryOptimizer(vehicle_tokenizer.template_set, trajectory_optimizer_cfg)

    ego_label_len = (timestamp_size - history_size) // segment_labels
    v_eps = 0.1
    center_rear_axle_dis = 1.4

    x_y_yaw_k = np.asarray(x_y_yaw_k)

    # 后轴中心点转到后轴中心坐标系
    x_y_yaw_k[:, 0] = x_y_yaw_k[:, 0] + center_rear_axle_dis * (1.0 - np.cos(x_y_yaw_k[:, 2]))
    x_y_yaw_k[:, 1] = x_y_yaw_k[:, 1] - center_rear_axle_dis * np.sin(x_y_yaw_k[:, 2])
    x = np.asarray(x_y_yaw_k)[:, 0]
    y = np.asarray(x_y_yaw_k)[:, 1]

    # ---------- 一阶导 ----------
    dx = np.gradient(x, dt)
    dy = np.gradient(y, dt)

    # ---------- 航向角 ----------
    motion_yaw = np.arctan2(dy, dx)
    motion_yaw = np.unwrap(motion_yaw)   # 避免跳变
    raw_yaw = np.unwrap(x_y_yaw_k[:, 2].copy())

    # ---------- 二阶导 ----------
    ddx = np.gradient(dx, dt)
    ddy = np.gradient(dy, dt)

    # ---------- 曲率 ----------
    denom = np.maximum((dx**2 + dy**2)**1.5, 1e-3)
    k_by_diff = (dx * ddy - dy * ddx) / denom

    # ---------- 速度（带符号） ----------
    v = np.sqrt(dx**2 + dy**2)
    v_zero_eps = v_eps
    v_yaw_eps = 0.5

    yaw = raw_yaw.copy()
    high_speed_mask = v > v_yaw_eps
    yaw[high_speed_mask] = motion_yaw[high_speed_mask]

    v[v < v_zero_eps] = 0.0

    # ---------- 加速度 ----------
    a = np.gradient(v, dt)
    a[v < v_zero_eps] = 0.0

    yaw = (yaw + np.pi) % (2 * np.pi) - np.pi
    if x_y_yaw_k.shape[1] == 3:
        k = k_by_diff
        print("use k_by_diff")
    else:
        k = x_y_yaw_k[:, 3]

    cur_frame_index = history_size - 1
    ego_labels = []
    optimized_states = []
    decoded_states = []
    if use_trajectory_optimizer:
        coarse_indices = np.arange(cur_frame_index, timestamp_size, segment_labels)
        ref_traj = np.column_stack([
            x[coarse_indices],
            y[coarse_indices],
            yaw[coarse_indices],
            v[coarse_indices],
        ])
        ref_u_traj = np.column_stack([
            a[coarse_indices[1:]],
            k[coarse_indices[1:]],
        ])
        init_state = ref_traj[0].copy()
        u_prev = np.array([a[coarse_indices[0]], k[coarse_indices[0]]], dtype=np.float32)
        try:
            ego_labels = trajectory_optimizer.search(
                init_state,
                ref_traj,
                segment_labels,
                ref_u_traj=ref_u_traj,
                u_prev=u_prev,
            ).tolist()
        except RuntimeError:
            return empty_result()

        for label_id in ego_labels:
            decoded_control = vehicle_tokenizer.decode(label_id)
            decoded_traj = vehicle_tokenizer.rollout(init_state, decoded_control, dt=dt, horizon=segment_labels)
            decoded_state = decoded_traj[0, -1]
            decoded_states.append(np.array([
                decoded_state[0], decoded_state[1], decoded_state[2], decoded_control[1],
                decoded_state[3], decoded_control[0],
            ]))
            init_state = decoded_state
    else:
        init_state = None
        for ts in range(cur_frame_index, timestamp_size - segment_labels):
            if (ts - cur_frame_index) % segment_labels != 0:
                continue

            target_idx = ts + segment_labels
            target_state = np.array([x[target_idx], y[target_idx], yaw[target_idx], v[target_idx]])
            if init_state is None:
                init_state = np.array([x[ts], y[ts], yaw[ts], v[ts]])

            label_id, error = vehicle_tokenizer(init_state, target_state, with_error=True, dt=dt, horizon=segment_labels)
            ego_labels.append(label_id)

            decoded_control = vehicle_tokenizer.decode(label_id)

            decoded_traj = vehicle_tokenizer.rollout(init_state, decoded_control, dt=dt, horizon=segment_labels)
            decoded_state = decoded_traj[0, -1]
            decoded_states.append(np.array([decoded_state[0], decoded_state[1], decoded_state[2], decoded_control[1],
                                            decoded_state[3], decoded_control[0]]))

            init_state = decoded_state

    ego_labels = np.array(ego_labels)
    if len(optimized_states) == 0:
        optimized_states = decoded_states
    optimized_states = np.array(optimized_states)
    decoded_states = np.array(decoded_states)

    gt_traj = np.column_stack([x[cur_frame_index + segment_labels : timestamp_size : segment_labels],
                               y[cur_frame_index + segment_labels : timestamp_size : segment_labels],
                               yaw[cur_frame_index + segment_labels : timestamp_size : segment_labels],
                               k[cur_frame_index + segment_labels : timestamp_size : segment_labels],
                               v[cur_frame_index + segment_labels : timestamp_size : segment_labels],
                               a[cur_frame_index + segment_labels : timestamp_size : segment_labels]])

    # ---------- 异常数据过滤 ------------
    if use_filter:
        max_abs_k_by_diff = np.max(np.abs(k_by_diff[cur_frame_index + segment_labels : timestamp_size : segment_labels]))
        max_abs_k = np.max(np.abs(k[cur_frame_index + segment_labels : timestamp_size : segment_labels]))
        max_a = np.max(a[cur_frame_index + segment_labels : timestamp_size : segment_labels])
        min_a = np.min(a[cur_frame_index + segment_labels : timestamp_size : segment_labels])
        max_yaw_diff = np.max(np.abs(np.diff(yaw[cur_frame_index + segment_labels : timestamp_size : segment_labels])))

        # filter reverse trajectory
        yaw_diff = (motion_yaw - raw_yaw + np.pi) % (2 * np.pi) - np.pi
        future_reverse_mask = (np.abs(yaw_diff[history_size - 1 : timestamp_size]) > (0.5 * np.pi)) & (
            v[history_size - 1 : timestamp_size] > v_eps
        )

        if max_abs_k_by_diff > 0.5 or max_abs_k > 0.2 or max_a > 3.0 or min_a < -6.0 or max_yaw_diff > np.pi * 0.5\
                or len(ego_labels) != ego_label_len or np.any(future_reverse_mask):
            return empty_result()

    return ego_labels, gt_traj, optimized_states, decoded_states


class Plannn2Dataset(BaseDataset):
    def __init__(
        self,
        meta_file,
        frame_downsample=1,
        item_mini_batch=1,
        timestamp_size=40,
        history_state_size=800,
        ori_od_select_state_size=800,
        max_obj_token=96,
        env_block_size=380,
        history_size=15,
        mode="pretrain",
        polyline_size=4,
        with_action_token=False,
        use_quantized_state=False,
        start_at_idx=None,
        navi_path_dropout=0.0,
        static_scene=False,
        swap_ego_and_agent=False,
        tp_mode="train",
        vehicle_tokenizer=None,
        transforms=None,
        segment_labels=None,
        hist_quanti=False,
        mark_idx_list=None,
        expert_data_ann_file=None,
        vis_polygon=False,
        need_road_boundary=False,
        train_data_num=None,
        use_trajectory_optimizer=False,
        start_idx_sample_mode = "acc",
        **kargs,
    ):
        super().__init__(mode=tp_mode, transforms=transforms)
        gc.disable()

        self.vis_polygon = vis_polygon
        self.tp_mode = tp_mode
        self.item_mini_batch = item_mini_batch
        self.timestamp_size = timestamp_size
        self.env_block_size = env_block_size
        self.history_size = history_size
        self.min_history_size = 3
        self.history_state_size = history_state_size
        self.ori_od_select_state_size = ori_od_select_state_size
        self.max_obj_token = max_obj_token
        self.segment_labels = segment_labels
        self.hist_quanti = hist_quanti
        self.train_data_num = train_data_num
        self.state_block_size = history_state_size + self.timestamp_size - self.history_size
        self.with_action_token = with_action_token  # state中包含运动状态token
        self.vehicle_tokenizer = MODULE.build(vehicle_tokenizer)
        if with_action_token:
            raise NotImplementedError("with_action_token not implemented yet")
        self.use_quantized_state = use_quantized_state
        assert mode in ["pretrain", "infer", "rl", "sft"]
        self.mode = mode
        self.frame_downsample = frame_downsample
        assert 5 % frame_downsample == 0, "frame_downsample should be a factor of 15"
        self.fps = 5 // frame_downsample
        # 模拟范围：自车以120km/h速度行驶时的最大范围的1.5倍
        self.state_range = 120 / 3.6 * (40 / self.fps) * 1.5  # 400
        self.polyline_size = polyline_size
        self.label_error_threshold_vehicle = 5
        self.label_error_threshold_pedestrian = 2
        train_datas = []
        self.sample_subset_list = []
        key_frame_sample_mode = []
        key_frame_flags = []
        self.reward_meta_map = {}
        self.expert_data_ann_file = expert_data_ann_file
        self.longitudinal_checker = LongitudinalChecker(
            history_size=self.history_size, timestamp_size=self.timestamp_size
        )
        self.effective_change_lane_checker = EffectiveChangeLaneChecker(
            history_size=self.history_size, timestamp_size=self.timestamp_size
        )
        self.humanoid_checker = HumanoidChecker(history_size=self.history_size)
        special_train_datas = []
        offline_tag_path = []
        offline_tag_subset_checker_name = []
        if tp_mode == "eval_rewards":
            eval_rewards_dataset = meta_file["plannn2"]["eval_rewards"]
            for scenario_name, scenario_config in eval_rewards_dataset.items():
                dataset_config = scenario_config["dataset"]
                reward_list = scenario_config["reward_list"]

                cur_expert_path_list = []
                cur_failure_path_list = []
                for expert_path in dataset_config.get("expert_data", []):
                    with open(expert_path) as f:
                        cur_expert_path_list.extend(l for l in f.readlines() if l.strip())
                for failure_path in dataset_config.get("failure_data", []):
                    with open(failure_path) as f:
                        cur_failure_path_list.extend(l for l in f.readlines() if l.strip())
                train_datas.extend(cur_expert_path_list)
                train_datas.extend(cur_failure_path_list)

                for cur_path in cur_expert_path_list:
                    cur_path_slice = cur_path.split("/")
                    clip_id = cur_path_slice[cur_path_slice.index("output") + 1].split("_")[0]
                    self.reward_meta_map[cur_path] = {
                        "scenario": scenario_name,
                        "dataset_type": "expert",
                        "reward_list": reward_list,
                        "clip_id": clip_id,
                    }
                for cur_path in cur_failure_path_list:
                    cur_path_slice = cur_path.split("/")
                    clip_id = cur_path_slice[cur_path_slice.index("output") + 1].split("_")[0]
                    self.reward_meta_map[cur_path] = {
                        "scenario": scenario_name,
                        "dataset_type": "failure",
                        "reward_list": reward_list,
                        "clip_id": clip_id,
                    }
        else:
            meta_entry = meta_file["plannn2"][tp_mode]
            scenario_data_dict: Dict[str, List] = dict()
            if isinstance(meta_entry, dict):
                for subset_name, subset_cfg in meta_entry.items():
                    ds_list = []
                    key_frame_txt_flags = []
                    key_frame_txt_sample_mode = []
                    if isinstance(subset_cfg, dict):
                        for subset_checker_name, subset_checker_cfg in subset_cfg.items():
                            if subset_checker_name in list(
                                train_data_tag_config[subset_name].keys()
                            ) and "clip_copy_times" in list(
                                train_data_tag_config[subset_name][subset_checker_name].keys()
                            ):
                                copy_times = train_data_tag_config[subset_name][subset_checker_name]["clip_copy_times"]
                            else:
                                copy_times = 1
                            ds_list = ds_list + subset_checker_cfg * copy_times
                            if subset_checker_name == "normal":
                                key_frame_txt_flags = (
                                    key_frame_txt_flags + [None] * len(subset_checker_cfg) * copy_times
                                )
                                key_frame_txt_sample_mode = (
                                    key_frame_txt_sample_mode + [None] * len(subset_checker_cfg) * copy_times
                                )
                            elif train_data_tag_config[subset_name][subset_checker_name]["sample_mode"] == "offline":
                                if "offline_tag_path" in list(
                                    train_data_tag_config[subset_name][subset_checker_name].keys()
                                ):
                                    key_frame_txt_flags = (
                                        key_frame_txt_flags + ["offline_local"] * len(subset_checker_cfg) * copy_times
                                    )
                                    key_frame_txt_sample_mode = key_frame_txt_sample_mode + ["offline_local"] * len(
                                        subset_checker_cfg * copy_times
                                    )
                                    offline_tag_path = (
                                        offline_tag_path
                                        + train_data_tag_config[subset_name][subset_checker_name]["offline_tag_path"]
                                    )
                                    offline_tag_subset_checker_name = offline_tag_subset_checker_name + [
                                        subset_name + "--" + subset_checker_name
                                    ] * len(subset_checker_cfg)
                                else:
                                    key_frame_txt_flags = (
                                        key_frame_txt_flags + ["offline_server"] * len(subset_checker_cfg) * copy_times
                                    )
                                    key_frame_txt_sample_mode = (
                                        key_frame_txt_sample_mode
                                        + ["offline_server"] * len(subset_checker_cfg) * copy_times
                                    )
                            else:
                                key_frame_txt_flags = (
                                    key_frame_txt_flags
                                    + [train_data_tag_config[subset_name][subset_checker_name]["key_frame_checker"]]
                                    * len(subset_checker_cfg)
                                    * copy_times
                                )
                                key_frame_txt_sample_mode = (
                                    key_frame_txt_sample_mode
                                    + [train_data_tag_config[subset_name][subset_checker_name]["sample_mode"]]
                                    * len(subset_checker_cfg)
                                    * copy_times
                                )
                    else:
                        ds_list = ds_list + subset_cfg
                        key_frame_txt_flags = key_frame_txt_flags + [None] * len(subset_cfg)
                        key_frame_txt_sample_mode = key_frame_txt_sample_mode + [None] * len(subset_cfg)
                    # 收集该子集的所有数据行
                    subset_lines = []
                    subset_line_flag = []
                    subset_line_flag_sample_mode = []
                    for ds_num_index, ds_index in enumerate(ds_list):
                        with open(ds_index) as f:
                            lines = [l for l in f.readlines() if l.strip()]
                            subset_lines.extend(lines)
                            subset_line_flag.extend([key_frame_txt_flags[ds_num_index]] * len(lines))
                            subset_line_flag_sample_mode.extend([key_frame_txt_sample_mode[ds_num_index]] * len(lines))
                    data_flag_pair = list(zip(subset_lines, subset_line_flag, subset_line_flag_sample_mode))

                    # 根据train_data_num调整数据量
                    if self.train_data_num is not None:
                        target_num = self.train_data_num.get(subset_name, None)
                        if target_num is not None:
                            actual_num = len(subset_lines)
                            if actual_num > target_num:
                                # 数据量多于目标数量，随机选择目标数量的行
                                data_flag_pair = random.sample(data_flag_pair, target_num)
                                subset_lines_split, subset_line_flag_split, subset_line_flag_sample_mode_split = zip(
                                    *data_flag_pair
                                )
                                subset_lines = list(subset_lines_split)
                                subset_line_flag = list(subset_line_flag_split)
                                subset_line_flag_sample_mode = list(subset_line_flag_sample_mode_split)
                            elif actual_num < target_num:
                                # 数据量少于目标数量，随机重复某些行扩展到目标数量
                                # 先复制原始数据，然后随机采样补足差额
                                shortage = target_num - actual_num
                                data_flag_pair = random.choices(data_flag_pair, k=shortage)
                                subset_lines_split, subset_line_flag_split, subset_line_flag_sample_mode_split = zip(
                                    *data_flag_pair
                                )
                                subset_lines.extend(list(subset_lines_split))
                                subset_line_flag.extend(list(subset_line_flag_split))
                                subset_line_flag_sample_mode.extend(list(subset_line_flag_sample_mode_split))

                    # 添加调整后的数据
                    train_datas.extend(subset_lines)
                    key_frame_flags.extend(subset_line_flag)
                    key_frame_sample_mode.extend(subset_line_flag_sample_mode)
                    # 为每个数据样本记录子集名称，按追加顺序与 data_list 对齐
                    self.sample_subset_list.extend([subset_name] * len(subset_lines))
            else:
                # 兼容：原始列表形式
                for ds in meta_entry:
                    if isinstance(ds, str):
                        if (
                            ds == "/share-global/weidong.shi1/data/planner/valid_data.txt"
                            or ds == "/share-global/menghan.pan/planner_nn_data/lane_change_0909.txt"
                        ):
                            with open(ds) as f:
                                special_train_datas.extend(l for l in f.readlines() if l.strip())
                        else:
                            with open(ds) as f:
                                train_datas.extend(l for l in f.readlines() if l.strip())
                    else:
                        assert isinstance(ds, (list, tuple)) and 2 == len(ds), f"Unknown data config '{ds}'"
                        fp, scenario = ds
                        if scenario not in scenario_data_dict:
                            scenario_data_dict[scenario] = []
                        scenario_data_lst = scenario_data_dict[scenario]
                        scenario_data_lst.append(fp)
                key_frame_flags = key_frame_flags + [None] * len(train_datas)
                key_frame_sample_mode = key_frame_sample_mode + [None] * len(train_datas)
                self.sample_subset_list.extend([None] * len(train_datas))
        if len(offline_tag_path) > 0:
            clipid_tag = self.cal_clip_tag(offline_tag_path, offline_tag_subset_checker_name, train_datas)
            self.clipid_tag = clipid_tag
        else:
            self.clipid_tag = {}
        self.key_frame_flags = key_frame_flags
        self.key_frame_sample_mode = key_frame_sample_mode

        self.mark_idx_list = mark_idx_list

        path_lists = []
        for train_data in train_datas:
            try:
                data = json.loads(train_data)  # 尝试 JSON 解析
                path = data.get("path", "")  # 新格式：读 path
                path_lists.append(path)
            except (json.JSONDecodeError, TypeError):
                path = train_data
                path_lists.append(path)

        if mark_idx_list is not None:
            self.data_list = [path_lists[i] for i in mark_idx_list]
        else:
            self.data_list = path_lists
        ori_data = self.data_list

        self.data_list = []
        self.data_list += [(False, i) for i in special_train_datas]
        self.data_list += [(True, i) for i in ori_data]
        self.scenario_id_lst = [ScenarioEnum.UNK] * len(self.data_list)
        if self.mode == "rl":
            if len(scenario_data_dict) > 0:
                self._add_scenario_data_lst(scenario_data_dict)
        self.build_path_to_tags_dict(pretrain_meta_label_path, sft_meta_label_path)
        self.build_data_length_index()
        self.start_at_idx = start_at_idx  # infer mode从0开始
        self.navi_path_dropout = navi_path_dropout
        self.property_dim = 12
        self.max_lane_num = 13  # 如果修改需要同时修改common中的定义
        self.static_scene = static_scene
        self.swap_ego_and_agent = swap_ego_and_agent
        self.need_road_boundary = need_road_boundary
        self.kwargs = self.make_kwargs()

        assert (
            len(self.data_list)
            == len(self.scenario_id_lst)
            == len(self.key_frame_flags)
            == len(self.key_frame_sample_mode)
        ), (
            f"Length mismatch: data_list {len(self.data_list)}, scenario_id_lst {len(self.scenario_id_lst)}, key_frame_flags {len(self.key_frame_flags)}, "
            f"key_frame_sample_mode {len(self.key_frame_sample_mode)}"
        )
        self.dirty_meta = {}
        if "dirty_tag_meta" in meta_file["plannn2"]:
            for pkl in meta_file["plannn2"]["dirty_tag_meta"]:
                with open(pkl, 'rb') as f:
                    self.dirty_meta.update(pickle.load(f))
        self.make_mpo_data(meta_file)

        self.dt = 0.2

        self.use_trajectory_optimizer = use_trajectory_optimizer
        self.start_idx_sample_mode = start_idx_sample_mode

    def _add_scenario_data_lst(self, scenario_data_dict: Dict[str, List]):
        data_list_backup = self.data_list
        ret_scenario_id_lst = []
        ret_lst = []
        tmp_data_lst = []
        for scenario, fps in scenario_data_dict.items():
            if 0 == len(fps):
                continue
            tmp_data_lst = []
            for fp in fps:
                with open(fp) as f:
                    tmp_data_lst.extend(l for l in f.readlines() if l.strip())
            self.data_list = tmp_data_lst

            ret_scenario_id_lst.extend([ScenarioEnum.from_string(scenario)] * len(self.data_list))
            ret_lst.extend([(False, d) for d in self.data_list])
        self.scenario_id_lst.extend(ret_scenario_id_lst)
        self.data_list = data_list_backup
        self.data_list.extend(ret_lst)
        self.key_frame_flags.extend([None] * len(ret_lst))
        self.key_frame_sample_mode.extend([None] * len(ret_lst))
        assert len(self.scenario_id_lst) == len(
            self.data_list
        ), f"inequal length for scenario '{len(self.scenario_id_lst)}' vs data '{len(self.data_list)}'"

    def __len__(self):
        return len(self.data_list)

    @staticmethod
    def _extract_clip_id(path: str) -> str:
        """Extract clip_id from data path via pkl filename (without .pkl suffix).

        Robust to varying path prefix depths. Path structure: .../<clip_id>/output/<clip_id>.pkl
        """
        basename = os.path.basename(path.split()[0])  # remove filesize if present
        return basename.replace(".pkl", "")

    def __getstate__(self):
        super().__getstate__()
        state = self.__dict__.copy()
        state.pop("tag_storage", None)
        state.pop("clipid_tag", None)
        return state

    def cal_clip_tag(self, offline_tag_path, offline_tag_subset_checker_name, train_datas):
        train_clip_id_set = {self._extract_clip_id(train_data) for train_data in train_datas}
        clip_tags = {}
        # 遍历所有txt文件
        for idx, tag_file in enumerate(offline_tag_path):
            with open(tag_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    data = json.loads(line)
                    clip_id = data["clip_id"]
                    if clip_id not in train_clip_id_set:
                        continue
                    tags = data["tags"]
                    if clip_id not in clip_tags:
                        clip_tags[clip_id] = {offline_tag_subset_checker_name[idx]: tags}
                    elif offline_tag_subset_checker_name[idx] not in clip_tags[clip_id]:
                        clip_tags[clip_id][offline_tag_subset_checker_name[idx]] = tags
                    elif tags not in clip_tags[clip_id][offline_tag_subset_checker_name[idx]]:
                        clip_tags[clip_id][offline_tag_subset_checker_name[idx]] = (
                            clip_tags[clip_id][offline_tag_subset_checker_name[idx]] + tags
                        )
        return clip_tags

    def build_data_length_index(self):
        """build data length index for fast access,
        data is ceph_path filesize data_length, read data_length as index and keep ceph_path filesize left.
        if data is ceph_path filesize, set data_length to 100000.
        """
        self.data_length_index = []
        for i, data_path in enumerate(self.data_list):
            content = data_path[1].split()
            if len(content) == 3:
                ceph_path, filesize, data_length = content
                data_length = int(data_length)
                self.data_length_index.append(data_length)
                self.data_list[i] = (data_path[0], " ".join([ceph_path, filesize]), None)
                if data_path in self.reward_meta_map:
                    self.reward_meta_map[self.data_list[i]] = self.reward_meta_map[data_path]
                    del self.reward_meta_map[data_path]
            elif len(content) == 4:
                ceph_path, filesize, data_length, closed_timestamp = content
                data_length = int(data_length)
                self.data_length_index.append(data_length)
                self.data_list[i] = (data_path[0], " ".join([ceph_path, filesize]), closed_timestamp)
                if data_path in self.reward_meta_map:
                    self.reward_meta_map[self.data_list[i]] = self.reward_meta_map[data_path]
                    del self.reward_meta_map[data_path]
            else:
                self.data_list[i] = self.data_list[i] + (None,)
                self.data_length_index.append(100000)

    def build_path_to_tags_dict(self, pretrain_meta_label_path, sft_meta_label_path):
        if self.mode not in ['pretrain', 'sft'] or not pretrain_meta_label_path or not sft_meta_label_path:
            return
        if self.mode == 'pretrain':
            meta_label_path = pretrain_meta_label_path
        elif self.mode == 'sft':
            meta_label_path = sft_meta_label_path

        print(f"Loading meta label from pkl: {meta_label_path}")
        with open(meta_label_path, 'rb') as f:
            self.tag_storage = pickle.load(f)
        print(f"Meta label loaded: {self.tag_storage.stats['total_clips']:>8,} clips")

    def get_tags_for_path(self, uuid):
        if not hasattr(self, 'tag_storage'):
            return []

        tags = self.tag_storage.get_tags(uuid)
        return tags

    def make_kwargs(self):
        kwargs = {
            "mode": self.mode,
            "state_range": self.state_range,
            "history_size": self.history_size,
            "timestamp_size": self.timestamp_size,
            "env_block_size": self.env_block_size,
            "min_history_size": self.min_history_size,
            "history_state_size": self.history_state_size,
            "ori_od_select_state_size": self.ori_od_select_state_size,
            "polyline_size": self.polyline_size,
            "env_block_size": self.env_block_size,
            "navi_path_dropout": self.navi_path_dropout,
            "max_lane_num": self.max_lane_num,
            "property_dim": self.property_dim,
            "static_scene": self.static_scene,
            "vis_polygon": self.vis_polygon,
        }
        return kwargs

    @property
    def data_lengths(self):
        return self.data_length_index

    @property
    def num_classes(self):
        return len(self.vehicle_tokenizer)

    def _get_obj_from_relative_pose(self, obj1, dx, dy, dyaw):
        obj1_pose = np.eye(4)
        obj1_pose[:3, :3] = R.from_euler("z", obj1[6]).as_matrix()
        obj1_pose[:3, 3] = obj1[:3]
        move = np.eye(4)
        move[:2, 3] = [dx, dy]
        move[:3, :3] = R.from_euler("z", dyaw).as_matrix()
        obj2_pose = obj1_pose @ move
        obj2 = obj1.copy()
        obj2[:3] = obj2_pose[:3, 3]
        obj2[6] = R.from_matrix(obj2_pose[:3, :3]).as_euler("xyz")[2]
        return obj2

    @staticmethod
    def interpolate_state(obj1, obj2, ratio):
        """
        obj1, obj2: at least 7 dim, x, y, z, l, w, h, yaw, ....
        """
        # interpolate yaw
        yaw1 = obj1[6]
        yaw2 = obj2[6]
        new_yaw = interpolate_angles(yaw1, yaw2, ratio)
        diff_other = obj2 - obj1
        new_obj = obj1.copy()
        new_obj[6] = new_yaw
        new_obj[:3] = obj1[:3] + diff_other[:3] * ratio
        return new_obj

    @staticmethod
    def judge_obj_property(tids, tid_histobjs, center, origin_yaw, road_edge_polylines):
        """
        剔除路沿外静态的 vehicle & bicycle
            路沿外: 连线和路沿仅有一个交点
            静态: 速度最大值小于 0.1m/s?
        剔除15帧内都在远离自车的目标 (包括行人?)
            最后一帧的距离 > n米
        静态目标保留一帧
            不区分死车和拥堵车,交由模型判断
        """
        pedestrian_flags = np.zeros(len(tids), dtype=bool)
        static_flags = np.zeros(len(tids), dtype=bool)
        runaway_flags = np.zeros(len(tids), dtype=bool)
        crossedge_flags = np.zeros(len(tids), dtype=bool)
        for i, tid in enumerate(tids):
            histobjs = tid_histobjs[tid]

            # 是否是行人
            cid = get_map_cls_to_3cls(histobjs[-1, 7])  # ["vehicle", "bicycle", "pedestrian"]
            if cid == "pedestrian":
                pedestrian_flags[i] = True

            # 是否静止目标
            if len(histobjs) > 5:
                speeds = np.linalg.norm(histobjs[:, 10:12], axis=1)
                traj_dist = np.linalg.norm(histobjs[0, :2] - histobjs[-1, :2])
                if speeds.max() < 0.1 and traj_dist < 0.2:  # 最大速度小于0.1m/s, 行进距离小于0.2m
                    static_flags[i] = True

            # 是否是远离自车的对向车
            if len(histobjs) > 5:
                dist_to_ego = np.linalg.norm(histobjs[:, :2] - center, axis=1)
                dist_diff = dist_to_ego[1:] - dist_to_ego[:-1]
                obj_yaw = norm_yaw(histobjs[-1, 6] - origin_yaw)  # 历史最后一帧，自车坐标系中
                if (
                    np.abs(obj_yaw - np.pi) < np.pi / 6 and dist_to_ego[0] > 10 and np.all(dist_diff > 0.5)
                ):  # 与自车朝向相反,距离自车超过10m,逐渐远离
                    runaway_flags[i] = True

            # 是否在路沿外
            obs_vector_polyline = LineString([histobjs[-1, :2], center])
            for roadedge in road_edge_polylines:
                intersection = obs_vector_polyline.intersection(roadedge)
                num_intersections = (
                    intersection.geom_type == "MultiPoint" and len(intersection.geoms) or 1
                    if intersection.geom_type == "Point"
                    else 0
                )
                if num_intersections == 1:
                    crossedge_flags[i] = True
                    break

        keep_index = np.where(~(crossedge_flags & static_flags & ~pedestrian_flags) & ~(runaway_flags))[0]
        keep_tids = tids[keep_index]
        static_flags = static_flags[keep_index]
        return keep_tids, static_flags

    @staticmethod
    def dobj_to_ego_distance(input_tids, tid_histobjs, center, tree):
        distance = []
        for tid in input_tids:
            histobjs = tid_histobjs[tid]
            if tree is not None:
                dist, _ = tree.query(histobjs[-1, :2])
            else:
                dist = np.linalg.norm(histobjs[-1, :2] - center)
            distance.append(dist)
        return np.array(distance)

    @staticmethod
    def get_trackid_hist_objs(frame_agents, input_track_ids, frame_tid_map_list, history_size):
        # 历史帧中，每个目标的轨迹
        tid_histobjs = {tid: [] for tid in input_track_ids}
        for tid_dict, (ego_pose, dobjs_full) in zip(frame_tid_map_list, frame_agents[:history_size]):
            for tid in input_track_ids:
                if (obj_idx := tid_dict.get(tid)) is not None:
                    tid_histobjs[tid].append(dobjs_full[obj_idx])
        tid_histobjs = {tid: np.stack(objs) for tid, objs in tid_histobjs.items()}
        return tid_histobjs

    @staticmethod
    def dobj_select_all(frame_agents, center, origin_yaw, way_points, roadedge, **kwargs):
        """
        选取第0帧出现的尽量全部的物体:
            - 剔除路沿外静态的 vehicle & bicycle
                路沿外: 连线和路沿仅有一个交点
                静态: 速度最大值小于 0.1m/s?
            - 剔除15帧内都在远离自车的目标 (包括行人?)
                最后一帧的距离 > n米
            - 静态目标保留一帧
                不区分死车和拥堵车
            - 如果物体驶出target range, label为-1
        """
        # roadedge
        self_history_size = kwargs["history_size"]
        self_min_history_size = kwargs["min_history_size"]
        self_ori_od_select_state_size = kwargs["ori_od_select_state_size"]
        road_edge_polylines = []
        for p in roadedge:
            if p.shape[0] > 2:
                road_edge_polylines.append(LineString(p[:, :2]))
        # way_points of navi_path
        tree = cKDTree(way_points) if way_points is not None else None

        # 倒序遍历，选取距离waypoints最近的动静态物体
        static_raw_track_ids = set()
        dynamic_raw_track_ids = set()
        hist_tids = set()
        left_state_size = self_ori_od_select_state_size - self_history_size
        history_size = None
        frame_tid_map_list = [
            {obj[9]: i for i, obj in enumerate(dobjs_full)} for _, dobjs_full in frame_agents[:self_history_size]
        ]
        for frame_i, (ego_pose, dobjs_full) in enumerate(frame_agents[:self_history_size][::-1]):
            raw_track_id = dobjs_full[:, 9]
            new_index = np.where([tid not in hist_tids for tid in raw_track_id])[0]  # TODO: check
            dobjs_full = dobjs_full[new_index]
            raw_track_id = raw_track_id[new_index]
            hist_tids.update(raw_track_id)

            tid_histobjs = Plannn2Dataset.get_trackid_hist_objs(
                frame_agents, raw_track_id, frame_tid_map_list, self_history_size
            )
            keep_tids, static_flags = Plannn2Dataset.judge_obj_property(
                raw_track_id, tid_histobjs, center, origin_yaw, road_edge_polylines
            )
            static_tids, dynamic_tids = keep_tids[static_flags], keep_tids[~static_flags]
            static_count, dynamic_count = len(static_tids), len(dynamic_tids)

            if frame_i == 0:
                # 无需牺牲帧数, 全部添加
                if static_count + dynamic_count * self_history_size <= left_state_size:
                    static_raw_track_ids.update(static_tids)
                    dynamic_raw_track_ids.update(dynamic_tids)
                    left_state_size -= static_count + dynamic_count * self_history_size
                    history_size = self_history_size
                # 全部添加，动态帧数 >= 3
                elif static_count + dynamic_count * self_min_history_size <= left_state_size:  # 至少保留 3 帧
                    static_raw_track_ids.update(static_tids)
                    dynamic_raw_track_ids.update(dynamic_tids)
                    history_size = int((left_state_size - static_count) // dynamic_count)
                    left_state_size -= static_count + dynamic_count * history_size
                    break
                # 目标数量太多, 按距离逐个添加
                else:
                    history_size = self_min_history_size
                    distance = Plannn2Dataset.dobj_to_ego_distance(keep_tids, tid_histobjs, center, tree)
                    index = np.argsort(distance)
                    keep_tids = keep_tids[index]
                    static_flags = static_flags[index]
                    _i = 0
                    while left_state_size > 0 and _i < keep_tids.shape[0]:
                        if static_flags[_i]:
                            static_raw_track_ids.add(keep_tids[_i])
                            left_state_size -= 1
                        elif left_state_size >= history_size:
                            dynamic_raw_track_ids.add(keep_tids[_i])
                            left_state_size -= history_size
                        _i += 1
                    break
            else:
                # 按距离逐个添加
                distance = Plannn2Dataset.dobj_to_ego_distance(keep_tids, tid_histobjs, center, tree)
                index = np.argsort(distance)
                keep_tids = keep_tids[index]
                static_flags = static_flags[index]
                _i = 0
                while left_state_size > 0 and _i < keep_tids.shape[0]:
                    if static_flags[_i]:
                        static_raw_track_ids.add(keep_tids[_i])
                        left_state_size -= 1
                    elif left_state_size >= history_size:
                        dynamic_raw_track_ids.add(keep_tids[_i])
                        left_state_size -= history_size
                    _i += 1
            if left_state_size < history_size:
                break

        return static_raw_track_ids, dynamic_raw_track_ids, history_size

    @staticmethod
    def get_np_plus_lcc_status(data, use_timestamps, initpose, lane_lines):
        """
        Args:
            data: dict, 包含所有的帧数据
            use_timestamps: list, 使用的时间戳列表
            initpose: 齐次变换矩阵， 中心位姿
            lane_lines: list, 最后一帧车道线信息
        Returns:
            np_plus_is_activate: bool, True NP+激活, False NP+未激活
        """
        traj = [(initpose @ data[ts]["car_pose"])[:2, 3] for ts in use_timestamps]
        traj = np.array(traj)
        traj_string = LineString(traj[:, :2])
        for p, a in lane_lines:
            if len(p) < 2:
                continue
            polyline = LineString(p[:, :2])
            intersection = traj_string.intersection(polyline)
            if not intersection.is_empty:
                return False
        return True


    def get_state_label(
        self,
        frame_agents,
        center,
        origin_yaw,
        waypoints,
        roadedge,
        lane_change_commands,
        np_plus_lcc_status,
        use_timestamps,
        all_frame_agents,
        wheel_base,
        frnt_whl_ag,
    ):
        """
        Args:
        frame_agents: list of (T, dobjs_full) as each timestamp, T is 4x4 ego pose,
                    dobjs_full is n x 12, x, y, z, l, w, h, yaw, cid, sid, tid, vx, vy
        Returns:
            state_polygon: N x 4 x 2, N is state_block_size
            state_polyline: N x M x 2
            state_poly_mask: N x 2
            state_property: N x 5 cls1(大类), cls2(细分类), 0, tid, timestamp_id
            label: N 车和人的label组合在一起
            raw_dobjs: list of {tid: [dobj, c3, label_id]} for each timestamp
        """
        egoinfo = np.array([[0, 0, 0, 4.85, 2, 2, 0]], dtype=np.float32)

        # 1. 根据历史帧选取动静态的track_id, 并构造到输入网络的tid的映射tid_map以及ego_tid
        static_raw_track_ids, dynamic_raw_track_ids, history_size = self.dobj_select_all(
            frame_agents, center, origin_yaw, waypoints, roadedge, **self.kwargs
        )
        select_raw_track_ids = static_raw_track_ids | dynamic_raw_track_ids
        dobj_start_size = self.history_size - history_size

        # 构造tid_map
        track_id_to_net = np.arange(1, 2 + len(select_raw_track_ids))
        if not self.mode == "infer":
            np.random.shuffle(track_id_to_net[1:])
        tid_map = {tid: track_id_to_net[i + 1] for i, tid in enumerate(select_raw_track_ids)}
        ego_tid = track_id_to_net[0]

        # 2. 遍历构造每个时刻数据，记录每个时刻中在tid_map中物体的状态
        data_all = []
        record_static_tids = set()
        for ts, (ego_pose, dobjs_full) in enumerate(all_frame_agents):
            frame_data = {}
            # ego
            frame_data[ego_tid] = [transform_obj(egoinfo, ego_pose)[0], cls_mapping["ego"], -1]
            # 动静态目标
            if ts < self.history_size:
                raw_track_id = dobjs_full[:, 9]
                in_tid_map = [tid in tid_map for tid in raw_track_id]
                dobjs_full = dobjs_full[in_tid_map]
                cid = dobjs_full[:, 7]
                cid_3cls = [get_map_cls_to_3cls(c) for c in cid]
                for tid, dobj, c3 in zip(raw_track_id[in_tid_map], dobjs_full, cid_3cls):
                    # 如果是人，将yaw角置为0
                    if c3 == "pedestrian":
                        dobj[6] = 0
                    # 静态目标 & 初次出现
                    if tid in static_raw_track_ids and tid not in record_static_tids:
                        frame_data[tid_map[tid]] = [
                            dobj[:7],
                            cls_mapping["static_" + c3],
                            -1,
                        ]  # 静态目标根据最早出现的位置进行排列
                        record_static_tids.add(tid)
                    # 动态目标 & 在动态帧数中
                    elif tid in dynamic_raw_track_ids and ts >= dobj_start_size:
                        frame_data[tid_map[tid]] = [dobj[:7], cls_mapping[c3], -1]
            data_all.append(frame_data)
        data = data_all[: self.timestamp_size + 1]
        data_all_len = len(data_all)

        # 3. 构造 ego label
        x_y_yaw_k = []
        valid_ts = []
        for idx, frame_data in enumerate(data_all):
            dobj, _, _ = frame_data[ego_tid]
            whlbase = wheel_base[idx]
            frntwhlag = frnt_whl_ag[idx]
            if frntwhlag is None:
                x_y_yaw_k.append([dobj[0], dobj[1], dobj[6]])
            else:
                kappa_by_frnt_whl_ag = -1 * np.tan(frntwhlag) / max(1e-6, whlbase)
                x_y_yaw_k.append([dobj[0], dobj[1], dobj[6], kappa_by_frnt_whl_ag])
        if self.mode in ["pretrain", "sft"]:
            ego_labels, _, _, _ = cal_acc_kappa_ego_labels(
                x_y_yaw_k,
                self.vehicle_tokenizer,
                use_filter=True,
                use_trajectory_optimizer=self.use_trajectory_optimizer,
                history_size=self.history_size,
                timestamp_size=self.timestamp_size,
                segment_labels=self.segment_labels,
            )
        else:
            ego_labels = np.full((self.timestamp_size - self.history_size) // self.segment_labels, -1)

        # 4. 构造state_polygon, state_polyline, state_poly_mask, state_property
        # polyline 和 poly_mask为固定值
        state_polyline = np.zeros((self.state_block_size, self.polyline_size, 2))
        state_poly_mask = np.zeros((self.state_block_size, 2))
        state_poly_mask[:, 0] = 1
        state_polygon = []
        state_property = []
        state_labels = []

        ego_polygon = []
        ego_property = []
        tids_all = []

        for ts, frame_data in enumerate(data[:-1]):
            tids, dobjs_full, main_cids, labels = [], [], [], []

            # 其他agent
            if ts < self.history_size:
                for tid, (dobj, main_cid, _) in frame_data.items():
                    if tid == ego_tid:
                        continue
                    tids.append(tid)
                    dobjs_full.append(dobj[:7])
                    main_cids.append(main_cid)
                    labels.append(-1)
                    if tid not in tids_all:  ##记录15帧所有非自车的tid，后面有tid查找对齐objs
                        tids_all.append(tid)

            # 将自车放在每个时间patch的最后
            dobj, main_cid, label_id = frame_data[ego_tid]
            tids.append(ego_tid)
            dobjs_full.append(dobj[:7])
            main_cids.append(main_cid)
            labels.append(label_id)

            polygons = get_rotated_rectangle(np.array(dobjs_full))  # N x 4 x 2
            propertys = np.zeros((len(tids), self.property_dim))
            propertys[:, 0] = main_cids
            propertys[:, 3] = tids
            propertys[:, 4] = ts

            # Add command information for ego vehicle (last entry in each timestamp)
            if lane_change_commands is not None and ts < len(lane_change_commands) and ts < self.history_size:
                # Encode command in property[5] for ego vehicle
                # command: 0=straight, 1=left, 2=right
                ego_idx = len(tids) - 1  # ego is always last
                propertys[ego_idx, 7] = lane_change_commands[ts]

            propertys[:, 8] = 1 if np_plus_lcc_status else 0

            labels = np.array(labels)

            ego_polygon.append(polygons[-1])
            ego_property.append(propertys[-1])

            state_polygon.append(polygons)
            state_property.append(propertys)
            state_labels.append(labels)

        ego_polyline_full = np.zeros((self.timestamp_size, self.polyline_size, 2))
        ego_poly_mask_full = np.zeros((self.timestamp_size, 2))

        ego_polygon_full = np.array(ego_polygon)
        ego_property_full = np.array(ego_property)

        ego_polyline = np.zeros((self.timestamp_size, self.polyline_size, 2))[: self.history_size]
        ego_poly_mask = np.zeros((self.timestamp_size, 2))[: self.history_size]
        ego_poly_mask[:, 0] = 1

        ego_polygon = np.array(ego_polygon)[: self.history_size]
        ego_property = np.array(ego_property)[: self.history_size]

        state_polygon = np.concatenate(state_polygon, axis=0)
        state_property = np.concatenate(state_property, axis=0)
        state_labels = np.concatenate(state_labels, axis=0)

        # get gt_state_polygon & gt_state_property
        gt_state_polygon = []
        gt_state_property = []
        for ts, frame_data in enumerate(data):
            tids, dobjs_full, main_cids = [], [], []
            # 只要自车
            for tid, (dobj, main_cid, _) in frame_data.items():
                if tid == ego_tid:
                    dobj, main_cid, label_id = frame_data[ego_tid]
                    tids.append(ego_tid)
                    dobjs_full.append(dobj[:7])
                    main_cids.append(main_cid)

                    polygons = get_rotated_rectangle(np.array(dobjs_full))  # N x 4 x 2
                    propertys = np.zeros((len(tids), self.property_dim))
                    propertys[:, 0] = main_cids
                    propertys[:, 3] = tids
                    propertys[:, 4] = ts

                    gt_state_polygon.append(polygons)
                    gt_state_property.append(propertys)

        gt_state_polygon = np.concatenate(gt_state_polygon, axis=0)
        gt_state_property = np.concatenate(gt_state_property, axis=0)

        # 5. pad
        if len(frame_agents) < self.timestamp_size + 1:
            future_pad_size = self.timestamp_size + 1 - len(frame_agents)
            state_polygon = np.concatenate([state_polygon, np.zeros((future_pad_size, 4, 2))], axis=0)
            state_property = np.concatenate([state_property, np.zeros((future_pad_size, self.property_dim))], axis=0)
            state_labels = np.concatenate([state_labels, -1 * np.ones(future_pad_size)], axis=0)
            ego_polygon_full = np.concatenate([ego_polygon_full, np.zeros((future_pad_size, 4, 2))], axis=0)
            ego_property_full = np.concatenate(
                [ego_property_full, np.zeros((future_pad_size, self.property_dim))], axis=0
            )

        state_block_size_ori_tmp = self.ori_od_select_state_size + self.timestamp_size - self.history_size
        assert len(state_polygon) == len(state_property) == len(state_labels) <= state_block_size_ori_tmp
        if len(state_polygon) < state_block_size_ori_tmp:
            pad_size = state_block_size_ori_tmp - len(state_polygon)
            state_polygon = np.concatenate([np.zeros((pad_size, 4, 2)), state_polygon], axis=0)
            state_property = np.concatenate([np.zeros((pad_size, self.property_dim)), state_property], axis=0)
            state_labels = np.concatenate([-1 * np.ones(pad_size), state_labels], axis=0)

        select_raw_track_ids = {"static": static_raw_track_ids, "dynamic": dynamic_raw_track_ids}

        # sequence od compress
        od_comp = self.seq_od_token_gen(
            frame_agents,
            np_plus_lcc_status,
            self.max_obj_token,
            self.polyline_size,
            self.history_size,
            self.property_dim,
        )
        state_polygon_comp = od_comp["od_polygon_seq"]
        state_polyline_comp = od_comp["od_polyline_seq"]
        state_property_comp = od_comp["od_property_seq"]
        state_poly_mask_comp = od_comp["od_poly_mask_seq"]

        return (
            state_polygon,
            state_polyline,
            state_poly_mask,
            state_property,
            state_labels,
            data,
            select_raw_track_ids,
            dobj_start_size,
            valid_ts,
            state_polygon_comp,
            state_polyline_comp,
            state_poly_mask_comp,
            state_property_comp,
            ego_polygon,
            ego_polyline,
            ego_property,
            ego_poly_mask,
            ego_labels,
            ego_polygon_full,
            ego_polyline_full,
            ego_property_full,
            ego_poly_mask_full,
            gt_state_polygon,
        )

    @staticmethod
    def seq_od_token_gen(
        frame_agents,
        np_plus_lcc_status,
        max_obj_token,
        polyline_size,
        history_size,
        property_dim,
    ):
        """Generate sequence OD tokens for dynamic objects."""
        history_frame_agents = frame_agents[:history_size]
        all_ods, id_frame_index_mapping = Plannn2Dataset.map_od_id2frame_index(history_frame_agents)
        all_ods = Plannn2Dataset.ped_yaw2zero(all_ods)
        selected_od_ids = Plannn2Dataset.seq_od_select_ids(history_frame_agents[-1][1], max_obj_token)
        od_polygon_seq = Plannn2Dataset.seq_od_polygon_gen(
            all_ods, id_frame_index_mapping, selected_od_ids, history_size, max_obj_token
        )
        od_polyline_seq = Plannn2Dataset.seq_od_polyline_gen(max_obj_token, polyline_size)
        od_property_seq = Plannn2Dataset.seq_od_property_gen(
            all_ods, id_frame_index_mapping, selected_od_ids, np_plus_lcc_status, property_dim, max_obj_token
        )
        od_poly_mask_seq = Plannn2Dataset.seq_od_poly_mask_gen(max_obj_token)

        return {
            "od_polygon_seq": od_polygon_seq,
            "od_polyline_seq": od_polyline_seq,
            "od_property_seq": od_property_seq,
            "od_poly_mask_seq": od_poly_mask_seq,
        }

    @staticmethod
    def ped_yaw2zero(all_ods):
        """Set pedestrian yaw to zero in all_ods."""
        cid = all_ods[:, 7]
        cid_3cls = list(map(get_map_cls_to_3cls, cid))
        ped_index = [idx for idx, c3 in enumerate(cid_3cls) if c3 == "pedestrian"]
        all_ods[ped_index, 6] = 0.0
        return all_ods

    @staticmethod
    def seq_od_select_ids(current_frame_ods, max_obj_token):
        """Select OD ids for dynamic objects in the current frame."""
        selected_ids = None
        od_num = current_frame_ods.shape[0]
        if od_num <= max_obj_token:
            selected_ids = current_frame_ods[:, 9]
        else:
            distance = np.sqrt(current_frame_ods[:, 0] ** 2 + current_frame_ods[:, 1] ** 2)
            index = np.argsort(distance)[:max_obj_token]
            selected_ids = current_frame_ods[sorted(index), 9]
        return selected_ids

    @staticmethod
    def map_od_id2frame_index(history_frame_agents):
        """Map OD ids to frame num and indices."""
        all_ods = np.concatenate([hist_frame[1] for hist_frame in history_frame_agents])
        mapping = defaultdict(list)
        od_index = 0
        for hist_frame_index, (_, hist_agents) in enumerate(history_frame_agents):
            for agent in hist_agents:
                mapping[agent[9]].append((hist_frame_index, od_index))
                od_index += 1

        return all_ods, mapping

    @staticmethod
    def seq_od_polygon_gen(all_ods, id_frame_index_mapping, selected_od_ids, history_size, max_obj_token):
        """Generate sequence OD polygons for dynamic objects."""
        all_ods_polygon = get_rotated_rectangle(all_ods)  # N x 4 x 2
        seq_od_polygons = np.zeros((len(selected_od_ids), history_size, 4, 2))
        for token_index, id_select in enumerate(selected_od_ids):
            for frame_index, all_od_index in id_frame_index_mapping[id_select]:
                seq_od_polygons[token_index, frame_index] = all_ods_polygon[all_od_index]
                assert id_select == all_ods[all_od_index, 9]

        if len(selected_od_ids) < max_obj_token:
            pad_size = max_obj_token - len(selected_od_ids)
            seq_od_polygons = np.concatenate([np.zeros((pad_size, history_size, 4, 2)), seq_od_polygons], axis=0)

        return seq_od_polygons

    @staticmethod
    def seq_od_polyline_gen(max_obj_token, polyline_size):
        """Generate sequence OD polylines for dynamic objects."""
        return np.zeros((max_obj_token, polyline_size, 2))

    @staticmethod
    def seq_od_property_gen(
        all_ods, id_frame_index_mapping, selected_od_ids, np_plus_lcc_status, property_dim, max_obj_token
    ):
        """Generate sequence OD properties for dynamic objects."""
        seq_od_property = np.zeros((len(selected_od_ids), property_dim))
        tid = np.arange(2, 2 + len(selected_od_ids))
        for token_index, od_id in enumerate(selected_od_ids):
            od = all_ods[id_frame_index_mapping[od_id][-1][1]]
            cls23 = get_map_cls_to_3cls(od[7])
            cls_value = cls_mapping[cls23]
            seq_od_property[token_index, 0] = cls_value
            seq_od_property[token_index, 3] = tid[token_index]

        seq_od_property[:, 8] = 1 if np_plus_lcc_status else 0

        if len(selected_od_ids) < max_obj_token:
            pad_size = max_obj_token - len(selected_od_ids)
            seq_od_property = np.concatenate([np.zeros((pad_size, property_dim)), seq_od_property], axis=0)
        return seq_od_property

    @staticmethod
    def seq_od_poly_mask_gen(max_obj_token):
        """Generate sequence OD poly masks for dynamic objects."""
        seq_od_poly_mask = np.zeros((max_obj_token, 2))
        seq_od_poly_mask[:, 0] = 1
        return seq_od_poly_mask

    @staticmethod
    def tids_all_selelct_objs_satisfy_maxobjtoken(tids_all, data, max_obj_token, history_size):
        """Select tids to satisfy max_obj_token limit."""
        if len(set(tids_all)) <= max_obj_token:
            return tids_all
        else:
            tids_seq_ordered = []
            for da in data[:history_size][::-1]:
                distance = [(tid, np.sqrt(obj[0][0] ** 2 + obj[0][1] ** 2)) for tid, obj in da.items() if tid != 1]
                distance_sorted = sorted(distance, key=lambda x: x[1])
                for tid, _ in distance_sorted:
                    if tid not in tids_seq_ordered:
                        tids_seq_ordered.append(tid)
            tids_all = [tid for tid in tids_all if tid in tids_seq_ordered[:max_obj_token]]
            return tids_all

    @staticmethod
    def _stop_line_interp(p, num_interp):
        assert len(p) == 2, "stop line should have 2 points"
        x1, y1 = p[0]
        x2, y2 = p[1]
        x = np.linspace(x1, x2, num_interp)
        y = np.linspace(y1, y2, num_interp)
        return np.stack([x, y], axis=1)

    @staticmethod
    def polyline_to_size(polyline, size, center):
        n = len(polyline)
        if n > size:
            distance = np.linalg.norm(polyline - center, axis=1)
            idx = np.argsort(distance)[:size]
            polyline = polyline[idx]
        elif n < size:
            polyline = np.concatenate([polyline, np.zeros((size - n, 2))], axis=0)
        return polyline

    @staticmethod
    def split_line(p, segment_length=4):
        """
        p: N x 2
        """
        n = len(p)
        idx = np.arange(0, n, segment_length - 1)
        data = [p[i : i + segment_length] for i in idx]
        return data

    @staticmethod
    def _get_lane_id_position(lane_id, num_lane_infos, max_lane_num, mode):
        """
        convert lane_id to "from left nth" or "from right nth",
        ex: lane_id 2 num_lane_infos 3 -> from right position 0
            lane_id 2 num_lane_infos 5 -> from left position 2
        """
        if num_lane_infos <= 0:
            raise ValueError(f"num_lane_infos must be positive, got {num_lane_infos}")
        if lane_id < 0:
            raise ValueError(f"lane_id must be non-negative, got {lane_id}")
        if lane_id >= max_lane_num or lane_id >= num_lane_infos:
            raise ValueError(f"lane_id {lane_id} >= max_lane_num {max_lane_num} or num_lane_infos {num_lane_infos}")

        from_left = True
        position = lane_id
        from_right_position = num_lane_infos - lane_id - 1
        if mode in ["pretrain", "sft"]:
            if lane_id >= max_lane_num / 2:
                from_left = False
                position = from_right_position
            elif from_right_position >= max_lane_num // 2:
                pass
            else:
                if np.random.rand() > 0.5:
                    from_left = False
                    position = from_right_position
        else:
            if lane_id > num_lane_infos / 2:
                from_left = False
                position = from_right_position
        return from_left, position

    @staticmethod
    def _encode_lane_navi_info(lane_is_ok, lane_direction):
        result = 0
        result |= lane_direction << 1
        result |= lane_is_ok
        return result

    @staticmethod
    def get_env(
        sobjs,
        sobjs_polygon,
        god_polygon,
        road_sign,
        lane_lines,
        road_edge,
        nomap_road_edge,
        stop_line,
        tld,
        spd_limit,
        navi_infos,
        center,
        **kwargs,
    ):
        """
        Args:
            sobjs: N x 12, x, y, z, l, w, h, yaw, cid, sid, tid, vx, vy
            sobjs_polygon: N x 4 x 2
            road_sign: list of (polygon 4x2, ptype)
            lane_lines: list of (polyline Nx2, ptype_and_color N x 2)
            road_edge: list of polyline Nx2
            nomap_road_edge: list of polyline Nx2
            stop_line: list of polyline Nx2
            tld: str, traffic light color
            navi_infos: see create_empty_navi_info()
            spd_limit: int
        """
        # sobjs
        n = len(sobjs)
        polyline_size = kwargs["polyline_size"]
        env_block_size = kwargs["env_block_size"]
        property_dim = kwargs["property_dim"]
        max_lane_num = kwargs["max_lane_num"]
        mode = kwargs["mode"]

        sobjs_polylines = np.zeros((n, polyline_size, 2))  # N x M x 2
        sobjs_property = np.concatenate(
            [np.array([cls_mapping["sobj"]] * n)[:, None], np.zeros((n, property_dim - 1))], axis=1
        )  # N x property_dim
        sobjs_polymask = np.zeros((n, 2))  # N x 2
        sobjs_polymask[:, 0] = 1

        # process gate maching
        mask_gate = sobjs[:, 7] == 29
        sobjs_property[mask_gate, 0] = cls_mapping["gate_machine"]
        sobjs_property[mask_gate, 1] = get_gate_machine_cls2_mapping(sobjs[mask_gate, 8])

        # road_sign
        road_sign_without_arrow = [
            (p, ptype) for (p, ptype) in road_sign if ptype not in road_arrow_to_lane_direction_mapping
        ]
        n = len(road_sign_without_arrow)
        road_sign_polygon = np.zeros((n, 4, 2))  # N x 4 x 2

        road_sign_polylines = np.zeros((n, polyline_size, 2))  # N x M x 2
        road_sign_property = np.zeros((n, property_dim))
        road_sign_property[:, 0] = cls_mapping["road_sign"]
        for i, (p, ptype) in enumerate(road_sign_without_arrow):
            road_sign_polygon[i, :, :] = p[:, :2]
            road_sign_property[i, 1] = get_road_sign_cls2_mapping(ptype)
        road_sign_polymask = np.zeros((n, 2))  # N x 2
        road_sign_polymask[:, 0] = 1

        # road arrow
        road_arrow = [(p, ptype) for (p, ptype) in road_sign if ptype in road_arrow_to_lane_direction_mapping]
        n = len(road_arrow)
        road_arrow_polygon = np.zeros((n, 4, 2))  # N x 4 x 2

        road_arrow_polylines = np.zeros((n, polyline_size, 2))  # N x M x 2
        road_arrow_property = np.zeros((n, property_dim))
        road_arrow_property[:, 0] = cls_mapping["road_arrow"]
        for i, (p, ptype) in enumerate(road_arrow):
            road_arrow_polygon[i, :, :] = p[:, :2]
            road_arrow_property[i, 1] = get_road_sign_cls2_mapping(ptype)
            road_arrow_property[i, 6] = road_arrow_to_lane_direction_mapping[ptype] << 1
        road_arrow_polymask = np.zeros((n, 2))  # N x 2
        road_arrow_polymask[:, 0] = 1

        # lane_lines
        lane_lines_polygon = []  # np.zeros((n, 4, 2))  # N x 4 x 2
        lane_lines_polylines = []  # np.zeros((n, polyline_size, 2))
        lane_lines_property = []  # np.zeros((n, 5))
        lane_lines_polymask = []  #  np.zeros((n, 2))  # N x 2
        for i, (p, a) in enumerate(lane_lines):
            p = p[:, :2]
            segments = Plannn2Dataset.split_line(p, polyline_size)
            attr_segments = Plannn2Dataset.split_line(a, polyline_size)
            for segment, attr in zip(segments, attr_segments):
                lane_lines_polygon.append(np.zeros((4, 2)))
                _property = np.zeros(property_dim)
                _property[0] = cls_mapping["lane_lines"]
                _property[1] = get_lane_line_cls2_mapping(attr[0, 0])
                _property[2] = attr[0, 1]
                lane_lines_property.append(_property)
                lane_lines_polymask.append(np.array([0, min(polyline_size, len(segment))]))
                if segment.shape[0] < polyline_size:
                    segment = np.concatenate([segment, np.zeros((polyline_size - segment.shape[0], 2))], axis=0)
                lane_lines_polylines.append(segment)
        lane_lines_polygon = np.stack(lane_lines_polygon, axis=0) if lane_lines_polygon else np.zeros((0, 4, 2))
        lane_lines_polylines = (
            np.stack(lane_lines_polylines, axis=0) if lane_lines_polylines else np.zeros((0, polyline_size, 2))
        )
        lane_lines_property = (
            np.stack(lane_lines_property, axis=0) if lane_lines_property else np.zeros((0, property_dim))
        )
        lane_lines_polymask = np.stack(lane_lines_polymask, axis=0) if lane_lines_polymask else np.zeros((0, 2))

        # road_edge
        road_edge_polygon = []
        road_edge_polylines = []
        road_edge_property = []
        road_edge_polymask = []
        for i, p in enumerate(road_edge + nomap_road_edge):
            p = p[:, :2]
            segments = Plannn2Dataset.split_line(p, polyline_size)
            for segment in segments:
                road_edge_polygon.append(np.zeros((4, 2)))
                _property = np.zeros(property_dim)
                _property[0] = cls_mapping["road_edge"] if i < len(road_edge) else cls_mapping["nomap_road_edge"]
                road_edge_property.append(_property)
                road_edge_polymask.append(np.array([0, min(polyline_size, len(segment))]))
                if segment.shape[0] < polyline_size:
                    segment = np.concatenate([segment, np.zeros((polyline_size - segment.shape[0], 2))], axis=0)
                road_edge_polylines.append(segment)
        road_edge_polygon = np.stack(road_edge_polygon, axis=0) if road_edge_polygon else np.zeros((0, 4, 2))
        road_edge_polylines = (
            np.stack(road_edge_polylines, axis=0) if road_edge_polylines else np.zeros((0, polyline_size, 2))
        )
        road_edge_property = np.stack(road_edge_property, axis=0) if road_edge_property else np.zeros((0, property_dim))
        road_edge_polymask = np.stack(road_edge_polymask, axis=0) if road_edge_polymask else np.zeros((0, 2))

        # GOD polygon by polyline format
        god_polygon_list = []
        god_polylines = []
        god_property = []
        god_polymask = []
        for i, p in enumerate(god_polygon):
            p = p[:, :2]
            segments = Plannn2Dataset.split_line(p, polyline_size)
            for segment in segments:
                god_polygon_list.append(np.zeros((4, 2)))
                _property = np.zeros(property_dim)
                _property[0] = cls_mapping["god_polygon"]
                god_property.append(_property)
                god_polymask.append(np.array([0, min(polyline_size, len(segment))]))
                if segment.shape[0] < polyline_size:
                    segment = np.concatenate([segment, np.zeros((polyline_size - segment.shape[0], 2))], axis=0)
                god_polylines.append(segment)
        god_polygon_list = np.stack(god_polygon_list, axis=0) if god_polygon_list else np.zeros((0, 4, 2))
        god_polylines = np.stack(god_polylines, axis=0) if god_polylines else np.zeros((0, polyline_size, 2))
        god_property = np.stack(god_property, axis=0) if god_property else np.zeros((0, property_dim))
        god_polymask = np.stack(god_polymask, axis=0) if god_polymask else np.zeros((0, 2))

        # stop_line
        stop_line_polygon = []
        stop_line_polylines = []
        stop_line_property = []
        stop_line_polymask = []
        for i, p in enumerate(stop_line):
            p = p[:, :2]
            p = Plannn2Dataset._stop_line_interp(p, 4)
            segments = Plannn2Dataset.split_line(p, polyline_size)
            for segment in segments:
                stop_line_polygon.append(np.zeros((4, 2)))
                _property = np.zeros(property_dim)
                _property[0] = cls_mapping["stop_line"]
                stop_line_property.append(_property)
                stop_line_polymask.append(np.array([0, min(polyline_size, len(segment))]))
                if segment.shape[0] < polyline_size:
                    segment = np.concatenate([segment, np.zeros((polyline_size - segment.shape[0], 2))], axis=0)
                stop_line_polylines.append(segment)
        stop_line_polygon = np.stack(stop_line_polygon, axis=0) if stop_line_polygon else np.zeros((0, 4, 2))
        stop_line_polylines = (
            np.stack(stop_line_polylines, axis=0) if stop_line_polylines else np.zeros((0, polyline_size, 2))
        )
        stop_line_property = np.stack(stop_line_property, axis=0) if stop_line_property else np.zeros((0, property_dim))
        stop_line_polymask = np.stack(stop_line_polymask, axis=0) if stop_line_polymask else np.zeros((0, 2))

        # tld
        tld_polygon = np.zeros((4, 4, 2))  # N x 2 x 2
        tld_polylines = np.zeros((4, polyline_size, 2))  # N x M x 2
        tld_property = np.zeros((4, property_dim))
        tld_property[:, 0] = cls_mapping["tld"]
        tld_property[:, 1] = [get_tld_cls2_mapping(tld_id) for tld_id in tld]
        tld_property[:, 6] = np.array(tld_to_lane_direction_mapping) << 1
        tld_mask = np.zeros((4, 2))  # N x 2

        # navi info
        # 1. action
        main_action_1 = max(0, navi_infos["main_action_1"])
        assistant_action_1 = max(0, navi_infos["assistant_action_1"])
        remain_distance1 = navi_infos["link_main_distance_1"]
        action1_polygon = np.zeros((1, 4, 2))  # N x 2 x 2
        action1_polylines = np.zeros((1, polyline_size, 2))  # N x M x 2
        action1_property = np.zeros((1, property_dim))
        action1_property[0, 0] = cls_mapping["action_1"]
        action1_property[0, 1] = get_action_cls2_mapping(main_action_1)
        action1_property[0, 2] = get_action_cls3_mapping(assistant_action_1)
        action1_property[0, 5] = get_remain_distance_cls4_mapping(remain_distance1)
        action1_polymask = np.zeros((1, 2))  # N x 2

        main_action_2 = max(0, navi_infos["main_action_2"])
        assistant_action_2 = max(0, navi_infos["assistant_action_2"])
        remain_distance2 = navi_infos["link_main_distance_2"]
        action2_polygon = np.zeros((1, 4, 2))  # N x 2 x 2
        action2_polylines = np.zeros((1, polyline_size, 2))  # N x M x 2
        action2_property = np.zeros((1, property_dim))
        action2_property[0, 0] = cls_mapping["action_2"]
        action2_property[0, 1] = get_action_cls2_mapping(main_action_2)
        action2_property[0, 2] = get_action_cls3_mapping(assistant_action_2)
        action2_property[0, 5] = get_remain_distance_cls4_mapping(remain_distance2)
        action2_polymask = np.zeros((1, 2))  # N x 2

        # 2. sub_path_main_path
        sub_path_polygon = []
        sub_path_polylines = []
        sub_path_property = []
        sub_path_polymask = []
        if navi_infos["sub_path_main_path_points"] is not None:
            p = navi_infos["sub_path_main_path_points"][:, :2]
            # 截断mainpath, 保留[-100, 300]范围
            p = interpolate_points(p, 25)
            p = cut_sub_path_spec(p, center, -50.0, 300.0)
            if np.isfinite(p).all():
                segments = Plannn2Dataset.split_line(p, polyline_size)
                for index, segment in enumerate(segments):
                    sub_path_polygon.append(np.zeros((4, 2)))
                    _property = np.zeros(property_dim)
                    _property[0] = cls_mapping["sub_path"]
                    _property[1] = get_map_cls2_to_sub_path(1)  # 1: main_path
                    sub_path_property.append(_property)
                    sub_path_polymask.append(np.array([0, min(polyline_size, len(segment))]))
                    if segment.shape[0] < polyline_size:
                        segment = np.concatenate([segment, np.zeros((polyline_size - segment.shape[0], 2))], axis=0)
                    sub_path_polylines.append(segment)
        # sub_path_polygon = np.stack(sub_path_polygon, axis=0) if sub_path_polygon else np.zeros((0, 4, 2))
        # sub_path_polylines = (
        #     np.stack(sub_path_polylines, axis=0) if sub_path_polylines else np.zeros((0, polyline_size, 2))
        # )
        # sub_path_property = np.stack(sub_path_property, axis=0) if sub_path_property else np.zeros((0, property_dim))
        # sub_path_polymask = np.stack(sub_path_polymask, axis=0) if sub_path_polymask else np.zeros((0, 2))

        # sub_path_sub_path
        if navi_infos["sub_path_sub_path_points"] is not None:
            for sub_path in navi_infos["sub_path_sub_path_points"]:
                p = sub_path[:, :2]
                p = interpolate_points(p, 25)
                p = cut_sub_path_spec(p, center, -25.0, 150.0)
                if np.isfinite(p).all():
                    segments = Plannn2Dataset.split_line(p, polyline_size)
                    for index, segment in enumerate(segments):
                        sub_path_polygon.append(np.zeros((4, 2)))
                        _property = np.zeros(property_dim)
                        _property[0] = cls_mapping["sub_path"]
                        _property[1] = get_map_cls2_to_sub_path(0)  # 0: sub_path
                        sub_path_property.append(_property)
                        sub_path_polymask.append(np.array([0, min(polyline_size, len(segment))]))
                        if segment.shape[0] < polyline_size:
                            segment = np.concatenate([segment, np.zeros((polyline_size - segment.shape[0], 2))], axis=0)
                        sub_path_polylines.append(segment)
        sub_path_polygon = np.stack(sub_path_polygon, axis=0) if sub_path_polygon else np.zeros((0, 4, 2))
        sub_path_polylines = (
            np.stack(sub_path_polylines, axis=0) if sub_path_polylines else np.zeros((0, polyline_size, 2))
        )
        sub_path_property = np.stack(sub_path_property, axis=0) if sub_path_property else np.zeros((0, property_dim))
        sub_path_polymask = np.stack(sub_path_polymask, axis=0) if sub_path_polymask else np.zeros((0, 2))

        # 4. lane_info lane_highline_info
        lane_nr_remain_distance = navi_infos["lane_nr_remain_distance"]
        num_lane_infos = len(navi_infos["lane_infos"])
        lane_info_polygon = np.zeros((num_lane_infos, 4, 2))  # N x 2 x 2
        lane_info_polylines = np.zeros((num_lane_infos, polyline_size, 2))  # N x M x 2
        lane_info_property = np.zeros((num_lane_infos, property_dim))
        lane_info_property[:, 0] = cls_mapping["lane_info"]
        lane_highline_info_polygon = np.zeros((num_lane_infos, 4, 2))  # N x 2 x 2
        lane_highline_info_polylines = np.zeros((num_lane_infos, polyline_size, 2))  # N x M x 2
        lane_highline_info_property = np.zeros((num_lane_infos, property_dim))
        lane_highline_info_property[:, 0] = cls_mapping["lane_highline_info"]
        if num_lane_infos <= max_lane_num:
            for lane_id, lane_info in enumerate(navi_infos["lane_infos"]):
                lane_direction, lane_highline_direction, lane_is_drivable, lane_is_highline, lane_type = lane_info
                from_left, position = Plannn2Dataset._get_lane_id_position(lane_id, num_lane_infos, max_lane_num, mode)
                encode_lane_id = position * 2 if from_left else position * 2 + 1
                lane_info_property[lane_id, 1] = get_lane_id_cls2_mapping(encode_lane_id)
                lane_info_property[lane_id, 2] = get_lane_type_cls3_mapping(lane_type)
                lane_highline_info_property[lane_id, 1] = get_lane_id_cls2_mapping(encode_lane_id)
                lane_highline_info_property[lane_id, 2] = get_lane_type_cls3_mapping(lane_type)
                lane_info_property[lane_id, 5] = get_remain_distance_cls4_mapping(lane_nr_remain_distance)
                lane_highline_info_property[lane_id, 5] = get_remain_distance_cls4_mapping(lane_nr_remain_distance)

                lane_info_property[lane_id, 6] = Plannn2Dataset._encode_lane_navi_info(lane_is_drivable, lane_direction)
                lane_highline_info_property[lane_id, 6] = Plannn2Dataset._encode_lane_navi_info(
                    lane_is_highline, lane_highline_direction
                )
        lane_info_polymask = np.zeros((num_lane_infos, 2))  # N x 2
        lane_highline_info_polymask = np.zeros((num_lane_infos, 2))  # N x 2

        # spd_limit
        spd_limit_polygon = np.zeros((1, 4, 2))  # N x 2 x 2
        spd_limit_polylines = np.zeros((1, polyline_size, 2))  # N x M x 2
        spd_limit_property = np.zeros((1, property_dim))
        spd_limit_property[0, 0] = cls_mapping["spd_limit"]
        spd_limit_property[0, 1] = get_spd_limit_cls2_mapping(np.clip(spd_limit, 0, 120) // 10)
        spd_limit_mask = np.zeros((1, 2))  # N x 2

        # merge all
        env_polygon = np.concatenate(
            [
                action1_polygon,
                action2_polygon,
                sub_path_polygon,
                lane_info_polygon,
                lane_highline_info_polygon,
                sobjs_polygon,
                god_polygon_list,
                road_sign_polygon,
                road_arrow_polygon,
                lane_lines_polygon,
                road_edge_polygon,
                stop_line_polygon,
            ],
            axis=0,
        )
        env_polylines = np.concatenate(
            [
                action1_polylines,
                action2_polylines,
                sub_path_polylines,
                lane_info_polylines,
                lane_highline_info_polylines,
                sobjs_polylines,
                god_polylines,
                road_sign_polylines,
                road_arrow_polylines,
                lane_lines_polylines,
                road_edge_polylines,
                stop_line_polylines,
            ],
            axis=0,
        )
        env_poly_mask = np.concatenate(
            [
                action1_polymask,
                action2_polymask,
                sub_path_polymask,
                lane_info_polymask,
                lane_highline_info_polymask,
                sobjs_polymask,
                god_polymask,
                road_sign_polymask,
                road_arrow_polymask,
                lane_lines_polymask,
                road_edge_polymask,
                stop_line_polymask,
            ],
            axis=0,
        )
        env_property = np.concatenate(
            [
                action1_property,
                action2_property,
                sub_path_property,
                lane_info_property,
                lane_highline_info_property,
                sobjs_property,
                god_property,
                road_sign_property,
                road_arrow_property,
                lane_lines_property,
                road_edge_property,
                stop_line_property,
            ],
            axis=0,
        )

        # pad
        env_polygon, env_polylines, env_poly_mask, env_property, env_len = Plannn2Dataset.pad_env(
            env_polygon,
            env_polylines,
            env_poly_mask,
            env_property,
            center,
            env_block_size - 5,
            polyline_size,
            property_dim,
        )
        # add tld and spd_limit
        env_polygon = np.concatenate([env_polygon, tld_polygon, spd_limit_polygon], axis=0)
        env_polylines = np.concatenate([env_polylines, tld_polylines, spd_limit_polylines], axis=0)
        env_poly_mask = np.concatenate([env_poly_mask, tld_mask, spd_limit_mask], axis=0)
        env_property = np.concatenate([env_property, tld_property, spd_limit_property], axis=0)
        env_len += 5
        return env_polygon, env_polylines, env_poly_mask, env_property, env_len

    @staticmethod
    def pad_env(
        env_polygon, env_polyline, env_poly_mask, env_property, center, env_block_size, polyline_size, property_dim
    ):
        assert len(env_polygon) == len(env_polyline) == len(env_poly_mask) == len(env_property)
        env_len = len(env_polygon)
        if env_len < env_block_size:
            pad_size = env_block_size - env_len
            env_polygon = np.concatenate([env_polygon, np.zeros((pad_size, 4, 2))], axis=0)
            env_polyline = np.concatenate([env_polyline, np.zeros((pad_size, polyline_size, 2))], axis=0)
            env_poly_mask = np.concatenate([env_poly_mask, np.zeros((pad_size, 2))], axis=0)
            env_property = np.concatenate([env_property, np.zeros((pad_size, property_dim))], axis=0)
        elif env_len > env_block_size:
            distance_polygon = np.linalg.norm(np.mean(env_polygon, axis=1) - center, axis=1)  # n
            distance_polyline = []
            for i in range(env_len):
                if env_poly_mask[i, 1] > 0:
                    d = np.min(np.linalg.norm(env_polyline[i, : int(env_poly_mask[i, 1]), :] - center, axis=1))
                else:
                    d = distance_polygon[i]
                distance_polyline.append(d)
            distance = distance_polyline
            index = np.argsort(distance)[:env_block_size]
            env_polygon = env_polygon[index]
            env_polyline = env_polyline[index]
            env_poly_mask = env_poly_mask[index]
            env_property = env_property[index]
            env_len = env_block_size
        return env_polygon, env_polyline, env_poly_mask, env_property, env_len

    @staticmethod
    def create_empty_navi_info():
        navi_info = {
            "main_action_1": 0,
            "assistant_action_1": 0,
            "link_main_distance_1": -1,
            "main_action_2": 0,
            "assistant_action_2": 0,
            "link_main_distance_2": -1,
            "lane_infos": [],
            "sub_path_main_path_points": None,
            "sub_path_sub_path_points": [],
            "lane_nr_remain_distance": -1,
            "checkpoints": [],
            "navi_centerlines": [],
            "action_list": [],
            "lanenr_list": [],
        }
        return navi_info

    def filter_god_point_by_road_edge(road_edge, god_polygon, center):
        road_edge_polylines = []
        for p in road_edge:
            if p.shape[0] >= 2:
                road_edge_polylines.append(LineString(p[:, :2]))
        # 为所有路沿段构建STRtree空间索引, 加快运算
        road_edges_tree = STRtree(road_edge_polylines)

        new_god_polygon = []
        not_filter_by_road_edge_range = 10
        for polygon in god_polygon:
            new_p = polygon[:, :2]
            num_points = new_p.shape[0]
            if num_points < 2:
                continue

            # 距离ego小于not_filter_by_road_edge_range的点不根据路沿过滤，一定保留，避免转弯路沿缺失和不准
            center2point = new_p - center
            dis = np.linalg.norm(center2point, axis=1)
            keep_by_dis = dis < not_filter_by_road_edge_range

            indices_to_keep = set()
            def keep_index(i): return indices_to_keep.update([(i - 1) % num_points, i, (i + 1) % num_points])
            for i in range(num_points):
                if keep_by_dis[i] == True:
                    keep_index(i)
                    continue

                # 距离大于等于阈值时，进行路沿相交检测
                current_point = new_p[i]
                line_to_center = LineString([current_point, center])
                # 使用STRtree查询可能相交的路沿段
                intersect_candidates = road_edges_tree.query(line_to_center)
                # 精确检测是否实际相交
                has_intersection = False
                for candidate in intersect_candidates:
                    if line_to_center.intersects(candidate):
                        has_intersection = True
                        continue

                # 如果不相交，说明这个点在路沿外，保留该点及相邻点
                if not has_intersection:
                    keep_index(i)

            # 如果没有需要保留的点，则不保留该polygon
            if len(indices_to_keep) < 3:
                continue
            # 转换为排序后的索引列表并返回结果
            sorted_indices = sorted(indices_to_keep)
            new_p = new_p[sorted_indices]
            new_god_polygon.append(new_p)

        return new_god_polygon

    def filter_god_point_by_road_sign(etc_road_sign, god_polygon):
        if len(etc_road_sign) <= 0:
            return god_polygon
        new_god_polygon = []
        filter_dis_threshold = 2.0
        etc_road_sign_centor = np.average(np.array(etc_road_sign), axis=1)

        for p in god_polygon:
            new_p = p
            keep_idx = np.ones(new_p.shape[0], dtype=bool)
            for center_i in range(len(etc_road_sign_centor)):
                p2c_vec = p - etc_road_sign_centor[center_i, :]
                distance_vec = np.linalg.norm(p2c_vec, axis=1)
                keep_idx = keep_idx & (distance_vec > filter_dis_threshold)
            new_p = p[keep_idx]
            if len(new_p) >= 2:
                new_god_polygon.append(new_p)

        return new_god_polygon

    @staticmethod
    def convert_etc_type(frame, T, etc_road_sign, raw_type):
        center = etc_road_sign[:, :2].mean(axis=0)
        gate_centerlines = frame.get("toll_gate_center_line", None)
        if gate_centerlines is not None:
            for gate in gate_centerlines:
                new_points = ego2global(gate["points"], T)
                if len(new_points) > 0 and np.linalg.norm(new_points[0][:2] - center) < 0.5:
                    return gate["type"]

        return etc_sematic_to_road_sign.get(raw_type, 1002)

    def get_object_filter_attrs(perception_objects):
        obj_attr_dict = dict()
        for obj_attr in perception_objects:
            key = obj_attr["staticobj"]["OBS_ID"]
            obj_attr_dict[key] = obj_attr["staticobj"]
        return obj_attr_dict
    def parse_his_fut_tld(data, navi_infos, use_timestamp, ego_property):
        tld_his_fut_list = []
        tld_color_select_list = []
        his_len = ego_property.shape[0]
        for num_index, ts_index in enumerate(use_timestamp):
            frame = data[ts_index]
            traffic_lights = frame["traffic_lights"]
            tld = [4, 4, 4, 4]
            if len(traffic_lights) > 4:
                traffic_lights = traffic_lights[:4]
            if traffic_lights:
                assert len(traffic_lights) == 4, f"traffic_lights is len {len(traffic_lights)}"
                for i, light in enumerate(traffic_lights):
                    # [color, status, timer]
                    c, s, t = light
                    if s != 0:
                        c = 4
                    tld[i] = c
            tld_color_select,_ = Plannn2Dataset.get_tld_direct_select(navi_infos, tld)
            tld_color_select_list.append(tld_color_select)
            tld_his_fut_list.append(tld)
            if num_index < his_len:
                ego_property[num_index,-1] = tldcolor.index(tld_color_select)
        return tld_his_fut_list, tld_color_select_list, ego_property
    @staticmethod
    def get_tld_direct_select(navi_infos, tld):
        # TODO: 红绿灯不再绑定到到单个导航，需要自己确定自车所在的车道来获取红绿灯状态
        # 这里先暂时使用导航信息来获取红绿灯状态
        ##用来确定是否到达路口
        lane_infos = navi_infos["lane_infos"]
        if len(lane_infos) > 0:
            highline_directions = [info[1] for info in lane_infos if info[1]]
            if highline_directions:
                highline_direction = highline_directions[0]
                direct_light = lane_direction_to_tld_id_mapping[highline_direction]
                tld_select = tld[direct_light]
                tld_color_select = tldcolor[tld_select]
            else:
                tld_color_select = "gray"
                direct_light = 4
        else:
            tld_color_select = "gray"  # 还没到路口
            direct_light = 4
        return tld_color_select, direct_light
    def project_polygon(self, axis, poly):
        projections = poly @ axis
        return projections.min(), projections.max()

    def overlap_1d(self, a_min, a_max, b_min, b_max):
        return not (a_max < b_min or b_max < a_min)

    def box_corners(self, x, y, yaw, length, width):
        """
        返回形状 [4,2]，按逆时针
        """
        hl = length / 2.0
        hw = width / 2.0

        # 车辆坐标系下的角点
        corners = np.array([
            [-hl, -hw],
            [hl, -hw],
            [hl, hw],
            [-hl, hw],
        ])

        c, s = np.cos(yaw), np.sin(yaw)
        R = np.array([[c, -s],
                      [s, c]])

        corners = corners @ R.T
        corners[:, 0] += x
        corners[:, 1] += y
        return corners

    def project_polygon(self, axis, poly):
        projections = poly @ axis
        return projections.min(), projections.max()

    def sat_collision(self, poly1, poly2):
        """
        poly1, poly2: [N,2], [M,2]
        """
        for poly in (poly1, poly2):
            n = poly.shape[0]
            for i in range(n):
                edge = poly[(i + 1) % n] - poly[i]
                axis = np.array([-edge[1], edge[0]])
                axis = axis / (np.linalg.norm(axis) + 1e-8)

                min1, max1 = self.project_polygon(axis, poly1)
                min2, max2 = self.project_polygon(axis, poly2)

                if not self.overlap_1d(min1, max1, min2, max2):
                    return False
        return True

    def follow_vehicle_check(self, ego_pos, dynamic_objs, check_distance=20, check_frames=20, front_obs_dist=3.0):
        ego_pos = torch.from_numpy(ego_pos[:check_frames])
        last_ego_pos = ego_pos[0].clone()
        last_ego_pos[:, 0] = last_ego_pos[:, 0] + front_obs_dist
        ego_pos = torch.cat([ego_pos, last_ego_pos.unsqueeze(0)], dim=0)
        ego_pos_x, ego_pos_y = torch.mean(ego_pos[0], axis=0)
        for obj in dynamic_objs:
            if obj[7] < 300:  # vehicle x, y, z, l, w, h, yaw, cid, sid, tid, vx, vy
                veh_x = obj[0]
                veh_y = obj[1]
                veh_length = obj[3]
                veh_width = obj[4]
                veh_yaw = obj[6]
                if torch.sqrt((veh_x - ego_pos_x)**2 + (veh_y - ego_pos_y)**2) < check_distance:
                    obs_poly = self.box_corners(
                        veh_x, veh_y,
                        veh_yaw,
                        veh_length,
                        veh_width
                    )
                    for t in range(ego_pos.shape[0]):
                        ego_poly = ego_pos[t]
                        if self.sat_collision(ego_poly, obs_poly):
                            return True
        return False

    def tld_start_mask_flag(self, ego_polygons, ego_property, vehspeeds, navi_infos, frame_agents, tld_color_select_list, tld_his_fut_list, ego_labels, scene_id):
        ego_labels_mask = ego_labels.copy()
        if navi_infos["main_action_1"] == 7:  # 掉头场景
            return ego_labels_mask
        padding_index = ego_property[..., 0] == 0
        selected_indices = np.where(~padding_index)[0]
        ego_polygons = ego_polygons[selected_indices]
        for ts_index in range(ego_polygons.shape[0]):
            label_index = int(ts_index / self.segment_labels)
            if label_index >= len(ego_labels):
                continue
            if vehspeeds[self.history_size - 1 + ts_index] == 0 and tld_color_select_list[self.history_size - 1 + ts_index] == "green" and not self.follow_vehicle_check(ego_polygons[ts_index:], frame_agents[self.history_size + ts_index][1]):
                ego_labels_mask[label_index] = -1
            elif vehspeeds[self.history_size - 1 + ts_index] == 0 and tld_his_fut_list[self.history_size - 1 + ts_index][1] == 3 and scene_id == 1 and not self.follow_vehicle_check(ego_polygons[ts_index:], frame_agents[self.history_size + ts_index][1]):
                ego_labels_mask[label_index] = -1
            elif tld_color_select_list[self.history_size - 1] in ["red", "yellow"] and not (tld_his_fut_list[self.history_size - 1][1] == 3 and scene_id == 1) and tld_color_select_list[self.history_size + ts_index] == "green" and vehspeeds[self.history_size - 1] == 0 and not self.follow_vehicle_check(ego_polygons[ts_index:], frame_agents[self.history_size + ts_index][1]):
                ego_labels_mask[label_index] = -1
        return ego_labels_mask

    def get_scene_class(self, raw_env):
        # scene_id 0表示无待转区， 1表示有待转区,且未进入待转区 2.表示有待转区，且已经进入待转区
        scene_id = 0
        # 如果有两条停止线，一条是待转区的，一条是normal的，且绿灯为直行，自车为左转，左转红灯亮了，直行绿灯亮了，自车速度>0,给正向reward 10
        wm_stoplines = raw_env["egopath_stoplines"]
        egopath_stoplines_ids = []
        egopath_stoplines_points = []
        for wm_stopline_junc in wm_stoplines:
            if len(wm_stopline_junc) == 0:
                continue
            t = wm_stopline_junc[2]
            p = wm_stopline_junc[0]
            egopath_stoplines_ids.append(t)
            egopath_stoplines_points.append(p)
        if len(egopath_stoplines_ids) > 0:
            if len(egopath_stoplines_ids) == 2 and 2 in egopath_stoplines_ids:
                # 这是一个待转区，且自车未进入待转区
                scene_id = 1
            if len(egopath_stoplines_ids) == 1 and 2 in egopath_stoplines_ids:
                scene_id = 2
        return scene_id, egopath_stoplines_points

    @staticmethod
    def parse_frame_env_v3(frame, T, center, original_yaw, **kwargs):
        """获取原始的env信息"""
        vis_polygon = kwargs["vis_polygon"]
        try:
            priority_road_class = frame["global_localization"]["map_topo_loc"]["priority_road_class"]
        except (KeyError, TypeError):
            priority_road_class = None
        sobjs, god_polygon, god_polygon_vis = parse_staticobj_v2(
            objs=frame["static_dets"],
            polygons=frame["static_polygon"],
            should_filter=True,
            T=T,
            priority_road_class=priority_road_class,
            object_filter_attrs=Plannn2Dataset.get_object_filter_attrs(frame["perception_objects"]),
            center=center,
            original_yaw=original_yaw,
            god_forward_filter_dis_threshold=50,
            god_backward_filter_dis_threshold=5,
            vis_polygon=vis_polygon,
        )
        parked_vehicle = []
        if "mlm_scene_info" in frame:
            parked_vehicle = frame["mlm_scene_info"]["dead_car_info"]

        areazones = frame.get("road_zones", [])
        wm_stoplines = frame.get("wm_stoplines", [])

        lanes, types, attrs = unique_lanes(
            frame["manner_lane_points"], frame["manner_lane_types"], frame["manner_lane_attr"]
        )
        road_sign, lane_lines, road_edge, nomap_road_edge, stop_line, tld, navi_path = [], [], [], [], [], 4, None
        road_edge_vis, etc_road_sign = [], []
        spd_limit = frame["speed_limit"]

        near_etc_gate = False
        for p, t, a in zip(lanes, types, attrs):
            """
            p为N个点坐标(x, y): N * 2
            t为整条lane的类型:  1
            a为每个point的类型: N * 2
            """
            x_length = np.max(p[:, 0]) - np.min(p[:, 0])
            y_length = np.max(p[:, 1]) - np.min(p[:, 1])
            # 对齐全部数据到新坐标系
            p = ego2global(p, T)

            if t == 0:  # lane_line
                lane_lines.append([p, a])
            elif t == 1:  # road_edge
                if vis_polygon:
                    road_edge_vis.append(p)
                # filter point by distance to ego
                new_p = filter_points_by_dis(
                    points_array=p,
                    center=center,
                    original_yaw=original_yaw,
                    forward_filter_dis_threshold=125,
                    backward_filter_dis_threshold=5,
                    sorted_points_array=True,
                )
                if new_p is not None:
                    road_edge.append(new_p)

            elif t == 2:  # stop_line
                stop_line.append(p)
            elif t == 3:  # road_sign
                if a[0][1] == 99999:
                    if a[0][0] in [209, 212, 204]:
                        etc_road_sign.append(p[:, :2])
                    if not near_etc_gate:
                        near_etc_gate = True
                        sobjs = filter_etc_staticobj(frame["static_dets"], T)
                    etc_road_sign_type = Plannn2Dataset.convert_etc_type(frame, T, p, a[0][0])
                    road_sign.append([p, etc_road_sign_type])
                else:
                    road_sign.append([p, a[0][0]])
            else:
                raise ValueError(f"Unknown manner type: {t}")

        # increase nomap curb
        nomap_lanes, nomap_types, _ = unique_lanes(
            frame["manner_lane_points_nomap"], frame["manner_lane_types_nomap"], frame["manner_lane_attr_nomap"]
        )
        for p, t in zip(nomap_lanes, nomap_types):
            if t == 1:  # road_edge
                # 对齐全部数据到新坐标系
                p = ego2global(p, T)
                if vis_polygon:
                    road_edge_vis.append(p)
                # filter point by distance to ego
                new_p = filter_points_by_dis(
                    points_array=p,
                    center=center,
                    original_yaw=original_yaw,
                    forward_filter_dis_threshold=30,
                    backward_filter_dis_threshold=5,
                    sorted_points_array=True,
                )

                if new_p is not None:
                    nomap_road_edge.append(new_p)

        # filter god polygon by road edge & etc road sign
        god_polygon = Plannn2Dataset.filter_god_point_by_road_edge(road_edge + nomap_road_edge, god_polygon, center)
        # god_polygon = Plannn2Dataset.filter_god_point_by_road_sign(etc_road_sign, god_polygon)

        # centerline
        centerlines = []
        # do pose transform
        for centerline in frame.get("manner_lane_center_lines", ()):  # dict
            if centerline["type"] == 99 or centerline["id"] < 90000 or centerline["id"] > 100000:
                continue
            points = centerline["points"]
            if points.size < 1:
                continue
            new_points = ego2global(points, T)
            centerlines.append([new_points, centerline["type"], centerline["confidence"]])

        # traffic light
        traffic_lights = frame["traffic_lights"]
        tld = [4, 4, 4, 4]
        if len(traffic_lights) > 4:
            traffic_lights = traffic_lights[:4]
        if traffic_lights:
            assert len(traffic_lights) == 4, f"traffic_lights is len {len(traffic_lights)}"
            for i, light in enumerate(traffic_lights):
                # [color, status, timer]
                c, s, t = light
                if s != 0:
                    c = 4
                tld[i] = c
        ##
        ##增加waitzone and wmstopline 转换
        # areazones = waitzones['road_zones']
        waitzones = []
        if "polygon_points" in areazones:
            polygon_points = areazones["polygon_points"]
            for polygon_point in polygon_points:
                polygon_point = ego2global(polygon_point[:, 0:2], T)
                waitzones.append(polygon_point)

        egopath_stoplines = []
        if len(wm_stoplines) > 0:
            for wm_stopline_junc in wm_stoplines[:1]:
                if "points" not in wm_stopline_junc:
                    continue
                stopline_points = wm_stopline_junc["points"]
                ids = wm_stopline_junc["stopline_id"]
                stoplines_type = wm_stopline_junc["stopline_type"]
                for idx, stopline in enumerate(stopline_points):
                    p = stopline
                    p = ego2global(p[:, 0:2], T)
                    id = ids[idx]
                    t = stoplines_type[idx]
                    egopath_stoplines.append([p, id, t])

        # navi
        link_info = frame["link_info"]
        map_loc = frame["map_loc"]
        sub_path = frame["sub_path"]
        lanenr_actions_info = frame.get("local_lanenr_actions", None)

        # navipath
        assert len(frame["navi_path_points"]) <= 1
        for i, p in enumerate(frame["navi_path_points"]):
            if p.ndim == 2 and len(p) > 0:
                p = ego2global(p, T)
                navi_path = p

        navi_info = Plannn2Dataset.create_empty_navi_info()
        if lanenr_actions_info:
            action_count = 0
            lanenr_count = 0
            for info in lanenr_actions_info:
                # action
                if (
                    "merged_tbt_segment_action" in info
                    and info["merged_tbt_segment_action"]["main_action"] > 0
                    and (
                        info["merged_tbt_segment_action"]["distance"] >= 0.0
                        or info["merged_tbt_segment_action"]["source"] == 3
                    )
                ):
                    if action_count == 0:
                        action_count += 1
                        navi_info["main_action_1"] = info["merged_tbt_segment_action"]["main_action"]
                        navi_info["assistant_action_1"] = info["merged_tbt_segment_action"]["assistant_action"]
                        navi_info["link_main_distance_1"] = info["merged_tbt_segment_action"]["distance"]
                    elif action_count == 1:
                        action_count += 1
                        navi_info["main_action_2"] = info["merged_tbt_segment_action"]["main_action"]
                        navi_info["assistant_action_2"] = info["merged_tbt_segment_action"]["assistant_action"]
                        navi_info["link_main_distance_2"] = info["merged_tbt_segment_action"]["distance"]
                # lanenr
                if (
                    "merged_multi_lane_info" in info
                    and info["merged_multi_lane_info"]["parsed_lane_nr_info"]
                    and (
                        info["merged_multi_lane_info"]["distance"] >= 0.0
                        or info["merged_multi_lane_info"]["source"] == 3
                    )
                ):
                    if lanenr_count == 0:
                        lanenr_count += 1
                        navi_info["lane_nr_remain_distance"] = info["merged_multi_lane_info"]["distance"]
                        for info in info["merged_multi_lane_info"]["parsed_lane_nr_info"]:
                            lane_direction = info["lane_direction"]
                            lane_highline_direction = info["lane_highline_direction"]
                            lane_is_drivable = info["lane_is_drivable"]
                            lane_is_highline = info["lane_is_highline"]
                            navi_info["lane_infos"].append(
                                [
                                    lane_direction,
                                    lane_highline_direction,
                                    lane_is_drivable,
                                    lane_is_highline,
                                    info["lane_type"],
                                ]
                            )
                # Use the first two actions and the first laner
                if action_count >= 2 and lanenr_count >= 1:
                    break

        if lanenr_actions_info:
            # action list
            for info in lanenr_actions_info:
                if "merged_tbt_segment_action" not in info:
                    continue

                if info["merged_tbt_segment_action"]["distance"] > 1000:
                    break

                if info["merged_tbt_segment_action"]["main_action"] < 0:
                    continue

                if (
                    info["merged_tbt_segment_action"]["distance"] >= 0.0
                    or info["merged_tbt_segment_action"]["source"] == 3
                ):
                    navi_info["action_list"].append(
                        [
                            info["merged_tbt_segment_action"]["main_action"],
                            info["merged_tbt_segment_action"]["assistant_action"],
                            info["merged_tbt_segment_action"]["distance"],
                        ]
                    )

            # lanenr list
            for info in lanenr_actions_info:
                if "merged_multi_lane_info" not in info:
                    continue

                if not info["merged_multi_lane_info"]["parsed_lane_nr_info"]:
                    continue

                if info["merged_multi_lane_info"]["distance"] >= 0.0 or info["merged_multi_lane_info"]["source"] == 3:
                    lanenr_item = {"infos": [], "distance": info["merged_multi_lane_info"]["distance"]}
                    for lanenr_info in info["merged_multi_lane_info"]["parsed_lane_nr_info"]:
                        lanenr_item["infos"].append(
                            [
                                lanenr_info["lane_direction"],
                                lanenr_info["lane_highline_direction"],
                                lanenr_info["lane_is_drivable"],
                                lanenr_info["lane_is_highline"],
                            ]
                        )
                    navi_info["lanenr_list"].append(lanenr_item)

        # subpath
        sub_path_main = sub_path["sub_path_main_path_points"]
        sub_path_sub = sub_path["sub_path_sub_path_points"]
        sub_path_main = np.array(sub_path_main, dtype=np.float32) if sub_path_main else None
        sub_path_sub = [
            np.array(s, dtype=np.float32) if s else np.zeros((0, 2), dtype=np.float32) for s in sub_path_sub
        ]
        assert sub_path_main is None or (sub_path_main.ndim == 2 and sub_path_main.shape[1] == 2)
        navi_info["sub_path_main_path_points"] = ego2global(sub_path_main, T) if sub_path_main is not None else None
        navi_info["sub_path_sub_path_points"] = [ego2global(s, T) for s in sub_path_sub]

        checkpoints = frame.get("checkpoints", None)
        navi_info["checkpoints"] = []
        if checkpoints is not None:
            for checkpoint in checkpoints:
                checkpoint_coords = np.array([checkpoint[0][:2], checkpoint[1][:2]], dtype=np.float32)
                checkpoint_coords = ego2global(checkpoint_coords, T)
                navi_info["checkpoints"].append([checkpoint_coords[0], checkpoint_coords[1], checkpoint[2]])

        # navi centerline
        navi_info["navi_centerlines"] = []
        navi_centerlines = frame.get("navi_centerlines", None)
        if navi_centerlines is not None:
            for navi_lane in navi_centerlines:
                # check
                if navi_lane["points"].shape[0] < 2:
                    continue
                new_points = np.array(navi_lane["points"], dtype=np.float32)
                new_points = ego2global(new_points, T)
                navi_info["navi_centerlines"].append(
                    [new_points, navi_lane["solid_line_start_index"], navi_lane["source"]]
                )

        toll_gate_centerline = []
        gate_centerlines = frame.get("toll_gate_center_line", None)
        if gate_centerlines is not None:
            for gate in gate_centerlines:
                # check
                if gate["points"].shape[0] < 2:
                    continue

                new_points = np.array(gate["points"], dtype=np.float32)
                new_points = ego2global(new_points, T)
                new_extend_points = np.array(gate["extend_points"], dtype=np.float32)
                new_extend_points = ego2global(new_extend_points, T)

                if len(gate["start_point"]) > 0:
                    new_start_point = np.array([gate["start_point"]], dtype=np.float32)
                    new_start_point = ego2global(new_start_point, T)
                else:
                    new_start_point = np.array([gate["start_point"]], dtype=np.float32)
                toll_gate_centerline.append([new_points, new_extend_points, new_start_point[0], gate["type"]])

        # virtual wall
        navi_info["virtual_wall"] = []
        virtual_wall = frame.get("virtual_wall", None)
        if virtual_wall is not None:
            for wall in virtual_wall:
                wall_coords = np.array([wall["start_point"][:2], wall["end_point"][:2]], dtype=np.float32)
                wall_coords = ego2global(wall_coords, T)
                navi_info["virtual_wall"].append(wall_coords)

        # nadsts
        drv_intract_nfo = frame.get("drv_intract_nfo", None)
        nadsts = "DANADSt_Unknown"
        if drv_intract_nfo is not None:
            np_drv_if = drv_intract_nfo.get("NpDrvIF", {})
            if np_drv_if is not None:
                nadsts = np_drv_if.get("DANADSts", "DANADSt_Unknown")
        # least_lc_dist
        least_lc_dist = frame.get("least_lc_dist", 10000)

        # navi road driving space
        navi_info["navi_road_driving_space"] = {}
        navi_road_driving_space = frame.get("navi_road_driving_space", None)
        if navi_road_driving_space is not None:
            left_boundary = navi_road_driving_space.get("left_boundary", None)
            # transform left boundary
            if left_boundary is not None and left_boundary.shape[0] >= 2:
                left_boundary = ego2global(left_boundary, T)
            right_boundary = navi_road_driving_space.get("right_boundary", None)
            # transform left boundary
            if right_boundary is not None and right_boundary.shape[0] >= 2:
                right_boundary = ego2global(right_boundary, T)

            drivable_polygon = navi_road_driving_space.get("drivable_polygon", None)
            if drivable_polygon is not None and drivable_polygon.shape[0] >= 3:
                drivable_polygon = ego2global(drivable_polygon, T)

            navi_info["navi_road_driving_space"]["left_boundary"] = left_boundary
            navi_info["navi_road_driving_space"]["right_boundary"] = right_boundary
            navi_info["navi_road_driving_space"]["drivable_polygon"] = drivable_polygon
            navi_info["navi_road_driving_space"]["left_start_index"] = navi_road_driving_space.get(
                "left_start_index", 0
            )
        # manner scene info
        manner_scene_info = frame.get("manner_scene_info", None)
        link_info = frame.get("link_info", None)

        return (
            sobjs,
            god_polygon,
            road_sign,
            lane_lines,
            road_edge,
            nomap_road_edge,
            stop_line,
            tld,
            spd_limit,
            navi_path,
            navi_info,
            centerlines,
            nadsts,
            least_lc_dist,
            toll_gate_centerline,
            waitzones,
            egopath_stoplines,
            god_polygon_vis,
            road_edge_vis,
            manner_scene_info,
            link_info,
            priority_road_class,
            parked_vehicle,
        )

    @staticmethod
    def parse_multi_spd_limit(data, timestamps):
        spd_limits = []
        for ts in timestamps:
            spd_limit = data[ts]["speed_limit"]
            spd_limits.append(spd_limit)
        return np.array(spd_limits)

    @staticmethod
    def parse_frame_tld(frame):
        traffic_lights = frame["traffic_lights"]
        tld = [4, 4, 4, 4]
        if len(traffic_lights) > 4:
            traffic_lights = traffic_lights[:4]
        if traffic_lights:
            assert len(traffic_lights) == 4, f"traffic_lights is len {len(traffic_lights)}"
            for i, light in enumerate(traffic_lights):
                # [color, status, timer]
                c, s, t = light
                if s != 0:
                    c = 4
                tld[i] = c
        return tld

    @staticmethod
    def augment_initpose(pose0):
        """输入初始pose0，返回扰动后的pose1，以pose1为中心时pose0的center"""
        rand_shift_xy = np.random.uniform(-10, 10, size=2)

        random_yaw = np.random.uniform(-np.pi, np.pi)  # np.pi / 2
        pose1 = pose0.copy()
        pose1[:2, 3] += rand_shift_xy
        pose1[:3, :3] = R.from_euler("z", random_yaw).as_matrix() @ pose1[:3, :3]

        pose0_in_pose1 = np.linalg.inv(pose1) @ pose0
        center = pose0_in_pose1[:2, 3]
        yaw = R.from_matrix(pose0_in_pose1[:3, :3]).as_euler("xyz")[2]  # 获取yaw
        return pose1, center, yaw

    def _get_lane_nr_distance(self, frame):
        # navi
        link_info = frame["link_info"]
        map_loc = frame["map_loc"]

        lane_nr_distance = -1
        if link_info and "link_index" in map_loc:
            link_index = map_loc["link_index"]
            link_remain_distance = map_loc["link_remain_dist"]

            # next available lane_nr_info
            link_index_next_lane = -1
            for link_id in range(link_index, len(link_info)):
                if link_info[link_id]["lane_nr_info"]:
                    link_index_next_lane = link_id
                    break
            if link_index_next_lane >= 0:
                lane_nr_distance = link_remain_distance
                if link_index != link_index_next_lane:
                    for i in range(link_index + 1, link_index_next_lane + 1):
                        lane_nr_distance += link_info[i]["cal_link_length"]
            else:
                lane_nr_distance = -1
        return lane_nr_distance

    @staticmethod
    def align_to_new_ego_inplace(Trans, data, timestamps, history_size):
        # 4. 历史帧对齐全部数据到新坐标系，未来帧保持不变
        for i, ts in enumerate(timestamps[:history_size]):
            frame = data[ts]
            # a_pose = new_ego_pose[i]
            # e_pose = ego_pose[i]
            T = Trans[i]  # np.linalg.inv(a_pose) @ e_pose
            frame["dynamic_dets"] = parse_dynamicobj_v2(frame["dynamic_dets"], T)
            frame["static_dets"], frame["static_polygon"] = parse_staticobj_v2(
                objs=frame["static_dets"], polygons=frame["static_polygon"], should_filter=False, T=T
            )
            frame["car_pose"] = frame["car_pose"] @ np.linalg.inv(T)  # a_pose
            for j, p in enumerate(frame["manner_lane_points"]):
                frame["manner_lane_points"][j] = ego2global(p, T)
            for j, p in enumerate(frame["manner_lane_points_nomap"]):
                frame["manner_lane_points_nomap"][j] = ego2global(p, T)
            sub_path = frame["sub_path"]
            if sub_path:
                if sub_path["sub_path_main_path_points"]:
                    sub_path_main_path_points = np.array(sub_path["sub_path_main_path_points"])
                    sub_path["sub_path_main_path_points"] = list(ego2global(sub_path_main_path_points, T)[:, :2])
                sub_sub_paths = sub_path["sub_path_sub_path_points"]
                for j, sub_sub_path in enumerate(sub_sub_paths):
                    if sub_sub_path:
                        sub_sub_path_points = np.array(sub_sub_path)
                        sub_sub_paths[j] = list(ego2global(sub_sub_path_points, T)[:, :2])
            # checkpoint
            checkpoints = frame["checkpoints"]
            if checkpoints is not None:
                for i, checkpoint in enumerate(checkpoints):
                    checkpoint_coords = np.array([checkpoint[0][:2], checkpoint[1][:2]])
                    checkpoint_coords = ego2global(checkpoint_coords, T)
                    checkpoints[i] = [checkpoint_coords[0], checkpoint_coords[1], checkpoint[2]]
            # centerline
            centerlines = frame["manner_lane_center_lines"]
            if centerlines is not None:
                for i, centerline in enumerate(centerlines):
                    points = centerline["points"]
                    if points.size < 1:
                        continue
                    new_points = ego2global(points, T)
                    centerlines[i]["points"] = new_points

            # navi centerline
            navi_centerlines = frame.get("navi_centerlines", None)
            if navi_centerlines is not None:
                for i, navi_lane in enumerate(navi_centerlines):
                    new_points = np.array(navi_lane["points"], dtype=np.float32)
                    new_points = ego2global(new_points, T)
                    navi_centerlines[i]["points"] = new_points

            # wait zone
            areazones = frame.get("area_zones", None)
            if areazones is not None:
                if "polygon_points" in areazones:
                    polygon_points = areazones["polygon_points"]
                    for idx, polygon_point in enumerate(polygon_points):
                        frame["area_zones"]["polygon_points"][idx] = ego2global(polygon_point[:, 0:2], T)

            wm_stoplines = frame.get("wm_stoplines", None)
            if wm_stoplines is not None:
                for index, wm_stopline_junc in enumerate(wm_stoplines):
                    if "points" not in wm_stopline_junc:
                        continue
                    stopline_points = wm_stopline_junc["points"]
                    for idx, stopline in enumerate(stopline_points):
                        p = stopline
                        p = ego2global(p[:, 0:2], T)
                        frame["wm_stoplines"][index]["points"][idx] = p

        return data

    def swap_ego_agent(self, data, timestamps, history_size=15, prob=0.5):
        """
        将自车在历史帧中的位置转移到他车身上。未来帧依然使用自车原来的位置（为了准确的闭环仿真）
        被附身的他车会被删除
        """
        # 如果距离路口过近70米以内，不做数据增强
        frame = data[timestamps[history_size - 1]]
        lane_nr_distance = self._get_lane_nr_distance(frame)
        if lane_nr_distance < 70:
            return data, False, 0, None

        # 1. 找到符合条件的agent, history timestamps都出现，和ego处于相邻车道，朝向相同，距离较近
        tids = None
        for ts in timestamps[:history_size]:
            frame = data[ts]
            if len(frame["dynamic_dets"]) == 0:
                tids = None
                break
            trakids = set(list(frame["dynamic_dets"][:, 9].astype(int)))
            if tids is None:
                tids = trakids
            tids &= trakids
        if not tids:
            return data, False, 0, None
        tids = np.array(list(tids))
        frame_at_0 = data[timestamps[history_size - 1]]
        dets = frame_at_0["dynamic_dets"]
        dets = dets[np.isin(dets[:, 9].astype(int), tids)]
        # 相邻车道，2 < abs(y) < 4, 距离不远， abs(x) < 15, # 朝向相同 # 类型为车 cid < 300
        y = np.abs(dets[:, 1])
        rad = (dets[:, 6] + np.pi) % (2 * np.pi) - np.pi
        index = (y > 2) & (y < 4) & (np.abs(dets[:, 0]) < 15) & (np.abs(rad) < np.pi / 4) & (dets[:, 7] < 300)
        dets = dets[index]
        if len(dets) == 0:
            return data, False, 0, None
        if np.random.rand() > prob:
            return data, False, 0, None

        select_agent_index = 0
        select_agent = dets[select_agent_index]
        select_agent_tid = int(dets[select_agent_index][9])

        # 2. 计算出agent在世界坐标系下的后轴中心pose
        agent_pose = []
        ego_pose = []
        shift = np.eye(4)  # I
        shift[:3, 3] = [-1.4, 0, 0]
        for ts in timestamps[:history_size]:
            car_pose = data[ts]["car_pose"]
            agent = data[ts]["dynamic_dets"]
            agent = agent[agent[:, 9].astype(int) == select_agent_tid][0]  # 12
            agent_center_pose_in_ego = np.eye(4)
            agent_center_pose_in_ego[:3, :3] = R.from_euler("z", agent[6]).as_matrix()
            agent_center_pose_in_ego[:3, 3] = agent[:3]
            agent_backwheel_in_ego = shift @ agent_center_pose_in_ego
            agent_backwheel_in_world = car_pose @ agent_backwheel_in_ego
            agent_pose.append(agent_backwheel_in_world)
            ego_pose.append(car_pose)

        # 3. 删掉agent
        ego_in_each_frame = [1.4, 0, 0, 4.85, 2, 2, 0] + [0.0] * (len(select_agent) - 7)
        ego_in_each_frame = np.array([ego_in_each_frame], dtype=np.float32)
        for ts in timestamps:
            agents = data[ts]["dynamic_dets"]
            if len(agents) == 0:
                continue
            data[ts]["dynamic_dets"] = agents[agents[:, 9].astype(int) != select_agent_tid]

        # 4. 历史帧对齐全部数据到新坐标系，未来帧保持不变
        Trans = [np.linalg.inv(a_pose) @ e_pose for a_pose, e_pose in zip(agent_pose, ego_pose)]
        Trans = np.stack(Trans, axis=0)
        data = self.align_to_new_ego_inplace(Trans, data, timestamps, history_size)
        return data, True, select_agent[0], ego_pose, agent_pose

    def move_across_centerline(self, data, timestamps, history_size=15, prob=0.5):
        # 1. 选择随机起始点
        frame = data[timestamps[history_size - 1]]
        centerlines = frame["manner_lane_center_lines"]
        if centerlines is None:
            return data, False, 0, None

        all_centerline_points = []
        for i, centerline in enumerate(centerlines):
            if centerline["type"] == 99 or centerline["id"] < 90000 or centerline["id"] > 100000:
                continue
            points = centerline["points"]
            if not points.size:
                continue
            if centerline["type"] in [2, 16]:
                all_centerline_points.append(points[:, :2])
        if len(all_centerline_points) == 0:
            return data, False, 0, None

        all_centerline_points = np.concatenate(all_centerline_points, axis=0)  # N x 2
        valid_points = all_centerline_points[np.abs(all_centerline_points[:, 0]) < 20]
        if len(valid_points) == 0:
            return data, False, 0, None
        index = np.random.randint(len(all_centerline_points))
        x, y = all_centerline_points[index]
        diff = x

        # 2. 计算新pose
        init_pose = data[timestamps[history_size - 1]]["car_pose"]
        init_pose_inv = np.linalg.inv(init_pose)
        agent_pose = []
        ego_pose = []
        for ts in timestamps[:history_size]:
            car_pose = data[ts]["car_pose"]
            apose = car_pose.copy()
            apose = init_pose_inv @ apose
            apose[0, 3] += x
            apose[1, 3] += y
            apose = init_pose @ apose
            agent_pose.append(apose)
            ego_pose.append(car_pose)

        # 4. 历史帧对齐全部数据到新坐标系，未来帧保持不变
        Trans = [np.linalg.inv(a_pose) @ e_pose for a_pose, e_pose in zip(agent_pose, ego_pose)]
        Trans = np.stack(Trans, axis=0)
        data = self.align_to_new_ego_inplace(Trans, data, timestamps, history_size)
        return data, True, diff, Trans

    def tmp_move_back(self, data, timestamps, history_size=15, prob=0.5, diff=0):
        """
        将自车在历史帧中的位置转移到他车身上。未来帧依然使用自车原来的位置（为了准确的闭环仿真）
        被附身的他车会被删除
        """
        init_pose = data[timestamps[history_size - 1]]["car_pose"]
        init_pose_inv = np.linalg.inv(init_pose)

        # 2. 计算出agent在世界坐标系下的后轴中心pose
        agent_pose = []
        ego_pose = []
        range = [-50 - diff, 20 - diff]
        move = np.random.rand() * (range[1] - range[0]) + range[0]
        for ts in timestamps[:history_size]:
            car_pose = data[ts]["car_pose"]
            apose = car_pose.copy()
            apose = init_pose_inv @ apose
            apose[0, 3] += move
            apose = init_pose @ apose
            agent_pose.append(apose)
            ego_pose.append(car_pose)

        # 4. 历史帧对齐全部数据到新坐标系，未来帧保持不变
        Trans = [np.linalg.inv(a_pose) @ e_pose for a_pose, e_pose in zip(agent_pose, ego_pose)]
        Trans = np.stack(Trans, axis=0)
        data = self.align_to_new_ego_inplace(Trans, data, timestamps, history_size)
        return data, True, move, Trans

    @staticmethod
    def get_lane_change_command(data, use_timestamps, initpose, lane_lines, mode, origin_idx, fps=5):
        """
        Args:
            data: dict, 包含了所有的帧数据
            use_timestamps: list, 使用的时间戳列表
            initpose: 齐次变换矩阵, 中心位姿
            lane_lines: list, 最后一帧的车道线信息
        Returns:
            commands: len(use_timestamps), 当前状态的指令
            np_plus_lcc_status: True, False np_lcc状态是否开启
        """
        # 获取轨迹
        traj = [(initpose @ data[ts]["car_pose"])[:2, 3] for ts in use_timestamps]
        traj = np.array(traj)
        # 获取所有command
        commands, command_time_steps = Plannn2Dataset.get_all_commands(traj, lane_lines)
        lane_change_signal = 0
        if len(commands) > 0:
            if commands[0] == 1:
                lane_change_signal = 1
            elif commands[0] == 2:
                lane_change_signal = 2
        # 设置command_done
        command_begin_time_steps, command_end_time_steps = Plannn2Dataset.get_all_command_change_time_steps(
            traj, command_time_steps, fps
        )
        # 设置每个状态的command和command_done
        commands_res = Plannn2Dataset.get_command_dones_and_commands(
            use_timestamps, command_begin_time_steps, command_end_time_steps, commands
        )
        np_plus_lcc_status = Plannn2Dataset.get_np_plus_lcc_status(data, use_timestamps, initpose, lane_lines)
        if mode in ["pretrain", "sft"]:
            if (len(commands) > 0 or np_plus_lcc_status == True) and np.random.random() > 1 / 3:
                commands_res[:] = 0
                lane_change_signal = 0
                np_plus_lcc_status = False
        elif mode == "rl":
            commands = commands_res
            commands_res[:] = commands_res[origin_idx]
            lane_change_signal = commands_res[origin_idx]
            if (lane_change_signal != 0 or np_plus_lcc_status == True) and np.random.random() > 1 / 3:
                np_plus_lcc_status = False
                commands_res[:] = 0
                lane_change_signal = 0
                commands[:] = 0
            if np_plus_lcc_status == True:
                commands[:] = 0
                commands_res[:] = 0
                lane_change_signal = 0
            if data.get("stalk_lcc_tag", False) == False:
                np_plus_lcc_status = False
                commands_res[:] = 0
                lane_change_signal = 0
                commands[:] = 0
        else:
            commands = commands_res
            commands_res[:] = commands_res[origin_idx]
            lane_change_signal = commands_res[origin_idx]
            np_plus_lcc_status = False
            commands_res[:] = 0
            lane_change_signal = 0
            commands[:] = 0

        return commands_res, lane_change_signal, np_plus_lcc_status, commands

    @staticmethod
    def get_lane_change_command_closed(data, use_timestamps, initpose, lane_lines, mode, origin_idx, fps=5):
        """
        Args:
            data: dict, 包含了所有的帧数据
            use_timestamps: list, 使用的时间戳列表
            initpose: 齐次变换矩阵, 中心位姿
            lane_lines: list, 最后一帧的车道线信息
        Returns:
            commands_res: 当前状态的指令
            lane_change_signal: 当前状态的指令
        """

        # 获取轨迹
        traj = [(initpose @ data[ts]["car_pose"])[:2, 3] for ts in use_timestamps]
        traj = np.array(traj)
        # 获取所有command
        commands, command_time_steps = Plannn2Dataset.get_all_commands(traj, lane_lines)
        lane_change_signal = 0
        if len(commands) > 0:
            if commands[0] == 1:
                lane_change_signal = 1
            elif commands[0] == 2:
                lane_change_signal = 2
        # 设置command_done
        command_begin_time_steps, command_end_time_steps = Plannn2Dataset.get_all_command_change_time_steps(
            traj, command_time_steps, fps
        )
        # 设置每个状态的command和command_done
        commands_res = Plannn2Dataset.get_command_dones_and_commands(
            use_timestamps, command_begin_time_steps, command_end_time_steps, commands
        )
        commands_res[:] = commands_res[origin_idx]
        lane_change_signal = commands_res[origin_idx]
        if (lane_change_signal != 0) and np.random.random() > 1 / 3 and mode in ["pretrain", "sft", "rl"]:
            commands_res[:] = 0
            lane_change_signal = 0
        if mode in ["rl"] and data.get("stalk_lcc_tag", False) == False:
            commands_res[:] = 0
            lane_change_signal = 0
        if mode in ["infer"]:
            commands_res[:] = 0
            lane_change_signal = 0
        return commands_res, lane_change_signal

    @staticmethod
    def get_all_commands(traj, lane_lines):
        """
        根据轨迹和车道线获得所有指令
        Args:
            traj: np.array, shape为(N, 2), N为轨迹点数
            lane_lines: list, 最后一帧的车道线信息
        Returns:
            commands: list, 所有指令, 取值为[1,2], 1表示左变道, 2表示右变道
            command_time_steps: list, 每个指令对应的时间步
        """
        # 排除左转、右转、左掉头等可能，变道前后车辆朝向通常不会有太大变化
        yaw_begin = np.arctan2(traj[1, 1] - traj[0, 1], traj[1, 0] - traj[0, 0])
        yaw_end = np.arctan2(traj[-1, 1] - traj[-2, 1], traj[-1, 0] - traj[-2, 0])
        yaw_diff = norm_yaw(yaw_end - yaw_begin)
        if yaw_diff > np.pi / 4 and yaw_diff < np.pi * 7 / 4:
            return [], []  # 无变道指令
        # 找交点
        traj_string = LineString(traj[:, :2])
        intersections, direction_diffs = [], []
        for p, a in lane_lines:
            if len(p) < 2:
                continue
            p = LineString(p[:, :2])
            intersection = p.intersection(traj_string)
            p = np.array(p.coords)
            if intersection.geom_type == "Point":
                intersection_point = np.array([intersection.x, intersection.y])
                # 计算切向
                distance_to_intersection = np.linalg.norm(p - intersection_point[None, :], axis=1)
                nearest_index = np.argsort(distance_to_intersection)[1]
                if np.linalg.norm(p[nearest_index] - traj[0]) < np.linalg.norm(intersection_point - traj[0]):
                    direction_lane = np.arctan2(
                        intersection_point[1] - p[nearest_index][1], intersection_point[0] - p[nearest_index][0]
                    )
                else:
                    direction_lane = np.arctan2(
                        p[nearest_index][1] - intersection_point[1], p[nearest_index][0] - intersection_point[0]
                    )
                distance_to_intersection = np.linalg.norm(traj - intersection_point, axis=1)
                nearest_index = np.argsort(distance_to_intersection)[1]
                if np.linalg.norm(traj[nearest_index] - traj[0]) < np.linalg.norm(intersection_point - traj[0]):
                    direction_traj = np.arctan2(
                        intersection_point[1] - traj[nearest_index][1], intersection_point[0] - traj[nearest_index][0]
                    )
                else:
                    direction_traj = np.arctan2(
                        traj[nearest_index][1] - intersection_point[1], traj[nearest_index][0] - intersection_point[0]
                    )
                direction_diff = norm_yaw(direction_lane - direction_traj)
                if direction_diff < np.pi / 4 or direction_diff > np.pi * 7 / 4:
                    intersections.append([intersection_point[0], intersection_point[1]])
                    direction_diffs.append(direction_diff)
            elif intersection.geom_type == "MultiPoint":
                for intersection_point in intersection.geoms:
                    intersection_point = np.array(intersection_point.coords[0])
                    # 计算切向
                    distance_to_intersection = np.linalg.norm(p - intersection_point[None, :], axis=1)
                    nearest_index = np.argsort(distance_to_intersection)[1]
                    if np.linalg.norm(p[nearest_index] - traj[0]) < np.linalg.norm(intersection_point - traj[0]):
                        direction_lane = np.arctan2(
                            intersection_point[1] - p[nearest_index][1], intersection_point[0] - p[nearest_index][0]
                        )
                    else:
                        direction_lane = np.arctan2(
                            p[nearest_index][1] - intersection_point[1], p[nearest_index][0] - intersection_point[0]
                        )
                    distance_to_intersection = np.linalg.norm(traj - intersection_point[None, :], axis=1)
                    nearest_index = np.argsort(distance_to_intersection)[1]
                    if np.linalg.norm(traj[nearest_index] - traj[0]) < np.linalg.norm(intersection_point - traj[0]):
                        direction_traj = np.arctan2(
                            intersection_point[1] - traj[nearest_index][1],
                            intersection_point[0] - traj[nearest_index][0],
                        )
                    else:
                        direction_traj = np.arctan2(
                            traj[nearest_index][1] - intersection_point[1],
                            traj[nearest_index][0] - intersection_point[0],
                        )
                    direction_diff = norm_yaw(direction_lane - direction_traj)
                    if direction_diff < np.pi / 4 or direction_diff > np.pi * 7 / 4:
                        intersections.append([intersection_point[0], intersection_point[1]])
                        direction_diffs.append(direction_diff)
        # 计算command
        commands, command_time_steps = [], []
        for i, intersection in enumerate(intersections):
            direction_diff = direction_diffs[i]
            if direction_diff < np.pi / 4:
                commands.append(2)
            elif direction_diff > np.pi * 7 / 4:
                commands.append(1)
            else:
                raise ValueError(f"Unexpected direction_diff: {direction_diff}")

            distance = np.linalg.norm(np.array(intersection) - traj[:, :2], axis=1)
            # min_index = np.argmin(distance)
            top_k = np.argsort(distance)[:3]  # 取前三个，防止交点处轨迹有噪声
            for index in top_k:
                if index not in command_time_steps:
                    command_time_steps.append(index)
                    break
        # 按时间步排序
        if len(command_time_steps) > 0:
            command_time_steps = np.array(command_time_steps)
            commands = np.array(commands)
            sort_index = np.argsort(command_time_steps)
            command_time_steps = command_time_steps[sort_index].tolist()
            commands = commands[sort_index].tolist()
        return commands, command_time_steps

    @staticmethod
    def get_all_command_change_time_steps(traj, command_time_steps, fps):
        """
        根据轨迹和指令时间步获取所有指令变化的时间步
        Args:
            traj: np.array, shape为(N, 2), N为轨迹点数
            command_time_steps: list, 每个指令对应的时间步
        Returns:
            command_begin_time_steps: list, 每个指令开始的时间步
            command_end_time_steps: list, 每个指令结束的时间步
        """
        command_begin_time_steps, command_end_time_steps = [], []
        for i in range(len(command_time_steps)):
            last_end_time_step = command_end_time_steps[-1] if i != 0 else -fps * 2  # 上一个指令变化的时间步
            next_command_time_step = (
                command_time_steps[i + 1] if i + 1 < len(command_time_steps) else len(traj) + fps * 2
            )
            # 考虑变道点往前20m + 4s的时间步，确定最早什么时候给出指令
            command_begin_time_step = command_time_steps[i] - 4 * fps  # 4s前的时间步
            length = 0
            for j in range(command_begin_time_step, last_end_time_step, -1):
                length += np.linalg.norm(traj[j] - traj[j - 1])  # 计算两点之间的距离
                if length >= 20:
                    command_begin_time_step = j
                    break
                elif j <= 0:
                    break
            if length < 20:
                command_begin_time_step = last_end_time_step
            # 尽可能离变道点2s以上
            if command_time_steps[i] - command_begin_time_step > fps * 2:
                random_time_step = np.random.randint(command_begin_time_step, command_time_steps[i] - fps * 2)
            else:
                random_time_step = command_begin_time_step
            command_begin_time_steps.append(random_time_step)
            # 尽可能离变道点2s以上
            if next_command_time_step - command_time_steps[i] > fps * 4:
                random_time_step = np.random.randint(command_time_steps[i] + fps * 2, next_command_time_step - fps * 2)
            else:
                random_time_step = (command_time_steps[i] + next_command_time_step) // 2
            command_end_time_steps.append(random_time_step)
        return command_begin_time_steps, command_end_time_steps

    @staticmethod
    def get_command_dones_and_commands(
        use_timestamps, command_begin_time_steps, command_end_time_steps, unzero_commands
    ):
        """
        根据指令变化的时间步获取每个状态的指令和指令是否完成
        Args:
            use_timestamps: list, 使用的时间戳列表
            command_begin_time_steps: list, 每个指令开始的时间步
            command_end_time_steps: list, 每个指令结束的时间步
            unzero_commands: list, 所有非直行指令, 取值为[1,2], 1表示左变道, 2表示右变道
        Returns:
            commands: np.array, shape为(len(use_timestamps),), 每个状态的指令, 取值为[0,1,2], 0表示不变道, 1表示左变道, 2表示右变道
        """
        commands = np.zeros(len(use_timestamps))
        current_command = 0 if len(unzero_commands) == 0 or command_begin_time_steps[0] > 0 else unzero_commands[0]
        current_unzero_command_index = 0  # 当前非直行指令的索引
        for i in range(len(use_timestamps)):
            if current_unzero_command_index >= len(unzero_commands):
                # 如果没有非直行指令了，保持当前状态不变道
                commands[i] = current_command
                continue
            if i < command_begin_time_steps[current_unzero_command_index]:
                commands[i] = current_command
            elif i == command_begin_time_steps[current_unzero_command_index]:
                # 开始变道指令
                current_command = unzero_commands[current_unzero_command_index]
                commands[i] = current_command
            elif (
                i > command_begin_time_steps[current_unzero_command_index]
                and i < command_end_time_steps[current_unzero_command_index]
            ):
                # 变道指令持续中
                commands[i] = current_command
            elif i == command_end_time_steps[current_unzero_command_index]:
                # 结束变道指令
                current_unzero_command_index += 1
                if current_unzero_command_index >= len(unzero_commands):
                    # 如果没有非直行指令了，保持当前状态不变道
                    current_command = 0
                else:
                    if command_begin_time_steps[current_unzero_command_index] == i:
                        current_command = unzero_commands[current_unzero_command_index]
                    elif command_begin_time_steps[current_unzero_command_index] > i:
                        current_command = 0
                    else:
                        raise ValueError(
                            f"Unexpected command_begin_time_steps: {command_begin_time_steps[current_unzero_command_index]} at index {current_unzero_command_index}"
                        )
                commands[i] = current_command
        return commands

    def get_one_sample(self, data, future_timestamps, idx):
        """
        Returns:
            polygon: N x 4 x 2
            polyline: N x M x 2
            polymask: N x 2
            propertys: N x 5 cls1(大类), cls2(细分类), cls3(车道线color), tid, timestamp_id. pad_id统一为0
            env_length: N
            label: N 车和人的label组合在一起
        注意：不要对data做INPLACE修改!
        """
        use_timestamps = future_timestamps[: self.timestamp_size]

        taginfo = data.get("tag_info", "")
        swap_flag = False
        trans = np.eye(4)[None, ...]
        if (
            self.swap_ego_and_agent
            and self.mode in ["rl", "infer"]
            and taginfo in ["navigate_30s", "road_to_ramp", "turn_left_30s", "turn_right_30s", "planner_scene_info"]
        ):
            data, swap_flag1, diff1, trans1 = self.move_across_centerline(data, use_timestamps, self.history_size, 1.0)
            data, swap_flag2, diff2, trans2 = self.tmp_move_back(data, use_timestamps, self.history_size, 1.0, diff1)
            swap_flag = swap_flag1 or swap_flag2
            if trans1 is not None:
                trans = trans1 @ trans
            if trans2 is not None:
                trans = trans2 @ trans

        trajpose = [data[ts]["car_pose"] for ts in future_timestamps]
        wheel_base = [data[ts]["vehicle_geometry"]["wheel_base"] for ts in future_timestamps]
        frnt_whl_ag = [None] * len(future_timestamps)
        for i, ts in enumerate(future_timestamps):
            if len(data[ts]["vehicle_info"]) > 0:
                frnt_whl_ag[i] = data[ts]["vehicle_info"][-1]["VehFrontWhlAg"]

        # 如果存在任意一个 None，则全部置为 None
        if any(v is None for v in frnt_whl_ag):
            frnt_whl_ag = [None] * len(future_timestamps)

        # 将原点坐标从自车后轴中心转移到车辆几何中心
        shift = np.eye(4)  # I
        shift[:3, 3] = [1.4, 0, 0]
        egocenter_pose = [t @ shift for t in trajpose]  # 自车位姿（自车坐标系）

        # 历史最后一帧的自车位置作为 center 和 origin
        origin_idx = min(len(egocenter_pose) - 1, self.history_size - 1)  # 14
        origin_pose = egocenter_pose[origin_idx]
        # if self.mode == "pretrain":
        #     # 数据增强移动起始帧位置
        #     origin_pose, center, origin_yaw = self.augment_initpose(origin_pose)
        # else:
        center = np.array([0, 0])
        origin_yaw = 0
        initpose = np.linalg.inv(origin_pose)

        # 动态物
        frame_agents = []
        frame_polygon = []
        for i, ts in enumerate(use_timestamps):
            ego_pose_backwheel = initpose @ data[ts]["car_pose"]
            if self.static_scene:
                dobjs_full = np.empty((0, 12), dtype=np.float32)
            else:
                dobjs_full = parse_dynamicobj_v2(data[ts]["dynamic_dets"], ego_pose_backwheel)  # 转到世界坐标系中
            frame_agents.append([ego_pose_backwheel @ shift, dobjs_full])
            frame_polygon.append(get_rotated_rectangle(dobjs_full))

        all_frame_agents = []
        for ts in future_timestamps:
            current_raw_data = data[ts]
            ego_pose_backwheel = initpose @ current_raw_data["car_pose"]

            if self.static_scene:
                dobjs_full = np.empty((0, 12), dtype=np.float32)
            else:
                dobjs_full = parse_dynamicobj_v2(current_raw_data["dynamic_dets"], ego_pose_backwheel)
            all_frame_agents.append([ego_pose_backwheel @ shift, dobjs_full])

        # 静态物
        env_ts_index = min(len(use_timestamps) - 1, self.history_size - 1)  # 历史最后一帧的信息
        env_ts = use_timestamps[env_ts_index]
        env_T = initpose @ data[env_ts]["car_pose"]
        (
            sobjs,
            god_polygon,
            road_sign,
            lane_lines,
            road_edge,
            nomap_road_edge,
            stop_line,
            tld,
            spd_limit,
            navi_path,
            navi_infos,
            centerlines,
            nadsts,
            least_lc_dist,
            toll_gate_center_line,
            waitzones,
            egopath_stoplines,
            god_polygon_vis,
            road_edge_vis,
            manner_scene_info,
            link_info,
            priority_road_class,
            parked_vehicle,
        ) = Plannn2Dataset.parse_frame_env_v3(data[env_ts], env_T, center, origin_yaw, **self.kwargs)
        sobjs_polygon = get_rotated_rectangle(sobjs)

        # 变道command
        (
            ego_lane_change_command,
            lane_change_signal,
            np_plus_lcc_status,
            commands_origin,
        ) = Plannn2Dataset.get_lane_change_command(
            data, use_timestamps, initpose, lane_lines, self.mode, origin_idx, self.fps
        )
        traj = [(initpose @ data[ts]["car_pose"])[:2, 3] for ts in use_timestamps]
        traj = np.array(traj)
        # 获取所有command
        commands, command_time_steps = Plannn2Dataset.get_all_commands(traj, lane_lines)
        turnlightsignal = dict([(ts, 0) for ts in use_timestamps])

        end_list = []

        cs_offset = 0
        if self.mode == "pretrain":
            cs_offset = 20
        elif self.mode == "rl":
            cs_offset = 10
        else:
            cs_offset = 20
        for idx in range(len(commands)):
            c = commands[idx]
            cs = command_time_steps[idx]
            if idx == 0:
                start = 0 if (cs - cs_offset) < 0 else cs - cs_offset
                end = len(traj) - 1 if (cs + 10) > len(traj) - 1 else cs + 10
                end_list.append(end)
            else:
                start = 0 if (cs - cs_offset) < 0 else cs - cs_offset
                if start <= end_list[-1]:
                    start = command_time_steps[idx - 1] + (command_time_steps[idx] - command_time_steps[idx - 1]) // 2
                end = len(traj) - 1 if (cs + 10) > len(traj) - 1 else cs + 10
                end_list.append(end)

            for ts in use_timestamps[start : end + 1]:
                turnlightsignal[ts] = c

        # egomotion
        vehspeeds = []
        for i, ts in enumerate(use_timestamps):
            egomotion = data[ts][
                "ego_motion"
            ]  # vx, vy, acc_x, acc_y, yaw, yaw_rate, whlag, whlagspd, vehspd, lgta, chassis_yawrate
            vehspeed = egomotion[8] * 3.6
            vehspeeds.append(vehspeed)

        # 原始环境信息放入dict
        raw_env = {
            "sobjs": sobjs,
            "sobjs_polygon": sobjs_polygon,
            "god_polygon": god_polygon,
            "god_polygon_vis": god_polygon_vis,
            "road_edge_vis": road_edge_vis,
            "road_sign": road_sign,
            "lane_lines": lane_lines,
            "centerlines": centerlines,
            "road_edge": road_edge,
            "nomap_road_edge": nomap_road_edge,
            "stop_line": stop_line,
            "tld": tld,
            "navi_infos": navi_infos,
            "navi_path": navi_path,
            "spd_limit": spd_limit,
            "dobjs_full": frame_agents,
            "dobjs_polygon": frame_polygon,
            "origin_pose": origin_pose,
            "max_time": min(self.timestamp_size, len(use_timestamps)),
            "gt_vehspeeds": vehspeeds,
            "gt_unreliable": True if self.static_scene else False,
            "ego_trans": trans if swap_flag else None,
            "np_plus_lcc_status": np_plus_lcc_status,
            "lane_change_signal": lane_change_signal,
            "toll_gate_center_line": toll_gate_center_line,
            "waitzones": waitzones,
            "egopath_stoplines": egopath_stoplines,
            "lane_change_command": commands_origin,
            "manner_scene_info": manner_scene_info,
            "link_info": link_info,
            "data_lengths": len(data["timestamp_list"]),
            "priority_road_class": priority_road_class,
            "parked_vehicle": parked_vehicle,
        }

        try:
            waypoints = (
                interpolate_points(navi_path[:4, :2], step=0.5) if navi_path is not None else None
            )  # 约20m距离，每隔0.5m插值
        except ValueError as e:
            print(f"Error in interpolate_navipath points: {e}, data idx {idx}")
            waypoints = None
        (
            state_polygon,
            state_polyline,
            state_poly_mask,
            state_property,
            label,  ## 825, 1 还是原来的label
            raw_dobjs,
            select_raw_tids,
            dobj_start_size,
            valid_ts,
            state_polygon_comp,
            state_polyline_comp,
            state_poly_mask_comp,
            state_property_comp,
            ego_polygons,
            ego_polyline,
            ego_property,
            ego_poly_mask,
            ego_labels,
            ego_polygon_full,
            ego_polyline_full,
            ego_property_full,
            ego_poly_mask_full,
            gt_state_polygon,
        ) = self.get_state_label(
            frame_agents,
            center,
            origin_yaw,
            waypoints,
            road_edge + nomap_road_edge,
            ego_lane_change_command,
            np_plus_lcc_status,
            use_timestamps,
            all_frame_agents,
            wheel_base,
            frnt_whl_ag,
        )
        _, _, ego_property = Plannn2Dataset.parse_his_fut_tld(data, navi_infos, use_timestamps, ego_property)
        scene_id, _ = self.get_scene_class(raw_env)
        tld_his_fut_list, tld_color_select_list, ego_property = Plannn2Dataset.parse_his_fut_tld(data, navi_infos, use_timestamps, ego_property)
        ego_labels_mask = self.tld_start_mask_flag(ego_polygon_full[self.history_size:], ego_property_full[self.history_size - 1:], vehspeeds, navi_infos, frame_agents, tld_color_select_list, tld_his_fut_list, ego_labels, scene_id)
        raw_env["select_raw_tids"] = select_raw_tids
        raw_env["dobj_start_size"] = dobj_start_size

        # 如果GT车速超过限速太多，增加一个gt_unreliable flag, 在RL时，不计算与GT相关的惩罚
        overspeed_distance = self.get_overspeed_distance(data, use_timestamps, gt_state_polygon)
        if overspeed_distance > 50:
            raw_env["gt_unreliable"] = True

        if self.mode == "pretrain" and np.random.rand() < self.navi_path_dropout:
            navi_infos = Plannn2Dataset.create_empty_navi_info()

            spd_limit = 0
            tld = [4, 4, 4, 4]
            # 计算reward时仍然使用navi_path, 但不用spd_limit和tld(因为会产生较大惩罚)
            raw_env["speed_limit"] = 0
            raw_env["tld"] = [4, 4, 4, 4]

        gate_mask = sobjs[:, 7] == 29
        if self.mode == "pretrain" and np.any(gate_mask) and np.random.rand() < self.navi_path_dropout:
            gate_idx = np.where(gate_mask)[0]
            if gate_idx.size > 0:
                # 一部分 gate 直接删除（模拟漏检/被遮挡）
                drop_ratio = 0.3
                drop_n = int(np.ceil(drop_ratio * gate_idx.size))
                drop_idx = np.random.choice(gate_idx, size=drop_n, replace=False)

                keep_mask = np.ones(len(sobjs), dtype=bool)
                keep_mask[drop_idx] = False

                sobjs = sobjs[keep_mask]
                sobjs_polygon = sobjs_polygon[keep_mask]

                # 对剩下的 gate 做状态降级 unknown（模拟可见但不可判）
                gate_mask_after = sobjs[:, 7] == 29
                sobjs[gate_mask_after, 8] = 10000

        env_polygon, env_polyline, env_poly_mask, env_property, env_length = Plannn2Dataset.get_env(
            sobjs,
            sobjs_polygon,
            god_polygon,
            road_sign,
            lane_lines,
            road_edge,
            nomap_road_edge,
            stop_line,
            tld,
            spd_limit,
            navi_infos,
            center,
            **self.kwargs,
        )  # env_polygon: [360, 4, 2]

        # normalize state

        env_polygon = torch.from_numpy(env_polygon).float() / self.state_range
        env_polyline = torch.from_numpy(env_polyline).float() / self.state_range
        env_polymask = torch.from_numpy(env_poly_mask).long()
        env_propertys = torch.from_numpy(env_property).long()

        state_polygon = torch.from_numpy(state_polygon_comp).float() / self.state_range
        state_polyline = torch.from_numpy(state_polyline_comp).float() / self.state_range
        state_polymask = torch.from_numpy(state_poly_mask_comp).long()
        state_propertys = torch.from_numpy(state_property_comp).long()

        ego_polygons = torch.from_numpy(ego_polygons).float() / self.state_range
        ego_polyline = torch.from_numpy(ego_polyline).float() / self.state_range
        ego_property = torch.from_numpy(ego_property).long()
        ego_poly_mask = torch.from_numpy(ego_poly_mask).long()
        ego_labels = torch.from_numpy(ego_labels).long()
        ego_labels_mask = torch.from_numpy(ego_labels_mask).long()

        env_length = torch.tensor(env_length).long()
        label = torch.from_numpy(label).long()

        ego_polygon_full = torch.from_numpy(ego_polygon_full).float() / self.state_range
        ego_polyline_full = torch.from_numpy(ego_polyline_full).float() / self.state_range
        ego_property_full = torch.from_numpy(ego_property_full).long()
        ego_poly_mask_full = torch.from_numpy(ego_poly_mask_full).long()

        if (
            torch.isnan(env_polygon).any()
            or torch.isnan(env_polyline).any()
            or torch.isnan(env_polymask).any()
            or torch.isnan(env_propertys).any()
            or torch.isnan(state_polygon).any()
            or torch.isnan(state_polyline).any()
            or torch.isnan(state_polymask).any()
            or torch.isnan(state_propertys).any()
        ):
            print(f"Warning: NaN values found in data. Replacing with zeros.")
            env_polygon = torch.nan_to_num(env_polygon, nan=0.0, posinf=0.0, neginf=0.0)
            env_polyline = torch.nan_to_num(env_polyline, nan=0.0, posinf=0.0, neginf=0.0)
            env_polymask = torch.nan_to_num(env_polymask, nan=0, posinf=0, neginf=0)
            env_propertys = torch.nan_to_num(env_propertys, nan=0, posinf=0, neginf=0)

            state_polygon = torch.nan_to_num(state_polygon, nan=0.0, posinf=0.0, neginf=0.0)
            state_polyline = torch.nan_to_num(state_polyline, nan=0.0, posinf=0.0, neginf=0.0)
            state_polymask = torch.nan_to_num(state_polymask, nan=0, posinf=0, neginf=0)
            state_propertys = torch.nan_to_num(state_propertys, nan=0, posinf=0, neginf=0)

        assert self.env_block_size == len(env_polygon) == len(env_polyline) == len(env_polymask) == len(
            env_propertys
        ) and self.max_obj_token == len(state_polygon) == len(state_polyline) == len(state_polymask) == len(
            state_propertys
        )
        raw_env["valid_ts"] = valid_ts
        raw_env["turnlightsignal"] = turnlightsignal

        # # append motion labels to label
        latitude_gt_label_list = []
        longitudinal_gt_label_list = []

        frame_motion_status = []
        for i, ts in enumerate(use_timestamps):
            motion_status = data[ts]["motion_status"]
            frame_motion_status.append(motion_status)
            latitude_gt_label_list.append(MetaActionManager.LATITUDE_LABELS_MAP[motion_status["lateral"]])
            longitudinal_gt_label_list.append(MetaActionManager.LONGITUDE_LABELS_MAP[motion_status["longitudinal"]])


        # latitude_label labels (action-oriented: label matches current frame's trajectory)
        latitude_status = frame_motion_status[origin_idx].get("lateral", 0)
        latitude_label = MetaActionManager.LATITUDE_LABELS_MAP[latitude_status]
        latitude_label = latitude_label + self.num_classes
        raw_env["latitude_label"] = latitude_label
        raw_env["latitude_gt_labels"] = latitude_gt_label_list[self.history_size:]

        # longitude labels
        longitude_status = frame_motion_status[origin_idx].get("longitudinal", 0)
        if longitude_status != 0:
            longitude_label = MetaActionManager.LONGITUDE_LABELS_MAP[longitude_status]
        else:
            # look forward to get next non-zero motion status
            longitude_label = 0
            for future_status in frame_motion_status[origin_idx + 1 :]:
                if future_status["longitudinal"] != 0:
                    longitude_label = MetaActionManager.LONGITUDE_LABELS_MAP[future_status["longitudinal"]]
                    break

        longitude_label = longitude_label + self.num_classes + MetaActionManager.LATITUDE_LABEL_NUM
        raw_env["longitude_label"] = longitude_label
        raw_env["longitude_gt_labels"] = longitudinal_gt_label_list[self.history_size:]

        return (
            state_polygon,
            state_polyline,
            state_polymask,
            state_propertys,
            env_polygon,
            env_polyline,
            env_polymask,
            env_propertys,
            env_length,
            label,
            raw_env,
            ego_polygons,
            ego_polyline,
            ego_property,
            ego_poly_mask,
            ego_polygon_full,
            ego_polyline_full,
            ego_property_full,
            ego_poly_mask_full,
            ego_labels,
            ego_labels_mask,
        )

    def get_overspeed_distance(self, data, use_timestamps, gt_state_polygon):
        label_num = len(use_timestamps) + 1 - self.history_size
        if label_num > 0:
            pred_polygon = gt_state_polygon[-label_num:]
            spd_limits = self.parse_multi_spd_limit(data, use_timestamps[self.history_size :])
            spd_limits[spd_limits == 0] = 10000  # 无限速
            vehspd = np.linalg.norm(pred_polygon.mean(1)[1:] - pred_polygon.mean(1)[:-1], axis=1)
            over_spd = np.maximum(0, vehspd - spd_limits / 3.6 / self.fps)
            sum_over_distance = np.sum(over_spd)
            return sum_over_distance
        else:
            return 0

    def _get_lane_info_sequence(self, data, timestamps):
        """
        返回经过路口的时间点
        """
        lane_nr_distance_list = []
        for i, t in enumerate(timestamps):
            frame = data[t]
            link_info = frame["link_info"]
            map_loc = frame["map_loc"]
            if link_info and "link_index" in map_loc:
                link_index = map_loc["link_index"]
                link_remain_distance = map_loc["link_remain_dist"]

                # next available lane_nr_info
                link_index_next_lane = -1
                for link_id in range(link_index, len(link_info)):
                    if link_info[link_id]["lane_nr_info"]:
                        link_index_next_lane = link_id
                        break
                if link_index_next_lane >= 0:
                    lane_nr_distance = link_remain_distance
                    if link_index != link_index_next_lane:
                        for i in range(link_index + 1, link_index_next_lane + 1):
                            lane_nr_distance += link_info[i]["cal_link_length"]
                else:
                    lane_nr_distance = 10000
                lane_nr_distance_list.append(lane_nr_distance)
            else:
                lane_nr_distance_list.append(10000)

        # 返回distance < 150的index
        return list(np.where(np.array(lane_nr_distance_list) < 300)[0])

    def select_start_idx(
        self, data, timestamps, select_num, key_frame_flag=None, key_frame_sample_mode=None, fname=None
    ):
        idx = []


        max_start_idx = max(0, len(timestamps) - self.timestamp_size)

        vehspeeds = []
        vehyaws = []
        abs_acc = []
        abs_yawrate = []

        dyn_dets = []
        for i, ts in enumerate(timestamps):
            dynamic_dets = data[ts]["dynamic_dets"]  # x, y, z, l, w, h, yaw, cid, sid, tid, vx, vy
            dyn_dets.append(dynamic_dets)
            egomotion = data[ts][
                "ego_motion"
            ]  # vx, vy, acc_x, acc_y, yaw, yaw_rate, whlag, whlagspd, vehspd, lgta, chassis_yawrate
            vehspeed = egomotion[8] * 3.6
            vehyaw = abs(egomotion[5]) * 53.7
            vehspeeds.append(vehspeed)
            vehyaws.append(vehyaw)
            abs_acc.append(abs(egomotion[2])+abs(egomotion[3]))
            abs_yawrate.append(abs(egomotion[5]))


        def sample_start_idx(select_num, max_start_idx,start_idx_sample_mode,abs_acc,abs_yawrate):
            sample_res = []
            if start_idx_sample_mode == "acc":
                high_acc_sample_num = int(np.ceil(select_num * 0.75))
                random_sample_num = select_num - high_acc_sample_num
                random_begin = np.random.randint(self.history_size, self.timestamp_size-2*self.segment_labels)
                if random_begin >= max_start_idx:
                    return sample_res
                valid_acc_abs = np.array(abs_acc[random_begin:max_start_idx])
                top_acc_indices = np.where(valid_acc_abs > 0.2)[0]
                if len(top_acc_indices) == 0:
                    return sample_res
                high_acc_start_idx = np.random.choice(
                    top_acc_indices,
                    size=high_acc_sample_num,
                    replace=high_acc_sample_num > len(top_acc_indices),
                ).tolist()
                random_start_idx = np.random.randint(0, max_start_idx, size=random_sample_num).tolist()
                high_acc_start_idx = [x + random_begin - self.history_size -(random_begin-self.history_size)  for x in high_acc_start_idx]
                sample_res = high_acc_start_idx + random_start_idx
            if start_idx_sample_mode == "acc_yawrate":
                high_acc_sample_num = int(np.ceil(select_num * 0.5))
                high_yawrate_sample_num = int(np.ceil(select_num * 0.25))
                random_sample_num = select_num - high_acc_sample_num - high_yawrate_sample_num
                random_begin = np.random.randint(self.history_size, self.timestamp_size-2*self.segment_labels)
                if random_begin >= max_start_idx:
                    return sample_res
                valid_acc_abs = np.array(abs_acc[random_begin:max_start_idx])
                valid_yawrate_abs = np.array(abs_yawrate[random_begin:max_start_idx])
                top_acc_num = max(1, int(np.ceil(max_start_idx * 0.1)))
                top_acc_indices = np.argsort(valid_acc_abs)[-top_acc_num:]
                top_yawrate_num = max(1, int(np.ceil(max_start_idx * 0.1)))
                top_yawrate_indices = np.argsort(valid_yawrate_abs)[-top_yawrate_num:]
                high_acc_start_idx = np.random.choice(
                    top_acc_indices,
                    size=high_acc_sample_num,
                    replace=high_acc_sample_num > len(top_acc_indices),
                ).tolist()
                high_yawrate_start_idx = np.random.choice(
                    top_yawrate_indices,
                    size=high_yawrate_sample_num,
                    replace=high_yawrate_sample_num > len(top_yawrate_indices),
                ).tolist()
                random_start_idx = np.random.randint(0, max_start_idx, size=random_sample_num).tolist()
                high_acc_yawrate_start_idx = high_acc_start_idx + high_yawrate_start_idx
                high_acc_yawrate_start_idx = [x + random_begin - self.history_size -(random_begin-self.history_size)  for x in high_acc_yawrate_start_idx]
                sample_res = high_acc_yawrate_start_idx + random_start_idx

            return sample_res

        if self.mode in ["pretrain", "sft"]:
            if key_frame_sample_mode == "online":
                if key_frame_flag == "start":
                    key_frames = self.longitudinal_checker.find_start_key_frames(
                        vehspeeds,
                        time_step=1.0 / self.fps,
                        threshold=0.3,
                        duration_for_check=1.0,
                    )
                if key_frame_flag == "effective_change_lane":
                    key_frames = self.effective_change_lane_checker.find_effective_change_lane_key_frames(
                        dyn_dets, vehspeeds
                    )
                    if len(key_frames) == 0:
                        return idx
                elif key_frame_flag == "intersection":
                    is_average_sample = True
                    key_frames = self.humanoid_checker.find_intersection_key_frames(
                        data, timestamps, max_key_idx=max_start_idx - 1
                    )
            elif key_frame_sample_mode == "offline_local":
                clip_id = self._extract_clip_id(fname)
                offline_local_tags = self.clipid_tag.get(clip_id, None)
                key_frames = {}
                if offline_local_tags is not None:
                    for tag_checker_name in offline_local_tags:
                        tags_info = offline_local_tags[tag_checker_name]
                        key_frames_list = []
                        for tag_index in tags_info:
                            start_time = tag_index["start_time"]
                            end_time = tag_index["end_time"]
                            if start_time < timestamps[0]:
                                start_time = timestamps[0]
                            elif start_time > timestamps[-1]:
                                start_time = timestamps[-1]
                            if end_time > timestamps[-1]:
                                end_time = timestamps[-1]
                            elif end_time < timestamps[0]:
                                end_time = timestamps[0]
                            start_idx = max(timestamps.index(start_time), self.history_size - 1)
                            end_idx = min(
                                timestamps.index(end_time),
                                len(timestamps) - self.timestamp_size + (self.history_size - 2),
                            )
                            if end_idx >= start_idx:
                                key_frames_list = key_frames_list + [
                                    idx_index for idx_index in range(start_idx, end_idx + 1)
                                ]
                        if len(key_frames_list) > 0:
                            key_frames[tag_checker_name] = key_frames_list
                else:
                    logger.debug(f"offline_local_tags is None for clip_id {clip_id}")
            elif key_frame_sample_mode == "offline_server":
                print("get offline key frames from lua checker, not implemented yet")

        taginfo = data.get("tag_info", "")
        uuid = data.get("uuid", "")
        bad_inds = []
        if uuid in self.dirty_meta:
            all_bad_inds = []
            for tag in self.dirty_meta[uuid]:
                dirty_start_idx = find_closest_index(timestamps, tag["start_time"])
                dirty_end_idx = find_closest_index(timestamps, tag["end_time"])
                bad_inds = list(range(dirty_start_idx, dirty_end_idx + 1))
                # print('Found bad inds in uuid %s: %s' % (uuid, str(bad_inds)))
                pre, post = [], []
                for i in range(40):
                    if bad_inds[0] - (i + 1) > 0:
                        pre.append(bad_inds[0] - (i + 1))
                for i in range(5):
                    if bad_inds[-1] + (i + 1) < len(timestamps):
                        post.append(bad_inds[-1] + (i + 1))
                bad_inds = pre + bad_inds + post
                # print('Got all bad inds: %s' % str(bad_inds))
                all_bad_inds += bad_inds
            bad_inds = np.unique(all_bad_inds).tolist()

        if self.mode == "infer":
            if select_num > 0:
                if self.start_at_idx:
                    idx = [self.start_at_idx] * select_num
                    return idx

                if taginfo in ["navigate_30s", "road_to_ramp", "turn_left_30s", "turn_right_30s"]:
                    lane_seq_index = self._get_lane_info_sequence(data, timestamps)
                    if lane_seq_index:
                        return [min(max_start_idx, lane_seq_index[0])] * select_num

                for _ in range(select_num):
                    # infer mode选择第5%帧作为起始帧
                    start_idx = min(int(len(timestamps) * 0.05), len(timestamps) - self.history_size - 1)
                    idx.append(start_idx)
            else:
                # 开环测试，直接返回所有帧数据
                idx = list(range(len(timestamps) - self.history_size))
        elif self.mode == "rl":
            if taginfo in ["navigate_30s", "road_to_ramp", "turn_left_30s", "turn_right_30s"]:
                lane_seq_index = self._get_lane_info_sequence(data, timestamps)
                if lane_seq_index:
                    return [min(max_start_idx, lane_seq_index[0])] * select_num

            for _ in range(select_num):
                # infer mode选择第5%帧作为起始帧
                start_idx = np.random.randint(0, max_start_idx + 1)
                idx.append(start_idx)
        else:
            max_start_idx = len(timestamps) - 1 - self.timestamp_size
            if max_start_idx < 2:
                return idx
            if taginfo == "aeb_tp":
                for _ in range(select_num):
                    start_idx = np.random.randint(6, 25)  # 1-4s 作为历史0时刻
                    start_idx = min(start_idx, max_start_idx)
                    # if key_frame_flag is not None and len(key_frames) > 0:
                    #     start_idx = random.choice(key_frames) - (self.history_size - 1)
                    idx.append(start_idx)
            elif taginfo == "collision_high_risk":
                for _ in range(select_num):
                    start_idx = np.random.randint(1, 15)  # # 0-2s 作为历史0时刻
                    start_idx = min(start_idx, max_start_idx)
                    # if key_frame_flag is not None and len(key_frames) > 0:
                    #     start_idx = random.choice(key_frames) - (self.history_size - 1)
                    idx.append(start_idx)
            elif taginfo == "plann2_etc":
                first_plaza_in = next(
                    (idx for idx, ts in enumerate(data["timestamp_list"]) if "toll_gate_center_line" in data[ts]), None
                )
                if first_plaza_in and first_plaza_in <= max_start_idx:
                    for _ in range(select_num):
                        start_idx = np.random.randint(
                            max(0, first_plaza_in - 20), max_start_idx
                        )  # # 从进入ETC模式前3s开始
                        # if key_frame_flag is not None and len(key_frames) > 0:
                        #     start_idx = random.choice(key_frames) - (self.history_size - 1)
                        idx.append(start_idx)
                else:
                    for _ in range(select_num):
                        start_idx = np.random.randint(0, max_start_idx)
                        # if key_frame_flag is not None and len(key_frames) > 0:
                        #     start_idx = random.choice(key_frames) - (self.history_size - 1)
                        idx.append(start_idx)
            else:
                if key_frame_sample_mode == "online":
                    if key_frame_flag == "intersection" and is_average_sample and len(key_frames) > 0:
                        key_frames = sorted(list(set(key_frames)))
                        n = len(key_frames)
                        for i in range(select_num):
                            start = i * n // select_num
                            end = (i + 1) * n // select_num
                            key_frames_batch = key_frames[start:end]
                            start_idx = random.choice(key_frames) - (self.history_size - 1)
                            if len(key_frames_batch) > 0:
                                start_idx = random.choice(key_frames_batch) - (self.history_size - 1)
                            idx.append(start_idx)
                    else:
                        for _ in range(select_num):
                            if key_frame_flag is not None and len(key_frames) > 0:
                                start_idx = random.choice(key_frames) - (self.history_size - 1)
                            else:
                                start_idx = np.random.randint(0, max_start_idx)
                            idx.append(start_idx)
                elif key_frame_sample_mode == "offline_local":
                    if not key_frames:
                        for _ in range(select_num):
                            start_idx = np.random.randint(0, max_start_idx)
                            idx.append(start_idx)

                    else:
                        checker_name_sample_times = {}
                        for key_frame in key_frames:
                            sample_times = train_data_tag_config[key_frame.split("--")[0]][key_frame.split("--")[1]][
                                "sample_times"
                            ]
                            checker_name_sample_times[key_frame] = sample_times
                            checker_name_sample_times_sorted = dict(
                                sorted(
                                    checker_name_sample_times.items(),
                                    key=lambda x: (x[1], random.random(), random.random(), random.random()),
                                    reverse=True,
                                )
                            )
                        sampled_num = 0
                        for key_frame, sample_times in checker_name_sample_times_sorted.items():
                            key_frame_list = key_frames[key_frame]
                            if sampled_num + sample_times > select_num:
                                sample_num = select_num - sampled_num
                                if sample_num > len(key_frame_list):
                                    start_idx = np.random.choice(key_frame_list, size=sample_num, replace=True)
                                else:
                                    start_idx = np.random.choice(key_frame_list, size=sample_num, replace=False)
                                idx = idx + (start_idx - (self.history_size - 1)).tolist()
                                sampled_num = sampled_num + sample_num
                            else:
                                if sample_times > len(key_frame_list):
                                    start_idx = np.random.choice(key_frame_list, size=sample_times, replace=True)
                                else:
                                    start_idx = np.random.choice(key_frame_list, size=sample_times, replace=False)
                                idx = idx + (start_idx - (self.history_size - 1)).tolist()
                                sampled_num = sampled_num + sample_times
                        if sampled_num < select_num:
                            for _ in range(select_num - sampled_num):
                                start_idx = np.random.randint(0, max_start_idx)
                                idx.append(start_idx)
                elif key_frame_sample_mode == "offline_server":
                    print("offline_server not implemented yet")
                else:
                    if np.random.random() < 0.0:
                        possible_inds = [_ for _ in range(len(timestamps) - 1 - self.timestamp_size) if _ not in bad_inds]
                        if not possible_inds:
                            return idx
                        idx = np.random.choice(possible_inds, select_num, len(possible_inds) < select_num).tolist()
                    else:
                        idx.extend(sample_start_idx(select_num, max_start_idx, start_idx_sample_mode=self.start_idx_sample_mode, abs_acc=abs_acc, abs_yawrate=abs_yawrate))

        return idx

    def __getitem__(self, idx):
        # Periodically run GC to prevent heap accumulation.
        # Auto-GC is disabled in worker_init_fn to avoid stop-the-world pauses
        # (gen2 full collection can take 11~17s when object heap is large).
        if not hasattr(self, "_gc_counter"):
            self._gc_counter = 0
        self._gc_counter += 1
        if self._gc_counter % 1000 == 0:
            gc.collect()  # full collect, reclaim lru_cache evictions
        elif self._gc_counter % 100 == 0:
            gc.collect(0)  # gen0 only, ~0.1ms

        is_ori, fname, closed_timestamp = self.data_list[idx]
        # uuid = fname.split("CLIP/")[-1].split("/")[0].split("_0_0")[0]
        uuid = find_uuid(fname, md5_ok=False) ## this could be "" for some data without uuid. if md5_ok=True, will produce an md5 instead
        try:
            data = _load_data(fname)
            timestamps = sorted(data["timestamp_list"])
            meta_action_tag = self.get_tags_for_path(extract_minium_uuid(fname))
            # pre-process collision risk detection
            action_manager = MetaActionManager(data, clip_id=f"{idx:08d}", enable_viz=False)
            if not meta_action_tag:
                clip_lable_status = action_manager.process(dataset_kwargs=self.kwargs)
            else:
                clip_lable_status = action_manager.process_offline(meta_action_tag, dataset_kwargs=self.kwargs)

            # fill data with motion status and collision status, inplace update data
            for ts, clip_label in zip(timestamps, clip_lable_status):
                data[ts]["motion_status"] = clip_label
        except Exception as e:
            print(f"Error when reading file {idx}  {fname}: {e}")
            return self.__getitem__(np.random.randint(0, len(self)))

        timestamps = sorted(data["timestamp_list"])
        data["uuid"] = uuid

        # 不使用第一帧
        timestamps = timestamps[1:]
        if self.mode == "pretrain" and len(timestamps) - self.timestamp_size - 1 < 1:
            logger.warning("Not enough timestamps in data idx %d, random get another one.", idx)
            return self.__getitem__(np.random.randint(0, len(self)))

        if self.mode == "pretrain":
            offset = np.random.randint(0, self.frame_downsample)
        else:
            offset = 0
        downsample_timestamps = timestamps[offset :: self.frame_downsample]
        if self.mode == "rl":
            if len(downsample_timestamps) < self.history_size + 20:
                print(f"len(downsample_timestamps): {len(downsample_timestamps)}, random get another one.")
                return self.__getitem__(np.random.randint(0, len(self)))

        if closed_timestamp is not None:
            item_mini_start_idx = [
                max(0, round((float(closed_timestamp) - downsample_timestamps[0]) / 0.2) - (self.history_size - 1))
            ]
        else:
            item_mini_start_idx = self.select_start_idx(
                data,
                downsample_timestamps,
                self.item_mini_batch,
                key_frame_flag=self.key_frame_flags[idx],
                key_frame_sample_mode=self.key_frame_sample_mode[idx],
                fname=fname,
            )



        if not item_mini_start_idx or item_mini_start_idx[0] < 0:
            print(f"Error when reading file {idx}: No available start idx")
            if self.mode == "infer":
                return self.__getitem__((idx * 2 + 1) % len(self))
            else:
                return self.__getitem__(np.random.randint(0, len(self)))

        assert item_mini_start_idx[0] >= 0, "item_mini_start_idx should be greater than or equal to 0"
        item_batches = []
        turnlight_batches = []
        turnlight_batches_mask = []
        scenario_id_lst = []
        for start_idx in item_mini_start_idx:
            use_timestamps = downsample_timestamps[start_idx:]
            item = self.get_one_sample(data, use_timestamps, idx)
            if len(item[19]) == 0: # ego_labels长度为0
                continue
            valid_ts = item[-11].pop("valid_ts")
            turnlightsignal = item[-11].pop("turnlightsignal")
            item[-11]["idx"] = idx
            item[-11]["scenario_id"] = self.scenario_id_lst[idx]
            item[-11]["use_timestamps"] = use_timestamps
            # item[-1]["plannn_data"] = data
            item[-11]["v3_ceph"] = fname
            # item[-1]["downsample_timestamps"] = downsample_timestamps
            item[-11]["eval_rewards_info"] = self.reward_meta_map.get(fname, None)
            # # 对于打灯，为了和action label对齐
            if data["use_turnlightsignal"]:
                turnlightsignal = {}
                for ts in data["timestamp_list"]:
                    turnlightsignal[ts] = data[ts]["turnlight"]
            turnlight = []
            for ts in valid_ts:
                turnlight.append(turnlightsignal[ts])
            turnlight = np.array(turnlight)
            # label = item[-1]
            # turnlightsignal = -1 * np.ones_like(label)
            # turnlightsignal[label != -1] = turnlight
            # turnlight_batches.append(torch.from_numpy(turnlightsignal).long())
            # turnlightsignal_mask = torch.ones((1,))
            # if is_ori and turnlight.sum() == 0:
            #     turnlightsignal_mask = torch.zeros((1,))
            # turnlight_batches_mask.append(turnlightsignal_mask)
            subset_name = self.sample_subset_list[idx] if idx < len(self.sample_subset_list) else self.tp_mode
            item[-11]["subset_info"] = {
                "family": "plannn2",
                "split": subset_name,
            }
            scenario_id_lst.append(torch.tensor([self.scenario_id_lst[idx].value], dtype=torch.long))

            item_batches.append(item)
        if not item_batches:
            return self.__getitem__(np.random.randint(0, len(self)))

        train_data = []
        for item in zip(*item_batches):
            if isinstance(item[0], torch.Tensor):
                train_data.append(torch.stack(item, dim=0))
            else:
                train_data.append(item)
        # polygons, polylines, polymask, propertys, env_length, label, raw_data = train_data

        (
            state_polygons,
            state_polylines,
            state_polymask,
            state_propertys,
            env_polygons,
            env_polylines,
            env_polymask,
            env_propertys,
            env_length,
            label,
            raw_data,
            ego_polygons,
            ego_polyline,
            ego_property,
            ego_poly_mask,
            ego_polygon_full,
            ego_polyline_full,
            ego_property_full,
            ego_poly_mask_full,
            ego_labels,
            ego_labels_mask,
        ) = train_data

        eval_rewards_info = [rd.get("eval_rewards_info", None) for rd in raw_data]
        # turnlightsignal = torch.stack(turnlight_batches, dim=0)
        # turnlightsignal_mask = torch.stack(turnlight_batches_mask, dim=0)
        scenario_id = torch.stack(scenario_id_lst, dim=0)
        motion_label = torch.tensor([[rd["latitude_label"],rd["longitude_label"]] for rd in raw_data]).long()
        ego_labels = torch.cat((motion_label, ego_labels), dim=1)
        ego_labels_mask = torch.cat((motion_label, ego_labels_mask), dim=1)

        data_input = {
            "dyn_polygons": state_polygons,
            "dyn_polylines": state_polylines,
            "dyn_polymask": state_polymask,
            "dyn_propertys": state_propertys,
            "ego_polygon": ego_polygons,
            "ego_polyline": ego_polyline,
            "ego_property": ego_property,
            "ego_poly_mask": ego_poly_mask,
            "polygons": env_polygons,
            "polylines": env_polylines,
            "polymask": env_polymask,
            "propertys": env_propertys,
            "env_length": env_length,
            "label": label,
            "raw_data": raw_data,
            "idx": idx if self.mark_idx_list is None else self.mark_idx_list[idx],
            "eval_rewards_info": eval_rewards_info,
            "scenario_id": scenario_id,
            "ego_polygon_full": ego_polygon_full,
            "ego_polyline_full": ego_polyline_full,
            "ego_property_full": ego_property_full,
            "ego_poly_mask_full": ego_poly_mask_full,
            "scenario_id": scenario_id,
            # init ego_label and ego_action for inference mode.
            "ego_labels": ego_labels_mask,
            "ego_actions": ego_labels[:, :-1],
        }
        if self._transforms is not None:
            data_input = self._transforms(data_input)

        return data_input

    def batch_collate(self, data: List[Any]) -> Any:
        """Batch collate function.

        Args:
            data (List): List of `__getitem__` returns.
        """

        polygons = torch.concatenate([d["polygons"] for d in data], dim=0)
        polylines = torch.concatenate([d["polylines"] for d in data], dim=0)
        polymask = torch.concatenate([d["polymask"] for d in data], dim=0)
        propertys = torch.concatenate([d["propertys"] for d in data], dim=0)

        dyn_polygons = torch.concatenate([d["dyn_polygons"] for d in data], dim=0)
        dyn_polylines = torch.concatenate([d["dyn_polylines"] for d in data], dim=0)
        dyn_polymask = torch.concatenate([d["dyn_polymask"] for d in data], dim=0)
        dyn_propertys = torch.concatenate([d["dyn_propertys"] for d in data], dim=0)

        ego_polygons = torch.concatenate([d["ego_polygon"] for d in data], dim=0)
        ego_polylines = torch.concatenate([d["ego_polyline"] for d in data], dim=0)
        ego_polymask = torch.concatenate([d["ego_poly_mask"] for d in data], dim=0)
        ego_propertys = torch.concatenate([d["ego_property"] for d in data], dim=0)
        ego_labels = torch.concatenate([d["ego_labels"] for d in data], dim=0)

        ego_polygon_full = torch.concatenate([d["ego_polygon_full"] for d in data], dim=0)
        ego_polyline_full = torch.concatenate([d["ego_polyline_full"] for d in data], dim=0)
        ego_property_full = torch.concatenate([d["ego_property_full"] for d in data], dim=0)
        ego_poly_mask_full = torch.concatenate([d["ego_poly_mask_full"] for d in data], dim=0)

        ego_actions = torch.concatenate([d["ego_actions"] for d in data], dim=0)

        label = torch.concatenate([d["label"] for d in data], dim=0)
        idx = torch.tensor([d["idx"] for d in data])
        scenario_id = torch.concatenate([d["scenario_id"] for d in data], dim=0)
        # turnlightsignal = torch.concatenate([d["turnlightsignal"] for d in data], dim=0)
        # turnlightsignal_mask = torch.concatenate([d["turnlightsignal_mask"] for d in data], dim=0)

        data_collate = {
            "polygon": polygons,
            "polyline": polylines,
            "polymask": polymask,
            "property": propertys,
            "dyn_polygon": dyn_polygons,
            "dyn_polyline": dyn_polylines,
            "dyn_polymask": dyn_polymask,
            "dyn_property": dyn_propertys,
            "ego_polygon": ego_polygons,
            "ego_polyline": ego_polylines,
            "ego_polymask": ego_polymask,
            "ego_property": ego_propertys,
            "ego_labels": ego_labels,
            "label": label,
            "idx": idx,
            "scenario_id": scenario_id,
            "ego_actions": ego_actions,
            "ego_polygon_full": ego_polygon_full,
            "ego_polyline_full": ego_polyline_full,
            "ego_property_full": ego_property_full,
            "ego_poly_mask_full": ego_poly_mask_full,
        }

        # Include cpu_data for rl, sft, and infer modes
        # infer mode needs cpu_data for evaluator
        if self.mode in ["rl", "sft", "infer"]:
            raw_data = [d["raw_data"] for d in data]
            eval_rewards_info = []
            for d in data:
                eval_rewards_info.extend(d["eval_rewards_info"])
            data_collate["cpu_data"] = {"raw_data": raw_data, "eval_rewards_info": eval_rewards_info}

        if "polygon_ori" in data[0].keys():
            polygons_ori = torch.concatenate([d["polygon_ori"] for d in data], dim=0)
            polylines_ori = torch.concatenate([d["polyline_ori"] for d in data], dim=0)
            polymask_ori = torch.concatenate([d["polymask_ori"] for d in data], dim=0)
            propertys_ori = torch.concatenate([d["property_ori"] for d in data], dim=0)
            data_collate["polygon_ori"] = polygons_ori
            data_collate["polyline_ori"] = polylines_ori
            data_collate["polymask_ori"] = polymask_ori
            data_collate["property_ori"] = propertys_ori

        if "ego_polygon_ori" in data[0].keys():
            ego_polygons_ori = torch.concatenate([d["ego_polygon_ori"] for d in data], dim=0)
            ego_polylines_ori = torch.concatenate([d["ego_polyline_ori"] for d in data], dim=0)
            ego_polymask_ori = torch.concatenate([d["ego_poly_mask_ori"] for d in data], dim=0)
            ego_propertys_ori = torch.concatenate([d["ego_property_ori"] for d in data], dim=0)
            data_collate["ego_polygon_ori"] = ego_polygons_ori
            data_collate["ego_polyline_ori"] = ego_polylines_ori
            data_collate["ego_polymask_ori"] = ego_polymask_ori
            data_collate["ego_property_ori"] = ego_propertys_ori

        return data_collate

    @staticmethod
    def get_state_closed(frame_agents, center, origin_yaw, waypoints, roadedge, commands, np_plus_lcc_status, **kwargs):
        """
        选取第0帧出现的尽量全部的物体:
            - 剔除路沿外静态的 vehicle & bicycle
                路沿外: 连线和路沿仅有一个交点
                静态: 速度最大值小于 0.1m/s?
            - 剔除15帧内都在远离自车的目标 (包括行人?)
                最后一帧的距离 > n米
            - 静态目标保留一帧
                不区分死车和拥堵车
            - 如果物体驶出target range, label为-1
        Args:
        frame_agents: list of (T, dobjs_full) as each timestamp, T is 4x4 ego pose,
                    dobjs_full is n x 12, x, y, z, l, w, h, yaw, cid, sid, tid, vx, vy
                    仅包含历史帧
        Returns:
            state_polygon: N x 4 x 2, N is state_block_size
            state_polyline: N x M x 2
            state_poly_mask: N x 2
            state_property: N x 5 cls1(大类), cls2(细分类), 0, tid, timestamp_id
            raw_dobjs: list of {tid: [dobj, c3, label_id]} for each timestamp
        """
        egoinfo = np.array([[0, 0, 0, 4.85, 2, 2, 0]], dtype=np.float32)

        # 1. 根据历史帧选取动静态的track_id, 并构造到输入网络的tid的映射tid_map以及ego_tid
        static_raw_track_ids, dynamic_raw_track_ids, history_size = Plannn2Dataset.dobj_select_all(
            frame_agents, center, origin_yaw, waypoints, roadedge, **kwargs
        )
        select_raw_track_ids = static_raw_track_ids | dynamic_raw_track_ids
        dobj_start_size = kwargs["history_size"] - history_size

        # 构造tid_map
        track_id_to_net = np.arange(1, 2 + len(select_raw_track_ids))
        if not kwargs["mode"] in ["infer", "rl"]:
            np.random.shuffle(track_id_to_net[1:])
        tid_map = {tid: track_id_to_net[i + 1] for i, tid in enumerate(select_raw_track_ids)}
        ego_tid = track_id_to_net[0]  # 自车

        # 2. 遍历构造每个时刻数据，记录每个时刻中在tid_map中物体的状态
        data = []
        record_static_tids = set()
        for ts, (ego_pose, dobjs_full) in enumerate(frame_agents):
            frame_data = {}
            # ego
            frame_data[ego_tid] = [transform_obj(egoinfo, ego_pose)[0], cls_mapping["ego"], -1]
            # 动静态目标
            if ts < kwargs["history_size"]:
                raw_track_id = dobjs_full[:, 9].astype(int)
                in_tid_map = [tid in tid_map for tid in raw_track_id]
                dobjs_full = dobjs_full[in_tid_map]
                cid = dobjs_full[:, 7].astype(int)
                cid_3cls = [get_map_cls_to_3cls(c) for c in cid]
                for tid, dobj, c3 in zip(raw_track_id[in_tid_map], dobjs_full, cid_3cls):
                    # 如果是人，将yaw角置为0
                    if c3 == "pedestrian":
                        dobj[6] = 0
                    # 静态目标 & 初次出现
                    if tid in static_raw_track_ids and tid not in record_static_tids:
                        frame_data[tid_map[tid]] = [
                            dobj[:7],
                            cls_mapping["static_" + c3],
                            -1,
                        ]  # 静态目标根据最早出现的位置进行排列
                        record_static_tids.add(tid)
                    # 动态目标 & 在动态帧数中
                    elif tid in dynamic_raw_track_ids and ts >= dobj_start_size:
                        frame_data[tid_map[tid]] = [dobj[:7], cls_mapping[c3], -1]
            data.append(frame_data)

        # 4. 构造state_polygon, state_polyline, state_poly_mask, state_property
        # polyline 和 poly_mask为固定值
        state_polyline = np.zeros((kwargs["history_state_size"], kwargs["polyline_size"], 2))
        state_poly_mask = np.zeros((kwargs["history_state_size"], 2))
        state_poly_mask[:, 0] = 1
        state_polygon = []
        state_property = []

        ego_polygon = []
        ego_property = []
        tids_all = []
        for ts, frame_data in enumerate(data[: kwargs["history_size"]]):
            tids, dobjs_full, main_cids = [], [], []

            # 其他agent
            for tid, (dobj, main_cid, _) in frame_data.items():
                if tid == ego_tid:
                    continue
                tids.append(tid)
                dobjs_full.append(dobj[:7])
                main_cids.append(main_cid)
                if tid not in tids_all:  ##记录15帧所有非自车的tid，后面有tid查找对齐objs
                    tids_all.append(tid)

            # 将自车放在每个时间patch的最后
            dobj, main_cid, _ = frame_data[ego_tid]
            tids.append(ego_tid)
            dobjs_full.append(dobj[:7])
            main_cids.append(main_cid)

            polygons = get_rotated_rectangle(np.array(dobjs_full))  # N x 4 x 2
            propertys = np.zeros((len(tids), kwargs["property_dim"]))
            propertys[:, 0] = main_cids
            propertys[:, 3] = tids
            propertys[:, 4] = ts

            # Add command information for ego vehicle (last entry in each timestamp)
            if commands is not None and ts < len(commands) and ts < history_size:
                # Encode command in property[5] for ego vehicle
                # command: 0=straight, 1=left, 2=right
                ego_idx = len(tids) - 1  # ego is always last
                propertys[ego_idx, 7] = commands[ts]

            propertys[:, 8] = 1 if np_plus_lcc_status else 0

            ego_polygon.append(polygons[-1])
            ego_property.append(propertys[-1])

            state_polygon.append(polygons)
            state_property.append(propertys)

        ego_polyline = np.zeros((kwargs["history_size"], kwargs["polyline_size"], 2))
        ego_poly_mask = np.zeros((kwargs["history_size"], 2))
        ego_poly_mask[:, 0] = 1

        ego_polygon = np.array(ego_polygon)
        ego_property = np.array(ego_property)

        state_polygon = np.concatenate(state_polygon, axis=0)
        state_property = np.concatenate(state_property, axis=0)

        # 5. pad
        assert len(state_polygon) == len(state_property) <= kwargs["ori_od_select_state_size"]
        if len(state_polygon) < kwargs["ori_od_select_state_size"]:
            pad_size = kwargs["ori_od_select_state_size"] - len(state_polygon)
            state_polygon = np.concatenate([np.zeros((pad_size, 4, 2)), state_polygon], axis=0)
            state_property = np.concatenate([np.zeros((pad_size, kwargs["property_dim"])), state_property], axis=0)
        select_raw_track_ids = {"static": static_raw_track_ids, "dynamic": dynamic_raw_track_ids}

        # sequence od compress
        od_comp = Plannn2Dataset.seq_od_token_gen(
            frame_agents,
            np_plus_lcc_status,
            kwargs["max_obj_token"],
            kwargs["polyline_size"],
            kwargs["history_size"],
            kwargs["property_dim"],
        )
        state_polygon_comp = od_comp["od_polygon_seq"]
        state_polyline_comp = od_comp["od_polyline_seq"]
        state_property_comp = od_comp["od_property_seq"]
        state_poly_mask_comp = od_comp["od_poly_mask_seq"]

        assert ego_polygon.shape[0] >= 15

        return (
            state_polygon,
            state_polyline,
            state_poly_mask,
            state_property,
            data,
            select_raw_track_ids,
            dobj_start_size,
            state_polygon_comp,
            state_polyline_comp,
            state_poly_mask_comp,
            state_property_comp,
            ego_polygon,
            ego_polyline,
            ego_property,
            ego_poly_mask,
        )

    @staticmethod
    def get_one_sample_closed(
        data,
        future_timestamps,
        sim_ts,
        sim_pose,
        ego_trans,
        ego_lane_change_command,
        np_plus_lcc_status,
        eval_mode=False,
        gt_mode=False,
        **kwargs,
    ):
        """
        Returns:
            polygon:  N x 4 x 2
            polyline: N x M x 2
            polymask: N x 2
            propertys: N x 5 cls1(大类), cls2(细分类), cls3(车道线color), tid, timestamp_id. pad_id统一为0
            env_length: N
            label: N 车和人的label组合在一起. 返回 None
        """
        ego_lane_change_command = ego_lane_change_command[sim_ts : kwargs["history_size"] + sim_ts]
        lane_change_signal = ego_lane_change_command[-1]
        ego_lane_change_command[:] = ego_lane_change_command[-1]
        if ego_trans is not None:
            data = Plannn2Dataset.align_to_new_ego_inplace(ego_trans, data, future_timestamps, kwargs["history_size"])

        # 计算最原始的原点，用于绘制静态信息和周车
        trajpose0 = data[future_timestamps[kwargs["history_size"] - 1]]["car_pose"]
        shift = np.eye(4, dtype=np.float32)
        shift[:3, 3] = [1.4, 0, 0]
        origin_pose0 = trajpose0 @ shift  # 自车位姿（自车坐标系）
        center = np.array([0, 0])
        origin_yaw = 0
        initpose0 = np.linalg.inv(origin_pose0)

        use_timestamps = future_timestamps[sim_ts : kwargs["history_size"] + sim_ts]
        if gt_mode:
            trajpose = data[future_timestamps[kwargs["history_size"] - 1 + sim_ts]]["car_pose"]
            origin_pose = trajpose @ shift
            initpose = np.linalg.inv(origin_pose)
        else:
            origin_pose = sim_pose  # pred at last t
            initpose = np.linalg.inv(origin_pose)

        # 动态物
        frame_agents, frame_agents_T0 = [], []
        frame_polygon, frame_polygon_T0 = [], []
        for i, ts in enumerate(use_timestamps):
            ego_pose_backwheel = initpose @ data[ts]["car_pose"]  # 自车相对位置
            if kwargs["static_scene"]:
                dobjs_full = np.empty((0, 12), dtype=np.float32)
            else:
                dobjs_full = parse_dynamicobj_v2(data[ts]["dynamic_dets"], ego_pose_backwheel)  # 转到世界坐标系中
            frame_agents.append([ego_pose_backwheel @ shift, dobjs_full])
            frame_polygon.append(get_rotated_rectangle(dobjs_full))

        vehspeeds = []
        if gt_mode:
            traj_draw_long = 20 + 1  # 多取些，用于每步轨迹的reward计算
            use_timestamps_reward = future_timestamps[sim_ts : kwargs["history_size"] + sim_ts + traj_draw_long]
            for i, ts in enumerate(use_timestamps_reward):
                # 转到T0下
                to_T0_pose = initpose0 @ data[ts]["car_pose"]
                if kwargs["static_scene"]:
                    dobjs_full = np.empty((0, 12), dtype=np.float32)
                else:
                    dobjs_full = parse_dynamicobj_v2(data[ts]["dynamic_dets"], to_T0_pose)
                frame_agents_T0.append([to_T0_pose @ shift, dobjs_full])
                frame_polygon_T0.append(get_rotated_rectangle(dobjs_full))

            # egomotion
            vehspeeds = []
            for i, ts in enumerate(use_timestamps_reward):
                egomotion = data[ts][
                    "ego_motion"
                ]  # vx, vy, acc_x, acc_y, yaw, yaw_rate, whlag, whlagspd, vehspd, lgta, chassis_yawrate
                vehspeed = egomotion[8] * 3.6
                vehspeeds.append(vehspeed)

        if not eval_mode:
            # 寻找离自车最近的点
            car_poses = [data[t]["car_pose"] for t in future_timestamps]
            car_poses = np.array(car_poses, dtype=np.float32)
            car_poses = car_poses @ shift  # 将原点坐标从自车后轴中心转移到车辆几何中心
            dxdy = car_poses[:, :2, 3] - sim_pose[:2, 3]
            dist = np.linalg.norm(dxdy, axis=1)
            static_idx = future_timestamps[np.argmin(dist)]
        else:
            # 使用当前帧
            sim_index = kwargs["history_size"] - 1 + sim_ts
            static_idx = future_timestamps[sim_index]

        # 静态物
        env_T = (initpose @ data[static_idx]["car_pose"]).astype(np.float32)  # ego 离 gt 最近的时间点
        (
            sobjs,
            god_polygon,
            road_sign,
            lane_lines,
            road_edge,
            nomap_road_edge,
            stop_line,
            _,
            spd_limit,
            navi_path,
            navi_infos,
            centerlines,
            nadsts,
            least_lc_dist,
            toll_gate_center_line,
            waitzones,
            egopath_stoplines,
            god_polygon_vis,
            road_edge_vis,
            manner_scene_info,
            link_info,
            priority_road_class,
            parked_vehicle,
        ) = Plannn2Dataset.parse_frame_env_v3(  # 红绿灯信息需要摘出来
            data[static_idx], env_T, center, origin_yaw, **kwargs
        )
        sobjs_polygon = get_rotated_rectangle(sobjs)
        tld = Plannn2Dataset.parse_frame_tld(data[use_timestamps[-1]])  # traffic light
        # 用于绘制的静态物信息
        env_T0 = (initpose0 @ data[static_idx]["car_pose"]).astype(np.float32)  # ego 离 gt 最近的时间点
        center_mat = np.array([0.0, 0.0, 0.0, 1.0], dtype=np.float32).reshape(4, 1)
        draw_center = ((env_T0 @ center_mat).squeeze())[:2]
        Rotate0 = env_T0[:3, :3]
        dir_mat = np.array([1.0, 0.0, 0.0]).reshape(3, 1)
        dir_trans = (Rotate0 @ dir_mat).squeeze()
        draw_yaw = np.arctan2(dir_trans[1], dir_trans[0])
        (
            sobjs0,
            god_polygon0,
            road_sign0,
            lane_lines0,
            road_edge0,
            nomap_road_edge0,
            stop_line0,
            _,
            spd_limit0,
            navi_path0,
            navi_infos0,
            centerlines0,
            nadsts0,
            least_lc_dist0,
            toll_gate_center_line0,
            waitzones0,
            egopath_stoplines0,
            god_polygon_vis0,
            road_edge_vis0,
            manner_scene_info0,
            link_info0,
            priority_road_class0,
            parked_vehicle0,
        ) = Plannn2Dataset.parse_frame_env_v3(  # 红绿灯信息需要摘出来
            data[static_idx], env_T0, draw_center, draw_yaw, **kwargs
        )
        sobjs_polygon0 = get_rotated_rectangle(sobjs0)
        if not np_plus_lcc_status and lane_change_signal == 0:
            # 变道command
            ego_lane_change_command, lane_change_signal = Plannn2Dataset.get_lane_change_command_closed(
                data, use_timestamps, initpose, lane_lines, kwargs["mode"], len(use_timestamps) - 1, 5
            )
        traj = [(initpose @ data[ts]["car_pose"])[:2, 3] for ts in use_timestamps]
        traj = np.array(traj)

        # 获取所有command
        commands, command_time_steps = Plannn2Dataset.get_all_commands(traj, lane_lines)
        turnlightsignal = dict([(ts, 0) for ts in use_timestamps])

        end_list = []
        for idx in range(len(commands)):
            c = commands[idx]
            cs = command_time_steps[idx]
            if idx == 0:
                start = 0 if (cs - 10) < 0 else cs - 10
                end = len(traj) - 1 if (cs + 10) > len(traj) - 1 else cs + 10
                end_list.append(end)
            else:
                start = 0 if (cs - 10) < 0 else cs - 10
                if start <= end_list[-1]:
                    start = command_time_steps[idx - 1] + (command_time_steps[idx] - command_time_steps[idx - 1]) // 2
                end = len(traj) - 1 if (cs + 10) > len(traj) - 1 else cs + 10
                end_list.append(end)

            for ts in use_timestamps[start : end + 1]:
                turnlightsignal[ts] = c
        # 原始环境信息放入dict
        raw_env = {
            "sobjs": sobjs0,
            "sobjs_polygon": sobjs_polygon0,
            "god_polygon": god_polygon0,
            "god_polygon_vis": god_polygon_vis0,
            "road_edge_vis": road_edge_vis0,
            "road_sign": road_sign0,
            "lane_lines": lane_lines0,
            "centerlines": centerlines0,
            "road_edge": road_edge0,
            "nomap_road_edge": nomap_road_edge0,
            "stop_line": stop_line0,
            "tld": tld,
            "navi_infos": navi_infos0,
            "navi_path": navi_path0,
            "spd_limit": spd_limit0,
            "dobjs_full": frame_agents,
            "dobjs_full_T0": frame_agents_T0,
            "dobjs_polygon": frame_polygon,
            "dobjs_polygon_T0": frame_polygon_T0,
            "origin_pose": origin_pose,
            "ego_trans": ego_trans,
            "nad_sts": nadsts0,
            "least_lc_dist": least_lc_dist0,
            "lane_change_signal": lane_change_signal,
            "toll_gate_center_line": toll_gate_center_line0,
            "waitzones": waitzones0,
            "egopath_stoplines": egopath_stoplines0,
            "np_plus_lcc_status": np_plus_lcc_status,
            "manner_scene_info": manner_scene_info0,
            "link_info": link_info0,
            "gt_vehspeeds": vehspeeds,
            "gt_unreliable": True if kwargs["static_scene"] else False,
            "uuid": data["uuid"] if "uuid" in data.keys() else None,
            "priority_road_class": priority_road_class0,
            "parked_vehicle": parked_vehicle0,
        }
        env_polygon, env_polyline, env_poly_mask, env_property, env_len = Plannn2Dataset.get_env(
            sobjs,
            sobjs_polygon,
            god_polygon,
            road_sign,
            lane_lines,
            road_edge,
            nomap_road_edge,
            stop_line,
            tld,
            spd_limit,
            navi_infos,
            center,
            **kwargs,
        )  # env_polygon: [360, 4, 2]

        try:
            waypoints = (
                interpolate_points(navi_path[:4, :2], step=0.5) if navi_path is not None else None
            )  # 约20m距离，每隔0.5m插值
        except ValueError as e:
            print(f"Error in interpolate_navipath points: {e}")
            waypoints = None
        (
            state_polygon,
            state_polyline,
            state_poly_mask,
            state_property,
            raw_dobjs,
            select_raw_tids,
            dobj_start_size,
            state_polygon_comp,
            state_polyline_comp,
            state_poly_mask_comp,
            state_property_comp,
            ego_polygon,
            ego_polyline,
            ego_property,
            ego_poly_mask,
        ) = Plannn2Dataset.get_state_closed(
            frame_agents,
            center,
            origin_yaw,
            waypoints,
            road_edge + nomap_road_edge,
            ego_lane_change_command,
            np_plus_lcc_status,
            **kwargs,
        )
        raw_env["select_raw_tids"] = select_raw_tids
        raw_env["dobj_start_size"] = dobj_start_size

        # normalize state
        env_polygon = env_polygon.astype(np.float32) / kwargs["state_range"]
        env_polyline = env_polyline.astype(np.float32) / kwargs["state_range"]
        env_polymask = env_poly_mask.astype(np.int64)
        env_propertys = env_property.astype(np.int64)

        state_polygon = state_polygon_comp.astype(np.float32) / kwargs["state_range"]
        state_polyline = state_polyline_comp.astype(np.float32) / kwargs["state_range"]
        state_polymask = state_poly_mask_comp.astype(np.int64)
        state_propertys = state_property_comp.astype(np.int64)

        ego_polygon = ego_polygon.astype(np.float32) / kwargs["state_range"]
        ego_polyline = ego_polyline.astype(np.float32) / kwargs["state_range"]
        ego_property = ego_property.astype(np.int64)
        ego_poly_mask = ego_poly_mask.astype(np.int64)
        # 临时fix code, nantonum，需要找到真正nan原因
        if (
            np.isnan(env_polygon).any()
            or np.isnan(env_polyline).any()
            or np.isnan(env_polymask).any()
            or np.isnan(env_propertys).any()
            or np.isnan(state_polygon).any()
            or np.isnan(state_polyline).any()
            or np.isnan(state_polymask).any()
            or np.isnan(state_propertys).any()
        ):
            print(f"Warning: NaN values found in data. Replacing with zeros.")
            env_polygon = np.nan_to_num(env_polygon, nan=0.0, posinf=0.0, neginf=0.0)
            env_polyline = np.nan_to_num(env_polyline, nan=0.0, posinf=0.0, neginf=0.0)
            env_polymask = np.nan_to_num(env_polymask, nan=0, posinf=0, neginf=0)
            env_propertys = np.nan_to_num(env_propertys, nan=0, posinf=0, neginf=0)

            state_polygon = np.nan_to_num(state_polygon, nan=0.0, posinf=0.0, neginf=0.0)
            state_polyline = np.nan_to_num(state_polyline, nan=0.0, posinf=0.0, neginf=0.0)
            state_polymask = np.nan_to_num(state_polymask, nan=0, posinf=0, neginf=0)
            state_propertys = np.nan_to_num(state_propertys, nan=0, posinf=0, neginf=0)

        assert (
            kwargs["env_block_size"] == len(env_polygon) == len(env_polyline) == len(env_polymask) == len(env_propertys)
        )

        assert (
            kwargs["max_obj_token"]
            == len(state_polygon)
            == len(state_polyline)
            == len(state_polymask)
            == len(state_propertys)
        )

        raw_env["turnlightsignal"] = turnlightsignal

        return (
            env_polygon,
            env_polyline,
            env_polymask,
            env_propertys,
            state_polygon,
            state_polyline,
            state_polymask,
            state_propertys,
            ego_polygon,
            ego_polyline,
            ego_poly_mask,
            ego_property,
            env_len,
            raw_env,
        )

    @staticmethod
    def prefetch_env_data(step, fnames):
        succ_count = 0
        for fname in fnames:
            result = _load_data(fname)
            succ_count += 1 if result is not None else 0
        return succ_count

    @staticmethod
    def get_env_closed(
        v3_ceph,
        use_timestamps,
        sim_ts,
        sim_pose,
        ego_trans,
        ego_lane_change_command,
        np_plus_lcc_status,
        eval_mode=False,
        gt_mode=False,
        **kwargs,
    ):
        data = _load_data(v3_ceph, kwargs.get("need_road_boundary", False))
        if kwargs.get("post_padding", False):
            sim_ts = min(sim_ts, len(use_timestamps) - kwargs["history_size"])
        items = Plannn2Dataset.get_one_sample_closed(
            data,
            use_timestamps,
            sim_ts,
            sim_pose,
            ego_trans,
            ego_lane_change_command,
            np_plus_lcc_status,
            eval_mode,
            gt_mode,
            **kwargs,
        )

        return items

    def make_mpo_data(self, meta_file):
        ## mpo-manned data are already inside training set.
        ## now we register manned and companion data uuids, and add companion dataset
        path_dict = meta_file["plannn2"]
        self.mpo_manned_uuids = set()
        mpo_companion_datalist = []
        if "mpo-manned_data" not in path_dict:
            return

        for _txt in path_dict["mpo-manned_data"]:
            with open(_txt, "r") as f:
                for _l in f:
                    self.mpo_manned_uuids.add(find_uuid(_l.strip(), md5_ok=True))

        for _txt in path_dict["mpo-comp_data"]:
            with open(_txt, "r") as f:
                for _l in f:
                    _l = _l.strip()
                    mpo_companion_datalist.append((True, _l))

        _data_list = self.data_list
        self.data_list = mpo_companion_datalist
        self.build_data_length_index()
        self.mpo_companion_data = {find_uuid(_path, md5_ok=True): _path for _, _path, _ in self.data_list}
        self.data_list = _data_list


if __name__ == "__main__":

    planner_data_meta_file = {
        "plannn2": {
            "train": [
                "/share-global/runlin.he/plannn2/case_set/test3_case_v3_1.txt",  # pylint: disable=line-too-long  # noqa: E501
            ],
            "test": [
                "/share-global/xiangwei.geng/plannn2/data/0827/test1000_case_v3_1_new.txt",  # pylint: disable=line-too-long  # noqa: E501
            ],
            "cicd_train": [
                "/share-global/xiangwei.geng/plannn2/data/0827/test1000_case_v3_1_new.txt",  # pylint: disable=line-too-long  # noqa: E501
            ],
            "cicd_test": [
                "/share-global/xiangwei.geng/plannn2/data/0827/test1000_case_v3_1_new.txt",  # pylint: disable=line-too-long  # noqa: E501
            ],
        }
    }
    template_set_file = "/data-algorithm-hl/junxuan.chen/work/plannn2/data/template_set/v2.5/5fps_50w_768.npy"
    frame_downsample = 1
    item_mini_batch = 4
    timestamp_size = 40
    history_state_size = 800
    env_block_size = 380
    history_size = 15
    polyline_size = 4
    use_quantized_state = True
    navi_path_dropout = 1
    use_aebhighrisk = True

    dataset = Plannn2Dataset(
        planner_data_meta_file,
        template_set_file,
        frame_downsample,
        item_mini_batch,
        timestamp_size,
        history_state_size,
        env_block_size,
        history_size,
        mode="pretrain",
        polyline_size=polyline_size,
        use_quantized_state=use_quantized_state,
        navi_path_dropout=navi_path_dropout,
        tp_mode="train",
    )

    from torchpilot.data.dataloader.multitask_dataloader import MultiTaskDataLoader
    from torchpilot.data.sampler.tp_distributed_sampler import TPDistributedSampler
    from torchpilot.utils.registries import DATALOADER
    from torchpilot.utils.registries import DATASET

    dataset_cfg = dict(
        type=Plannn2Dataset,
        meta_file=planner_data_meta_file,
        tempalte_set=template_set_file,
        frame_downsample=frame_downsample,
        item_mini_batch=item_mini_batch,
        timestamp_size=timestamp_size,
        history_state_size=history_state_size,
        env_block_size=env_block_size,
        history_size=history_size,
        mode="pretrain",
        polyline_size=polyline_size,
        use_quantized_state=use_quantized_state,
        navi_path_dropout=navi_path_dropout,
        use_aebhighrisk=use_aebhighrisk,
        tp_mode="train",
        vis_polygon=False,
    )

    dataloader = dict(
        type=MultiTaskDataLoader,
        dataset_cfg=dataset_cfg,
        sampler_cfg=dict(
            type=TPDistributedSampler,
            shuffle=True,
            seed=0,
            drop_last=True,
        ),
        batch_size=2,
        seed=0,
        num_workers=1,
        pin_memory=True,
        prefetch_factor=1,
        persistent_workers=True,
        drop_last=True,
        to_cuda=True,
    )
    torch.distributed.init_process_group(
        backend="nccl",
        init_method="tcp://localhost:9998",
        world_size=1,
        rank=0,
    )
    torch.cuda.empty_cache()
    dataset = DATASET.build(dataset_cfg)
    dataloader = DATALOADER.build(dataloader)

    for data in dataloader:
        print(data)
        break
