# -*- coding: utf-8 -*-
"""MultiTask dataset for planner."""
import logging
import random
from typing import Any
from typing import Dict
from typing import List

from torch.utils.data._utils.collate import default_collate
from torchpilot.data.dataset.multitask_dataset import MultiTaskDataset


logger = logging.getLogger(__name__)


class PlannerMultiTaskDataset(MultiTaskDataset):
    """PlannerMultiTaskDataset."""

    def batch_collate(self, data: List[Any]) -> Dict[str, Dict[str, Any]]:  # pylint: disable=arguments-differ
        """Collate function for current dataset.

        Args:
            data (List[Dict[str, Dict[str, Any]]]): List of map-style data. Each item is
                dict, each dict is (task_name, task_data_dict) pairs.

        Returns:
            Dict[str, Dict[str, Any]] each item is (task_name, task_batched_data_dict).
        """
        data_dict = {}
        for task_name in data[0].keys():
            collate_func = getattr(self._task_datasets[task_name], "batch_collate", default_collate)
            data_dict[task_name] = collate_func(  # type: ignore[misc]
                [onemodel_data[task_name] for onemodel_data in data]
            )

        # Add task_name key in task_batch.
        for task_name, task_batched_data in data_dict.items():
            task_batched_data["task_name"] = task_name
        return data_dict

    def __getitem__(  # type: ignore[override]
        self,
        index: Dict[str, Any],
    ) -> Dict[str, Dict[str, Any]]:
        """Get one item.

        Args:
            idx (Dict[str, int]): The {task_name, index} pairs.

        Returns:
            {task_name, task_data_dict} pairs.
        """
        # For pythonic.
        if self._fetch_until_success:
            data_dict: Dict[str, Dict[str, Any]] = {}
            for task_name, task_idx in index.items():
                get_item_success = False
                task_dataset = self._task_datasets[task_name]
                while not get_item_success:
                    try:
                        data_dict[task_name] = task_dataset[task_idx % self._len_datasets[task_name]]
                        get_item_success = True
                    except Exception as ex:  # pylint: disable=broad-except
                        ex_message = ex.args[0] if len(ex.args) > 0 else ""
                        logger.warning(
                            "%s get item idx %d failed, try to get next one. " "Error message: %s",
                            task_name,
                            task_idx,
                            ex_message,
                        )
                        task_idx = random.randint(0, self._len_datasets_each_rank[task_name])
                        continue
            return data_dict

        return {
            task_name: self._task_datasets[task_name][task_idx % self._len_datasets[task_name]]
            for task_name, task_idx in index.items()
        }
