# -*- coding: utf-8 -*-
"""Dataset of Astra Planner."""

import hashlib
import json
import math
import os
import pickle
from typing import Any
from typing import Dict
from typing import List

import cv2
import niofs
import numpy as np
import torch

# from read_cache_op_py import read_cache_batch_op_py
from read_cache_op_py import read_cache_op_py
from torchpilot import logger
from torchpilot.data.dataset.base_dataset import BaseDataset
from torchpilot.utils.mmap_list import MmapSerializedList
from tqdm import tqdm

from tpp_onemodel.tools.astra_planner.data.data_utils.astra_planner_frame_data import (
    get_head_tail_points,
)
from tpp_onemodel.tools.astra_planner.data.data_utils.astra_planner_frame_data import (
    is_lane_on_left_or_right,
)


ceph_client = niofs.Client("81fbac8cd8abdee5", "1c46fdaf88a24f35b7f68289e6e236ce")


def get_ceph_size(ceph_path):
    """Get ceph size."""
    try:
        bucket_name, path = ceph_path[1:].split("/", 1)
        response_info = ceph_client.head_object(Bucket=bucket_name, Key=path)
        size = response_info["ContentLength"]
    except Exception:
        size = -1
    return size


def contains_nan_or_inf(data):
    """Check data has nan or inf."""
    if isinstance(data, (int, float)):
        return math.isnan(data) or math.isinf(data)
    elif isinstance(data, np.ndarray):
        return np.isnan(data).any() or np.isinf(data).any()
    elif isinstance(data, torch.Tensor):
        return torch.isnan(data).any().item() or torch.isinf(data).any().item()
    elif isinstance(data, list):
        return any(contains_nan_or_inf(item) for item in data)
    elif isinstance(data, dict):
        return any(contains_nan_or_inf(value) for value in data.values())
    return False


class AstraPlannerDataset(BaseDataset):
    """Astra planner dataset."""

    all_meta_data: Dict[Any, Any] = {}

    DYNAMIC_DETS_SHAPE = 40

    def __init__(
        self,
        mode: str,
        meta_file=None,
        transforms=None,
        window=None,
        interval=1,
        task_name="astra_planner",
        history_meta_key=["dynamic_dets"],
        current_meta_key=[
            "dynamic_dets",
            "dynamic_gods",
            "static_dets",
            "tsrs",
            "tld",
            "meta",
            "lane",
            "manner_lane",
            "navi_line",
            "sdmap",
            "atlas",
            "atlas_bev",
            "decisions",
            "crop_images",
            "crop_lidar",
            "gt_bboxes",
            "car_pose",
        ],
        future_meta_key=["meta"],
        load_tags=False,
        clip_padding_length=0,
        tld_data_aug=False,
        stop_data_aug=False,
        select_scenes=["LaneKeep"],
        scene_tag_to_id={
            "Learnable_LK": 0,
            "LaneKeep": 1,
            # "LeftChange": 2,
            # "RightChange": 3,
            "LeftTurn": 4,
            "RightTurn": 5,
            # "IGNORE": 6,
        },
        future_meta_frame_num=0,
        load_wb=False,
        wb_version=None,
        zero_shot_aug_enable=False,
        zero_shot_aug_state=None,
        all_task_names: List = [],
        **kwargs,
    ):
        """Init."""
        super().__init__(mode=mode, meta_file=meta_file, transforms=transforms, **kwargs)

        self.interval = interval
        self.load_tags = load_tags
        self.clip_padding_length = clip_padding_length
        if window is None:
            self.window = list(range(-15, 35))
        else:
            self.window = window
        self._task_name = task_name
        self.window_size = max(self.window) - min(self.window) + 1
        self.current_frame_index = self.window.index(0)
        self.select_scenes = select_scenes
        self.tld_data_aug = tld_data_aug
        self.stop_data_aug = stop_data_aug

        self.all_task_names: list = all_task_names

        self.meta_path_list = self._meta_file[self._task_name][self._mode]
        (
            self.clip_meta_path,
            self.data,
            self.tags_path,
            self.scene_type_list,
            self.clip_task_mask_lst,
        ) = self._load_meta_data()

        self.history_meta_key = history_meta_key
        self.current_meta_key = current_meta_key
        self.future_meta_key = future_meta_key

        self.scene_tag_to_id = scene_tag_to_id
        self._future_meta_frame_num = future_meta_frame_num
        self.load_wb = load_wb
        self.wb_version = wb_version
        self.zero_shot_aug_enable = zero_shot_aug_enable
        self.zero_shot_aug_state = zero_shot_aug_state

    def _load_meta_data(self):
        """
        Load meta data.

        Clip_meta_path is the path of the clip meta file.
        Data is the list of data. Each element is a tuple (clip_idx, window_id).
        """
        meta_path_list_str = json.dumps(self.meta_path_list)
        meta_path_list_md5 = hashlib.md5(meta_path_list_str.encode()).hexdigest()  # noqa: S303
        if meta_path_list_md5 in self.all_meta_data:
            logger.info("Load meta data from cache.")
            return self.all_meta_data[meta_path_list_md5]

        meta_data = []

        # TODO(charlie.cheng1): move this code into 'data-filter'
        clip_task_mask_lst = []
        for mp in self.meta_path_list:
            sample_task_mask = np.zeros(len(self.all_task_names), dtype=np.float32)
            if isinstance(mp, str):
                fp = mp
                sample_task_mask += 1
            else:
                assert isinstance(mp, (list, tuple)), "check meta-file config"
                fp, task_names = mp[0], mp[1]
                for task_name in task_names:
                    assert (
                        task_name in self.all_task_names
                    ), f"task-name '{task_name}' unpported, must be one of {self.all_task_names}"
                    task_id = self.all_task_names.index(task_name)
                    sample_task_mask[task_id] = 1

            with open(fp, "rb") as f:
                data_lst = pickle.load(f)
                meta_data.extend(data_lst)
                clip_task_mask_lst.extend([sample_task_mask] * len(data_lst))
                logger.warning("data %s loaded", fp)

            logger.warning("meta '%s' sample-task-mask %s", fp, str(sample_task_mask))

        clip_meta_path = []
        data_cwp_pair = []
        tags_path = []
        scene_type_list = []

        logger.warning("Loading meta data")
        for idx, data in tqdm(enumerate(meta_data)):
            meta_ceph_path = data["meta_ceph_path"]
            if meta_ceph_path.startswith("huailai_cos:"):
                meta_ceph_path = "/" + meta_ceph_path[len("huailai_cos:") :]
            else:
                raise NotImplementedError(f"Unknown prefix: {meta_ceph_path}")
            clip_meta_path.append(meta_ceph_path)

            tag_ceph_path = data["tag_ceph_path"]
            if tag_ceph_path is not None:
                if tag_ceph_path.startswith("huailai_cos:"):
                    tag_ceph_path = "/" + tag_ceph_path[len("huailai_cos:") :]
                else:
                    raise NotImplementedError(f"Unknown prefix: {tag_ceph_path}")
            tags_path.append(tag_ceph_path)

            data_length = data["frame_num"]
            if "selected_frame_idx" in data and data["selected_frame_idx"] is not None:
                data_list = data["selected_frame_idx"]
            else:
                data_list = list(range(data_length))

            scene_types = data["extra"]["scene"]

            windows_ids_clip, padding_lengths_clip = self.generate_data_pair(data_list, data_length)

            data_cwp_pair.extend([(idx, w_id, pad_l) for w_id, pad_l in zip(windows_ids_clip, padding_lengths_clip)])

            scene_type_list += [scene_types[frame_idx] for frame_idx in data_list]

        logger.warning("Meta data loaded")

        mmap_clip_meta_path = MmapSerializedList(clip_meta_path, "clip_meta_path.pkl")
        mmap_data = MmapSerializedList(data_cwp_pair[:: self.interval], "tags_path.pkl")
        mmap_tags_path = MmapSerializedList(tags_path, "scene_type_list.pkl")
        mmap_scene_type_list = MmapSerializedList(scene_type_list[:: self.interval], "data.pkl")
        mmap_clip_task_mask_list = MmapSerializedList(clip_task_mask_lst, "clip_task_mask_list.pkl")

        self.all_meta_data[meta_path_list_md5] = (
            mmap_clip_meta_path,
            mmap_data,
            mmap_tags_path,
            mmap_scene_type_list,
            mmap_clip_task_mask_list,
        )
        return self.all_meta_data[meta_path_list_md5]

    def generate_data_pair(self, data_list, data_length):
        """Generate data pair."""
        windows_ids = []
        padding_lengths = []
        for cur_idx in data_list:
            window_id = cur_idx - self.current_frame_index
            if window_id < 0 or window_id + self.window_size > (data_length + self.clip_padding_length):
                continue
            windows_ids.append(window_id)
            padding_length_tmp = window_id + self.window_size - data_length
            padding_lengths.append(0 if padding_length_tmp <= 0 else padding_length_tmp)

        return windows_ids, padding_lengths

    def _get_window_data(self, clip_idx, window_id, pad_length, scene_type, sample_task_mask):
        """Get window data."""
        clip_meta_path = self.clip_meta_path[clip_idx]
        clip_meta = pickle.loads(read_cache_op_py([clip_meta_path])[0])
        clip_frame_num = len(clip_meta.get("timestamp_list", []))

        history_ceph_path = self._format_ceph_path(
            clip_meta_path,
            clip_meta,
            self.history_meta_key,
            range_list=list(range(window_id, window_id + self.current_frame_index)),
            time_key="history",
        )
        current_ceph_path = self._format_ceph_path(
            clip_meta_path,
            clip_meta,
            self.current_meta_key,
            range_list=[window_id + self.current_frame_index],
            time_key="current",
        )
        future_ceph_path = self._format_ceph_path(
            clip_meta_path,
            clip_meta,
            self.future_meta_key,
            range_list=[window_id + i for i in range(self.current_frame_index + 1, self.window_size - pad_length)],
            time_key="future",
        )

        future_all_meta_ceph_path = None
        if self._future_meta_frame_num > 0:
            future_all_meta_ceph_path = self._format_ceph_path(
                clip_meta_path,
                clip_meta,
                ["meta"],
                range_list=[
                    window_id + i
                    for i in range(
                        self.current_frame_index + 1,
                        min(self.current_frame_index + self._future_meta_frame_num + 1, clip_frame_num - window_id),
                    )
                ],
            )

        window_data = self._load_ceph_data(
            history_ceph_path, current_ceph_path, future_ceph_path, future_all_meta_ceph_path
        )

        if pad_length > 0:
            window_data["future"] = window_data["future"][:-pad_length] + [None for _ in range(pad_length)]
        window_meta_data = self._load_window_meta_data(
            clip_idx, clip_meta, window_id, scene_type, future_all_len=len(future_all_meta_ceph_path)
        )

        for temp in ["history", "current", "future"]:
            window_data[temp] = list(
                map(
                    self.parse_frame_data,
                    window_data[temp],
                    window_meta_data[temp],
                    [scene_type] * len(window_data[temp]),
                )
            )
            window_data[temp] = list(map(lambda wd, wd_mt: {**wd, **wd_mt}, window_data[temp], window_meta_data[temp]))
        if "future-all-meta" in window_data:
            for idx, temp in enumerate(window_data["future-all-meta"]):
                window_meta = window_meta_data["future_all"][idx]
                window_data["future-all-meta"][idx]["timestamps"] = window_meta["timestamps"]

        wb_data = None
        if self.load_wb:
            if self.wb_version is not None:
                wb_ceph_path = self.get_wb_ceph_path(clip_meta_path)
                wb_data = json.loads(read_cache_op_py([wb_ceph_path])[0]) if wb_ceph_path else None

        window_data["current"][0]["wb_data"] = wb_data
        window_data["current"][0]["sample_task_mask"] = sample_task_mask

        return window_data

    def get_wb_ceph_path(self, clip_meta_path):
        """Get wb ceph path."""
        subclip_id = clip_meta_path.split("/")[4]
        json_niofs_path = (
            "huailai_cos:ad-cn-hlidc-multimodal/planning/planning_data/whitebox_tags_json/"
            + f"{self.wb_version}/{subclip_id}.json"
        )
        json_ceph_path = "/" + json_niofs_path[len("huailai_cos:") :]
        json_ceph_size = get_ceph_size(json_ceph_path)
        if json_ceph_size > 0:
            wb_ceph_path = f"{json_ceph_path} {json_ceph_size}"
        else:
            wb_ceph_path = None
        return wb_ceph_path

    def _load_window_meta_data(self, clip_idx, clip_meta, window_id, scene_type="null", future_all_len=60):
        """Load window meta data."""
        if self.load_tags:
            tags_ceph_path = self.tags_path[clip_idx]
            tags = None
            if tags_ceph_path is not None:
                tags = pickle.loads(read_cache_op_py([tags_ceph_path])[0])

        window_meta_data = {"history": [], "current": [], "future": [], "future_all": []}
        target_window_size = future_all_len + self.current_frame_index + 1
        window_size = self.window_size if self.window_size >= target_window_size else target_window_size
        timestamps = clip_meta.get("timestamp_list", [])[window_id : window_id + window_size]

        for idx in range(window_size):
            if idx < self.current_frame_index:
                temp_key = "history"
            elif idx == self.current_frame_index:
                temp_key = "current"
            else:
                temp_key = "future_all"
            frame_meta_dict = {}
            frame_meta_dict.update({"timestamps": timestamps[idx] if idx < len(timestamps) else 0})

            # for align with the old version, but it is not necessary.
            frame_meta_dict.update({"scene_type": scene_type if idx < len(timestamps) else "pad"})
            frame_meta_dict.update({"ids": f"{self._task_name}_{idx + window_id}" if idx < len(timestamps) else "null"})
            frame_meta_dict.update({"gt": np.empty((0, 19))})  # 19 is a constant used in the old version.
            if self.load_tags:
                tag_key = str(int(frame_meta_dict["timestamps"]))
                tag_obj = tags.get(tag_key, {"objs": []}) if tags and (tag_key in tags) else {"objs": []}
                if "objs" in tag_obj:
                    frame_tag = [_["cate"] for _ in tag_obj["objs"]]
                elif "tag" in tag_obj:
                    frame_tag = tag_obj["tag"]
                else:
                    frame_tag = []
                frame_meta_dict.update({"tags": frame_tag})

            ##############################################
            if temp_key == "future_all" and idx < self.window_size:
                window_meta_data["future"].append(frame_meta_dict)
            window_meta_data[temp_key].append(frame_meta_dict)

        return window_meta_data

    def _load_ceph_data(
        self,
        his_ceph_path,
        cur_ceph_path,
        fut_ceph_path,
        future_all_meta_ceph_path=None,
    ):
        """Load ceph data."""
        all_keys = []
        all_ceph_path = []

        def append_ceph_paths(prefix, ceph_path_dict, all_keys, all_ceph_path):
            """Append ceph paths."""
            for key, value in ceph_path_dict.items():
                all_keys.append(f"{prefix}_{key}")
                all_ceph_path.append(value)

        all_ceph_path = []
        all_keys = []

        append_ceph_paths("history", his_ceph_path, all_keys, all_ceph_path)
        append_ceph_paths("current", cur_ceph_path, all_keys, all_ceph_path)
        append_ceph_paths("future", fut_ceph_path, all_keys, all_ceph_path)
        if future_all_meta_ceph_path:
            append_ceph_paths("future-all-meta", future_all_meta_ceph_path, all_keys, all_ceph_path)

        ceph_data = self.read_cache_op_py_merge_seq(all_ceph_path)

        hist_data = [{sensor: None for sensor in self.history_meta_key} for _ in range(self.current_frame_index)]
        curr_data = [{sensor: None for sensor in self.current_meta_key}]
        fut_data = [
            {sensor: None for sensor in self.future_meta_key}
            for _ in range(self.window_size - self.current_frame_index - 1)
        ]
        fut_all_meta_data = (
            [{sensor: None for sensor in ["meta"]} for _ in range(len(future_all_meta_ceph_path.keys()))]
            if self._future_meta_frame_num > 0
            else None
        )
        data = {"history": hist_data, "current": curr_data, "future": fut_data, "future-all-meta": fut_all_meta_data}

        for key, val in zip(all_keys, ceph_data):
            temporal_range = key.split("_")[0]
            sensor = "_".join(key.split("_")[1:-1])
            idx = int(key.split("_")[-1])

            data[temporal_range][idx][sensor] = pickle.loads(val)
        return data

    def read_cache_op_py_merge_seq(self, all_ceph_path):
        """Read cache op py merge seq."""
        merged_ceph_path = self.merge_ceph_path(all_ceph_path)
        merged_ceph_data = read_cache_batch_op_py(merged_ceph_path)
        merged_ceph_path_dict = {
            ceph_path.split(" ")[0]: {"offset": int(ceph_path.split(" ")[2]), "ceph_data": ceph_data}
            for ceph_path, ceph_data in zip(merged_ceph_path, merged_ceph_data)
        }
        all_ceph_data = []
        for ceph_path in all_ceph_path:
            file_name = ceph_path.split(" ")[0]
            offset = int(ceph_path.split(" ")[2])
            window_size = int(ceph_path.split(" ")[3])
            rel_offset = offset - merged_ceph_path_dict[file_name]["offset"]
            all_ceph_data.append(merged_ceph_path_dict[file_name]["ceph_data"][rel_offset : rel_offset + window_size])

        return all_ceph_data

    def merge_ceph_path(self, all_ceph_path):
        """Merge ceph path."""
        merged_ceph_path = []
        all_file_dict = {
            file_name: {"file_size": None, "start_index": None, "end_index": None}
            for file_name in {ceph_path.split(" ")[0] for ceph_path in all_ceph_path}
        }
        for file_path in all_ceph_path:
            file_name, file_size, offset, window_size = file_path.split(" ")
            end_index = int(offset) + int(window_size)
            all_file_dict[file_name]["file_size"] = file_size
            if all_file_dict[file_name]["start_index"] is None or all_file_dict[file_name]["start_index"] > int(offset):
                all_file_dict[file_name]["start_index"] = int(offset)
            if all_file_dict[file_name]["end_index"] is None or all_file_dict[file_name]["end_index"] < end_index:
                all_file_dict[file_name]["end_index"] = end_index
        merged_ceph_path = [
            f"{file_name} {file_dict['file_size']} {file_dict['start_index']} "
            + f"{file_dict['end_index'] - file_dict['start_index']}"
            for file_name, file_dict in all_file_dict.items()
        ]

        return merged_ceph_path

    def _format_ceph_path(self, clip_meta_path, clip_meta, meta_key=None, range_list=None, time_key="history"):
        """Format ceph path."""
        ceph_path_root = os.path.dirname(os.path.dirname(clip_meta_path.split(":")[-1].lstrip("/")))
        if range_list is None:
            range_list = list(range(0, len(clip_meta.get("timestamp_list", []))))

        frame_ceph_path = {}

        if meta_key is None:
            meta_key = clip_meta["annos"].keys()
        for sensor in meta_key:
            if time_key == "current":
                frame_ceph_path_tmp = {
                    "path": [f"/{ceph_path_root}/all.dat" for _ in range_list],
                    "size": [clip_meta["cephpath_filesize"]["all"] for _ in range_list],  # right
                    "offset": [
                        clip_meta["annos_by_ts"][clip_meta["timestamp_list"][idx]][sensor][0] for idx in range_list
                    ],
                    "window_size": [
                        clip_meta["annos_by_ts"][clip_meta["timestamp_list"][idx]][sensor][1] for idx in range_list
                    ],
                }
            else:
                frame_ceph_path_tmp = {
                    "path": [f"/{ceph_path_root}/{sensor}.dat" for _ in range_list],
                    "size": [clip_meta["cephpath_filesize"][sensor] for _ in range_list],
                    "offset": [clip_meta["annos"][sensor][idx][0] for idx in range_list],
                    "window_size": [clip_meta["annos"][sensor][idx][1] for idx in range_list],
                }
            for idx, (path, size, offset, window_size) in enumerate(
                zip(
                    frame_ceph_path_tmp["path"],
                    frame_ceph_path_tmp["size"],
                    frame_ceph_path_tmp["offset"],
                    frame_ceph_path_tmp["window_size"],
                )
            ):
                frame_ceph_path[f"{sensor}_{idx}"] = f"{path} {size} {offset} {window_size}"
        return frame_ceph_path

    def _format_data(self, window_data):
        """Format data. This is a placeholder function for possible format change. For now, it just returns the data."""
        return window_data

    def _parse_scene_type(self, idx, data_input):
        scene_type = self.scene_type_list[idx]
        data_input["current"]["scene_type"] = scene_type
        data_input["current"]["scene_id"] = self.scene_tag_to_id[scene_type]
        return data_input

    def __getitem__(self, idx):
        """Get one data item."""
        clip_idx = self.data[idx][0]
        window_id = self.data[idx][1]
        pad_length = self.data[idx][2]
        scene_type = self.scene_type_list[idx]
        sample_task_mask = self.clip_task_mask_lst[clip_idx]
        window_data = self._get_window_data(clip_idx, window_id, pad_length, scene_type, sample_task_mask)

        data_input = self._format_data(window_data)

        if self._transforms is not None:
            data_input = self._transforms(data_input)
        data_input = self._parse_scene_type(idx, data_input)

        if contains_nan_or_inf(data_input):
            raise ValueError(f"find anormaly value (nan or inf). subclip {data_input['current']['subclip_ids'][0]}.")
        return data_input

    def __len__(self):
        """Return the size of the dataset."""
        return len(self.data)

    def parse_frame_data(self, data, meta_data, scene_type):
        """Parse frame data."""
        frame_anno_info = {}

        if data is None:
            frame_anno_info["dynamic_dets"] = np.zeros((0, self.DYNAMIC_DETS_SHAPE))
            frame_anno_info["car_poses"] = np.eye(4)
            frame_anno_info["ego_motion"] = np.zeros(12)  # TODO[stephen.wang]: using hardcode here.
            frame_anno_info["scene_type"] = "pad"
            frame_anno_info["ids"] = "null"
            frame_anno_info["aligned_trajectory"] = None
            return frame_anno_info
        for sensor in data:
            info_bytes = data[sensor]
            if sensor == "lane":
                frame_anno_info["lane_points"] = self._parse_nested_list(
                    info_bytes["lane_points"], info_bytes["lane_points_shape"]
                )
                frame_anno_info["lane_types"] = self._parse_bytes_from_buffer(
                    info_bytes["lane_types"], info_bytes["lane_types_shape"]
                )
            elif sensor == "navi_line":
                # (6x11x2)
                frame_anno_info["navi_line_points"] = np.array(
                    self._parse_nested_list(info_bytes["navi_line_points"], info_bytes["navi_line_points_shape"]),
                    dtype=object,
                )
                # (6x3)
                frame_anno_info["navi_lane_tld"] = np.array(
                    self._parse_nested_list(
                        info_bytes["navi_lane_tld"], info_bytes["navi_lane_tld_shape"], dtype=np.int32
                    ),
                    dtype=object,
                )
                frame_anno_info["navi_lane_stoppoints"] = np.array(
                    self._parse_nested_list(
                        info_bytes["navi_lane_stoppoints"], info_bytes["navi_lane_stoppoints_shape"]
                    ),
                    dtype=object,
                )
                # 6
                frame_anno_info["navi_line_types"] = 4 * np.ones(
                    len(frame_anno_info["navi_line_points"]), dtype=np.float32
                )
                # 6x1x3
                frame_anno_info["navi_lane_speed_limit"] = np.array(
                    self._parse_nested_list(
                        info_bytes["navi_lane_speed_limit"], info_bytes["navi_lane_speed_limit_shape"]
                    ),
                    dtype=object,
                )
                navi_line_types, naviline_type_indices = self._parse_naviline_types(
                    frame_anno_info["navi_line_points"], scene_type
                )
                frame_anno_info["navi_line_types"] = navi_line_types
            elif sensor == "navi_path":
                frame_anno_info["navi_path_points"] = np.array(
                    self._parse_nested_list(info_bytes["navi_path_points"], info_bytes["navi_path_points_shape"])
                )
                if len(frame_anno_info["navi_path_points"]) == 0 or len(frame_anno_info["navi_path_points"][0]) == 0:
                    frame_anno_info["navi_path_types"] = [np.zeros((1, 30, 2), dtype=np.float32)]
                    frame_anno_info["navi_path_types"] = -1 * np.ones(
                        len(frame_anno_info["navi_path_points"]), dtype=np.float32
                    )
                    frame_anno_info["navi_path_tld"] = np.array([0, 0, 65535], dtype=np.int32).reshape(1, 3)
                    frame_anno_info["navi_path_stoppoints"] = np.array([1000, 0], dtype=np.float32).reshape(1, 1, 2)
                    frame_anno_info["navi_path_speed_limit"] = np.array([120, 0, 120], dtype=np.float32).reshape(
                        1, 1, 3
                    )
                else:
                    frame_anno_info["navi_path_types"] = 5 * np.ones(
                        len(frame_anno_info["navi_path_points"]), dtype=np.float32
                    )

                    navi_path_tld_info = np.array(
                        self._parse_nested_list(
                            info_bytes["navi_path_tld"], info_bytes["navi_path_tld_shape"], dtype=np.int32
                        ),
                    )

                    if (
                        navi_path_tld_info.shape[-1] >= 5
                        and len(navi_path_tld_info) >= 1
                        and navi_path_tld_info[0][0] == 2
                    ):
                        if (
                            navi_path_tld_info[0][0] == 2  # yellow
                            and navi_path_tld_info[0][1] == 0  # not blink
                            and navi_path_tld_info[0][2] == 65535  # no countdown
                            and navi_path_tld_info[0][3] == 1  # valid
                        ):
                            navi_path_tld_info[0][2] = min(max(0, int(4 - navi_path_tld_info[0][4] / 1000)), 3)
                            # print("new yellow countdown:", navi_path_tld_info[0][2], navi_path_tld_info[0][4])

                    frame_anno_info["navi_path_tld"] = navi_path_tld_info[:, :3]

                    frame_anno_info["navi_path_stoppoints"] = np.array(
                        self._parse_nested_list(
                            info_bytes["navi_path_stoppoints"], info_bytes["navi_path_stoppoints_shape"]
                        ),
                    )
                    frame_anno_info["navi_path_speed_limit"] = np.array(
                        self._parse_nested_list(
                            info_bytes["navi_path_speed_limit"], info_bytes["navi_path_speed_limit_shape"]
                        )
                    )
            elif sensor == "sdmap":
                frame_anno_info["sdmap_geo"] = self._parse_nested_list(info_bytes["sdmap"], info_bytes["sdmap_shape"])
                frame_anno_info["sd_link_ids"] = self._parse_bytes_from_buffer(
                    info_bytes["sd_link_ids"],
                    info_bytes["sd_link_ids_shape"],
                    dtype=np.uint64,
                )
            elif sensor == "atlas":
                frame_anno_info["atlas"] = {
                    "main_ground": self._parse_nested_list(
                        info_bytes["atlas"]["main_ground"],
                        info_bytes["atlas"]["main_ground_shape"],
                    ),
                    "foreground": self._parse_nested_list(
                        info_bytes["atlas"]["foreground"],
                        info_bytes["atlas"]["foreground_shape"],
                    ),
                    "unsafe_area": self._parse_nested_list(
                        info_bytes["atlas"]["unsafe_area"],
                        info_bytes["atlas"]["unsafe_area_shape"],
                    ),
                }
            elif sensor == "atlas_bev":
                frame_anno_info["atlas_bev"] = self._parse_bytes_from_buffer(
                    info_bytes["atlas_bev"],
                    info_bytes["atlas_bev_shape"],
                    dtype=np.uint8,
                )
            elif sensor == "static_polys":
                frame_anno_info["static_polys"] = np.frombuffer(
                    info_bytes["static_polys"]["points"], dtype=np.float32
                ).reshape(-1, 2)
                frame_anno_info["static_poly_split"] = info_bytes["static_polys"]["counts"]

            elif sensor == "static_dets":
                frame_anno_info[sensor] = self._parse_bytes_from_buffer(
                    info_bytes[sensor], info_bytes[f"{sensor}_shape"]
                )
                frame_anno_info["static_polys"] = np.frombuffer(
                    info_bytes["static_polys"]["points"], dtype=np.float32
                ).reshape(-1, 2)
                frame_anno_info["static_poly_split"] = info_bytes["static_polys"]["counts"]
            elif sensor == "dynamic_gods":
                frame_anno_info[sensor] = self._parse_bytes_from_buffer(
                    info_bytes[sensor], info_bytes[f"{sensor}_shape"]
                )
                frame_anno_info["dynamic_gods_polys"] = np.frombuffer(
                    info_bytes["dynamic_gods_polys"]["points"], dtype=np.float32
                ).reshape(-1, 2)
                frame_anno_info["dynamic_gods_polys_split"] = info_bytes["dynamic_gods_polys"]["counts"]

            elif sensor == "meta":
                frame_anno_info["car_poses"] = self._parse_bytes_from_buffer(info_bytes["car_pose"], (4, 4))
                frame_anno_info["ego_motion"] = self._parse_bytes_from_buffer(
                    info_bytes["ego_motion"], (12,)
                )  # vx,vy,acc_x,acc_y,yaw[2],yaw_rate[2],whlag,whlagspd,vehspd,lgta,chassis_yawrate
                frame_anno_info["ego_box"] = info_bytes["ego_box"]
                frame_anno_info["ego_gears_raw"] = frame_anno_info["ego_motion"][-1:]
                frame_anno_info["agent_label"] = info_bytes.get("agent_label", None)

                # TODO[stephen.wang]: backup for next version.
                subclip_id = info_bytes["subclip_id"]
                frame_anno_info["subclip_ids"] = subclip_id
                aligned_trajectory = None
                if "aligned_trajectory" in info_bytes:
                    aligned_trajectory = self._parse_bytes_from_buffer(info_bytes["aligned_trajectory"], (-1, 3))
                    if len(aligned_trajectory) == 0:
                        aligned_trajectory = None
                frame_anno_info["aligned_trajectory"] = aligned_trajectory
            elif sensor == "car_pose":
                frame_anno_info["delta_ts_carpose"] = {
                    "road_detection": self._parse_bytes_from_buffer(
                        info_bytes["car_pose_per_topic"]["road_detection"]["car_pose"], (4, 4)
                    ),
                    "atlas": self._parse_bytes_from_buffer(
                        info_bytes["car_pose_per_topic"]["atlas"]["car_pose"], (4, 4)
                    ),
                    "road_post": self._parse_bytes_from_buffer(
                        info_bytes["car_pose_per_topic"]["road_post"]["car_pose"], (4, 4)
                    ),
                }
            elif sensor == "crop_images":
                if "crop_images" not in info_bytes.keys() or len(info_bytes["crop_images"]) == 0:
                    frame_anno_info["crop_images"] = np.zeros((frame_anno_info["dynamic_dets"].shape[0], 64 * 64 * 3))
                else:
                    frame_anno_info["crop_images"] = self._parse_crop_images_list(info_bytes["crop_images"])
            elif sensor == "manner_lane":
                frame_anno_info["manner_lane_points"] = self._parse_nested_list(
                    info_bytes["manner_lane_points"], info_bytes["manner_lane_points_shape"]
                )
                frame_anno_info["manner_lane_types"] = self._parse_bytes_from_buffer(
                    info_bytes["manner_lane_types"], info_bytes["manner_lane_types_shape"]
                )
                if "manner_lane_attr" in info_bytes:
                    frame_anno_info["manner_lane_attr"] = self._parse_nested_list(
                        info_bytes["manner_lane_attr"], info_bytes["manner_lane_attr_shape"], np.int16
                    )
            elif sensor == "dynamic_dets":
                frame_anno_info["dynamic_dets"] = self._parse_bytes_from_buffer(
                    info_bytes[sensor], info_bytes[f"{sensor}_shape"]
                )
                frame_anno_info["dynamic_dets"] = frame_anno_info["dynamic_dets"][:, : self.DYNAMIC_DETS_SHAPE]
            elif sensor == "agent_prediction":
                agent_prediction = self._parse_bytes_from_buffer(info_bytes[sensor], info_bytes[f"{sensor}_shape"])
                frame_anno_info[sensor] = agent_prediction[:, :51]
                frame_anno_info["priority_type"] = agent_prediction[:, 51:52]
            else:
                try:
                    frame_anno_info[sensor] = self._parse_bytes_from_buffer(
                        info_bytes[sensor], info_bytes[f"{sensor}_shape"]
                    )
                except Exception:
                    logger.warning("Unknown sensor type: %s", sensor)
        return frame_anno_info

    def add_scene_tag(self, frame_data):
        """Add scene tag to frame data based on timestamp."""
        # get timestamp from middle of future frame
        future_frame_data = frame_data["future"][(self.window_size - self.current_frame_index - 1) // 2]
        if future_frame_data["tags"][0] == "null":
            frame_data["current"][0]["scene_id"] = -1
            return frame_data

        subclip_id = future_frame_data["subclip_ids"]
        # change subclip id format
        ts1, ts2 = subclip_id.split("_")[-2:]
        subclip_id = subclip_id.replace(ts1, f"{float(ts1):.6f}").replace(ts2, f"{float(ts2):.6f}")
        timestamp = future_frame_data["timestamps"]

        if subclip_id not in self.scene_tag_infos:
            frame_data["current"][0]["scene_id"] = -1
            return frame_data

        # add scene tag
        scene_id = -1
        for scene_name in self.select_scenes:
            clip_scene_info = self.scene_tag_infos[subclip_id].get(scene_name, [])
            for ts in clip_scene_info:
                st = float(ts["start_ts"])
                et = float(ts["end_ts"])
                if timestamp >= st and timestamp <= et:
                    scene_id = self.scene_tag_to_id[scene_name]

        frame_data["current"][0]["scene_id"] = scene_id
        return frame_data

    @staticmethod
    def _parse_bytes_from_buffer(bytes, shape, dtype=np.float32):
        """Parse bytes from buffer."""
        return np.frombuffer(bytes, dtype=dtype).reshape(shape)

    def _parse_nested_list(self, data_list, shapes, dtype=np.float32):
        """Parse nested list."""
        return [self._parse_bytes_from_buffer(data_list[i], shapes[i], dtype) for i in range(len(data_list))]

    def _parse_crop_images_list(self, crop_images_list, dtype=np.float32):
        """Parse crop images list."""
        parsed_list = []
        for crop_img_byte in crop_images_list:
            if crop_img_byte is not None:
                crop_img_raw = np.frombuffer(crop_img_byte, dtype=np.uint8)
                crop_img = cv2.imdecode(crop_img_raw, cv2.IMREAD_COLOR).reshape(-1)
            else:
                crop_img = np.zeros((64 * 64 * 3))
            parsed_list.append(crop_img)
        return np.array(parsed_list, dtype=dtype) / 255.0

    def get_ego_navi_dist(self, navi_line_points):
        """Get ego navi dist."""
        navi_line_points_diff = navi_line_points[1:] - navi_line_points[:-1]
        navi_line_points_diff = np.concatenate((navi_line_points_diff, navi_line_points_diff[-1:]))
        ego = np.array([[0, 0]])
        ego_navilane_diff = ego - navi_line_points
        distances = np.linalg.norm(navi_line_points, axis=-1)
        nearest_point_indices = distances.argmin()
        match_indeices = [nearest_point_indices]
        if nearest_point_indices > 0:
            match_indeices.append(nearest_point_indices - 1)
        dist_l_min = 1e6
        for idx in match_indeices:
            if idx >= len(navi_line_points_diff):
                continue
            u = navi_line_points_diff[idx]
            v = ego_navilane_diff[idx]
            dist_l = v[0] * u[1] - v[1] * u[0]
            dist_l = abs(dist_l / np.linalg.norm(u))
            dist_l_min = dist_l if dist_l < dist_l_min else dist_l_min
        return dist_l_min

    def _parse_lk_navilanes(self, navi_line_points):
        dist_l = np.zeros(len(navi_line_points))
        for idx, navi_line_point in enumerate(navi_line_points):
            dist_l[idx] = self.get_ego_navi_dist(navi_line_point)
        lk_indices = []
        if len(dist_l) > 0:
            min_idx = dist_l.argmin()
            if dist_l[min_idx] < 1.5:
                lk_indices = [min_idx]

        return lk_indices

    def _parse_lt_navilanes(self, navilanes, scene_type):
        lt_indices, rt_indices = [], []
        for idx, lane_points in enumerate(navilanes):
            if len(lane_points) < 2:
                continue
            head_points, tail_points = get_head_tail_points(lane_points)
            if len(head_points) == 0 or len(tail_points) == 0:
                continue
            head_angle = np.arctan2(head_points[1][1] - head_points[0][1], head_points[1][0] - head_points[0][0])
            tail_angle = np.arctan2(tail_points[1][1] - tail_points[0][1], tail_points[1][0] - tail_points[0][0])
            if scene_type not in ["LT", "RT"]:
                if tail_angle - head_angle > math.pi * (60 / 180) and tail_angle - head_angle < math.pi * (120 / 180):
                    lt_indices.append(idx)
                elif tail_angle - head_angle < math.pi * (-60 / 180) and tail_angle - head_angle > math.pi * (
                    -120 / 180
                ):
                    rt_indices.append(idx)
                elif tail_angle - head_angle > math.pi * (120 / 180) or tail_angle - head_angle < math.pi * (
                    -120 / 180
                ):
                    head_to_tail_points = np.array(
                        [tail_points[1][0] - head_points[0][0], tail_points[1][1] - head_points[0][1]],
                    )
                    head_to_tail_angle = np.arctan2(
                        head_to_tail_points[1] - head_points[0][1], head_to_tail_points[0] - head_points[0][0]
                    )
                    if head_to_tail_angle > 0:
                        lt_indices.append(idx)
                    else:
                        rt_indices.append(idx)
            else:
                if tail_angle - head_angle > math.pi * (30 / 180) and tail_angle - head_angle < math.pi * (120 / 180):
                    lt_indices.append(idx)
                elif tail_angle - head_angle < math.pi * (-30 / 180) and tail_angle - head_angle > math.pi * (
                    -120 / 180
                ):
                    rt_indices.append(idx)
                elif tail_angle - head_angle > math.pi * (120 / 180) or tail_angle - head_angle < math.pi * (
                    -120 / 180
                ):
                    head_to_tail_points = np.array(
                        [tail_points[1][0] - head_points[0][0], tail_points[1][1] - head_points[0][1]],
                    )
                    head_to_tail_angle = np.arctan2(
                        head_to_tail_points[1] - head_points[0][1], head_to_tail_points[0] - head_points[0][0]
                    )
                    if head_to_tail_angle > 0:
                        lt_indices.append(idx)
                    else:
                        rt_indices.append(idx)
        return lt_indices, rt_indices

    def _parse_lc_navilane(self, navilanes, lk_navilane_index, lt_navilane_index, rt_navilane_index):
        lc_indices, rc_indices = [], []
        not_lc_navilane_index = lk_navilane_index + lt_navilane_index + rt_navilane_index
        for idx, lane_points in enumerate(navilanes):
            if idx in not_lc_navilane_index:
                continue
            flag = is_lane_on_left_or_right((0, 0), lane_points)
            if flag == "left":
                lc_indices.append(idx)
            elif flag == "right":
                rc_indices.append(idx)
        return lc_indices, rc_indices

    def _parse_naviline_types(self, navi_line_points, scene_type):
        navi_line_points = [naviline.astype("float") for naviline in navi_line_points]
        lk_navilane_index = self._parse_lk_navilanes(navi_line_points)
        lt_navilane_index, rt_navilane_index = self._parse_lt_navilanes(navi_line_points, scene_type)
        lc_navilane_index, rc_navilane_index = self._parse_lc_navilane(
            navi_line_points,
            lk_navilane_index,
            lt_navilane_index,
            rt_navilane_index,
        )
        navi_line_types = 4 * np.ones(len(navi_line_points), dtype=np.float32)

        naviline_type_indices = {}
        naviline_type_indices["LK"] = lk_navilane_index
        naviline_type_indices["LT"] = lt_navilane_index
        naviline_type_indices["RT"] = rt_navilane_index
        naviline_type_indices["LC"] = lc_navilane_index
        naviline_type_indices["RC"] = rc_navilane_index

        if len(lt_navilane_index) + len(rt_navilane_index) > 0:
            navi_line_types[lk_navilane_index] = -1
            lk_navilane_index = []

        navi_line_types[lk_navilane_index] = 0
        navi_line_types[lt_navilane_index] = 1
        navi_line_types[rt_navilane_index] = 2
        navi_line_types[lc_navilane_index] = 0
        navi_line_types[rc_navilane_index] = 0
        return navi_line_types, naviline_type_indices

    def batch_collate(self, data):
        """Collate batch."""
        batch_ids = [data_entry["current"]["ids"][0] for data_entry in data]

        batch_current_bboxes = [data_entry["current"]["bboxes"] for data_entry in data]

        batch_carposes = np.stack(
            [
                np.vstack(
                    [
                        data_entry["history"]["car_poses"],
                        data_entry["current"]["car_poses"],
                    ]
                )
                for data_entry in data
            ],
            axis=0,
        ).astype(
            np.float32
        )  # B, T, 4, 4

        eye_matrix = np.eye(4)[None]
        batch_hist2curr_trans = np.stack(
            [
                np.vstack(
                    [
                        data_entry["history"]["hist2curr_trans"],  # T-1, 4, 4
                        eye_matrix,  # 1, 4, 4
                    ]
                )
                for data_entry in data
            ],
            axis=0,
        ).astype(
            np.float32
        )  # B, T, 4, 4

        batch_future2curr_trans = np.stack(
            [
                np.vstack(
                    [
                        data_entry["future"]["hist2curr_trans"],  # T-1, 4, 4
                        eye_matrix,  # 1, 4, 4
                    ]
                )
                for data_entry in data
            ],
            axis=0,
        ).astype(
            np.float32
        )  # B, T, 4, 4

        subclip_ids = [data_entry["current"]["subclip_ids"][0] for data_entry in data]
        batch_items = {
            "update_subtasks": [data_entry["update_subtasks"] for data_entry in data],
            "subclip_ids": subclip_ids,
            "car_poses": torch.from_numpy(batch_carposes),
            "hist2curr_trans": torch.from_numpy(batch_hist2curr_trans),
            "future2curr_trans": torch.from_numpy(batch_future2curr_trans),
            "ids": batch_ids,
            # od gt for current frame
            "4dgt_bboxes": batch_current_bboxes,
        }

        # stamp related inputs
        ego_box_feat_dims = (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14)
        batch_egos = np.stack(
            [
                np.vstack(
                    [
                        data_entry["history"]["egos"][..., ego_box_feat_dims],  # [T-1, D]
                        data_entry["current"]["egos"][..., ego_box_feat_dims],  # [1, D]
                    ]
                )
                for data_entry in data
            ]
        ).astype(np.float32)[
            :,
            :,
            np.newaxis,
        ]  # [B, T, 1, D]
        batch_egos_delta_v = np.stack(
            [
                np.concatenate(
                    [
                        data_entry["history"]["egos_delta_v"],  # [T-1, D]
                        data_entry["current"]["egos_delta_v"],  # [1, D]
                    ]
                )
                for data_entry in data
            ]
        ).astype(np.float32)[
            :,
            :,
            np.newaxis,
        ]  # [B, T, 1, D]
        batch_egos_padding_mask = np.stack(
            [
                data_entry["history"]["egos_padding_mask"] + data_entry["current"]["egos_padding_mask"]
                for data_entry in data
            ]
        ).astype(np.float32)[
            :,
            :,
            np.newaxis,
        ]  # [B, T, 1]

        batch_bboxes = np.stack(
            [
                np.vstack(
                    [
                        data_entry["history"]["dynamic_dets"],  # T-1, n_t, D
                        data_entry["current"]["dynamic_dets"],  # 1, n_t, D
                    ]
                )
                for data_entry in data
            ]
        ).astype(
            np.float32
        )  # [B, T, n_t, D]
        batch_bboxes_track_id = np.stack(
            [
                np.vstack(
                    [
                        data_entry["history"]["dynamic_dets"][..., 9],  # T-1, n_t
                        data_entry["current"]["dynamic_dets"][..., 9],  # 1, n_t
                    ]
                )
                for data_entry in data
            ]
        ).astype(np.float32)
        batch_bboxes_padding_mask = np.stack(
            [
                np.vstack(
                    [
                        data_entry["history"]["dynamic_dets_padding_mask"],  # T-1, n_t
                        data_entry["current"]["dynamic_dets_padding_mask"],  # 1, n_t
                    ]
                )
                for data_entry in data
            ],
        ).astype(
            np.float32
        )  # [B, T, n_t]

        batch_ego_trackable_agent_gt = np.stack([data_entry["ego_trackable_agent_gt"] for data_entry in data]).astype(
            np.float32
        )  # [B, n_t]

        batch_ego_trackable_agent_gt_mask = np.stack(
            [data_entry["ego_trackable_agent_gt_mask"] for data_entry in data],
        ).astype(
            np.float32
        )  # [B, n_t]

        # batch_asso_index = np.stack([data_entry["current"]["asso_index"] for data_entry in data])  # [B, 191, T]

        batch_ts = np.vstack(
            [
                np.array(
                    data_entry["history"]["timestamps"] + data_entry["current"]["timestamps"],
                    dtype=np.float64,
                )
                for data_entry in data
            ]
        )  # B, T
        batch_delta_ts = (batch_ts[:, -1:] - batch_ts).astype(np.float32)

        batch_ts_all = np.vstack(
            [
                np.concatenate(
                    [
                        data_entry["history"]["timestamps"],
                        data_entry["current"]["timestamps"],
                        data_entry["future"]["timestamps"],
                    ]
                )
                for data_entry in data
            ]
        )
        batch_delta_ts_all = (batch_ts_all - batch_ts_all[:, 14:15]).astype(np.float32)
        batch_scene_type = [data_entry["current"]["scene_type"] for data_entry in data]
        batch_select_scene_idx = []
        for scene_type in batch_scene_type:
            if scene_type in self.select_scenes:
                batch_select_scene_idx.append(self.select_scenes.index(scene_type))
            else:
                batch_select_scene_idx.append(-1)
        batch_items.update(
            {
                "bboxes": torch.from_numpy(batch_bboxes),
                "bboxes_padding_mask": torch.from_numpy(batch_bboxes_padding_mask),
                "bboxes_track_id": torch.from_numpy(batch_bboxes_track_id),
                # "asso_index": torch.from_numpy(batch_asso_index),
                "delta_timestamp": torch.from_numpy(batch_delta_ts),
                "timestamp": batch_ts,
                "timestamp_all": batch_ts_all,
                "delta_timestamp_all": torch.from_numpy(batch_delta_ts_all),
                "egos": torch.from_numpy(np.concatenate([batch_egos, batch_egos_delta_v[..., np.newaxis]], axis=-1)),
                "egos_padding_mask": torch.from_numpy(batch_egos_padding_mask),
                "navilane_scene_type": batch_scene_type,
                "navilane_scene_idx": torch.tensor(batch_select_scene_idx),  # use index in select_scenes not tag-id
                # "trajectory_scene_type": batch_trajectory_scene_type,
                "ego_trackable_agent_gt": torch.tensor(batch_ego_trackable_agent_gt),
                "ego_trackable_agent_gt_mask": torch.tensor(batch_ego_trackable_agent_gt_mask),
            }
        )
        if "bev_feature_occ_driving" in data[0]["current"]:
            batch_bev_occ_driving = np.vstack(
                [[data_entry["current"]["bev_feature_occ_driving"]] for data_entry in data]
            )
            batch_items.update(
                {
                    "bev_feature_occ_driving": torch.from_numpy(batch_bev_occ_driving),
                }
            )
        if "bev_feature_static" in data[0]["current"]:
            batch_bev_static = np.vstack([[data_entry["current"]["bev_feature_static"]] for data_entry in data])
            batch_items.update(
                {
                    "bev_feature_static": torch.from_numpy(batch_bev_static),
                }
            )

        if "agent_decision_label" in data[0]["current"]:
            batch_agent_decision_label = np.vstack(
                [data_entry["current"]["agent_decision_label"] for data_entry in data]
            )
            batch_agent_decision_mask = np.vstack([data_entry["current"]["agent_decision_mask"] for data_entry in data])
            batch_items.update(
                {
                    "agent_decision_label": torch.from_numpy(batch_agent_decision_label),
                    "agent_decision_mask": torch.from_numpy(batch_agent_decision_mask),
                }
            )

        if "tags" in data[0]["current"]:
            batch_tags = [data_entry["current"]["tags"][0] for data_entry in data]
            batch_items.update({"tags": batch_tags})
        else:
            batch_items.update({"tags": [[] for _ in data]})

        if "sod_poly_boxes" in data[0]["current"]:
            batch_sod_poly_boxes = np.stack(
                [data_entry["current"]["sod_poly_boxes"] for data_entry in data]  # 1, n_t, D
            ).astype(np.float32)
            batch_sod_poly_boxes_padding_mask = np.stack(
                [data_entry["current"]["sod_poly_boxes_padding_mask"] for data_entry in data]  # 1, n_t
            ).astype(np.float32)
            batch_sod_poly_pts = np.stack(
                [data_entry["current"]["sod_poly_pts"] for data_entry in data]  # 1, n_t, D
            ).astype(np.float32)
            batch_sod_poly_pts_padding_mask = np.stack(
                [data_entry["current"]["sod_poly_pts_padding_mask"] for data_entry in data]  # 1, n_t
            ).astype(np.float32)

            batch_items.update(
                {
                    "sod_poly_boxes": torch.from_numpy(batch_sod_poly_boxes),
                    "sod_poly_boxes_padding_mask": torch.from_numpy(batch_sod_poly_boxes_padding_mask),
                    "sod_poly_pts": torch.from_numpy(batch_sod_poly_pts),
                    "sod_poly_pts_padding_mask": torch.from_numpy(batch_sod_poly_pts_padding_mask),
                }
            )

        if "god_poly_pts" in data[0]["current"]:
            batch_god_poly = np.stack([data_entry["current"]["god_poly_pts"] for data_entry in data])
            batch_god_poly_padding_mask = np.stack(
                [data_entry["current"]["god_poly_pts_padding_mask"] for data_entry in data]
            )
            batch_god_attrs = np.stack([data_entry["current"]["god_attrs"] for data_entry in data])
            batch_god_attr_padding_mask = np.stack(
                [data_entry["current"]["god_attr_padding_mask"] for data_entry in data]
            )
            batch_items.update(
                {
                    "god_poly_pts": torch.from_numpy(batch_god_poly),
                    "god_poly_pts_padding_mask": torch.from_numpy(batch_god_poly_padding_mask),
                    "god_attrs": torch.from_numpy(batch_god_attrs),
                    "god_attr_padding_mask": torch.from_numpy(batch_god_attr_padding_mask),
                }
            )

        if "crop_images" in data[0]["current"]:
            batch_crop_imgs = np.stack(
                [
                    np.vstack(
                        [
                            data_entry["current"]["crop_images"],  # 1, n_t, 64*64*3
                        ]
                    )
                    for data_entry in data
                ]
            ).astype(
                np.float32
            )  # [B, 1, n_t, 64*64*3]
            batch_items["crop_imgs"] = torch.from_numpy(batch_crop_imgs)

        if "tld" in data[0]["current"]:
            batch_tld = np.stack([data_entry["current"]["tld"] for data_entry in data]).astype(np.float32)
            batch_tld_padding_mask = np.stack(
                [data_entry["current"]["tld_padding_mask"] for data_entry in data]
            ).astype(np.float32)
            batch_items.update(
                {
                    "tld": torch.from_numpy(batch_tld),
                    "tld_padding_mask": torch.from_numpy(batch_tld_padding_mask),
                }
            )

        batch_dets_pred_gt = np.stack(
            [data_entry["current"]["dynamic_dets_pred_gt"] for data_entry in data]
        )  # [48, 191, 30, 2]
        batch_dets_pred_mask = np.stack(
            [data_entry["current"]["dynamic_dets_pred_mask"] for data_entry in data]
        )  # [48, 191, 30]
        batch_det_pred_info_gt = np.stack(
            [data_entry["current"]["dynamic_dets_pred_full_info_gt"] for data_entry in data]
        )
        batch_dets_pred_gt_transformed = np.stack(
            [data_entry["trans"]["bboxes_pred_gt"] for data_entry in data]
        ).squeeze(1)
        bboxes_det_pred_full_info_gt_transformed = np.stack(
            [data_entry["trans"]["bboxes_det_pred_full_info_gt"] for data_entry in data]
        ).squeeze(1)
        batch_items.update(
            {
                "bboxes_pred_gt": torch.from_numpy(batch_dets_pred_gt.astype(np.float32)),
                "bboxes_pred_mask": torch.from_numpy(batch_dets_pred_mask.astype(np.float32)),
                "bboxes_det_pred_full_info_gt": torch.from_numpy(batch_det_pred_info_gt),
                "bboxes_pred_gt_transformed": torch.from_numpy(batch_dets_pred_gt_transformed.astype(np.float32)),
                "bboxes_det_pred_full_info_gt_transformed": torch.from_numpy(
                    bboxes_det_pred_full_info_gt_transformed.astype(np.float32)
                ),
            }
        )

        if "egos_pred_gt" in data[0]["current"]:
            batch_egos_pred_gt = np.stack(
                [data_entry["current"]["egos_pred_gt"] for data_entry in data]
            )  # [48, 1, 30, 2]
            batch_egos_pred_gt_transformed = np.stack([data_entry["trans"]["egos_pred_gt"] for data_entry in data])[
                :, 0
            ]  # [B,1,T,2]
            batch_egos_yaw_gt_transformed = np.stack([data_entry["trans"]["egos_heading_gt"] for data_entry in data])[
                :, 0
            ]
            batch_egos_pred_mask = np.stack(
                [data_entry["current"]["egos_pred_mask"] for data_entry in data]
            )  # [48, 1, 30, 2]
            batch_egos_pred_mask_transformed = np.stack([data_entry["trans"]["egos_pred_mask"] for data_entry in data])[
                :, 0
            ]  # [B,1,T]

            batch_egos_yaw_gt = np.stack(
                [data_entry["current"]["egos_yaw_pred_gt"] for data_entry in data]
            )  # [batch, 1, future_horizon, 1]
            batch_items.update(
                {
                    "egos_pred_gt": torch.from_numpy(batch_egos_pred_gt.astype(np.float32)),
                    "egos_pred_mask": torch.from_numpy(batch_egos_pred_mask.astype(np.float32)),
                    "egos_pred_gt_transformed": torch.from_numpy(batch_egos_pred_gt_transformed.astype(np.float32)),
                    "egos_pred_yaw_gt_transformed": torch.from_numpy(batch_egos_yaw_gt_transformed.astype(np.float32)),
                    "egos_pred_mask_transformed": torch.from_numpy(batch_egos_pred_mask_transformed.astype(np.float32)),
                    "egos_yaw_pred_gt": torch.from_numpy(batch_egos_yaw_gt.astype(np.float32)),
                }
            )

        if "dets_vel_pred_gt" in data[0]["current"]:
            batch_dets_vel_pred_gt = np.stack([data_entry["current"]["dets_vel_pred_gt"] for data_entry in data])
            batch_dets_vel_pred_mask = np.stack([data_entry["current"]["dets_vel_pred_mask"] for data_entry in data])

            batch_items.update(
                {
                    "bboxes_vel_pred_gt": torch.from_numpy(batch_dets_vel_pred_gt.astype(np.float32)),
                    "bboxes_vel_pred_mask": torch.from_numpy(batch_dets_vel_pred_mask.astype(np.float32)),
                }
            )

        if "aligned_trajectory" in data[0]["current"]:
            batch_aligned_trajectory = []
            for data_entry in data:
                if data_entry["current"]["aligned_trajectory"][0] is None:
                    batch_aligned_trajectory.append(None)
                else:
                    batch_aligned_trajectory.append(torch.tensor(data_entry["current"]["aligned_trajectory"][0]))
            batch_items.update({"aligned_trajectory": batch_aligned_trajectory})

        if "ego_vel_pred_gt" in data[0]["current"]:
            batch_ego_vel_pred_gt = np.stack([data_entry["current"]["ego_vel_pred_gt"] for data_entry in data])
            batch_ego_vel_pred_gt_transformed = np.stack(
                [data_entry["trans"]["ego_vel_pred_gt"] for data_entry in data]
            )[
                :, 0
            ]  # [B,T,2]

            batch_items.update(
                {
                    "ego_vel_pred_gt": torch.from_numpy(batch_ego_vel_pred_gt.astype(np.float32)),
                    "ego_vel_pred_gt_transformed": torch.from_numpy(
                        batch_ego_vel_pred_gt_transformed.astype(np.float32)
                    ),
                }
            )

        if "ego_steering_wheel_pred_gt" in data[0]["current"]:
            batch_ego_steering_wheel_pred_gt = np.stack(
                [data_entry["current"]["ego_steering_wheel_pred_gt"] for data_entry in data]
            )

            batch_items.update(
                {
                    "ego_steering_wheel_pred_gt": torch.from_numpy(batch_ego_steering_wheel_pred_gt.astype(np.float32)),
                }
            )

        if "ego_acc_pred_gt" in data[0]["current"]:
            batch_ego_acc_pred_gt = np.stack([data_entry["current"]["ego_acc_pred_gt"] for data_entry in data])

            batch_items.update(
                {
                    "ego_acc_pred_gt": torch.from_numpy(batch_ego_acc_pred_gt.astype(np.float32)),
                }
            )

        if "ego_yaw_rate_pred_gt" in data[0]["current"]:
            batch_ego_yaw_rate_pred_gt = np.stack(
                [data_entry["current"]["ego_yaw_rate_pred_gt"] for data_entry in data]
            )

            batch_items.update(
                {
                    "ego_yaw_rate_pred_gt": torch.from_numpy(batch_ego_yaw_rate_pred_gt.astype(np.float32)),
                }
            )

        if "priority_gt" in data[0]["current"]:
            batch_priority_gt = np.stack([data_entry["current"]["priority_gt"] for data_entry in data])
            batch_items.update(
                {
                    "priority_gt": torch.from_numpy(batch_priority_gt),
                }
            )

        if "lane_points" in data[0]["current"]:
            batch_lane_points = np.stack(
                [data_entry["current"]["lane_points"] for data_entry in data]
            )  # [48, 191, 30, 2]
            batch_lane_types = np.stack([data_entry["current"]["lane_types"] for data_entry in data])  # [48, 191, 30]
            batch_lane_attr = np.stack([data_entry["current"]["lane_attr"] for data_entry in data])
            batch_items.update(
                {
                    "lane_points": torch.from_numpy(batch_lane_points),
                    "lane_types": torch.from_numpy(batch_lane_types),
                    "lane_attr": torch.from_numpy(batch_lane_attr),
                }
            )

        # group atlas batch
        if "atlas" in data[0]["current"]:
            if "atlas_in_polar" in data[0]["current"]:
                nmax_pts = max([batch["current"]["atlas_in_polar"].shape[1] for batch in data])
                max_plg = max([batch["current"]["atlas_in_polar"].shape[0] for batch in data])
                polygons_all = []
                for batch in data:
                    polygons = batch["current"]["atlas_in_polar"]
                    polygons_all.append(
                        np.pad(
                            polygons,
                            (
                                (0, max_plg - polygons.shape[0]),
                                (0, nmax_pts - polygons.shape[1]),
                                (0, 0),
                            ),
                            mode="constant",
                            constant_values=-1,
                        )
                    )
                batch_items.update(
                    {
                        "atlas": torch.from_numpy(np.stack(polygons_all, axis=0)),
                    }
                )
            else:
                batch_atlas_polygons = np.stack(
                    [data_entry["current"]["atlas_polygons"] for data_entry in data]
                )  # (b, nplg, npts, 2)
                batch_atlas_type = np.stack(
                    [data_entry["current"]["atlas_polygons_type"] for data_entry in data]
                )  # (b, nplg, npts, type_dim)
                batch_atlas = np.concatenate([batch_atlas_polygons, batch_atlas_type], axis=-1)
                batch_items.update({"atlas": torch.from_numpy(batch_atlas)})
        else:
            batch_items.update({"atlas": torch.zeros([len(data), 50, 30, 3])})

        if "atlas_bev" in data[0]["current"]:
            batch_atla_bev = np.stack([data_entry["current"]["atlas_bev_cls"] for data_entry in data])
            batch_items.update(
                {
                    "atlas": torch.from_numpy(batch_atla_bev.astype(np.float32)),
                }
            )

        # group sdmap polylines
        if "sdmap_polylines" in data[0]["current"]:
            batch_sdmap_polylines = np.stack(
                [data_entry["current"]["sdmap_polylines"] for data_entry in data]
            )  # (b, npl, bpts, 2)
            batch_sdmap_polylines_padding_mask = np.stack(
                [data_entry["current"]["sdmap_polylines_type"] for data_entry in data]
            )  # (b, npl, bpts)
            batch_items.update(
                {
                    "sdmap_polylines": torch.from_numpy(batch_sdmap_polylines),
                    "sdmap_polylines_type": torch.from_numpy(batch_sdmap_polylines_padding_mask),
                }
            )

        # process adas_info
        if "adas_info" in data[0]["current"]:
            speed_lmt_batch = []
            navi_info_batch = []
            map_loc_batch = []
            road_class_batch = []
            lanenr_info_batch = []
            adasmap_valid_batch = []
            adasmap_is_on_highway = []
            for data_entry in data:
                if data_entry["current"]["adas_info"][0]["adas_info"].shape[0] > 0:
                    # process adas_info part
                    adasmap_valid_batch.append(data_entry["current"]["adas_info"][0]["adas_info"][0].astype(np.float32))
                    adasmap_is_on_highway.append(
                        data_entry["current"]["adas_info"][0]["adas_info"][1].astype(np.float32)
                    )
                else:
                    adasmap_valid_batch.append(0)
                    adasmap_is_on_highway.append(0)

                if len(data_entry["current"]["adas_info"][0]["navi_info"]) > 0:
                    # process navi info
                    current_navi_info = data_entry["current"]["adas_info"][0]["navi_info"]
                    tbt = current_navi_info[0][:4]
                    road_class = current_navi_info[0][-1:]
                    lanenr_info = current_navi_info[0][4:-1]
                    if len(lanenr_info) > 2:
                        assert "laner_info length is more than 2"

                    tbt_info_np = np.array(tbt)
                    road_class_np = np.array(road_class)

                    adas_segment = current_navi_info[1]
                    speed_lmt_np = np.zeros([8])
                    speed_lmt_cnt = np.zeros([8])
                    if adas_segment.shape[0] > 0:
                        for i in range(adas_segment.shape[0]):
                            acc_speed = speed_lmt_np[adas_segment[i, 1]] * speed_lmt_cnt[adas_segment[i, 1]]
                            speed_lmt_cnt[adas_segment[i, 1]] += 1
                            speed_lmt_np[adas_segment[i, 1]] = (acc_speed + (adas_segment[i, 0] / 3.6)) / speed_lmt_cnt[
                                adas_segment[i, 1]
                            ]
                    else:
                        speed_lmt_np = np.zeros([8])
                    navi_info_batch.append(tbt_info_np)
                    road_class_batch.append(road_class_np)
                    # lanenr_info_batch.append(lanenr_info_np)
                    speed_lmt_batch.append(speed_lmt_np)
                else:
                    speed_lmt_batch.append(np.zeros((8)))
                    navi_info_batch.append(np.zeros((4,)))
                    road_class_batch.append(np.zeros((1,)))
                    # lanenr_info_batch.append(np.zeros((2,)))
                lanenr_info_batch.append(np.zeros((2,)))

                if data_entry["current"]["adas_info"][0]["map_loc"].shape[0] > 0:
                    map_loc_batch.append(data_entry["current"]["adas_info"][0]["map_loc"])
                else:
                    map_loc_batch.append(np.zeros((3,), dtype=np.float32))

            batch_speed_lmt = np.vstack(speed_lmt_batch).astype(np.float32)
            batch_navi_info = np.vstack(navi_info_batch).astype(np.float32)
            batch_lanenr_info = np.vstack(lanenr_info_batch).astype(np.float32)
            batch_road_class = np.vstack(road_class_batch).astype(np.float32)
            batch_map_loc = np.vstack(map_loc_batch).astype(np.float32)
            batch_adasmap_valid = np.vstack(adasmap_valid_batch).astype(np.float32)
            batch_adasmap_onhighway = np.vstack(adasmap_is_on_highway).astype(np.float32)

            batch_items.update(
                {
                    "speed_lmt": torch.from_numpy(batch_speed_lmt),
                    "navi_info": torch.from_numpy(batch_navi_info),
                    "lanenr_info": torch.from_numpy(batch_lanenr_info),
                    "road_class": torch.from_numpy(batch_road_class),
                    "batch_map_loc": torch.from_numpy(batch_map_loc),
                    "is_on_highway": torch.from_numpy(batch_adasmap_onhighway),
                    "is_adasinfo_valid": torch.from_numpy(batch_adasmap_valid),
                }
            )

        box_size_indices = (3, 5)
        batch_items["egos_size"] = batch_items["egos"][
            :, -1, :, box_size_indices[0] : box_size_indices[1]
        ]  # type: ignore
        batch_items["bboxes_size"] = batch_items["bboxes"][  # type: ignore
            :, -1, :, box_size_indices[0] : box_size_indices[1]
        ]

        # process global routing info
        if "global_routing" in data[0]["current"] and "sd_link_ids" in data[0]["current"]:
            has_routing_valid_list = []
            global_matching_state_list = []
            global_routing_mask_list = []
            for data_entry in data:
                global_matching_state = data_entry["current"]["global_routing"][0]["matching_state"]
                global_rt = data_entry["current"]["global_routing"][0]["hd_link_segments"]

                map_link_id_list = data_entry["current"]["filtered_sd_link_ids"]

                common_element = list(set(map_link_id_list).intersection(global_rt))
                global_routing_valid = (
                    global_matching_state == 1 or global_matching_state == 6 or global_matching_state == 2
                )
                has_routing_valid_list.append(len(common_element) > 0)
                global_matching_state_list.append(global_routing_valid)

                global_routing_mask = np.zeros(len(map_link_id_list), dtype=bool)
                for i in range(map_link_id_list.shape[0]):
                    global_routing_mask[i] = map_link_id_list[i] in common_element

                if len(map_link_id_list) < data_entry["current"]["sdmap_polylines"].shape[0]:
                    delta_lane_num = data_entry["current"]["sdmap_polylines"].shape[0] - len(map_link_id_list)
                    global_routing_mask = np.concatenate([global_routing_mask, np.zeros(delta_lane_num)], axis=0)
                global_routing_mask_list.append(global_routing_mask)

            batch_global_routing_mask = torch.from_numpy(np.vstack(global_routing_mask_list)).float()
            batch_has_routing_valid = torch.from_numpy(np.array(has_routing_valid_list)).unsqueeze(-1)
            batch_global_matching_state = torch.from_numpy(np.array(global_matching_state_list)).unsqueeze(-1)

            batch_items.update(
                {
                    "global_routing_mask": batch_global_routing_mask,
                    "has_routing_valid": batch_has_routing_valid,
                    "global_matching_state": batch_global_matching_state,
                }
            )

        if "navi_line_points" in data[0]["current"]:
            batch_navi_line_points = np.stack([data_entry["current"]["navi_line_points"] for data_entry in data])
            batch_navi_line_types = np.stack([data_entry["current"]["navi_line_types"] for data_entry in data])
            batch_navi_lane_tld = np.stack([data_entry["current"]["navi_lane_tld"] for data_entry in data])
            batch_navi_lane_stoppoints = np.stack(
                [data_entry["current"]["navi_lane_stoppoints"] for data_entry in data]
            )
            batch_items.update(
                {
                    "navi_line_points": torch.from_numpy(batch_navi_line_points),
                    "navi_line_types": torch.from_numpy(batch_navi_line_types),
                    "navi_lane_tld": torch.from_numpy(batch_navi_lane_tld),
                    "navi_lane_stoppoints": torch.from_numpy(batch_navi_lane_stoppoints),
                }
            )
        if "navi_path_points" in data[0]["current"]:
            batch_navi_path_points = np.stack([data_entry["current"]["navi_path_points"] for data_entry in data])
            batch_navi_path_types = np.stack([data_entry["current"]["navi_path_types"] for data_entry in data])
            if len(batch_navi_path_types.shape) == 2:
                batch_navi_path_types = np.expand_dims(batch_navi_path_types, axis=1)
            batch_navi_path_speed_limit = np.stack(
                [data_entry["current"]["navi_path_speed_limit"] for data_entry in data]
            )
            batch_navi_path_stoppoints = np.stack(
                [data_entry["current"]["navi_path_stoppoints"] for data_entry in data]
            )
            batch_navi_path_tld = np.stack([data_entry["current"]["navi_path_tld"] for data_entry in data])
            batch_items.update(
                {
                    "navi_path_points": torch.from_numpy(batch_navi_path_points),
                    "navi_path_types": torch.from_numpy(batch_navi_path_types),
                    "navi_path_speed_limit": torch.from_numpy(batch_navi_path_speed_limit),
                    "navi_path_stoppoints": torch.from_numpy(batch_navi_path_stoppoints),
                    "navi_path_tld": torch.from_numpy(batch_navi_path_tld),
                }
            )
        for static_key in ("road_detection", "atlas", "road_post"):
            batch_items.update(
                {
                    f"{static_key}_veh2ref": torch.from_numpy(
                        np.stack([data_entry["current"][f"{static_key}_veh2ref"] for data_entry in data])
                    )
                }
            )

        if "lane_collision_map" in data[0]["current"]:
            batch_lane_collision_map = np.stack([data_entry["current"]["lane_collision_map"] for data_entry in data])
            batch_items.update(
                {
                    "lane_collision_map": torch.from_numpy(batch_lane_collision_map),
                }
            )

        if self.tld_data_aug:
            batch_items["tld_data_aug"] = [
                data_entry["data_aug"] if "data_aug" in data_entry else None for data_entry in data
            ]

        if self.stop_data_aug:
            batch_items["stop_data_aug"] = [
                data_entry["stop_aug"] if "stop_aug" in data_entry else None for data_entry in data
            ]

        if "navi_lane_to_target_lc_times" not in batch_items and "navi_line_points" in batch_items:
            batch_items["navi_lane_to_target_lc_times"] = torch.zeros(
                (batch_items["navi_line_points"].shape[0], 6, 1), dtype=torch.float32
            )
        if "control_point" in data[0]["current"]:
            batch_control_points = np.stack([data_entry["current"]["control_point"] for data_entry in data])
            batch_items.update(
                {
                    "control_points": torch.from_numpy(batch_control_points).to(torch.float32),
                }
            )
        if "drive_path" in data[0]["current"]:
            batch_dirve_path = np.stack([data_entry["current"]["drive_path"] for data_entry in data])
            batch_drive_path_mask = np.stack([data_entry["current"]["drive_path_mask"] for data_entry in data])
            batch_navi_drive_path = np.stack([data_entry["current"]["navi_drive_path"] for data_entry in data])
            batch_navi_drive_path_mask = np.stack(
                [data_entry["current"]["navi_drive_path_mask"] for data_entry in data]
            )
            batch_items.update(
                {
                    "drive_path": torch.from_numpy(batch_dirve_path).to(torch.float32),
                    "drive_path_mask": torch.from_numpy(batch_drive_path_mask).to(torch.float32),
                    "navi_drive_path": torch.from_numpy(batch_navi_drive_path).to(torch.float32),
                    "navi_drive_path_mask": torch.from_numpy(batch_navi_drive_path_mask).to(torch.float32),
                }
            )
        if "od_prior" in data[0]["current"]:
            batch_od_prior = np.stack([data_entry["current"]["od_prior"] for data_entry in data])
            batch_items.update(
                {
                    "od_prior_gt": torch.from_numpy(batch_od_prior).to(torch.float32),
                }
            )

        if "prediction_traj" in data[0]["current"]:
            batch_prediction_traj = np.stack([data_entry["current"]["prediction_traj"] for data_entry in data])
            batch_items.update(
                {
                    "prediction_traj": torch.from_numpy(batch_prediction_traj).to(torch.float32),
                }
            )

        if "od_prior_mask_input" in data[0]["current"]:
            batch_od_prior_mask_input = np.stack([data_entry["current"]["od_prior_mask_input"] for data_entry in data])
            batch_items.update(
                {
                    "od_prior_mask_input": torch.from_numpy(batch_od_prior_mask_input).to(torch.float32),
                }
            )

        if "ar_ego_action_vocab" in data[0]:
            batch_ar_ego_action_vocab = np.stack([data_entry["ar_ego_action_vocab"] for data_entry in data])
            batch_items.update(
                {
                    "ar_ego_action_vocab": torch.from_numpy(batch_ar_ego_action_vocab).to(torch.float32),
                }
            )
        if "ar_ego_action_soft_labels" in data[0]:
            batch_ar_ego_action_soft_labels = np.stack([data_entry["ar_ego_action_soft_labels"] for data_entry in data])
            batch_items.update(
                {
                    "ar_ego_action_soft_labels": torch.from_numpy(batch_ar_ego_action_soft_labels).to(torch.float32),
                }
            )

        if "ar_ego_action_vocab_all" in data[0]:
            batch_ar_ego_action_vocab_all = np.stack([data_entry["ar_ego_action_vocab_all"] for data_entry in data])
            batch_items.update(
                {
                    "ar_ego_action_vocab_all": torch.from_numpy(batch_ar_ego_action_vocab_all).to(torch.float32),
                }
            )
        if "ar_ego_action_soft_labels_all" in data[0]:
            batch_ar_ego_action_soft_labels_all = np.stack(
                [data_entry["ar_ego_action_soft_labels_all"] for data_entry in data]
            )
            batch_items.update(
                {
                    "ar_ego_action_soft_labels_all": torch.from_numpy(batch_ar_ego_action_soft_labels_all).to(
                        torch.float32
                    ),
                }
            )

        if "ar_ego_action_vocab_all" in data[0]:
            batch_ar_ego_action_vocab_all = np.stack([data_entry["ar_ego_action_vocab_all"] for data_entry in data])
            batch_items.update(
                {
                    "ar_ego_action_vocab_all": torch.from_numpy(batch_ar_ego_action_vocab_all).to(torch.float32),
                }
            )
        if "ar_ego_action_soft_labels_all" in data[0]:
            batch_ar_ego_action_soft_labels_all = np.stack(
                [data_entry["ar_ego_action_soft_labels_all"] for data_entry in data]
            )
            batch_items.update(
                {
                    "ar_ego_action_soft_labels_all": torch.from_numpy(batch_ar_ego_action_soft_labels_all).to(
                        torch.float32
                    ),
                }
            )
        if "ar_ego_state" in data[0]:
            batch_ar_ego_state = np.stack([data_entry["ar_ego_state"] for data_entry in data])
            batch_items.update(
                {
                    "ar_ego_state": torch.from_numpy(batch_ar_ego_state).to(torch.float32),
                }
            )

        if "ar_ego_future_mask" in data[0]:
            batch_ar_ego_future_mask = np.stack([data_entry["ar_ego_future_mask"] for data_entry in data])
            batch_items.update(
                {
                    "ar_ego_future_mask": torch.from_numpy(batch_ar_ego_future_mask).to(torch.float32),
                }
            )

        if "ar_ego_action_norm" in data[0]:
            batch_ar_ego_action_norm = np.stack([data_entry["ar_ego_action_norm"] for data_entry in data])
            batch_items.update(
                {
                    "ar_ego_action_norm": torch.from_numpy(batch_ar_ego_action_norm).to(torch.float32),
                }
            )

        if "ar_agents_state" in data[0]:
            batch_ar_agents_state = np.stack([data_entry["ar_agents_state"] for data_entry in data])
            batch_items.update(
                {
                    "ar_agents_state": torch.from_numpy(batch_ar_agents_state).to(torch.float32),
                }
            )

        if "ar_agents_action" in data[0]:
            batch_ar_agents_action = np.stack([data_entry["ar_agents_action"] for data_entry in data])
            batch_items.update(
                {
                    "ar_agents_action": torch.from_numpy(batch_ar_agents_action).to(torch.float32),
                }
            )

        def check_add_stack_tensor(
            data: List[Dict[str, Any]], key: str, batch_items: Dict[str, torch.Tensor], dtype=None
        ):
            if key in data[0]:
                dtype = dtype if dtype is not None else data[0][key].dtype
                ts = np.stack([data_entry[key] for data_entry in data]).astype(dtype)
                batch_items[key] = torch.from_numpy(ts)

        check_add_stack_tensor(data=data, key="egos_gear", batch_items=batch_items)
        check_add_stack_tensor(data=data, key="egos_gt_gear_shift_idx", batch_items=batch_items)
        check_add_stack_tensor(data=data, key="egos_input_gear_shift_points", batch_items=batch_items, dtype=np.float32)
        check_add_stack_tensor(data=data, key="egos_gt_gear_shift_points", batch_items=batch_items, dtype=np.float32)
        check_add_stack_tensor(data=data, key="egos_gt_gear_shift_points_mask", batch_items=batch_items, dtype=bool)
        check_add_stack_tensor(data=data, key="egos_gt_gear", batch_items=batch_items, dtype=np.int64)

        def check_current_add_stack_tensor(
            data: List[Dict[str, Any]],
            key: str,
            batch_items: Dict[str, torch.Tensor],
            dtype=None,
        ):
            if key in data[0]["current"]:
                dtype = dtype if dtype is not None else data[0]["current"][key][0].dtype
                ts = np.stack([data_entry["current"][key][0] for data_entry in data]).astype(dtype)
                batch_items[key] = torch.from_numpy(ts)

        check_current_add_stack_tensor(data=data, key="sample_task_mask", batch_items=batch_items)

        if contains_nan_or_inf(batch_items):
            raise ValueError("find anormaly value (nan or inf). please check batch_collate func.")

        if self.zero_shot_aug_enable:
            cur_batch_clip_ids = [x.split("_")[0] for x in batch_items["subclip_ids"]]
            cur_batch_ts = list(batch_items["timestamp"][:, -1])

            for each_aug_info in self.zero_shot_aug_state:
                aug_clip_id, aug_ts, aug_bbox_id, aug_x_y_yaw = each_aug_info

                if aug_clip_id in cur_batch_clip_ids and aug_ts in cur_batch_ts:
                    # bbox_xylwh = bbox[[0, 1, 3, 4, 6]]
                    # x, y, z,  l, w, h,  heading
                    batch_items["bboxes"][:, :, aug_bbox_id, 0] += aug_x_y_yaw[0]
                    batch_items["bboxes"][:, :, aug_bbox_id, 1] += aug_x_y_yaw[1]
                    batch_items["bboxes"][:, :, aug_bbox_id, 6] += aug_x_y_yaw[2]
                    batch_items["bboxes_pred_gt"][:, aug_bbox_id, :25, 0] += aug_x_y_yaw[0]
                    batch_items["bboxes_pred_gt"][:, aug_bbox_id, :25, 1] += aug_x_y_yaw[1]
                    batch_items["bboxes_det_pred_full_info_gt"][:, aug_bbox_id, :25, 0] += aug_x_y_yaw[0]
                    batch_items["bboxes_det_pred_full_info_gt"][:, aug_bbox_id, :25, 1] += aug_x_y_yaw[1]
                    batch_items["bboxes_det_pred_full_info_gt"][:, aug_bbox_id, :25, 6] += aug_x_y_yaw[2]

        return batch_items
