import math
from typing import Optional

import numpy as np
import torch
import torch.distributed as dist
from torchpilot.data.sampler.tp_distributed_sampler import TPDistributedSampler

from tpp_onemodel.data.dataset.plannn2_dataset import Plannn2Dataset


class Plannn2DistributedLengthGroupedSampler(TPDistributedSampler):
    def __init__(  # pylint: disable=super-init-not-called
        self,
        dataset: Plannn2Dataset,
        shuffle: bool = True,
        seed: int = 0,
        drop_last: bool = False,
        batch_size: int = 1,
        num_replicas: Optional[int] = None,
        num_workers: Optional[int] = None,
        rank: Optional[int] = None,
    ):
        self._dataset = dataset
        self._shuffle = shuffle
        self._seed = seed
        self._epoch = 0
        self._step = 0
        self._batch_size = batch_size
        self._drop_last = drop_last
        self._num_replicas = num_replicas
        self._data_length_index = dataset.data_lengths
        self._indices = list(range(len(self._dataset)))

        if num_replicas is None:
            if not dist.is_available():
                raise RuntimeError("Requires distributed package to be available")
            num_replicas = dist.get_world_size()
        if rank is None:
            if not dist.is_available():
                raise RuntimeError("Requires distributed package to be available")
            rank = dist.get_rank()
        if rank not in range(0, num_replicas):
            raise ValueError(
                f"Invalid rank {rank}, rank should be in the interval"
                f" [0, {num_replicas - 1}].",
            )
        self._num_replicas = num_replicas
        self._rank = rank

        sample_len = len(self._dataset)
        if self._drop_last and sample_len % self._num_replicas != 0:
            self._num_samples = math.ceil(
                (sample_len - self._num_replicas) / self._num_replicas,
            )
        else:
            self._num_samples = math.ceil(sample_len / self._num_replicas)
        self._total_size = self._num_samples * self._num_replicas
        self._global_batch_size = self._batch_size * self._num_replicas

    def __iter__(self):
        g = torch.Generator()
        g.manual_seed(self._seed + self._epoch)

        indices = self._indices.copy()
        if self._shuffle:
            indices = torch.randperm(len(self._dataset), generator=g).tolist()
        indices.sort(key=lambda x: self._data_length_index[x])

        if self._drop_last:
            indices = indices[: self._total_size]
        else:
            padding_size = self._total_size - len(indices)
            if padding_size <= len(indices):
                indices += indices[:padding_size]
            else:
                indices += (indices * math.ceil(padding_size / len(indices)))[:padding_size]

        mega_batches = [indices[i : i + self._global_batch_size] for i in range(0, len(indices), self._global_batch_size)]
        if self._shuffle:
            np.random.seed(self._seed + self._epoch)
            np.random.shuffle(mega_batches)

        rank_indices = []
        for mb in mega_batches:
            start_index = self._rank * self._batch_size
            end_index = start_index + self._batch_size
            local_batch = mb[start_index:end_index]
            rank_indices.extend(local_batch)

        return iter(rank_indices)

    def __len__(self):
        return self._num_samples


if __name__ == "__main__":
    import random
    random.seed(1)
    lengths = [1, 2, 3, 5, 10] * 100
    random.shuffle(lengths)
    indices = list(range(len(lengths)))

    print(lengths)
    print(indices)

    r0 = Plannn2DistributedLengthGroupedSampler(indices, lengths=lengths, shuffle=True, seed=1, drop_last=True, batch_size=8, num_replicas=4, rank=0)
    r1 = Plannn2DistributedLengthGroupedSampler(indices, lengths=lengths, shuffle=True, seed=1, drop_last=True, batch_size=8, num_replicas=4, rank=1)
    r2 = Plannn2DistributedLengthGroupedSampler(indices, lengths=lengths, shuffle=True, seed=1, drop_last=True, batch_size=8, num_replicas=4, rank=2)
    r3 = Plannn2DistributedLengthGroupedSampler(indices, lengths=lengths, shuffle=True, seed=1, drop_last=True, batch_size=8, num_replicas=4, rank=3)

    itr0 = iter(r0)
    itr1 = iter(r1)
    itr2 = iter(r2)
    itr3 = iter(r3)
    for b in range(10):
        batch = []
        for i in range(8):
            batch.append(lengths[next(itr0)])
            batch.append(lengths[next(itr1)])
            batch.append(lengths[next(itr2)])
            batch.append(lengths[next(itr3)])
        print("batch ", b, batch)
