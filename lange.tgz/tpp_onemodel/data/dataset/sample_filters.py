# -*- coding: utf-8 -*-

from typing import Dict
from typing import Tuple


class SampleGenerator:
    def __init__(self, history_frame_num, future_frames_num, slide_win_step):
        self.history_frame_num = history_frame_num
        self.future_frames_num = future_frames_num
        self.slide_win_step = slide_win_step

    def __call__(self, timestamp_list):
        """Generate index."""
        num_frames = len(timestamp_list)
        all_index = []
        for current in range(num_frames):
            history_start = max(0, current - self.history_frame_num)
            history_end = current
            future_start = current + 1
            future_end = min(num_frames, current + 1 + self.future_frames_num)

            history = list(range(history_start, history_end))
            history = [-1] * (self.history_frame_num - len(history)) + history  # pad history frame
            future = list(range(future_start, future_end))
            future = future + [-1] * (self.future_frames_num - len(future))  # pad future frame
            current_frame = [current]

            all_index.append(
                {
                    "current_index": current_frame,
                    "history_index": history,
                    "future_index": future,
                }
            )
        all_index = all_index[:: self.slide_win_step]
        return all_index


class SampleFilter:
    def __init__(self, name: str):
        if name is None or name == "":
            name = self.__class__.__name__
        self.name = name

    def __call__(self, sample: Dict) -> Tuple[bool, str]:
        """Check if sample is valid."""
        return (True, self.name)


# class PaddingFilterSukai(SampleFilter):
#     def __init__(self, name: str):
#         super().__init__(name)

#     def _check_sample_sanity(self, one_pair_infos):
#         # history frame satisfied
#         history_flag = self.history_frame_num == len(one_pair_infos["history"])
#         if not history_flag:
#             return False
#         if self.padding_history:
#             if one_pair_infos["history"][-3] is None:
#                 # drop first 3 frames of one clip
#                 return False
#         else:
#             if one_pair_infos["history"][0] is None:
#                 return False

#         future_flag = self.future_frames_num == len(one_pair_infos["future"])
#         if not future_flag:
#             return False
#         if self.padding_future:
#             if one_pair_infos["future"][0] is None:
#                 # drop last frame of one clip
#                 return False
#         else:
#             if one_pair_infos["future"][-1] is None:
#                 return False

#         all_input_sensors = {item for sublist in self.input_sensor_map.values() for item in sublist}
#         all_data_sensors = set(one_pair_infos["current"][0].keys())

#         if not all_input_sensors.issubset(all_data_sensors):
#             print("Some input sensors are missing in data sensors: %s.", all_input_sensors - all_data_sensors)
#             return False
#         return True


class PaddingFilter(SampleFilter):
    def __init__(
        self, history_frame_num: int, future_frames_num: int, input_sensor_map: Dict[str, list], name: str = ""
    ):
        super().__init__(name)
        self.history_frame_num = history_frame_num
        self.future_frames_num = future_frames_num
        self.input_sensor_map = input_sensor_map

    def __call__(self, sample: Dict) -> Tuple[bool, str]:
        """Check if sample is valid."""
        history_flag = self.history_frame_num == len(sample["history"])
        if not history_flag:
            return (False, self.name)
        if any([item is None for item in sample["history"]]):
            return (False, self.name)

        future_flag = self.future_frames_num == len(sample["future"])
        if not future_flag:
            return (False, self.name)
        if any([item is None for item in sample["future"][:5]]):
            return (False, self.name)

        all_input_sensors = {item for sublist in self.input_sensor_map.values() for item in sublist}
        all_data_sensors = set(sample["current"][0].keys())

        if not all_input_sensors.issubset(all_data_sensors):
            print("missing sensors: %s.", all_input_sensors - all_data_sensors)  # noqa: T201
            return (False, self.name)
        return (True, self.name)


class TagIncludeFilter(SampleFilter):
    def __init__(self, included_tag_list: list, name: str = ""):
        super().__init__(name)
        self.included_tag_list = included_tag_list

    def __call__(self, one_pair_infos) -> Tuple[bool, str]:
        """Check if sample include all of the tags."""
        if not self.included_tag_list:
            return (True, self.name)
        current_tags = one_pair_infos["current"][0]["tags"]
        for tag in self.included_tag_list:
            is_found = False
            for current_tag in current_tags:
                if tag in current_tag:
                    is_found = True
                    break
            if not is_found:
                return (False, self.name)
        return (True, self.name)


class TagExcludeFilter(SampleFilter):
    def __init__(self, excluded_tag_list: list, name: str = ""):
        super().__init__(name)
        self.excluded_tag_list = excluded_tag_list

    def __call__(self, one_pair_infos) -> Tuple[bool, str]:
        """Check if sample exclude any of the tags."""
        if not self.excluded_tag_list:
            return (True, self.name)
        current_tags = one_pair_infos["current"][0]["tags"]
        for tag in self.excluded_tag_list:
            for current_tag in current_tags:
                if tag in current_tag:
                    return (False, self.name)
        return (True, self.name)


class RequiredFieldsFilter(SampleFilter):
    def __init__(self, required_fields: list, name: str = ""):
        super().__init__(name)
        self.required_fields = required_fields

    def __call__(self, one_pair_infos) -> Tuple[bool, str]:
        """Check if sample has required fields."""
        # navi_line_len = one_pair_infos["current"][0]["navi_line"][1]
        current_info = one_pair_infos.get("current", [{}])[0]

        for field in self.required_fields:
            min_window_size = 5
            if field == "navi_line":
                min_window_size = 300
            if field not in current_info:
                return (False, self.name)
            if current_info[field] is None:
                return (False, self.name)
            if current_info[field][1] < min_window_size:
                return (False, self.name)
        return (True, self.name)
