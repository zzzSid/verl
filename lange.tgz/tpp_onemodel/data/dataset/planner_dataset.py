# -*- coding: utf-8 -*-
"""Dataset of Stamp."""
# pylint: disable=line-too-long
# flake8:noqa
import copy
import itertools
import json
import logging
import os
import pickle
import re
import time
from concurrent.futures import ProcessPoolExecutor
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
from multiprocessing import Pool
from multiprocessing import RLock
from pathlib import Path
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Union

import cv2
import numpy as np
import torch
import torch.distributed as dist
from torchpilot.data.dataset.base_dataset import BaseDataset
from tqdm import tqdm

from tpp_onemodel.data.dataset.planner_subiterator import SubIteratorManager
from tpp_onemodel.data.dataset.planner_subiterator import is_sample_exclude_tag
from tpp_onemodel.data.dataset.planner_subiterator import is_sample_include_tag
from tpp_onemodel.data.dataset.sample_filters import PaddingFilter
from tpp_onemodel.data.dataset.sample_filters import RequiredFieldsFilter
from tpp_onemodel.data.dataset.sample_filters import SampleFilter
from tpp_onemodel.data.dataset.sample_filters import SampleGenerator
from tpp_onemodel.data.dataset.sample_filters import TagExcludeFilter
from tpp_onemodel.data.dataset.sample_filters import TagIncludeFilter
from tpp_onemodel.utils.common_utils import get_paths_finfos
from tpp_onemodel.utils.common_utils import timer
from tpp_onemodel.utils.niofs import FileInfo
from tpp_onemodel.utils.niofs import get_niofs_client
from tpp_onemodel.utils.niofs import load_file_with_tag_from_cache
from tpp_onemodel.utils.niofs import parse_niofs_url


logger = logging.getLogger(__name__)
try:
    from read_cache_op_py import read_cache_op_py
except ImportError as err:
    logger.warning("No read_cache_op_py: %s", err)

_DEFAULT_CLIP_DOWNLOAD_ROOT = Path("/tmp/stamp_dataset_cache")
_HOME_CACHEDIR = Path("~/.training_cache").expanduser()
_TRAIN_PLATFORM_MAX_CPUS_PER_GPU = 15
_SIZE_OUTLIER_MUL = 10  # Size outlier multiplier
ceph_client = get_niofs_client(max_pool_connections=os.cpu_count())

# from torchpilot.utils.stopwatch import ProfileStopwatch

# stopwatch = ProfileStopwatch(
#     "__getitem__",  # 计时器的名字，可以自己取
#     sync_before_stopwatch=True,  # true 时，在每次计时前及间隔做 torch.cuda.synchronize()
#     barrier_before_stopwatch=False,  # true 时， 在每次计时前及间隔做 dist.barrier()
#     log_interval=1,  # 设置打印耗时的间隔， 40 表示调用 40 次 log_time_cost 方法之后打印一次平均耗时
# )
# stopwatch1 = ProfileStopwatch(
#     "convert_meta_info", sync_before_stopwatch=True, barrier_before_stopwatch=False, log_interval=1
# )
# stopwatch2 = ProfileStopwatch(
#     "fetch_batch_meta_cache_infos", sync_before_stopwatch=True, barrier_before_stopwatch=False, log_interval=1
# )
# stopwatch3 = ProfileStopwatch("transforms", sync_before_stopwatch=True, barrier_before_stopwatch=False, log_interval=1)


# pylint: disable=dangerous-default-value, too-many-arguments, too-many-statements, too-many-instance-attributes, too-many-locals


def group_new_annos(all_annos):
    nframe = len(all_annos["timestamp"])
    new_all_annos = []
    for i in range(nframe):
        annos = {key: all_annos[key][i] for key in all_annos}
        new_all_annos.append(annos)
    return new_all_annos


def generate_windows(all_annos, history_frame_num, future_frames_num):
    """Generate index."""
    num_frames = len(all_annos)
    all_index = []
    for current in range(num_frames):
        history_start = max(0, current - history_frame_num)
        history_end = current
        future_start = current + 1
        future_end = min(num_frames, current + 1 + future_frames_num)

        history = list(range(history_start, history_end))
        history = [-1] * (history_frame_num - len(history)) + history  # pad history frame
        future = list(range(future_start, future_end))
        future = future + [-1] * (future_frames_num - len(future))  # pad future frame
        current_frame = [current]

        all_index.append(
            {
                "current_index": current_frame,
                "history_index": history,
                "future_index": future,
            }
        )
    return all_index


def merge_multi_frame(frames):
    if len(frames) < 1:
        return {}

    results = {}

    for key in frames[0]:
        if key in [
            "dynamic_dets",
            "static_dets",
            "tsrs",
            "crop_images",
        ]:
            results[key] = np.concatenate([item[key] for item in frames], axis=0)
            results[key + "_splits"] = np.array([len(item[key]) for item in frames])
        elif key == "tld":
            results[key] = np.concatenate([item[key] for item in frames], axis=0)
        elif key == "car_poses":
            results[key] = np.stack([item[key] for item in frames])
        elif key == "gt":
            results["bboxes"] = np.concatenate([item[key] for item in frames], axis=0)
            results["bboxes_splits"] = np.array([len(item[key]) for item in frames])
        else:
            # "ids", "subclip_ids", "timestamps", "ego_motion", "scene_type",
            # "adas_info", "lane_points", "lane_types", "atlas", "sdmap_geo"
            results[key] = [item[key] for item in frames]
    return results


def sample_collate(
    one_pair_infos, name, start_idx, frame_idx, meta_loader=False, use_future=True
):  # pylint: disable=too-many-locals, too-many-branches, too-many-statements
    """Parse one pair infos."""
    pair_infos = dict(current={}, history={})
    if use_future:
        pair_infos["future"] = {}

    time_curr = float(one_pair_infos["current"][0]["timestamp"])
    states = ["current", "history"]
    if use_future:
        states.append("future")

    for state in states:  # pylint:disable=too-many-nested-blocks
        item_state = one_pair_infos[state]
        one_state_infos = []
        for _, frame in enumerate(item_state):
            # one_frame_info = copy.deepcopy(frame)
            if frame is not None:
                frame["ids"] = f"{name}_{frame_idx + start_idx}"
            one_state_infos.append(frame)

        if meta_loader:
            pair_infos.update({state: one_state_infos})
        else:
            pair_infos.update({state: merge_multi_frame(one_state_infos)})

            if state == "current":
                pair_infos["current"]["adas_info"] = frame["adas_info"]
                pair_infos["current"]["lane_points"] = frame["lane_points"]
                pair_infos["current"]["lane_types"] = frame["lane_types"]
                pair_infos["current"]["atlas"] = frame["atlas"]
                pair_infos["current"]["sdmap_geo"] = frame["sdmap"]
    return pair_infos


def file_content_to_samples(
    sample_generator: SampleGenerator,
    filters: List[SampleFilter],
    clip_content: Any,
    dataset_name: str,
    meta_loader: bool,
    use_future: bool = False,
):
    """Convert file content to samples."""
    clip_path, info_bytes = clip_content[0]
    infos = pickle.loads(info_bytes)
    infos["annos"].update({"timestamp": infos["timestamp_list"]})

    _, tag_info_bytes = clip_content[1]
    if tag_info_bytes is None:
        tag_infos = {}
    else:
        tag_infos = pickle.loads(tag_info_bytes)

    all_annos = group_new_annos(infos["annos"])
    all_index = sample_generator(infos["timestamp_list"])
    # Form frames samples
    stats = {}
    stats["invalid_frames"] = 0
    stats["total_frames"] = 0
    stats["invalid_tag_frames"] = 0

    all_infos: List[Dict] = []
    for sample_index in all_index:
        stats["total_frames"] += 1
        current = [all_annos[idx] for idx in sample_index["current_index"]]
        history: List[Optional[Dict]] = []
        for idx in sample_index["history_index"]:
            if idx == -1:
                history.append(None)
            else:
                history.append(all_annos[idx])
        future: List[Optional[Dict]] = []
        for idx in sample_index["future_index"]:
            if idx == -1:
                future.append(None)
            else:
                future.append(all_annos[idx])
        one_sample = {
            "current": current,
            "history": history,
            "future": future,
        }
        tag_objs = tag_infos.get(f"{int(current[0]['timestamp'])}", {"objs": []})
        one_sample["current"][0]["tags"] = [_["cate"] for _ in tag_objs["objs"]]

        cur_sample_is_valid = True
        for filter in filters:
            is_success, filter_name = filter(one_sample)
            if not is_success:
                stats["invalid_frames"] += 1
                cur_sample_is_valid = False
                break
        if not cur_sample_is_valid:
            continue

        if one_sample_info := sample_collate(one_sample, dataset_name, 0, len(all_infos), meta_loader, use_future):
            if meta_loader:
                all_infos.append(
                    {
                        "clip_path": f"{clip_path.bucket}/{clip_path.path}",
                        "meta_info": one_sample_info,
                        "cephpath_filesize": infos["cephpath_filesize"],
                    }
                )
            else:
                all_infos.append(one_sample_info)
    return all_infos, stats


def files_contents_to_samples_process(
    files_contents,
    sample_generator,
    sample_filters,
    dataset_name: str,
    meta_loader: bool,
    use_future: bool,
):
    all_infos = []
    stats = {"invalid_frames": 0, "total_frames": 0, "invalid_tag_frames": 0}

    for file_content in files_contents:
        if file_content[0] is None:
            continue
        infos, stats = file_content_to_samples(
            sample_generator=sample_generator,
            filters=sample_filters,
            clip_content=file_content,
            dataset_name=dataset_name,
            meta_loader=meta_loader,
            use_future=use_future,
        )
        all_infos.extend(infos)
        stats["invalid_frames"] += stats["invalid_frames"]
        stats["total_frames"] += stats["total_frames"]
        stats["invalid_tag_frames"] += stats["invalid_tag_frames"]

    return all_infos, stats


class PlannerMultiDataset(BaseDataset):
    """Multi Dataset for E2E Planner Task."""

    def __init__(
        self,
        mode: str,
        data_meta,
        subiterator_cfg,
        input_sensor_map,
        task_name,
        box_feat_dims,
        sod_box_feat_dims,
        ego_box_feat_dims,
        gt_box_dim,
        stamp_det_dim,
        gt_cls_mapping,
        dynamic_det_dim,
        static_det_dim,
        tld_panel_dim,
        tsr_dim,
        adas_info_speed_lmt_dim,
        subtype_mapping,
        subtype2subtype,
        sensor_type_remap,
        motion_type_mapping,
        bev_key,
        data_distribute_cfg=None,
        recls_by_size=[],
        previous_frames_num=19,
        future_frames_num=1,
        previous_frames_sample_step=1,
        future_frames_sample_step=1,
        padding_history=True,
        padding_future=True,
        slide_win_step=1,
        included_tag_list=[],
        excluded_tag_list=[],
        required_fields=[],
        transforms: Union[List[Any], Dict[str, Any], None] = None,
        num_multiprocess_pkl_infos=1,
        shuffle=False,
        training_epoch_length=1000,
        train_all_samples_each_epoch=False,
        batch_size=1,
        disable_god=False,
        use_future=False,
        num_workers=1,
        dataloader_num_workers=1,
        use_lane=False,
        use_lane_post=False,
        lane_type_remap={
            "lane_line": 0,
            "road_edge": 1,
            "stop_line": 2,
            "road_sign": 3,
        },
        use_dataset_glob_cache=False,
        box_size_indices=[3, 5],
        debug=False,
    ) -> None:
        """Init.

        Args:
            num_multiprocess_pkl_infos (int): Flag to control whether using multiprocess
             to speed up pkl process in function parse_label_dir.
             Default 1 means not using multiprocess.
        """
        super().__init__(
            mode=mode,
            meta_file=None,
            transforms=transforms,
        )
        self.use_dataset_glob_cache = use_dataset_glob_cache
        self.annos_per_pickle: Dict = {}
        self.slide_win_step = slide_win_step
        if included_tag_list:
            included_tag_list = [str(i).strip().replace("-", ".") for i in included_tag_list]
        self.included_tag_list = included_tag_list
        if excluded_tag_list:
            excluded_tag_list = [str(i).strip().replace("-", ".") for i in excluded_tag_list]
        self.required_fields = required_fields
        self.excluded_tag_list = excluded_tag_list
        self.disable_god = disable_god
        self.use_future = use_future
        self.stamp_det_dim = stamp_det_dim
        self.box_feat_dims = box_feat_dims
        self.sod_box_feat_dims = sod_box_feat_dims
        self.subtype_mapping = subtype_mapping
        self.subtype2subtype = subtype2subtype
        self.sensor_type_remap = sensor_type_remap

        self.motion_type_mapping = motion_type_mapping

        self.use_lane = use_lane
        self.use_lane_post = use_lane_post
        self.lane_type_remap = lane_type_remap
        self.ego_box_feat_dims = ego_box_feat_dims

        self.bev_key = bev_key
        self.ego_motion_template = {
            "velocity": [-1, -1, -1],
            "acceleration": [-1, -1, -1],
            "yaw": [0, 0, 0],
            "yaw_rate": [-1, -1, -1],
            "whlag": 0,
            "whlagspd": 0,
        }
        self.empty_frame = {
            "timestamp": "0",
            "sensor_name": "pad",
            "detection": [],
            "annotation": [],
            "pad_frame_flag": True,
            "car_pose": np.eye(4).flatten().tolist(),
            "lidar": {
                "falcon": {
                    "extrinsic": np.eye(4).flatten().tolist(),
                    "ceph_path": "",
                },
                "subclip_id": "",
            },
            "lane": [],
            "ego_motion": self.ego_motion_template,
            "meta_type": "pad",
        }

        if data_distribute_cfg is None:
            raise ValueError("data_distribute_cfg is None")
        self.lidar_query_lidar_key_num = data_distribute_cfg.lidar_query_lidar_key_num
        self.camera_query_lidar_key_num = data_distribute_cfg.camera_query_lidar_key_num
        self.lidar_sample_step = data_distribute_cfg.lidar_sample_step
        self.camera_sample_step = data_distribute_cfg.camera_sample_step
        self.history_frame_num = previous_frames_num
        self.future_frames_num = future_frames_num

        self.padding_history = padding_history
        self.padding_future = padding_future

        if (max(self.lidar_query_lidar_key_num, self.camera_query_lidar_key_num) > self.history_frame_num) or min(
            self.lidar_query_lidar_key_num, self.camera_query_lidar_key_num
        ) < 0:
            raise ValueError("Lidar Key Num must in [0, history_frame_num]")

        # inherit from class lidar_multi_dataset
        self.debug_mode = debug
        self.task_name = task_name
        self.recls_by_size = recls_by_size
        self.gt_box_dim = gt_box_dim
        self.gt_cls_mapping = gt_cls_mapping
        self.keep_gt_names = list(self.gt_cls_mapping.keys())
        self.previous_frames_sample_step = previous_frames_sample_step
        self.future_frames_sample_step = future_frames_sample_step

        self.subiterator_manager = SubIteratorManager(
            mode,
            subiterator_cfg,
            shuffle=shuffle,
            batch_size=batch_size,
            debug_mode=debug,
            num_replicas=1,
            rank=0,
            dataloader_num_workers=dataloader_num_workers,
        )

        self.shuffle = shuffle
        self.epoch_length = training_epoch_length
        self.train_all_samples_each_epoch = train_all_samples_each_epoch
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.num_multiprocess_pkl_infos = num_multiprocess_pkl_infos
        self.multiprocess_dataworker_lock = RLock()
        self.n_gpu = dist.get_world_size()

        self.input_sensor_map = input_sensor_map
        self.dynamic_det_dim = dynamic_det_dim
        self.static_det_dim = static_det_dim

        self.tld_panel_dim = tld_panel_dim
        self.tsr_dim = tsr_dim
        self.adas_info_speed_lmt_dim = adas_info_speed_lmt_dim
        # clip training save root
        self.clip_training_download_root = _DEFAULT_CLIP_DOWNLOAD_ROOT
        if use_dataset_glob_cache:
            self.dataset_filepaths_cache = _HOME_CACHEDIR / "dataset_filepaths_cache.json"
            self.dataset_filepaths_cache.parent.mkdir(parents=True, exist_ok=True)

        self.box_size_indices = box_size_indices

        self.load_sample_cnt = 0
        self.drop_sample_cnt = 0

        data_meta = data_meta[self._mode]
        self.prepare_all_data(data_meta)
        logger.info("Dataset Init successfully!")

    def __len__(self) -> int:
        """Get length."""
        if "train" in self._mode:
            if not self.train_all_samples_each_epoch:
                return int(self.epoch_length / self.batch_size / self.n_gpu)
            else:
                return int(self.load_sample_cnt / self.batch_size / self.n_gpu)
        if "val" in self._mode or "vis" in self._mode or "test" in self._mode:
            return int(self.load_sample_cnt / self.batch_size)
        raise RuntimeError(f"get invalid mode: {self._mode}")

    def reset(self, step: int = 0):
        """Reset."""
        self.subiterator_manager.reset(step)

    @timer(vis=True)
    def prepare_all_data(self, data_meta):
        """Load data."""
        for name, info in data_meta.items():
            only_meta = info["only_meta"]
            dataset = info["datasets"]
            root_dir = info["root_dir"]
            if self.debug_mode:
                dataset = dataset[:1]

            # clip training
            annos, keep_cnt, drop_cnt = self.load_to_samples_mp(
                data_meta_dir=root_dir,
                datasets=dataset,
                meta_loader=only_meta,
                dataset_name=name,
            )
            if len(annos) < 1:
                logger.error(f"Load {name} failed. Skip.")
                continue
            self.drop_sample_cnt += drop_cnt
            self.subiterator_manager.add_samples(annos)

        self.subiterator_manager.init_all_subiterator()
        self.load_sample_cnt = len(self.subiterator_manager)

        logger.info(
            """\nDataset Summary:\n
                history_frame_num: %s/future_frames_num: %s\n
                keep_frame_cnt %s,\n drop_frame_cnt %s.\n
            """,
            self.history_frame_num,
            self.future_frames_num,
            self.load_sample_cnt,
            self.drop_sample_cnt,
        )

    def get_all_samples(self):
        """Get all samples."""
        return self.subiterator_manager.yield_all_subiterator_samples()

    @timer(vis=True)
    def download_ceph_files_concurrently(
        self, file_paths: List[str], num_workers: int = _TRAIN_PLATFORM_MAX_CPUS_PER_GPU
    ) -> List[Path]:
        """Download ceph files concurrently."""
        logger.info(f"Start to download {len(file_paths)} files.")
        files_metas = []

        _time = time.perf_counter()
        logger.info(f"Obtaining files information for {len(file_paths)} files.")
        with ThreadPoolExecutor(max_workers=_TRAIN_PLATFORM_MAX_CPUS_PER_GPU) as executor:
            splits_files_per_worker = [file_paths[i :: executor._max_workers] for i in range(executor._max_workers)]
            logger.info(f"Split files per worker: {[len(split_files) for split_files in splits_files_per_worker]}")
            # Overload files meta cache
            results = executor.map(
                get_paths_finfos,
                itertools.repeat(ceph_client),
                splits_files_per_worker,
                itertools.repeat(True),
                itertools.repeat(_SIZE_OUTLIER_MUL),
            )
            for res_list in results:
                files_metas.extend(res_list)
        logger.info(
            f"Obtained files information cache for {len(files_metas)} files. Time: {time.perf_counter() - _time} s."
        )

        # Distribute batches per workers
        def _download_files_batch(files_metas):
            # Group files_metas by bucket
            grouped_files_metas = [
                (bucket, list(bucket_files))
                for bucket, bucket_files in itertools.groupby(files_metas, key=lambda x: x[0].bucket)
            ]
            file_contents = []
            # We dont expect too many buckets so its ok
            for bucket, files_metas in grouped_files_metas:
                path_bytes = load_file_with_tag_from_cache(bucket=bucket, paths=files_metas)
                file_contents.extend(path_bytes)
            return file_contents

        res_paths = []
        with ThreadPoolExecutor(max_workers=num_workers) as executor:
            files_metas_per_worker = [files_metas[i :: executor._max_workers] for i in range(executor._max_workers)]
            logger.info(
                f"Split files per worker for downloads: {[len(split_files) for split_files in files_metas_per_worker]}"
            )
            results = tqdm(
                executor.map(_download_files_batch, files_metas_per_worker),
                total=len(files_metas_per_worker),
                initial=1,
                desc="Downloading files",
            )
            for i, paths in enumerate(results):
                if len(files_metas_per_worker[i]):
                    logger.info(f"Downloaded {len(files_metas_per_worker[i])} files.")
                    res_paths.extend(paths)  # type: ignore
        logger.info(f"Download {len(res_paths)} files finished.")
        return list(itertools.chain(res_paths))

    def _glob_files_search(self, data_meta_dir: str, datasets: List[str]) -> List[str]:
        logger.warning("Using glob to search files, this may take a long time for share-global directories.")

        @lru_cache
        def _load_glob_cache(
            cache_path: Path = self.dataset_filepaths_cache,
        ) -> Dict[str, Dict[str, List[str]]]:
            if cache_path.exists():
                # {data_meta_dir: {dataset_name: [file_path1, file_path2...]}}
                while True:
                    try:
                        with self.dataset_filepaths_cache.open("rb") as fin:
                            all_paths_map = json.loads(fin.read())
                        break
                    except:
                        logger.warning("Load dataset_filepaths_cache failed. Trying again")
                        time.sleep(1)
                logger.info("Loaded glob cache from %s", cache_path)
            else:
                all_paths_map = {}
                logger.warning("No dataset_filepaths_cache found.")
            return all_paths_map

        if self.use_dataset_glob_cache:
            all_paths_map = _load_glob_cache()
        else:
            all_paths_map = {}

        split_files = []
        for item in datasets:
            # Load from cache e.g. /share-global/planning_data/ "0707_10w_slimdata_v2/*/meta_data_*.txt
            if data_meta_dir in all_paths_map and item in all_paths_map[data_meta_dir]:
                split_files.extend(all_paths_map[data_meta_dir][item])
                logger.info("Found dataset %s in cache.", item)
                continue

            if data_meta_dir not in all_paths_map:
                all_paths_map[data_meta_dir] = {}

            if item not in all_paths_map[data_meta_dir]:
                all_paths_map[data_meta_dir][item] = []

            for txt_file in Path(data_meta_dir).rglob(item):
                with txt_file.open("r") as clip_file:
                    all_paths_map[data_meta_dir][item].extend([line.strip() for line in clip_file.readlines()])

            split_files.extend(all_paths_map[data_meta_dir][item])

        if self.use_dataset_glob_cache:
            # Save to cache
            with self.dataset_filepaths_cache.open("w") as fout:
                fout.write(json.dumps(all_paths_map))

        return split_files

    def _get_txtxs_paths(self, data_meta_dir: str, datasets: List[str]) -> List[str]:
        """Get paths from txt files by patterns, cache glob operation."""
        split_files = []
        for dataset in datasets:
            if Path(data_meta_dir, dataset).exists():
                with Path(data_meta_dir, dataset).open("r") as clip_file:
                    split_files.extend([line.strip() for line in clip_file.readlines()])
                continue

            if "*" in dataset or "?" in dataset:
                split_files.extend(self._glob_files_search(data_meta_dir, [dataset]))

            logger.error(
                "No files found in %s with dataset %s. Use * or ? for searching with rglob",
                data_meta_dir,
                dataset,
            )

        return sorted(list(set(split_files)))

    @timer(vis=True)
    def files_contents_to_samples_mp(
        self,
        files_contents_per_worker,
        dataset_name: str,
        meta_loader: bool,
        files_contents,
    ):
        """Load all infos."""
        sample_generator = SampleGenerator(self.history_frame_num, self.future_frames_num, self.slide_win_step)
        sample_filters: List[SampleFilter] = [
            PaddingFilter(self.history_frame_num, self.future_frames_num, self.input_sensor_map),
            TagIncludeFilter(self.included_tag_list),
            TagExcludeFilter(self.excluded_tag_list),
            RequiredFieldsFilter(self.required_fields),
        ]
        all_infos = []
        invalid_frames = 0
        total_frames = 0
        invalid_tag_frames = 0
        invalid_clip_num = 0
        # single process ------------------------
        if len(files_contents_per_worker) == 1:
            infos, stats = files_contents_to_samples_process(
                files_contents_per_worker[0],
                sample_generator,
                sample_filters,
                dataset_name,
                meta_loader,
                self.use_future,
            )
            all_infos.extend(infos)
            invalid_frames += stats["invalid_frames"]
            total_frames += stats["total_frames"]
            invalid_tag_frames += stats["invalid_tag_frames"]
        else:
            # multi process ------------------------
            # with ThreadPoolExecutor(max_workers=min(self.num_workers, len(files_contents_per_worker))) as executor:
            with ProcessPoolExecutor(max_workers=min(self.num_workers, len(files_contents_per_worker))) as executor:
                results = tqdm(
                    executor.map(
                        files_contents_to_samples_process,
                        files_contents_per_worker,
                        itertools.repeat(sample_generator),
                        itertools.repeat(sample_filters),
                        itertools.repeat(dataset_name),
                        itertools.repeat(meta_loader),
                        itertools.repeat(self.use_future),
                    ),
                    total=len(files_contents_per_worker),
                    initial=1,
                    colour="green",
                    desc="files_contents_to_samples_process",
                )

                for i, result in enumerate(results):
                    infos, stats = result
                    if result is None:
                        invalid_clip_num += len(files_contents_per_worker[i])
                        logger.error(f"Error loading clip: {invalid_clip_num}")
                        continue
                    all_infos.extend(infos)
                    # Update statistics
                    invalid_frames += stats["invalid_frames"]
                    total_frames += stats["total_frames"]
                    invalid_tag_frames += stats["invalid_tag_frames"]

        valid_clip_num = len(files_contents) - invalid_clip_num
        logger.info(
            "Load %d clips, %d valid clips, %d invalid clips.",
            len(files_contents),
            valid_clip_num,
            invalid_clip_num,
        )
        filter_frame_cnt = invalid_frames + invalid_tag_frames
        keep_frame_cnt = total_frames - filter_frame_cnt
        logger.info(
            f"""    \n : keep_frame_cnt: {keep_frame_cnt},\
                    \n : total_frames: {total_frames},\
                    \n : invalid_frames: {invalid_frames},\
                    \n : invalid_tag_frames: {invalid_tag_frames}\
                    """
        )
        all_infos.sort(key=lambda x: x["clip_path"])
        return (all_infos, keep_frame_cnt, filter_frame_cnt)

    @timer(vis=True)
    def load_to_samples_mp(
        self,
        data_meta_dir,
        datasets,
        meta_loader=True,
        dataset_name="4D_OD",
    ):
        # pylint: disable=logging-fstring-interpolation
        """Load all infos."""
        num_replicas = dist.get_world_size()
        rank = dist.get_rank()
        split_files = self._get_txtxs_paths(data_meta_dir, datasets)
        logger.info(f">>> Found {len(split_files)} files in {data_meta_dir} with datasets {datasets}.")
        if not split_files:
            raise ValueError(
                f"No files found in {data_meta_dir} with datasets {datasets}. Consider deleting filepaths cache at {self.dataset_filepaths_cache} and retry."
            )

        if self.debug_mode:
            split_files = split_files[:1]

        cur_gpu_split_files = split_files[: int(os.environ.get("DEBUG_SPLIT", len(split_files)))][rank::num_replicas]
        logger.info(f"Rank {rank} Total {len(split_files)} files to load.")
        print(f"Rank {rank} Total {len(split_files)} files to load.")

        download_list = []
        for file_path in cur_gpu_split_files:
            # download_list.add(file_path.replace("meta_data", "tags").replace(".pkl", "_tags.pkl"))
            # tags_path = re.sub(r"^([^/]+/[^/]+/)[^/]+", r"\1prod_v20240831_105w_tags", file_path)
            tag_path = "/".join(
                file_path.split("/")[0:2] + ["prod_yx_20240919_tags_only_all"] + file_path.split("/")[3:]
            )

            tag_path = os.path.join(
                os.path.dirname(tag_path).replace("meta_data", "tags"),
                os.path.basename(tag_path).replace(".pkl", "_tags.pkl"),
            )
            download_list.append([file_path, tag_path])

        files_contents = self.download_ceph_files_concurrently(list(download_list))

        files_contents_per_worker = [files_contents[i :: self.num_workers] for i in range(self.num_workers)]
        files_contents_per_worker = [i for i in files_contents_per_worker if i]
        assert len(files_contents_per_worker) > 0

        all_infos, keep_frame_cnt, filter_frame_cnt = self.files_contents_to_samples_mp(
            files_contents_per_worker, dataset_name, meta_loader, files_contents
        )
        return all_infos, keep_frame_cnt, filter_frame_cnt

    @staticmethod
    def _generate_cache_key(clip_path, sensor_type, batch_idx):
        return f"{os.path.basename(clip_path)}/{sensor_type}/{batch_idx}"

    @staticmethod
    def _parse_cache_key(cache_key):
        clip_path, sensor_type, batch_idx = cache_key.split("/")
        return clip_path, sensor_type, batch_idx

    def fetch_batch_meta_cache_infos(self, batch_data_pairs):
        """Fetch meta cache info."""
        # stopwatch2.tic()
        chunk_size_map = {}
        for batch_idx, data_pair in enumerate(batch_data_pairs):
            cephpath_filesize = data_pair["cephpath_filesize"]
            # load cache from ceph
            for state in ["history", "current", "future"]:
                item_state = data_pair["meta_info"][state]
                for _, frame in enumerate(item_state):
                    if frame is None:
                        continue

                    sensors = self.input_sensor_map[state]
                    ceph_file_root = os.path.dirname(os.path.dirname(data_pair["clip_path"]))
                    for sensor_type in sensors:
                        if sensor_type == "tags":
                            continue
                        if sensor_type not in cephpath_filesize or sensor_type not in frame:
                            print("sensor_type not in cephpath_filesize or sensor_type not in frame!!")
                            print(f"sensor_type: {sensor_type}")
                            print(data_pair["clip_path"])
                            print(cephpath_filesize)
                            print(frame)
                            continue

                        chunk_key = self._generate_cache_key(data_pair["clip_path"], sensor_type, batch_idx)
                        if chunk_key not in chunk_size_map:
                            chunk_size_map[chunk_key] = {
                                "path": f"/{ceph_file_root}/{sensor_type}.dat",
                                "size": cephpath_filesize[sensor_type],
                                "offset": frame[sensor_type][0],
                                "window_size": frame[sensor_type][1],
                                "frame_chunk_size": {
                                    frame["timestamp"]: [0, frame[sensor_type][1]],
                                },
                            }
                        else:
                            chunk_size_map[chunk_key]["window_size"] = (
                                frame[sensor_type][0] + frame[sensor_type][1] - chunk_size_map[chunk_key]["offset"]
                            )
                            chunk_size_map[chunk_key]["frame_chunk_size"][frame["timestamp"]] = [
                                frame[sensor_type][0] - chunk_size_map[chunk_key]["offset"],
                                frame[sensor_type][1],
                            ]

        ceph_file_list = [
            f"{chunk_size_map[key]['path']} {chunk_size_map[key]['size']} {chunk_size_map[key]['offset']} {chunk_size_map[key]['window_size']}"
            for key in chunk_size_map
        ]
        # stopwatch2.record_time_cost(f"sort infos len{len(ceph_file_list)}")
        ceph_bytes_list = read_cache_op_py(ceph_file_list)
        # stopwatch2.record_time_cost(f"read_cache_op_py len{len(ceph_file_list)}")
        meta_info_cache = {}
        for key_idx, key in enumerate(list(chunk_size_map.keys())):
            clip_path, sensor_type, batch_idx = self._parse_cache_key(key)
            if clip_path not in meta_info_cache:
                meta_info_cache[clip_path] = {}
            if sensor_type not in meta_info_cache[clip_path]:
                meta_info_cache[clip_path][sensor_type] = {}
            for ts in chunk_size_map[key]["frame_chunk_size"]:
                if ts not in meta_info_cache[clip_path][sensor_type]:
                    meta_info_cache[clip_path][sensor_type][ts] = {}
                frame_indice = chunk_size_map[key]["frame_chunk_size"][ts]
                meta_info_cache[clip_path][sensor_type][ts] = pickle.loads(
                    ceph_bytes_list[key_idx][frame_indice[0] : frame_indice[0] + frame_indice[1]]
                )
        # stopwatch2.record_time_cost(f"pickle.loads len{len(ceph_file_list)}")
        # stopwatch2.log_time_cost()
        return meta_info_cache

    def __getitem__(self, idx: int) -> Dict[str, Union[np.ndarray, int]]:
        """Get one item.

        Args:
            idx (scalar): The samplers on each rank generate same idx.
            The idx is produced by sample_idx + sample_indice_length * epoch_idx.
        """
        if torch.utils.data.get_worker_info() is not None:
            worker_id = torch.utils.data.get_worker_info().id
        else:
            worker_id = 0

        # stopwatch.tic()
        iterator, update_subtasks, only_meta = self.random_choice_iterator(idx)
        with self.multiprocess_dataworker_lock:
            batch_data_pairs = iterator.get_batch_data(worker_id)
        # stopwatch.record_time_cost("get batch data")

        if only_meta:
            while True:
                # load meta cache info first
                meta_info_cache = self.fetch_batch_meta_cache_infos(batch_data_pairs)
                # stopwatch.record_time_cost(f"fetch_batch_meta_cache_infos bs{len(batch_data_pairs)}.")

                new_batch_data_pairs = []
                for idx, data_pair in enumerate(batch_data_pairs):
                    pair_infos = self.convert_meta_info(data_pair, meta_info_cache)
                    if pair_infos is not None:
                        new_batch_data_pairs.append(pair_infos)
                # stopwatch.record_time_cost(f"convert_meta_info")

                if len(new_batch_data_pairs) == 0:
                    with self.multiprocess_dataworker_lock:
                        batch_data_pairs = iterator.get_batch_data(worker_id)
                        logger.error("Cur batch are all invalid, retrying...")
                    continue

                #### To be refined.
                def convert_dict_keys_to_list(obj):
                    if isinstance(obj, dict):
                        return {k: convert_dict_keys_to_list(v) for k, v in obj.items()}
                    elif isinstance(obj, list):
                        return [convert_dict_keys_to_list(item) for item in obj]
                    elif isinstance(obj, tuple):
                        return tuple(convert_dict_keys_to_list(item) for item in obj)
                    elif isinstance(obj, type({}.keys())):
                        return list(obj)
                    else:
                        return obj

                if len(new_batch_data_pairs) < len(batch_data_pairs):
                    lane_miss_sample_num = len(batch_data_pairs) - len(new_batch_data_pairs)
                    lane_miss_compensation = [
                        convert_dict_keys_to_list(new_batch_data_pairs[idx])
                        for idx in np.random.choice(len(new_batch_data_pairs), lane_miss_sample_num)
                    ]
                    new_batch_data_pairs.extend(lane_miss_compensation)
                ####

                if len(new_batch_data_pairs) < len(batch_data_pairs):
                    logger.warning(
                        f"Cur batch has invalid/valid/all: {len(batch_data_pairs) - len(new_batch_data_pairs)}/{len(new_batch_data_pairs)}/{len(batch_data_pairs)}."
                    )
                    for _ in range(len(batch_data_pairs) - len(new_batch_data_pairs)):
                        new_batch_data_pairs.append(copy.deepcopy(new_batch_data_pairs[-1]))
                batch_data_pairs = new_batch_data_pairs
                break

        results = []
        for one_sample_data_dict in batch_data_pairs:
            one_sample_data_dict["update_subtasks"] = update_subtasks

            if self._transforms is not None:
                one_sample_data_dict = self._transforms(one_sample_data_dict)
            results.append(one_sample_data_dict)

        # stopwatch.record_time_cost("transforms")
        # stopwatch.log_time_cost()
        return results  # type: ignore

    def random_choice_iterator(self, idx):
        """Random sample."""
        subiterator, update_subtasks = self.subiterator_manager.random_choice_subiterator(idx)
        only_meta = True
        return subiterator, update_subtasks, only_meta

    @staticmethod
    def _parse_bytes_from_buffer(bytes, shape, dtype=np.float32):
        return np.frombuffer(bytes, dtype=dtype).reshape(shape)

    def _parse_nested_list(self, data_list, shapes, dtype=np.float32):
        return [self._parse_bytes_from_buffer(data_list[i], shapes[i], dtype) for i in range(len(data_list))]

    def _parse_crop_images_list(self, crop_images_list, dtype=np.float32):
        parsed_list = []
        for crop_img_byte in crop_images_list:
            if crop_img_byte is not None:
                crop_img_raw = np.frombuffer(crop_img_byte, dtype=np.uint8)
                crop_img = cv2.imdecode(crop_img_raw, cv2.IMREAD_COLOR).reshape(-1)
            else:
                crop_img = np.zeros((64 * 64 * 3))
            parsed_list.append(crop_img)
        return np.array(parsed_list, dtype=dtype) / 255.0

    def convert_meta_info(self, data_pair_meta, meta_info_cache):
        """Convert meta info."""
        # stopwatch1.tic()
        data_pair = data_pair_meta["meta_info"]
        clip_cache = meta_info_cache[os.path.basename(data_pair_meta["clip_path"])]
        pair_infos = dict(current={}, history={})
        if self.use_future:
            pair_infos["future"] = {}

        subclip_id = None
        for state in ["current", "history", "future"]:
            item_state = data_pair[state]
            one_state = []
            for _, frame in enumerate(item_state):
                sensors = self.input_sensor_map[state]
                frame_anno_info = {}
                frame_anno_info["scene_type"] = "null"
                if frame is None:
                    frame_anno_info = {}
                    # TODO[stephen.wang]: add more features while history/future using more sensor input.
                    frame_anno_info["dynamic_dets"] = np.zeros((0, 40))
                    frame_anno_info["car_poses"] = np.eye(4)
                    frame_anno_info["ego_motion"] = np.zeros(11)  # TODO[stephen.wang]: using hardcode 11 here.
                    frame_anno_info["scene_type"] = "pad"
                    frame_anno_info["timestamps"] = 0
                    frame_anno_info["ids"] = "null"
                    frame_anno_info["tags"] = ["null"]
                else:
                    timestamp = frame["timestamp"]
                    frame_anno_info["timestamps"] = timestamp
                    frame_anno_info["ids"] = frame["ids"]
                    for sensor in sensors:
                        if sensor == "tags":
                            frame_anno_info["tags"] = frame["tags"] if "tags" in frame else ["null"]
                            continue
                        # hack navi line for no navilane
                        if sensor == "navi_line":
                            if sensor in clip_cache.keys():
                                info_bytes = clip_cache[sensor][timestamp]
                                for key in [
                                    "navi_line_points",
                                    "navi_lane_tld",
                                    "navi_lane_stoppoints",
                                ]:
                                    if key in ["navi_lane_tld"]:
                                        frame_anno_info[key] = self._parse_nested_list(
                                            info_bytes[key], info_bytes[f"{key}_shape"], dtype=np.int32
                                        )
                                    else:
                                        frame_anno_info[key] = self._parse_nested_list(
                                            info_bytes[key], info_bytes[f"{key}_shape"]
                                        )
                                    # print(key, info_bytes[f"{key}_shape"])
                                frame_anno_info["navi_line_types"] = 4 * np.ones(
                                    len(frame_anno_info["navi_line_points"]), dtype=np.float32
                                )
                            else:
                                frame_anno_info["navi_line_points"] = [np.zeros((60, 2), dtype=np.float32)]
                                frame_anno_info["navi_line_types"] = -1 * np.ones(1, dtype=np.float32)
                                frame_anno_info["navi_lane_tld"] = [np.zeros(3, dtype=np.int32)]
                                frame_anno_info["navi_lane_stoppoints"] = [np.zeros((1, 2), dtype=np.float32)]
                            continue

                        info_bytes = clip_cache[sensor][timestamp]
                        if sensor == "lane":
                            frame_anno_info["lane_points"] = self._parse_nested_list(
                                info_bytes["lane_points"], info_bytes[f"lane_points_shape"]
                            )
                            frame_anno_info["lane_types"] = self._parse_bytes_from_buffer(
                                info_bytes["lane_types"], info_bytes[f"lane_types_shape"]
                            )
                        elif sensor == "sdmap":
                            frame_anno_info["sdmap_geo"] = self._parse_nested_list(
                                info_bytes["sdmap"], info_bytes[f"sdmap_shape"]
                            )
                            frame_anno_info["sd_link_ids"] = self._parse_bytes_from_buffer(
                                info_bytes["sd_link_ids"],
                                info_bytes[f"sd_link_ids_shape"],
                                dtype=np.uint64,
                            )
                        elif sensor == "atlas":
                            frame_anno_info["atlas"] = {
                                "main_ground": self._parse_nested_list(
                                    info_bytes["atlas"]["main_ground"],
                                    info_bytes["atlas"]["main_ground_shape"],
                                ),
                                "foreground": self._parse_nested_list(
                                    info_bytes["atlas"]["foreground"],
                                    info_bytes["atlas"]["foreground_shape"],
                                ),
                                "unsafe_area": self._parse_nested_list(
                                    info_bytes["atlas"]["unsafe_area"],
                                    info_bytes["atlas"]["unsafe_area_shape"],
                                ),
                            }
                        elif sensor == "atlas_bev":
                            frame_anno_info["atlas_bev"] = self._parse_bytes_from_buffer(
                                info_bytes["atlas_bev"],
                                info_bytes["atlas_bev_shape"],
                                dtype=np.uint8,
                            )
                        elif sensor == "static_polys":
                            frame_anno_info["static_polys"] = np.frombuffer(
                                info_bytes["static_polys"]["points"], dtype=np.float32
                            ).reshape(-1, 2)
                            frame_anno_info["static_poly_split"] = info_bytes["static_polys"]["counts"]

                        elif sensor == "static_dets":
                            frame_anno_info[sensor] = self._parse_bytes_from_buffer(
                                info_bytes[sensor], info_bytes[f"{sensor}_shape"]
                            )
                            frame_anno_info["static_polys"] = np.frombuffer(
                                info_bytes["static_polys"]["points"], dtype=np.float32
                            ).reshape(-1, 2)
                            frame_anno_info["static_poly_split"] = info_bytes["static_polys"]["counts"]
                        elif sensor == "dynamic_gods":
                            frame_anno_info[sensor] = self._parse_bytes_from_buffer(
                                info_bytes[sensor], info_bytes[f"{sensor}_shape"]
                            )
                            frame_anno_info["dynamic_gods_polys"] = np.frombuffer(
                                info_bytes["dynamic_gods_polys"]["points"], dtype=np.float32
                            ).reshape(-1, 2)
                            frame_anno_info["dynamic_gods_polys_split"] = info_bytes["dynamic_gods_polys"]["counts"]

                        elif sensor == "meta":
                            frame_anno_info["car_poses"] = self._parse_bytes_from_buffer(info_bytes["car_pose"], (4, 4))
                            frame_anno_info["ego_motion"] = self._parse_bytes_from_buffer(
                                info_bytes["ego_motion"], (11,)
                            )  # vx,vy,acc_x,acc_y,yaw[2],yaw_rate[2],whlag,whlagspd,vehspd,lgta,chassis_yawrate

                            # TODO[stephen.wang]: backup for next version.
                            if state == "current":
                                subclip_id = info_bytes["subclip_id"]
                                frame_anno_info["global_routing"] = info_bytes["global_routing"]
                                frame_anno_info["turn_signal"] = info_bytes["turn_signal"]
                                frame_anno_info["adas_info"] = {
                                    "adas_info": self._parse_bytes_from_buffer(
                                        info_bytes["adas_info"]["adas_info"],
                                        info_bytes["adas_info"]["adas_info_shape"],
                                        dtype=np.int8,
                                    ),
                                    "navi_info": self._parse_nested_list(
                                        info_bytes["adas_info"]["navi_info"],
                                        info_bytes["adas_info"]["navi_info_shape"],
                                        dtype=np.int32,
                                    ),
                                    "map_loc": self._parse_bytes_from_buffer(
                                        info_bytes["adas_info"]["map_loc"],
                                        info_bytes["adas_info"]["map_loc_shape"],
                                        dtype=np.float64,
                                    ),
                                }
                        elif sensor == "car_pose":
                            frame_anno_info["delta_ts_carpose"] = {
                                "road_detection": self._parse_bytes_from_buffer(
                                    info_bytes["car_pose_per_topic"]["road_detection"]["car_pose"], (4, 4)
                                ),
                                "atlas": self._parse_bytes_from_buffer(
                                    info_bytes["car_pose_per_topic"]["atlas"]["car_pose"], (4, 4)
                                ),
                                "road_post": self._parse_bytes_from_buffer(
                                    info_bytes["car_pose_per_topic"]["road_post"]["car_pose"], (4, 4)
                                ),
                            }
                        elif sensor == "crop_images":
                            if "crop_images" not in info_bytes.keys() or len(info_bytes["crop_images"]) == 0:
                                frame_anno_info["crop_images"] = np.zeros(
                                    (frame_anno_info["dynamic_dets"].shape[0], 64 * 64 * 3)
                                )
                            else:
                                frame_anno_info["crop_images"] = self._parse_crop_images_list(info_bytes["crop_images"])
                        else:

                            frame_anno_info[sensor] = self._parse_bytes_from_buffer(
                                info_bytes[sensor], info_bytes[f"{sensor}_shape"]
                            )
                frame_anno_info["gt"] = np.empty((0, self.gt_box_dim))
                frame_anno_info["subclip_ids"] = subclip_id
                frame_anno_info["keys"] = clip_cache.keys()
                one_state.append(frame_anno_info)
            pair_infos.update({state: one_state})
            # stopwatch1.record_time_cost(f"parse state {state}: {len(item_state)} frames.")

        for state in ["current", "history", "future"]:
            pair_infos[state] = merge_multi_frame(pair_infos[state])
        if len(pair_infos["current"]["lane_points"][0]) == 0:
            return None
        # stopwatch1.log_time_cost()
        return pair_infos

    @staticmethod
    def _merge_features(obs_dict):
        """Merge the features in the observation dictionary into a single NumPy array."""
        # Flatten the dictionary values into a single list
        values = []
        for _, value in obs_dict.items():
            if isinstance(value, list):
                values.extend(value)
            else:
                values.append(value)
        # Convert the list to a NumPy array
        ret_np = np.array(values)

        return ret_np

    # pylint: disable=arguments-differ, too-many-locals.
    def batch_collate(self, data: List[Any]) -> Any:
        """Batch collate function.

        Args:
            data (List): List of `__getitem__` returns.
        """
        if len(data) != 1:
            raise RuntimeError(f"must be 1 but got {len(data)}")
        data = data[0]

        batch_ids = [data_entry["current"]["ids"][0] for data_entry in data]

        batch_current_bboxes = [data_entry["current"]["bboxes"] for data_entry in data]

        batch_carposes = np.stack(
            [
                np.vstack(
                    [
                        data_entry["history"]["car_poses"],
                        data_entry["current"]["car_poses"],
                    ]
                )
                for data_entry in data
            ],
            axis=0,
        ).astype(
            np.float32
        )  # B, T, 4, 4

        eye_matrix = np.eye(4)[None]
        batch_hist2curr_trans = np.stack(
            [
                np.vstack(
                    [
                        data_entry["history"]["hist2curr_trans"],  # T-1, 4, 4
                        eye_matrix,  # 1, 4, 4
                    ]
                )
                for data_entry in data
            ],
            axis=0,
        ).astype(
            np.float32
        )  # B, T, 4, 4

        batch_future2curr_trans = np.stack(
            [
                np.vstack(
                    [
                        data_entry["future"]["hist2curr_trans"],  # T-1, 4, 4
                        eye_matrix,  # 1, 4, 4
                    ]
                )
                for data_entry in data
            ],
            axis=0,
        ).astype(
            np.float32
        )  # B, T, 4, 4

        subclip_ids = [data_entry["current"]["subclip_ids"][0] for data_entry in data]
        keys = [data_entry["current"]["keys"] for data_entry in data]
        batch_items = {
            "update_subtasks": [data_entry["update_subtasks"] for data_entry in data],
            "subclip_ids": subclip_ids,
            "car_poses": torch.from_numpy(batch_carposes),
            "hist2curr_trans": torch.from_numpy(batch_hist2curr_trans),
            "future2curr_trans": torch.from_numpy(batch_future2curr_trans),
            "ids": batch_ids,
            "keys": keys,
            # od gt for current frame
            "4dgt_bboxes": batch_current_bboxes,
        }

        # stamp related inputs
        batch_egos = np.stack(
            [
                np.vstack(
                    [
                        data_entry["history"]["egos"][..., self.ego_box_feat_dims],  # [T-1, D]
                        data_entry["current"]["egos"][..., self.ego_box_feat_dims],  # [1, D]
                    ]
                )
                for data_entry in data
            ]
        ).astype(np.float32)[
            :,
            :,
            np.newaxis,
        ]  # [B, T, 1, D]
        batch_egos_padding_mask = np.stack(
            [
                data_entry["history"]["egos_padding_mask"] + data_entry["current"]["egos_padding_mask"]
                for data_entry in data
            ]
        ).astype(np.float32)[
            :,
            :,
            np.newaxis,
        ]  # [B, T, 1]

        batch_bboxes = np.stack(
            [
                np.vstack(
                    [
                        data_entry["history"]["dynamic_dets"],  # T-1, n_t, D
                        data_entry["current"]["dynamic_dets"],  # 1, n_t, D
                    ]
                )
                for data_entry in data
            ]
        ).astype(
            np.float32
        )  # [B, T, n_t, D]
        batch_bboxes_track_id = np.stack(
            [
                np.vstack(
                    [
                        data_entry["history"]["dynamic_dets"][..., 9],  # T-1, n_t
                        data_entry["current"]["dynamic_dets"][..., 9],  # 1, n_t
                    ]
                )
                for data_entry in data
            ]
        ).astype(np.float32)
        batch_bboxes_padding_mask = np.stack(
            [
                np.vstack(
                    [
                        data_entry["history"]["dynamic_dets_padding_mask"],  # T-1, n_t
                        data_entry["current"]["dynamic_dets_padding_mask"],  # 1, n_t
                    ]
                )
                for data_entry in data
            ],
        ).astype(
            np.float32
        )  # [B, T, n_t]

        # batch_asso_index = np.stack([data_entry["current"]["asso_index"] for data_entry in data])  # [B, 191, T]

        batch_ts = np.vstack(
            [
                np.array(
                    data_entry["history"]["timestamps"] + data_entry["current"]["timestamps"],
                    dtype=np.float64,
                )
                for data_entry in data
            ]
        )  # B, T
        batch_delta_ts = (batch_ts[:, -1:] - batch_ts).astype(np.float32)
        batch_scene_type = [data_entry["current"]["scene_type"][0] for data_entry in data]
        batch_items.update(
            {
                "bboxes": torch.from_numpy(batch_bboxes),
                "bboxes_padding_mask": torch.from_numpy(batch_bboxes_padding_mask),
                "bboxes_track_id": torch.from_numpy(batch_bboxes_track_id),
                # "asso_index": torch.from_numpy(batch_asso_index),
                "delta_timestamp": torch.from_numpy(batch_delta_ts),
                "timestamp": batch_ts,
                "egos": torch.from_numpy(batch_egos),
                "egos_padding_mask": torch.from_numpy(batch_egos_padding_mask),
                "scene_type": batch_scene_type,
            }
        )
        if "bev_feature_occ_driving" in data[0]["current"]:
            batch_bev_occ_driving = np.vstack(
                [[data_entry["current"]["bev_feature_occ_driving"]] for data_entry in data]
            )
            batch_items.update(
                {
                    "bev_feature_occ_driving": torch.from_numpy(batch_bev_occ_driving),
                }
            )
        if "bev_feature_static" in data[0]["current"]:
            batch_bev_static = np.vstack([[data_entry["current"]["bev_feature_static"]] for data_entry in data])
            batch_items.update(
                {
                    "bev_feature_static": torch.from_numpy(batch_bev_static),
                }
            )

        if "agent_decision_label" in data[0]["current"]:
            batch_agent_decision_label = np.vstack(
                [data_entry["current"]["agent_decision_label"] for data_entry in data]
            )
            batch_agent_decision_mask = np.vstack([data_entry["current"]["agent_decision_mask"] for data_entry in data])
            batch_items.update(
                {
                    "agent_decision_label": torch.from_numpy(batch_agent_decision_label),
                    "agent_decision_mask": torch.from_numpy(batch_agent_decision_mask),
                }
            )

        if "tags" in data[0]["current"]:
            batch_tags = [data_entry["current"]["tags"][0] for data_entry in data]
            batch_items.update({"tags": batch_tags})
        else:
            batch_items.update({"tags": [[] for _ in data]})

        if "sod_poly_boxes" in data[0]["current"]:
            batch_sod_poly_boxes = np.stack(
                [data_entry["current"]["sod_poly_boxes"] for data_entry in data]  # 1, n_t, D
            ).astype(np.float32)
            batch_sod_poly_boxes_padding_mask = np.stack(
                [data_entry["current"]["sod_poly_boxes_padding_mask"] for data_entry in data]  # 1, n_t
            ).astype(np.float32)
            batch_sod_poly_pts = np.stack(
                [data_entry["current"]["sod_poly_pts"] for data_entry in data]  # 1, n_t, D
            ).astype(np.float32)
            batch_sod_poly_pts_padding_mask = np.stack(
                [data_entry["current"]["sod_poly_pts_padding_mask"] for data_entry in data]  # 1, n_t
            ).astype(np.float32)

            batch_items.update(
                {
                    "sod_poly_boxes": torch.from_numpy(batch_sod_poly_boxes),
                    "sod_poly_boxes_padding_mask": torch.from_numpy(batch_sod_poly_boxes_padding_mask),
                    "sod_poly_pts": torch.from_numpy(batch_sod_poly_pts),
                    "sod_poly_pts_padding_mask": torch.from_numpy(batch_sod_poly_pts_padding_mask),
                }
            )

        if "god_poly_pts" in data[0]["current"]:
            batch_god_poly = np.stack([data_entry["current"]["god_poly_pts"] for data_entry in data])
            batch_god_poly_padding_mask = np.stack(
                [data_entry["current"]["god_poly_pts_padding_mask"] for data_entry in data]
            )
            batch_god_attrs = np.stack([data_entry["current"]["god_attrs"] for data_entry in data])
            batch_god_attr_padding_mask = np.stack(
                [data_entry["current"]["god_attr_padding_mask"] for data_entry in data]
            )
            batch_items.update(
                {
                    "god_poly_pts": torch.from_numpy(batch_god_poly),
                    "god_poly_pts_padding_mask": torch.from_numpy(batch_god_poly_padding_mask),
                    "god_attrs": torch.from_numpy(batch_god_attrs),
                    "god_attr_padding_mask": torch.from_numpy(batch_god_attr_padding_mask),
                }
            )

        if "crop_images" in data[0]["current"]:
            batch_crop_imgs = np.stack(
                [
                    np.vstack(
                        [
                            data_entry["current"]["crop_images"],  # 1, n_t, 64*64*3
                        ]
                    )
                    for data_entry in data
                ]
            ).astype(
                np.float32
            )  # [B, 1, n_t, 64*64*3]
            batch_items["crop_imgs"] = torch.from_numpy(batch_crop_imgs)

        if "tld" in data[0]["current"]:
            batch_tld = np.stack([data_entry["current"]["tld"] for data_entry in data]).astype(np.float32)
            batch_tld_padding_mask = np.stack(
                [data_entry["current"]["tld_padding_mask"] for data_entry in data]
            ).astype(np.float32)
            batch_items.update(
                {
                    "tld": torch.from_numpy(batch_tld),
                    "tld_padding_mask": torch.from_numpy(batch_tld_padding_mask),
                }
            )

        if self.use_future:
            batch_dets_pred_gt = np.stack(
                [data_entry["current"]["dynamic_dets_pred_gt"] for data_entry in data]
            )  # [48, 191, 30, 2]
            batch_dets_pred_mask = np.stack(
                [data_entry["current"]["dynamic_dets_pred_mask"] for data_entry in data]
            )  # [48, 191, 30]
            batch_det_pred_info_gt = np.stack(
                [data_entry["current"]["dynamic_dets_pred_full_info_gt"] for data_entry in data]
            )
            batch_items.update(
                {
                    "bboxes_pred_gt": torch.from_numpy(batch_dets_pred_gt.astype(np.float32)),
                    "bboxes_pred_mask": torch.from_numpy(batch_dets_pred_mask.astype(np.float32)),
                    "bboxes_det_pred_full_info_gt": torch.from_numpy(batch_det_pred_info_gt),
                }
            )

            if "egos_pred_gt" in data[0]["current"]:
                batch_egos_pred_gt = np.stack(
                    [data_entry["current"]["egos_pred_gt"] for data_entry in data]
                )  # [48, 1, 30, 2]
                batch_egos_pred_gt_transformed = np.stack([data_entry["trans"]["egos_pred_gt"] for data_entry in data])[
                    :, 0
                ]  # [B,1,T,2]
                batch_egos_pred_mask = np.stack(
                    [data_entry["current"]["egos_pred_mask"] for data_entry in data]
                )  # [B,1,T]
                batch_egos_pred_mask_transformed = np.stack(
                    [data_entry["trans"]["egos_pred_mask"] for data_entry in data]
                )[
                    :, 0
                ]  # [B,1,T]
                batch_egos_yaw_gt = np.stack(
                    [data_entry["current"]["egos_yaw_pred_gt"] for data_entry in data]
                )  # [batch, 1, future_horizon, 1]

                batch_items.update(
                    {
                        "egos_pred_gt": torch.from_numpy(batch_egos_pred_gt.astype(np.float32)),
                        "egos_pred_mask": torch.from_numpy(batch_egos_pred_mask.astype(np.float32)),
                        "egos_pred_gt_transformed": torch.from_numpy(batch_egos_pred_gt_transformed.astype(np.float32)),
                        "egos_pred_mask_transformed": torch.from_numpy(
                            batch_egos_pred_mask_transformed.astype(np.float32)
                        ),
                        "egos_yaw_pred_gt": torch.from_numpy(batch_egos_yaw_gt.astype(np.float32)),
                    }
                )

            if "dets_vel_pred_gt" in data[0]["current"]:
                batch_dets_vel_pred_gt = np.stack([data_entry["current"]["dets_vel_pred_gt"] for data_entry in data])
                batch_dets_vel_pred_mask = np.stack(
                    [data_entry["current"]["dets_vel_pred_mask"] for data_entry in data]
                )

                batch_items.update(
                    {
                        "bboxes_vel_pred_gt": torch.from_numpy(batch_dets_vel_pred_gt.astype(np.float32)),
                        "bboxes_vel_pred_mask": torch.from_numpy(batch_dets_vel_pred_mask.astype(np.float32)),
                    }
                )

            if "ego_vel_pred_gt" in data[0]["current"]:
                batch_ego_vel_pred_gt = np.stack(
                    [data_entry["current"]["ego_vel_pred_gt"] for data_entry in data]
                )  # [B,T,2]
                batch_ego_vel_pred_gt_transformed = np.stack(
                    [data_entry["trans"]["ego_vel_pred_gt"] for data_entry in data]
                )[
                    :, 0
                ]  # [B,T,2]
                batch_items.update(
                    {
                        "ego_vel_pred_gt": torch.from_numpy(batch_ego_vel_pred_gt.astype(np.float32)),
                        "ego_vel_pred_gt_transformed": torch.from_numpy(
                            batch_ego_vel_pred_gt_transformed.astype(np.float32)
                        ),
                    }
                )

            if "ego_steering_wheel_pred_gt" in data[0]["current"]:
                batch_ego_steering_wheel_pred_gt = np.stack(
                    [data_entry["current"]["ego_steering_wheel_pred_gt"] for data_entry in data]
                )

                batch_items.update(
                    {
                        "ego_steering_wheel_pred_gt": torch.from_numpy(
                            batch_ego_steering_wheel_pred_gt.astype(np.float32)
                        ),
                    }
                )

            if "ego_acc_pred_gt" in data[0]["current"]:
                batch_ego_acc_pred_gt = np.stack([data_entry["current"]["ego_acc_pred_gt"] for data_entry in data])

                batch_items.update(
                    {
                        "ego_acc_pred_gt": torch.from_numpy(batch_ego_acc_pred_gt.astype(np.float32)),
                    }
                )

            if "ego_yaw_rate_pred_gt" in data[0]["current"]:
                batch_ego_yaw_rate_pred_gt = np.stack(
                    [data_entry["current"]["ego_yaw_rate_pred_gt"] for data_entry in data]
                )

                batch_items.update(
                    {
                        "ego_yaw_rate_pred_gt": torch.from_numpy(batch_ego_yaw_rate_pred_gt.astype(np.float32)),
                    }
                )

            if "priority_gt" in data[0]["current"]:
                batch_priority_gt = np.stack([data_entry["current"]["priority_gt"] for data_entry in data])
                batch_items.update(
                    {
                        "priority_gt": torch.from_numpy(batch_priority_gt),
                    }
                )

        if "lane_points" in data[0]["current"]:
            batch_lane_points = np.stack(
                [data_entry["current"]["lane_points"] for data_entry in data]
            )  # [48, 191, 30, 2]
            batch_lane_types = np.stack([data_entry["current"]["lane_types"] for data_entry in data])  # [48, 191, 30]
            batch_items.update(
                {
                    "lane_points": torch.from_numpy(batch_lane_points),
                    "lane_types": torch.from_numpy(batch_lane_types),
                }
            )

        # group atlas batch
        if "atlas" in data[0]["current"]:
            if "atlas_in_polar" in data[0]["current"]:
                nmax_pts = max([batch["current"]["atlas_in_polar"].shape[1] for batch in data])
                max_plg = max([batch["current"]["atlas_in_polar"].shape[0] for batch in data])
                polygons_all = []
                for batch in data:
                    polygons = batch["current"]["atlas_in_polar"]
                    polygons_all.append(
                        np.pad(
                            polygons,
                            (
                                (0, max_plg - polygons.shape[0]),
                                (0, nmax_pts - polygons.shape[1]),
                                (0, 0),
                            ),
                            mode="constant",
                            constant_values=-1,
                        )
                    )
                batch_items.update(
                    {
                        "atlas": torch.from_numpy(np.stack(polygons_all, axis=0)),
                    }
                )
            else:
                batch_atlas_polygons = np.stack(
                    [data_entry["current"]["atlas_polygons"] for data_entry in data]
                )  # (b, nplg, npts, 2)
                batch_atlas_type = np.stack(
                    [data_entry["current"]["atlas_polygons_type"] for data_entry in data]
                )  # (b, nplg, npts, type_dim)
                batch_atlas = np.concatenate([batch_atlas_polygons, batch_atlas_type], axis=-1)
                batch_items.update({"atlas": torch.from_numpy(batch_atlas)})

        if "atlas_bev" in data[0]["current"]:
            batch_atla_bev = np.stack([data_entry["current"]["atlas_bev_cls"] for data_entry in data])
            batch_items.update(
                {
                    "atlas": torch.from_numpy(batch_atla_bev.astype(np.float32)),
                }
            )

        # group sdmap polylines
        if "sdmap_polylines" in data[0]["current"]:
            batch_sdmap_polylines = np.stack(
                [data_entry["current"]["sdmap_polylines"] for data_entry in data]
            )  # (b, npl, bpts, 2)
            batch_sdmap_polylines_padding_mask = np.stack(
                [data_entry["current"]["sdmap_polylines_type"] for data_entry in data]
            )  # (b, npl, bpts)
            batch_items.update(
                {
                    "sdmap_polylines": torch.from_numpy(batch_sdmap_polylines),
                    "sdmap_polylines_type": torch.from_numpy(batch_sdmap_polylines_padding_mask),
                }
            )

        # process adas_info
        if "adas_info" in data[0]["current"]:
            speed_lmt_batch = []
            navi_info_batch = []
            map_loc_batch = []
            road_class_batch = []
            lanenr_info_batch = []
            adasmap_valid_batch = []
            adasmap_is_on_highway = []
            for data_entry in data:
                if data_entry["current"]["adas_info"][0]["adas_info"].shape[0] > 0:
                    # process adas_info part
                    adasmap_valid_batch.append(data_entry["current"]["adas_info"][0]["adas_info"][0].astype(np.float32))
                    adasmap_is_on_highway.append(
                        data_entry["current"]["adas_info"][0]["adas_info"][1].astype(np.float32)
                    )
                else:
                    adasmap_valid_batch.append(0)
                    adasmap_is_on_highway.append(0)

                if len(data_entry["current"]["adas_info"][0]["navi_info"]) > 0:
                    # process navi info
                    current_navi_info = data_entry["current"]["adas_info"][0]["navi_info"]
                    tbt = current_navi_info[0][:4]
                    road_class = current_navi_info[0][-1:]
                    lanenr_info = current_navi_info[0][4:-1]
                    if len(lanenr_info) > 2:
                        assert "laner_info length is more than 2"

                    tbt_info_np = np.array(tbt)
                    lanenr_info_np = np.array(lanenr_info)
                    road_class_np = np.array(road_class)

                    adas_segment = current_navi_info[1]
                    speed_lmt_np = np.zeros([self.adas_info_speed_lmt_dim])
                    speed_lmt_cnt = np.zeros([self.adas_info_speed_lmt_dim])
                    if adas_segment.shape[0] > 0:
                        for i in range(adas_segment.shape[0]):
                            acc_speed = speed_lmt_np[adas_segment[i, 1]] * speed_lmt_cnt[adas_segment[i, 1]]
                            speed_lmt_cnt[adas_segment[i, 1]] += 1
                            speed_lmt_np[adas_segment[i, 1]] = (acc_speed + (adas_segment[i, 0] / 3.6)) / speed_lmt_cnt[
                                adas_segment[i, 1]
                            ]
                    else:
                        speed_lmt_np = np.zeros([self.adas_info_speed_lmt_dim])
                    navi_info_batch.append(tbt_info_np)
                    road_class_batch.append(road_class_np)
                    # lanenr_info_batch.append(lanenr_info_np)
                    speed_lmt_batch.append(speed_lmt_np)
                else:
                    speed_lmt_batch.append(np.zeros((self.adas_info_speed_lmt_dim,)))
                    navi_info_batch.append(np.zeros((4,)))
                    road_class_batch.append(np.zeros((1,)))
                    # lanenr_info_batch.append(np.zeros((2,)))
                lanenr_info_batch.append(np.zeros((2,)))

                if data_entry["current"]["adas_info"][0]["map_loc"].shape[0] > 0:
                    map_loc_batch.append(data_entry["current"]["adas_info"][0]["map_loc"])
                else:
                    map_loc_batch.append(np.zeros((3,), dtype=np.float32))

            batch_speed_lmt = np.vstack(speed_lmt_batch).astype(np.float32)
            batch_navi_info = np.vstack(navi_info_batch).astype(np.float32)
            batch_lanenr_info = np.vstack(lanenr_info_batch).astype(np.float32)
            batch_road_class = np.vstack(road_class_batch).astype(np.float32)
            batch_map_loc = np.vstack(map_loc_batch).astype(np.float32)
            batch_adasmap_valid = np.vstack(adasmap_valid_batch).astype(np.float32)
            batch_adasmap_onhighway = np.vstack(adasmap_is_on_highway).astype(np.float32)

            batch_items.update(
                {
                    "speed_lmt": torch.from_numpy(batch_speed_lmt),
                    "navi_info": torch.from_numpy(batch_navi_info),
                    "lanenr_info": torch.from_numpy(batch_lanenr_info),
                    "road_class": torch.from_numpy(batch_road_class),
                    "batch_map_loc": torch.from_numpy(batch_map_loc),
                    "is_on_highway": torch.from_numpy(batch_adasmap_onhighway),
                    "is_adasinfo_valid": torch.from_numpy(batch_adasmap_valid),
                }
            )

        batch_items["egos_size"] = batch_items["egos"][:, -1, :, self.box_size_indices[0] : self.box_size_indices[1]]  # type: ignore
        batch_items["bboxes_size"] = batch_items["bboxes"][  # type: ignore
            :, -1, :, self.box_size_indices[0] : self.box_size_indices[1]
        ]

        # process global routing info
        if "global_routing" in data[0]["current"] and "sd_link_ids" in data[0]["current"]:
            has_routing_valid_list = []
            global_matching_state_list = []
            global_routing_mask_list = []
            for data_entry in data:
                global_matching_state = data_entry["current"]["global_routing"][0]["matching_state"]
                current_link_id = data_entry["current"]["global_routing"][0]["current_hd_link_id"]
                global_rt = data_entry["current"]["global_routing"][0]["hd_link_segments"]

                map_link_id_list = data_entry["current"]["filtered_sd_link_ids"]

                common_element = list(set(map_link_id_list).intersection(global_rt))
                global_routing_valid = (
                    global_matching_state == 1 or global_matching_state == 6 or global_matching_state == 2
                )
                has_routing_valid_list.append(len(common_element) > 0)
                global_matching_state_list.append(global_routing_valid)

                global_routing_mask = np.zeros(len(map_link_id_list), dtype=bool)
                for i in range(map_link_id_list.shape[0]):
                    global_routing_mask[i] = map_link_id_list[i] in common_element

                if len(map_link_id_list) < data_entry["current"]["sdmap_polylines"].shape[0]:
                    delta_lane_num = data_entry["current"]["sdmap_polylines"].shape[0] - len(map_link_id_list)
                    global_routing_mask = np.concatenate([global_routing_mask, np.zeros(delta_lane_num)], axis=0)
                global_routing_mask_list.append(global_routing_mask)

            batch_global_routing_mask = torch.from_numpy(np.vstack(global_routing_mask_list)).float()
            batch_has_routing_valid = torch.from_numpy(np.array(has_routing_valid_list)).unsqueeze(-1)
            batch_global_matching_state = torch.from_numpy(np.array(global_matching_state_list)).unsqueeze(-1)

            batch_items.update(
                {
                    "global_routing_mask": batch_global_routing_mask,
                    "has_routing_valid": batch_has_routing_valid,
                    "global_matching_state": batch_global_matching_state,
                }
            )

        if "navi_line_points" in data[0]["current"]:
            batch_navi_line_points = np.stack([data_entry["current"]["navi_line_points"] for data_entry in data])
            batch_navi_line_types = np.stack([data_entry["current"]["navi_line_types"] for data_entry in data])
            batch_navi_lane_tld = np.stack([data_entry["current"]["navi_lane_tld"] for data_entry in data])
            batch_navi_lane_stoppoints = np.stack(
                [data_entry["current"]["navi_lane_stoppoints"] for data_entry in data]
            )

            batch_items.update(
                {
                    "navi_line_points": torch.from_numpy(batch_navi_line_points),
                    "navi_line_types": torch.from_numpy(batch_navi_line_types),
                    "navi_lane_tld": torch.from_numpy(batch_navi_lane_tld),
                    "navi_lane_stoppoints": torch.from_numpy(batch_navi_lane_stoppoints),
                }
            )

        for static_key in ("road_detection", "atlas", "road_post"):
            batch_items.update(
                {
                    f"{static_key}_veh2ref": torch.from_numpy(
                        np.stack([data_entry["current"][f"{static_key}_veh2ref"] for data_entry in data])
                    )
                }
            )

        if "lane_collision_map" in data[0]["current"]:
            batch_lane_collision_map = np.stack([data_entry["current"]["lane_collision_map"] for data_entry in data])
            batch_items.update(
                {
                    "lane_collision_map": torch.from_numpy(batch_lane_collision_map),
                }
            )

        return batch_items
