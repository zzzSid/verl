import json
import time
import os
from array import array
from typing import Dict, List, Tuple


class TagStorage:

    def __init__(self):
        # 字符串池
        self.string_pool = {}
        self.string_list = []

        # 使用数组存储数据
        self.clip_ids = array('I')
        self.clip_start_idx = array('I')
        self.tag_types = array('I')
        self.tag_names = array('I')
        self.start_times = array('d')
        self.end_times = array('d')

        # 【关键优化1】添加反向索引：clip_id -> 位置（O(1)查找）
        self.clip_id_to_pos = {}  # clip_id字符串 -> 在数组中的位置

        # 【关键优化2】缓存常用的tag_name查询
        self.tag_name_cache = {}  # tag_name -> [(clip_id, start_time, end_time), ...]

        self.stats = {
            'total_clips': 0,
            'total_tags': 0,
            'unique_strings': 0
        }

    def _get_string_id(self, s: str) -> int:
        """获取字符串ID（自动去重）"""
        if s not in self.string_pool:
            self.string_pool[s] = len(self.string_list)
            self.string_list.append(s)
            self.stats['unique_strings'] = len(self.string_list)
        return self.string_pool[s]

    def add_clip(self, clip_id: str, tags: list):
        """添加一个clip的所有tags"""
        # 记录起始位置
        current_pos = len(self.clip_ids)
        self.clip_start_idx.append(len(self.start_times))

        # 存储clip_id
        clip_id_idx = self._get_string_id(clip_id)
        self.clip_ids.append(clip_id_idx)

        # 【关键优化】建立反向索引
        self.clip_id_to_pos[clip_id] = current_pos

        # 存储所有tags
        for tag in tags:
            tag_type = tag.get('tag_type', '')
            tag_name = tag.get('tag_name', '')
            start_time = tag.get('start_time', 0)
            end_time = tag.get('end_time', 0)

            self.tag_types.append(self._get_string_id(tag_type))
            self.tag_names.append(self._get_string_id(tag_name))
            self.start_times.append(float(start_time))
            self.end_times.append(float(end_time))

            self.stats['total_tags'] += 1

        self.stats['total_clips'] += 1

    def get_tags(self, clip_id: str) -> List[Tuple]:

        # 【关键优化】直接通过字典查找位置，O(1)
        pos = self.clip_id_to_pos.get(clip_id)
        if pos is None:
            return []

        start_idx = self.clip_start_idx[pos]
        end_idx = self.clip_start_idx[pos+1] if pos+1 < len(self.clip_start_idx) else len(self.start_times)

        # 批量构建结果（优化循环）
        tags = []
        string_list = self.string_list  # 本地变量加速访问
        tag_types = self.tag_types
        tag_names = self.tag_names
        start_times = self.start_times
        end_times = self.end_times

        for i in range(start_idx, end_idx):
            tags.append((
                # string_list[tag_types[i]],
                string_list[tag_names[i]],
                start_times[i],
                end_times[i]
            ))

        return tags


    def search_by_tag_name(self, tag_name: str, use_cache: bool = True) -> List[Tuple[str, float, float]]:
        """【带缓存】搜索包含特定tag_name的所有clip"""

        # 【关键优化】使用缓存
        if use_cache and tag_name in self.tag_name_cache:
            return self.tag_name_cache[tag_name][:]  # 返回副本

        tag_name_idx = self.string_pool.get(tag_name)
        if tag_name_idx is None:
            return []

        results = []
        # 预计算所有clip的边界
        clip_boundaries = []
        for i in range(len(self.clip_ids)):
            start = self.clip_start_idx[i]
            end = self.clip_start_idx[i+1] if i+1 < len(self.clip_start_idx) else len(self.start_times)
            clip_boundaries.append((start, end, self.string_list[self.clip_ids[i]]))

        # 搜索所有tags
        for i in range(len(self.tag_names)):
            if self.tag_names[i] == tag_name_idx:
                # 找到包含这个tag的clip
                for start, end, clip_id in clip_boundaries:
                    if start <= i < end:
                        results.append((clip_id, self.start_times[i], self.end_times[i]))
                        break

        # 缓存结果
        if use_cache:
            self.tag_name_cache[tag_name] = results

        return results

    def precompute_tag_index(self, tag_names: List[str]):
        """【预计算】预先建立常用tag的索引，大幅提升搜索速度"""
        print(f"\n预计算 {len(tag_names)} 个tag的索引...")
        start_time = time.time()

        for tag_name in tag_names:
            self.search_by_tag_name(tag_name, use_cache=True)

        elapsed = time.time() - start_time
        print(f"预计算完成! 耗时: {elapsed:.2f}s, 缓存了{len(self.tag_name_cache)}个tag")
