# -*- coding: utf-8 -*-
import numpy as np

from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import ego2global
from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import etc_sematic_to_road_sign


class TollGateCenterline:
    def __init__(
        self,
        extend_thres=5.0,
    ):

        self.extend_thres = extend_thres

    def _create_empty_navi_info(self):
        navi_info = {
            "main_action_1": 0,
            "assistant_action_1": 0,
            "link_main_distance_1": -1,
            "main_action_2": 0,
            "assistant_action_2": 0,
            "link_main_distance_2": -1,
            "lane_infos": [],
            "sub_path_main_path_points": None,
            "sub_path_sub_path_points": [],
            "lane_nr_remain_distance": -1,
            "checkpoints": [],
            "navi_centerlines": [],
        }
        return navi_info

    def extend_toll_gate_centerline(self, line_points):
        if len(line_points) < 2:
            return line_points

        p0 = line_points[0]
        p1 = line_points[1]
        # 计算方向向量并归一化
        direction = p0 - p1
        unit_direction = direction / np.linalg.norm(direction)
        # 计算延伸点
        new_point1 = p0 + unit_direction * self.extend_thres
        new_point2 = p0 + unit_direction * self.extend_thres * 2
        new_points = np.vstack([new_point2, new_point1, line_points])
        return new_points

    def calc_toll_gate_centerline(self, data, timestamps):
        # 获取ETC center_line出现的time
        label_time_index = [len(timestamps) - 1, 0]

        gate_type_list_time = {}
        for ts_idx, ts in enumerate(timestamps):
            # manner ceterline
            manner_centerline = data[ts].get("manner_lane_center_lines", [])
            data_item = data[ts]
            lanes = data_item["manner_lane_points"]
            types = data_item["manner_lane_types"]
            attrs = data_item["manner_lane_attr"]
            road_arrows = []
            for p, t, a in zip(lanes, types, attrs):
                """
                p为N个点坐标(x, y): N * 2
                t为整条lane的类型:  1
                a为每个point的类型: N * 2
                """
                if t == 3 and a[0][0] in [204, 209, 212] and a[0][1] == 99999:  # gate mock road_sign
                    road_arrows.append([p, a[0][0]])

            gate_centerline_list = []
            for i, (p, ptype) in enumerate(road_arrows):
                center = p[:, :2].mean(axis=0)
                for index, center_line in enumerate(manner_centerline):
                    if len(center_line["points"]) < 1 or any(sublist[0] == index for sublist in gate_centerline_list):
                        continue

                    new_points = center_line["points"]
                    if np.linalg.norm(new_points[0][:2] - center) < 0.5:
                        gate_centerline_list.append([index, center_line["id"], ptype])

                        if center_line["id"] in gate_type_list_time:
                            gate_type_list_time[center_line["id"]].append([new_points[0][0], new_points[0][1], ptype])
                        else:
                            gate_type_list_time[center_line["id"]] = [[new_points[0][0], new_points[0][1], ptype]]

                        break

            if len(gate_centerline_list) > 0 and ts_idx < label_time_index[0]:
                label_time_index[0] = ts_idx

            if len(gate_centerline_list) > 0 and label_time_index[1] < len(timestamps) - 1:
                label_time_index[1] = ts_idx

        if label_time_index[1] < len(timestamps) - 1 and label_time_index[0] == 0:
            label_time_index[1] = len(timestamps) - 1

        if label_time_index[1] > label_time_index[0]:
            # 语义信息抖动处理
            center_line_type_map = {}
            for lane_id, type_infos in gate_type_list_time.items():
                has_204 = (
                    any(all(frame[2] == 204 for frame in type_infos[i : i + 7]) for i in range(len(type_infos) - 6))
                    if len(type_infos) >= 7
                    else False
                )

                if has_204:
                    filter_type = 204
                else:
                    near_range_type = [type_info[2] for type_info in type_infos if type_info[0] < 40 and type_info[0] > 5]
                    if len(near_range_type) < 10:
                        near_range_type = [type_info[2] for type_info in type_infos[-10:]]

                    type_counts = {}
                    for detection in near_range_type:
                        if detection not in type_counts:
                            type_counts[detection] = 0
                        type_counts[detection] += 1

                    filter_type = max(type_counts.items(), key=lambda x: x[1])[0]
                center_line_type_map[lane_id] = etc_sematic_to_road_sign.get(filter_type, 1002)

            # 站前timestamps划分
            sub_timestamps = timestamps[label_time_index[0] : label_time_index[1] + 1]
            trajpose = [data[ts]["car_pose"] for ts in sub_timestamps]  # 后轴
            init_pose = trajpose[0]

            # shift = np.eye(4)  # I
            # shift[:3, 3] = [1.4, 0, 0]
            # egocenter_pose = [t @ shift for t in trajpose]  # 转到自车中心

            for index, ts in enumerate(timestamps):
                if index > label_time_index[1] or index < label_time_index[0]:
                    continue
                # convert to current ts
                # curr_center_pose = egocenter_pose[index-label_time_index[0]]
                # inv_center_pose = np.linalg.inv(curr_center_pose)
                # env_start = inv_center_pose @ trajpose[0]  # 开始时刻自车后轴到ts自车中心系矩阵
                # env_T = inv_center_pose @ trajpose[index-label_time_index[0]] #ts时刻自车后轴到自车中心系矩阵
                curr_backwheel_pose = trajpose[index - label_time_index[0]]
                inv_backwheel_pose = np.linalg.inv(curr_backwheel_pose)
                env_T = inv_backwheel_pose @ init_pose

                # centerline
                centerlines = []
                for manner_centerline_id, ptype in center_line_type_map.items():

                    for iter_lane in data[ts]["manner_lane_center_lines"]:
                        if iter_lane["id"] != manner_centerline_id or len(iter_lane["points"]) < 2:
                            continue
                        start_point = np.zeros((0, 3), dtype=np.float32)
                        for label_start_lane in data[timestamps[label_time_index[0]]]["manner_lane_center_lines"]:
                            if label_start_lane["id"] == manner_centerline_id and len(label_start_lane["points"]) >= 2:
                                start_point = label_start_lane['points'][:1]
                                break

                        start_point = ego2global(start_point, env_T)
                        new_points = iter_lane["points"]
                        extend_points = self.extend_toll_gate_centerline(new_points)
                        # gate_type = (road_arrow_to_lane_direction_mapping[ptype] << 1)
                        centerlines.append(
                            {
                                "start_point": start_point[0] if start_point.size else [],
                                "points": new_points,
                                "extend_points": extend_points,
                                "type": ptype,
                                "id": manner_centerline_id,
                            }
                        )

                data[ts]["toll_gate_center_line"] = centerlines

        return data


global_toll_gate_centerline = TollGateCenterline()
