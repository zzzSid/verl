# -*- coding: utf-8 -*-
import numpy as np

from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import ecef_points_to_vehicle
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import ego2global
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import get_rotated_rectangle
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import transform_obj


class NaviCenterline:
    def __init__(
        self,
        label_start=300.0,
        label_end=5.0,
        match_lanenr_range=60.0,
        scene_filter_start=300.0,
        scene_filter_end=0.0,
        entry_dist_min_filter=50.0,
        entry_dist_max_filter=300.0,
        lanenr_dist_min_filter=50.0,
        lanenr_dist_max_filter=150.0,
        stitch_interval=30.0,
    ):

        self.label_range = [label_start, label_end]
        self.match_lanenr_range = match_lanenr_range
        self.scene_filter_range = [scene_filter_start, scene_filter_end]
        self.entry_dist_filter = [entry_dist_min_filter, entry_dist_max_filter]
        self.lanenr_dist_filter = [lanenr_dist_min_filter, lanenr_dist_max_filter]
        self.stitch_interval = stitch_interval

    def _create_empty_navi_info(self):
        navi_info = {
            "main_action_1": 0,
            "assistant_action_1": 0,
            "link_main_distance_1": -1,
            "main_action_2": 0,
            "assistant_action_2": 0,
            "link_main_distance_2": -1,
            "lane_infos": [],
            "sub_path_main_path_points": None,
            "sub_path_sub_path_points": [],
            "lane_nr_remain_distance": -1,
            "checkpoints": [],
            "navi_centerlines": [],
        }
        return navi_info

    def parse_navi_info(self, data, future_timestamps):

        # 解析lane nr
        navi_info_all = []
        scene_info_all = []

        for ts in future_timestamps:
            # lanenr parse
            link_info = data[ts]["link_info"]
            map_loc = data[ts]["map_loc"]
            navi_info = self._create_empty_navi_info()
            if link_info and "link_index" in map_loc:
                link_index = map_loc["link_index"]
                link_remain_distance = map_loc["link_remain_dist"]
                # next available lane_nr_info
                link_index_next_lane = -1
                for link_id in range(link_index, len(link_info)):
                    if link_info[link_id]["lane_nr_info"]:
                        link_index_next_lane = link_id
                        break
                if link_index_next_lane >= 0:
                    lane_nr_info = link_info[link_index_next_lane]["lane_nr_info"]
                    lane_nr_distance = link_remain_distance
                    if link_index != link_index_next_lane:
                        for i in range(link_index + 1, link_index_next_lane + 1):
                            lane_nr_distance += link_info[i]["cal_link_length"]
                else:
                    lane_nr_info = []
                    lane_nr_distance = -1
                navi_info["lane_nr_remain_distance"] = lane_nr_distance
                # action lane_nr_info
                for info in lane_nr_info:
                    lane_direction = info["lane_direction"]
                    lane_highline_direction = info["lane_highline_direction"]

                    lane_is_drivable = info["lane_is_drivable"]
                    lane_is_highline = info["lane_is_highline"]
                    navi_info["lane_infos"].append(
                        [lane_direction, lane_highline_direction, lane_is_drivable, lane_is_highline, info["lane_type"]]
                    )
            navi_info_all.append(navi_info)

            # scene info
            scene_info = []
            manner_scene_info = data[ts].get("manner_scene_info", None)
            if manner_scene_info is not None:
                for scene in manner_scene_info:
                    scene_info.append(
                        [
                            scene["distance_to_entry"],
                            scene["distance_to_exit"],
                            scene["scene_type"],
                            scene["is_controlled_by_traffic_light"],
                            scene["turn_direction"],
                            scene["id"],
                        ]
                    )
            scene_info_all.append(scene_info)

        return navi_info_all, scene_info_all

    def _select_navi_scene_id(self, navi_info_all, scene_info_all):

        # id
        unique_scene_id = []

        for i in range(len(navi_info_all)):
            lanenr_distance = navi_info_all[i]["lane_nr_remain_distance"]
            for scene_info in scene_info_all[i]:
                # type 1 unkown, 2 junction,
                # turn 0 unkown, 1 straight, 2 left, 3 right, 4 turn around left, 5 turn around right
                scene_entry = scene_info[0]
                scene_exit = scene_info[1]
                is_controlled_by_traffic_light = scene_info[3]
                turn_direction = scene_info[4]
                id = scene_info[5]
                if (
                    id not in unique_scene_id
                    and (
                        scene_entry < self.scene_filter_range[0]
                        and scene_entry > 0.0
                        and scene_exit > self.scene_filter_range[1]
                    )
                    and (is_controlled_by_traffic_light or turn_direction not in [0, 1])
                    and (
                        abs(lanenr_distance - scene_entry) < self.match_lanenr_range and abs(lanenr_distance + 1) > 1e-6
                    )
                ):
                    unique_scene_id.append(id)

        return unique_scene_id

    def _select_navi_time(self, unique_scene_id, scene_info_all, future_timestamps):
        # distance
        if len(unique_scene_id) < 0:
            return []

        # reconstruct geo info
        scene_info_dict_entry = {}
        scene_info_dict_exit = {}
        scene_info_dict_time_index = {}
        for i in range(len(scene_info_all)):
            for scene_info in scene_info_all[i]:
                if scene_info[5] in unique_scene_id:
                    if scene_info[5] in scene_info_dict_entry:
                        scene_info_dict_entry[scene_info[5]].append(scene_info[0])
                        scene_info_dict_exit[scene_info[5]].append(scene_info[1])
                        scene_info_dict_time_index[scene_info[5]].append(i)
                    else:
                        scene_info_dict_entry[scene_info[5]] = [scene_info[0]]
                        scene_info_dict_exit[scene_info[5]] = [scene_info[1]]
                        scene_info_dict_time_index[scene_info[5]] = [i]

        label_time_index_list = []
        for id in unique_scene_id:
            start_index = None
            end_index = None
            entry_all = scene_info_dict_entry[id]
            # start index
            if len(label_time_index_list) < 1:
                # start
                if entry_all[0] < self.label_range[0]:
                    start_index = scene_info_dict_time_index[id][0]
                elif entry_all[0] >= self.label_range[0]:
                    index = np.argmin(np.abs(np.array(self.label_range[0]) - np.array(entry_all)))
                    start_index = scene_info_dict_time_index[id][index]
                # end
                if entry_all[-1] > self.label_range[1]:
                    end_index = scene_info_dict_time_index[id][-1]
                elif entry_all[-1] <= self.label_range[1]:
                    index = np.argmin(np.abs(np.array(self.label_range[1]) - np.array(entry_all)))
                    end_index = scene_info_dict_time_index[id][index]
                label_time_index_list.append([id, start_index, end_index])
            else:
                prev_id = label_time_index_list[-1][0]
                prev_exit_all = scene_info_dict_exit[prev_id]
                prev_time_index = scene_info_dict_time_index[prev_id]

                # 出前一个路口的时间，出了前一个路口或者最后一帧存在
                exit_prev_time_index = None
                exit_indeces = np.where(np.array(prev_exit_all) < 10.0)[0]
                exit_index = exit_indeces[0] if exit_indeces.size > 0 else None
                if exit_index is not None:
                    exit_prev_time_index = prev_time_index[exit_index]
                else:
                    exit_prev_time_index = prev_time_index[-1]
                exit_prev_time_index = max(exit_prev_time_index, label_time_index_list[-1][1])  # protection

                # start
                cur_start_index = None
                if entry_all[0] < self.label_range[0]:
                    cur_start_index = scene_info_dict_time_index[id][0]
                elif entry_all[0] >= self.label_range[0]:
                    index = np.argmin(np.abs(np.array(self.label_range[0]) - np.array(entry_all)))
                    cur_start_index = scene_info_dict_time_index[id][index]

                # end
                cur_end_index = None
                if entry_all[-1] > self.label_range[1]:
                    cur_end_index = scene_info_dict_time_index[id][-1]
                elif entry_all[-1] <= self.label_range[1]:
                    index = np.argmin(np.abs(np.array(self.label_range[1]) - np.array(entry_all)))
                    cur_end_index = scene_info_dict_time_index[id][index]

                if exit_prev_time_index > cur_end_index:
                    break

                start_index = max(cur_start_index, exit_prev_time_index)

                label_time_index_list.append([id, start_index, cur_end_index])

        return label_time_index_list

    def _construct_navi_env_v3(self, data, future_timestamps, sub_navi_info_all, sub_scene_info_all, navi_scene_id):

        n_timestamps = len(future_timestamps)

        # 1. 将 trajpose 转为 numpy 数组批量处理
        trajpose = np.stack([data[ts]["car_pose"] for ts in future_timestamps])  # (N, 4, 4)

        shift = np.eye(4)
        shift[:3, 3] = [1.4, 0, 0]

        origin_pose = trajpose[-1] @ shift
        origin_pose_inv = np.linalg.inv(origin_pose)

        # 3. 预计算所有帧的 env_T (N, 4, 4)
        env_T_all = (origin_pose_inv @ trajpose).astype(np.float32)  # 批量矩阵乘法

        # 4. 批量处理 ego_gt_polygon
        egoinfo = np.array([[0, 0, 0, 4.85, 2, 2, 0]], dtype=np.float32)
        egoinfo_all = np.repeat(egoinfo, n_timestamps, axis=0)  # (N, 7)

        # 批量计算 ego 变换矩阵
        ego_transformed = transform_obj(egoinfo_all, env_T_all @ shift.astype(np.float32))
        ego_gt_polygon = get_rotated_rectangle(ego_transformed)  # (N, 4, 2)

        # 转换为列表格式 (每个元素是 4x2 数组)
        ego_gt_polygon = [ego_gt_polygon[i] for i in range(n_timestamps)]

        # 5. 处理 lane lines 和 centerlines (保持原有逻辑，但预计算 env_T)
        stop_lines_all = []
        lane_lines_all = []
        centerlines_all = []

        for i, ts in enumerate(future_timestamps):
            env_T = env_T_all[i]

            # lines
            lanes = data[ts]["manner_lane_points"]
            types = data[ts]["manner_lane_types"]
            attrs = data[ts]["manner_lane_attr"]
            lane_lines = []
            stop_line = []
            for p, t, a in zip(lanes, types, attrs):
                p = ego2global(p, env_T)
                if t == 0:  # lane_line
                    lane_lines.append([p, a])
                elif t == 2:  # stop_line
                    stop_line.append(p)
            lane_lines_all.append(lane_lines)
            stop_lines_all.append(stop_line)

            # centerline
            centerlines = []
            for centerline in data[ts]["manner_lane_center_lines"]:  # dict
                centerline_type = centerline["type"]
                centerline_id = centerline["id"]
                if centerline_type == 99 or centerline_id < 90000 or centerline_id > 100000:
                    continue
                # points are dicts ({"x","y","z"}) after manner_lane_center_lines reformat
                # (see _postprocess_nn2_clip_info / _load_data_impl), so use len() not ndarray.size.
                if len(centerline["points"]) < 1:
                    continue
                new_points = np.array(
                    [[p["x"], p["y"], p["z"]] for p in centerline["points"]], dtype=np.float32
                )
                new_points = ego2global(new_points, env_T)
                centerlines.append([new_points, centerline_type, centerline["confidence"], centerline_id])
            centerlines_all.append(centerlines)

        navi_raw_data = {
            "ego_gt_polygon": ego_gt_polygon,
            'stop_lines_all': stop_lines_all,
            "lane_lines_all": lane_lines_all,
            "centerlines_all": centerlines_all,
            "navi_info_all": sub_navi_info_all,
            "scene_info_all": sub_scene_info_all,
            "navi_scene_id": navi_scene_id,
            "timestamps": future_timestamps,
        }

        return navi_raw_data, origin_pose

    def _get_navi_centerline_v4(self, navi_raw_data, ego_pos, ts, is_use_max_entry_dist_filter=False):

        result = -1
        navi_centerline = []
        drivable_center_line = []
        highlight_centerline = []
        not_navi_centerline = []

        # filter
        if not len(navi_raw_data['navi_info_all']):
            return navi_centerline, result, drivable_center_line, highlight_centerline, not_navi_centerline

        navi_infos = navi_raw_data['navi_info_all'][ts]
        lanenr_distance = navi_infos['lane_nr_remain_distance']

        # lanenr num
        lane_num_before_junction = len(navi_infos['lane_infos'])

        # observation lane num
        centerline = navi_raw_data['centerlines_all'][ts]
        drivable_center_line = []

        navi_scene_id = navi_raw_data['navi_scene_id']
        scene_info_ts = navi_raw_data['scene_info_all'][ts]
        entry_dist = lanenr_distance
        for scene in scene_info_ts:
            if navi_scene_id == scene[5]:
                entry_dist = scene[0]
                break

        max_start_x = entry_dist + ego_pos[0]

        for p, t, c, id in centerline:
            if t in [2, 16] and p[0, 0] < max_start_x:  # motor way or bus way
                mask = p[:, 0] < max_start_x
                cut_p = p[mask, :]
                drivable_center_line.append([cut_p, t, c, id])

        if len(drivable_center_line) != lane_num_before_junction:
            result = -3
            return navi_centerline, result, drivable_center_line, highlight_centerline, not_navi_centerline

        # navi check
        navi_index = []
        highlight_index = []
        not_navi_index = []
        for i, (lane_direction,
            lane_highline_direction,
            lane_is_drivable,
            lane_is_highline,
            lane_type) in enumerate(navi_infos['lane_infos']):
            if lane_is_drivable:
                navi_index.append(i)
            if lane_is_highline:
                highlight_index.append(i)
            if (not lane_is_drivable) and (not lane_is_highline):
                not_navi_index.append(i)

        if len(navi_index) < 1:
            result = -4
            return navi_centerline, result, drivable_center_line, highlight_centerline, not_navi_centerline

        # sort centerline by end y, from left to right based on ego
        drivable_center_line.sort(key=lambda x:x[0][-1, 1], reverse=True)

        result = 1
        for i in navi_index:
            navi_centerline.append(drivable_center_line[i])
        for i in highlight_index:
            highlight_centerline.append(drivable_center_line[i])
        for i in not_navi_index:
            not_navi_centerline.append(drivable_center_line[i])

        return navi_centerline, result, drivable_center_line, highlight_centerline, not_navi_centerline

    def _get_navi_centerline_v3(self, navi_raw_data, ego_pos, ts, is_use_max_entry_dist_filter=False):

        result = -1
        navi_centerline = []
        drivable_center_line = []

        # filter
        if not len(navi_raw_data["navi_info_all"]):
            return navi_centerline, result, drivable_center_line

        navi_infos = navi_raw_data["navi_info_all"][ts]
        lanenr_distance = navi_infos["lane_nr_remain_distance"]

        # lanenr num
        lane_num_before_junction = len(navi_infos["lane_infos"])

        # observation lane num
        centerline = navi_raw_data["centerlines_all"][ts]
        drivable_center_line = []

        navi_scene_id = navi_raw_data["navi_scene_id"]
        scene_info_ts = navi_raw_data["scene_info_all"][ts]
        entry_dist = lanenr_distance
        for scene in scene_info_ts:
            if navi_scene_id == scene[5]:
                entry_dist = scene[0]
                break

        max_start_x = entry_dist + ego_pos[0]

        for p, t, c, id in centerline:
            if t in [2, 16] and p[0, 0] < max_start_x:  # motor way or bus way
                mask = p[:, 0] < max_start_x
                cut_p = p[mask, :]
                drivable_center_line.append([cut_p, t, c, id])

        if len(drivable_center_line) != lane_num_before_junction:
            result = -3
            return navi_centerline, result, drivable_center_line

        # navi check
        navi_index = []
        for i, (lane_direction, lane_highline_direction, lane_is_drivable, lane_is_highline, lane_type) in enumerate(
            navi_infos["lane_infos"]
        ):
            if lane_is_drivable:
                navi_index.append(i)

        if len(navi_index) < 1:
            result = -4
            return navi_centerline, result, drivable_center_line

        # sort centerline by end y, from left to right based on ego
        drivable_center_line.sort(key=lambda x: x[0][-1, 1], reverse=True)

        result = 1
        for i in navi_index:
            navi_centerline.append(drivable_center_line[i])

        return navi_centerline, result, drivable_center_line

    def _build_adjacent_lane_with_stitch_info(self, lane_id, navi_raw_data, navi_lane_stitch,
                                            reference_start_x, target_length):
        """
        利用导航车道的拼接信息构建相邻车道

        Args:
            lane_id: 相邻车道ID
            navi_raw_data: 原始导航数据
            navi_lane_stitch: 导航车道的拼接信息 [points, type, confidence, id, used_time_stamp]
            reference_start_x: 参考起始x坐标
            target_length: 目标长度

        Returns:
            extended_points: 拼接好的点
        """

        # 导航车道使用的时间戳列表（已排序）
        navi_used_timestamps = navi_lane_stitch[4]  # [ts1, ts2, ts3, ...]

        # print(f"[Adjacent Lane] Navi lane used timestamps: {navi_used_timestamps}")
        # print(f"[Adjacent Lane] Trying to build lane {lane_id} using same timestamps...")

        # 存储各个时间戳的相邻车道片段
        segments = []

        # 遍历导航车道使用的所有时间戳
        for ts in navi_used_timestamps:
            # 在该时间戳查找相邻车道
            centerlines_ts = navi_raw_data["centerlines_all"][ts]
            found_lane = None
            for centerline in centerlines_ts:
                if centerline[3] == lane_id:
                    found_lane = centerline[0]  # points [N, 3]
                    break

            if found_lane is None:
                # print(f"[Adjacent Lane] Lane {lane_id} not found at ts={ts}")
                continue

            # 判断x方向
            lane_start_x = found_lane[0, 0]
            lane_end_x = found_lane[-1, 0]
            is_x_increasing = lane_end_x > lane_start_x

            # 裁剪：保留远离路口的部分
            if is_x_increasing:
                mask = found_lane[:, 0] <= reference_start_x
            else:
                mask = found_lane[:, 0] >= reference_start_x

            clipped = found_lane[mask]

            if len(clipped) > 0:
                segments.append({
                    'ts': ts,
                    'points': clipped,
                    'is_x_increasing': is_x_increasing
                })
                # print(f"[Adjacent Lane] ts={ts}: found {len(clipped)} points, "
                #     f"x_range=[{clipped[0, 0]:.2f}, {clipped[-1, 0]:.2f}]")

        if not segments:
            # print(f"[Adjacent Lane] No valid segments found for lane {lane_id}")
            return None

        # 拼接所有片段
        # 策略：按时间戳顺序，从最早的开始拼接
        extended_points = segments[0]['points'].copy()
        is_x_increasing = segments[0]['is_x_increasing']

        # print(f"[Adjacent Lane] Starting with ts={segments[0]['ts']}, {len(extended_points)} points")

        for i in range(1, len(segments)):
            prev_segment = segments[i-1]['points']
            curr_segment = segments[i]['points']

            # 确定拼接端点
            if is_x_increasing:
                # x递增：当前段应该拼接到前段的后面（x更大的一端）
                prev_end_point = prev_segment[-1, :2]
                # 在当前段找到最接近的点
                distances = np.sqrt(np.sum((curr_segment[:, :2] - prev_end_point)**2, axis=1))
                closest_idx = np.argmin(distances)

                if distances[closest_idx] > 30.0:
                    # print(f"[Adjacent Lane] Gap too large between ts={segments[i-1]['ts']} and ts={segments[i]['ts']}: "
                    #     f"{distances[closest_idx]:.2f}m, stop stitching")
                    break

                # 从closest_idx之后的点拼接（避免重复）
                if closest_idx < len(curr_segment) - 1:
                    new_points = curr_segment[closest_idx + 1:]
                    extended_points = np.concatenate([extended_points, new_points], axis=0)
                    # print(f"[Adjacent Lane] Stitched ts={segments[i]['ts']}, added {len(new_points)} points")
            else:
                # x递减：当前段应该拼接到前段的前面（x更小的一端）
                prev_start_point = prev_segment[0, :2]
                distances = np.sqrt(np.sum((curr_segment[:, :2] - prev_start_point)**2, axis=1))
                closest_idx = np.argmin(distances)

                if distances[closest_idx] > 30.0:
                    # print(f"[Adjacent Lane] Gap too large between ts={segments[i-1]['ts']} and ts={segments[i]['ts']}: "
                    #     f"{distances[closest_idx]:.2f}m, stop stitching")
                    break

                # 从起点到closest_idx之前的点拼接
                if closest_idx > 0:
                    new_points = curr_segment[:closest_idx]
                    extended_points = np.concatenate([new_points, extended_points], axis=0)
                    # print(f"[Adjacent Lane] Stitched ts={segments[i]['ts']}, added {len(new_points)} points")

        # 计算最终长度
        segment_lengths = np.sqrt(np.sum(np.diff(extended_points[:, :2], axis=0)**2, axis=1))
        total_length = np.sum(segment_lengths)

        # print(f"[Adjacent Lane] Lane {lane_id}: final {len(extended_points)} points, length={total_length:.2f}m, "
        #     f"x_range=[{extended_points[0, 0]:.2f}, {extended_points[-1, 0]:.2f}]")

        if total_length < target_length * 0.3:
            # print(f"[Adjacent Lane] Lane {lane_id}: length {total_length:.2f}m < {target_length*0.3:.2f}m, rejected")
            return None

        return extended_points

    def _get_adjacent_lane_centerlines(self, time_stamp, navi_raw_data, navi_centerline_list_stitch,
                                    drivable_centerline_list, min_length=100.0):
        """
        为导航车道的相邻车道构建部分navi_centerline

        改进：
        1. 只构建一条辅助线（导航车道正旁边的那条）
        2. 检查横向距离，避免T型路口的交叉车道
        """

        # print(f"\n[Adjacent Build] ========== Starting to build adjacent centerlines ==========")

        if not navi_centerline_list_stitch or not drivable_centerline_list:
            # print(f"[Adjacent Build] ✗ Empty inputs")
            return []

        # 1. 找到导航车道在所有可行驶车道中的索引
        navi_ids = {lane[3] for lane in navi_centerline_list_stitch}
        navi_indices = []
        navi_lanes_map = {}

        for i, lane in enumerate(drivable_centerline_list):
            if lane[3] in navi_ids:
                navi_indices.append(i)
                for navi_lane in navi_centerline_list_stitch:
                    if navi_lane[3] == lane[3]:
                        navi_lanes_map[lane[3]] = navi_lane
                        break

        if not navi_indices:
            # print(f"[Adjacent Build] ✗ No navi lanes found")
            return []

        # 2. 确定参考点
        reference_start_x = float('inf')
        navi_start_points = []

        for navi_lane in navi_centerline_list_stitch:
            lane_start_x = navi_lane[0][0, 0]
            lane_end_x = navi_lane[0][-1, 0]

            if lane_start_x < lane_end_x:
                actual_start_x = lane_start_x
            else:
                actual_start_x = lane_end_x

            navi_start_points.append(actual_start_x)
            reference_start_x = min(reference_start_x, actual_start_x)

        # print(f"[Adjacent Build] Reference start x: {reference_start_x:.2f}")

        # 3. 找相邻车道（左右各一条）
        # 关键：应该只有一个导航车道（已在_should_build中检查）
        navi_idx = navi_indices[0]
        navi_lane_id = drivable_centerline_list[navi_idx][3]
        navi_lane = navi_lanes_map[navi_lane_id]

        # print(f"[Adjacent Build] Navi lane index: {navi_idx}, id: {navi_lane_id}")

        # 确定构建哪一侧的相邻车道
        # 如果导航车道在最左侧，构建右侧；如果在最右侧，构建左侧
        is_leftmost = (navi_idx == 0)
        is_rightmost = (navi_idx == len(drivable_centerline_list) - 1)

        target_adjacent_idx = None
        if is_leftmost:
            # 最左侧，构建右侧相邻车道
            target_adjacent_idx = navi_idx + 1
            side = "right"
        elif is_rightmost:
            # 最右侧，构建左侧相邻车道
            target_adjacent_idx = navi_idx - 1
            side = "left"
        else:
            # print(f"[Adjacent Build] ✗ Navi lane not at edge (should not happen)")
            return []

        if target_adjacent_idx < 0 or target_adjacent_idx >= len(drivable_centerline_list):
            # print(f"[Adjacent Build] ✗ No adjacent lane on {side} side")
            return []

        adjacent_lane = drivable_centerline_list[target_adjacent_idx]
        adjacent_lane_id = adjacent_lane[3]

        # print(f"[Adjacent Build] Target: lane[{target_adjacent_idx}] id={adjacent_lane_id} ({side} side of navi)")

        # 4. 检查横向距离，避免T型路口的交叉车道
        if not self._check_lane_lateral_distance(navi_lane, adjacent_lane, time_stamp, navi_raw_data):
            # print(f"[Adjacent Build] ✗ Lateral distance check failed, likely T-junction crossing")
            return []

        # 5. 构建辅助中心线
        # print(f"\n[Adjacent Build] ========== Building lane {adjacent_lane_id} ==========")

        extended_points = self._build_adjacent_lane_with_stitch_info(
            adjacent_lane_id, navi_raw_data, navi_lane, reference_start_x, min_length
        )

        if extended_points is None or len(extended_points) < 3:
            # print(f"[Adjacent Build] ✗ Failed to build lane {adjacent_lane_id}")
            return []

        # 计算最终长度
        segment_lengths = np.sqrt(np.sum(np.diff(extended_points[:, :2], axis=0)**2, axis=1))
        total_length = np.sum(segment_lengths)

        # print(f"[Adjacent Build] ✓✓✓ Successfully built lane {adjacent_lane_id}")
        # print(f"[Adjacent Build]   - Points: {len(extended_points)}")
        # print(f"[Adjacent Build]   - Length: {total_length:.2f}m")
        # print(f"[Adjacent Build]   - X range: [{extended_points[0, 0]:.2f}, {extended_points[-1, 0]:.2f}]")

        adjacent_centerline_list = [[
            extended_points,
            adjacent_lane[1],
            adjacent_lane[2] * 0.8,
            adjacent_lane_id,
            navi_lane[4]  # 使用导航车道的时间戳列表
        ]]

        # print(f"\n[Adjacent Build] ========== Build complete: 1 adjacent lane ==========\n")
        return adjacent_centerline_list


    def _check_lane_lateral_distance(self, navi_lane, adjacent_lane, time_stamp, navi_raw_data,
                                    max_lateral_distance=6.0, min_lateral_distance=2.0):
        """
        检查两条车道的横向距离是否合理（垂直于车道方向的距离）

        Args:
            navi_lane: 导航车道（拼接后的）
            adjacent_lane: 相邻车道（当前时间戳的）
            time_stamp: 当前时间戳
            navi_raw_data: 原始导航数据
            max_lateral_distance: 最大横向距离（米）
            min_lateral_distance: 最小横向距离（米）

        Returns:
            bool: 距离是否合理
        """

        # 获取当前时间戳的相邻车道完整数据
        centerlines_ts = navi_raw_data["centerlines_all"][time_stamp]
        adjacent_full_lane = None
        for centerline in centerlines_ts:
            if centerline[3] == adjacent_lane[3]:
                adjacent_full_lane = centerline[0]
                break

        if adjacent_full_lane is None:
            # print(f"[Lateral Check] Cannot find adjacent lane {adjacent_lane[3]} at ts={time_stamp}")
            return False

        # 取导航车道的中间部分点（避免端点影响）
        navi_points = navi_lane[0]  # [N, 3]
        start_idx = len(navi_points) // 3
        end_idx = len(navi_points) * 2 // 3
        navi_sample_points = navi_points[start_idx:end_idx, :2]  # 取中间1/3

        # 取相邻车道的中间部分点
        adj_points = adjacent_full_lane[:, :2]
        adj_start_idx = len(adj_points) // 3
        adj_end_idx = len(adj_points) * 2 // 3
        adj_sample_points = adj_points[adj_start_idx:adj_end_idx]

        if len(navi_sample_points) < 3 or len(adj_sample_points) < 3:
            # print(f"[Lateral Check] Too few sample points")
            return False

        # 计算真正的横向距离（垂直于导航车道方向）
        lateral_distances = []

        for i in range(1, len(navi_sample_points) - 1):
            # 当前点
            pt = navi_sample_points[i]

            # 用前后点计算车道方向（切线方向）
            prev_pt = navi_sample_points[i - 1]
            next_pt = navi_sample_points[i + 1]

            # 车道方向向量（归一化）
            tangent = next_pt - prev_pt
            tangent_norm = np.linalg.norm(tangent)

            if tangent_norm < 1e-6:
                continue

            tangent = tangent / tangent_norm

            # 法向量（垂直于车道方向）：旋转90度
            # 2D旋转90度: (x, y) -> (-y, x)
            normal = np.array([-tangent[1], tangent[0]])

            # 找到相邻车道上最近的点
            distances_to_adj = np.sqrt(np.sum((adj_sample_points - pt)**2, axis=1))
            closest_idx = np.argmin(distances_to_adj)
            closest_pt = adj_sample_points[closest_idx]

            # 从导航车道点到相邻车道点的向量
            vec_to_adj = closest_pt - pt

            # 计算横向距离：向量在法向量上的投影
            lateral_dist = abs(np.dot(vec_to_adj, normal))

            lateral_distances.append(lateral_dist)

        if len(lateral_distances) == 0:
            # print(f"[Lateral Check] No valid lateral distances computed")
            return False

        avg_lateral_distance = np.mean(lateral_distances)
        max_dist = np.max(lateral_distances)
        min_dist = np.min(lateral_distances)
        std_lateral_distance = np.std(lateral_distances)

        # print(f"[Lateral Check] Lateral distance (perpendicular): "
        #     f"avg={avg_lateral_distance:.2f}m, "
        #     f"min={min_dist:.2f}m, max={max_dist:.2f}m, "
        #     f"std={std_lateral_distance:.2f}m")

        # 判断条件：
        # 1. 平均横向距离在合理范围内（2-6米，典型车道宽3.5米）
        # 2. 标准差不能太大（说明两条车道基本平行，距离稳定）
        is_valid = (min_lateral_distance <= avg_lateral_distance <= max_lateral_distance and
                    std_lateral_distance < 2.0)  # 标准差小于2米，说明距离稳定

        # if is_valid:
        #     print(f"[Lateral Check] ✓ Lateral distance check passed")
        # else:
        #     print(f"[Lateral Check] ✗ Lateral distance check failed")
        #     if not (min_lateral_distance <= avg_lateral_distance <= max_lateral_distance):
        #         print(f"[Lateral Check]   Reason: avg distance {avg_lateral_distance:.2f}m "
        #             f"not in range [{min_lateral_distance}, {max_lateral_distance}]")
        #     if std_lateral_distance >= 2.0:
        #         print(f"[Lateral Check]   Reason: std {std_lateral_distance:.2f}m too large (lanes not parallel)")

        return is_valid

    def _get_navi_env_info_v3(self, navi_raw_data, scene_id):

        time_stamp = -1
        navi_centerline_list_stitch = []
        navi_centerline_info = {}

        # scene dist
        scene_id_all = []
        for i, scene_infos in enumerate(navi_raw_data["scene_info_all"]):
            for scene in scene_infos:
                if scene[5] == scene_id:
                    scene_id_all.append([i, scene])

        # 1. 查找导航生效点
        all_navi_event_index = []
        min_scene_entry_distance = 1e6
        for scene_id_ts_info in scene_id_all:
            min_scene_entry_distance = min(min_scene_entry_distance, max(scene_id_ts_info[1][0], 0.0))
            if len(all_navi_event_index) < 1 and 0.0 < scene_id_ts_info[1][0] < self.entry_dist_filter[0]:
                all_navi_event_index.append([scene_id_ts_info[0], scene_id_ts_info[1][0]])
                break

        is_use_max_entry_dist_filter = False
        if len(all_navi_event_index) < 1 and min_scene_entry_distance < self.entry_dist_filter[1]:
            for scene_id_ts_info in scene_id_all:
                if len(all_navi_event_index) < 1 and 0.0 < scene_id_ts_info[1][0] < self.entry_dist_filter[1]:
                    all_navi_event_index.append([scene_id_ts_info[0], scene_id_ts_info[1][0]])
                    is_use_max_entry_dist_filter = True
                    break

        ego_polygon = np.stack(navi_raw_data["ego_gt_polygon"], axis=0)
        ego_traj = ego_polygon.mean(axis=1)

        if len(all_navi_event_index) < 1:
            return time_stamp, navi_centerline_list_stitch, navi_centerline_info

        # 2. 导航车道匹配
        navi_centerline_list = []
        if is_use_max_entry_dist_filter:
            for pred_ts in range(len(ego_polygon) - 1, all_navi_event_index[0][0], -1):
                if len(navi_centerline_list):
                    time_stamp = pred_ts - 1
                    break
                ego_pos = ego_polygon[pred_ts].mean(axis=0)
                navi_centerline_list, _, drivable_centerline_list = self._get_navi_centerline_v3(
                    navi_raw_data, ego_pos, pred_ts, is_use_max_entry_dist_filter
                )
        else:
            for pred_ts in range(all_navi_event_index[0][0], len(ego_polygon)):
                if len(navi_centerline_list):
                    time_stamp = pred_ts - 1
                    break
                ego_pos = ego_polygon[pred_ts].mean(axis=0)
                navi_centerline_list, _, drivable_centerline_list = self._get_navi_centerline_v3(
                    navi_raw_data, ego_pos, pred_ts, is_use_max_entry_dist_filter
                )

        # protection
        if not len(navi_centerline_list):
            return time_stamp, navi_centerline_list_stitch, navi_centerline_info

        # 3. 拼接
        # [points, type, confidence, id]
        navi_centerline_list_stitch = self._extend_navi_centerline(time_stamp, navi_centerline_list, navi_raw_data)

        # 4. 查找navi lane 的左右边界的索引（navi_raw_data[time_stamp]）
        navi_centerline_info = self._match_lane_boundary(time_stamp, navi_raw_data, navi_centerline_list_stitch)

        # 5. 分割
        navi_centerline_info = self._split_navi_centerline_by_solid_line(
            time_stamp, navi_raw_data, navi_centerline_list_stitch, navi_centerline_info, drivable_centerline_list
        )

        return time_stamp, navi_centerline_list_stitch, navi_centerline_info

    def _should_build_adjacent_centerlines(self, navi_info, navi_centerline_list_stitch, drivable_centerline_list):
        """
        判断是否需要为相邻车道构建辅助navi_centerline

        条件：
        1. 只有一条导航中心线
        2. 导航车道是最左侧或最右侧
        3. 导航中心线长度 < 150米
        """

        # print(f"\n[Adjacent Check] ========== Checking if need adjacent centerlines ==========")
        # print(f"[Adjacent Check] navi_centerline_list_stitch: {len(navi_centerline_list_stitch) if navi_centerline_list_stitch else 0}")
        # print(f"[Adjacent Check] drivable_centerline_list: {len(drivable_centerline_list) if drivable_centerline_list else 0}")
        # print(f"[Adjacent Check] navi_info: {navi_info is not None and len(navi_info) > 0}")

        if not navi_centerline_list_stitch or not drivable_centerline_list:
            # print(f"[Adjacent Check] ✗ No navi centerlines or drivable centerlines")
            return False

        # 条件1：只有一条导航中心线
        if len(navi_centerline_list_stitch) != 1:
            # print(f"[Adjacent Check] ✗ Found {len(navi_centerline_list_stitch)} navi centerlines, need exactly 1")
            return False

        # print(f"[Adjacent Check] ✓ Condition 1: Only 1 navi centerline")

        # 找到导航车道在所有可行驶车道中的索引
        navi_ids = {lane[3] for lane in navi_centerline_list_stitch}
        # print(f"[Adjacent Check] Navi lane IDs: {navi_ids}")

        navi_indices = []
        for i, lane in enumerate(drivable_centerline_list):
            # print(f"[Adjacent Check]   drivable[{i}]: id={lane[3]}")
            if lane[3] in navi_ids:
                navi_indices.append(i)

        if not navi_indices:
            # print(f"[Adjacent Check] ✗ Cannot find navi lane in drivable centerlines")
            return False

        navi_idx = navi_indices[0]
        # print(f"[Adjacent Check] Navi lane index in drivable list: {navi_idx}")

        # 条件2：导航车道是最左侧或最右侧
        is_leftmost = (navi_idx == 0)
        is_rightmost = (navi_idx == len(drivable_centerline_list) - 1)

        # print(f"[Adjacent Check] is_leftmost={is_leftmost}, is_rightmost={is_rightmost} "
        #     f"(total drivable lanes: {len(drivable_centerline_list)})")

        if not (is_leftmost or is_rightmost):
            # print(f"[Adjacent Check] ✗ Navi lane at index {navi_idx} is NOT at edge "
            #     f"(leftmost=0, rightmost={len(drivable_centerline_list)-1})")
            return False

        # print(f"[Adjacent Check] ✓ Condition 2: Navi lane is at {'leftmost' if is_leftmost else 'rightmost'} edge")

        # 条件3：导航中心线长度 < 100米
        navi_lane = navi_centerline_list_stitch[0]
        navi_points = navi_lane[0]  # [N, 3]

        # print(f"[Adjacent Check] Navi lane points: {len(navi_points)}")

        # 计算长度
        segment_lengths = np.sqrt(np.sum(np.diff(navi_points[:, :2], axis=0)**2, axis=1))
        navi_length = np.sum(segment_lengths)

        # print(f"[Adjacent Check] Navi centerline length: {navi_length:.2f}m")

        if navi_length >= 150.0:
            # print(f"[Adjacent Check] ✗ Navi centerline length {navi_length:.2f}m >= 150m")
            # print(f"[Adjacent Check] ========== Result: NO NEED for adjacent ==========\n")
            return False

        # print(f"[Adjacent Check] ✓ Condition 3: Length {navi_length:.2f}m < 150m")
        # print(f"[Adjacent Check] ========== Result: NEED adjacent centerlines! ==========\n")
        return True

    def _get_navi_env_info_v4(self, navi_raw_data, scene_id):
        """修改后的版本，增加相邻车道中心线构建"""

        time_stamp = -1
        navi_centerline_list_stitch = []
        navi_centerline_info = {}
        highlight_centerline_list_stitch = []
        not_navi_centerline_list_stitch = []

        # scene dist
        scene_id_all = []
        for i, scene_infos in enumerate(navi_raw_data["scene_info_all"]):
            for scene in scene_infos:
                if scene[5] == scene_id:
                    scene_id_all.append([i, scene])

        # 1. 查找导航生效点
        all_navi_event_index = []
        min_scene_entry_distance = 1e6
        for scene_id_ts_info in scene_id_all:
            min_scene_entry_distance = min(min_scene_entry_distance, max(scene_id_ts_info[1][0], 0.0))
            if len(all_navi_event_index) < 1 and 0.0 < scene_id_ts_info[1][0] < self.entry_dist_filter[0]:
                all_navi_event_index.append([scene_id_ts_info[0], scene_id_ts_info[1][0]])
                break

        is_use_max_entry_dist_filter = False
        if len(all_navi_event_index) < 1 and min_scene_entry_distance < self.entry_dist_filter[1]:
            for scene_id_ts_info in scene_id_all:
                if len(all_navi_event_index) < 1 and 0.0 < scene_id_ts_info[1][0] < self.entry_dist_filter[1]:
                    all_navi_event_index.append([scene_id_ts_info[0], scene_id_ts_info[1][0]])
                    is_use_max_entry_dist_filter = True
                    break

        ego_polygon = np.stack(navi_raw_data["ego_gt_polygon"], axis=0)
        ego_traj = ego_polygon.mean(axis=1)

        if len(all_navi_event_index) < 1:
            return (time_stamp, navi_centerline_list_stitch, navi_centerline_info,
                    highlight_centerline_list_stitch, not_navi_centerline_list_stitch)

        # 2. 导航车道匹配
        navi_centerline_list = []
        drivable_centerline_list = []
        highlight_centerline = []
        not_navi_centerline = []

        if is_use_max_entry_dist_filter:
            for pred_ts in range(len(ego_polygon) - 1, all_navi_event_index[0][0], -1):
                if len(navi_centerline_list):
                    time_stamp = pred_ts - 1
                    break
                ego_pos = ego_polygon[pred_ts].mean(axis=0)
                (navi_centerline_list, _, drivable_centerline_list, highlight_centerline,
                    not_navi_centerline) = self._get_navi_centerline_v4(
                    navi_raw_data, ego_pos, pred_ts, is_use_max_entry_dist_filter
                )
        else:
            for pred_ts in range(all_navi_event_index[0][0], len(ego_polygon)):
                if len(navi_centerline_list):
                    time_stamp = pred_ts - 1
                    break
                ego_pos = ego_polygon[pred_ts].mean(axis=0)
                (navi_centerline_list, _, drivable_centerline_list,highlight_centerline,
                not_navi_centerline) = self._get_navi_centerline_v4(
                    navi_raw_data, ego_pos, pred_ts, is_use_max_entry_dist_filter
                )

        # if not len(navi_centerline_list):
        #     return time_stamp, navi_centerline_list_stitch, navi_centerline_info

        # 3. 拼接导航车道
        if len(navi_centerline_list):
            navi_centerline_list_stitch = self._extend_navi_centerline(time_stamp, navi_centerline_list, navi_raw_data)

            # 4. 查找navi lane 的左右边界的索引
            navi_centerline_info = self._match_lane_boundary(time_stamp, navi_raw_data, navi_centerline_list_stitch)

             # 5. 分割实线区域
            navi_centerline_info = self._split_navi_centerline_by_solid_line(
            time_stamp, navi_raw_data, navi_centerline_list_stitch, navi_centerline_info, drivable_centerline_list
            )

        if len(highlight_centerline):
            highlight_centerline_list_stitch = self._extend_navi_centerline(time_stamp, highlight_centerline, navi_raw_data)

        if len(not_navi_centerline):
            not_navi_centerline_list_stitch = self._extend_navi_centerline(time_stamp, not_navi_centerline, navi_raw_data)

        # ===== 新增：构建相邻车道的部分中心线 =====
        # print(f"\n[Navi Centerline] === Checking if adjacent lane centerlines are needed ===")
        # print(f"[Navi Centerline] Navi lanes: {[lane[3] for lane in navi_centerline_list_stitch]}")

        # 6. 判断是否需要构建辅助线
        navi_info = navi_raw_data["navi_info_all"][time_stamp] if time_stamp >= 0 else {}
        should_build = self._should_build_adjacent_centerlines(
            navi_info, navi_centerline_list_stitch, drivable_centerline_list
        )

        if should_build:
            # print(f"[Navi Centerline] === Constructing adjacent lane centerlines ===")

            # 7. 构建相邻车道的辅助引导线
            adjacent_centerlines = self._get_adjacent_lane_centerlines(
                time_stamp, navi_raw_data, navi_centerline_list_stitch,
                drivable_centerline_list, min_length=100.0
            )

            # 8. 将相邻车道中心线添加到结果中
            for adj_lane in adjacent_centerlines:
                navi_centerline_info[adj_lane[3]] = {
                    'left_boundary_index': None,
                    'right_boundary_index': None,
                    'solid_line_start_index': None,
                    'is_adjacent': True
                }
                navi_centerline_list_stitch.append(adj_lane)

            # print(f"[Navi Centerline] Total centerlines: {len(navi_centerline_list_stitch)} "
            #     f"(navi: {len(navi_centerline_list)}, adjacent: {len(adjacent_centerlines)})")
        # else:
        #     print(f"[Navi Centerline] No need for adjacent centerlines")

        # print(f"[Navi Centerline] === Adjacent lane check done ===\n")

        return (time_stamp, navi_centerline_list_stitch, navi_centerline_info, highlight_centerline_list_stitch,
               not_navi_centerline_list_stitch)

    def _find_prev_lane_time_stamp_index(self, index, navi_lane_all_time_points):

        # index navi_lane_time_stamp
        base_point = navi_lane_all_time_points[index][0, :2]

        index_in_navi_lane_time_stamp = None

        for i in range(index, -1, -1):
            start_points = navi_lane_all_time_points[i][0, :2]  # n*2
            tmp = start_points - base_point
            dist = np.linalg.norm(tmp)
            if dist > self.stitch_interval:
                index_in_navi_lane_time_stamp = i
                break

        if index_in_navi_lane_time_stamp is None:
            index_in_navi_lane_time_stamp = 0

        return index_in_navi_lane_time_stamp

    def _stitch_navi_lane_by_id(
        self, init_time_stamp, init_navi_lane_points, navi_lane_time_stamp, navi_lane_all_time_points
    ):

        start_time_stamp_index = np.argmin(np.abs(np.array(init_time_stamp) - np.array(navi_lane_time_stamp)))
        # start_pos = navi_lane_all_time_points[start_time_stamp_index][0, :2]
        start_pos = init_navi_lane_points[0, :2]

        used_time_stamp = np.array([init_time_stamp])
        # navi_lane_points = navi_lane_all_time_points[start_time_stamp_index][:, :2]  # n*2
        navi_lane_points = init_navi_lane_points[:, :2]

        for i in range(init_time_stamp):  # 最多循环init time stamp 次
            if start_time_stamp_index < 1:  # 拼接完了所有的线
                break
            # 找上一个要拼接的索引
            index_in_navi_lane_time_stamp = self._find_prev_lane_time_stamp_index(
                start_time_stamp_index, navi_lane_all_time_points
            )

            prev_navi_lane = navi_lane_all_time_points[index_in_navi_lane_time_stamp][:, :2]  # n*2
            projection_index = np.argmin(np.linalg.norm((start_pos - prev_navi_lane), axis=1))

            navi_lane_points = np.concatenate((prev_navi_lane[:projection_index], navi_lane_points), axis=0)

            if index_in_navi_lane_time_stamp != used_time_stamp[-1]:
                used_time_stamp = np.concatenate(
                    (np.array([navi_lane_time_stamp[index_in_navi_lane_time_stamp]]), used_time_stamp)
                )

            start_time_stamp_index = index_in_navi_lane_time_stamp
            start_pos = prev_navi_lane[0, :2]

        return navi_lane_points, used_time_stamp

    def _extend_navi_centerline(self, time_stamp, navi_centerline_list, navi_raw_data):
        navi_centerline_all_time_stamp = {}
        navi_centerline_all_time_points = {}
        centerline_ids = [navi_lane[3] for navi_lane in navi_centerline_list]

        for i, centerlines_ts in enumerate(navi_raw_data["centerlines_all"]):
            for centerline in centerlines_ts:
                if centerline[3] in centerline_ids:

                    post_points = centerline[0]

                    if centerline[1] == 32:  # 逆向车道误识别
                        post_points = np.flip(centerline[0], axis=0)

                    if centerline[3] not in navi_centerline_all_time_stamp:
                        navi_centerline_all_time_stamp[centerline[3]] = [i]
                        navi_centerline_all_time_points[centerline[3]] = [post_points]
                    else:
                        navi_centerline_all_time_stamp[centerline[3]].append(i)
                        navi_centerline_all_time_points[centerline[3]].append(post_points)

        navi_centerline_list_stitch = []
        for navi_lane in navi_centerline_list:

            navi_lane_time_stamp = navi_centerline_all_time_stamp[navi_lane[3]]
            navi_lane_all_time_points = navi_centerline_all_time_points[navi_lane[3]]

            navi_lane_stitch_point, used_time_stamp = self._stitch_navi_lane_by_id(
                time_stamp, navi_lane[0], navi_lane_time_stamp, navi_lane_all_time_points
            )

            navi_centerline_list_stitch.append(
                [navi_lane_stitch_point, navi_lane[1], navi_lane[2], navi_lane[3], used_time_stamp]
            )

        return navi_centerline_list_stitch

    def _match_lane_boundary(self, time_stamp, navi_raw_data, navi_centerline_list):

        lane_lines = navi_raw_data["lane_lines_all"][time_stamp]

        lane_boundary_set = set()
        lane_boundary_list = []

        for navi_lane in navi_centerline_list:
            navi_centerline_p = navi_lane[0]
            navi_centerline_end_p = navi_centerline_p[-1, :2]
            for i, (p, a) in enumerate(lane_lines):
                if i not in lane_boundary_set:
                    mask = (
                        (p[:, 0] >= navi_centerline_end_p[0] - 15.0)
                        & (p[:, 0] <= navi_centerline_end_p[0] + 0.0)
                        & (p[:, 1] >= navi_centerline_end_p[1] - 50.0)
                        & (p[:, 1] <= navi_centerline_end_p[1] + 50.0)
                    )
                    filter_pt_y = p[mask, :]
                    if len(filter_pt_y):
                        lane_boundary_list.append([i, filter_pt_y])
                        lane_boundary_set.add(i)

        lane_boundary_list.sort(key=lambda x: x[1][-1, 1], reverse=True)

        # 匹配boundary
        # 如果匹配不上，则navi_centerline_info[centerline_index] = {}
        navi_centerline_info = {}
        boundary_index_list = []
        for centerline in navi_centerline_list:
            navi_centerline_info[centerline[3]] = {"left_boundary_index": None, "right_boundary_index": None}
            if len(lane_boundary_list):
                if centerline[0][-1, 1] > lane_boundary_list[0][1][-1, 1]:
                    navi_centerline_info[centerline[3]]["right_boundary_index"] = lane_boundary_list[0][0]
                    boundary_index_list.append(lane_boundary_list[0][0])
                elif centerline[0][-1, 1] < lane_boundary_list[-1][1][-1, 1]:
                    navi_centerline_info[centerline[3]]["left_boundary_index"] = lane_boundary_list[-1][0]
                    boundary_index_list.append(lane_boundary_list[-1][0])
                else:
                    for i in range(0, len(lane_boundary_list) - 1):
                        if (
                            centerline[0][-1, 1] < lane_boundary_list[i][1][-1, 1]
                            and centerline[0][-1, 1] > lane_boundary_list[i + 1][1][-1, 1]
                        ):
                            navi_centerline_info[centerline[3]]["left_boundary_index"] = lane_boundary_list[i][0]
                            navi_centerline_info[centerline[3]]["right_boundary_index"] = lane_boundary_list[i + 1][0]
                            boundary_index_list.append(lane_boundary_list[i][0])
                            boundary_index_list.append(lane_boundary_list[i + 1][0])

        return navi_centerline_info

    def _split_navi_centerline_by_solid_line(
        self, time_stamp, navi_raw_data, navi_centerline_list, navi_centerline_info, drivable_centerline_list
    ):

        boundary_index_list = []
        max_navi_lane_x = None
        for navi_lane in navi_centerline_list:
            id = navi_lane[3]
            if navi_centerline_info[id]["left_boundary_index"] is not None:
                boundary_index_list.append(navi_centerline_info[id]["left_boundary_index"])
            if navi_centerline_info[id]["right_boundary_index"] is not None:
                boundary_index_list.append(navi_centerline_info[id]["right_boundary_index"])
            if max_navi_lane_x is None:
                max_navi_lane_x = navi_lane[0][-1, 0]
            else:
                max_navi_lane_x = min(max_navi_lane_x, navi_lane[0][-1, 0])

        # 路口前实线点
        solid_line_start_info = {}
        unique_boundary_index_list = list(set(boundary_index_list))

        lane_lines = navi_raw_data["lane_lines_all"][time_stamp]
        for index in unique_boundary_index_list:
            solid_line_start_info[index] = {}
            p, a = lane_lines[index]
            mask = p[:, 0] < max_navi_lane_x - 3.0
            clip_p = p[mask]
            clip_a = a[mask]
            solid_point_num = 0
            for i in range(len(clip_a) - 1, 0, -1):
                solid_type = [1, 5, 7, 8]
                if clip_a[i][0] in solid_type:
                    if clip_a[i - 1][0] not in solid_type:
                        solid_line_start_info[index]["solid_line_start_point"] = clip_p[i]
                        solid_line_start_info[index]["is_all_solid_point"] = False
                        break
                    else:
                        solid_point_num += 1
            if solid_point_num > 0 and solid_point_num == len(clip_a) - 1:
                solid_line_start_info[index]["solid_line_start_point"] = clip_p[0]
                solid_line_start_info[index]["is_all_solid_point"] = True

        # 分割实线区域
        # solid line start index in navi centerline
        is_muilt_lane_scene = len(drivable_centerline_list) > 1
        for centerline in navi_centerline_list:
            id = centerline[3]
            # boundary solid line start point
            if navi_centerline_info[id]:
                center_line_potins = centerline[0]
                navi_centerline_info[id]["solid_line_start_index"] = None
                left_boundary_solid_start_p = right_boundary_solid_start_p = np.array([])
                left_boundary_all_solid_point = right_boundary_all_solid_point = False
                left_boundary_index = navi_centerline_info[id]["left_boundary_index"]
                if left_boundary_index is not None and len(solid_line_start_info[left_boundary_index]):
                    left_boundary_solid_start_p = solid_line_start_info[left_boundary_index]["solid_line_start_point"]
                    left_boundary_all_solid_point = solid_line_start_info[left_boundary_index]["is_all_solid_point"]
                right_boundary_index = navi_centerline_info[id]["right_boundary_index"]
                if right_boundary_index is not None and len(solid_line_start_info[right_boundary_index]):
                    right_boundary_solid_start_p = solid_line_start_info[right_boundary_index]["solid_line_start_point"]
                    right_boundary_all_solid_point = solid_line_start_info[right_boundary_index]["is_all_solid_point"]

                # #  虚实线点仲裁
                if is_muilt_lane_scene and id == drivable_centerline_list[0][3]:  # 最左侧
                    boundary_solid_start_p = right_boundary_solid_start_p
                elif is_muilt_lane_scene and id == drivable_centerline_list[-1][3]:  # 最右侧
                    boundary_solid_start_p = left_boundary_solid_start_p
                elif left_boundary_all_solid_point and right_boundary_all_solid_point:
                    boundary_solid_start_p = (
                        left_boundary_solid_start_p
                        if left_boundary_solid_start_p[0] > right_boundary_solid_start_p[0]
                        else right_boundary_solid_start_p
                    )
                elif (
                    len(left_boundary_solid_start_p)
                    and len(right_boundary_solid_start_p)
                    and (not (left_boundary_all_solid_point or right_boundary_all_solid_point))
                ):
                    if abs(left_boundary_solid_start_p[0] - right_boundary_solid_start_p[0]) < 10.0:
                        boundary_solid_start_p = (left_boundary_solid_start_p + right_boundary_solid_start_p) / 2.0
                    else:
                        boundary_solid_start_p = (
                            left_boundary_solid_start_p
                            if left_boundary_solid_start_p[0] > right_boundary_solid_start_p[0]
                            else right_boundary_solid_start_p
                        )
                elif (not left_boundary_all_solid_point) and len(left_boundary_solid_start_p):
                    boundary_solid_start_p = left_boundary_solid_start_p
                elif (not right_boundary_all_solid_point) and len(right_boundary_solid_start_p):
                    boundary_solid_start_p = right_boundary_solid_start_p
                else:
                    boundary_solid_start_p = np.array([])
                # find boundary solid line start point in navi centerline
                if len(boundary_solid_start_p):
                    dist = np.linalg.norm((center_line_potins - boundary_solid_start_p[:2])[:, :2], axis=1)
                    solid_line_start_index = np.argmin(dist).item()
                    navi_centerline_info[id]["solid_line_start_index"] = solid_line_start_index

        return navi_centerline_info

    def _fill_navi_centerline_global_v3(self, data, navi_centerline_list_all):

        timestamps = sorted(data["timestamp_list"])

        for ts in timestamps:
            navi_centerlines = []
            for navi_centerline_list, navi_centerline_info, origin_pose in navi_centerline_list_all:
                if len(navi_centerline_list) < 1:
                    continue
                else:
                    inv_car_pose = np.linalg.inv(data[ts]["car_pose"])
                    convert_mat = inv_car_pose @ origin_pose
                    for navi_lane in navi_centerline_list:
                        new_points = np.array(navi_lane[0], dtype=np.float32)
                        new_points = ego2global(new_points, convert_mat)
                        solid_line_start_index = None
                        if (
                            navi_centerline_info is not None
                            and navi_centerline_info[navi_lane[3]]
                            and navi_centerline_info[navi_lane[3]]["solid_line_start_index"] is not None
                        ):
                            solid_line_start_index = navi_centerline_info[navi_lane[3]]["solid_line_start_index"]
                        navi_centerlines.append(
                            {
                                "points": new_points,
                                "type": navi_lane[1],
                                "confidence": navi_lane[2],
                                "solid_line_start_index": solid_line_start_index,
                                "id": navi_lane[3],
                            }
                        )

            data[ts]["navi_centerlines"] = navi_centerlines

        return data

    def _fill_navi_centerline_global_v4(self, data,
            navi_centerline_list_all,
            highlight_centerline_list_all,
            not_navi_centerline_list_all):
        """
        将导航中心线（包括相邻车道）填充到所有时间戳

        Modified: 支持相邻车道的部分中心线
        """
        timestamps = sorted(data["timestamp_list"])

        for ts in timestamps:
            navi_centerlines = []
            for navi_centerline_list, navi_centerline_info, origin_pose in navi_centerline_list_all:
                if len(navi_centerline_list) < 1:
                    continue
                else:
                    inv_car_pose = np.linalg.inv(data[ts]["car_pose"])
                    convert_mat = (inv_car_pose @ origin_pose).astype(np.float32)

                    for navi_lane in navi_centerline_list:
                        new_points = ego2global(navi_lane[0], convert_mat)

                        solid_line_start_index = None
                        is_adjacent = False  # 标记是否为相邻车道

                        # 检查是否为相邻车道
                        if (navi_centerline_info is not None and navi_lane[3] in navi_centerline_info):
                            lane_info = navi_centerline_info[navi_lane[3]]

                            # 获取实线起始索引（导航车道有，相邻车道为None）
                            if lane_info.get("solid_line_start_index") is not None:
                                solid_line_start_index = lane_info["solid_line_start_index"]

                            # 标记是否为相邻车道
                            is_adjacent = lane_info.get("is_adjacent", False)

                        navi_centerlines.append({
                            "points": new_points,
                            "type": navi_lane[1],
                            "confidence": navi_lane[2],
                            "solid_line_start_index": solid_line_start_index,
                            "id": navi_lane[3],
                            "is_adjacent": is_adjacent,  # 新增字段，标识相邻车道
                        })
            # 2.
            highlight_centerlines = []
            for highlight_centerline_list, navi_centerline_info, origin_pose in highlight_centerline_list_all:
                if len(highlight_centerline_list) < 1:
                    continue
                else:
                    inv_car_pose = np.linalg.inv(data[ts]['car_pose'])
                    convert_mat = inv_car_pose @ origin_pose
                    for navi_lane in highlight_centerline_list:
                        new_points = np.array(navi_lane[0], dtype=np.float32)
                        new_points = ego2global(new_points, convert_mat)
                        solid_line_start_index = None
                        if (
                            navi_centerline_info is not None
                            and navi_centerline_info[navi_lane[3]]
                            and navi_centerline_info[navi_lane[3]]['solid_line_start_index'] is not None
                        ):
                            solid_line_start_index = navi_centerline_info[navi_lane[3]]['solid_line_start_index']
                        highlight_centerlines.append(
                            {
                                'points': new_points,
                                'type': navi_lane[1],
                                'confidence': navi_lane[2],
                                'solid_line_start_index':solid_line_start_index,
                                'id': navi_lane[3]
                            }
                        )
            # 3.
            not_navi_centerlines = []
            for not_navi_centerlines_list, navi_centerline_info, origin_pose in not_navi_centerline_list_all:
                if len(not_navi_centerlines_list) < 1:
                    continue
                else:
                    inv_car_pose = np.linalg.inv(data[ts]['car_pose'])
                    convert_mat = inv_car_pose @ origin_pose
                    for navi_lane in not_navi_centerlines_list:
                        new_points = np.array(navi_lane[0], dtype=np.float32)
                        new_points = ego2global(new_points, convert_mat)
                        solid_line_start_index = None
                        if (
                            navi_centerline_info is not None
                            and navi_centerline_info[navi_lane[3]]
                            and navi_centerline_info[navi_lane[3]]['solid_line_start_index'] is not None
                        ):
                            solid_line_start_index = navi_centerline_info[navi_lane[3]]['solid_line_start_index']
                        not_navi_centerlines.append(
                            {
                                'points': new_points,
                                'type': navi_lane[1],
                                'confidence': navi_lane[2],
                                'solid_line_start_index':solid_line_start_index,
                                'id': navi_lane[3]
                            }
                        )

            data[ts]["navi_centerlines"] = navi_centerlines
            data[ts]['highlight_centerlines'] = highlight_centerlines
            data[ts]['not_navi_centerlines'] = not_navi_centerlines

        return data

    def calc_navi_centerline_v3(self, data, timestamps):

        # 全局共享信息, 与timestamps对齐
        navi_info_all, scene_info_all = self.parse_navi_info(data, timestamps)
        unique_scene_id = self._select_navi_scene_id(navi_info_all, scene_info_all)
        label_time_index_list = self._select_navi_time(unique_scene_id, scene_info_all, timestamps)

        # construct sub env
        navi_centerline_list_all = []
        for label_time_index in label_time_index_list:
            sub_timestamps = timestamps[label_time_index[1] : label_time_index[2] + 1]
            sub_navi_info_all = navi_info_all[label_time_index[1] : label_time_index[2] + 1]
            sub_scene_info_all = scene_info_all[label_time_index[1] : label_time_index[2] + 1]
            sub_navi_raw_data, origin_pose = self._construct_navi_env_v3(
                data, sub_timestamps, sub_navi_info_all, sub_scene_info_all, label_time_index[0]
            )
            time_stamp, navi_centerline_list, navi_centerline_info = self._get_navi_env_info_v3(
                sub_navi_raw_data, label_time_index[0]
            )
            navi_centerline_list_all.append([navi_centerline_list, navi_centerline_info, origin_pose])

        data = self._fill_navi_centerline_global_v3(data, navi_centerline_list_all)

        return data

    def calc_navi_centerline_v4(self, data, timestamps):
        """主函数，完整流程"""

        # 1. 全局共享信息, 与timestamps对齐
        navi_info_all, scene_info_all = self.parse_navi_info(data, timestamps)
        unique_scene_id = self._select_navi_scene_id(navi_info_all, scene_info_all)
        label_time_index_list = self._select_navi_time(unique_scene_id, scene_info_all, timestamps)

        # 2. construct sub env - 为每个路口构建导航中心线
        navi_centerline_list_all = []
        highlight_centerline_list_all = []
        not_navi_centerline_list_all = []
        for label_time_index in label_time_index_list:
            sub_timestamps = timestamps[label_time_index[1] : label_time_index[2] + 1]
            sub_navi_info_all = navi_info_all[label_time_index[1] : label_time_index[2] + 1]
            sub_scene_info_all = scene_info_all[label_time_index[1] : label_time_index[2] + 1]

            # 构建子环境
            sub_navi_raw_data, origin_pose = self._construct_navi_env_v3(
                data, sub_timestamps, sub_navi_info_all, sub_scene_info_all, label_time_index[0]
            )

            # 获取导航中心线（包括相邻车道）
            (time_stamp,
            navi_centerline_list,
            navi_centerline_info,
            highlight_centerline_list_stitch,
            not_navi_centerline_list_stitch) = self._get_navi_env_info_v4( sub_navi_raw_data, label_time_index[0])

            navi_centerline_list_all.append([navi_centerline_list, navi_centerline_info, origin_pose])
            highlight_centerline_list_all.append([highlight_centerline_list_stitch, None, origin_pose])
            not_navi_centerline_list_all.append([not_navi_centerline_list_stitch, None, origin_pose])

        # 3. 填充到所有时间戳
        data = self._fill_navi_centerline_global_v4(data, navi_centerline_list_all,
                    highlight_centerline_list_all, not_navi_centerline_list_all)

        return data

    def _fill_navi_centerline_from_hd(self, data, timestamps, hd_info_ts0):
        # get navi center line from hdmap
        for ts in timestamps:
            # 获取功能状态
            nadsts = 'DANADSt_Unknown'
            drv_intract_nfo = data[ts].get('drv_intract_nfo',{})
            if len(drv_intract_nfo) > 0:
                np_drv_if = drv_intract_nfo.get('NpDrvIF', {})
                if len(np_drv_if) > 0:
                    nadsts = np_drv_if.get("DANADSts", "DANADSt_Unknown")
            min_merge_point_dist_ts = 10000
            min_change_end_dist_ts = 10000
            least_lc_dist = 10000
            if nadsts != 'DANADSt_NADTrsnDmd':
                navi_centerline_list_origin_from_hd = []
                virtual_walls = []
                hd_info_ts =  data[ts].get('hd_info',{})
                if len(hd_info_ts) > 0:
                    H = hd_info_ts.get('H',{})
                    h_ref = hd_info_ts.get('h_ref',None)
                    n_hat = hd_info_ts.get('n_hat',{})
                    n_hat_wall = hd_info_ts.get('n_hat_wall',{})
                if len(H) > 0 and h_ref is not None and len(n_hat) > 0:
                    hd_info = hd_info_ts0
                else:
                    hd_info = hd_info_ts
                for index, navi_centerline in enumerate(hd_info.get('navi_centerline', {})):   # dict
                    if navi_centerline['confidence'] != 1.0 or navi_centerline['type'] == 99:
                        continue

                    points = np.array(navi_centerline['points'])

                    if len(points) < 1:
                        continue
                    if len(H) > 0 and h_ref is not None and len(n_hat) > index:
                        ecef_t = points + h_ref * n_hat[index]
                        new_points = ecef_points_to_vehicle(H, ecef_t)
                    else:
                        new_points = points
                    merge_in = navi_centerline.get('merge_in',False)
                    merge_point_dist = new_points[-1][0]
                    change_start_index = navi_centerline.get('change_start_index',None)
                    change_end_index = navi_centerline.get('change_end_index',None)
                    change_index = None
                    change_start_dist = None
                    change_end_dist = None
                    change_dist = None
                    if merge_in:
                        if change_start_index is not None and (change_start_index <= 0 or change_start_index >= len(new_points)):
                            change_start_index = None
                        if change_end_index is not None and (change_end_index < 0 or change_end_index >= len(new_points)):
                            change_end_index = None
                        if change_start_index is not None:
                            change_start_dist = new_points[change_start_index][0]
                        if change_end_index is not None:
                            change_end_dist = new_points[change_end_index][0]

                        if change_start_dist is not None and change_end_dist is not None:
                            merge_change_range = change_end_dist - change_start_dist
                            if  merge_change_range > 0.0:
                                if merge_change_range < 100.0:
                                    change_dist = min(change_start_dist + 45.0, change_start_dist + 0.6*merge_change_range)
                                else:
                                    change_dist = change_start_dist + 60.0
                        elif change_start_dist is not None:
                            change_dist = change_start_dist + 60.0
                        elif change_end_dist is not None:
                            change_dist = min (merge_point_dist - 100.0, change_end_dist - 80.0)
                        else:
                            change_dist = merge_point_dist - 100.0
                        if change_dist is not None:
                            for i in range(0, len(new_points)):
                                if new_points[i][0] > change_dist:
                                    change_index = i
                                    break
                    solid_line_start_index = navi_centerline.get('solid_line_start_index',None)
                    merge_point_dist = new_points[-1][0]
                    if merge_point_dist < min_merge_point_dist_ts and merge_point_dist > -10:
                        min_merge_point_dist_ts = merge_point_dist

                    if merge_point_dist < min_merge_point_dist_ts and merge_point_dist > -10.0:
                        min_merge_point_dist_ts = merge_point_dist
                    if change_end_dist is not None and change_end_dist < min_change_end_dist_ts and change_end_dist > -10.0:
                        min_change_end_dist_ts = change_end_dist
                    # 计算第一列（x坐标）的绝对值
                    x_abs = np.abs(new_points[:, 0])
                    # 找到最接近0的点的索引
                    closest_index = np.argmin(x_abs)
                    # 获取对应的y值和完整点坐标
                    closest_y = new_points[closest_index, 1]
                    closest_point = new_points[closest_index]
                    navi_centerline_list_origin_from_hd.append(
                        {
                            'points': new_points,
                            'type': None,
                            'confidence': None,
                            'solid_line_start_index': None,
                            'change_start_index':change_start_index,
                            'change_end_index':change_end_index,
                            'change_index':change_index,
                            'id': index,
                            'merge_in': merge_in,
                            'merge_point_dist':merge_point_dist,
                            'change_start_dist':change_start_dist,
                            'change_end_dist':change_end_dist,
                            'change_dist':change_dist,
                            'closest_y':closest_y,
                            'source' : 0
                        }
                    )
                if True or data[ts]["is_in_ramp"]:
                    least_lc_dist = min(data[ts]["least_lc_dist"], min_merge_point_dist_ts, min_change_end_dist_ts)
                else:
                    least_lc_dist = data[ts]["least_lc_dist"]

                if len(navi_centerline_list_origin_from_hd) > 0 and least_lc_dist < 2000:
                    merge_info = []
                    for i in range(len(navi_centerline_list_origin_from_hd)):
                        if navi_centerline_list_origin_from_hd[i].get('merge_in',False) == True:
                            merge_info.append([i, navi_centerline_list_origin_from_hd[i].get('merge_point_dist',10000)])
                    sorted_merge_info = sorted(merge_info, key=lambda x: x[1])
                    merge_ln_cut_list = []
                    for i in range(len(sorted_merge_info)):
                        points = navi_centerline_list_origin_from_hd[sorted_merge_info[i][0]]['points']
                        merge_point_dist = navi_centerline_list_origin_from_hd[sorted_merge_info[i][0]].get('merge_point_dist',10000)
                        closest_y = navi_centerline_list_origin_from_hd[sorted_merge_info[i][0]].get('closest_y',10000)
                        cut_x = merge_point_dist - 100
                        for j in range(len(merge_ln_cut_list)):
                            if abs(closest_y - navi_centerline_list_origin_from_hd[merge_ln_cut_list[j][0]].get('closest_y',10000)) < 5.0 and abs(closest_y - navi_centerline_list_origin_from_hd[merge_ln_cut_list[j][0]].get('closest_y',10000)) > 2.0:
                                cut_x = max(navi_centerline_list_origin_from_hd[merge_ln_cut_list[j][0]].get('merge_point_dist',10000),cut_x)
                        change_index = navi_centerline_list_origin_from_hd[sorted_merge_info[i][0]]['change_index']
                        if change_index is not None and change_index+1 in range(0,len(navi_centerline_list_origin_from_hd[sorted_merge_info[i][0]]['points'])):
                            navi_centerline_list_origin_from_hd[sorted_merge_info[i][0]]['points'] = navi_centerline_list_origin_from_hd[sorted_merge_info[i][0]]['points'][:change_index+1]
                        else:
                            for m in range(len(points)):
                                if(points[m][0] > cut_x):
                                    navi_centerline_list_origin_from_hd[sorted_merge_info[i][0]]['points'] = navi_centerline_list_origin_from_hd[sorted_merge_info[i][0]]['points'][:m]
                                    break
                        merge_ln_cut_list.append(sorted_merge_info[i])
                    data[ts]['navi_centerlines'] = navi_centerline_list_origin_from_hd
                if least_lc_dist < 2000:
                    for index, virtual_wall in enumerate(hd_info.get('virtual_wall', [])): # dict
                        start_point = np.array(virtual_wall.get('start_point'))
                        end_point = np.array(virtual_wall.get('end_point'))

                        if len(start_point) < 1 or len(end_point) < 1:
                            continue
                        if len(H) > 0 and h_ref is not None and len(n_hat_wall) > index:
                            ecef_s = start_point + h_ref * n_hat_wall[index]
                            start_point = ecef_points_to_vehicle(H, ecef_s)[0]
                            ecef_e = end_point + h_ref * n_hat_wall[index]
                            end_point = ecef_points_to_vehicle(H, ecef_e)[0]
                        virtual_walls.append(
                            {
                                'start_point': start_point,
                                'end_point': end_point,
                                'id': index
                            }
                        )
                    if len(hd_info.get('virtual_wall', {})) > 0 and len(virtual_walls) > 0:
                        data[ts]['virtual_wall'] = virtual_walls
                data[ts]['least_lc_dist'] = least_lc_dist
            data[ts]['min_merge_point_dist'] = min_merge_point_dist_ts
            data[ts]['least_lc_dist'] = least_lc_dist
        return data

    def calc_highway_navi_centerline(self, data, timestamps):
        hd_info_ts0 = data[timestamps[0]].get("hd_info", {})
        return self._fill_navi_centerline_from_hd(data, timestamps, hd_info_ts0)

global_navi_centerline = NaviCenterline()
