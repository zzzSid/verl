LEFT_RIGHT_TURN_MAIN_ACTION_MAPPING = {
    1: "左转",  # 左转0x1
    2: "右转",  # 右转0x2
    7: "左转调头",  # 左转调头0x7
}

NONE_ASSIST_ACTION_MAPPING = {
    0: "无",
}

ROAD_SPLIT_MAIN_ACTION_MAPPING = {
    3: "向左前方行驶",  # 向左前方行驶0x3
    4: "向右前方行驶",  # 向右前方行驶0x4
    8: "直行",  # 直行0x8
    9: "靠左",  # 靠左0x9
    10: "靠右",  # 靠右
}

ROAD_SPLIT_ASSIST_ACTION_MAPPING = {
    0: "无",
    1: "进入主路",
    2: "进入辅路",
    4: "进入匝道",
    6: "进入中间岔道",
    7: "进入右岔路",
    8: "进入左岔路",
    9: "进入右转专用道",
    10: "进入左转专用道",
    11: "进入中间道路",
    12: "进入右侧道路",
    13: "进入左侧道路",
    14: "靠右进入辅路",
    15: "靠左进入辅路",
    16: "靠右进入主路",
    17: "靠左进入主路",
    18: "靠右进入右转专用道",
    117: "进入内部路",
    118: "进入左侧第二岔路",
    119: "进入左侧第三岔路",
    120: "进入右侧第二岔路",
    121: "进入右侧第三岔路",
    122: "进入加油站道路",
    123: "进入小区道路",
    124: "进入园区道路",
    125: "上高架",
    126: "走中间岔路上高架",
    127: "走最右侧岔路上高架",
    128: "走最左侧岔路上高架",
}

CHECKER_TYPE_LACK_NAVI_GT = "lack_navi_gt"
CHECKER_TYPE_INVALID_SCENE = "invalid_scene"
CHECKER_TYPE_NOT_ARRIVED = "not_arrived"
CHECKER_TYPE_DEVIATION = "deviation"
CHECKER_TYPE_STATIC = "static"
CHECKER_TYPE_NORMAL = "normal"
CHECKER_TYPE_DEVIATION_SPECIAL = "deviation_special"
CHECKER_TYPE_FOCUS = "focus"
FOCUS_CHECKER_TYPES = [CHECKER_TYPE_FOCUS, CHECKER_TYPE_DEVIATION, CHECKER_TYPE_DEVIATION_SPECIAL]


def distance_ranges_to_target_scene(
    navi_info,
    main_actions,
    assist_actions,
    action_distance_range=(-15, 50),
    penalty_dist_thresh=30,
    action_max_distance=300,
):
    """返回指定场景的距离范围."""
    distance_ranges = []
    action_size = len(navi_info["action_list"])
    for i in range(action_size):
        main_action, assist_action, distance = navi_info["action_list"][i]
        if distance + action_distance_range[0] > action_max_distance:
            break

        if main_action in main_actions and assist_action in assist_actions:
            distance_ranges.append(
                (
                    distance + action_distance_range[0],
                    distance + action_distance_range[1],
                    distance + penalty_dist_thresh,
                )
            )

    return distance_ranges

def distance_ranges_to_current_link_only(
    navi_info,
    main_actions,
    assist_actions,
    trigger_distance=200,
):
    distance_ranges = []
    # 只看 main_action_1
    main_action  = navi_info.get("main_action_1", -1)
    assist_action = navi_info.get("assistant_action_1", -1)
    distance      = navi_info.get("link_main_distance_1", 0)

    if (distance >= trigger_distance and
        main_action in main_actions and
        assist_action in assist_actions):
        distance_ranges.append((distance, distance))
    return distance_ranges
