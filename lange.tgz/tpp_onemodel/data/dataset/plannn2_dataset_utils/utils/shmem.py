# -*- coding: utf-8 -*-
import numpy as np
import multiprocessing as mp

g_shmpool = {}


def shmpool_create(name, shm_num, shm_size=10 * 1024 * 1024):
    global g_shmpool
    if name in g_shmpool:
        raise ValueError(f"Shared memory pool {name} already exists.")
    shm_names = []
    for i in range(shm_num):
        shm = mp.shared_memory.SharedMemory(create=True, size=shm_size)
        shm_names.append(shm.name)
        shm.close()
    g_shmpool[name] = {"idx": 0, "shm_num": shm_num, "shm_size": shm_size, "shm_names": shm_names}


def shmpool_reset(name, shm_num=1):
    global g_shmpool
    if name in g_shmpool:
        assert shm_num <= g_shmpool[name]["shm_num"], "shm_num should be less than or equal to the original shm_num."
        g_shmpool[name]["idx"] = 0
    else:
        shmpool_create(name, shm_num)


def shmpool_get(name):
    global g_shmpool
    if name not in g_shmpool:
        raise ValueError(f"Shared memory pool {name} does not exist.")
    shm_idx = g_shmpool[name]["idx"]
    shm_name = g_shmpool[name]["shm_names"][shm_idx]
    g_shmpool[name]["idx"] = (shm_idx + 1) % g_shmpool[name]["shm_num"]
    return shm_name


def shmpool_destroy(name, proc_pool=None):
    global g_shmpool
    if name not in g_shmpool:
        raise ValueError(f"Shared memory pool {name} does not exist.")
    shm_names = g_shmpool[name]["shm_names"]
    if proc_pool is None:
        for shm_name in shm_names:
            release_shm(shm_name)
    else:
        proc_pool.map_async(release_shm, shm_names)
    del g_shmpool[name]


def release_shm(shm_name):
    shm = mp.shared_memory.SharedMemory(name=shm_name)
    shm.close()
    shm.unlink()


def convert_to_membuff(data, membuff, offset):
    if isinstance(data, dict):
        for key, value in data.items():
            data[key], offset = convert_to_membuff(value, membuff, offset)
    elif isinstance(data, (tuple, list)):
        for i, d in enumerate(data):
            data[i], offset = convert_to_membuff(d, membuff, offset)
    elif isinstance(data, np.ndarray):
        if data.nbytes > 0:
            offset_end = offset + data.nbytes
            shared_arr = np.ndarray(data.shape, dtype=data.dtype, buffer=membuff[offset:offset_end])
            np.copyto(shared_arr, data)
            data = {
                "__dtype__": "numpy",
                "mem_shape": data.shape,
                "mem_dtype": data.dtype,
                "mem_addr1": offset,
                "mem_addr2": offset_end,
            }
            offset = offset_end
        else:
            data = {
                "__dtype__": "numpy",
                "mem_shape": data.shape,
                "mem_dtype": data.dtype,
            }
    return data, offset


def convert_to_shm(data, shm_name=None, shm_size=10 * 1024 * 1024):
    if not isinstance(data, dict):
        return data
    assert "shm_name" not in data, "shm_name should not be in data."
    if shm_name is None:
        shm = mp.shared_memory.SharedMemory(create=True, size=shm_size)
    else:
        shm = mp.shared_memory.SharedMemory(name=shm_name)

    # membuff = np.empty(len(shm.buf), dtype=np.uint8)
    membuff = np.ndarray(len(shm.buf), dtype=np.uint8, buffer=shm.buf)
    data, offset = convert_to_membuff(data, membuff, 0)
    assert offset < shm_size, "Shared memory buffer is too small."
    data["shm_size"] = len(shm.buf)
    data["shm_name"] = shm.name
    data["shm_shape"] = membuff.shape
    data["shm_dtype"] = membuff.dtype
    return data


def convert_from_membuff(data, membuff):
    if isinstance(data, dict):
        if "__dtype__" in data:
            __dtype__ = data["__dtype__"]
            if __dtype__ == "numpy":
                mem_addr1 = data.get("mem_addr1", None)
                mem_addr2 = data.get("mem_addr2", None)
                if mem_addr1 is not None and mem_addr2 is not None:
                    data = np.ndarray(
                        data["mem_shape"], dtype=data["mem_dtype"], buffer=membuff[mem_addr1:mem_addr2]
                    ).copy()
                else:
                    data = np.empty(data["mem_shape"], dtype=data["mem_dtype"])
            else:
                raise NotImplementedError(f"Unsupported __dtype__: {__dtype__}")
        else:
            for key, value in data.items():
                data[key] = convert_from_membuff(value, membuff)
    elif isinstance(data, (tuple, list)):
        data = [convert_from_membuff(d, membuff) for d in data]
    return data


def convert_from_shm(data, shm_names=None, proc_pool=None):
    if not isinstance(data, dict):
        return data
    if "shm_name" not in data:
        return data
    shm_size = data.pop("shm_size")
    shm_name = data.pop("shm_name")
    shm_shape = data.pop("shm_shape")
    shm_dtype = data.pop("shm_dtype")
    shm = mp.shared_memory.SharedMemory(name=shm_name)
    membuff = np.ndarray(shm_shape, dtype=shm_dtype, buffer=shm.buf)
    data = convert_from_membuff(data, membuff)
    if shm_names is not None:
        shm_names.append(shm_name)
    elif proc_pool is not None:
        proc_pool.map_async(release_shm, [shm_name])
    return data
