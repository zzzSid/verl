# -*- coding: utf-8 -*-
import math
from enum import Enum

import cv2
import numpy as np
import torch
from scipy.spatial.transform import Rotation as R
from shapely.geometry import LineString
from shapely.geometry import MultiLineString
from shapely.geometry import MultiPolygon
from shapely.geometry import Polygon
from shapely.geometry import Point
from shapely.ops import nearest_points

def point_to_segment_distance(p, a, b):
    """
    计算点 p 到线段 ab 的最短距离
    p, a, b: np.array([x, y])
    """
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    p = np.asarray(p, dtype=float)
    ab = b - a
    ap = p - a
    cross = ab[0] * ap[1] - ab[1] * ap[0]
    dis = abs(cross) / (np.linalg.norm(ab) + 0.001)
    return dis

def point_to_centerline_dis(car_point, centerline):
    """
    判断点是否在中心线
    car_point: (x, y)
    centerline: np.array shape (n, 2)
    """
    min_dis = 10e6
    p = np.array(car_point, dtype=float)
    for i in range(len(centerline) - 1):
        a, b = centerline[i], centerline[i + 1]
        d = point_to_segment_distance(p, a, b)
        if d < min_dis:
            min_dis = d
    return min_dis


def normalize_angle(angle):
    return (angle + math.pi) % (2 * math.pi) - math.pi


def shortest_angle_diff(start_angle, end_angle):
    diff = normalize_angle(end_angle - start_angle)
    return diff


def interpolate_angles(start_angle, end_angle, t):
    start_angle = normalize_angle(start_angle)
    end_angle = normalize_angle(end_angle)
    diff = shortest_angle_diff(start_angle, end_angle)
    interpolated_angle = start_angle + t * diff
    return normalize_angle(interpolated_angle)


def transform_obj(objs, T):
    objs = objs.copy()
    boxes = np.eye(4, 4, dtype=np.float32)
    boxes = np.array([boxes] * objs.shape[0], dtype=np.float32)
    cos = np.cos(objs[:, 6])
    sin = np.sin(objs[:, 6])
    boxes[:, 0, 0] = cos
    boxes[:, 0, 1] = -sin
    boxes[:, 1, 0] = sin
    boxes[:, 1, 1] = cos
    boxes[:, :3, 3] = objs[:, :3]
    boxes = np.matmul(T, boxes)
    objs[:, :3] = boxes[:, :3, 3]
    objs[:, 6] = np.arctan2(boxes[:, 1, 0], boxes[:, 0, 0])
    return objs

def ego2global2d(points, T=None):
    if T is None:
        return points
    outs = np.ones((points.shape[0], 3), dtype=np.float32)
    outs[:, :2] = points[:, :2]
    outs = (T @ outs.T).T
    points = points.copy()
    points[:, :2] = outs[:, :2]
    return points

def get_rotated_rectangle(objs, T=None):
    if objs.shape[0] == 0:
        return np.empty((0, 4, 2), dtype=np.float32)

    # 全局坐标变换
    if T is not None:
        objs = transform_obj(objs, T)

    # 计算矩形的四个顶点
    hl = objs[:, 3] / 2
    hw = objs[:, 4] / 2
    corners = np.array([[-hl, -hw], [hl, -hw], [hl, hw], [-hl, hw]], dtype=np.float32)
    corners = corners.transpose(2, 0, 1)

    # 旋转矩形
    sin = np.sin(objs[:, 6])
    cos = np.cos(objs[:, 6])
    R = np.array([[cos, -sin], [sin, cos]], dtype=np.float32)
    corners = np.matmul(corners, R.transpose(2, 1, 0))

    # 平移矩形
    corners += objs[:, None, :2]

    return corners


def get_rotated_rectangle_torch(objs):
    n = objs.shape[0]
    if n == 0:
        return torch.zeros(0, 4, 2, device=objs.device, dtype=objs.dtype)

    # 全局坐标变换
    objs = objs.clone()

    # 计算矩形的四个顶点
    hl = objs[:, 3] / 2  # n
    hw = objs[:, 4] / 2  # n
    corners = torch.stack(
        [
            torch.stack([-hl, -hw], dim=1),
            torch.stack([hl, -hw], dim=1),
            torch.stack([hl, hw], dim=1),
            torch.stack([-hl, hw], dim=1),
        ],
        dim=1,
    )  # n x 4 x 2

    # 旋转矩形
    sin = torch.sin(objs[:, 6])
    cos = torch.cos(objs[:, 6])
    R = torch.stack([cos, -sin, sin, cos], dim=1).view(n, 2, 2)
    corners = corners @ R.transpose(1, 2)

    # 平移矩形
    corners += objs[:, None, :2]

    return corners


def get_relative_pose_from_obj(obj1, obj2):
    """
    obj1, obj2: at least 7 dim, x, y, z, l, w, h, yaw, ....
    """
    obj1_pose = np.eye(4)
    obj1_pose[:3, :3] = R.from_euler("z", obj1[6]).as_matrix()
    obj1_pose[:3, 3] = obj1[:3]
    obj2_pose = np.eye(4)
    obj2_pose[:3, :3] = R.from_euler("z", obj2[6]).as_matrix()
    obj2_pose[:3, 3] = obj2[:3]
    return np.linalg.inv(obj1_pose) @ obj2_pose


def get_xyyaw_from_polygon(corners):
    """
    corners: n x 4 x 2
    return: n x 7
    """
    xy = corners.mean(axis=1)
    x = xy[:, 0]
    y = xy[:, 1]
    z = np.zeros_like(x)
    pxpy = corners[:, 1:3].mean(axis=1)
    px = pxpy[:, 0]
    py = pxpy[:, 1]
    yaw = np.arctan2(py - y, px - x)  # n
    l = np.linalg.norm(corners[:, 0] - corners[:, 1], axis=1)
    w = np.linalg.norm(corners[:, 1] - corners[:, 2], axis=1)
    h = np.zeros_like(l) + 2
    return np.stack([x, y, z, l, w, h, yaw], axis=1)


def get_xyyaw_from_polygon_torch(corners):
    """
    corners: n x 4 x 2
    return: n x 7
    """
    xy = corners.mean(dim=1)  # n x 2
    x = xy[:, 0]
    y = xy[:, 1]
    z = torch.zeros_like(x)

    pxpy = corners[:, 1:3].mean(dim=1)  # n x 2
    px = pxpy[:, 0]
    py = pxpy[:, 1]

    yaw = torch.atan2(py - y, px - x)  # n

    l = torch.norm(corners[:, 0] - corners[:, 1], dim=1)  # n
    w = torch.norm(corners[:, 1] - corners[:, 2], dim=1)  # n

    h = torch.zeros_like(l) + 2

    return torch.stack([x, y, z, l, w, h, yaw], dim=1)  # n x 7


def ego2global(points, T=None):
    if T is None:
        return points
    if points.shape[1] == 2:
        pzeros = np.zeros((points.shape[0], 1), dtype=points.dtype)
        points = np.hstack((points, pzeros))
    outs = np.ones((points.shape[0], 4), dtype=np.float32)
    outs[:, :3] = points[:, :3]
    outs = (T @ outs.T).T
    if points.shape[1] == 3:
        return outs[:, :3]
    else:
        points = points.copy()
        points[:, :3] = outs[:, :3]
        return points


def ecef_points_to_vehicle(H_ecef: np.ndarray, ecef_points: np.ndarray) -> np.ndarray:
    pts = np.asarray(ecef_points, dtype=float)
    ones = np.ones((pts.shape[0], 1), dtype=float)
    pts_h = np.hstack([pts, ones])             # (N,4)
    return (H_ecef @ pts_h.T).T[:, :3]         # (N,3)


def get_corner(x, length=4.85, width=2, center_shift=0, dlength=0, dwidth=0):
    b = np.array([[0.5, 0.5], [0.5, -0.5], [-0.5, -0.5], [-0.5, 0.5]])
    b[:, 0] *= length
    b[:, 1] *= width
    b[:, 0] += center_shift
    b[[0, 1], 0] += dlength / 2
    b[[2, 3], 0] -= dlength / 2
    b[[0, 3], 1] += dwidth / 2
    b[[1, 2], 1] -= dwidth / 2

    sin, cos = np.sin(x[2]), np.cos(x[2])
    b = np.stack([b[:, 0] * cos - b[:, 1] * sin, b[:, 0] * sin + b[:, 1] * cos], axis=1)
    b[:, 0] += x[0]
    b[:, 1] += x[1]
    return b


def get_corners(X, length=4.85, width=2, center_shift=0):
    n = len(X)
    b = np.array([[0.5, 0.5], [0.5, -0.5], [-0.5, -0.5], [-0.5, 0.5]])
    b[:, 0] *= length
    b[:, 1] *= width
    b[:, 0] += center_shift
    B = np.tile(b, (n, 1, 1))
    sin, cos = np.sin(X[:, 2]), np.cos(X[:, 2])
    B = np.stack(
        [
            B[:, :, 0] * cos[:, None] - B[:, :, 1] * sin[:, None],
            B[:, :, 0] * sin[:, None] + B[:, :, 1] * cos[:, None],
        ],
        axis=2,
    )
    B[:, :, 0] += X[:, 0].reshape(-1, 1)
    B[:, :, 1] += X[:, 1].reshape(-1, 1)
    return B


def transform_polygon(polygons, labels, vehicle_tokenizer, pedestrian_tokenizer):
    """
    Args:
        polygons: ... x 4 x 2
        labels: ...
    Returns:
        new_polygons: ... x 4 x 2
    """
    original_shape = polygons.shape
    polygons = polygons.reshape(-1, 4, 2)  # n*4 x 2
    labels = labels.reshape(-1)  # n

    state_info = get_xyyaw_from_polygon(polygons)  # n x 7

    # 确定label是vehicle还是pedestrian
    new_state = []
    for xyzlwhyaw, label in zip(state_info, labels):
        x, y, z, l, w, h, yaw = xyzlwhyaw
        if label < len(vehicle_tokenizer):
            dx, dy, dyaw = vehicle_tokenizer.decode(label)
            # from polygon to x, y, yaw
            cosyaw = np.cos(yaw)
            sinyaw = np.sin(yaw)
            # transform
            ego = np.array([[cosyaw, -sinyaw, x], [sinyaw, cosyaw, y], [0, 0, 1]])
            x2, y2 = (ego @ np.array([dx, dy, 1]))[:2]
            yaw2 = yaw + dyaw
            new_state.append([x2, y2, z, l, w, h, yaw2])
        else:
            label = label - len(vehicle_tokenizer)
            dx, dy = pedestrian_tokenizer.decode(label)
            x2, y2 = x + dx, y + dy
            new_state.append([x2, y2, z, l, w, h, yaw])
    state_info = np.array(new_state)
    new_polygons = get_rotated_rectangle(state_info)

    new_polygons = new_polygons.reshape(original_shape)
    return new_polygons


def transform_polygon_torch(polygons, labels, vehicle_tokenizer, pedestrian_tokenizer=None):
    """
    Args:
        polygons: ... x 4 x 2
        labels: ...
    Returns:
        new_polygons: ... x 4 x 2
    """
    original_shape = polygons.shape
    polygons = polygons.reshape(-1, 4, 2)  # n*4 x 2
    labels = labels.reshape(-1)  # n
    n = polygons.shape[0]
    labels_np = labels.cpu().numpy()

    state_info = get_xyyaw_from_polygon_torch(polygons)  # n x 7

    # ego
    x, y, yaw = state_info[:, [0, 1, 6]].T  # n
    cos, sin = torch.cos(yaw), torch.sin(yaw)  # n
    transform = torch.stack(
        [
            torch.stack([cos, -sin, x], dim=1),
            torch.stack([sin, cos, y], dim=1),
            torch.tensor([0.0, 0.0, 1.0], device=polygons.device, dtype=polygons.dtype).unsqueeze(0).expand(n, 3),
        ],
        dim=1,
    )  # n x 3 x 3

    # 全部按照vehicle计算一次
    vehicle_labels = np.clip(labels_np, 0, len(vehicle_tokenizer) - 1)
    vehicle_action = torch.from_numpy(vehicle_tokenizer.decode(vehicle_labels)).to(
        polygons.device, dtype=polygons.dtype
    )  # n x 3
    xy_one = torch.stack(
        [
            vehicle_action[:, 0],
            vehicle_action[:, 1],
            torch.ones_like(vehicle_action[:, 0]),
        ],
        dim=1,
    ).unsqueeze(2)
    xy = transform @ xy_one  # n x 3 x 1
    vx, vy = xy[:, 0, 0], xy[:, 1, 0]
    vyaw = yaw + vehicle_action[:, 2]
    v_state = torch.stack(
        [
            vx,
            vy,
            state_info[:, 2],
            state_info[:, 3],
            state_info[:, 4],
            state_info[:, 5],
            vyaw,
        ],
        dim=1,
    )  # n x 7

    if pedestrian_tokenizer is not None:
        is_vehicle = labels < len(vehicle_tokenizer)
        # 全部按照pedestrian计算一次
        pedestrian_labels = labels_np - len(vehicle_tokenizer)
        pedestrian_labels = np.clip(pedestrian_labels, 0, len(pedestrian_tokenizer) - 1)
        pedestrian_action = torch.from_numpy(pedestrian_tokenizer.decode(labels_np - len(vehicle_tokenizer))).to(
            polygons.device, dtype=polygons.dtype
        )  # n x 2
        px = x + pedestrian_action[:, 0]
        py = y + pedestrian_action[:, 1]
        p_state = torch.stack(
            [
                px,
                py,
                state_info[:, 2],
                state_info[:, 3],
                state_info[:, 4],
                state_info[:, 5],
                yaw,
            ],
            dim=1,
        )  # n x 7
        # 合并
        v_state = v_state * is_vehicle.unsqueeze(1) + p_state * (~is_vehicle.unsqueeze(1))
    new_polygons = get_rotated_rectangle_torch(v_state)
    new_polygons = new_polygons.reshape(original_shape)
    return new_polygons

def transform_polygon_torch_5s(init_polygons, actions, state_range=1.0):
    """
    Args:
        init_polygons: [B, 4, 2]  初始多边形位置
        actions:       [B, T, 3]  动作序列 (dx, dy, dyaw)
        state_range:   float, 坐标归一化尺度
    Returns:
        polygons: [B, T, 4, 2] 未来 T 帧多边形
    """
    B, _, _ = init_polygons.shape
    T = actions.shape[1]

    # ---- STEP 1: decode actions ----
    dx, dy, dyaw = actions[..., 0], actions[..., 1], actions[..., 2]  # [B, T]

    # ---- STEP 2: 初始化输出 ----
    polygons = torch.zeros(B, T, 4, 2, device=init_polygons.device, dtype=init_polygons.dtype)

    half_l = torch.norm(init_polygons[:, 1] - init_polygons[:, 0], dim=1) / 2
    half_w = torch.norm(init_polygons[:, 1] - init_polygons[:, 2], dim=1) / 2

    corners = torch.stack(
        [
            torch.stack([-half_l, -half_w], dim=1),
            torch.stack([ half_l, -half_w], dim=1),
            torch.stack([ half_l,  half_w], dim=1),
            torch.stack([-half_l,  half_w], dim=1),
        ],
        dim=1,
    )  # [B, 4, 2]

    # prev_poly 表示上一帧多边形（初始是 init_polygons）
    prev_poly = init_polygons

    # ---- STEP 3: 计算每一步 polygon ----
    for t in range(T):
        # 计算前一帧的旋转矩阵（多边形自身方向）
        direct = prev_poly[ :, 1] - prev_poly[:, 0]   # [B, 2]
        yaw_prev = torch.atan2(direct[:, 1], direct[:, 0])
        sin_p = torch.sin(yaw_prev)
        cos_p = torch.cos(yaw_prev)

        # polygon 内部旋转+平移矩阵
        pose = torch.eye(3, device=init_polygons.device, dtype=init_polygons.dtype).unsqueeze(0).repeat(B, 1, 1)
        pose[:, 0, 0] = cos_p
        pose[:, 0, 1] = -sin_p
        pose[:, 1, 0] = sin_p
        pose[:, 1, 1] = cos_p
        pose[:, 0, 2] = prev_poly.mean(dim=1)[:, 0]
        pose[:, 1, 2] = prev_poly.mean(dim=1)[:, 1]

        # 动作变换矩阵
        TR = torch.eye(3, device=init_polygons.device, dtype=init_polygons.dtype).unsqueeze(0).repeat(B, 1, 1)
        sin_a = torch.sin(dyaw[:, t])
        cos_a = torch.cos(dyaw[:, t])
        TR[:, 0, 0] = cos_a
        TR[:, 0, 1] = -sin_a
        TR[:, 1, 0] = sin_a
        TR[:, 1, 1] = cos_a
        TR[:, 0, 2] = dx[:, t] / state_range
        TR[:, 1, 2] = dy[:, t] / state_range

        # ---- STEP 4: 变换并生成下一帧 ----
        final_pose = torch.matmul(pose, TR)  # [B, 3, 3]
        R = final_pose[:, :2, :2]
        t_trans = final_pose[:, :2, 2].unsqueeze(1)
        new_poly = corners @ R.transpose(-1, -2) + t_trans  # [B, 4, 2]

        # 写入输出
        polygons[:, t] = new_poly

        # 更新 prev_poly 给下一轮
        prev_poly = new_poly

    return polygons  # [B, T, 4, 2]


def transform_polygon_torch_v2(polygons, labels, vehicle_tokenizer, pedestrian_tokenizer=None, state_range=1.0, actions=None):
    plyshape = polygons.shape
    polygons = polygons.reshape(-1, 4, 2)  # N x 4 x 2

    # action transformation matrix
    if actions is None:
        actions = vehicle_tokenizer.decode_torch(labels.reshape(-1))    # N x 3
    sin = torch.sin(actions[:, 2])
    cos = torch.cos(actions[:, 2])
    TR = [torch.eye(3, device=polygons.device, dtype=polygons.dtype)] * plyshape[0]
    TR = torch.stack(TR)
    TR[:, 0, 0] = cos
    TR[:, 0, 1] = -sin
    TR[:, 1, 0] = sin
    TR[:, 1, 1] = cos
    TR[:, :2, 2] = actions[:, :2] / state_range

    # polygons transformation matrix
    direct_l = polygons[:, 1] - polygons[:, 0]
    direct_w = polygons[:, 1] - polygons[:, 2]
    yaw = torch.atan2(direct_l[:, 1], direct_l[:, 0])
    sin = torch.sin(yaw)
    cos = torch.cos(yaw)
    pose = TR.clone()
    pose[:, 0, 0] = cos
    pose[:, 0, 1] = -sin
    pose[:, 1, 0] = sin
    pose[:, 1, 1] = cos
    pose[:, :2, 2] = polygons.mean(dim=1)

    # transformation
    pose = torch.matmul(pose, TR)
    hafl = torch.norm(direct_l, dim=1) / 2.  # N
    hafw = torch.norm(direct_w, dim=1) / 2.  # N
    corners = torch.stack(
        [
            torch.stack([-hafl, -hafw], dim=1),
            torch.stack([ hafl, -hafw], dim=1),
            torch.stack([ hafl,  hafw], dim=1),
            torch.stack([-hafl,  hafw], dim=1),
        ],
        dim=1,
    )   # N x 4 x 2
    corners = torch.matmul(corners, pose[:, :2, :2].permute(0, 2, 1))
    polygons = pose[:, None, :2, 2] + corners
    polygons = polygons.reshape(plyshape)

    if pedestrian_tokenizer is not None:
        raise NotImplementedError("pedestrian not implemented")

    return polygons


def get_gt_polygons(gt_dobjs, tid_at_t, full_t=None):
    """
    gt_dobjs: list of dict of {tid: (dobj, cls3, label)}
    tid_at_t: np array of n
    return: polygons: n x t x 4 x 2, masks: n x t
    """
    n = len(tid_at_t)
    t = len(gt_dobjs)
    if full_t is None:
        full_t = t
    polygons = np.zeros((n, full_t, 4, 2)) - 10000
    masks = np.zeros((n, full_t)).astype(bool)
    for ts in range(min(t, full_t)):
        gt_dobjs_at_ts = gt_dobjs[ts]
        for i, tid in enumerate(tid_at_t):
            if tid in gt_dobjs_at_ts:
                dobj, cls3, label = gt_dobjs_at_ts[tid]
                polygon = get_rotated_rectangle(dobj[None, ...])[0]
                polygons[i, ts] = polygon
                masks[i, ts] = True
    return polygons, masks

def distance_point_to_segment(x, y, x1, y1, x2, y2):

    if x1 == x2 and y1 == y2:
        return ((x - x1)**2 + (y - y1)**2)**0.5
    dx = x2 - x1
    dy = y2 - y1
    ax = x - x1
    ay = y - y1

    t_n = ax * dx + ay * dy
    t_d = dx * dx + dy * dy
    t = t_n / t_d
    if t < 0.0:
        closest_x = x1
        closest_y = y1
    elif t > 1.0:
        closest_x = x2
        closest_y = y2
    else:
        closest_x = x1 + t * dx
        closest_y = y1 + t * dy
    distance = ((x - closest_x)**2 + (y - closest_y)**2)**0.5
    return distance

def get_projection_on_segment(x, y, x1, y1, x2, y2):
    if x1 == x2 and y1 == y2:
        return np.array([])
    dx = x2 - x1
    dy = y2 - y1
    ax = x - x1
    ay = y - y1

    t_n = ax * dx + ay * dy
    t_d = dx * dx + dy * dy
    t = t_n / t_d
    if t < 0.0 or t > 1.0:
        return np.array([])

    return np.array((x1 + t * dx, y1 + t * dy))


def get_lines_distance(lines, pt):
    # lines: n * 2
    # return sorted index and distance
    lines_distance = dict()
    for i, poly_line in enumerate(lines):
        dist = distance_point_to_segment(pt[0], pt[1],
                                            poly_line[0, 0], poly_line[0, 1],
                                            poly_line[1, 0], poly_line[1, 1])
        lines_distance[i] = dist
    sorted_lines_distance = dict(sorted(lines_distance.items(), key=lambda item: item[1]))
    sorted_lines_index = list(sorted_lines_distance.keys())

    return sorted_lines_index, sorted_lines_distance

def direction(p1, p2, p3):
    return (p2[0] - p1[0]) * (p3[1] - p1[1]) - (p2[1] - p1[1]) * (p3[0] - p1[0])

def on_segment(p, seg_p1, seg_p2):
    return (min(seg_p1[0], seg_p2[0]) <= p[0] <= max(seg_p1[0], seg_p2[0]) and
            min(seg_p1[1], seg_p2[1]) <= p[1] <= max(seg_p1[1], seg_p2[1]))

def segment_intersect(a1, a2, b1, b2):
    d1 = direction(b1, b2, a1)
    d2 = direction(b1, b2, a2)
    d3 = direction(a1, a2, b1)
    d4 = direction(a1, a2, b2)

    if (d1 * d2 < 0) and (d3 * d4 < 0):
        return True

    if d1 == 0 and on_segment(a1, b1, b2):
        return True
    if d2 == 0 and on_segment(a2, b1, b2):
        return True
    if d3 == 0 and on_segment(b1, a1, a2):
        return True
    if d4 == 0 and on_segment(b2, a1, a2):
        return True
    return False

def line_intersection_point(a1, a2, b1, b2):

    d = (a2[0] - a1[0]) * (b2[1] - b1[1]) - (a2[1]- a1[1]) * (b2[0] - b1[0])
    if d == 0:
        return np.array([])  # 线段平行或重合

    t = ((b1[0] - a1[0]) * (b2[1] - b1[1]) - (b1[1] - a1[1]) * (b2[0] - b1[0])) / d
    s = ((b1[0] - a1[0]) * (a2[1] - a1[1]) - (b1[1] - a1[1]) * (a2[0] - a1[0])) / d
    if 0 <= t <= 1 and 0 <= s <= 1:
        return np.array((a1[0] + t * (a2[0] - a1[0]), a1[1] + t * (a2[1] - a1[1])))

    return np.array([])  # 线段不相交

def split_points_to_segments(points):
    if len(points) < 2:
        return []
    return [ (points[i], points[i+1]) for i in range(len(points)-1) ]

def polygon_to_segments(polygon):
    return [(polygon[i], polygon[(i + 1) % 4]) for i in range(4)]

def get_vector_angle(v1, v2):
    dot_product = v1[0] * v2[0] + v1[1] * v2[1]
    norm_v1 = math.sqrt(v1[0]**2 + v1[1]**2)
    norm_v2 = math.sqrt(v2[0]**2 + v2[1]**2)

    # 处理零向量
    if norm_v1 == 0 or norm_v2 == 0:
        return 0.0  # 零向量的夹角定义为0

    cos_theta = dot_product / (norm_v1 * norm_v2)
    # 处理浮点数精度问题
    cos_theta = max(-1.0, min(1.0, cos_theta))
    theta = math.acos(cos_theta)
    return normalize_angle(theta)

def calc_path_length (path_points):
    # distance between the start point and end point
    start_points = path_points[:-1]
    end_points = path_points[1:]
    norm_vec = np.linalg.norm(end_points - start_points, axis=1)
    return np.sum(norm_vec)

def calc_path_length_from_point(polygons, point):
    idx = 0
    path = polygons.mean(axis=1)
    for i in range(1, len(path)):
        if on_segment(point, path[i-1], path[i]):
            idx = i
            break
    if idx != 0:
        new_path = np.concatenate((point.reshape(1, 2), path[idx:]), axis=0)
        return calc_path_length(new_path)
    else:
        base_pt = path[-1]
        base_polygon = polygons[-1]
        theta = get_vector_angle(base_polygon[1:3, :].mean(axis=0) - base_pt,
                                 point - base_pt)
        if abs(theta) < 1.57:    # 在stopline的左侧
            return -((base_pt[0] - point[0])**2 + (base_pt[1] - point[1])**2)**0.5
        else:                    # 在stopline的右侧
            return ((base_pt[0] - point[0])**2 + (base_pt[1] - point[1])**2)**0.5

def calc_path_idx_from_point(polygons, point):
    idx = -1
    path = polygons.mean(axis=1)
    for i in range(1, len(path)):
        if on_segment(point, path[i-1], path[i]):
            idx = i
            break
    return idx

class CollisionComputer:
    def __init__(self, grid_map_size=(100, 160), scale=20):
        """
        每个像素的精度是1 / scale 米，有效尺寸是 grid_map_size / scale 米
        如果需要更高精度，可以同步增加 grid_map_size 和 scale
        """
        self.grid_map_size = grid_map_size
        self.scale = scale
        self.shift = (grid_map_size[0] // 2, grid_map_size[1] // 2)

        self.ego_index = self._get_ego_index(4.85, 2)

    def _get_ego_index(self, l, w):
        corners = np.array([[0.5, 0.5], [0.5, -0.5], [-0.5, -0.5], [-0.5, 0.5]])
        corners[:, 0] *= l
        corners[:, 1] *= w

        grid_map = np.ones(self.grid_map_size, dtype=np.uint8) * 255
        corners = corners * self.scale + self.shift
        corners = corners.astype(int)
        self_car_map = cv2.fillPoly(grid_map, [corners], 0)
        return self_car_map == 0

    def intersection(self, T, lines, polygons):
        """
        Args:
            T: 3 x 3自车pose
            lines: list of [n x 2] 线段
            polygons: list of [4 x 2] 多边形
        Returns:
            obstacle_dt: 障碍物距离, 单位米
        """
        # 生成grid map
        grid_map = np.ones(self.grid_map_size, dtype=np.uint8) * 255

        # 将障碍物转移到原点
        inv_transform_matrix = np.linalg.inv(T)
        r = inv_transform_matrix[:2, :2]
        t = inv_transform_matrix[:2, 2]

        # 将n x 2的线段切成n - 1个 2 x 2的线段
        obstacle_lines = []
        for line in lines:
            for i in range(len(line) - 1):
                obstacle_lines.append(line[i:i+2])
        if len(obstacle_lines) > 0:
            obstacle_lines = np.array(obstacle_lines) # N x 2 x 2
            lines_np = ((r @ obstacle_lines.reshape(-1, 2).T).T + t)
            lines_np = (lines_np * self.scale + self.shift).reshape(-1, 2, 2).astype(np.int32)
            cv2.polylines(grid_map, lines_np, isClosed=False, color=0, thickness=1)

        # 将多边形转移到原点
        if len(polygons) > 0:
            polygons = np.array(polygons) # n x 4 x 2
            polygons = (r @ polygons.reshape(-1, 2).T).T + t
            polygons = (polygons * self.scale + self.shift).reshape(-1, 4, 2).astype(np.int32)
            cv2.fillPoly(grid_map, polygons, color=0)

        distance_transform_map = cv2.distanceTransform(grid_map, cv2.DIST_L2, cv2.DIST_MASK_5)
        dt_self_car = distance_transform_map[self.ego_index]
        obstacle_dt = min(1.5, np.min(dt_self_car) / self.scale)

        return obstacle_dt

    def intersection_v2_lines(self, T, lines):
        """
        Args:
            T: 3 x 3自车pose
            lines: list of [n x 2] 线段
        Returns:
            collision
        """
        # 生成grid map
        grid_map = np.ones(self.grid_map_size, dtype=np.uint8) * 255

        # 将障碍物转移到原点
        inv_transform_matrix = np.linalg.inv(T)
        r = inv_transform_matrix[:2, :2]
        t = inv_transform_matrix[:2, 2]

        # 处理静态物体 - 线段
        obstacle_lines = []
        for line in lines:
            for i in range(len(line) - 1):
                obstacle_lines.append(line[i:i+2])
        if len(obstacle_lines) > 0:
            obstacle_lines = np.array(obstacle_lines) # N x 2 x 2
            lines_np = ((r @ obstacle_lines.reshape(-1, 2).T).T + t)
            lines_np = (lines_np * self.scale + self.shift).reshape(-1, 2, 2).astype(np.int32)
            cv2.polylines(grid_map, lines_np, isClosed=False, color=0, thickness=1)

        # 计算距离变换
        distance_transform = cv2.distanceTransform(grid_map, cv2.DIST_L2, cv2.DIST_MASK_5)
        # 获取自车位置的距离
        dt = distance_transform[self.ego_index]
        min_distance = min(1.5, np.min(dt) / self.scale)
        # 判断是否碰撞
        collision = min_distance == 0
        return collision, min_distance


    def intersection_v2_polygons(self, T, polygons):
        """
        Args:
            T: 3 x 3自车pose
            polygons: list of [4 x 2] 多边形
        Returns:
            collision
        """
        # 生成grid map
        grid_map = np.ones(self.grid_map_size, dtype=np.uint8) * 255

        # 将障碍物转移到原点
        inv_transform_matrix = np.linalg.inv(T)
        r = inv_transform_matrix[:2, :2]
        t = inv_transform_matrix[:2, 2]

        # 处理多边形
        if len(polygons) > 0:
            polygons = np.array(polygons) # n x 4 x 2
            polygons = (r @ polygons.reshape(-1, 2).T).T + t
            polygons = (polygons * self.scale + self.shift).reshape(-1, 4, 2).astype(np.int32)
            cv2.fillPoly(grid_map, polygons, color=0)

        # 计算距离变换
        distance_transform = cv2.distanceTransform(grid_map, cv2.DIST_L2, cv2.DIST_MASK_5)
        # 获取自车位置的距离
        dt = distance_transform[self.ego_index]
        min_distance = min(1.5, np.min(dt) / self.scale)
        # 判断是否碰撞
        collision = min_distance == 0
        return collision, min_distance


class Turntype(Enum):
    UNKNOWN = 0
    STRAIGHT = 1
    LEFT = 2
    RIGHT = 3
    UTURN = 4


def get_turn_type_from_path(ego_polygon, stopline_pos, raw_env):
    remain_pts = 30
    path = ego_polygon.mean(axis=1)
    if len(stopline_pos) > 0:
        idx = calc_path_idx_from_point(ego_polygon,stopline_pos)
        new_path = path[idx:]
        if idx >= 0 and len(new_path) > remain_pts:
            return determine_path_turn_type(new_path)
        else:
            return {Turntype.UNKNOWN}
    else:
        return {Turntype.UNKNOWN}


def determine_path_turn_type(points):
    threshold_degree = 30
    fuzzy_threshold_degree = 20
    total_angle = 0.0
    threshold = math.radians(threshold_degree)
    fuzzy_threshold = math.radians(fuzzy_threshold_degree)

    for i in range(1, len(points)-1):
        # 前一个向量 (i-1 到 i)
        x_prev = points[i][0] - points[i-1][0]
        y_prev = points[i][1] - points[i-1][1]

        # 后一个向量 (i 到 i+1)
        x_next = points[i+1][0] - points[i][0]
        y_next = points[i+1][1] - points[i][1]

        # 计算向量模长
        mod_prev = math.hypot(x_prev, y_prev)
        mod_next = math.hypot(x_next, y_next)

        if mod_prev == 0 or mod_next == 0:
            continue  # 忽略零向量

        # 计算点积和叉积
        dot = x_prev * x_next + y_prev * y_next
        cross = x_prev * y_next - y_prev * x_next

        # 计算夹角
        cos_theta = dot / (mod_prev * mod_next)
        cos_theta = max(-1.0, min(1.0, cos_theta))
        sin_theta = cross / (mod_prev * mod_next)
        sin_theta = max(-1.0, min(1.0, sin_theta))
        delta_theta = math.atan2(sin_theta, cos_theta)

        if abs(delta_theta) > math.pi/2:
             continue

        total_angle += delta_theta

      # 判断转向类型
    if abs(total_angle) < fuzzy_threshold:
        return {Turntype.STRAIGHT}
    elif total_angle > threshold:
        return {Turntype.LEFT}
    elif total_angle > fuzzy_threshold:
        return {Turntype.LEFT, Turntype.STRAIGHT}
    elif total_angle < -threshold:
        return {Turntype.RIGHT}
    else:
        return {Turntype.RIGHT, Turntype.STRAIGHT}

def calc_nearest_dist_from_path(ego_polygon, point):
    ego_traj = ego_polygon.mean(axis=1)  # n x 2
    if len(ego_traj) < 1:
        return -1.0
    min_dist = math.hypot(ego_traj[0][0]-point[0], ego_traj[0][1]-point[1])
    for i in range(1, len(ego_traj)-1):
        min_dist = min(min_dist, math.hypot(ego_traj[i][0]-point[0], ego_traj[i][1]-point[1]))
    return min_dist

def filter_roadsign_after_stop_pos(ego_polygon, stopline_pos, roadsign_pos):
    ego_traj = ego_polygon.mean(axis=1)
    ego_stop_vec = stopline_pos - ego_traj[0]
    roadsign_stop_vec = stopline_pos - roadsign_pos
    angle = get_vector_angle(ego_stop_vec, roadsign_stop_vec)
    return angle > math.pi/2

def filter_stopline_pos_behind_ego(ego_polygon, stopline_pos):
    ego_traj = ego_polygon.mean(axis=1)
    if len(ego_traj) < 2:
        return True
    ego_traj_dir = ego_traj[1] - ego_traj[0]
    stopline_dir = stopline_pos - ego_traj[0]
    angle = get_vector_angle(ego_traj_dir, stopline_dir)
    return angle > math.pi/2

def match_road_sign_from_path(ego_polygon, stopline_pos, raw_env):
    stopline_dist_thres = 55.0
    road_sign_dist_thres = 1.5
    road_sign_list = []
    crosswalk_dist_thres = 12.0
    crosswalk_nearby = False

    for p, ptype in raw_env['road_sign']:
        if ptype != 300:
            continue
        cx, cy = p.mean(axis=0)[:2]
        # filter the road sign after the stop pos
        road_sign_pos = np.array([cx, cy])
        dist_from_stop_pos = math.hypot(stopline_pos[0] - cx, stopline_pos[1] - cy)
        #print(f"road sign: {ptype}, dist from stop pos: {dist_from_stop_pos}")
        if dist_from_stop_pos < crosswalk_dist_thres:
            crosswalk_nearby = True

    if not crosswalk_nearby:
        return road_sign_list


    for p, ptype in raw_env['road_sign']:
        if ptype >= 300 and ptype not in [905, 909]:
            continue
        #print(f"road sign: {ptype}")
        cx, cy = p.mean(axis=0)[:2]
        # filter the road sign after the stop pos
        road_sign_pos = np.array([cx, cy])
        if filter_roadsign_after_stop_pos(ego_polygon, stopline_pos, road_sign_pos):
            continue
        # calc dist from stop pos, if within threshold,
        dist_from_stop_pos = math.hypot(stopline_pos[0] - cx, stopline_pos[1] - cy)
        if dist_from_stop_pos < stopline_dist_thres:
            dist_from_road_sign = calc_nearest_dist_from_path(ego_polygon, road_sign_pos)
            #print(f"road sign: {ptype}, dist from stop pos: {dist_from_stop_pos}, dist from road sign: {dist_from_road_sign}")
            if dist_from_road_sign < road_sign_dist_thres:
                road_sign_list.append((ptype, dist_from_stop_pos))
    road_sign_list = sorted(road_sign_list, key=lambda x: x[1], reverse=True)
    return road_sign_list


def determine_road_sign_turn_type(road_sign_list):
    if len(road_sign_list) == 0:
        return {Turntype.UNKNOWN}, {}

    turn_type = 0
    forbidden = 0

    turn_type_dict={
        201: {Turntype.LEFT},
        202: {Turntype.RIGHT},
        203: {Turntype.LEFT, Turntype.RIGHT},
        204: {Turntype.STRAIGHT},
        205: {Turntype.RIGHT, Turntype.STRAIGHT},
        206: {Turntype.LEFT, Turntype.STRAIGHT},
        207: {Turntype.UTURN},
        208: {Turntype.LEFT, Turntype.UTURN},
        209: {Turntype.STRAIGHT, Turntype.UTURN}}

    forbidden_turn_type_dict={
        215: {Turntype.RIGHT},
        214: {Turntype.LEFT},
        216: {Turntype.STRAIGHT},
        217: {Turntype.UTURN},
        220: {Turntype.LEFT, Turntype.UTURN}}



    for ptype, dist in road_sign_list:
        if ptype in turn_type_dict:
            turn_type = (ptype, dist)
        if ptype in forbidden_turn_type_dict:
            forbidden = (ptype, dist)

    # check the conflict
    if turn_type != 0 and forbidden != 0:
        for item in turn_type_dict[turn_type[0]]:
            if item in forbidden_turn_type_dict[forbidden[0]]:
                if forbidden[1] < turn_type[1]:
                    turn_type = 0
                else:
                    forbidden = 0

    if turn_type != 0:
        road_sign = turn_type_dict[turn_type[0]]
    else:
        road_sign = {Turntype.UNKNOWN}

    if forbidden != 0:
        forbidden_road_sign = forbidden_turn_type_dict[forbidden[0]]
    else:
        forbidden_road_sign = {}

    return road_sign, forbidden_road_sign

def find_local_minima(a):
    """
    找到 1D ndarray 中的局部极小值。对于平坦极小区间，返回该区间最后一个位置的索引。

    参数
    ----
    a : ndarray
        输入的一维数组

    返回
    ----
    minima_indices : list of int
        局部极小值的索引
    minima_values : list
        对应的极小值
    """
    a = np.asarray(a)
    n = a.size
    if n == 0:
        return [], []

    # 计算相邻元素差异，定位相等值区间的边界
    diffs = np.diff(a)
    run_breaks = np.where(diffs != 0)[0]
    run_starts = np.concatenate(([0], run_breaks + 1))
    run_ends = np.concatenate((run_breaks, [n - 1]))  # 区间结束（包含）

    minima_indices = []

    for start, end in zip(run_starts, run_ends):
        val = a[start]
        # 边界处用 +inf 填充，保证边缘元素也可成为极小值
        left = a[start - 1] if start > 0 else np.inf
        right = a[end + 1] if end < n - 1 else np.inf

        # 严格小于两侧邻居
        if val < left and val < right:
            minima_indices.append(end)

    minima_values = a[minima_indices]
    return minima_indices, minima_values

def interpolate_points(points, step=0.1):
    if len(points) == 0:
        return points

    result = [list(points[0])]  # 初始时包含第一个点，转换为列表形式

    for i in range(len(points) - 1):
        current = points[i]
        next_point = points[i + 1]
        dx = next_point[0] - current[0]
        dy = next_point[1] - current[1]
        distance = math.hypot(dx, dy)

        if distance == 0:
            continue  # 跳过重合的点

        num_segments = math.ceil(distance / step)
        dx_per_segment = dx / num_segments
        dy_per_segment = dy / num_segments

        # 生成插值点，包括next_point，但排除current点
        for seg in range(1, num_segments + 1):
            x = current[0] + seg * dx_per_segment
            y = current[1] + seg * dy_per_segment
            result.append([x, y])

    return np.array(result)


def split_line(p, segment_length=4):
    """
    p: N x 2
    """
    n = len(p)
    idx = np.arange(0, n, segment_length - 1)
    data = [p[i : i + segment_length] for i in idx]
    return data


def norm_yaw(yaw):
    # 将弧度角转到 0-2pi 范围内
    yaw = yaw % (2 * np.pi)
    if yaw < 0:
        yaw += 2 * np.pi
    return yaw


def sort_points_nearest_neighbor(points):
    """使用最近邻方式排序点"""
    if len(points) <= 1:
        return points
    points = points.copy()
    n = len(points)
    visited = np.zeros(n, dtype=bool)
    path = [0]  # 从第一个点开始
    visited[0] = True

    for _ in range(1, n):
        last = path[-1]
        dists = np.linalg.norm(points[last] - points[~visited], axis=1)
        next_idx = np.where(~visited)[0][np.argmin(dists)]
        path.append(next_idx)
        visited[next_idx] = True

    return points[path]


def cut_sub_path(sub_path, center, max_distance=150.):
    """
    sub_path: n x 2 ndarray
    """
    distance = np.linalg.norm(sub_path - center, axis=1)
    minima_indices, minima_values = find_local_minima(distance)
    center_index = minima_indices[0]
    sub_path = sub_path[center_index:]
    cum_distance = np.linalg.norm(sub_path[1:] - sub_path[:-1], axis=1).cumsum()
    index = np.where(cum_distance > max_distance)[0]
    if len(index) > 0:
        return sub_path[:index[0]]
    else:
        return sub_path

def cut_sub_path_spec(sub_path, center, min_distance=0., max_distance=150.):
    """
    sub_path: n x 2 ndarray
    """
    if sub_path.shape[0] <= 2:
        return sub_path
    distance = np.linalg.norm(sub_path - center, axis=1)
    minima_indices, _ = find_local_minima(distance)
    center_index = minima_indices[0]
    # 计算相邻点之间的距离
    segment_distances = np.linalg.norm(sub_path[1:] - sub_path[:-1], axis=1)  # shape: (n-1,)
    # 向左累计（从 center_index 向 index 递减）
    left_index = center_index
    left_cumsum = 0.0
    for i in range(center_index - 1, -1, -1):
        left_index = i
        left_cumsum += segment_distances[i]
        if left_cumsum >= abs(min_distance):
            break

    # 向右累计（从 center_index 向 index 递增）
    right_index = center_index
    right_cumsum = 0.0
    for i in range(center_index, len(sub_path) - 1):
        right_index = i + 1
        right_cumsum += segment_distances[i]
        if right_cumsum >= abs(max_distance):
            break

    if 0 <= left_index <= center_index and center_index < right_index < len(sub_path):
        return sub_path[left_index : right_index + 1]
    else:
        return sub_path

def match_road_sign_with_lanenr(road_sign_set, navi_info, left_num, right_num):
    #print("lanenr num: ",len(navi_info['lane_infos']))
    #print("lanenr dist: ", navi_info['lane_nr_remain_distance'])
    # 右侧多一个非机动
    if len(navi_info['lane_infos']) not in [left_num + right_num, left_num + right_num + 1, left_num + right_num + 2]:
        #print("lane num not match", "left: ", left_num, "right: ", right_num, "lane_num: ", len(navi_info['lane_infos']))
        return 0.0
    if navi_info['lane_nr_remain_distance'] > 70.0:
        return 0.0
    #if len(navi_info['lane_infos'])  != left_num + right_num + 1:
        #print("lane num not match closely","left: ", left_num, "right: ", right_num, "lane_num: ", len(navi_info['lane_infos']))
    lane_highline_direction_set = set()
    for i in range(len(navi_info['lane_infos'])):
        lane_direction, lane_highline_direction, lane_is_drivable, lane_is_highline, lane_type = navi_info['lane_infos'][i]
        tmp = get_lane_direction(lane_highline_direction)
        if tmp:
            lane_highline_direction_set.update(tmp)
    for i in range(len(navi_info['lane_infos'])):
        if i == left_num:
            lane_direction, lane_highline_direction, lane_is_drivable, lane_is_highline, lane_type = navi_info['lane_infos'][i]
            lane_direction_set = get_lane_direction(lane_direction)
            #print("lane_direction_set: ",lane_direction_set)
            lane_highline_direction_set = get_lane_direction(lane_highline_direction)
            recommend_drive_direction = lane_highline_direction_set.pop()
            if recommend_drive_direction in road_sign_set and recommend_drive_direction in lane_direction_set:
                return 1.0
            if recommend_drive_direction not in road_sign_set and recommend_drive_direction not in lane_direction_set:
                return -1.0
    return 0.0

def get_lane_direction(lane_direction):
    lane_direction_set = set()
    if lane_direction & 0x1:
         lane_direction_set.add(Turntype.UTURN)
    if (lane_direction >> 1) & 0x1:
        lane_direction_set.add(Turntype.RIGHT)
    if (lane_direction >> 2) & 0x1:
         lane_direction_set.add(Turntype.STRAIGHT)
    if (lane_direction >> 3) & 0x1:
         lane_direction_set.add(Turntype.LEFT)
    if (lane_direction >> 4) & 0x1:
         lane_direction_set.add(Turntype.UTURN)
    return  lane_direction_set

def check_ego_gt_connection_cross_road_edge(ego_pose, gt_pose, road_edges):
    for p in road_edges:
        ego_gt_line = LineString([ego_pose, gt_pose])
        road_edge_line = LineString(p)
        if ego_gt_line.intersects(road_edge_line):
            return True
    return False


def calc_path_point_heading(path_points):
    """
    计算path点的朝向

    Args:
        path_points: path point n*2, [x, y]

    Returns:
        path point n*3, [x, y, heading]
    """
    yaw_list = []
    for min_index in range(len(path_points)):
        yaw_d = 0.0
        if min_index == 0:
            yaw_d = np.arctan2(
                path_points[min_index + 1][1] - path_points[min_index][1],
                path_points[min_index + 1][0] - path_points[min_index][0]
            )
        elif min_index == len(path_points) - 1:
            yaw_d = np.arctan2(
                path_points[min_index][1] - path_points[min_index - 1][1],
                path_points[min_index][0] - path_points[min_index - 1][0]
            )
        else:
            yaw_d = np.arctan2(
                path_points[min_index + 1][1] - path_points[min_index - 1][1],
                path_points[min_index + 1][0] - path_points[min_index - 1][0]
            )
        yaw_list.append(yaw_d)

    yaw_list = np.array(yaw_list).reshape(-1, 1)

    return np.concatenate((path_points, yaw_list), axis=1)


def find_nearest_point(
        pos,
        points,
        angle_diff=None,
        search_start=None,
        search_end=None,
        max_search_dist=50.0
    ):
    """
    暴力遍历, 使用search range优化计算负载

    Args:
        pos: x, y, yaw
        points: n*3  x, y, heading
        search_start: start index in points
        search_end: end index in points

     Returns:
        min_index: 最近点的索引
        min_distance: 距离最近点的欧式距离
    """
    if search_start is not None and search_end is not None:
        segment = points[search_start : search_end + 1, :]
    elif search_start is not None:
        segment = points[search_start:, :]
    elif search_end is not None:
        segment = points[:search_end, :]
    else:
        segment = points

    min_index_seg = -1
    min_distance = 1e6
    for index_seg, point in enumerate(segment):
        l2_dist = np.linalg.norm(pos[:2] - point[:2])

        if l2_dist > max_search_dist:
            continue

        if (
            (angle_diff is not None and l2_dist < min_distance and abs(pos[2] - point[2]) < angle_diff)
            or (angle_diff is None and l2_dist < min_distance)
        ):
            min_distance = l2_dist
            min_index_seg = index_seg

    min_index = -1
    if min_index_seg > -1:
        min_index = min_index_seg + search_start if search_start is not None else min_index_seg

    return min_index, min_distance

def get_long_distance(pos, point):
    """
    计算点pos到点point的投影点到点point的距离，前正后负

    Args:
        point: [x, y, heading]
        pos: [x, y, yaw]

    Returns:
        dist: 投影距离
    """
    # projection
    dx = pos[0] - point[0]
    dy = pos[1] - point[1]

    dist = dx * np.cos(point[2]) + dy * np.sin(point[2])

    return dist

def get_lat_distance(pos, point):
    """
    计算点pos到点point的投影点到点pos的距离， 左正右负

    Args:
        point: [x, y, heading]
        pos: [x, y, yaw]

    Returns:
        dist: 投影距离
    """
    dist = 0.0

    # projection
    dx = pos[0] - point[0]
    dy = pos[1] - point[1]

    dist = dy * np.cos(point[2]) - dx * np.sin(point[2])

    return dist

def is_segments_intersection(a_point1, a_point2, b_point1, b_point2, bias=0.1):
    a_line = LineString([a_point1, a_point2])
    b_line = LineString([b_point1, b_point2])
    return a_line.distance(b_line) < bias

def transform_polygan_torch(polygans, labels=None, vehicle_tokenizer=None, pedestrian_tokenizer=None, input_action=None):
    """
    Args:
        polygans: ... x 4 x 2
        labels: ...
    Returns:
        new_polygans: ... x 4 x 2
    """
    original_shape = polygans.shape
    polygans = polygans.reshape(-1, 4, 2)  # n*4 x 2
    n = polygans.shape[0]
    state_info = get_xyyaw_from_polygon_torch(polygans)  # n x 7

    # ego
    x, y, yaw = state_info[:, [0, 1, 6]].T  # n
    cos, sin = torch.cos(yaw), torch.sin(yaw)  # n
    transform = torch.stack(
        [
            torch.stack([cos, -sin, x], dim=1),
            torch.stack([sin, cos, y], dim=1),
            torch.tensor([0.0, 0.0, 1.0], device=polygans.device, dtype=polygans.dtype).unsqueeze(0).expand(n, 3),
        ],
        dim=1,
    )  # n x 3 x 3

    # 全部按照vehicle计算一次
    if input_action is None:
        labels = labels.reshape(-1)  # n
        labels_np = labels.cpu().numpy()
        vehicle_labels = np.clip(labels_np, 0, len(vehicle_tokenizer) - 1)
        vehicle_action = torch.from_numpy(vehicle_tokenizer.decode(vehicle_labels)).to(
            polygans.device, dtype=polygans.dtype
        )  # n x 3
    else:
        vehicle_action = torch.from_numpy(input_action).to(
            polygans.device, dtype=polygans.dtype
        )

    xy_one = torch.stack(
        [
            vehicle_action[:, 0],
            vehicle_action[:, 1],
            torch.ones_like(vehicle_action[:, 0]),
        ],
        dim=1,
    ).unsqueeze(2)
    xy = transform @ xy_one  # n x 3 x 1
    vx, vy = xy[:, 0, 0], xy[:, 1, 0]
    vyaw = yaw + vehicle_action[:, 2]
    v_state = torch.stack(
        [
            vx,
            vy,
            state_info[:, 2],
            state_info[:, 3],
            state_info[:, 4],
            state_info[:, 5],
            vyaw,
        ],
        dim=1,
    )  # n x 7

    if pedestrian_tokenizer is not None:
        is_vehicle = labels < len(vehicle_tokenizer)
        # 全部按照pedestrian计算一次
        pedestrian_labels = labels_np - len(vehicle_tokenizer)
        pedestrian_labels = np.clip(pedestrian_labels, 0, len(pedestrian_tokenizer) - 1)
        pedestrian_action = torch.from_numpy(pedestrian_tokenizer.decode(labels_np - len(vehicle_tokenizer))).to(
            polygans.device, dtype=polygans.dtype
        )  # n x 2
        px = x + pedestrian_action[:, 0]
        py = y + pedestrian_action[:, 1]
        p_state = torch.stack(
            [
                px,
                py,
                state_info[:, 2],
                state_info[:, 3],
                state_info[:, 4],
                state_info[:, 5],
                yaw,
            ],
            dim=1,
        )  # n x 7
        # 合并
        v_state = v_state * is_vehicle.unsqueeze(1) + p_state * (~is_vehicle.unsqueeze(1))
    new_polygans = get_rotated_rectangle_torch(v_state)
    new_polygans = new_polygans.reshape(original_shape)
    return new_polygans


def get_lon_lat_distance(pos, point):
    dx = pos[0] - point[0]
    dy = pos[1] - point[1]
    # 沿 heading 切线方向投影
    lon_dist = dx * np.cos(point[2]) + dy * np.sin(point[2])
    lat_dist = dy * np.cos(point[2]) - dx * np.sin(point[2])
    return lon_dist, lat_dist


def signed_distance(point: Point, polyline: LineString) -> float:
    """
    计算点到折线的带符号距离
    :param point: 目标点 (shapely Point)
    :param polyline: 折线 (shapely LineString)
    :return: 带符号距离 (点在左侧为正，右侧为负)
    """
    # Step 1: 找到折线上距离point最近的点
    nearest_pt = nearest_points(polyline, point)[0]

    # Step 2: 计算欧氏距离
    distance_val = point.distance(nearest_pt)

    # 如果点在折线上，距离为0
    if distance_val < 1e-10:
        return 0.0

    # Step 3: 获取折线坐标点
    coords = list(polyline.coords)

    # Step 4: 确定最近点在折线上的位置
    if nearest_pt.equals(Point(coords[0])):  # 最近点是起点
        segment_start = coords[0]
        segment_end = coords[1]
    elif nearest_pt.equals(Point(coords[-1])):  # 最近点是终点
        segment_start = coords[-2]
        segment_end = coords[-1]
    else:  # 最近点在线段中间
        # 遍历所有线段找到包含最近点的线段
        for i in range(len(coords) - 1):
            seg_start = Point(coords[i])
            seg_end = Point(coords[i + 1])
            if seg_start.distance(nearest_pt) + seg_end.distance(nearest_pt) - seg_start.distance(seg_end) < 1e-8:
                segment_start, segment_end = coords[i], coords[i + 1]
                break

    # Step 5: 计算方向向量和位置向量
    vec_line = (segment_end[0] - segment_start[0], segment_end[1] - segment_start[1])
    vec_point = (point.x - segment_start[0], point.y - segment_start[1])

    # Step 6: 计算叉积确定左右
    cross_product = vec_line[0] * vec_point[1] - vec_line[1] * vec_point[0]

    # Step 7: 根据叉积符号返回带符号距离
    return distance_val if cross_product > 0 else -distance_val


def pad_trajectory_boxes_numpy(boxes, target_len=20):
    """
    Pad 轨迹 box 到指定长度 (NumPy版)
    输入: [B, N, 4, 2]
    输出: [B, target_len, 4, 2]
    """
    boxes = boxes.astype(np.float32)
    b, n, _, _ = boxes.shape

    if n >= target_len:
        return boxes[:, :target_len]

    num_pad = target_len - n

    # 2. 计算速度向量 (velocity)
    if n >= 3:
        # 使用最后3帧计算平均速度 (平滑处理): (P_t - P_{t-2}) / 2
        # shape: [B, 1, 4, 2]
        velocity = (boxes[:, -1:] - boxes[:, -3:-2]) / 2.0
    elif n == 2:
        # 使用最后2帧计算瞬时速度: P_t - P_{t-1}
        velocity = boxes[:, -1:] - boxes[:, -2:-1]
    else:
        velocity = np.zeros((b, 1, 4, 2), dtype=boxes.dtype)

    # 3. 生成外推步长
    # steps shape: [1, num_pad, 1, 1] -> 比如 [1, 2, 3, ...]
    steps = np.arange(1, num_pad + 1, dtype=boxes.dtype).reshape(1, num_pad, 1, 1)

    # 4. 线性外推计算
    # last_box: [B, 1, 4, 2]
    last_box = boxes[:, -1:]

    # future_boxes = last_pos + v * t
    future_boxes = last_box + velocity * steps

    padded_boxes = np.concatenate([boxes, future_boxes], axis=1)

    return padded_boxes
def vehicle_dynamics_torch(state, control):
    """
    state:   [x, y, theta, v]
    control: [acc, kappa]
    return:  state_dot
    """
    x, y, theta, v = state.unbind(-1)
    acc, kappa = control.unbind(-1)

    dx = v * torch.cos(theta)
    dy = v * torch.sin(theta)
    dtheta = v * kappa
    dv = acc

    return torch.stack([dx, dy, dtheta, dv], dim=-1)
def rk4_step_torch(state, control, dt):
    """
    state:   [x, y, theta, v]
    control: [acc, kappa]
    return:  next_state
    """
    k1 = vehicle_dynamics_torch(state, control)
    k2 = vehicle_dynamics_torch(state + 0.5 * dt * k1, control)
    k3 = vehicle_dynamics_torch(state + 0.5 * dt * k2, control)
    k4 = vehicle_dynamics_torch(state + dt * k3, control)

    return state + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)


def vehicle_dynamics_torch(state, control):
    """
    state:   [x, y, theta, v]
    control: [acc, kappa]
    return:  state_dot
    """
    x, y, theta, v = state.unbind(-1)
    acc, kappa = control.unbind(-1)

    dx = v * torch.cos(theta)
    dy = v * torch.sin(theta)
    dtheta = v * kappa
    dv = acc

    return torch.stack([dx, dy, dtheta, dv], dim=-1)


def rk4_step_torch(state, control, dt):
    """
    state:   [x, y, theta, v]
    control: [acc, kappa]
    return:  next_state
    """
    k1 = vehicle_dynamics_torch(state, control)
    k2 = vehicle_dynamics_torch(state + 0.5 * dt * k1, control)
    k3 = vehicle_dynamics_torch(state + 0.5 * dt * k2, control)
    k4 = vehicle_dynamics_torch(state + dt * k3, control)

    return state + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)


def transform_polygon_torch_acc_kappa(polygons, control_rear, v_rear, state_range, dt):
    """
    polygons: 在几何中心定义的坐标系下的多边形
    control: 后轴中心的控制输入 [acc, kappa]
    ego_vel: 后轴中心的速度
    return:  在几何中心定义的坐标系下的下一个位置, 后轴中心的速度
    """
    plyshape = polygons.shape
    polygons = polygons.reshape(-1, 4, 2)  # N x 4 x 2

    xyyaw = get_xyyaw_from_polygon_torch(polygons)  # n x 7

    x_rear = xyyaw[:, 0] * state_range - 1.4 * torch.cos(xyyaw[:, 6])
    y_rear = xyyaw[:, 1] * state_range - 1.4 * torch.sin(xyyaw[:, 6])

    cur_state_rear = torch.cat((x_rear[:, None], y_rear[:, None], xyyaw[:, 6][:, None], v_rear[:, None]), dim=1)
    # action transformation matrix
    next_state_rear = rk4_step_torch(cur_state_rear, control_rear, dt)

    next_x_cneter = next_state_rear[:, 0] + 1.4 * torch.cos(next_state_rear[:, 2])
    next_y_cneter = next_state_rear[:, 1] + 1.4 * torch.sin(next_state_rear[:, 2])

    # polygons transformation matrix
    yaw = next_state_rear[:, 2]
    sin = torch.sin(yaw)
    cos = torch.cos(yaw)
    pose = torch.stack([torch.eye(3, device=polygons.device, dtype=polygons.dtype)] * plyshape[0])
    pose[:, 0, 0] = cos
    pose[:, 0, 1] = -sin
    pose[:, 1, 0] = sin
    pose[:, 1, 1] = cos
    pose[:, 0, 2] = next_x_cneter / state_range
    pose[:, 1, 2] = next_y_cneter / state_range

    # transformation
    direct_l = polygons[:, 1] - polygons[:, 0]
    direct_w = polygons[:, 1] - polygons[:, 2]
    hafl = torch.norm(direct_l, dim=1) / 2.0  # N
    hafw = torch.norm(direct_w, dim=1) / 2.0  # N
    corners = torch.stack(
        [
            torch.stack([-hafl, -hafw], dim=1),
            torch.stack([hafl, -hafw], dim=1),
            torch.stack([hafl, hafw], dim=1),
            torch.stack([-hafl, hafw], dim=1),
        ],
        dim=1,
    )  # N x 4 x 2
    corners = torch.matmul(corners, pose[:, :2, :2].permute(0, 2, 1))
    polygons = pose[:, None, :2, 2] + corners
    polygons = polygons.reshape(plyshape)

    return polygons, next_state_rear[:, 3]
