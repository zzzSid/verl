# -*- coding: utf-8 -*-
import pickle
import cv2
import math
import numpy as np
import copy
import torch
from matplotlib.font_manager import fontManager
from scipy.spatial import KDTree
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import ego2global
import matplotlib.colors as mcolors


def get_chinese_font():
    fontManager.addfont(path="tpp_onemodel/evaluator/plannn2_evaluator_utils/SimHei_Plannn2.ttf")

COLORS_ID = [
    (144, 238, 144),
    (178, 34, 34),
    (221, 160, 221),
    (0, 128, 0),
    (210, 105, 30),
    (220, 20, 60),
    (192, 192, 192),
    (255, 228, 196),
    (50, 205, 50),
    (139, 0, 139),
    (100, 149, 237),
    (138, 43, 226),
    (238, 130, 238),
    (255, 0, 255),
    (0, 100, 0),
    (127, 255, 0),
    (255, 0, 255),
    (255, 140, 0),
    (255, 239, 213),
    (199, 21, 133),
    (124, 252, 0),
    (147, 112, 219),
    (106, 90, 205),
    (176, 196, 222),
    (65, 105, 225),
    (173, 255, 47),
    (255, 20, 147),
    (219, 112, 147),
    (186, 85, 211),
    (199, 21, 133),
    (148, 0, 211),
    (255, 99, 71),
    (144, 238, 144),
    (255, 255, 0),
    (230, 230, 250),
    (128, 128, 0),
    (189, 183, 107),
    (255, 255, 224),
    (128, 128, 128),
    (105, 105, 105),
    (64, 224, 208),
    (205, 133, 63),
    (0, 128, 128),
    (72, 209, 204),
    (139, 69, 19),
    (255, 245, 238),
    (250, 240, 230),
    (152, 251, 152),
    (0, 255, 255),
    (135, 206, 235),
    (0, 191, 255),
    (176, 224, 230),
    (0, 250, 154),
    (245, 255, 250),
    (240, 230, 140),
    (245, 222, 179),
    (0, 139, 139),
    (143, 188, 143),
    (240, 128, 128),
    (102, 205, 170),
    (60, 179, 113),
    (46, 139, 87),
    (165, 42, 42),
    (178, 34, 34),
    (175, 238, 238),
    (255, 248, 220),
    (218, 165, 32),
    (255, 250, 240),
    (253, 245, 230),
    (244, 164, 96),
    (210, 105, 30),
]

def get_mpl_colors_as_rgba_dict():
    """
    获取所有 matplotlib 预定义颜色并将它们转换为
    dict(r=float, g=float, b=float, a=float) 的格式。
    """
    full_color_map = mcolors.get_named_colors_mapping()
    result_dict = {}
    for name, color_spec in full_color_map.items():
        try:
            rgba_tuple = mcolors.to_rgba(color_spec)
            result_dict[name] = {
                "r": rgba_tuple[0],
                "g": rgba_tuple[1],
                "b": rgba_tuple[2],
                "a": rgba_tuple[3]
            }
        except ValueError:
            continue

    return result_dict

MATPLOTLIB_COLOR_MAP = get_mpl_colors_as_rgba_dict()

MAIN_ACTION_MAPPING = {
    0: "无",
    1: "左转",                # 左转0x1
    2: "右转",                # 右转0x2
    3: "向左前方行驶",        # 向左前方行驶0x3
    4: "向右前方行驶",        # 向右前方行驶0x4
    5: "向左后方行驶",        # 向左后方行驶0x5
    6: "向右后方行驶",        # 向右后方行驶0x6
    7: "左转调头",            # 左转调头0x7
    8: "直行",                # 直行0x8
    9: "靠左",                # 靠左0x9
    10: "靠右",               # 靠右
    11: "进入环岛",           # 进入环岛
    12: "离开环岛",           # 离开环岛
    13: "减速",               # 减速
    14: "插入直行",           # 插入直行
    65: "进入建筑物",         # 进入建筑物
    66: "离开建筑物",         # 离开建筑物
    67: "电梯换层",           # 电梯换层
    68: "楼梯换层",           # 楼梯换层
    69: "扶梯换层",           # 扶梯换层
    70: "COUNT"               # 导航主动作最大个数
}

# assist action mapping
ASSIST_ACTION_MAPPING = {
    0: "无",
    1: "进入主路",
    2: "进入辅路",
    3: "进入高速",
    4: "进入匝道",
    5: "进入隧道",
    6: "进入中间岔道",
    7: "进入右岔路",
    8: "进入左岔路",
    9: "进入右转专用道",
    10: "进入左转专用道",
    11: "进入中间道路",
    12: "进入右侧道路",
    13: "进入左侧道路",
    14: "靠右进入辅路",
    15: "靠左进入辅路",
    16: "靠右进入主路",
    17: "靠左进入主路",
    18: "靠右进入右转专用道",
    19: "到达航道",
    20: "驶离轮渡",
    23: "沿当前道路行驶",
    24: "沿辅路行驶",
    25: "沿主路行驶",
    32: "到达出口",
    33: "到达服务区",
    34: "到达收费站",
    35: "到达途径地",
    36: "到达目的地",
    37: "到达充电站",
    48: "沿环岛左转",
    49: "绕环岛右转",
    50: "绕环岛直行",
    51: "绕环岛掉头",
    52: "小环岛不数个数",
    64: "复杂路口，走右边第一出口",
    65: "复杂路口，走右边第二出口",
    66: "复杂路口，走右边第三出口",
    67: "复杂路口，走右边第四出口",
    68: "复杂路口，走右边第五出口",
    69: "复杂路口，走左边第一出口",
    70: "复杂路口，走左边第二出口",
    71: "复杂路口，走左边第三出口",
    72: "复杂路口，走左边第四出口",
    73: "复杂路口，走左边第五出口",
    80: "进入调头专用路",
    90: "通过人行横道",
    91: "通过过街天桥",
    92: "通过地下通道",
    93: "通过广场",
    94: "通过公园",
    95: "通过扶梯",
    96: "通过直梯",
    97: "通过索道",
    98: "通过空中通道",
    99: "通过建筑物穿越通道",
    100: "通过行人道路",
    101: "通过游船路线",
    102: "通过观光车路线",
    103: "通过滑道",
    105: "通过阶梯",
    106: "通过斜坡",
    107: "通过桥",
    108: "通过轮渡",
    109: "通过地铁通道",
    112: "即将进入建筑",
    113: "即将离开建筑",
    114: "进入环岛",
    115: "离开环岛",
    116: "进入小路",
    117: "进入内部路",
    118: "进入左侧第二岔路",
    119: "进入左侧第三岔路",
    120: "进入右侧第二岔路",
    121: "进入右侧第三岔路",
    122: "进入加油站道路",
    123: "进入小区道路",
    124: "进入园区道路",
    125: "上高架",
    126: "走中间岔路上高架",
    127: "走最右侧岔路上高架",
    128: "走最左侧岔路上高架",
    129: "沿当前道路直行",
    130: "下高架",
    131: "走左侧道路上高架",
    132: "走右侧道路上高架",
    133: "上桥",
    134: "进停车场",
    135: "进立交桥",
    136: "进桥梁",
    137: "进地下通道",
    4096: "MAX"
}

kLaneTypeMap = {
    0: "无效车道",
    1: "普通车道",
    2: "公交车道",
    3: "公交车道文字",
    4: "可变车道",
    5: "HOV",
    6: "潮汐车道文字",
    7: "潮汐车道前行箭头",
    8: "潮汐车道叉号",
    9: "ETC (百度引擎)",
    10: "专用车道（高德引擎）",
    11: "..."
}


def parse_dynamicobj(v, T=None):
    if len(v) == 0:
        return np.empty((0, 12), dtype=np.float32)

    geometry = [d["geometry"] for d in v]
    d1 = np.array([d["OBJ_Distance"] for d in geometry], dtype=np.float32)
    d2 = np.array([d["OBJ_Dimension"] for d in geometry], dtype=np.float32)
    d3 = np.array([d["OBJ_Heading"] for d in geometry], dtype=np.float32)
    d4 = np.array([d["OBJ_Angle_Rate"] for d in geometry], dtype=np.float32)
    d5 = np.array([d["OBJ_Abs_Velocity"] for d in geometry], dtype=np.float32)
    d6 = np.array([d["OBJ_Abs_Acc"] for d in geometry], dtype=np.float32)

    cid = np.array([d["OBJ_Object_Class"] for d in v], dtype=np.float32)
    sid = np.array([d["OBJ_Object_SpecialClass"] for d in v], dtype=np.float32)
    tid = np.array([d["OBJ_Object_ID"] for d in v], dtype=np.float32)
    src = np.array([d["source"] for d in v], dtype=np.float32)
    # sometimes prob is -1, why?
    pro = np.array([d["property"]["OBJ_Existence_Probability"] for d in v], dtype=np.float32)

    out = np.concatenate(
        [
            d1[:, :3],
            d2[:, :3],
            d3[:, None],
            cid[:, None],
            sid[:, None],
            tid[:, None],
            src[:, None],
            pro[:, None],
        ],
        axis=1,
    )

    if T is not None:
        boxes = np.eye(4, 4, dtype=np.float32)
        boxes = np.array([boxes] * out.shape[0], dtype=np.float32)
        cos = np.cos(out[:, 6])
        sin = np.sin(out[:, 6])
        boxes[:, 0, 0] = cos
        boxes[:, 0, 1] = -sin
        boxes[:, 1, 0] = sin
        boxes[:, 1, 1] = cos
        boxes[:, :3, 3] = out[:, :3]
        boxes = np.matmul(T, boxes)
        out[:, :3] = boxes[:, :3, 3]
        out[:, 6] = np.arctan2(boxes[:, 1, 0], boxes[:, 0, 0])
    return out


def parse_dynamicobj_v2(objs, T=None):
    if len(objs) == 0:
        return np.empty((0, 12), dtype=np.float32)

    # 10?, 11?
    out = objs[:, :12].copy()
    if T is not None:
        boxes = np.eye(4, 4, dtype=np.float32)
        boxes = np.array([boxes] * out.shape[0], dtype=np.float32)
        cos = np.cos(out[:, 6])
        sin = np.sin(out[:, 6])
        boxes[:, 0, 0] = cos
        boxes[:, 0, 1] = -sin
        boxes[:, 1, 0] = sin
        boxes[:, 1, 1] = cos
        boxes[:, :3, 3] = out[:, :3]
        boxes = np.matmul(T, boxes)
        out[:, :3] = boxes[:, :3, 3]
        out[:, 6] = np.arctan2(boxes[:, 1, 0], boxes[:, 0, 0])
    return out

def parse_dynamicobj_v3(objs, T=None):
    if len(objs) == 0:
        return np.empty((0, 12), dtype=np.float32)

    # 10?, 11?
    out = objs[:, :12].copy()
    if T is not None:
        boxes = np.eye(4, 4, dtype=np.float32)
        boxes = np.array([boxes] * out.shape[0], dtype=np.float32)
        cos = np.cos(out[:, 6])
        sin = np.sin(out[:, 6])
        boxes[:, 0, 0] = cos
        boxes[:, 0, 1] = -sin
        boxes[:, 1, 0] = sin
        boxes[:, 1, 1] = cos
        boxes[:, :3, 3] = out[:, :3]
        boxes = np.matmul(T, boxes)
        out[:, :3] = boxes[:, :3, 3]
        out[:, 6] = np.arctan2(boxes[:, 1, 0], boxes[:, 0, 0])
        vel = np.pad(out[:, 10:12], [(0, 0), (0, 1)])
        new_vel = np.matmul(T[:3, :3], vel.T).T[:, :2]
        out[:, 10:12] = new_vel
    return out

def filter_points_by_dis(points_array, center, original_yaw, forward_filter_dis_threshold, backward_filter_dis_threshold, sorted_points_array=False):
    """
    :sorted_points_array: whether points_array is ordered from rear to front (relative to ego)
    """

    p2c_vec = points_array[:, :2] - center
    heading_unit_vec = np.array([math.cos(original_yaw), math.sin(original_yaw)]).reshape(2, 1)
    forward_backward_vec = p2c_vec @ heading_unit_vec >= 0
    threshold_vec = np.where(forward_backward_vec.reshape(-1), forward_filter_dis_threshold, backward_filter_dis_threshold)
    distance_vec = np.linalg.norm(p2c_vec, axis=1)
    keep_mask = distance_vec < threshold_vec
    if sorted_points_array:
        min_dis_idx = np.argmin(distance_vec)

        # 向量化方法计算边界
        false_indices = np.where(~keep_mask)[0]  # 所有False值的索引

        # 1. 计算左边界：在min_dis_idx左侧(含)最后一个False的右侧
        left_false = false_indices[false_indices <= min_dis_idx]
        left_bound = left_false[-1] + 1 if len(left_false) > 0 else 0

        # 2. 将min_dis_idx左侧第一个False之前的所有元素置为False
        keep_mask[:left_bound] = False

    new_p = points_array[keep_mask]
    if new_p.shape[0] < 2:
        return None
    return new_p

def filter_polygon_by_distance(polygons,
                               center,
                               original_yaw,
                               forward_filter_dis_threshold,
                               backward_filter_dis_threshold,
                               god_cid):
    new_polygons = []
    forward_filter_dis_threshold_dic = {
        23.0: np.inf,
        24.0: forward_filter_dis_threshold,
    }
    for i, p in enumerate(polygons):
        new_p = filter_points_by_dis(
            points_array=p,
            center=center,
            original_yaw=original_yaw,
            forward_filter_dis_threshold=forward_filter_dis_threshold_dic[god_cid[i]],
            backward_filter_dis_threshold=backward_filter_dis_threshold)
        if new_p is not None:
            new_polygons.append(new_p)

    return new_polygons

def dp_simplify(poly, eps):
    """
    Douglas-Peucker simplify
    poly: (N,2) numpy数组, 顺时针或逆时针
    eps:  最大允许偏差（米）
    return: (M,2) M≤N
    """
    if poly.shape[0] <= 2:
        return poly
    poly = poly.astype(np.float32)
    simp = cv2.approxPolyDP(poly, epsilon=eps, closed=True)
    simp = simp.squeeze().reshape(-1, 2)  # 去掉多余维度
    return simp

def is_ccw(poly):
    """
    poly: (N,2) 有序顶点，闭合与否均可
    return: True=逆时针, False=顺时针
    """
    if poly.shape[0] < 3:
        # 一或两个点无论正反都可以视为逆时针。
        return True

    #  Shoelace formula 的符号版
    x, y = poly[:,0], poly[:,1]
    signed_area = np.sum(x * np.roll(y, -1)) - np.sum(y * np.roll(x, -1))
    return signed_area > 0          # >0 即 CCW

def facing_vertices_2d(poly, center):
    """
    poly: (N, 2)  二维 polygon，要求 CCW 有序
    center:  (2,)    自车中心
    return: (M, 2) 面向自车的顶点子集
    """
    N = poly.shape[0]
    keep = np.zeros(N, dtype=bool)

    for i in range(N):
        p1, p2 = poly[i, :2], poly[(i+1) % N, :2]
        # 1. 外法线（2-D 左手法则：旋转90°）
        edge = p2 - p1
        n = np.array([-edge[1], edge[0]])
        n /= np.linalg.norm(n) + 1e-6
        # 2. 视线向量（边中点 → 自车）
        mid = 0.5*(p1 + p2)
        v = mid - center
        # 3. 朝向判断
        if np.dot(n, v) > 0:
            keep[i] = keep[(i+1) % N] = True

    return poly[keep]

def face_ego_simplify(poly, center):
    if not is_ccw(poly):
        poly = poly[::-1]   # 翻转为 CCW，再算外法线

    return facing_vertices_2d(poly, center)

def close_polygon(polygon):
    if polygon.shape[0] == 0 or np.allclose(polygon[0, :], polygon[-1, :], 1e-6):
        return polygon
    closed = np.append(polygon, polygon[0:1], axis=0)
    return closed

def downsample_polygon(polygons, dp_error, center):
    new_polygons = []
    for p in polygons:
        new_p = dp_simplify(p[:, :2], dp_error)
        new_p = face_ego_simplify(new_p, center)
        if new_p.shape[0] < 2:
            continue
        new_p = close_polygon(new_p)
        new_polygons.append(new_p)

    return new_polygons

def filter_by_open_gate_obj(polygons, sobjs):
    check_open = False
    gate_obj_idx = ((sobjs[:, 7] == 29) & ((sobjs[:, 8] == 10002) | (sobjs[:, 8] == 10003))) if check_open else (sobjs[:, 7] == 29)
    open_gate_obj = sobjs[gate_obj_idx]
    if len(open_gate_obj) <= 0:
        return polygons

    open_gate_obj_center = open_gate_obj[:, :2]  # (x, y)
    # 创建KDTree用于快速距离查询
    gate_tree = KDTree(open_gate_obj_center)

    new_polygons = []

    for polygon in polygons:
        if len(polygon) <= 0:
            continue

        # 计算多边形每个点到最近门对象中心的距离
        distances, _ = gate_tree.query(polygon[:, :2])

        # 保留距离大于等于5米的点
        filtered_threshold = 2.0
        keep_mask = distances >= filtered_threshold
        filtered_polygon = polygon[keep_mask]

        # 只有当过滤后的多边形至少还有2个点时才保留（保证能形成一个线段）
        if len(filtered_polygon) >= 2:
            new_polygons.append(filtered_polygon)

    return new_polygons


def filter_and_downsample_polygon(polygons,
                                  sobjs,
                                  center,
                                  original_yaw,
                                  forward_filter_dis_threshold,
                                  backward_filter_dis_threshold,
                                  god_cid):
    polygons = filter_polygon_by_distance(polygons,
                                          center,
                                          original_yaw,
                                          forward_filter_dis_threshold,
                                          backward_filter_dis_threshold,
                                          god_cid)
    polygons = filter_by_open_gate_obj(polygons, sobjs)
    polygons = downsample_polygon(polygons, 0.1, center)
    return polygons

def parse_staticobj_v2(objs,
                       polygons,
                       should_filter,
                       T=None,
                       priority_road_class = None,
                       object_filter_attrs = None,
                       center=None,
                       original_yaw=None,
                       god_forward_filter_dis_threshold=None,
                       god_backward_filter_dis_threshold=None,
                       vis_polygon = False):
    if len(objs) == 0 or len(polygons) != len(objs):
        return np.empty((0, 12), dtype=np.float32), [], []

    # 10?, 11?
    out = objs[:, :12].copy()
    polygons_out = polygons
    polygons_out_vis = []

    if T is not None:
        boxes = np.eye(4, 4, dtype=np.float32)
        boxes = np.array([boxes] * out.shape[0], dtype=np.float32)
        cos = np.cos(out[:, 6])
        sin = np.sin(out[:, 6])
        boxes[:, 0, 0] = cos
        boxes[:, 0, 1] = -sin
        boxes[:, 1, 0] = sin
        boxes[:, 1, 1] = cos
        boxes[:, :3, 3] = out[:, :3]
        boxes = np.matmul(T, boxes)
        out[:, :3] = boxes[:, :3, 3]
        out[:, 6] = np.arctan2(boxes[:, 1, 0], boxes[:, 0, 0])

        polygons_out = [ego2global(p, T) if p.shape[0] > 0 else p for p in polygons]
    if vis_polygon:
        polygons_out_vis = copy.deepcopy(polygons_out)

    if should_filter:
        cid = out[:, 7]       # 类别id，GOD 23 - 24
        source = out[:, 10]   # 目标数据源 0 - vision, 1 - lidar, 2 - fusion
        obj_id = out[:, 9]
        # assert priority_road_class is not None and object_filter_attrs is not None
        # lidar_cluster_class = np.array(
        #     [object_filter_attrs[id]["lidar_cluster_class"]
        #      if id in object_filter_attrs else -1
        #      for id in obj_id]
        # )
        # highway_fp_tag = np.array(
        #     [object_filter_attrs[id]["highway_fp_tag"]
        #      if id in object_filter_attrs else -1
        #      for id in obj_id]
        # )
        # keep polygon by attributes
        keep_polygon = (source >= 1) & (source <= 2) & (cid >= 23) & (cid <= 24)
        not_empty = np.array([len(p) > 0 for p in polygons_out], dtype=bool)
        god_keep_idx = np.where(keep_polygon & not_empty)[0]
        polygons_out = [polygons_out[i] for i in god_keep_idx]
        god_cid = cid[god_keep_idx]

        if center is not None:
            assert original_yaw is not None and \
                god_forward_filter_dis_threshold is not None and \
                god_backward_filter_dis_threshold is not None
            # if downsample triggered, polygons_out will become 2-D points.
            polygons_out = filter_and_downsample_polygon(polygons_out,
                                                         out,
                                                         center,
                                                         original_yaw,
                                                         god_forward_filter_dis_threshold,
                                                         god_backward_filter_dis_threshold,
                                                         god_cid)

        # 由于polygon过滤依赖out，所以最后才对out进行过滤。
        out = out[(cid > 24) | (cid < 23)]

    return out, polygons_out, polygons_out_vis


def filter_etc_staticobj(objs, T=None):
    if len(objs) == 0:
        return np.empty((0, 12), dtype=np.float32)

    # 10?, 11?
    out = objs[:, :12].copy()
    cid = out[:, 7]
    status = out[:, 8]
    if T is not None:
        boxes = np.eye(4, 4, dtype=np.float32)
        boxes = np.array([boxes] * out.shape[0], dtype=np.float32)
        cos = np.cos(out[:, 6])
        sin = np.sin(out[:, 6])
        boxes[:, 0, 0] = cos
        boxes[:, 0, 1] = -sin
        boxes[:, 1, 0] = sin
        boxes[:, 1, 1] = cos
        boxes[:, :3, 3] = out[:, :3]
        boxes = np.matmul(T, boxes)
        out[:, :3] = boxes[:, :3, 3]
        out[:, 6] = np.arctan2(boxes[:, 1, 0], boxes[:, 0, 0])
    mask = ((cid >= 1) & (cid <= 4)) | ((cid == 29) & (status != 10003))
    return out[mask]



def parse_staticobj(v, T=None):
    if len(v) == 0:
        return np.empty((0, 12), dtype=np.float32)

    geometry = [d["geometry"] for d in v]
    d1 = np.array([d["OBS_Distance"] for d in geometry], dtype=np.float32)
    d0 = np.array([0.0 for d in geometry], dtype=np.float32)
    d2 = np.array([d["OBS_Dension"] for d in geometry], dtype=np.float32)
    d3 = np.array([d["OBS_Heading"] for d in geometry], dtype=np.float32)

    cid = np.array([d["OBS_Type"] for d in v], dtype=np.float32)
    sid = np.array([0.0 for d in v], dtype=np.float32)
    tid = np.array([d["OBS_ID"] for d in v], dtype=np.float32)
    src = np.array([d["source"] for d in v], dtype=np.float32)
    pro = np.array([d["OBS_Type_Probability"] for d in v], dtype=np.float32)

    out = np.concatenate(
        [
            d1,
            d0[:, None],
            d2,
            d3[:, None],
            cid[:, None],
            sid[:, None],
            tid[:, None],
            src[:, None],
            pro[:, None],
        ],
        axis=1,
    )
    if T is not None:
        boxes = np.eye(4, 4, dtype=np.float32)
        boxes = np.array([boxes] * out.shape[0], dtype=np.float32)
        cos = np.cos(out[:, 6])
        sin = np.sin(out[:, 6])
        boxes[:, 0, 0] = cos
        boxes[:, 0, 1] = -sin
        boxes[:, 1, 0] = sin
        boxes[:, 1, 1] = cos
        boxes[:, :3, 3] = out[:, :3]
        boxes = np.matmul(T, boxes)
        out[:, :3] = boxes[:, :3, 3]
        out[:, 6] = np.arctan2(boxes[:, 1, 0], boxes[:, 0, 0])
    return out[(pro > 0.0) & (cid != 24)]


def parse_stopline(d):
    k1 = "SL_Long_Dist_L"
    k2 = "SL_Lat_Dist_L"
    k3 = "SL_Long_Dist_R"
    k4 = "SL_Lat_Dist_R"
    return np.array([[d[k1], d[k2], 0.0], [d[k3], d[k4], 0.0]], dtype=np.float32)


def parse_array(data, shape, dtype=np.float32):
    return np.frombuffer(data, dtype=dtype).reshape(shape)


def parse_array_list(datas, shapes, dtype=np.float32):
    return [parse_array(d, s, dtype=dtype) for d, s in zip(datas, shapes)]


def parse_frame(k, rawbytes):
    frame = pickle.loads(rawbytes)
    if k in ["dynamic_dets", "dynamic_gods", "static_dets", "agent_prediction"]:
        frame[k] = parse_array(frame[k], frame[f"{k}_shape"])
        # print(frame)
    elif k == "manner_lane":
        subk = f"{k}_types"
        frame[subk] = parse_array(frame[subk], frame[f"{subk}_shape"])
        subk = f"{k}_points"
        frame[subk] = parse_array_list(frame[subk], frame[f"{subk}_shape"])
        subk = f"{k}_attr"
        frame[subk] = parse_array_list(frame[subk], frame[f"{subk}_shape"], dtype=np.int16)
    elif k == "meta":
        frame["car_pose"] = parse_array(frame["car_pose"], (4, 4))
        # vx, vy, acc_x, acc_y, yaw[2], yaw_rate[2], whlag, whlagspd, vehspd, lgta, chassis_yawrate
        frame["ego_motion"] = parse_array(frame["ego_motion"], (12,))
        frame["ego_box"] = frame["ego_box"]
        frame["ego_gear_raw"] = frame["ego_motion"][-1:]
        # print(frame)
    elif k == "atlas":
        atlas = frame["atlas"]
        atlas = {
            "main_ground": parse_array_list(atlas["main_ground"], atlas["main_ground_shape"]),
            "fore_ground": parse_array_list(atlas["foreground"], atlas["foreground_shape"]),
            "unsafe_area": parse_array_list(atlas["unsafe_area"], atlas["unsafe_area_shape"]),
        }
        frame["atlas"] = atlas
        # print(frame)
    elif k == "navi_path":
        subk = "navi_path_tld"
        frame[subk] = parse_array_list(frame[subk], frame[f"{subk}_shape"], dtype=np.int32)
        for subk in ["points", "stoppoints", "speed_limit", "lc_attr"]:
            subk = f"{k}_{subk}"
            frame[subk] = parse_array_list(frame[subk], frame[f"{subk}_shape"])
        # print(frame)
    elif k == "mock_navi_path":
        subk = f"{k}_points"
        frame[subk] = parse_array_list(frame[subk], frame[f"{subk}_shape"])
        # print(frame)
    elif k == "car_pose":
        cpose = frame["car_pose_per_topic"]
        cpose = {
            "atlas": parse_array(cpose["atlas"]["car_pose"], (4, 4)),
            "road_post": parse_array(cpose["road_post"]["car_pose"], (4, 4)),
            "road_detection": parse_array(cpose["road_detection"]["car_pose"], (4, 4)),
        }
        frame = {"car_pose_per_topic": cpose}
        # print(frame)
    elif k == "gt_bboxes":
        frame = {"gt_bboxes": parse_array(frame["gt"], frame["gt_shape"])}
    #else:
    #    print(k)
    return frame

def check_state_dict_name(state_dict):
    # fix the keys of the state dictionary :(
    # honestly no idea how checkpoints sometimes get this prefix, have to debug more
    unwanted_prefix = '_orig_mod.'
    for k,v in list(state_dict.items()):
        if k.startswith(unwanted_prefix):
            state_dict[k[len(unwanted_prefix):]] = state_dict.pop(k)
    return state_dict

def compute_car_pose(corners):
    """
    计算批量 4×4 刚体变换矩阵（适用于 B×4×2 的输入）
    :param corners: (B, 4, 2) Tensor，每行是 (x, y)
    :return: (B, 4, 4) 变换矩阵 (torch.Tensor)
    """
    corners = corners.to(torch.float32)  # 转换为 float32

    # 计算前轴和后轴的中点 (B, 2)
    front_mid = (corners[:, 1] + corners[:, 2]) / 2
    rear_mid = (corners[:, 0] + corners[:, 3]) / 2

    # 计算车辆中心 (B, 2)
    t = (front_mid + rear_mid) / 2

    # 计算航向角 yaw (B,)
    direction = front_mid - rear_mid
    yaw = torch.atan2(direction[:, 1], direction[:, 0])  # atan2(Y, X)

    # 计算 4×4 变换矩阵 (B, 4, 4)
    T = torch.eye(4, dtype=torch.float32, device=corners.device).unsqueeze(0).repeat(corners.shape[0], 1, 1)

    # 计算旋转矩阵 (B, 2, 2)
    cos_yaw, sin_yaw = torch.cos(yaw), torch.sin(yaw)
    T[:, 0, 0] = cos_yaw
    T[:, 0, 1] = -sin_yaw
    T[:, 1, 0] = sin_yaw
    T[:, 1, 1] = cos_yaw

    # 赋值平移 (B, 4, 4)
    T[:, 0, 3] = t[:, 0]  # X 方向平移
    T[:, 1, 3] = t[:, 1]  # Y 方向平移

    return T

def compute_car_pose_torch(corners):
    """
    PyTorch 版本的 4×4 刚体变换矩阵计算
    :param corners: 4×2 Tensor，每行是 (x, y)
    :return: 4×4 变换矩阵 (torch.Tensor)
    """
    corners = corners.to(torch.float32)  # 转换为 float32

    # 计算前轴和后轴的中点
    front_mid = (corners[1] + corners[2]) / 2
    rear_mid = (corners[0] + corners[3]) / 2

    # 计算车辆中心
    t = (front_mid + rear_mid) / 2

    # 计算航向角 yaw
    direction = front_mid - rear_mid
    yaw = torch.atan2(direction[1], direction[0])  # atan2(Y, X)

    # 计算 4×4 变换矩阵
    T = torch.eye(4, dtype=torch.float32)
    cos_yaw, sin_yaw = torch.cos(yaw), torch.sin(yaw)
    T[0, 0] = cos_yaw
    T[0, 1] = -sin_yaw
    T[1, 0] = sin_yaw
    T[1, 1] = cos_yaw
    T[0, 3] = t[0]  # X 方向平移
    T[1, 3] = t[1]  # Y 方向平移

    return T

def compute_center_distance_torch(pred_polygons_pose0, gt_polygons):
    # 计算每个多边形的中心点
    pred_centers = pred_polygons_pose0.mean(dim=2)  # [b, replan_time, 2]
    gt_centers = gt_polygons.mean(dim=2)  # [b, replan_time, 2]
    # 计算中心点之间的欧氏距离
    dist = torch.norm(pred_centers - gt_centers, p=2, dim=-1, keepdim=True)  # [b, replan_time, 1]
    return dist

def transform_to_world(future_trajectory, car_pose):
    """
    Convert the predicted polygon trajectory from the old origin pose to the world coordinate system.

    :param pred_polygons: Tensor of shape [b, 5, 4, 2] representing predicted polygon trajectory in the old origin pose
    :param old_origin_pose: Tensor of shape [b, 4, 4] representing the old origin pose transformation matrix
    :return: Predicted polygon trajectory in the world coordinate system
    """
    world_trajectorys = []

    # 对每一帧轨迹进行转换
    for i in range(len(future_trajectory)):
        # 初始化转换后的轨迹列表
        world_trajectory = []
        car_pose_R = car_pose[i][:2, :2]
        for frame in future_trajectory[i]:  # batch size 为 1，直接取第一个 batch
            world_frame = []
            for point in frame:  # 每个点 [x, y, 1]
                transformed_point = torch.matmul(car_pose_R, point)  # 计算变换
                transformed_point[0] = transformed_point[0] + car_pose[i][0][3]
                transformed_point[1] = transformed_point[1] + car_pose[i][1][3]
                world_frame.append(transformed_point)  # 只取 (x, y) 坐标
            world_trajectory.append(torch.stack(world_frame))
        world_trajectory = torch.stack(world_trajectory)
        world_trajectorys.append(world_trajectory)

    return torch.stack(world_trajectorys, dim=0)  # 返回 (1, 5, 4, 2)

def transform_to_new_origin(pred_polygons_world, car_pose_target):
    """
    Convert the predicted polygon trajectory from the world coordinate system to the new origin pose.

    :param pred_polygons_world: Tensor of shape [b, 5, 4, 2] representing predicted polygon trajectory in world coordinates
    :param new_origin_pose: Tensor of shape [b, 4, 4] representing the new origin pose transformation matrix
    :return: Predicted polygon trajectory in the new origin pose
    """
    new_origin_trajectorys = []
    for i in range(len(pred_polygons_world)):
        # 计算新的轨迹
        new_origin_trajectory = []
        # 计算目标车坐标系下的变换矩阵
        car_pose_target_inv = torch.inverse(car_pose_target[i][:2, :2])  # 获取逆变换矩阵
        for frame in pred_polygons_world[i]:  # batch size 为 1，直接取第一个 batch
            new_origin_frame = []
            for point in frame:  # 每个点 [x, y]
                point[0] = point[0] - car_pose_target[i][0][3]
                point[1] = point[1] - car_pose_target[i][1][3]
                transformed_point = torch.matmul(car_pose_target_inv, point)  # 计算变换
                new_origin_frame.append(transformed_point)  # 只取 (x, y) 坐标
            new_origin_trajectory.append(torch.stack(new_origin_frame))
        new_origin_trajectory = torch.stack(new_origin_trajectory)
        new_origin_trajectorys.append(new_origin_trajectory)

    return torch.stack(new_origin_trajectorys, dim=0)  # 返回 (1, 5, 4, 2)

def transform_to_new_origin_v2(polygon, TR1, TR2):
    """
    将polygon转到TR1坐标系，再转到TR2坐标系
    """
    aug_ones = torch.ones(*polygon.shape[:-1], 1, device=polygon.device, dtype=polygon.dtype)
    aug_polygon = torch.cat([polygon, aug_ones], dim=-1)
    TR = torch.matmul(TR2.double(), TR1.double()).float()   # 坐标很大的情况float计算会有精度损失
    polygon = torch.matmul(TR[:, None, None, :, :], aug_polygon[:, :, :, :, None])
    return polygon[:, :, :, :2, 0]

def compute_center_distance(pred_polygons_pose0, gt_polygons):
    # pred_polygons_pose0, gt_polygons: shape [4, 2]
    pred_center = pred_polygons_pose0.mean(axis=0)  # shape [2]
    gt_center = gt_polygons.mean(axis=0)            # shape [2]
    dist = np.linalg.norm(pred_center - gt_center)  # scalar
    return dist

def calculate_origin_poses(rawdatas, device, repeat=1, state_range=400):
    origin_poses, origin_poses_2d = [], []
    for rdata in rawdatas:
        origin_pose = rdata["origin_pose"]
        origin_poses.append(origin_pose)
        pose = np.eye(3, dtype=np.float32)
        pose[:2, :2] = origin_pose[:2, :2]
        pose[:2, 2]  = origin_pose[:2, 3] / state_range
        origin_poses_2d.append(pose)
    origin_poses_2d_inv = [np.linalg.inv(pose) for pose in origin_poses_2d]

    origin_poses = np.array(origin_poses)
    origin_poses_2d = np.array(origin_poses_2d)
    origin_poses_2d_inv = np.array(origin_poses_2d_inv)

    if repeat > 1:
        origin_poses = np.tile(origin_poses, (repeat, 1, 1))
        origin_poses_2d = np.tile(origin_poses_2d, (repeat, 1, 1))
        origin_poses_2d_inv = np.tile(origin_poses_2d_inv, (repeat, 1, 1))

    origin_poses_2d = torch.tensor(origin_poses_2d, dtype=torch.float32).to(device)
    origin_poses_2d_inv = torch.tensor(origin_poses_2d_inv, dtype=torch.float32).to(device)

    return origin_poses, origin_poses_2d, origin_poses_2d_inv

def get_lane_direction_str(lane_direction):
    lane_direction_str = ""
    if lane_direction & 0x1:
        lane_direction_str += "↓"
    if (lane_direction >> 1) & 0x1:
        lane_direction_str += "→"
    if (lane_direction >> 2) & 0x1:
        lane_direction_str += "↑"
    if (lane_direction >> 3) & 0x1:
        lane_direction_str += "←"
    if (lane_direction >> 4) & 0x1:
        lane_direction_str += "↓"
    return lane_direction_str
