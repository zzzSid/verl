# road_boundary_builder.py

import matplotlib.pyplot as plt
import numpy as np

from scipy.interpolate import interp1d
from scipy.ndimage import convolve
from shapely.geometry import LineString, MultiLineString, GeometryCollection, Point, Polygon, box
from shapely.strtree import STRtree
from skimage.morphology import skeletonize, binary_opening, binary_closing
from typing import Dict, List, Any

from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import MAIN_ACTION_MAPPING
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import ASSIST_ACTION_MAPPING

from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import ego2global
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import get_rotated_rectangle
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import transform_obj


cmap = plt.cm.get_cmap("tab20", 30)
markers = ["o", "s", "^", "v", "<", ">", "d", "D", "p", "P", "*", "h", "H", "X", "x", "+", "|", "_", "."]


def _explode_lines(geom):
    """把任意几何打平成 LineString 列表."""
    if geom is None:
        return []
    if isinstance(geom, LineString):
        return [geom]
    if isinstance(geom, (MultiLineString, GeometryCollection)):
        out = []
        for g in geom.geoms:
            out.extend(_explode_lines(g))
        return out
    return []


def _neighbors8(y, x, H, W):
    for yy in range(y - 1, y + 2):
        for xx in range(x - 1, x + 2):
            if yy == y and xx == x:
                continue
            if 0 <= yy < H and 0 <= xx < W:
                yield yy, xx


def _prune_spurs(skel, max_len_px=5):
    """
    端点毛刺剪枝：从端点(8邻域度=1)向前走，遇到分叉(度!=2)或长度>=阈值停止；
    若长度<阈值则删除这段路径。多轮迭代直到没有可剪枝毛刺。
    """
    H, W = skel.shape
    K = np.ones((3, 3), dtype=np.uint8)
    changed = True
    skel = skel.copy()

    while changed:
        changed = False
        # 邻居计数（含自身），减去自身得到8邻域度
        deg = convolve(skel.astype(np.uint8), K, mode="constant", cval=0) - skel.astype(np.uint8)
        endpoints = np.argwhere((skel) & (deg == 1))

        for (sy, sx) in endpoints:
            path = []
            py, px = -1, -1
            cy, cx = sy, sx

            for _ in range(max_len_px):
                path.append((cy, cx))
                # 当前点邻居（在骨架上）
                nbrs = [(ny, nx) for (ny, nx) in _neighbors8(cy, cx, H, W) if skel[ny, nx]]
                # 去掉上一像素，避免回头
                if (py, px) in nbrs:
                    nbrs.remove((py, px))

                # 遇到分叉/节点（度!=2）或走到尽头就停
                if deg[cy, cx] != 1 and deg[cy, cx] != 2:
                    break
                if len(nbrs) == 0:
                    break
                if len(nbrs) >= 2:
                    break

                # 前进
                py, px = cy, cx
                cy, cx = nbrs[0]

                # 如果下一个点就是“节点”（度!=2），停
                if deg[cy, cx] != 2:
                    path.append((cy, cx))
                    break

            # 若路径短（毛刺），删除
            if 1 <= len(path) <= max_len_px:
                changed = True
                for (yy, xx) in path:
                    skel[yy, xx] = False

    return skel


def find_straight_start_by_yaw(trajpose, timestamps, yaw_window=5, yaw_thresh=0.01):
    """
    trajpose: [N, 4, 4] 轨迹矩阵 (ego->world)
    timestamps: 对应的时间戳
    yaw_window: 平滑窗口
    yaw_thresh: 航向角变化阈值 (弧度)
    """
    # 提取航向角 (yaw)
    yaws = np.arctan2(trajpose[:, 1, 0], trajpose[:, 0, 0])  # atan2(R10, R00)

    # 计算帧间 yaw 变化
    dyaw = np.abs(np.diff(yaws))
    dyaw = np.unwrap(dyaw)  # 处理跳变

    # 平滑
    kernel = np.ones(yaw_window) / yaw_window
    dyaw_smooth = np.convolve(dyaw, kernel, mode="same")

    # 找到第一个 yaw 变化小于阈值的位置
    idx = np.where(dyaw_smooth < yaw_thresh)[0]
    if len(idx) > 0:
        start_idx = idx[0]
        return timestamps[start_idx]
    else:
        return timestamps[0]  # 默认第一个


import numpy as np
from shapely.geometry import LineString


def find_stable_boundary_segment(boundary_pts, ego_traj, dist_window=5, yaw_window=5, yaw_thresh=0.05, dist_thresh=0.5):
    """
    找到边界上既直、又和自车轨迹保持稳定距离的起点

    Args:
        boundary_pts: (N,2) 左边界点链，已按行进方向排序，最好2m采样
        ego_traj: (M,2) 自车GT轨迹
        dist_window: 平滑窗口 (距离)
        yaw_window: 平滑窗口 (角度)
        yaw_thresh: 角度变化阈值 (弧度)
        dist_thresh: 距离变化阈值 (米)
    Returns:
        idx: 边界点链中符合条件的第一个点的索引
    """
    # === Step1: 方向角 ===
    dx = np.diff(boundary_pts[:, 0])
    dy = np.diff(boundary_pts[:, 1])
    yaws = np.arctan2(dy, dx)
    if len(yaws) < 2:
        return 0

    dyaw = np.abs(np.diff(yaws))
    dyaw = np.unwrap(dyaw)  # 防止 -π/π 跳变

    # 平滑
    kernel = np.ones(yaw_window) / yaw_window
    dyaw_smooth = np.convolve(dyaw, kernel, mode="same")

    # === Step2: 计算边界点到自车轨迹的距离 ===
    ego_line = LineString(ego_traj)
    dists = np.array([ego_line.distance(Point(pt.tolist())) for pt in boundary_pts])
    ddist = np.abs(np.diff(dists))

    kernel = np.ones(dist_window) / dist_window
    ddist_smooth = np.convolve(ddist, kernel, mode="same")

    # === Step3: 找到同时满足两个条件的起点 ===
    min_len = min(len(dyaw_smooth), len(ddist_smooth))
    idxs = np.where((dyaw_smooth[:min_len] < yaw_thresh) & (ddist_smooth[:min_len] < dist_thresh))[0]

    if len(idxs) > 0:
        return idxs[0]
    else:
        return 0


def construct_navi_env_v3(data, all_timestamps, start_time_data, max_dist=15):
    """获取最后一帧自车坐标系下 各个时刻的feature"""
    start_time = start_time_data["start_timestamp"]
    init_trajpose = start_time_data["trajpose"]

    trajpose = [data[ts]["car_pose"] for ts in all_timestamps]  # 后轴

    shift = np.eye(4)  # I
    shift[:3, 3] = [1.4, 0, 0]
    egocenter_pose = [t @ shift for t in trajpose]  # 转到自车中心

    origin_pose = egocenter_pose[-1]  # origin pos 最后一帧自车中心
    use_timestamp = all_timestamps[-1]
    origin_pose_inv = np.linalg.inv(origin_pose)

    ego_gt_polygon = []  # origin_pose自车中心系, 每个时刻自车的polygon
    stop_lines_all = []  # origin_pose自车中心系, 每个时刻的stopline
    lane_lines_all = []  # origin_pose自车中心系, 每个时刻的laneline
    roadedge_lines_all = []  # origin_pose自车中心系, 每个时刻的roadedge

    future_timestamps = [ts for ts in all_timestamps if ts >= start_time]

    # transform init_trajpose to origin_pose
    init_trajpose_in_origin = np.matmul(origin_pose_inv, init_trajpose)
    init_trajpose_in_origin = init_trajpose_in_origin[:, :3, 3]

    for ts in future_timestamps:
        # ego gt polygon
        ego_pose_backwheel = origin_pose_inv @ data[ts]["car_pose"]  # ts时刻自车后轴系到origin_pose自车中心系矩阵
        egoinfo = np.array([[0, 0, 0, 4.85, 2, 2, 0]], dtype=np.float32)  # ts时刻自车中心系
        ego = transform_obj(egoinfo, ego_pose_backwheel @ shift)  # attr 7 [x, y, z, l, w, h, heading]
        ego_polygon = get_rotated_rectangle(ego)
        ego_gt_polygon.append(ego_polygon[0])

        env_T = origin_pose_inv @ data[ts]["car_pose"]  # ts自车后轴到origin_pose自车中心系矩阵
        # lines
        lanes = data[ts]["manner_lane_points"]
        types = data[ts]["manner_lane_types"]
        attrs = data[ts]["manner_lane_attr"]
        lane_lines = []
        stop_line = []
        roadedge_line = []
        for p, t, a in zip(lanes, types, attrs):
            """
            p为N个点坐标(x, y): N * 2
            t为整条lane的类型:  1
            a为每个point的类型: N * 2
            """
            # --- 转换前过滤 ---
            if max_dist is not None:
                dists = np.linalg.norm(p, axis=1)  # xy 平面距离
                mask = dists <= max_dist
                p = p[mask]
                a = a[mask]  # 属性同步裁剪

            if p.shape[0] == 0:
                continue  # 全部点超过50米，跳过

            p = ego2global(p, env_T)
            if t == 0:  # lane_line
                lane_lines.append([p, a])
            elif t == 2:  # stop_line
                stop_line.append(p)
            elif t == 1:
                roadedge_line.append([p, a])
        lane_lines_all.append(lane_lines)
        stop_lines_all.append(stop_line)
        roadedge_lines_all.append(roadedge_line)

    navi_raw_data = {
        "ego_gt_polygon": ego_gt_polygon,
        "stop_lines_all": stop_lines_all,
        "lane_lines_all": lane_lines_all,
        "roadedge_lines_all": roadedge_lines_all,
        "timestamps": future_timestamps,
        "origin_pose": origin_pose,
        "use_timestamp": use_timestamp,
        "start_time_data": start_time_data,
    }

    return navi_raw_data


def process_ego_traj(data, timestamps, start_timestamp):
    """将直行段作为坐标系原点"""
    ori_trajposes = [data[ts]["car_pose"] for ts in timestamps]
    ori_trajposes_stack = np.stack(ori_trajposes)

    start_index = timestamps.index(start_timestamp)
    sub_trajpose = ori_trajposes_stack[start_index:]
    use_timestamps = timestamps[start_index:]

    cur_pos = data[start_timestamp]["car_pose"]
    orin_pose = np.linalg.inv(cur_pos)
    transform_trajpose = np.matmul(orin_pose, sub_trajpose)

    new_start_time = find_straight_start_by_yaw(transform_trajpose, use_timestamps)

    new_start_index = timestamps.index(new_start_time)

    index_buffer = 10

    new_start_index = new_start_index - index_buffer if new_start_index - index_buffer >= start_index else start_index

    new_start_time = timestamps[new_start_index]

    if new_start_time != start_timestamp:
        new_start_index = timestamps.index(new_start_time)
        cur_pos = data[new_start_time]["car_pose"]
        new_orin_pose = np.linalg.inv(cur_pos)
        new_sub_trajpose = ori_trajposes_stack[new_start_index:]
        new_transform_trajpose = np.matmul(new_orin_pose, new_sub_trajpose)
        start_timestamp = new_start_time
        orin_pose = new_orin_pose
        transform_trajpose = new_transform_trajpose

    return {
        "start_timestamp": start_timestamp,
        "initpose": orin_pose,
        "trajpose": transform_trajpose,
    }


def downsample_polyline(pts: np.ndarray, step: float = 0.5) -> np.ndarray:
    pts = np.asarray(pts, dtype=np.float32)
    if len(pts) < 2:
        return pts

    # 每段的长度
    diffs = np.diff(pts[:, :2], axis=0)
    seg_lengths = np.hypot(diffs[:, 0], diffs[:, 1])
    s = np.insert(np.cumsum(seg_lengths), 0, 0.0)

    # 按 step 下采样
    sampled_pts = [pts[0]]
    last_s = 0.0
    for i in range(1, len(pts)):
        if s[i] - last_s >= step:
            sampled_pts.append(pts[i])
            last_s = s[i]

    # 确保最后一个点保留
    if not np.allclose(sampled_pts[-1], pts[-1]):
        sampled_pts.append(pts[-1])

    return np.array(sampled_pts, dtype=np.float32)


def densify_polyline(pts: np.ndarray, step: float = 0.5) -> np.ndarray:
    """
    将一条 polyline 均匀化采样（插密点），支持 2D 或 3D 点链
    Args:
        pts: (N,2) 或 (N,3) numpy 数组，输入的点链
        step: float，采样间隔 (米)
    Returns:
        densified_pts: (M,2) 或 (M,3) numpy 数组，均匀采样后的点链
    """
    pts = np.asarray(pts, dtype=np.float32)
    if len(pts) < 2:
        return pts

    # 1) 计算累计弧长（只考虑 xy 平面距离）
    diffs = np.diff(pts[:, :2], axis=0)
    seg_lengths = np.hypot(diffs[:, 0], diffs[:, 1])
    s = np.insert(np.cumsum(seg_lengths), 0, 0.0)

    # 2) 构建插值函数（对每个维度都做）
    f_list = [interp1d(s, pts[:, d], kind="linear") for d in range(pts.shape[1])]

    # 3) 在等距采样点上插值
    s_new = np.arange(0, s[-1], step)
    densified_pts = np.column_stack([f(s_new) for f in f_list])

    # 确保包含最后一个原始点
    if not np.allclose(densified_pts[-1], pts[-1]):
        densified_pts = np.vstack([densified_pts, pts[-1]])

    return densified_pts


def _closest_point_on_segment(P, A, B):
    """零优化：点到线段最近点（欧氏投影公式）"""
    AB = B - A
    AB2 = float(np.dot(AB, AB))
    if AB2 == 0.0:
        Q = A.copy()
        d2 = float(np.dot(P - Q, P - Q))
        return Q, d2
    t = float(np.dot(P - A, AB) / AB2)
    if t < 0.0:
        t = 0.0
    elif t > 1.0:
        t = 1.0
    Q = A + t * AB
    d2 = float(np.dot(P - Q, P - Q))
    return Q, d2


def get_left_right_boundarys_simple(sub_trajpose, merged_lines):
    """
    初版（无任何优化）：
    1）按自车的 x 坐标升序遍历每个自车点 P
    2）取自车前进方向的垂直方向为法向 n
    3）对所有路沿折线的每一条线段，计算 P 到线段的最近点 Q（欧氏距离）
    4）用 (Q-P)·n 的正负号区分左右，分别取距离最近的一点
    5）按遍历顺序拼接 polygon（左顺 + 右逆）

    Returns:
        polygon: shapely Polygon 或 None
        left_pts:  (K,2) np.ndarray
        right_pts: (K,2) np.ndarray
    """
    traj = np.asarray(sub_trajpose, dtype=float)
    if traj.shape[1] > 2:
        traj = traj[:, :2]
    T = len(traj)
    if T < 2 or not merged_lines:
        return None, np.empty((0, 2)), np.empty((0, 2))

    # --- 把所有折线拆成“线段列表” ---
    segments = []  # 列表里每个元素是 (A, B)，A,B都是(2,) ndarray
    for ln in merged_lines:
        coords = np.asarray(ln.coords, dtype=float)
        for i in range(len(coords) - 1):
            A = coords[i]
            B = coords[i + 1]
            segments.append((A, B))
    if not segments:
        return None, np.empty((0, 2)), np.empty((0, 2))

    # --- 按自车 x 升序遍历下标 ---
    order = np.argsort(traj[:, 0])

    left_list, right_list = [], []

    for k, idx in enumerate(order):
        P = traj[idx]

        # 前进方向切向 d：用 x 排序的邻近点做差分（端点用前/后向）
        if 0 < k < len(order) - 1:
            prevP = traj[order[k - 1]]
            nextP = traj[order[k + 1]]
            d = nextP - prevP
        elif k == 0:
            d = traj[order[k + 1]] - traj[order[k]]
        else:
            d = traj[order[k]] - traj[order[k - 1]]

        # 归一化，防零
        dn = np.linalg.norm(d)
        if dn == 0.0:
            # 退化时给一个默认方向（朝 +x）
            d = np.array([1.0, 0.0], dtype=float)
        else:
            d = d / dn

        # 法向（垂直于前进方向）
        n = np.array([-d[1], d[0]], dtype=float)

        # 遍历所有线段，分别找左右最近
        best_left_d2, best_left_Q = float("inf"), None
        best_right_d2, best_right_Q = float("inf"), None

        for A, B in segments:
            Q, d2 = _closest_point_on_segment(P, A, B)
            lat = float(np.dot(Q - P, n))  # 侧向：>0 左，<0 右
            if lat > 0.0:
                if d2 < best_left_d2:
                    best_left_d2 = d2
                    best_left_Q = Q
            elif lat < 0.0:
                if d2 < best_right_d2:
                    best_right_d2 = d2
                    best_right_Q = Q
            else:
                # 正好落在法向轴上（极少见），不计入左右
                pass

        if best_left_Q is not None and best_right_Q is not None:
            left_list.append(best_left_Q)
            right_list.append(best_right_Q)

    if len(left_list) >= 2 and len(right_list) >= 2:
        left_pts = np.vstack(left_list)
        right_pts = np.vstack(right_list)
        ring = np.vstack([left_pts, right_pts[::-1]])
        polygon = Polygon(ring)
    else:
        polygon = None
        left_pts = np.empty((0, 2))
        right_pts = np.empty((0, 2))

    return polygon, left_pts, right_pts


def get_left_right_boundarys_local_search(
    sub_trajpose, merged_lines, epsilon=0.2, search_radius=10.0, virtual_dist=9.0
):
    orig_traj = np.asarray(sub_trajpose, dtype=float)
    if orig_traj.shape[1] > 2:
        orig_traj = orig_traj[:, :2]
    T = len(orig_traj)
    if T < 2 or not merged_lines:
        return None, np.empty((0, 2)), np.empty((0, 2))
    dist = np.zeros(T)
    dist[1:] = np.cumsum(np.linalg.norm(np.diff(orig_traj, axis=0), axis=1))
    min_point_dist = 2
    num_new = max(int(dist[-1] // min_point_dist), 1) + 1
    new_dist = np.linspace(0, dist[-1], num_new)

    interp_x = np.interp(new_dist, dist, orig_traj[:, 0])
    interp_y = np.interp(new_dist, dist, orig_traj[:, 1])
    traj = np.vstack([interp_x, interp_y]).T
    T = len(traj)
    # 拆成线段，并存储 (LineString, index) 元组
    segments = []
    seg_geoms = []
    for ln in merged_lines:
        coords = np.asarray(ln.coords, dtype=float)
        for i in range(len(coords) - 1):
            A, B = coords[i], coords[i + 1]
            segments.append((A, B))
            seg_geoms.append(LineString([A, B]))

    if not segments:
        return None, np.empty((0, 2)), np.empty((0, 2))

    # 构建 STRtree，同时用字典保存索引
    tree = STRtree(seg_geoms)
    geom2idx = {id(geom): i for i, geom in enumerate(seg_geoms)}

    left_list, right_list = [], []

    for k in range(T):
        P = traj[k]
        # 前进方向 d
        if 0 < k < T - 1:
            d = traj[k + 1] - traj[k - 1]
        elif k == 0:
            d = traj[k + 1] - traj[k]
        else:
            d = traj[k] - traj[k - 1]

        dn = np.linalg.norm(d)
        if dn == 0.0:
            d = np.array([1.0, 0.0])
        else:
            d = d / dn

        n = np.array([-d[1], d[0]])

        # 构建法向搜索矩形
        P_left = P + n * search_radius
        P_right = P - n * search_radius
        minx = min(P[0], P_left[0], P_right[0])
        maxx = max(P[0], P_left[0], P_right[0])
        miny = min(P[1], P_left[1], P_right[1])
        maxy = max(P[1], P_left[1], P_right[1])
        search_box = box(minx, miny, maxx, maxy)

        candidate_segs = tree.query(search_box)

        best_left_d2, best_left_Q = float("inf"), None
        best_right_d2, best_right_Q = float("inf"), None

        for seg in candidate_segs:
            # 安全获取索引
            idx = geom2idx.get(id(seg))
            if idx is None:
                continue  # 跳过意外类型
            A, B = segments[idx]
            Q, d2 = _closest_point_on_segment(P, A, B)
            lat = np.dot(Q - P, n)
            if lat > epsilon:
                if d2 < best_left_d2:
                    best_left_d2 = d2
                    best_left_Q = Q
            elif lat < -epsilon:
                if d2 < best_right_d2:
                    best_right_d2 = d2
                    best_right_Q = Q

        # 虚拟边界
        if best_left_Q is None:
            best_left_Q = P + n * virtual_dist
        if best_right_Q is None:
            best_right_Q = P - n * virtual_dist

        left_list.append(best_left_Q)
        right_list.append(best_right_Q)

    left_pts = np.vstack(left_list)
    right_pts = np.vstack(right_list)
    polygon = Polygon(np.vstack([left_pts, right_pts[::-1]]))

    return polygon, left_pts, right_pts


def _skeleton_to_lines_ordered(skel, res, x_min, y_min, min_len_px=2):
    from collections import deque

    H, W = skel.shape
    visited = np.zeros_like(skel, dtype=bool)
    lines = []

    # 8邻域
    neighbors = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]

    def in_bounds(y, x):
        return 0 <= y < H and 0 <= x < W

    # 找所有骨架点
    ys, xs = np.where(skel > 0)
    points_set = set(zip(ys, xs))

    # 找端点（邻居数=1）
    endpoints = []
    for y, x in points_set:
        cnt = sum((in_bounds(y + dy, x + dx) and skel[y + dy, x + dx]) for dy, dx in neighbors)
        if cnt == 1:
            endpoints.append((y, x))

    # 从端点追踪路径
    for ep in endpoints:
        if visited[ep]:
            continue
        path = []
        stack = deque([ep])
        while stack:
            y, x = stack.pop()
            if visited[y, x]:
                continue
            visited[y, x] = True
            path.append((y, x))
            for dy, dx in neighbors:
                ny, nx = y + dy, x + dx
                if in_bounds(ny, nx) and skel[ny, nx] and not visited[ny, nx]:
                    stack.append((ny, nx))
                    break  # 保证沿一条路径
        if len(path) >= min_len_px:
            ys_line, xs_line = zip(*path)
            xs_line = np.array(xs_line) * res + x_min
            ys_line = np.array(ys_line) * res + y_min
            lines.append(LineString(np.stack([xs_line, ys_line], axis=1)))

    # 处理剩余未访问像素（闭环或孤立分支）
    remaining = np.where((skel > 0) & (~visited))
    for y, x in zip(*remaining):
        if visited[y, x]:
            continue
        path = []
        stack = deque([(y, x)])
        while stack:
            yy, xx = stack.pop()
            if visited[yy, xx]:
                continue
            visited[yy, xx] = True
            path.append((yy, xx))
            for dy, dx in neighbors:
                ny, nx = yy + dy, xx + dx
                if in_bounds(ny, nx) and skel[ny, nx] and not visited[ny, nx]:
                    stack.append((ny, nx))
                    break
        if len(path) >= min_len_px:
            ys_line, xs_line = zip(*path)
            xs_line = np.array(xs_line) * res + x_min
            ys_line = np.array(ys_line) * res + y_min
            lines.append(LineString(np.stack([xs_line, ys_line], axis=1)))

    return lines


def fuse_roadedge_with_grid_v3(
    sub_trajpose,
    roadedge_point_timestamp_all,
    res=0.2,  # 栅格分辨率(米)
    min_count=3,  # 投票阈值
    morph_open=False,  # 是否开运算
    morph_close=True,  # 是否闭运算
    simplify_tol=0.05,  # 折线简化
    min_cc_px=2,  # 过滤小连通块(像素个数)
    prune_spur_m=0.0,  # 剪枝毛刺长度(米)
    join_dist_m=1.0,  # 端点吸附合并半径(米)
    min_line_m=0.3,  # 最终最短线长度(米)
):
    """
    基于栅格的路沿融合（抗碎版）
    返回: List[LineString]
    """
    # ===== Step1: 收集所有点 =====
    all_pts = []
    for frame in roadedge_point_timestamp_all:
        for pts in frame:
            if pts is None or len(pts) == 0:
                continue
            all_pts.append(pts[:, :2])
    if not all_pts:
        return []
    all_points = np.vstack(all_pts)

    # ===== Step2: 栅格投票 =====
    x_min, y_min = all_points.min(axis=0)
    x_max, y_max = all_points.max(axis=0)
    W = int(np.ceil((x_max - x_min) / res)) + 1
    H = int(np.ceil((y_max - y_min) / res)) + 1

    grid = np.zeros((H, W), dtype=np.int32)
    ix = ((all_points[:, 0] - x_min) / res).astype(int)
    iy = ((all_points[:, 1] - y_min) / res).astype(int)
    # 限边
    ix = np.clip(ix, 0, W - 1)
    iy = np.clip(iy, 0, H - 1)
    np.add.at(grid, (iy, ix), 1)

    # ===== Step3: 阈值化 + 连通域清理 + 形态学 =====
    mask = grid >= min_count

    if morph_open:
        mask = binary_opening(mask)
    if morph_close:
        mask = binary_closing(mask)

    if not mask.any():
        return []

    # ===== Step4: 骨架化 + 毛刺剪枝 =====
    skel = skeletonize(mask)  # 1像素骨架
    if prune_spur_m > 0:
        spur_px = max(1, int(round(prune_spur_m / res)))
        skel = _prune_spurs(skel, max_len_px=spur_px)

    if not skel.any():
        return []

    merged_lines = _skeleton_to_lines_ordered(skel, res, x_min, y_min, min_len_px=min_cc_px)

    polygon, left_buffer, right_buffer = get_left_right_boundarys_local_search(sub_trajpose, merged_lines)

    return merged_lines, polygon, left_buffer, right_buffer


def process_merged_data(all_merge_datas):
    """将所有帧的路沿融合成网格"""
    roadedge_point_timestamp_all = []
    if all_merge_datas is not None:
        roadedge_lines_all = all_merge_datas["roadedge_lines_all"]
        merged_data_init_pose = all_merge_datas["origin_pose"]
        for roadedges in roadedge_lines_all:
            roadedge_points_per_time = []
            for points, attr in roadedges:
                densifyd_points = densify_polyline(points, 0.1)
                roadedge_points_per_time.append(densifyd_points)
            roadedge_point_timestamp_all.append(roadedge_points_per_time)

        start_time_data = all_merge_datas["start_time_data"]
        ego_initpose = start_time_data["initpose"]
        ego_traj = start_time_data["trajpose"]

        # 统一到init_pose坐标系下
        ego_initpose_to_world = np.linalg.inv(ego_initpose)
        T = np.linalg.inv(merged_data_init_pose) @ ego_initpose_to_world
        ego_traj = np.matmul(T, ego_traj)
        sub_trajpose = ego_traj[:, :3, 3]

    lines, polygon, left_buffer, right_buffer = fuse_roadedge_with_grid_v3(
        sub_trajpose, roadedge_point_timestamp_all, res=0.2, min_count=5
    )

    return lines, polygon, left_buffer, right_buffer, sub_trajpose


def _fill_road_boundary_global(data, result):
    """
    把 process() 的 road boundary 结果分发到每一帧
    Args:
        data: Dict[ts -> frame dict]  (包含 'car_pose')
        result: Dict, 来自 process() 的输出
    Returns:
        data: 更新后的 data，每帧包含 ['road_boundary'] 字段
    """

    timestamps = sorted(data["timestamp_list"])
    origin_pose = result["origin_pose"]

    for ts in timestamps:
        inv_car_pose = np.linalg.inv(data[ts]["car_pose"])
        convert_mat = inv_car_pose @ origin_pose

        poly = result["drivable_polygon"]
        if hasattr(poly, "exterior"):  # shapely.Polygon
            poly_coords = np.array(poly.exterior.coords)
        else:
            poly_coords = np.array(poly)
        poly_local = ego2global(poly_coords, convert_mat)

        left = np.array(result["left_boundary"])
        right = np.array(result["right_boundary"])
        left_local = ego2global(left, convert_mat)
        right_local = ego2global(right, convert_mat)

        merged_lines_local = []
        for line in result["merged_lines"]:
            if hasattr(line, "coords"):  # shapely LineString
                coords = np.array(line.coords)
            else:
                coords = np.array(line)
            merged_lines_local.append(ego2global(coords, convert_mat))

        data[ts]["navi_road_driving_space"] = {
            "drivable_polygon": poly_local,
            "left_boundary": left_local,
            "right_boundary": right_local,
            "merged_lines": merged_lines_local,
            "left_start_index": result["left_start_index"],
        }

    return data


class RoadBoundaryBuilder:
    """
    用法：
        builder = RoadBoundaryBuilder(res=0.2, min_count=3)
        result = builder.run(data, timestamps)

    返回 result 字典包含：
        - start_timestamp: 选定的起点时间戳
        - merged_lines: List[LineString]  融合后的路沿线
        - left_boundary: (K,2) np.ndarray  左边界点链
        - right_boundary: (K,2) np.ndarray 右边界点链
        - drivable_polygon: shapely Polygon 或 None
        - origin_pose: (4,4) 将所有结果表达在该坐标系下
    """

    def __init__(
        self,
        res: float = 0.2,
        min_count: int = 3,
        morph_open: bool = False,
        morph_close: bool = True,
        densify_step: float = 0.1,
    ):
        self.res = res
        self.min_count = min_count
        self.morph_open = morph_open
        self.morph_close = morph_close
        self.densify_step = densify_step

    def process(self, data: Dict, timestamps: List[float]) -> Dict[str, Any]:
        """单帧数据增加GT边界"""
        timestamps = sorted(timestamps)
        start_timestamp = timestamps[0]
        start_time_data = process_ego_traj(data, timestamps, start_timestamp)
        all_merge_datas = construct_navi_env_v3(data, timestamps, start_time_data)

        merged_lines, polygon, left_buffer, right_buffer, sub_trajpose = process_merged_data(
            all_merge_datas,
        )

        left_boundary_pts = downsample_polyline(left_buffer, step=2.0)
        left_start_index = find_stable_boundary_segment(left_boundary_pts, sub_trajpose)

        result = {
            "start_timestamp": start_time_data["start_timestamp"],
            "origin_pose": all_merge_datas["origin_pose"],
            "merged_lines": merged_lines,
            "left_boundary": left_boundary_pts,
            "right_boundary": right_buffer,
            "drivable_polygon": polygon,
            "use_timestamp": all_merge_datas["use_timestamp"],
            "left_start_index": left_start_index,
        }

        data = _fill_road_boundary_global(data, result)

        return data
