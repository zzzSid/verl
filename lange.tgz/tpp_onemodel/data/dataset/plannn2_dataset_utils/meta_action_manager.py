import bisect
import numpy as np
import torch
from tqdm import tqdm
import matplotlib.pyplot as plt
import math
import cv2
import os
from typing import List

from scipy.spatial.transform import Rotation as R
from scipy.interpolate import interp1d
from scipy.spatial.transform import Rotation
from scipy.spatial.transform import Slerp
from scipy.spatial.transform import Rotation as R
from shapely.geometry import Polygon
from shapely.geometry import LineString
from shapely.geometry import Point
from shapely.geometry import MultiPolygon
from shapely.geometry import MultiLineString
import imageio.v2 as iio  # pip install imageio imageio-ffmpeg

from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils.misc import (
    COLORS_ID,
    MAIN_ACTION_MAPPING,
    ASSIST_ACTION_MAPPING,
    kLaneTypeMap,
    get_lane_direction_str,
    get_chinese_font,
    parse_dynamicobj_v2,
    parse_dynamicobj_v3,
)
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils.geometry import (split_line,get_rotated_rectangle,
                                                                            ego2global, ego2global2d, transform_obj)

from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import get_map_cls_to_3cls

class SimpleViz:

    def __init__(self, uuid):
        self.uuid = uuid
        self.fps = 5

    def _vis_raw_env(
        self,
        raw_env,
        dobjs_full,
        dobjs_polygons,
        ts,
        ax,
        T=None,
    ):
        navi_info = raw_env[ts]["navi_infos"]
        # draw sub_path
        sub_path = ego2global2d(navi_info['sub_path_main_path_points'], T)
        if sub_path is not None:
            ax.plot(sub_path[:, 0], sub_path[:, 1], color="green", linewidth=3, alpha=0.2)
            disptext = ""
        else:
            disptext = "no sub_path "

        # draw action lane_nr_info
        main_action_1 = navi_info['main_action_1']
        main_action_str_1 = MAIN_ACTION_MAPPING[main_action_1] if main_action_1 > 0 else "-"
        assistant_action_1 = navi_info['assistant_action_1']
        assistant_action_str_1 = ASSIST_ACTION_MAPPING[assistant_action_1] if assistant_action_1 > 0 else "-"
        main_action_2 = navi_info['main_action_2']
        main_action_str_2 = MAIN_ACTION_MAPPING[main_action_2] if main_action_2 > 0 else "-"
        assistant_action_2 = navi_info['assistant_action_2']
        assistant_action_str_2 = ASSIST_ACTION_MAPPING[assistant_action_2] if assistant_action_2 > 0 else "-"
        link_main_distance_1 = navi_info['link_main_distance_1']
        link_main_distance_2 = navi_info['link_main_distance_2']
        lane_nr_distance = navi_info['lane_nr_remain_distance']

        text = (f"主1: {main_action_str_1} 辅1: {assistant_action_str_1} 距1: {link_main_distance_1}"
                f"  主2: {main_action_str_2} 辅2: {assistant_action_str_2} 距2: {link_main_distance_2}")
        text2 = f"NextLane距: {lane_nr_distance}"
        for info in navi_info['lane_infos']:
            lane_direction, lane_highline_direction, lane_is_drivable, lane_is_highline, lane_type = info
            lane_type_str = kLaneTypeMap[lane_type]
            lane_direction_str = get_lane_direction_str(lane_direction)
            lane_direction_highline_str = get_lane_direction_str(lane_highline_direction)

            prefix = ""
            postfix = ""
            if not lane_is_drivable:
                prefix += "X"
                postfix += "X"
            if lane_is_highline or lane_direction_highline_str:
                postfix = f"[{lane_direction_highline_str}]" + postfix
            text2 += f" {prefix}{lane_direction_str}{lane_type_str}{postfix}"

        xmin, xmax = ax.get_xlim()
        ymin, ymax = ax.get_ylim()
        # draw text on right
        ax.text(xmax - 5, ymax - 1, text, color='k', ha='right', va='top', fontproperties=get_chinese_font())
        ax.text(xmax - 5, ymax - 6, text2, color='k', ha='right', va='top', fontproperties=get_chinese_font())

        # draw tld # ["k", "red", "yellow", "green", "gray"]
        tld = raw_env[ts]["tld"]
        tldcolor = ["k", "red", "yellow", "green", "gray"]
        for i, c in enumerate(tld):
            c = tldcolor[c]
            ax.scatter(xmin + 5 + i * 5, ymax-5, color=c, s=100)
            ax.text(xmin + 4 + i * 5, ymax-6, "↓←↑→"[i], color='k')

        # spd_limit
        spd_limit = raw_env[ts]["spd_limit"]
        disptext += f", limit: {spd_limit}"

        sobjs = raw_env[ts]["sobjs_polygon"]
        for d in sobjs:
            d = ego2global2d(d, T)
            ax.fill(d[:, 0], d[:, 1], color="olive", alpha=0.7, edgecolor="darkkhaki", linewidth=0.5)

        road_sign = raw_env[ts]["road_sign"]
        for p, ptype in road_sign:
            p = ego2global2d(p, T)
            cx, cy = p.mean(axis=0)[:2]
            ax.fill(p[:, 0], p[:, 1], color="slateblue", alpha=0.5, edgecolor="seagreen", linewidth=0.5)
            ax.text(cx, cy, f"{ptype}", fontsize=5, color="seagreen", ha="center", va="center")

        lane_lines = raw_env[ts]["lane_lines"]
        linecmap = {1: "k", 2: "orange"}
        for p, a in lane_lines:
            p = ego2global2d(p, T)
            # split the lane
            split_a = split_line(a)
            split_p = split_line(p)
            for a, p in zip(split_a, split_p):
                t, c = a[len(a)//2][:2]
                c = linecmap.get(c, 'w')
                s = '--' if t in [2, 8, 9] else '-'
                ax.plot(p[:, 0], p[:, 1], color=c, linestyle=s, linewidth=1)

        road_edge = raw_env[ts]["road_edge"]
        for p in road_edge:
            p = ego2global2d(p, T)
            ax.plot(p[:, 0], p[:, 1], color="purple", linestyle="-.", linewidth=1)

        stop_line = raw_env[ts]["stop_line"]
        for p in stop_line:
            p = ego2global2d(p, T)
            ax.plot(p[:, 0], p[:, 1], color="mediumslateblue")

        # 从 raw_data中读取其他动态物
        _, dobjs = dobjs_full[ts]   # 相对于最初的原点的位置
        dobjs_polygon = dobjs_polygons[ts]
        n = len(dobjs_polygon)
        dobjs_polygon = ego2global2d(dobjs_polygon.reshape(-1, 2), T).reshape(n, 4, 2)
        trackids = dobjs[:, 9].astype(np.int32)
        cids = [get_map_cls_to_3cls(cid) for cid in dobjs[:, 7].astype(int)]
        cxcy = dobjs_polygon.mean(axis=1)
        pxpy = dobjs_polygon[:, 1:3, :].mean(axis=1)
        edge = "darkgreen"
        for d, (x1, y1), (x2, y2), tid, cid in zip(dobjs_polygon, cxcy, pxpy, trackids, cids):
            ax.fill(
                d[:, 0],
                d[:, 1],
                color=np.array(COLORS_ID[tid % len(COLORS_ID)]) / 255.0,
                alpha=0.7,
                edgecolor=edge,
                linewidth=0.8,
                hatch=None,
            )
            ax.plot([x1, x2], [y1, y2], color=edge, linewidth=0.5)

        return disptext

    def vis(
        self,
        savename,
        timestamp,
        frame_agents,
        frame_polygon,
        all_raw_envs,
        ego_polygon,
        ego_poses,
        ego_motions,
        clip_motion_status,
    ):
        """

        Args:
            ego_motions (np.ndarray): (vehspd, yaw_rate, chessis_yawrate, rot_yawrate)
            clip_motion_status (list):
                - lateral: 0 no lane change, 1 left changing, -1 right changing, 2 left changed, -2 right changed
                - longitudinal: 0 stop, 1 uniform, 2 accel, 3 decel
                - speed: 速度 (m/s)
                - acceleration: 加速度 (m/s^2)
        """
        timestamp_size = len(timestamp)
        # tmpdir = tempfile.TemporaryDirectory()
        writer = iio.get_writer(
            savename,
            fps=self.fps,
            codec="libx264",     # widely supported
            format="FFMPEG",
            pixelformat="yuv420p"
        )

        # ego traj
        ego_traj = ego_polygon.mean(axis=1)  # n x 2

        global_xmin, global_xmax = (-75, 75)
        global_ymin, global_ymax = (-25, 25)
        assert (global_xmax - global_xmin) / (global_ymax - global_ymin) == 3.0

        # 速度曲线
        velocity = ego_traj[1:] - ego_traj[:-1]
        velocity = np.linalg.norm(velocity, axis=1) * self.fps * 3.6 # 速度km/h
        velocity = np.insert(velocity, 0, velocity[0])

        # motion
        vel_motion = ego_motions[:, 0] * 3.6  # m/s -> km/h

        v_min = min(velocity.min(), vel_motion.min())
        v_max = max(velocity.max(), vel_motion.max())
        v_diff = v_max - v_min

        timestamps = np.arange(timestamp_size)

        # reward曲线

        # 画图
        for ts in tqdm(range(timestamp_size)):
            state_polygon_at_t = ego_polygon[ts]
            ego_pose = ego_poses[ts]
            ego_center = ego_pose[:2, 3]

            T = None

            fig, ax = plt.subplots(figsize=(15, 5))

            xmin, xmax = (global_xmin + ego_center[0], global_xmax + ego_center[0])
            ymin, ymax = (global_ymin + ego_center[1], global_ymax + ego_center[1])
            ax.set_xlim(xmin, xmax)
            ax.set_ylim(ymin, ymax)   # vis limit
            ax.set_aspect("equal")
            ax.grid(linestyle="--")

            # raw env
            disptext = self._vis_raw_env(all_raw_envs, frame_agents, frame_polygon, ts, ax, T=T)

            # draw ego
            x1, y1 = state_polygon_at_t.mean(axis=0)
            x2, y2 = state_polygon_at_t[1:3, :].mean(axis=0)
            ax.fill(
                state_polygon_at_t[:, 0],
                state_polygon_at_t[:, 1],
                color=np.array(COLORS_ID[0]) / 255.0,
                alpha=0.7,
                edgecolor="red",
                linewidth=1.0,
            )
            ax.plot([x1, x2], [y1, y2], color="red", linewidth=0.5)

            # draw gt ego & longitudinal status
            long_status_names = {0: "stop", 1: "keep", 2: "accelerate", 3: "decelerate"}
            long_status_name = long_status_names[clip_motion_status[ts]["longitudinal"]]
            disptext += f", speed:{velocity[ts]:.1f}km/h, longitudinal:{long_status_name}"
            plt.figtext(0.5, 0.99, disptext, color="k", ha="center", va="top")

            # ego traj
            ego_traj_t = ego2global2d(ego_traj, T)  # n x 2
            ax.plot(
                ego_traj_t[:, 0],
                ego_traj_t[:, 1],
                color="deeppink",
                alpha=0.3,
                linewidth=4,
            )

            plt.figtext(0.5, 0.86, f"History {ts}, uuid:{self.uuid}", color="k", ha="center", va="top")

            # make picture
            plt.subplots_adjust(left=0.01, right=0.99, top=0.90, bottom=0.05)
            fig.canvas.draw()
            image1 = np.frombuffer(fig.canvas.buffer_rgba(), dtype=np.uint8)
            w, h = fig.canvas.get_width_height()
            image1 = image1.reshape((h, w, 4))
            plt.close(fig)

            # 速度曲线
            n = timestamp_size
            fig, axes = plt.subplots(nrows=3, ncols=2, figsize=(15, 9))

            ax = axes[0, 0]
            ax.set_title("Lateral")
            ax.set_ylim(-4.5, 4.5)
            lateral_status = np.array([_status["lateral"] for _status in clip_motion_status])
            ax.plot(timestamps[:n], lateral_status, 'r', label='lateral')
            ax.scatter(timestamps[ts], lateral_status[ts], color='r', s=30, zorder=5)
            # plot horizontal line at 0
            ax.axhline(y=0, color='gray', linestyle='--')
            ax.axhline(y=2.0, color='gray', linestyle='--')
            ax.axhline(y=-2.0, color='gray', linestyle='--')
            ax.legend(loc='upper left')

            ax = axes[0, 1]
            ax.set_title("Longitudinal")
            ax.set_ylim(-4.5, 4.5)
            # 纵向状态：需要偏移以便与横向状态区分
            # 0:stop, 1:uniform, 2:accel, 3:decel -> 映射到不同的y值
            long_status_mapping = {0: 0, 1: 1, 2: 2, 3: 3}
            long_status_array = np.array([long_status_mapping[_status["longitudinal"]] for _status in clip_motion_status])
            ax.plot(timestamps[:n], long_status_array, 'b', label='longitudinal', linewidth=2)
            ax.scatter(timestamps[ts], long_status_array[ts], color='b', s=30, zorder=5)

            # plot horizontal line at 0
            ax.axhline(y=0, color='gray', linestyle='--')
            ax.axhline(y=2.0, color='gray', linestyle='--')
            ax.axhline(y=-2.0, color='gray', linestyle='--')
            # 添加纵向状态的文本标签
            ax.text(timestamps[0], 0, 'STOP', fontsize=8, color='blue', va='center', ha='left')
            ax.text(timestamps[0], 1, 'KEEP', fontsize=8, color='blue', va='center', ha='left')
            ax.text(timestamps[0], 2, 'ACC', fontsize=8, color='blue', va='center', ha='left')
            ax.text(timestamps[0], 3, 'DEC', fontsize=8, color='blue', va='center', ha='left')
            ax.legend(loc='upper left')

            ax = axes[1, 0]
            ax.set_title("Speed Curve")
            ax.set_ylim(math.floor(v_min - v_diff * 0.1), math.ceil(v_max + v_diff * 0.1))
            ax.plot(timestamps[:n], velocity[:n], 'r', label='pose')
            ax.scatter(timestamps[ts], velocity[ts], color='red', s=30, zorder=5)
            ax.plot(timestamps[:n], vel_motion[:n], 'g', label='vehspd')
            ax.scatter(timestamps[ts], vel_motion[ts], color='g', s=30, zorder=5)
            ax.axvline(x=timestamps[ts], color='gray')
            ax.legend(loc='upper left')

            ax = axes[1, 1]
            ax.set_title("Acceleration Curve")
            ax.set_ylim(-5.0, 5.0)
            acceleration = np.array([_status["acceleration"] for _status in clip_motion_status])
            acceleration_raw = np.array([_status["acceleration_raw"] for _status in clip_motion_status])
            ax.plot(timestamps[:n], acceleration[:n], 'r', label='acce_smooth')
            ax.scatter(timestamps[ts], acceleration[ts], color='red', s=30, zorder=5)
            ax.plot(timestamps[:n], acceleration_raw[:n], 'g', label='acce_raw')
            ax.axhline(y=0, color='gray', linestyle='--')
            ax.axvline(x=timestamps[ts], color='gray')
            ax.legend(loc='upper left')


            # yaw rate 曲线
            yaw_rate = ego_motions[:, 1]  # yaw_rate
            yaw_chessis = ego_motions[:, 2]  # chessis_yawrate
            yaw_rot = ego_motions[:, 3]  # rot_yawrate
            deg_accumu = ego_motions[:, 4]  # deg_accumu

            ax = axes[2, 0]
            ax.set_title("Yaw Rate Curve/Degree")
            # ax.set_ylim(math.floor(y_min - y_diff * 0.1), math.ceil(y_max + y_diff * 0.1))
            ax.set_ylim(-3.0, 3.0)
            ax.plot(timestamps[:n], yaw_rate[:n], 'r', label='yaw_rate')
            ax.scatter(timestamps[ts], yaw_rate[ts], color='red', s=30, zorder=5)
            ax.plot(timestamps[:n], yaw_rot[:n], 'b', label='rot')
            ax.scatter(timestamps[ts], yaw_rot[ts], color='b', s=30, zorder=5)
            ax.axvline(x=timestamps[ts], color='gray')
            # plot horizontal line at 0
            ax.axhline(y=0, color='gray', linestyle='--')
            ax.axhline(y=1.0, color='gray', linestyle='--')
            ax.axhline(y=-1.0, color='gray', linestyle='--')
            ax.legend(loc='upper left')

            ax = axes[2, 1]
            ax.set_title("Yaw Accumu/Degree & Closest Lane Distance/Meter")
            ax.set_ylim(-15.0, 15.0)
            ax.plot(timestamps[:n], deg_accumu[:n], 'r', label='deg_accumu')
            ax.scatter(timestamps[ts], deg_accumu[ts], color='r', s=30, zorder=5)
            ax.plot(timestamps[:n],
                    np.array([_status["closest_lane_dist"] for _status in clip_motion_status]), 'g', label='dist')
            ax.axvline(x=timestamps[ts], color='gray')
            # plot horizontal line at 0
            ax.axhline(y=0, color='gray', linestyle='--')
            ax.axhline(y=5.0, color='gray', linestyle='--')
            ax.axhline(y=-5.0, color='gray', linestyle='--')
            ax.legend(loc='upper left')


            plt.subplots_adjust(left=0.02, right=0.98, top=0.90, bottom=0.10, wspace=0.05)
            fig.canvas.draw()
            image2 = np.frombuffer(fig.canvas.buffer_rgba(), dtype=np.uint8)
            w, h = fig.canvas.get_width_height()
            image2 = image2.reshape((h, w, 4))
            plt.close(fig)

            image = np.concatenate([image1, image2], axis=0)
            # cv2.imwrite(f"./output/preview/{self.uuid}_{ts:0>5}.jpg", image)
            writer.append_data(image)

        writer.close()

class ClipParser:
    def __init__(self, data: dict):
        """
        Args:
            data (dict):
        """
        self.fps = 5
        self.step_size = 0.5  # meters
        self.window_m = 10
        self.data = data
        self._init(data)
        self._init_interpolator()
        self._build_traj_curve()

    @staticmethod
    def inverse_transform(pose: np.ndarray):
        """
        Inverse the 4x4 transformation matrix, not np.linalg.inv for speed and stability.
        """
        pose_inv = np.eye(4, dtype=pose.dtype)
        pose_inv[0:3, 0:3] = pose[0:3, 0:3].T
        pose_inv[0:3, 3] = -pose_inv[0:3, 0:3] @ pose[0:3, 3]
        return pose_inv

    @staticmethod
    def unwrap_angle(angle):
        """将角度限制在 (-pi, pi) 并连续展开"""
        return np.arctan2(np.sin(angle), np.cos(angle))

    def _init(self, data):
        timestamps = sorted(data["timestamp_list"])
        timestamps = np.array(timestamps, dtype=np.float64)

        full_car_pose = [data[_ts]['car_pose'] for _ts in timestamps]
        full_car_pose = np.array(full_car_pose, dtype=np.float64)

        base_pose = full_car_pose[0]
        base_pose_inv = self.inverse_transform(base_pose)

        # transform all poses to be relative to the base pose
        poses_array = np.einsum('ij,tjk->tik', base_pose_inv, full_car_pose)

        # motion
        full_motion = [] # (vehspd, yaw_rate, chessis_yawrate)
        for _ts in timestamps:
            ego_motion = data[_ts]['ego_motion']
            full_motion.append((ego_motion[8], ego_motion[5], ego_motion[10]))
        full_motion = np.array(full_motion, dtype=np.float32)

        self.timestamps = timestamps
        self.base_pose = base_pose
        self.poses_array = poses_array
        self.full_motion = full_motion

    def _init_interpolator(self):
        """
        Initialize the interpolators for poses and motions.
        """

        pose_stamp = []
        pose_distance = []
        pose_position = []
        pose_rotation = []

        last_position = None
        for idx, (stamp, pose) in enumerate(zip(self.timestamps, self.poses_array)):
            pose_stamp.append(stamp)
            if last_position is not None:
                _dist_value = np.linalg.norm(pose[:3, 3] - last_position)
                _dist_value = pose_distance[-1] + max(_dist_value, 1e-3)
                pose_distance.append(_dist_value)
            else:
                pose_distance.append(0.0)
            last_position = pose[:3, 3]

            pose_position.append(pose[:3, 3])
            pose_rotation.append(pose[:3, :3])

        self.pose_distance = np.array(pose_distance, dtype=np.float32)

        self.slerp_distance = interp1d(
            pose_stamp,
            self.pose_distance,
            kind="linear",
            axis=0,
            bounds_error=False,
            fill_value="extrapolate"
        )
        self.slerp_position = interp1d(
            self.pose_distance,
            pose_position,
            kind="linear",
            axis=0,
            bounds_error=False,
            fill_value="extrapolate"
        )
        self.slerp_rotation = Slerp(
            self.pose_distance,
            Rotation.from_matrix(pose_rotation),
        )

        #
        ego_rotations = np.array([self.get_pose_by_timestamp(ts)[:3, :3] for ts in pose_stamp])
        ego_euler_angles = np.array([R.from_matrix(_rot).as_euler('zyx', degrees=False) for _rot in ego_rotations])
        ego_yaw = np.unwrap(ego_euler_angles[:, 0])
        ego_delta_yaw = np.diff(ego_yaw) # [N-1,]
        ego_delta_yaw = np.insert(ego_delta_yaw, 0, ego_delta_yaw[0]) # [N,]
        ego_yaw_rate = ego_delta_yaw * self.fps  # rad to rad/s
        # (vehspd, yaw_rate, chessis_yawrate, delta_yaw)
        self.full_motion = np.concatenate([self.full_motion, ego_yaw_rate[:, None]], axis=1)
        self.slerp_motion = interp1d(
            pose_stamp,
            self.full_motion,
            kind="linear",
            axis=0,
            bounds_error=False,
            fill_value="extrapolate"
        )

    def _build_traj_curve(self):
        """Build trajectory curve for meta-action calculation.
        """
        # step 1. create trajectory points by constant distance interval
        num_steps = int(self.pose_distance[-1] / self.step_size) + 1
        traj_distances = np.linspace(0, self.pose_distance[-1], num_steps, endpoint=True, dtype=np.float32)
        traj_distances = np.clip(traj_distances, 0, self.pose_distance[-1])
        ego_rotations = np.array([self.slerp_rotation(d).as_matrix() for d in traj_distances])
        ego_euler_angles = np.array([R.from_matrix(_rot).as_euler('zyx', degrees=False) for _rot in ego_rotations])
        ego_headings = np.unwrap(ego_euler_angles[:, 0])
        if len(ego_headings) <= 1:
            ego_delta = np.zeros_like(ego_headings)
        else:
            ego_delta = np.diff(ego_headings)
            ego_delta = np.insert(ego_delta, 0, ego_delta[0])

        #
        deg_accumu_wind = []

        for idx in range(len(traj_distances)):
            wind_start = idx
            # TODO: dynamic window size, according to speed
            wind_end = min(len(traj_distances)-1, idx + self.window_m)
            total_turn = np.sum(ego_delta[wind_start:wind_end])
            deg = np.degrees(total_turn)
            deg_accumu_wind.append(deg)

        self.deg_accumu_wind = np.array(deg_accumu_wind, dtype=np.float32)

        if len(traj_distances) < 2:
            traj_distances = np.append(traj_distances, traj_distances[0] + self.step_size)
            self.deg_accumu_wind = np.append(self.deg_accumu_wind, self.deg_accumu_wind[0])

        self.slerp_deg_accumu = interp1d(
            traj_distances,
            self.deg_accumu_wind,
            kind="linear",
            axis=0,
            bounds_error=False,
            fill_value="extrapolate"
        )

    @property
    def length(self):
        return len(self.timestamps)

    @property
    def end_timestamp(self):
        return self.timestamps[-1]

    @property
    def start_timestamp(self):
        return self.timestamps[0]

    def get_pose_by_timestamp(self, timestamp: float):
        """
        Get the interpolated pose by timestamp.

        Args:
            timestamp (float): The timestamp to query.

        Returns:
            pose (np.ndarray): The interpolated 4x4 pose matrix.
        """
        distance = self.slerp_distance(timestamp)
        return self.get_pose_by_distance(distance)

    def get_pose_by_distance(self, distance: float):
        """
        Get the interpolated pose by timestamp.

        Args:
            timestamp (float): The timestamp to query.

        Returns:
            pose (np.ndarray): The interpolated 4x4 pose matrix.
        """
        position = self.slerp_position(distance)
        rotation = self.slerp_rotation(distance).as_matrix()

        pose = np.eye(4, dtype=np.float32)
        pose[:3, :3] = rotation
        pose[:3, 3] = position

        return pose

    def get_motion_by_timestamp(self, timestamp: float):
        """
        Get the interpolated motion by timestamp.

        Args:
            timestamp (float): The timestamp to query.

        Returns:
            motion (np.ndarray): The interpolated motion information.
        """
        motion = self.slerp_motion(timestamp)
        return motion

    def get_deg_accumu_by_timestamp(self, timestamp: float):
        """
        Get the interpolated accumulated degree by timestamp.

        Args:
            timestamp (float): The timestamp to query.

        Returns:
            accumu_deg (float): The interpolated accumulated degree.
        """
        distance = self.slerp_distance(timestamp)
        return self.get_deg_accumu_by_distance(distance)

    def get_deg_accumu_by_distance(self, distance: float):
        """
        Get the interpolated accumulated degree by distance.

        Args:
            distance (float): The distance to query.

        Returns:
            accumu_deg (float): The interpolated accumulated degree.
        """
        accumu_deg = self.slerp_deg_accumu(distance)
        return accumu_deg


def smooth_signal(signal: np.ndarray, window: int = 3) -> np.ndarray:
    """
    简单滑动平均滤波
    """
    if window <= 1:
        return signal

    kernel = np.ones(window) / window
    return np.convolve(signal, kernel, mode="same")


class MetaActionManager:
    """元动作管理器,用于检测自车与周围车辆的碰撞风险(快要碰撞)."""

    # Meta Action: Turn Left/Right
    THRE_TIME_TURN = 2.0  # seconds, lane change duration threshold
    THRE_TURN = 5.0  # rad, turn direction threshold
    THRE_LANE_CHANGE_DEG = 15.0  # degree, lane change threshold
    THRE_U_TURN_DEG = 100.0  # degree, u-turn threshold
    THRE_NUDGE_UPPDER = 2.0 # degree, nudge threshold
    THRE_NUDGE_LOWER = 0.25 # degree, nudge threshold
    THRE_NUDGE_HUMP_DIST = 2.0 # seconds
    THRE_FUTURE_YAW_STABLE = 1.0  # degree, 未来3秒航向角稳定阈值（变化小于此值视为稳定）
    THRE_CENTERED_DIST_DIFF = 0.2  # meters, 居中判断阈值（左右距离差小于此值视为居中）
    THRE_LANE_YAW_ALIGN = 1.0  # degree, ego航向与车道线角度一致性阈值
    LABEL_KEEP = 0         # 车道跟随标签（非居中或航向不稳定时）
    LABEL_LANE_CHANGE = 1  # lane change label, -1 right, +1 left
    LABEL_TURN_CHANGE = 2  # turn change label, -2 right, +2 left
    LABEL_U_TURN = 3       # u-turn label, -3 right, +3 left
    # LABEL_NUDGE = 4        # nudge label, -4 right, +4 left
    LABEL_LANE_CENTERING = 4  # 车道跟随标签（居中且航向稳定时）

    # lane change update params
    MAX_SEARCH_FRAMES = 25   # 最多向前/后搜 5 秒 (FPS=5)
    PATIENCE = 2             # 连续多少帧满足条件则认为完成车道变更
    MIN_PEAK_DIST = 0.8      # meters, 车道变更轨迹峰值最小距离
    MIN_DURATION = 5    # frames, 车道变更最短持续时间

    # Collision risk detection thresholds - 检测快要碰撞的参数
    FRONT_RISK_DISTANCE = 15.0       # meters, 前方风险检测距离
    SIDE_RISK_DISTANCE = 5.0        # meters, 侧方风险检测距离
    DISTANCE_RISK_DISTANCE = 10.0      # meters, 综合风险检测距离
    FRONT_ANGLE_THRESHOLD_1 = 10.0     # degrees, 前方车辆角度阈值
    FRONT_ANGLE_THRESHOLD_2 = 15.0     # degrees, 前方车辆角度阈值
    FRONT_ANGLE_THRESHOLD_3 = 90.0     # degrees, 前方车辆角度阈值
    SIDE_ANGLE_THRESHOLD_MIN = 30.0  # degrees, 侧方来车最小角度
    SIDE_ANGLE_THRESHOLD_MAX = 150.0 # degrees, 侧方来车最大角度

    # TTC (Time To Collision) thresholds
    TTC_FRONT_THRESHOLD = 3.0        # seconds, 前方碰撞时间阈值
    TTC_SIDE_THRESHOLD = 2.0         # seconds, 侧方碰撞时间阈值

    # Safety distance thresholds
    SAFETY_DISTANCE_FRONT = 10.0      # meters, 前方安全距离
    SAFETY_DISTANCE_SIDE = 3.0       # meters, 侧方安全距离


    # Oncoming vehicle detection thresholds - 对向来车检测参数
    ONCOMING_RISK_DISTANCE = 30.0      # meters, 对向来车风险检测距离
    ONCOMING_ANGLE_THRESHOLD_MIN = 120.0  # degrees, 对向来车最小角度阈值
    ONCOMING_ANGLE_THRESHOLD_MAX = 240.0 # degrees, 对向来车最大角度阈值
    ONCOMING_LATERAL_DISTANCE_THRESHOLD = 5.0  # meters, 对向来车横向距离阈值

    # TTC (Time To Collision) thresholds
    TTC_ONCOMING_THRESHOLD = 2.5       # seconds, 对向来车碰撞时间阈值

    # Safety distance thresholds
    SAFETY_DISTANCE_ONCOMING = 15.0     # meters, 对向来车安全距离

    # Relative speed threshold
    RELATIVE_SPEED_THRESHOLD = 0.3   # m/s, 相对速度阈值

    # Cut-in detection thresholds - 检测其他车辆/自行车cut-in的参数
    CUTIN_LONGITUDINAL_RANGE_FRONT = 20.0   # meters, 角点前方纵向检测距离
    CUTIN_LONGITUDINAL_RANGE_REAR = 2.0     # meters, 角点后方纵向检测距离
    CUTIN_CENTER_LATERAL_MIN = 1.0          # meters, 中心横向最小距离（排除同车道目标）
    CUTIN_CENTER_LATERAL_MAX = 6.0          # meters, 中心横向最大距离（排除过远目标）
    CUTIN_CORNER_LATERAL_MAX = 3.0          # meters, 角点距离自车中心的最大横向距离（约半个车道宽）
    CUTIN_HEADING_DIFF_MAX = 30.0           # degrees, 最大航向角差异（同向行驶）
    CUTIN_LATERAL_VEL_THRESHOLD = 0.1       # m/s, 横向切入速度阈值
    CUTIN_TTC_THRESHOLD = 3.0               # seconds, cut-in碰撞时间阈值
    # cross thresholds
    CROSS_CENTER_LATERAL_MAX = 6.0          # meters, 中心横向最大距离（排除过远目标）
    CROSS_LONGITUDINAL_RANGE_FRONT = 20.0   # meters, 角点前方纵向检测距离
    CROSS_LONGITUDINAL_RANGE_REAR = 2.0     # meters, 角点后方纵向检测距离
    CROSS_CORNER_LATERAL_MAX = 6.0          # meters, 角点距离自车中心的最大横向距离（约半个车道宽）
    CROSS_HEADING_DIFF_MAX = 120.0          # degrees, 最大航向角差异（横向行驶）
    CROSS_HEADING_DIFF_MIN = 30.0           # degrees, 最小航向角差异（横向行驶）
    CROSS_TTC_THRESHOLD = 3.0               # seconds, cross碰撞时间阈值

    LATITUDE_LABEL_NUM = 8
    LATITUDE_LABELS_MAP = {
        -3: 0,
        -2: 1,
        -1: 2,
        0: 3,
        1: 4,
        2: 5,
        3: 6,
        4: 7,
    }

    # longitudinal status labels - 简化为四类
    LABEL_NO_RISK = 0                # 无碰撞风险
    LABEL_RISK = 1                   # 有碰撞风险（包含前方和侧方）
    LABEL_DECEL = 2                   # 需要刹停，没有用
    LABEL_ONCOMING_RISK = 3          # 对向来车碰撞风险
    LABEL_CUTIN_RISK = 4             # Cut-in碰撞风险
    LABEL_CROSS_RISK = 5             # Cross碰撞风险

    LONGITUDE_LABEL_NUM = 6
    LONGITUDE_LABELS_MAP = {
        0: 0,  # 无风险
        1: 1,  # 有碰撞风险
        2: 2,  # 需要刹停，优先级高于碰撞风险
        3: 3,  # 对向来车碰撞
        4: 4,  # Cut-in碰撞风险
        5: 5,  # Cross碰撞风险
    }


    # Thresholds for deceleration detection
    DECEL_TIME_WINDOW = 3.0          # seconds, 时间窗口
    DECEL_SPEED_THRESHOLD = 1.0      # m/s, 速度阈值
    DECEL_FRONT_DISTANCE = 20.0      # meters, 前方检测距离

    # Vehicle class IDs (car, truck, bus, etc.)
    VEHICLE_CLASS_IDS = [100, 101, 102, 103, 104, 200, 201, 202, 203, 204]

    # VRU class IDs (pedestrian, bike, etc.)
    # 根据实际情况调整这些ID
    VRU_CLASS_IDS = [300, 400, 401, 402, 403, 410, 411, 412, 413, 500, 501, 502]  # pedestrian, bike, etc.

    def __init__(self, data: dict, clip_id: str, enable_viz: bool = False):
        """
        Args:
            data (dict): 包含时间戳和动态物体信息的数据
            clip_id (str): 片段ID
            enable_viz (bool): 是否启用可视化
        """
        self.fps = 5
        self.data = data
        self.clip_id = clip_id
        self.enable_viz = enable_viz
        self.step_size = 0.5  # meters
        self.window_m = 10
        self.viz = SimpleViz(clip_id)

    def _is_vehicle(self, obj_class: int) -> bool:
        """判断物体是否为车辆."""
        return obj_class in self.VEHICLE_CLASS_IDS

    def _is_vru(self, obj_class: int) -> bool:
        """判断物体是否为VRU（易受伤害道路使用者）."""
        return obj_class in self.VRU_CLASS_IDS

    def _is_ped(self, obj_class: int) -> bool:
        return obj_class >= 500

    def _should_detect_collision(self, obj_class: int) -> bool:
        """判断是否需要检测与该物体的碰撞（车辆或VRU）."""
        return self._is_vehicle(obj_class) or self._is_vru(obj_class)

    def _has_vru_or_vehicle_ahead(
        self,
        ego_center: np.ndarray,
        ego_yaw: float,
        dobjs: np.ndarray,
        dobjs_polygons: np.ndarray
    ) -> bool:
        """
        检查自车前方是否有VRU或车辆.

        Args:
            ego_center: 自车中心 (2,)
            ego_yaw: 自车航向角 (deg)
            dobjs: 动态物体数组 (N, 12)
            dobjs_polygons: 动态物体多边形 (N, 4, 2)

        Returns:
            bool: 前方是否有VRU或车辆
        """
        for i, (dobj, obj_polygon) in enumerate(zip(dobjs, dobjs_polygons)):
            obj_class = int(dobj[7])
            # 只检测车辆和VRU
            if not self._should_detect_collision(obj_class):
                continue

            obj_center = obj_polygon.mean(axis=0)
            distance = self._calculate_distance(ego_center, obj_center)

            # 只考虑一定距离内的物体
            if distance > self.DECEL_FRONT_DISTANCE:
                continue

            # 获取障碍物yaw角: dobj格式 [x, y, z, l, w, h, yaw, class_id, ...]
            obj_yaw = dobj[6] if len(dobj) >= 7 else 0.0
            obj_yaw = np.degrees(obj_yaw)

            # 计算相对于自车的角度
            angle_to_obj = self._calculate_angle_to_object(ego_center, ego_yaw, obj_center)

            # 判断是否在前方（-60度到60度之间）
            if angle_to_obj <= 60.0:
                return True

        return False

    def _check_deceleration_to_slow_speed(
        self,
        current_idx: int,
        timestamps: List[float],
        ego_motions_list: List[np.ndarray]
    ) -> bool:
        """
        检查自车是否会在3秒内减速到1m/s以下.

        Args:
            current_idx: 当前时间戳索引
            timestamps: 时间戳列表
            ego_motions_list: 自车运动信息列表

        Returns:
            bool: 是否会在3秒内减速到1m/s以下
        """
        if current_idx >= len(timestamps):
            return False

        current_ts = timestamps[current_idx]
        current_speed = np.linalg.norm(ego_motions_list[current_idx][:2])

        # 如果当前速度已经在1m/s以下，返回False（不需要再减速）
        if current_speed < self.DECEL_SPEED_THRESHOLD:
            return False

        # 计算3秒后的时间戳
        target_ts = current_ts + self.DECEL_TIME_WINDOW

        # 查找3秒后的索引
        future_idx = current_idx + 15
        future_idx = min(future_idx, len(timestamps)-1)
        # 如果没有足够的未来数据
        if future_idx <= current_idx:
            return False

        # 检查未来3秒内的速度
        for i in range(current_idx + 1, future_idx + 1):
            speed = np.linalg.norm(ego_motions_list[i][:2])
            if speed < self.DECEL_SPEED_THRESHOLD:
                return True

        return False

    def _check_hump(self, yaw_rate, N, start_idx):
        i = start_idx
        hump_direction = np.sign(yaw_rate[i])
        while i < N and abs(yaw_rate[i]) >= self.THRE_NUDGE_LOWER:
            i += 1

        if i >= N:
            return False, N, hump_direction
        else:
            return True, i, hump_direction

    def _check_nudge(self, yaw_rate, timestamps, clip_motion_status):
        yaw_rate = smooth_signal(yaw_rate, window=3)

        i = 0
        N = len(timestamps)
        last_hump = None # {"start_idx": int, "end_idx": int, "direction": int}
        while i < N:
            # 进入候选段
            if abs(yaw_rate[i]) > self.THRE_NUDGE_UPPDER:
                hump_start_idx = i
                is_hump, hump_end_idx, hump_dir = self._check_hump(yaw_rate, N, i)

                i = hump_end_idx

                if is_hump:
                    cur_hump = {"start_idx": hump_start_idx, "end_idx": hump_end_idx, "direction": hump_dir}

                    # 检查 hump 队列，并且与当前 hump 方向相反，距离接近
                    if last_hump:
                        last_hump_idx = last_hump['end_idx']
                        last_hump_dir = last_hump['direction']
                        if last_hump_dir == -hump_dir:
                            # check distance
                            time_dist = (hump_start_idx - last_hump_idx) / self.fps
                            if time_dist <= self.THRE_NUDGE_HUMP_DIST:  # seconds
                                # confirm nudge, set with the last hump start_idx to current hump end_idx
                                nudge_label = -4 if last_hump['direction'] == -1 else 4
                                # no other lateral action in between
                                has_other_action = False
                                for j in range(last_hump["start_idx"], cur_hump["end_idx"]):
                                    if clip_motion_status[j]['lateral'] != 0:
                                        has_other_action = True
                                        break
                                if has_other_action:
                                    # reset
                                    last_hump = None
                                else:
                                    for j in range(last_hump["start_idx"], cur_hump["end_idx"]):
                                        clip_motion_status[j]['lateral'] = nudge_label
                                i = hump_end_idx
                            else:
                                # reset
                                last_hump = cur_hump
                        else:
                            # reset
                            last_hump = cur_hump
            else:
                i += 1


        return clip_motion_status

    def _expand_lane_change_by_peaks(self, clip_motion_status):
        """
        变道标签更新函数
        """
        N = len(clip_motion_status)

        raw_dists = np.array([s.get('closest_lane_dist', 10.0) for s in clip_motion_status])
        dists = smooth_signal(raw_dists, window=3)

        original_labels = np.array([s['lateral'] for s in clip_motion_status])

        # 获取锚点，靠之前的逻辑判断到压线点之后进行扩展更新
        anchor_indices = np.where((np.abs(original_labels) == self.LABEL_LANE_CHANGE))[0]

        if len(anchor_indices) == 0:
            return clip_motion_status

        new_labels = np.zeros(N, dtype=int)
        processed_mask = np.zeros(N, dtype=bool)

        for idx in anchor_indices:
            if processed_mask[idx]:
                continue

            action_type = original_labels[idx]

            # 搜索极大值函数
            def find_peak(start_idx, step):
                """
                通用搜索函数
                step: -1 代表向前搜索, 1 代表向后搜索
                """
                curr = start_idx
                best_peak_idx = start_idx
                best_peak_val = dists[start_idx]
                patience_counter = 0

                # 限制搜索步数
                for _ in range(self.MAX_SEARCH_FRAMES):
                    next_idx = curr + step

                    # 边界检查
                    if next_idx < 0 or next_idx >= N:
                        break

                    # 遇到高优先级动作(转弯)，立即截断
                    if abs(original_labels[next_idx]) not in [self.LABEL_KEEP, self.LABEL_LANE_CHANGE]:
                        break

                    val = dists[next_idx]

                    # 逻辑：我们在寻找极大值
                    if val > best_peak_val:
                        # 发现新高，更新波峰，重置耐心
                        best_peak_val = val
                        best_peak_idx = next_idx
                        patience_counter = 0
                    else:
                        # 距离不再增加，消耗耐心
                        patience_counter += 1

                    # 如果连续 N 帧没有创新高，且距离已经呈下降趋势，则停止
                    if patience_counter > self.PATIENCE:
                        break

                    curr = next_idx

                return best_peak_idx, best_peak_val

            # 向前找起点
            t_start, peak_val_start = find_peak(idx, -1)
            # 向后找终点
            t_end, peak_val_end = find_peak(idx, 1)

            # 保证变道幅度
            is_valid_amplitude = (peak_val_start > self.MIN_PEAK_DIST) or (peak_val_end > self.MIN_PEAK_DIST)

            # 保证持续时间
            is_valid_duration = (t_end - t_start) >= self.MIN_DURATION

            if is_valid_amplitude and is_valid_duration:
                # 标记区间
                for i in range(t_start, t_end + 1):
                    # 保护转弯不被覆盖
                    if abs(original_labels[i]) in [self.LABEL_KEEP, self.LABEL_LANE_CHANGE]:
                        new_labels[i] = action_type
                        processed_mask[i] = True
            else:
                # TODO: process invalid cases
                pass

        # === 更新状态 ===
        for i in range(N):
            if abs(original_labels[i]) not in [self.LABEL_KEEP, self.LABEL_LANE_CHANGE]:
                continue
            clip_motion_status[i]['lateral'] = int(new_labels[i])

        return clip_motion_status

    def _compute_centering_status(self, initpose, egocenter_pose, timestamps, ts_lane_lines_dict, label_status_list, dataset_kwargs: dict):
        """计算居中动作标签（动作标签：表达意图而非状态）。

        当前逻辑（动作标签）：综合判断三个信号，确认"正在向中心修正"：
            1. 当前偏位（左右距离差超过阈值）
            2. 未来 3s 内偏移量呈下降趋势
            → 两个条件同时满足才标记 CENTERING，确保标签纯净。
        """
        center = np.array([0, 0])
        origin_yaw = 0
        future_frames = int(3.0 * self.fps)  # 看未来 3s

        def _calc_lateral_offset(ego_pose, lane_lines):
            """计算自车相对于车道中心的横向偏移。
            Returns:
                tuple: (offset, valid)
                    - offset (float): min_left_dist - min_right_dist。
                      正 = 偏右（离左边远、离右边近），负 = 偏左。
                    - valid (bool): 是否成功获取左右车道线距离。
            """
            ego_pos = ego_pose[:2, 3]
            ego_yaw = np.arctan2(ego_pose[1, 0], ego_pose[0, 0])

            min_left_dist = float('inf')
            min_right_dist = float('inf')

            for _line in lane_lines:
                if len(_line[0]) <= 2:
                    continue
                try:
                    lane_line = LineString(_line[0])
                    nearest_pt = lane_line.interpolate(lane_line.project(Point(ego_pos)))
                    nearest_pt_coords = np.array(nearest_pt.coords[0][:2])
                    vec_to_lane = nearest_pt_coords - ego_pos
                    ego_forward = np.array([np.cos(ego_yaw), np.sin(ego_yaw)])
                    cross_val = ego_forward[0] * vec_to_lane[1] - ego_forward[1] * vec_to_lane[0]
                    dist = np.linalg.norm(vec_to_lane)
                    if cross_val > 0:  # 左侧车道线
                        if dist < min_left_dist:
                            min_left_dist = dist
                    else:  # 右侧车道线
                        if dist < min_right_dist:
                            min_right_dist = dist
                except Exception:
                    continue

            if min_left_dist == float('inf') or min_right_dist == float('inf'):
                return 0.0, False

            offset = min_left_dist - min_right_dist
            return offset, True

        for i in range(len(label_status_list)):
            # 只处理 lateral status 为 0 的帧（其他动作优先级更高）
            if label_status_list[i]['lateral'] != 0:
                continue

            # 获取当前帧横向偏移
            ts = timestamps[i]
            ego_pose_backwheel = initpose @ self.data[ts]["car_pose"]
            lane_lines = ts_lane_lines_dict[ts]
            # lane_lines = self._parse_frame_env(
            #     self.data[ts], ego_pose_backwheel, center, origin_yaw, **dataset_kwargs
            # )
            offset_now, valid_now = _calc_lateral_offset(egocenter_pose[i], lane_lines)
            if not valid_now or abs(offset_now) < self.THRE_CENTERED_DIST_DIFF:
                continue  # 已在中心或车道线不完整

            future_idx = min(i + future_frames, len(label_status_list) - 1)
            future_ts = timestamps[future_idx]
            future_ego_pose_backwheel = initpose @ self.data[future_ts]["car_pose"]
            future_lane_lines = ts_lane_lines_dict[future_ts]
            # future_lane_lines = self._parse_frame_env(
            #     self.data[future_ts], future_ego_pose_backwheel, center, origin_yaw, **dataset_kwargs
            # )
            offset_future, valid_future = _calc_lateral_offset(
                egocenter_pose[future_idx], future_lane_lines
            )
            if not valid_future:
                continue
            if abs(offset_future) < abs(offset_now) * 0.9:
                label_status_list[i]['lateral'] = self.LABEL_LANE_CENTERING
            # 否则保持 0（虽然偏了且打了方向，但偏移量没显著减小）

        return label_status_list

    def _parse_frame_env(self, frame, T, center, original_yaw, **kwargs):

        lanes = frame["manner_lane_points"]
        types = frame["manner_lane_types"]
        attrs = frame["manner_lane_attr"]

        areazones = frame.get("road_zones", [])
        wm_stoplines = frame.get("wm_stoplines", [])

        # easy way to remove duplicate lanes
        hash_value = [l.sum() + t + a.sum() for l, t, a in zip(lanes, types, attrs)]
        filter_idx = np.unique(hash_value, return_index=True)[1]
        filter_idx = sorted(filter_idx)
        lanes = [lanes[i] for i in filter_idx]
        types = [types[i] for i in filter_idx]
        attrs = [attrs[i] for i in filter_idx]
        road_sign, lane_lines, road_edge, nomap_road_edge, stop_line, tld, navi_path = [], [], [], [], [], 4, None
        road_edge_vis, etc_road_sign = [], []
        spd_limit = frame["speed_limit"]

        near_etc_gate = False
        for p, t, a in zip(lanes, types, attrs):
            """
            p为N个点坐标(x, y): N * 2
            t为整条lane的类型:  1
            a为每个point的类型: N * 2
            """
            x_length = np.max(p[:, 0]) - np.min(p[:, 0])
            y_length = np.max(p[:, 1]) - np.min(p[:, 1])
            # 对齐全部数据到新坐标系
            p = ego2global(p, T)

            if t == 0:  # lane_line
                lane_lines.append([p, a])
        return lane_lines

    def _calculate_distance(self, ego_center: np.ndarray, obj_center: np.ndarray) -> float:
        """计算两个中心点之间的欧氏距离."""
        return np.linalg.norm(ego_center - obj_center)

    def _calculate_relative_angle(self, ego_yaw: float, obj_yaw: float) -> float:
        """
        计算障碍物相对于自车的角度.

        Args:
            ego_yaw: 自车航向角 (radians)
            obj_yaw: 障碍物航向角 (radians)

        Returns:
            float: 相对角度 (degrees), 范围[0, 180]
        """
        # relative_angle = np.degrees(obj_yaw - ego_yaw)
        relative_angle = obj_yaw - ego_yaw
        relative_angle = (relative_angle + 180) % 360 - 180

        return abs(relative_angle)

    def _calculate_angle_to_object(self, ego_center: np.ndarray, ego_yaw: float, obj_center: np.ndarray) -> float:
        """
        计算障碍物中心相对于自车朝向的角度.

        Args:
            ego_center: 自车中心 (2,)
            ego_yaw: 自车航向角 (deg)
            obj_center: 障碍物中心 (2,)

        Returns:
            float: 角度 (degrees), 范围[0, 180]
        """
        vec_to_obj = obj_center - ego_center
        angle_to_obj = np.arctan2(vec_to_obj[1], vec_to_obj[0])

        relative_angle = np.degrees(angle_to_obj) - ego_yaw
        relative_angle = (relative_angle + 180) % 360 - 180

        return abs(relative_angle)

    def _calculate_time_to_collision(
        self,
        ego_center: np.ndarray,
        ego_vel: np.ndarray,
        obj_center: np.ndarray,
        obj_vel: np.ndarray
    ) -> float:
        """
        计算碰撞时间 (TTC).

        Args:
            ego_center: 自车中心 (2,)
            ego_vel: 自车速度 (2,)
            obj_center: 障碍物中心 (2,)
            obj_vel: 障碍物速度 (2,)

        Returns:
            float: 碰撞时间 (seconds), 如果不会碰撞返回inf
        """
        relative_pos = obj_center - ego_center
        relative_vel = obj_vel - ego_vel

        vel_norm_sq = np.dot(relative_vel, relative_vel)
        if vel_norm_sq < 1e-6:
            return float('inf')

        ttc = -np.dot(relative_pos, relative_vel) / vel_norm_sq

        if ttc < 0:
            return float('inf')

        return ttc

    def _calculate_relative_speed_longitudinal(
        self,
        ego_vel: np.ndarray,
        obj_vel: np.ndarray,
        relative_pos: np.ndarray
    ) -> float:
        """计算纵向相对速度(沿两车间连线方向)."""
        if np.linalg.norm(relative_pos) < 1e-6:
            return 0.0

        direction = relative_pos / np.linalg.norm(relative_pos)
        relative_vel = obj_vel - ego_vel
        # return np.dot(relative_vel, direction)
        return relative_vel

    def _check_front_risk(
        self,
        distance: float,
        relative_pos: np.ndarray,
        relative_angle: float,
        ttc: float,
        relative_speed: np.ndarray,
        obj_vel: np.ndarray
    ) -> bool:
        """
        检查是否有前方碰撞风险.

        判断条件:
        1. 在检测范围内且角度符合前方条件
        2. TTC小于阈值(正在接近)
        3. 距离小于安全距离 或 相对速度为负(正在接近)
        """
        # if distance > self.FRONT_RISK_DISTANCE:
        #     return False
        # if relative_angle > self.FRONT_ANGLE_THRESHOLD_1 and relative_angle < self.FRONT_ANGLE_THRESHOLD_2:
        #     return False
        # if relative_angle > self.FRONT_ANGLE_THRESHOLD_3:
        #     return False
        obj_speed = np.linalg.norm(obj_vel)
        relative_vel = np.sign(relative_speed[0]) * np.linalg.norm(relative_speed)
        # 如果TTC有效且小于阈值,说明有碰撞风险
        if ttc < self.TTC_FRONT_THRESHOLD and abs(relative_pos[1]) < 2.0:
            return True

        # 如果距离已经很近
        if distance < self.DISTANCE_RISK_DISTANCE and obj_speed > 0.3:
            # 检查是否在接近(相对速度为负表示距离在减小)
            if relative_vel < -self.RELATIVE_SPEED_THRESHOLD:
                return True

        return False

    def _check_side_risk(
        self,
        distance: float,
        relative_angle: float,
        ttc: float,
        relative_speed: float,
        ego_vel: np.ndarray,
        obj_vel: np.ndarray
    ) -> bool:
        """
        检查是否有侧方碰撞风险.

        判断条件:
        1. 在检测范围内
        2. 角度在侧方范围内(30-150度)
        3. TTC小于阈值 或 距离小于安全距离且有接近趋势
        """
        if distance > self.SIDE_RISK_DISTANCE:
            return False
        if relative_angle < self.SIDE_ANGLE_THRESHOLD_MIN or relative_angle > self.SIDE_ANGLE_THRESHOLD_MAX:
            return False
        obj_speed = np.linalg.norm(obj_vel)
        # 如果TTC有效且小于阈值
        if ttc < self.TTC_SIDE_THRESHOLD and obj_speed > 0.3:
            return True

        # 如果距离较近且有接近趋势
        if distance < self.SAFETY_DISTANCE_SIDE:
            if relative_speed < -self.RELATIVE_SPEED_THRESHOLD:
                return True

            # 检查横向接近速度
            ego_speed = np.linalg.norm(ego_vel)

            if ego_speed > 1.0 and obj_speed > 1.0:
                # 两车都有速度,检查是否有交叉路径
                return True

        return False

    def _detect_collision_risk_at_timestamp(
        self,
        ego_pose: np.ndarray,
        ego_polygon: np.ndarray,
        ego_motion: np.ndarray,
        dobjs: np.ndarray,
        dobjs_polygons: np.ndarray
    ) -> int:
        """
        在某一时间戳检测碰撞风险.

        Args:
            ego_pose: 自车位姿 (4, 4)
            ego_polygon: 自车多边形 (4, 2)
            ego_motion: 自车运动信息
            dobjs: 动态物体数组 (N, 12)
            dobjs_polygons: 动态物体多边形 (N, 4, 2)

        Returns:
            int: 碰撞风险标签
        """
        ego_center = ego_polygon.mean(axis=0)
        # 获取自车速度和yaw角: ego_motion格式 [vx, vy, acc_x, acc_y, yaw, yaw_rate, ...]
        ego_vel = ego_motion[0:2] if len(ego_motion) >= 2 else np.array([0.0, 0.0])
        ego_yaw = ego_motion[4] if len(ego_motion) >= 5 else 0.0

        has_front_risk = False
        has_side_risk = False

        for i, (dobj, obj_polygon) in enumerate(zip(dobjs, dobjs_polygons)):
            # 检测车辆和VRU（易受伤害道路使用者）
            obj_class = int(dobj[7])
            # if not self._should_detect_collision(obj_class):
            #     continue

            obj_center = obj_polygon.mean(axis=0)
            distance = self._calculate_distance(ego_center, obj_center)

            # 获取障碍物yaw角: dobj格式 [x, y, z, l, w, h, yaw, class_id, ...]
            obj_yaw = dobj[6] if len(dobj) >= 7 else 0.0
            obj_yaw = np.degrees(obj_yaw)

            # 计算障碍物相对于自车的角度
            relative_angle = self._calculate_angle_to_object(ego_center, ego_yaw, obj_center)
            # relative_angle = self._calculate_relative_angle(ego_yaw, obj_yaw)

            # 获取障碍物速度: dobj格式 [... , vx, vy, ...]
            obj_vel = dobj[10:12] if len(dobj) >= 12 else np.array([0.0, 0.0])

            # 计算TTC
            ttc = self._calculate_time_to_collision(ego_center, ego_vel, obj_center, obj_vel)

            # 计算相对位置向量
            relative_pos = obj_center - ego_center

            # 计算纵向相对速度
            relative_speed = self._calculate_relative_speed_longitudinal(ego_vel, obj_vel, relative_pos)

            if relative_pos[0] <= 0:
                continue

            # if relative_pos[0] > 0 and obj_vel[0] < 0 and relative_pos[0] < 15 and relative_angle < 90:
            #     print("debug2")

            # 检查前方风险
            if not has_front_risk:
                has_front_risk = self._check_front_risk(
                    distance, relative_pos, relative_angle, ttc, relative_speed, obj_vel
                )

            # # 检查侧方风险
            # if not has_side_risk:
            #     has_side_risk = self._check_side_risk(
            #         distance, relative_angle, ttc, relative_speed, ego_vel, obj_vel
            #     )

            # 如果检测到任何风险(前方或侧方),统一返回有风险
            if has_front_risk or has_side_risk:
                return self.LABEL_RISK

        return self.LABEL_NO_RISK


    def _calculate_relative_angle_oncoming(self, ego_yaw: float, obj_yaw: float) -> float:
        """
        计算障碍物相对于自车的角度.

        Args:
            ego_yaw: 自车航向角 (radians)
            obj_yaw: 障碍物航向角 (radians)

        Returns:
            float: 相对角度 (degrees), 范围[0, 360]
        """
        relative_angle = np.degrees(obj_yaw - ego_yaw)
        relative_angle = (relative_angle if relative_angle > 0 else (relative_angle + 360)) % 360

        return relative_angle

    def _is_outside_road_edge(self, ego_center: np.ndarray, obj_center: np.ndarray, road_edge: list) -> bool:
        """
        判断车辆是否在路沿外.

        Args:
            ego_center: 自车中心 (2,)
            obj_center: 障碍物中心 (2,)
            road_edge: 路沿信息列表

        Returns:
            bool: 是否在路沿外
        """

        # 检查车辆是否在路沿内
        for edge in road_edge:
            if len(edge) >= 3:
                edge_polyline = LineString(edge[:, :2])
                ego_obj_polyline = LineString([ego_center, obj_center])
                if edge_polyline.intersects(ego_obj_polyline):
                    return True

        return False

    def _is_outside_solid_lane(self, ego_center: np.ndarray, obj_center: np.ndarray, lane_lines: list) -> bool:
        """
        判断车辆是否在实线车道外.

        Args:
            ego_center: 自车中心 (2,)
            obj_center: 障碍物中心 (2,)
            lane_lines: 车道线信息列表, solid lane lines {1, 5, 7, 10, 11, 100}

        Returns:
            bool: 是否在实线车道外
        """
        # 实线类型：1表示实线
        solid_line_types = [1, 5, 7, 10, 11, 100]

        # 检查车辆是否在实线车道内
        for line_points, line_attrs in lane_lines:
            if len(line_attrs) >= 2:
                # solid_lane_line = []
                # for index, attr in enumerate(line_attrs):
                #     line_type = attr[0]
                #     if line_type in solid_line_types:
                #         solid_lane_line.append(line_points[index])
                solid_lane_line = line_points
                if len(solid_lane_line) > 2:
                    lane_polyline = LineString([point[:2] for point in solid_lane_line])
                    ego_obj_polyline = LineString([ego_center, obj_center])
                    if lane_polyline.intersects(ego_obj_polyline):
                        return True
        return False

    def _is_oncoming_vehicle(self,
                             ego_yaw: float,
                             obj_yaw: float,
                             obj_center: np.ndarray,
                             ego_center: np.ndarray,
                             obj_polygon,
                             ego_polygon,
                             road_edge: list = None,
                             lane_lines: list = None) -> bool:
        """
        判断目标是否为对向来车.

        Args:
            ego_yaw: 自车航向角 (radians)
            obj_yaw: 障碍物航向角 (radians)
            obj_center: 障碍物中心 (2,)
            ego_center: 自车中心 (2,)
            road_edge: 路沿信息列表
            lane_lines: 车道线信息列表

        Returns:
            bool: 是否为对向来车
        """
        # 计算相对角度
        relative_angle = self._calculate_relative_angle_oncoming(ego_yaw, obj_yaw)

        # 检查角度是否在对向来车范围内(120-240度)
        if not (self.ONCOMING_ANGLE_THRESHOLD_MIN <= relative_angle <= self.ONCOMING_ANGLE_THRESHOLD_MAX):
            return False

        # 计算障碍物相对于自车的方向向量
        vec_to_obj = obj_center - ego_center
        angle_to_obj = np.arctan2(vec_to_obj[1], vec_to_obj[0])

        # 检查障碍物是否在自车的前方区域
        relative_angle_to_obj = np.degrees(angle_to_obj) - np.degrees(ego_yaw)
        relative_angle_to_obj = (relative_angle_to_obj if relative_angle_to_obj > 0 else (relative_angle_to_obj + 360)) % 360
        if not (relative_angle_to_obj < 90 or relative_angle_to_obj > 270):
            return False

        # 检查车辆是否在路沿外
        min_distance = float('inf')
        for obj_corner in obj_polygon:
            for ego_corner in ego_polygon:
                distance = np.linalg.norm(obj_corner - ego_corner)
                if distance < min_distance:
                    min_distance = distance
                    nearest_obj_corner = obj_corner
                    nearest_ego_corner = ego_corner

        if road_edge and self._is_outside_road_edge(nearest_ego_corner, nearest_obj_corner, road_edge):
            return False

        # 检查车辆是否在实线车道外
        if lane_lines and self._is_outside_solid_lane(nearest_ego_corner, nearest_obj_corner, lane_lines):
            return False

        return True

    def _calculate_angle_to_object_oncoming(self, ego_center: np.ndarray, ego_yaw: float, obj_center: np.ndarray) -> float:
        """
        计算障碍物中心相对于自车朝向的角度.

        Args:
            ego_center: 自车中心 (2,)
            ego_yaw: 自车航向角 (radians)
            obj_center: 障碍物中心 (2,)

        Returns:
            float: 角度 (degrees), 范围[0, 360]
        """
        vec_to_obj = obj_center - ego_center
        angle_to_obj = np.arctan2(vec_to_obj[1], vec_to_obj[0])

        relative_angle = np.degrees(angle_to_obj - ego_yaw)
        relative_angle = (relative_angle if relative_angle > 0 else (relative_angle + 360)) % 360

        return relative_angle

    def _calculate_time_to_collision_oncoming(
        self,
        ego_center: np.ndarray,
        ego_vel: np.ndarray,
        ego_polygon: np.ndarray,
        obj_center: np.ndarray,
        obj_vel: np.ndarray,
        obj_polygon: np.ndarray
    ) -> float:
        """
        计算碰撞时间 (TTC)，考虑车辆尺寸和横纵向位移.

        Args:
            ego_center: 自车中心 (2,)
            ego_vel: 自车速度 (2,)
            ego_polygon: 自车多边形 (4, 2)
            obj_center: 障碍物中心 (2,)
            obj_vel: 障碍物速度 (2,)
            obj_polygon: 障碍物多边形 (4, 2)

        Returns:
            float: 碰撞时间 (seconds), 如果不会碰撞返回inf
        """
        relative_pos = obj_center - ego_center
        relative_vel = obj_vel - ego_vel

        vel_norm_sq = np.dot(relative_vel, relative_vel)
        if vel_norm_sq < 1e-6:
            return float('inf')

        # 计算基于中心点的TTC
        ttc_center = -np.dot(relative_pos, relative_vel) / vel_norm_sq

        if ttc_center < 0 or ttc_center > 4:
            return float('inf')

        # 考虑车辆尺寸，计算实际碰撞时间
        # 计算车辆的边界框

        # 计算最小碰撞时间
        min_ttc = float('inf')
        # 检查不同时间点的碰撞可能性
        for t in np.arange(0.6 * ttc_center, ttc_center * 1.4, 0.1):
            # 计算未来位置
            ego_future_polygon = ego_polygon + ego_vel * t
            obj_future_polygon = obj_polygon + obj_vel * t

            # 检查边界框是否重叠
            shapely_ego_polygon = Polygon(ego_future_polygon)
            shapely_obj_polygon = Polygon(obj_future_polygon)
            if np.hypot(relative_vel[0], relative_vel[1]) > 10:
                safe_buffer = 0.4
            else:
                safe_buffer = 0.04 * np.hypot(relative_vel[0], relative_vel[1])
            expanded_ego_polygon = shapely_ego_polygon.buffer(safe_buffer)
            expanded_obj_polygon = shapely_obj_polygon.buffer(safe_buffer)
            if expanded_ego_polygon.intersects(expanded_obj_polygon):
                min_ttc = t
                break

        if min_ttc < float('inf'):
            return min_ttc

        return float('inf')


    def _calculate_time_to_collision_cutin(
        self,
        ego_center: np.ndarray,
        ego_vel: np.ndarray,
        ego_polygon: np.ndarray,
        obj_center: np.ndarray,
        obj_vel: np.ndarray,
        obj_polygon: np.ndarray,
    ) -> float:
        """
        计算碰撞时间 (TTC)，考虑车辆尺寸和横纵向位移.

        Args:
            ego_center: 自车中心 (2,)
            ego_vel: 自车速度 (2,)
            ego_polygon: 自车多边形 (4, 2)
            obj_center: 障碍物中心 (2,)
            obj_vel: 障碍物速度 (2,)
            obj_polygon: 障碍物多边形 (4, 2)

        Returns:
            float: 碰撞时间 (seconds), 如果不会碰撞返回inf
        """
        relative_pos = obj_center - ego_center
        relative_vel = obj_vel - ego_vel

        vel_norm_sq = np.dot(relative_vel, relative_vel)
        if vel_norm_sq < 1e-6:
            return float('inf')

        # 计算基于中心点的TTC
        ttc_center = -np.dot(relative_pos, relative_vel) / vel_norm_sq

        if ttc_center < 0:
            return float('inf')

        # 考虑车辆尺寸，计算实际碰撞时间
        # 计算车辆的边界框

        # 计算最小碰撞时间
        min_ttc = float('inf')
        if ttc_center > self.CUTIN_TTC_THRESHOLD:
            check_range = np.arange(0, self.CUTIN_TTC_THRESHOLD + 0.1, 0.1)
        else:
            check_range = np.arange(0.6 * ttc_center, ttc_center * 1.4, 0.1)
        # 检查不同时间点的碰撞可能性
        for t in check_range:
            # 计算未来位置
            ego_future_polygon = ego_polygon + ego_vel * t
            obj_future_polygon = obj_polygon + obj_vel * t

            # 检查边界框是否重叠
            shapely_ego_polygon = Polygon(ego_future_polygon)
            shapely_obj_polygon = Polygon(obj_future_polygon)
            if np.hypot(relative_vel[0], relative_vel[1]) > 10:
                safe_buffer = 0.4
            else:
                safe_buffer = 0.04 * np.hypot(relative_vel[0], relative_vel[1])
            expanded_ego_polygon = shapely_ego_polygon.buffer(safe_buffer)
            expanded_obj_polygon = shapely_obj_polygon.buffer(safe_buffer)
            if expanded_ego_polygon.intersects(expanded_obj_polygon):
                min_ttc = t
                break

        if min_ttc < float('inf'):
            return min_ttc

        return float('inf')


    def is_polyline_turning_by_direction(self, polyline, total_angle_threshold=0.9):
        """
        根据方向变化累积判断 polyline 是否拐弯

        Args:
            polyline: np.array, 折线点序列，shape (N, 2)
            total_angle_threshold: float, 总方向变化阈值（度）

        Returns:
            bool, 是否拐弯
            float, 总方向变化角度
        """
        if len(polyline) < 3:
            return False, 0.0

        total_angle_change = 0.0
        prev_direction = None

        for i in range(1, len(polyline)):
            # 计算当前段的方向
            direction = polyline[i] - polyline[i - 1]

            if np.linalg.norm(direction) == 0:
                continue

            direction = direction / np.linalg.norm(direction)  # 归一化

            if prev_direction is not None:
                # 计算方向变化角度
                dot_product = np.dot(prev_direction, direction)
                dot_product = np.clip(dot_product, -1, 1)
                angle_change = np.degrees(np.arccos(dot_product))

                total_angle_change += angle_change

            prev_direction = direction

        return total_angle_change > total_angle_threshold, total_angle_change

    def _cal_pos_when_turn(self, ego_polygon, current_vel, trajectory, t):
        """
        使用 shapely 库计算沿轨迹的位置（自车是多边形）

        Args:
            ego_polygon: np.array 或 list，自车多边形的顶点坐标，shape (4, 2)
            current_vel: float, 当前速度 (m/s)
            trajectory: np.array 或 list, 轨迹点序列，shape (N, 2)
            t: float, 时间 (s)

        Returns:
            tuple, t 时刻后的位置 (x, y) 和朝向角
        """
        def calculate_yaw_from_polygon(polygon):
            """
            从多边形计算自车的朝向角

            Args:
                polygon: np.array, 多边形顶点坐标，shape (4, 2)

            Returns:
                float, 朝向角（弧度）
            """
            # 假设多边形的前两个点定义了车头方向
            # 计算从后中心点到前中心点的向量
            front_center = (polygon[0] + polygon[3]) / 2  # 前两个顶点的中点
            rear_center = (polygon[1] + polygon[2]) / 2  # 后两个顶点的中点

            direction_vec = front_center - rear_center
            yaw = np.arctan2(direction_vec[1], direction_vec[0])

            return yaw


        # 1. 创建轨迹线
        line = LineString(trajectory)

        # 2. 计算行驶距离
        target_distance = np.hypot(current_vel[0], current_vel[1]) * t

        # 7. 处理边界情况
        if target_distance <= 0:
            target_pos = np.array(line.coords[0])
        elif target_distance >= line.length:
            target_pos = np.array(line.coords[-1])
        else:
            # 在轨迹上插值找到目标位置
            target_point = line.interpolate(target_distance)
            target_pos = np.array([target_point.x, target_point.y])

        # 8. 计算轨迹切线方向（作为自车新的朝向）
        # 找到目标位置所在的轨迹段
        target_point = Point(target_pos)
        segment_idx = None

        for i in range(len(trajectory) - 1):
            seg_start = Point(trajectory[i])
            seg_end = Point(trajectory[i + 1])
            seg_line = LineString([seg_start, seg_end])

            if seg_line.distance(target_point) < 1e-6:
                segment_idx = i
                break

        # 计算切线方向（朝向角）
        if segment_idx is not None and segment_idx < len(trajectory) - 1:
            direction_vec = trajectory[segment_idx + 1] - trajectory[segment_idx]
            yaw = np.arctan2(direction_vec[1], direction_vec[0])
        else:
            # 如果无法确定方向，保持原方向
            # 从原多边形计算原朝向
            yaw = calculate_yaw_from_polygon(ego_polygon)

        # 计算原始多边形的中心点
        original_center = np.mean(ego_polygon, axis=0)

        # 将多边形平移到原点
        centered_polygon = ego_polygon - original_center

        # 计算旋转矩阵
        cos_yaw = np.cos(yaw)
        sin_yaw = np.sin(yaw)
        rotation_matrix = np.array([[cos_yaw, -sin_yaw], [sin_yaw, cos_yaw]])

        # 应用旋转
        rotated_polygon = centered_polygon @ rotation_matrix.T

        # 平移到目标位置
        new_polygon = rotated_polygon + target_pos

        return new_polygon

    def _follow_polyline_curvature(self, ego_polygon, current_vel, cur_index, polyline, t):
        """
        让自车按照 polyline 在 cur_index 附近一段曲线的平均曲率前进（避免单点曲率不稳定）

        Args:
            ego_polygon: np.array, 自车多边形，shape (4, 2)
            current_vel: float, 当前速度（m/s）
            cur_index: int, 当前时间步索引
            polyline: np.array, 折线点序列，shape (N, 2)
            t: float, 时间（秒）

        Returns:
            np.array, 新位置的多边形
            float, 新位置 [x, y]
            float, 新朝向角（弧度）
        """
        def calculate_yaw_from_polygon(polygon):
            """
            从多边形计算自车的朝向角

            Args:
                polygon: np.array, 多边形顶点坐标，shape (4, 2)

            Returns:
                float, 朝向角（弧度）
            """
            # 顶点顺序: 0-右下(后右), 1-右上(前右), 2-左上(前左), 3-左下(后左)
            front_center = (polygon[1] + polygon[2]) / 2  # 前边缘中点(前右+前左)
            rear_center = (polygon[0] + polygon[3]) / 2   # 后边缘中点(后右+后左)

            direction_vec = front_center - rear_center
            yaw = np.arctan2(direction_vec[1], direction_vec[0])

            return yaw

        def get_new_polygon_at_position(original_polygon, target_pos, target_yaw):
            """
            根据目标位置和朝向生成新的多边形

            Args:
                original_polygon: np.array, 原始多边形，shape (4, 2)
                target_pos: np.array, 目标位置 [x, y]
                target_yaw: float, 目标朝向角（弧度）

            Returns:
                np.array, 新位置的多边形
            """
            # 计算原始多边形的中心点
            original_center = np.mean(original_polygon, axis=0)

            # 将多边形平移到原点
            centered_polygon = original_polygon - original_center

            # 计算原始朝向角，只旋转增量部分（delta_yaw）
            original_yaw = calculate_yaw_from_polygon(original_polygon)
            delta_yaw = target_yaw - original_yaw

            # 计算旋转矩阵（基于增量角度）
            cos_yaw = np.cos(delta_yaw)
            sin_yaw = np.sin(delta_yaw)
            rotation_matrix = np.array([[cos_yaw, -sin_yaw], [sin_yaw, cos_yaw]])

            # 应用旋转
            rotated_polygon = centered_polygon @ rotation_matrix.T

            # 平移到目标位置
            new_polygon = rotated_polygon + target_pos

            return new_polygon

        def calculate_curvature_sign(polyline, point_index):
            """
            计算曲率的符号（左拐为正，右拐为负）

            Args:
                polyline: np.array, 折线点序列
                point_index: int, 点索引

            Returns:
                int, 曲率符号（1: 左拐, -1: 右拐, 0: 直线）
            """
            if point_index < 1 or point_index >= len(polyline) - 1:
                return 0

            p_prev = polyline[point_index - 1]
            p_curr = polyline[point_index]
            p_next = polyline[point_index + 1]

            vec1 = p_curr - p_prev  # 入方向（前一个点到当前点）
            vec2 = p_next - p_curr  # 出方向（当前点到下一个点）

            cross_product = np.cross(vec1, vec2)

            if cross_product > 0:
                return 1  # 左拐
            elif cross_product < 0:
                return -1  # 右拐
            else:
                return 0  # 直线

        def calculate_curvature_at_point(polyline, point_index):
            """
            计算 polyline 中指定点的曲率

            Args:
                polyline: np.array, 折线点序列，shape (N, 2)
                point_index: int, 要计算曲率的点索引

            Returns:
                float, 曲率值（1/米）
                float, 转弯半径（米）
            """
            if point_index < 1 or point_index >= len(polyline) - 1:
                return 0.0, float('inf')  # 边界点无法计算曲率

            # 获取三个连续点
            p_prev = polyline[point_index - 1]
            p_curr = polyline[point_index]
            p_next = polyline[point_index + 1]

            # 计算三条边的长度
            a = np.linalg.norm(p_curr - p_prev)
            b = np.linalg.norm(p_next - p_curr)
            c = np.linalg.norm(p_next - p_prev)

            if a * b * c == 0:
                return 0.0, float('inf')

            # Menger 曲率公式：k = 2 * |cross(P1P2, P1P3)| / (|P1P2| * |P2P3| * |P1P3|)
            cross_product = np.cross(p_curr - p_prev, p_next - p_prev)
            denominator = a * b * c

            if denominator == 0:
                return 0.0, float('inf')

            curvature = 2.0 * np.abs(cross_product) / denominator
            radius = 1.0 / curvature if curvature != 0 else float('inf')

            return curvature, radius

        def move_with_curvature(current_pos, current_yaw, current_vel, curvature, curvature_sign, t):
            """
            让自车按照给定曲率前进

            Args:
                current_pos: np.array, 当前位置 [x, y]
                current_yaw: float, 当前朝向角（弧度）
                current_vel: float, 当前速度（m/s）
                curvature: float, 曲率（1/米）
                curvature_sign: int, 曲率符号（1: 左拐, -1: 右拐）
                t: float, 时间（秒）

            Returns:
                np.array, 新位置 [x, y]
                float, 新朝向角（弧度）
            """
            if curvature == 0 or abs(curvature) < 1e-6:
                # 直线行驶
                delta_x = current_vel * t * np.cos(current_yaw)
                delta_y = current_vel * t * np.sin(current_yaw)
                new_pos = current_pos + np.array([delta_x, delta_y])
                new_yaw = current_yaw  # 朝向不变

                return new_pos, new_yaw

            # 弯道行驶
            radius = 1.0 / curvature

            # 计算行驶的弧长
            arc_length = current_vel * t

            # 计算旋转角度
            delta_theta = arc_length / radius * curvature_sign

            # 计算转弯圆心
            center_x = current_pos[0] - radius * np.sin(current_yaw) * curvature_sign
            center_y = current_pos[1] + radius * np.cos(current_yaw) * curvature_sign

            # 计算新位置
            new_angle = current_yaw + delta_theta
            new_x = center_x + radius * np.sin(new_angle) * curvature_sign
            new_y = center_y - radius * np.cos(new_angle) * curvature_sign

            new_pos = np.array([new_x, new_y])
            new_yaw = new_angle

            return new_pos, new_yaw

        # 1. 计算当前自车的中心点和朝向
        ego_center = np.mean(ego_polygon, axis=0)
        current_yaw = calculate_yaw_from_polygon(ego_polygon)

        # 2. 计算 cur_index 附近一段曲线的平均曲率（避免单点曲率不稳定）
        if len(polyline) < 3:
            # 点太少，按直线处理
            curvature = 0.0
            curvature_sign = 0
        else:
            avg_window = 5  # 前后各取 avg_window 个点做平均
            start_idx = max(1, cur_index - avg_window)
            end_idx = min(len(polyline) - 1, cur_index + avg_window + 1)
            curvature_list = []
            sign_list = []
            for pi in range(start_idx, end_idx):
                k, _ = calculate_curvature_at_point(polyline, pi)
                s = calculate_curvature_sign(polyline, pi)
                curvature_list.append(k)
                sign_list.append(s)
            if len(curvature_list) > 0:
                curvature = float(np.mean(curvature_list))
                # 曲率符号取多数投票，0 不参与
                non_zero_signs = [s for s in sign_list if s != 0]
                if len(non_zero_signs) > 0:
                    curvature_sign = 1 if sum(non_zero_signs) > 0 else -1
                else:
                    curvature_sign = 0
            else:
                curvature = 0.0
                curvature_sign = 0

        # 3. 计算前进后的位置和朝向
        new_pos, new_yaw = move_with_curvature(
            ego_center, current_yaw, current_vel, curvature, curvature_sign, t
        )

        # 4. 生成新位置的多边形
        new_polygon = get_new_polygon_at_position(ego_polygon, new_pos, new_yaw)

        return new_polygon

    def _calculate_time_to_collision_cross(
        self,
        cur_index: int,
        gt_traj: np.ndarray,
        ego_center: np.ndarray,
        ego_vel: np.ndarray,
        ego_polygon: np.ndarray,
        obj_center: np.ndarray,
        obj_vel: np.ndarray,
        obj_polygon: np.ndarray,
        enable_vis: bool = False,
        is_vru: bool = False,
        vis_save_path: str = "/home/lu.yuan1/projects/melange/vis/ttc_cross_vis.png",
    ) -> float:
        """
        计算碰撞时间 (TTC)，考虑车辆尺寸和横纵向位移.

        Args:
            ego_center: 自车中心 (2,)
            ego_vel: 自车速度 (2,)
            ego_polygon: 自车多边形 (4, 2)
            obj_center: 障碍物中心 (2,)
            obj_vel: 障碍物速度 (2,)
            obj_polygon: 障碍物多边形 (4, 2)

        Returns:
            float: 碰撞时间 (seconds), 如果不会碰撞返回inf
        """
        relative_pos = obj_center - ego_center
        relative_vel = obj_vel - ego_vel

        vel_norm_sq = np.dot(relative_vel, relative_vel)
        if vel_norm_sq < 1e-6:
            return float('inf')

        # 计算基于中心点的TTC
        ttc_center = -np.dot(relative_pos, relative_vel) / vel_norm_sq

        if ttc_center < 0:
            return float('inf')

        # 考虑车辆尺寸，计算实际碰撞时间
        # 计算车辆的边界框
        turn_start_index = max(0, cur_index - 2)
        turn_end_index = min(len(gt_traj), 5 + turn_start_index)
        is_turn, angle_changed = self.is_polyline_turning_by_direction(gt_traj[turn_start_index:turn_end_index])
        # 计算最小碰撞时间
        min_ttc = float('inf')
        if ttc_center > self.CROSS_TTC_THRESHOLD:
            time_steps = np.arange(0, self.CROSS_TTC_THRESHOLD + 0.1, 0.1)
        else:
            time_steps = np.arange(0.6 * ttc_center, ttc_center * 1.4, 0.1)
        # 用于可视化：收集每个时间步计算好的polygon
        ego_polygons_list = [] if enable_vis else None
        obj_polygons_list = [] if enable_vis else None
        collision_idx = None
        # 检查不同时间点的碰撞可能性
        for idx, t in enumerate(time_steps):
            # 计算未来位置
            if is_turn:
                # ego_future_polygon = self._cal_pos_when_turn(ego_polygon, ego_vel, gt_traj[cur_index:], t)
                ego_future_polygon = self._follow_polyline_curvature(ego_polygon,
                                                                     np.hypot(ego_vel[0], ego_vel[1]),
                                                                     cur_index,
                                                                     gt_traj,
                                                                     t)
            else:
                ego_future_polygon = ego_polygon + ego_vel * t
            obj_future_polygon = obj_polygon + obj_vel * t

            if enable_vis:
                ego_polygons_list.append(ego_future_polygon.copy())
                obj_polygons_list.append(obj_future_polygon.copy())

            # 检查边界框是否重叠
            shapely_ego_polygon = Polygon(ego_future_polygon)
            shapely_obj_polygon = Polygon(obj_future_polygon)
            if is_vru:
                max_safe_buffer = 0.4
                max_vel_thresh = 5
            else:
                max_safe_buffer = 0.4
                max_vel_thresh = 10
            if np.hypot(relative_vel[0], relative_vel[1]) > max_vel_thresh:
                safe_buffer = max_safe_buffer
            else:
                safe_buffer = (max_safe_buffer / max_vel_thresh) * np.hypot(relative_vel[0], relative_vel[1])
            expanded_ego_polygon = shapely_ego_polygon.buffer(safe_buffer)
            expanded_obj_polygon = shapely_obj_polygon.buffer(safe_buffer)
            if expanded_ego_polygon.intersects(expanded_obj_polygon):
                if min_ttc == float('inf'):
                    min_ttc = t
                    collision_idx = idx
                break

        # 不管是否碰撞都进行可视化
        if enable_vis:
            # time_steps截断到实际收集的polygon数量（碰撞后break会导致列表不足100）
            actual_len = len(ego_polygons_list)
            self._visualize_ttc_cross_trajectory(
                time_steps=time_steps[:actual_len],
                ego_polygons_list=ego_polygons_list,
                obj_polygons_list=obj_polygons_list,
                ego_center=ego_center,
                obj_center=obj_center,
                ego_vel=ego_vel,
                obj_vel=obj_vel,
                relative_vel=relative_vel,
                ttc_center=ttc_center,
                is_turn=is_turn,
                collision_idx=collision_idx,
                collision_time=min_ttc if min_ttc < float('inf') else None,
                gt_traj=gt_traj,
                cur_index=cur_index,
                save_path=vis_save_path,
            )

        if min_ttc < float('inf'):
            return min_ttc

        return float('inf')

    def _visualize_ttc_cross_trajectory(
        self,
        time_steps: np.ndarray,
        ego_polygons_list: list,
        obj_polygons_list: list,
        ego_center: np.ndarray,
        obj_center: np.ndarray,
        ego_vel: np.ndarray,
        obj_vel: np.ndarray,
        relative_vel: np.ndarray,
        ttc_center: float,
        is_turn: bool,
        collision_idx: int = None,
        collision_time: float = None,
        gt_traj: np.ndarray = None,
        cur_index: int = 0,
        save_path: str = "/home/lu.yuan1/projects/melange/vis/ttc_cross_vis.png",
    ) -> None:
        """
        可视化 _calculate_time_to_collision_cross 中自车与目标在每个时间步的位移轨迹.

        直接使用计算过程中已经算好的polygon数据，不重复计算。
        不管是否碰撞都会绘制。

        会生成一张图片，包含：
        - 自车和目标在每个采样时间点的polygon轮廓（渐变色表示时间推移）
        - 自车和目标中心的位移轨迹线
        - 碰撞时刻（如果存在）的高亮标记
        - 初始位置和初始速度方向箭头

        Args:
            time_steps: 采样时间点数组 (N,)
            ego_polygons_list: 自车在各时间步的polygon列表, 每项 (4, 2)
            obj_polygons_list: 目标在各时间步的polygon列表, 每项 (4, 2)
            ego_center: 自车初始中心 (2,)
            obj_center: 目标初始中心 (2,)
            ego_vel: 自车速度 (2,)
            obj_vel: 目标速度 (2,)
            relative_vel: 相对速度 (2,)
            ttc_center: 基于中心点的TTC (s)
            is_turn: 是否为转弯场景
            collision_idx: 碰撞时间步索引, None表示未碰撞
            collision_time: 碰撞时间 (s), None表示未碰撞
            gt_traj: 自车GT轨迹 (T, 2), 用于绘制真实行驶轨迹做对比
            cur_index: 当前帧索引, 用于截取GT轨迹的未来部分
            save_path: 可视化图片保存路径
        """
        # 从已计算好的polygon中提取中心轨迹
        ego_centers_list = [p.mean(axis=0) for p in ego_polygons_list]
        obj_centers_list = [p.mean(axis=0) for p in obj_polygons_list]
        ego_centers_arr = np.array(ego_centers_list)
        obj_centers_arr = np.array(obj_centers_list)

        # ---- 绘图 ----
        fig, ax = plt.subplots(1, 1, figsize=(14, 10))
        ax.set_aspect('equal')
        ax.set_title(
            f"TTC Cross Trajectory Visualization\n"
            f"is_turn={is_turn}  ttc_center={ttc_center:.2f}s  "
            f"collision={'%.2fs' % collision_time if collision_time is not None else 'None'}",
            fontsize=12,
        )
        ax.set_xlabel("X (m)")
        ax.set_ylabel("Y (m)")

        # 选取若干关键帧绘制polygon轮廓
        num_samples = min(20, len(time_steps))
        sample_indices = np.linspace(0, len(time_steps) - 1, num_samples, dtype=int)
        # 确保碰撞帧也在内
        if collision_idx is not None and collision_idx not in sample_indices:
            sample_indices = np.append(sample_indices, collision_idx)
            sample_indices = np.sort(np.unique(sample_indices))

        from matplotlib.colors import Normalize
        from matplotlib.cm import ScalarMappable
        norm = Normalize(vmin=time_steps[0], vmax=time_steps[-1])
        ego_cmap = plt.cm.Blues
        obj_cmap = plt.cm.Oranges

        for si in sample_indices:
            t = time_steps[si]
            alpha = 0.15 + 0.6 * (si / (len(time_steps) - 1))  # 越晚越深

            # 自车polygon
            ego_poly = ego_polygons_list[si]
            ego_patch = plt.Polygon(ego_poly, closed=True, fill=True,
                                    facecolor=ego_cmap(norm(t)), edgecolor='blue',
                                    alpha=alpha, linewidth=0.8)
            ax.add_patch(ego_patch)

            # 目标polygon
            obj_poly = obj_polygons_list[si]
            obj_patch = plt.Polygon(obj_poly, closed=True, fill=True,
                                    facecolor=obj_cmap(norm(t)), edgecolor='orange',
                                    alpha=alpha, linewidth=0.8)
            ax.add_patch(obj_patch)

        # 碰撞帧高亮
        if collision_idx is not None:
            ego_poly_c = ego_polygons_list[collision_idx]
            obj_poly_c = obj_polygons_list[collision_idx]
            ax.add_patch(plt.Polygon(ego_poly_c, closed=True, fill=False,
                                     edgecolor='red', linewidth=2.5, linestyle='--'))
            ax.add_patch(plt.Polygon(obj_poly_c, closed=True, fill=False,
                                     edgecolor='red', linewidth=2.5, linestyle='--'))
            ax.plot(*ego_centers_list[collision_idx], marker='x', color='red', markersize=12, zorder=10)
            ax.plot(*obj_centers_list[collision_idx], marker='x', color='red', markersize=12, zorder=10)
            ax.annotate(f"collision t={collision_time:.2f}s",
                        xy=ego_centers_list[collision_idx], fontsize=9, color='red',
                        xytext=(10, 10), textcoords='offset points')

        # 中心轨迹线
        ax.plot(ego_centers_arr[:, 0], ego_centers_arr[:, 1], '-', color='blue',
                linewidth=1.5, label='Ego predicted traj', zorder=5)
        ax.plot(obj_centers_arr[:, 0], obj_centers_arr[:, 1], '-', color='orange',
                linewidth=1.5, label='Obj predicted traj', zorder=5)

        # GT轨迹（自车真实行驶轨迹）
        if gt_traj is not None and len(gt_traj) > cur_index:
            # 取当前帧往后一段GT轨迹用于对比
            gt_future = gt_traj[cur_index:]
            ax.plot(gt_future[:, 0], gt_future[:, 1], '--', color='green',
                    linewidth=2.0, label='Ego GT traj', zorder=6)
            # GT起点标记
            ax.plot(gt_future[0, 0], gt_future[0, 1], 'o', color='green',
                    markersize=8, zorder=10)
            # GT终点标记
            ax.plot(gt_future[-1, 0], gt_future[-1, 1], 's', color='green',
                    markersize=8, zorder=10)
            ax.annotate("GT start", xy=gt_future[0], fontsize=9, color='green',
                        xytext=(5, -15), textcoords='offset points')

        # 起始位置标记
        ax.plot(*ego_center, 'o', color='blue', markersize=8, zorder=10)
        ax.plot(*obj_center, 'o', color='orange', markersize=8, zorder=10)
        ax.annotate("Ego start", xy=ego_center, fontsize=9, color='blue',
                    xytext=(5, 8), textcoords='offset points')
        ax.annotate("Obj start", xy=obj_center, fontsize=9, color='orange',
                    xytext=(5, 8), textcoords='offset points')

        # 速度方向箭头
        arrow_scale = 0.5
        ax.annotate('', xy=ego_center + ego_vel * arrow_scale, xytext=ego_center,
                    arrowprops=dict(arrowstyle='->', color='blue', lw=2))
        ax.annotate('', xy=obj_center + obj_vel * arrow_scale, xytext=obj_center,
                    arrowprops=dict(arrowstyle='->', color='orange', lw=2))

        # 终止位置标记
        ax.plot(*ego_centers_arr[-1], 's', color='blue', markersize=8, zorder=10)
        ax.plot(*obj_centers_arr[-1], 's', color='orange', markersize=8, zorder=10)

        # 时间色标
        sm_ego = ScalarMappable(cmap=ego_cmap, norm=norm)
        sm_obj = ScalarMappable(cmap=obj_cmap, norm=norm)
        sm_ego.set_array([])
        sm_obj.set_array([])
        cbar = fig.colorbar(sm_ego, ax=ax, fraction=0.03, pad=0.04)
        cbar.set_label("Time (s)")

        ax.legend(loc='best', fontsize=10)
        ax.grid(True, alpha=0.3)

        # 保存
        save_dir = os.path.dirname(save_path)
        if save_dir and not os.path.exists(save_dir):
            os.makedirs(save_dir, exist_ok=True)
        fig.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.close(fig)
        print(f"[vis] TTC cross trajectory saved to: {save_path}")


    def _should_calculate_cutin_ttc(
        self,
        obj_polygon: np.ndarray,
        obj_yaw: float,
        obj_vel: np.ndarray,
        ego_center: np.ndarray,
        ego_forward: np.ndarray,
        ego_lateral: np.ndarray,
        ego_yaw: float,
        relative_center: np.ndarray,
    ) -> bool:
        """
        判断目标是否满足cut-in风险的前置条件，若返回True则需要计算TTC.

        检查条件:
        1. 目标中心在相邻车道范围内
        2. 目标polygon角点侵入自车前方区域
        3. 目标与自车大致同向行驶
        4. 目标有向自车车道切入的横向速度分量

        Args:
            obj_polygon: 目标多边形 (4, 2)
            obj_yaw: 目标航向角
            obj_vel: 目标速度 (2,)
            ego_center: 自车中心 (2,)
            ego_forward: 自车前向单位向量 (2,)
            ego_lateral: 自车侧向单位向量 (2,)
            ego_yaw: 自车航向角
            relative_center: 目标中心相对自车中心的向量 (2,)

        Returns:
            bool: True表示需要计算TTC, False表示不满足cut-in条件
        """
        # 1. 中心点粗筛：必须在相邻车道范围内
        center_lateral_dist = np.dot(relative_center, ego_lateral)
        abs_center_lateral = abs(center_lateral_dist)
        if abs_center_lateral < self.CUTIN_CENTER_LATERAL_MIN or abs_center_lateral > self.CUTIN_CENTER_LATERAL_MAX:
            return False

        # 2. 检查他车polygon的每个角点是否侵入自车前方区域
        has_corner_in_front = False
        for corner in obj_polygon:
            corner_rel = corner - ego_center
            corner_longitudinal = np.dot(corner_rel, ego_forward)
            corner_lateral = np.dot(corner_rel, ego_lateral)
            if corner_longitudinal < self.CUTIN_LONGITUDINAL_RANGE_REAR or corner_longitudinal > self.CUTIN_LONGITUDINAL_RANGE_FRONT:
                continue
            if abs(corner_lateral) > self.CUTIN_CORNER_LATERAL_MAX:
                continue
            has_corner_in_front = True
            break

        if not has_corner_in_front:
            return False

        # 3. 航向角差异检查：必须大致同向行驶
        heading_diff = np.degrees(obj_yaw) - np.degrees(ego_yaw)
        heading_diff = (heading_diff + 180) % 360 - 180
        if abs(heading_diff) > self.CUTIN_HEADING_DIFF_MAX:
            return False

        # 4. 横向速度分量检查：是否在向自车车道切入
        obj_lateral_vel = np.dot(obj_vel, ego_lateral)
        lateral_vel_towards_ego = -np.sign(center_lateral_dist) * obj_lateral_vel
        if lateral_vel_towards_ego < self.CUTIN_LATERAL_VEL_THRESHOLD:
            return False

        return True

    def _should_calculate_cross_ttc(
        self,
        obj_class: int,
        obj_polygon: np.ndarray,
        obj_yaw: float,
        ego_center: np.ndarray,
        ego_forward: np.ndarray,
        ego_lateral: np.ndarray,
        ego_yaw: float,
        relative_center: np.ndarray,
    ) -> bool:
        """
        判断目标是否满足cross风险的前置条件，若返回True则需要计算TTC.

        检查条件:
        1. 目标中心在侧向范围内
        2. 目标polygon角点侵入自车前方区域
        3. 目标横向行驶（航向角差异在指定范围内，行人跳过此检查）

        Args:
            obj_class: 目标类别
            obj_polygon: 目标多边形 (4, 2)
            obj_yaw: 目标航向角
            ego_center: 自车中心 (2,)
            ego_forward: 自车前向单位向量 (2,)
            ego_lateral: 自车侧向单位向量 (2,)
            ego_yaw: 自车航向角
            relative_center: 目标中心相对自车中心的向量 (2,)

        Returns:
            bool: True表示需要计算TTC, False表示不满足cross条件
        """
        # 1. 中心点粗筛：侧向距离不能超过阈值
        center_lateral_dist = np.dot(relative_center, ego_lateral)
        abs_center_lateral = abs(center_lateral_dist)
        if abs_center_lateral > self.CROSS_CENTER_LATERAL_MAX:
            return False

        # 2. 检查他车polygon的每个角点是否侵入自车前方区域
        has_corner_in_front = False
        for corner in obj_polygon:
            corner_rel = corner - ego_center
            corner_longitudinal = np.dot(corner_rel, ego_forward)
            corner_lateral = np.dot(corner_rel, ego_lateral)
            if corner_longitudinal < self.CROSS_LONGITUDINAL_RANGE_REAR or corner_longitudinal > self.CROSS_LONGITUDINAL_RANGE_FRONT:
                continue
            if abs(corner_lateral) > self.CROSS_CORNER_LATERAL_MAX:
                continue
            has_corner_in_front = True
            break

        if not has_corner_in_front:
            return False

        # 3. 航向角差异检查：必须横向行驶（行人跳过此检查）
        if not self._is_ped(obj_class):
            heading_diff = np.degrees(obj_yaw) - np.degrees(ego_yaw)
            heading_diff = (heading_diff + 180) % 360 - 180
            if abs(heading_diff) > self.CROSS_HEADING_DIFF_MAX or abs(heading_diff) < self.CROSS_HEADING_DIFF_MIN:
                return False

        return True

    def _detect_all_collision_risks_at_timestamp(
        self,
        cur_index: int,
        ego_pose_list: np.ndarray,
        ego_polygon: np.ndarray,
        ego_motion: np.ndarray,
        dobjs: np.ndarray,
        dobjs_polygons: np.ndarray,
        road_edge=None,
        lane_lines=None,
        enable_vis: bool = False,
    ) -> dict:
        """
        统一检测对向来车、cut-in和cross三种碰撞风险，复用公共计算以降低运算时延.

        Args:
            cur_index: 当前时间索引
            ego_pose_list: 自车位姿列表 (T, 4, 4)
            ego_polygon: 自车多边形 (4, 2)
            ego_motion: 自车运动信息
            dobjs: 动态物体数组 (N, 12)
            dobjs_polygons: 动态物体多边形 (N, 4, 2)
            road_edge: 道路边缘信息
            lane_lines: 车道线信息
            enable_vis: 是否开启可视化

        Returns:
            dict: {"oncoming": label, "cutin": label, "cross": label}
        """
        result = {
            "oncoming": self.LABEL_NO_RISK,
            "cutin": self.LABEL_NO_RISK,
            "cross": self.LABEL_NO_RISK,
        }

        # === 公共ego状态计算（只做一次） ===
        ego_center = ego_polygon.mean(axis=0)
        ego_pose = ego_pose_list[cur_index]

        # 自车速度（转换到全局坐标系）
        ego_vel_local = np.array([ego_motion[0], ego_motion[1], 0.0]) if len(ego_motion) >= 2 else np.array([0.0, 0.0, 0.0])
        ego_vel = ego_pose[:3, :3].dot(ego_vel_local)[:2]

        # 自车前向和侧向方向
        ego_forward = ego_pose[:2, 0]
        ego_forward = ego_forward / (np.linalg.norm(ego_forward) + 1e-8)
        ego_lateral = np.array([-ego_forward[1], ego_forward[0]])  # 左侧为正

        ego_yaw = np.arctan2(ego_forward[1], ego_forward[0])
        # oncoming用速度方向的yaw
        ego_yaw_vel = np.arctan2(ego_vel[1], ego_vel[0])

        # cross TTC需要的gt_traj（延迟计算标记）
        gt_traj = None

        for i, (dobj, obj_polygon) in enumerate(zip(dobjs, dobjs_polygons)):
            obj_class = int(dobj[7])

            # === 公共目标状态计算（只做一次） ===
            obj_center = obj_polygon.mean(axis=0)
            relative_center = obj_center - ego_center

            # 目标航向角（公共计算）
            if np.hypot(dobj[-2], dobj[-1:]) < 1:
                obj_yaw = dobj[6] if len(dobj) >= 7 else 0.0
            else:
                obj_yaw = np.arctan2(dobj[-1], dobj[-2])

            # 目标速度（公共计算）
            obj_vel = dobj[10:12] if len(dobj) >= 12 else np.array([0.0, 0.0])

            is_vru_flag = self._is_vru(obj_class)
            is_vehicle_flag = self._is_vehicle(obj_class)
            # === 1. 对向来车风险检测 ===
            if is_vehicle_flag and self._is_oncoming_vehicle(ego_yaw_vel, obj_yaw, obj_center, ego_center,
                                            obj_polygon, ego_polygon, road_edge, lane_lines):
                ttc = self._calculate_time_to_collision_oncoming(
                    ego_center, ego_vel, ego_polygon, obj_center, obj_vel, obj_polygon)
                if ttc < self.TTC_ONCOMING_THRESHOLD:
                    result["oncoming"] = self.LABEL_ONCOMING_RISK

            # === 2. Cut-in风险检测 ===
            elif (is_vru_flag or is_vehicle_flag) and self._should_calculate_cutin_ttc(
                obj_polygon, obj_yaw, obj_vel, ego_center, ego_forward, ego_lateral, ego_yaw, relative_center
            ):
                ttc = self._calculate_time_to_collision_cutin(
                    ego_center, ego_vel, ego_polygon, obj_center, obj_vel, obj_polygon)
                if ttc < self.CUTIN_TTC_THRESHOLD:
                    result["cutin"] = self.LABEL_CUTIN_RISK

            # === 3. Cross风险检测 ===
            elif (is_vru_flag or is_vehicle_flag) and self._should_calculate_cross_ttc(
                obj_class, obj_polygon, obj_yaw, ego_center, ego_forward, ego_lateral, ego_yaw, relative_center
            ):
                # 计算TTC
                if gt_traj is None:
                    gt_traj = ego_pose_list[:, :2, 3]
                ttc = self._calculate_time_to_collision_cross(
                    cur_index, gt_traj, ego_center, ego_vel, ego_polygon,
                    obj_center, obj_vel, obj_polygon, is_vru=is_vru_flag, enable_vis=enable_vis)
                if ttc < self.CROSS_TTC_THRESHOLD:
                    result["cross"] = self.LABEL_CROSS_RISK

            # 三种风险都已检测到，提前退出
            if (result["oncoming"] != self.LABEL_NO_RISK and
                    result["cutin"] != self.LABEL_NO_RISK and
                    result["cross"] != self.LABEL_NO_RISK):
                break

        return result

    def _detect_cross_risk_at_timestamp(
        self,
        cur_index: int,
        ego_pose_list: np.ndarray,
        ego_polygon: np.ndarray,
        ego_motion: np.ndarray,
        dobjs: np.ndarray,
        dobjs_polygons: np.ndarray,
        enable_vis: bool = False,
    ) -> int:
        """
        在某一时间戳检测是否有其他车辆或自行车cross自车并有碰撞风险.
        Args:
            ego_pose_list: 自车位姿列表 (T, 4, 4)
            ego_polygon: 自车多边形 (4, 2)
            ego_motion: 自车运动信息
            dobjs: 动态物体数组 (N, 12)
            dobjs_polygons: 动态物体多边形 (N, 4, 2)

        Returns:
            int: LABEL_CROSS_RISK 如果检测到cross风险, 否则 LABEL_NO_RISK
        """
        ego_center = ego_polygon.mean(axis=0)
        ego_pose = ego_pose_list[cur_index]

        # 获取自车速度（转换到全局坐标系）
        ego_vel_local = np.array([ego_motion[0], ego_motion[1], 0.0]) if len(ego_motion) >= 2 else np.array([0.0, 0.0, 0.0])
        ego_vel = ego_pose[:3, :3].dot(ego_vel_local)[:2]

        # 自车前向和侧向方向（从位姿矩阵的x轴列获取）
        ego_forward = ego_pose[:2, 0]
        ego_forward = ego_forward / (np.linalg.norm(ego_forward) + 1e-8)
        ego_lateral = np.array([-ego_forward[1], ego_forward[0]])  # 左侧为正

        ego_yaw = np.arctan2(ego_forward[1], ego_forward[0])

        for i, (dobj, obj_polygon) in enumerate(zip(dobjs, dobjs_polygons)):
            obj_class = int(dobj[7])
            # if dobj[9] == 696379:
            #     print(dobj[9])
            # 检测车辆和VRU（包括自行车）
            if not (self._is_vehicle(obj_class) or self._is_vru(obj_class)):
                continue
            is_vru_flag = self._is_vru(obj_class)
            obj_center = obj_polygon.mean(axis=0)
            relative_center = obj_center - ego_center

            # 用中心点做粗筛：必须在相邻车道或前方范围内
            center_lateral_dist = np.dot(relative_center, ego_lateral)
            abs_center_lateral = abs(center_lateral_dist)
            if abs_center_lateral > self.CROSS_CENTER_LATERAL_MAX:
                continue

            # 检查他车polygon的每个角点是否侵入自车前方区域
            has_corner_in_front = False
            for corner in obj_polygon:
                corner_rel = corner - ego_center
                corner_longitudinal = np.dot(corner_rel, ego_forward)
                corner_lateral = np.dot(corner_rel, ego_lateral)

                # 角点必须在自车前方纵向范围内
                if corner_longitudinal < self.CROSS_LONGITUDINAL_RANGE_REAR or corner_longitudinal > self.CROSS_LONGITUDINAL_RANGE_FRONT:
                    continue
                if abs(corner_lateral) > self.CROSS_CORNER_LATERAL_MAX:
                    continue
                else:
                    has_corner_in_front = True
                    break

            if not has_corner_in_front:
                continue

            # 获取目标航向角和速度
            if np.hypot(dobj[-2], dobj[-1:]) < 1:
                obj_yaw = dobj[6] if len(dobj) >= 7 else 0.0
            else:
                obj_yaw = np.arctan2(dobj[-1], dobj[-2])
            obj_vel = dobj[10:12] if len(dobj) >= 12 else np.array([0.0, 0.0])

            # 检查航向角差异：必须横向行驶
            if not self._is_ped(obj_class):
                heading_diff = np.degrees(obj_yaw) - np.degrees(ego_yaw)
                heading_diff = (heading_diff + 180) % 360 - 180
                if abs(heading_diff) > self.CROSS_HEADING_DIFF_MAX or abs(heading_diff) < self.CROSS_HEADING_DIFF_MIN:
                    continue

            # 计算TTC
            gt_traj = ego_pose_list[:, :2, 3]
            ttc = self._calculate_time_to_collision_cross(cur_index,
                                                          gt_traj,
                                                          ego_center,
                                                          ego_vel,
                                                          ego_polygon,
                                                          obj_center,
                                                          obj_vel,
                                                          obj_polygon,
                                                          is_vru=is_vru_flag,
                                                          enable_vis=enable_vis
                                                          )

            if ttc < self.CROSS_TTC_THRESHOLD:
                return self.LABEL_CROSS_RISK

        return self.LABEL_NO_RISK

    def _detect_cutin_risk_at_timestamp(
        self,
        ego_pose: np.ndarray,
        ego_polygon: np.ndarray,
        ego_motion: np.ndarray,
        dobjs: np.ndarray,
        dobjs_polygons: np.ndarray,
    ) -> int:
        """
        在某一时间戳检测是否有其他车辆或自行车cut-in自车并有碰撞风险.

        基于他车polygon角点判断cut-in:
        1. 目标与自车大致同向行驶（航向角差异小于阈值）
        2. 目标中心在相邻车道范围内（排除同车道和过远目标）
        3. 目标的某个polygon角点位于自车正前方区域（纵向在前、横向在车道内）
        4. 目标有向自车车道切入的横向速度分量
        5. TTC小于阈值或距离过近

        Args:
            ego_pose: 自车位姿 (4, 4)
            ego_polygon: 自车多边形 (4, 2)
            ego_motion: 自车运动信息
            dobjs: 动态物体数组 (N, 12)
            dobjs_polygons: 动态物体多边形 (N, 4, 2)

        Returns:
            int: LABEL_CUTIN_RISK 如果检测到cut-in风险, 否则 LABEL_NO_RISK
        """
        ego_center = ego_polygon.mean(axis=0)

        # 获取自车速度（转换到全局坐标系）
        ego_vel_local = np.array([ego_motion[0], ego_motion[1], 0.0]) if len(ego_motion) >= 2 else np.array([0.0, 0.0, 0.0])
        ego_vel = ego_pose[:3, :3].dot(ego_vel_local)[:2]

        # 自车前向和侧向方向（从位姿矩阵的x轴列获取）
        ego_forward = ego_pose[:2, 0]
        ego_forward = ego_forward / (np.linalg.norm(ego_forward) + 1e-8)
        ego_lateral = np.array([-ego_forward[1], ego_forward[0]])  # 左侧为正

        ego_yaw = np.arctan2(ego_forward[1], ego_forward[0])

        for i, (dobj, obj_polygon) in enumerate(zip(dobjs, dobjs_polygons)):
            obj_class = int(dobj[7])
            # 检测车辆和VRU（包括自行车）
            if not (self._is_vehicle(obj_class) or self._is_vru(obj_class)):
                continue

            obj_center = obj_polygon.mean(axis=0)
            relative_center = obj_center - ego_center

            # 用中心点做粗筛：必须在相邻车道范围内
            center_lateral_dist = np.dot(relative_center, ego_lateral)
            abs_center_lateral = abs(center_lateral_dist)
            if abs_center_lateral < self.CUTIN_CENTER_LATERAL_MIN or abs_center_lateral > self.CUTIN_CENTER_LATERAL_MAX:
                continue

            # 检查他车polygon的每个角点是否侵入自车前方区域
            has_corner_in_front = False
            for corner in obj_polygon:
                corner_rel = corner - ego_center
                corner_longitudinal = np.dot(corner_rel, ego_forward)
                corner_lateral = np.dot(corner_rel, ego_lateral)

                # 角点必须在自车前方纵向范围内
                if corner_longitudinal < self.CUTIN_LONGITUDINAL_RANGE_REAR or corner_longitudinal > self.CUTIN_LONGITUDINAL_RANGE_FRONT:
                    continue
                if abs(corner_lateral) > self.CUTIN_CORNER_LATERAL_MAX:
                    continue
                else:
                    has_corner_in_front = True
                    break

            if not has_corner_in_front:
                continue

            # 获取目标航向角和速度
            if np.hypot(dobj[-2], dobj[-1:]) < 1:
                obj_yaw = dobj[6] if len(dobj) >= 7 else 0.0
            else:
                obj_yaw = np.arctan2(dobj[-1], dobj[-2])
            obj_vel = dobj[10:12] if len(dobj) >= 12 else np.array([0.0, 0.0])

            # 检查航向角差异：必须大致同向行驶
            heading_diff = np.degrees(obj_yaw) - np.degrees(ego_yaw)
            heading_diff = (heading_diff + 180) % 360 - 180
            if abs(heading_diff) > self.CUTIN_HEADING_DIFF_MAX:
                continue

            # 检查横向速度分量：是否在向自车车道切入
            # center_lateral_dist > 0: 目标在左侧，切入需要向右移动（横向速度为负）
            # center_lateral_dist < 0: 目标在右侧，切入需要向左移动（横向速度为正）
            obj_lateral_vel = np.dot(obj_vel, ego_lateral)
            lateral_vel_towards_ego = -np.sign(center_lateral_dist) * obj_lateral_vel

            if lateral_vel_towards_ego < self.CUTIN_LATERAL_VEL_THRESHOLD:
                continue

            # 计算TTC
            ttc = self._calculate_time_to_collision_cutin(ego_center,
                                                          ego_vel,
                                                          ego_polygon,
                                                          obj_center,
                                                          obj_vel,
                                                          obj_polygon)

            if ttc < self.CUTIN_TTC_THRESHOLD:
                return self.LABEL_CUTIN_RISK

        return self.LABEL_NO_RISK

    def _detect_oncoming_collision_risk_at_timestamp(
        self,
        ego_pose: np.ndarray,
        ego_polygon: np.ndarray,
        ego_motion: np.ndarray,
        dobjs: np.ndarray,
        dobjs_polygons: np.ndarray,
        road_edge,
        lane_lines,
    ) -> int:
        """
        在某一时间戳检测对向来车碰撞风险.

        Args:
            ego_pose: 自车位姿 (4, 4)
            ego_polygon: 自车多边形 (4, 2)
            ego_motion: 自车运动信息
            dobjs: 动态物体数组 (N, 12)
            dobjs_polygons: 动态物体多边形 (N, 4, 2)

        Returns:
            int: 碰撞风险标签
        """
        ego_center = ego_polygon.mean(axis=0)
        # 获取自车速度和yaw角: ego_motion格式 [vx, vy, acc_x, acc_y, yaw, yaw_rate, ...]
        ego_vel = np.array([ego_motion[0], ego_motion[1], 0.]) if len(ego_motion) >= 2 else np.array([0.0, 0.0, 0.0])
        ego_vel = ego_pose[:3, :3].dot(ego_vel)[:2]
        ego_yaw = np.arctan2(ego_vel[1], ego_vel[0])

        for i, (dobj, obj_polygon) in enumerate(zip(dobjs, dobjs_polygons)):
            # 只检测车辆
            obj_class = int(dobj[7])
            if not self._is_vehicle(obj_class):
                continue

            obj_center = obj_polygon.mean(axis=0)
            distance = self._calculate_distance(ego_center, obj_center)

            # 获取障碍物yaw角: dobj格式 [x, y, z, l, w, h, yaw, class_id, ...]
            if np.hypot(dobj[-2], dobj[-1:]) < 1:
                obj_yaw = dobj[6] if len(dobj) >= 7 else 0.0
            else:
                obj_yaw = np.arctan2(dobj[-1], dobj[-2])
            # 首先判断是否为对向来车
            if not self._is_oncoming_vehicle(ego_yaw,
                                             obj_yaw,
                                             obj_center,
                                             ego_center,
                                             obj_polygon,
                                             ego_polygon,
                                             road_edge,
                                             lane_lines):
                continue

            # 计算障碍物相对于自车的角度
            relative_angle = self._calculate_relative_angle_oncoming(ego_yaw, obj_yaw)

            # 计算障碍物中心相对于自车朝向的角度
            angle_to_object = self._calculate_angle_to_object_oncoming(ego_center, ego_yaw, obj_center)

            # 获取障碍物速度: dobj格式 [... , vx, vy, ...]
            obj_vel = dobj[10:12] if len(dobj) >= 12 else np.array([0.0, 0.0])

            # 计算TTC，考虑车辆尺寸和横纵向位移
            ttc = self._calculate_time_to_collision_oncoming(ego_center, ego_vel, ego_polygon, obj_center, obj_vel, obj_polygon)

            if ttc < self.TTC_ONCOMING_THRESHOLD:
                return self.LABEL_ONCOMING_RISK

        return self.LABEL_NO_RISK

    @staticmethod
    def get_lanes(lanes, types, attrs, T):
        hash_value = [l.sum() + t + a.sum() for l, t, a in zip(lanes, types, attrs)]
        filter_idx = np.unique(hash_value, return_index=True)[1]
        filter_idx = np.sort(filter_idx)
        lanes = [lanes[i] for i in filter_idx]
        types = [types[i] for i in filter_idx]
        attrs = [attrs[i] for i in filter_idx]

        lane_lines, road_edge = [], []
        for p, t, a in zip(lanes, types, attrs):
            """
            p为N个点坐标(x, y): N * 2
            t为整条lane的类型:  1
            a为每个point的类型: N * 2
            """
            x_length = np.max(p[:, 0]) - np.min(p[:, 0])
            y_length = np.max(p[:, 1]) - np.min(p[:, 1])
            p = ego2global(p, T)
            if t == 0:  # lane_line
                lane_lines.append([p, a])
            elif t == 1:  # road_edge
                road_edge.append(p)
        return road_edge, lane_lines



    def _process_longitude_lable(self, timestamps, initpose, egocenter_pose, ego_polygons, ego_motions_list, label_status_list, dataset_kwargs: dict = {}):
        """
        处理整个片段,检测每帧的碰撞风险状态和减速状态.

        Args:
            dataset_kwargs: 数据集参数(可选)

        Returns:
            list: 每帧的碰撞风险状态和减速状态列表
        """
        dataset_kwargs = dataset_kwargs if dataset_kwargs is not None else {}


        for i, ts in enumerate(timestamps):
            ego_pose_backwheel = initpose @ self.data[ts]["car_pose"]
            dobjs_full = parse_dynamicobj_v3(self.data[ts]["dynamic_dets"], ego_pose_backwheel)
            dobjs_polygons = get_rotated_rectangle(dobjs_full)

            # 获取自车运动信息
            ego_motion = ego_motions_list[i]
            longitude_lable = 0

            # 检测前车碰撞风险
            collision_label = self._detect_collision_risk_at_timestamp(
                egocenter_pose[i],
                ego_polygons[i],
                ego_motion,
                dobjs_full,
                dobjs_polygons
            )
            longitude_lable = collision_label


            # 获取roadedge 和 lanelines
            frame = self.data[ts]
            roadedge, lanelines = self.get_lanes(
                frame["manner_lane_points"], frame["manner_lane_types"], frame["manner_lane_attr"], ego_pose_backwheel)

            # 统一检测对向来车、cut-in、cross碰撞风险（合并计算以降低时延）
            risk_results = self._detect_all_collision_risks_at_timestamp(
                i,
                egocenter_pose,
                ego_polygons[i],
                ego_motion,
                dobjs_full,
                dobjs_polygons,
                road_edge=roadedge,
                lane_lines=lanelines,
                enable_vis=False
            )
            if risk_results["oncoming"] == self.LABEL_ONCOMING_RISK:
                longitude_lable = risk_results["oncoming"]
            if risk_results["cutin"] == self.LABEL_CUTIN_RISK:
                longitude_lable = risk_results["cutin"]
            if risk_results["cross"] == self.LABEL_CROSS_RISK:
                longitude_lable = risk_results["cross"]

            # # 检测是否有VRU或车辆在前方
            # ego_center = ego_polygons[i].mean(axis=0)
            # ego_yaw = ego_motion[4] if len(ego_motion) >= 5 else 0.0
            # has_obstacle_ahead = self._has_vru_or_vehicle_ahead(
            #     ego_center, ego_yaw, dobjs_full, dobjs_polygons
            # )

            # # 检测是否会在3秒内减速到1m/s以下
            # decel_label = self.LABEL_NO_RISK
            # if has_obstacle_ahead:
            #     will_decel = self._check_deceleration_to_slow_speed(
            #         i, timestamps, ego_motions_list
            #     )
            #     decel_label = self.LABEL_DECEL if will_decel else self.LABEL_NO_RISK

            # if decel_label == self.LABEL_DECEL:
            #     longitude_lable = decel_label

            label_status_list[i]['longitudinal'] = longitude_lable

        return label_status_list



    def _process_lateral_label(self, timestamps, ego_motions, initpose, egocenter_pose, ego_deg_accumu, label_status_list, dataset_kwargs: dict):

        # lane change status
        # lateral: -3, U-turn_right, -2, right_turn, -1 right_change, 0 no, +1 left_turen, +2 left_change, +3 U-turn_left

        # Motion: Change Direction
        for i, ts in enumerate(timestamps):
            deg_accumu = ego_deg_accumu[i]
            if abs(deg_accumu) >= self.THRE_TURN:
                if deg_accumu > 0:
                    label_status_list[i]['lateral'] = 2  # left change
                else:
                    label_status_list[i]['lateral'] = -2  # right change

        # 检查 turn 持续时间，持续时间小于2 s，删除
        min_turn_frames = int(self.THRE_TIME_TURN * self.fps)
        processed_frames = np.zeros(len(label_status_list), dtype=bool)
        for i in range(len(label_status_list)):
            if processed_frames[i]:
                continue
            processed_frames[i] = True
            status = label_status_list[i]['lateral']
            if abs(status) == self.LABEL_TURN_CHANGE:
                # find the duration of this turn
                start_idx = i
                end_idx = i
                for j in range(i+1, len(label_status_list)):
                    if label_status_list[j]['lateral'] == status:
                        end_idx = j
                    else:
                        break
                duration = end_idx - start_idx + 1
                processed_frames[start_idx:end_idx+1] = True
                if duration < min_turn_frames:
                    # remove this turn
                    for j in range(start_idx, end_idx + 1):
                        label_status_list[j]['lateral'] = 0
                else:
                    # TODO: 检查起点和终点之间heading角度
                    # lane_change: abs(角度)<15度
                    # turn: 转弯 abs(角度)>40度
                    # U-turn: 掉头 角度>100度
                    # check heading angle difference
                    start_pose = egocenter_pose[start_idx]
                    end_pose = egocenter_pose[end_idx]
                    start_yaw = np.arctan2(start_pose[1, 0], start_pose[0, 0])
                    end_yaw = np.arctan2(end_pose[1, 0], end_pose[0, 0])
                    yaw_diff = np.degrees(np.unwrap(np.array([end_yaw]) - np.array([start_yaw])))[0]
                    if abs(yaw_diff) < self.THRE_LANE_CHANGE_DEG:
                        # maybe lane change, reset to keep, double-check at next step
                        for j in range(start_idx, end_idx + 1):
                            label_status_list[j]['lateral'] = self.LABEL_KEEP
                    elif abs(yaw_diff) >= self.THRE_U_TURN_DEG:
                        # u-turn
                        u_turn_label = 3 if status == 2 else -3
                        for j in range(start_idx, end_idx + 1):
                            label_status_list[j]['lateral'] = u_turn_label

        center = np.array([0, 0])
        origin_yaw = 0
        # Motion: Lane Change Status Update

        ts_lane_lines_dict = {}
        for i, ts in enumerate(timestamps):
            ego_pose_backwheel = initpose @ self.data[ts]["car_pose"]


            lane_lines = self._parse_frame_env(
                self.data[ts], ego_pose_backwheel, center, origin_yaw, **dataset_kwargs
            )
            ts_lane_lines_dict[ts] = lane_lines

            # lane change status
            # change direction -> no lane change
            ego_pose = egocenter_pose[i]
            next_ego_pose = egocenter_pose[i+1] if i + 1 < len(egocenter_pose) else egocenter_pose[i]
            ego_move_line = LineString([ego_pose[:2, 3], next_ego_pose[:2, 3]])
            cross_lane_dist = float('inf')
            cross_direction = 0 # left +1, right -1
            # cross lane
            all_cross_lane = [LineString(_line[0]) for _line in lane_lines if len(_line[0]) > 2]
            for _cross_lane in all_cross_lane:
                # calculate distance from ego to cross lane
                dist = _cross_lane.distance(Point(ego_pose[:2, 3]))
                if dist < cross_lane_dist:
                    cross_lane_dist = dist

                if ego_move_line.crosses(_cross_lane):
                    # move the cross lane direction to ego move direction
                    lane_coors = np.array(_cross_lane.coords)
                    v_car = np.array(ego_move_line.coords[1]) - np.array(ego_move_line.coords[0])
                    v_line = lane_coors[-1] - lane_coors[0]
                    # 3. 【关键步骤】方向校正
                    # 计算点积：如果小于0，说明这两个向量夹角超过90度（反向了）
                    if np.dot(v_car[:2], v_line[:2]) < 0:
                        v_line = -v_line  # 翻转车道线向量，使其与车头朝向一致
                    # 4. 计算叉乘 (2D Cross Product)
                    # 此时 v_line 是参考基准(正前方)，v_car 是实际航向
                    # 公式：Lane_x * Car_y - Lane_y * Car_x
                    cross_val = v_line[0] * v_car[1] - v_line[1] * v_car[0]
                    # 5. 判断
                    # Cross > 0: 车辆向量在车道向量的左侧 (逆时针)
                    # Cross < 0: 车辆向量在车道向量的右侧 (顺时针)
                    if cross_val > 0:
                        cross_direction = 1  # left
                    else:
                        cross_direction = -1 # right

            # closest_lane_distance.append((cross_lane_dist, cross_direction))
            label_status_list[i]["closest_lane_dist"] = cross_lane_dist

            if i != 0 and label_status_list[i]['lateral'] == 0 and cross_direction != 0:
                # inherit previous lateral status
                label_status_list[i]['lateral'] = cross_direction

        # TODO: move forward lane change position...

        # Motion: nudge
        yaw_rate = ego_motions[:, 1]  # yaw_rate
        # label_status_list = self._check_nudge(yaw_rate, timestamps, label_status_list)

        # expand the lane_change logic
        label_status_list = self._expand_lane_change_by_peaks(label_status_list)

        label_status_list = self._compute_centering_status(initpose, egocenter_pose, timestamps, ts_lane_lines_dict, label_status_list, dataset_kwargs)
        return label_status_list

    def process(self, dataset_kwargs: dict):
        egoinfo = np.array([[0, 0, 0, 4.85, 2, 2, 0]], dtype=np.float32)
        shift = np.eye(4)  # I
        shift[:3, 3] = [1.4, 0, 0]

        clip_parser = ClipParser(self.data)
        timestamps = sorted(self.data["timestamp_list"])

        # (vehspd, yaw_rate, chessis_yawrate)
        ego_motions = np.array([clip_parser.get_motion_by_timestamp(ts) for ts in timestamps])
        ego_motions[:, 1:] = np.degrees(ego_motions[:, 1:])  # rad to deg

        # ego degree
        ego_deg_accumu = np.array([clip_parser.get_deg_accumu_by_timestamp(ts) for ts in timestamps])
        # (vehspd, yaw_rate, chessis_yawrate, delta_yaw, deg_accumu)
        ego_motions = np.concatenate([ego_motions, ego_deg_accumu[:, None]], axis=1)

        # collect all clip data
        trajpose = [self.data[ts]["car_pose"] for ts in timestamps]
        egocenter_pose = np.array([t @ shift for t in trajpose])   # 自车位姿（自车坐标系）
        origin_pose = egocenter_pose[0].copy()
        initpose = np.linalg.inv(origin_pose)

        egocenter_pose = np.array([initpose @ t for t in egocenter_pose])  # 转到以第一帧为原点的坐标系中
        ego_objects = np.array([transform_obj(egoinfo, ego_pose)[0] for ego_pose in egocenter_pose])
        ego_polygons = get_rotated_rectangle(ego_objects)

        # 预加载所有时间戳的运动信息
        ego_motions_list = []
        label_status_list = []
        for ts in timestamps:
            ego_motion = self.data[ts].get("ego_motion", np.zeros(12))
            ego_motions_list.append(ego_motion)
            label_status_list.append({"ts": ts, "lateral": 0, "longitudinal": 0, "closest_lane_dist": float('inf')})

        label_status_list = self._process_lateral_label(timestamps, ego_motions, initpose, egocenter_pose, ego_deg_accumu, label_status_list, dataset_kwargs)
        label_status_list = self._process_longitude_lable(timestamps, initpose, egocenter_pose, ego_polygons, ego_motions_list, label_status_list, dataset_kwargs)

        for item in label_status_list:
            if "closest_lane_dist" in item:
                del item["closest_lane_dist"]

        return label_status_list


    def process_offline(self, meta_action_tags, dataset_kwargs: dict = {}):
        timestamps = np.array(sorted(self.data["timestamp_list"]), dtype=np.float64)
        n = len(timestamps)

        lateral_values = np.zeros(n, dtype=np.int32)
        longitudinal_values = np.zeros(n, dtype=np.int32)
        lon_category_map = {
            "NO_RISK": 0,
            "COLLISION": 1,
            "DECAL": 2,
            "ONCOMING_RISK": 3,
            "CUTIN_COLLISION": 4,
            "CROSS_RISK": 5,
        }
        lat_category_map = {
            "RIGHT_UTURN": 0,
            "RIGHT_TURN": 1,
            "RIGHT_LC": 2,
            "KEEP": 3,
            "LEFT_LC": 4,
            "LEFT_TURN": 5,
            "LEFT_UTURN": 6,
            "CENTERING": 3,
        }
        lat_value_to_key = {v: k for k, v in self.LATITUDE_LABELS_MAP.items()}
        lon_value_to_key = {v: k for k, v in self.LONGITUDE_LABELS_MAP.items()}
        lat_updates = []  # List of (start_idx, end_idx, value)
        lon_updates = []  # List of (start_idx, end_idx, value)
        for tag in meta_action_tags:
            # Handle both tuple format (tag_name, start_time, end_time) and dict format
            if isinstance(tag, tuple):
                # New optimized format: (tag_name, start_time, end_time)
                tag_name, start_time, end_time = tag
            else:
                # Legacy dict format
                tag_name = tag.get("tag_name", "")
                start_time = tag.get("start_time", 0)
                end_time = tag.get("end_time", 0)

            if tag_name in lat_category_map or tag_name in lon_category_map:
                start_idx = bisect.bisect_left(timestamps, start_time)
                end_idx = bisect.bisect_right(timestamps, end_time)

                if start_idx >= n or end_idx <= 0:
                    continue

                start_idx = max(0, start_idx)
                end_idx = min(n, end_idx)

                if tag_name in lat_category_map:
                    category_value = lat_category_map[tag_name]
                    lateral_value = lat_value_to_key.get(category_value)
                    if lateral_value is not None:
                        lat_updates.append((start_idx, end_idx, lateral_value))


                if tag_name in lon_category_map:
                    category_value = lon_category_map[tag_name]
                    longitudinal_value = lon_value_to_key.get(category_value)
                    if longitudinal_value is not None:
                        lon_updates.append((start_idx, end_idx, longitudinal_value))

        for start_idx, end_idx, value in lat_updates:
            lateral_values[start_idx:end_idx] = value
        for start_idx, end_idx, value in lon_updates:
            longitudinal_values[start_idx:end_idx] = value

        # print(f"lateral_values = {lateral_values}")
        # print(f"longitudinal_values = {longitudinal_values}")
        # Build final result list
        label_status_list = [
            {
                "ts": float(timestamps[i]),
                "lateral": int(lateral_values[i]),
                "longitudinal": int(longitudinal_values[i]),
            }
            for i in range(n)
        ]
        return label_status_list
