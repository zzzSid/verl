# -*- coding: utf-8 -*-
import glob
import os
import json
import logging
import struct
import copy
import numpy as np
import math
from google.protobuf.json_format import MessageToDict
from scipy.spatial.transform import Rotation as R
import pymap3d as pm
from helios import mazu, utils, fs
import gzip
import io
from typing import Union


def parse_waitzone(frame):
    areazones = frame["preproc_data"]["road_zones"]
    wm_stoplines = frame["preproc_data"]["wm_stoplines"]
    stoplines = frame["preproc_data"]["stop_lines"]
    lanes = frame['manner_lane_points']
    types = frame['manner_lane_types']
    attrs = frame['manner_lane_attr']
    lanes_ids = []
    if "manner_lane_id" in frame:
        lanes_ids = frame["manner_lane_id"]
    frame["road_zones"] = {}
    for areazone in areazones:
        # areazone["area_box"]["polygon_points"] 为N个点坐标(x, y): N * 3
        if "polygon_points" not in frame["road_zones"]:
            frame["road_zones"]["polygon_points"] = []
        if "type" not in frame["road_zones"]:
            frame["road_zones"]["type"] = []
        frame["road_zones"]["polygon_points"].append(areazone["area_box"]["polygon_points"])
        frame["road_zones"]["type"].append(areazone["type"])
    frame["wm_stoplines"] = []
    if len(wm_stoplines) > 1:
        wm_stoplines = wm_stoplines[:1]
    for wm_stopline_junc in wm_stoplines:
        ##对齐当前红绿灯junction维度
        ###frame_trafficlight
        junc_wm_stopline = {}
        # junc_wm_stopline['wm_stoplines'] = {}
        for wm_stopline in wm_stopline_junc:
            p_wm = np.array([wm_stopline["stop_points"]])
            id = wm_stopline["stopline_id"]
            for ind, each_lane_id in enumerate(lanes_ids):
                if types[ind] == 2 and each_lane_id == id:
                    spline_type = 100
                    for stopline in stoplines:
                        if id == stopline["id"]:
                            spline_type = stopline["type"]
                            break
                    if spline_type == 100:
                        continue
                    sp_line_st = [lanes[ind][0][0], lanes[ind][0][1]]
                    sp_line_end = [lanes[ind][1][0], lanes[ind][1][1]]
                    p = np.array([sp_line_st, sp_line_end], dtype=np.float32)
                    if "points" not in junc_wm_stopline:
                        junc_wm_stopline["points"] = []
                    junc_wm_stopline["points"].append(p)
                    if "stopline_type" not in junc_wm_stopline:
                        junc_wm_stopline["stopline_type"] = []
                    junc_wm_stopline["stopline_type"].append(spline_type)
                    # print("new stopline id ", id, " points ", p, " type ", spline_type, "\n")
                    break

            if "stopline_id" not in junc_wm_stopline:
                junc_wm_stopline["stopline_id"] = []
            junc_wm_stopline["stopline_id"].append(id)

            if "stop_points" not in junc_wm_stopline:
                junc_wm_stopline["stop_points"] = []

            junc_wm_stopline["stop_points"].append(p_wm)
        frame["wm_stoplines"].append(junc_wm_stopline)
    return frame


def _get_topic_file_from_meta(metainfo, topic_name):
    if topic_name not in metainfo["topics"]:
        logging.error("not find topic_name:%s in in meta", topic_name)
        return None
    filename = None
    filenames = metainfo["topics"][topic_name]
    if type(filenames) is dict:
        filename = filenames["file_name"]
    elif type(filenames) is list:
        if len(filenames) == 0:
            logging.error("Empty file list in topic: %s", topic_name)
            return None
        elif len(filenames) >= 1:
            filename = filenames[0]
    elif type(filenames) is str:
        filename = filenames
    return filename


def get_topic_files(clip_dir: "str", topics: "list[str]") -> "dict[str, str]":
    if not os.path.exists(clip_dir):
        logging.error("Path is not exist!! ... %s", clip_dir)
        return {}
    metafile = os.path.join(clip_dir, "meta.json")
    topic_files = {}
    loadmetasuccess = False
    if os.path.exists(metafile):  # 路采数据分支
        try:
            with open(metafile, "r") as f:
                metainfo = json.load(f)

            for topic in topics:
                filename = _get_topic_file_from_meta(metainfo, topic if topic.startswith("/") else "/" + topic)
                if filename is None:
                    continue
                logging.info("find file for topic: %s -> %s", topic, filename)
                fullpath = os.path.join(clip_dir, filename)
                assert os.path.exists(fullpath), fullpath
                topic_files[topic] = fullpath
            loadmetasuccess = True
        except:
            logging.error("got exception while getting filepath from meta, try to use glob")
            pass
    if not loadmetasuccess:
        pbfiles = glob.glob(clip_dir + "/*.pb.dat")
        topic_files = {}
        isdlb = len(pbfiles) > 0
        if isdlb:  # dlb录制数据分支
            for filename in pbfiles:
                basename = os.path.basename(filename)
                topic = "_".join(basename.split("_")[1:-1]).replace("-", "/")
                if topic in topics:
                    topic_files[topic] = filename
        else:  # 其他格式符合后缀为.dat 然后 topic name 中 / 字符被 - 替换的数据
            pbfiles = glob.glob(clip_dir + "/*.dat")
            for filename in pbfiles:
                basename_with_suffix = os.path.basename(filename)
                basename = os.path.splitext(basename_with_suffix)[0]
                matchtopics = [topic for topic in topics if basename == topic.replace("/", "-")]
                if matchtopics:
                    topic_files[matchtopics[0]] = filename
    for topic in topics:
        if topic not in topic_files:
            logging.warning("Warning not find file for %s", topic)
        else:
            logging.info("%s matched %s", topic, topic_files[topic])

    return topic_files


def parse_pb(pb_path, obj_class):
    """Parse proto."""
    f = open(pb_path, "rb")
    filesize = os.path.getsize(pb_path)
    pb_rets = []
    last_ftell = 0

    while f.tell() < filesize:
        try:
            sub_ptp_ts = struct.unpack("Q", f.read(8))[0]
            pub_ptp_ts = struct.unpack("Q", f.read(8))[0]
            sub_utc_ts = struct.unpack("Q", f.read(8))[0]
            pub_utc_ts = struct.unpack("Q", f.read(8))[0]
            # print(sub_ptp_ts, pub_ptp_ts, sub_utc_ts, pub_utc_ts)
            fsize = struct.unpack("Q", f.read(8))[0]
            obj = obj_class()
            obj.ParseFromString(f.read(fsize))
        except Exception as e:
            raise
        pb_rets.append(obj)
        last_ftell = f.tell()
    return pb_rets


def euler_to_matrix(roll: float = 0.0, pitch: float = 0.0, yaw: float = 0.0) -> np.ndarray:
    cy = math.cos(yaw)
    sy = math.sin(yaw)
    cp = math.cos(pitch)
    sp = math.sin(pitch)
    cr = math.cos(roll)
    sr = math.sin(roll)
    mat = np.array(
        [
            [cy * cp, -sy * cr + cy * sp * sr, sy * sr + cy * sp * cr],
            [sy * cp, cy * cr + sy * sp * sr, -cy * sr + sy * sp * cr],
            [-sp, cp * sr, cp * cr],
        ]
    )

    return mat


def wgs84_to_car(wgs84_points, ref_wgs84, ref_euler_angle, ignore_height=False):
    """
    0->lat
    1->lon
    2->h
    """
    if len(wgs84_points) == 0:
        return np.asarray([])

    enu_pts = []
    ref_lat = ref_wgs84[0]
    ref_lon = ref_wgs84[1]
    # ref_h = ref_wgs84[2] if not ignore_height else 0.0

    pt_lat = wgs84_points[0]
    pt_lon = wgs84_points[1]
    pt_h = wgs84_points[2]

    ref_h = pt_h

    # enu_pts.append(pm.geodetic2enu(pt[1], pt[0], pt[2], ref_y, ref_x, ref_z))
    enu_pts.append(pm.geodetic2enu(pt_lat, pt_lon, pt_h, ref_lat, ref_lon, ref_h))

    roll = ref_euler_angle[0]
    pitch = ref_euler_angle[1]
    yaw = ref_euler_angle[2]
    local_enu = euler_to_matrix(roll, pitch, yaw).T

    # 使用行向量
    local_pts = np.array(enu_pts) @ local_enu.T

    # logger.info(local_pts)
    # logger.info("#" * 20)

    return local_pts.tolist()[0]


def parse_map_loc(map_loc_frame, global_loc_frame, link_info):
    if not getattr(map_loc_frame, "link_index"):
        return {}

    map_latitude = map_loc_frame.pos.latitude
    map_longitude = map_loc_frame.pos.longitude
    map_altitude = map_loc_frame.pos.altitude

    global_latitude = global_loc_frame.latitude
    global_longitude = global_loc_frame.longitude
    global_altitude = global_loc_frame.altitude

    global_roll = global_loc_frame.roll
    glboal_pitch = global_loc_frame.pitch
    global_yaw = global_loc_frame.yaw

    map_loc_point = [
        map_loc_frame.local_pos.x,
        map_loc_frame.local_pos.y,
        map_loc_frame.local_pos.z,
    ]

    # map_loc_point = wgs84_to_car(
    #     [map_latitude, map_longitude, map_altitude],
    #     [global_latitude, global_longitude, global_altitude],
    #     [global_roll, glboal_pitch, global_yaw],
    # )
    link_index = map_loc_frame.link_index
    link_remain_dist = map_loc_frame.link_remain_dist

    map_loc_link_index = link_index
    idxs = find_next_valid_link_info(map_loc_link_index, link_info)

    if len(idxs) == 2:
        link_index_1 = idxs[0]
        link_index_2 = idxs[-1]
        distance_1 = (
            link_remain_dist
            if map_loc_link_index == idxs[0]
            else link_remain_dist + cal_distance(map_loc_link_index + 1, idxs[0], link_info)
        )
        distance_2 = (
            link_remain_dist
            if map_loc_link_index == idxs[-1]
            else link_remain_dist + cal_distance(map_loc_link_index + 1, idxs[-1], link_info)
        )

    elif len(idxs) == 1:
        link_index_1 = idxs[0]
        link_index_2 = -1
        distance_1 = (
            link_remain_dist
            if map_loc_link_index == idxs[0]
            else link_remain_dist + cal_distance(map_loc_link_index + 1, idxs[0], link_info)
        )
        distance_2 = -1
    else:
        link_index_1 = -1
        link_index_2 = -1
        distance_1 = -1
        distance_2 = -1

    # distance_1 = link_remain_dist if map_loc_link_index == idxs[0] else link_remain_dist + self.cal_distance(map_loc_link_index + 1, idxs[0], link_info)
    # distance_2 = link_remain_dist if map_loc_link_index == idxs[-1] else link_remain_dist + self.cal_distance(map_loc_link_index + 1, idxs[-1], link_info)

    if link_index < 0:
        link_speed_limit = 0
    else:
        map_loc_link_frame = link_info[link_index]
        link_speed_limit = map_loc_link_frame.speed_limit
    # logger.info(link_speed_limit)

    res = {
        "map_loc_point": map_loc_point[0:-1],
        "link_index": link_index,
        "link_speed_limit": link_speed_limit,
        "link_remain_dist": link_remain_dist,
        "link_main_distance_1": distance_1,
        "link_main_distance_2": distance_2,
        "link_index_1": link_index_1,
        "link_index_2": link_index_2,
    }

    return res


def parse_link_info(link_info, global_loc_frame):

    res_link_info = []
    keys = [
        "main_action",
        "assistant_action",
        "turn_info",
        "road_class",
        "speed_limit",
        "origin_link_length",
        "cal_link_length",
    ]

    global_latitude = global_loc_frame.latitude
    global_longitude = global_loc_frame.longitude
    global_altitude = global_loc_frame.altitude

    global_roll = global_loc_frame.roll
    glboal_pitch = global_loc_frame.pitch
    global_yaw = global_loc_frame.yaw
    for item in link_info:
        format_points = []
        # point
        # for point in item.points:
        for point in item.local_points:

            # link_latitude = point.latitude
            # link_longitude = point.longitude
            # link_altitude = point.altitude

            # link_loc_point = wgs84_to_car(
            #     [link_latitude, link_longitude, link_altitude],
            #     [global_latitude, global_longitude, global_altitude],
            #     [global_roll, glboal_pitch, global_yaw],
            # )

            # format_points.append((link_loc_point[0], link_loc_point[1]))
            format_points.append((point.x, point.y))

        # format_points = [wgs84_to_car([point.latitude, point.longitude, point.altitude], [global_latitude, global_longitude, global_altitude], [global_roll, glboal_pitch, global_yaw]) for point in item.points]
        # nr info
        nr_infos = [
            MessageToDict(
                line_nr_info,
                including_default_value_fields=True,
                preserving_proto_field_name=True,
            )
            for line_nr_info in item.lane_nr_info
        ]
        link_attrs = {key: getattr(item, key) for key in keys if hasattr(item, key)}
        link_attrs["points"] = format_points
        link_attrs["lane_nr_info"] = nr_infos
        res_link_info.append(link_attrs)

    return res_link_info


def parse_sub_path(sub_path_frame, global_loc_frame):

    global_latitude = global_loc_frame.latitude
    global_longitude = global_loc_frame.longitude
    global_altitude = global_loc_frame.altitude

    global_roll = global_loc_frame.roll
    glboal_pitch = global_loc_frame.pitch
    global_yaw = global_loc_frame.yaw

    # main path
    main_path_points = []
    for item in sub_path_frame.main_path.segments:
        for point in item.shape_points:
            # _loc_point = wgs84_to_car(
            #     [point.latitude, point.longitude, 0.0],
            #     [global_latitude, global_longitude, global_altitude],
            #     [global_roll, glboal_pitch, global_yaw],
            # )
            # main_path_points.append((_loc_point[0], _loc_point[1]))
            main_path_points.append((point.local_x, point.local_y))

    # sub path
    sub_path_points = []
    for sub_path in sub_path_frame.sub_paths:
        one_path_points = []
        for segment in sub_path.segments:
            for point in segment.shape_points:
                # _loc_point = wgs84_to_car(
                #     [point.latitude, point.longitude, 0.0],
                #     [global_latitude, global_longitude, global_altitude],
                #     [global_roll, glboal_pitch, global_yaw],
                # )
                # one_path_points.append((_loc_point[0], _loc_point[1]))
                one_path_points.append((point.local_x, point.local_y))

        if one_path_points:
            sub_path_points.append(one_path_points)

    res = {
        "sub_path_main_path_points": main_path_points,
        "sub_path_sub_path_points": sub_path_points,
    }
    return res


def find_next_valid_link_info(idx, link_info, num=2):
    from itertools import islice

    return list(islice((i for i in range(idx, len(link_info)) if link_info[i].main_action > 0), num))


def cal_distance(start, end, link_info):
    return sum(getattr(obj, "cal_link_length") for obj in link_info[start : end + 1])


def convert_pb_framedata_todict(d):
    keys = ["has_sd_map", "has_hd_map", "has_navi_route"]
    frame = {"manner_meta": {k: getattr(d, k) for k in keys}}

    # ===========> parse car_pose <===========
    ego = d.ego
    quat = [ego.qx, ego.qy, ego.qz, ego.qw]
    car_pose = np.eye(4, dtype=np.float32)
    car_pose[:3, :3] = R.from_quat(quat).as_matrix()
    car_pose[:3, 3] = [ego.x, ego.y, ego.z]
    frame["car_pose"] = car_pose

    # ==========> parse ego_motion <==========
    keys = [
        "vx",
        "vy",
        "acc_x",
        "acc_y",
        "yaw",
        "yaw_rate",
        "whlag",
        "whlagspd",
        "vehspd",
        "lgta",
        "chassis_yawrate",
    ]
    frame["ego_motion"] = [getattr(ego, k) for k in keys]

    # ========> parse dynamic_dets <==========
    keys = [
        "x",
        "y",
        "z",
        "l",
        "w",
        "h",
        "heading",
        "obj_class",
        "obj_special_class",
        "obj_id",
        "vx",
        "vy",
    ]
    dobjs = [[getattr(x, k) for k in keys] for x in d.dynamic_objects]
    # print([item[-2] for item in dobjs])
    dobjs = np.array(dobjs, dtype=np.float32)
    frame["dynamic_dets"] = dobjs

    # =========> parse static_dets <===========
    keys = [
        "x",
        "y",
        "z",
        "l",
        "w",
        "h",
        "heading",
        "obj_class",
        "obj_special_class",
        "obj_id",
    ]
    sobjs = [[getattr(x, k) for k in keys] for x in d.static_objects]
    sobjs = np.array(sobjs, dtype=np.float32)
    frame["static_dets"] = sobjs

    # # ==========> parse maploc <============
    frame["speed_limit"] = d.speed_limit
    map_loc_frame = d.map_loc
    global_loc_frame = d.global_localization
    map_loc_item = parse_map_loc(map_loc_frame, global_loc_frame, d.link_info)
    frame["link_speed_limit"] = map_loc_item.get("link_speed_limit", 0)
    frame["map_loc"] = map_loc_item
    # # ==========> parse link_info <============
    link_info_item = parse_link_info(d.link_info, global_loc_frame)
    frame["link_info"] = link_info_item
    # # ==========> parse link_info <============
    sub_path_item = parse_sub_path(d.sub_path_infos, global_loc_frame)
    frame["sub_path"] = sub_path_item
    # ==========> parse traffic light <============
    frame["traffic_lights"] = [[item.color, item.status, item.timer] for item in d.junc_traffic_lights]

    # keys = ['main_path', 'sub_paths', 'timestamp', 'timestamp_utc']
    # subpath_objs = [[getattr(x, k) for k in keys] for x in d.sub_path_infos]
    # frame['navi_sub_paths'] = subpath_objs

    # ==========> parse navi_path <============
    limit_speed = d.speed_limit

    navi_points, navi_tld, navi_spdlimit = [], [], []
    for navip in d.navi_paths:
        navi_tld.append([navip.tld_color, navip.tld_status, navip.tld_timer])
        points = [(p.x, p.y, p.z) for p in navip.points]
        navi_points.append(np.array(points, dtype=np.float32))
        spdlimit = [(limit_speed, -1) for _ in range(len(points))]

        # spdlimit = [(d.speed_limit, -1)]
        navi_spdlimit.append(np.array(spdlimit, dtype=np.float32))

    frame[f"navi_path_tld"] = navi_tld
    frame[f"navi_path_points"] = navi_points
    frame[f"navi_path_speed_limit"] = navi_spdlimit

    # ========> parse manner_lane <==========
    lanes, types, attrs, metas = [], [], [], []
    make_attrs = {
        "lane_lines": lambda l: [(a, c) for a, c in zip(l.types, l.colors)],
        "road_edges": lambda l: [(a, -1) for a in l.types],
        "stop_lines": lambda l: [(-1, -1), (-1, -1)],
        "road_signs": lambda l: [(l.roadsign_class, -1) for _ in range(4)],
    }
    # frame['road_signs'] = [l for l in d.road_signs if l.confidence > 0.]
    for t, (k, m) in enumerate(make_attrs.items()):
        lines = getattr(d, k)
        for line in lines:
            if k == "road_signs" and line.confidence <= 0.0:
                continue

            p = [(p.x, p.y, p.z) for p in line.points]
            p = np.array(p, dtype=np.float32)
            a = np.array(m(line), dtype=np.int32)
            assert p.shape[0] == a.shape[0], f"key: {k} -> p.shape: {p.shape}, a.shape: {a.shape}"
            lanes.append(p)
            types.append(t)
            attrs.append(a)
    frame["manner_lane_points"] = lanes
    frame["manner_lane_types"] = types
    frame["manner_lane_attr"] = attrs
    # frame["manner_lane_center_lines"] = d.lane_center_lines
    frame["manner_lane_center_lines"] = [
        MessageToDict(item, including_default_value_fields=True, preserving_proto_field_name=True)
        for item in d.lane_center_lines
    ]

    frame_ts = d.frame_ts / 1e9
    return frame_ts, frame


def frame_data_to_pkl(frame_datas: list, output_file):
    import pickle

    fdata = {}
    for frame_data in frame_datas:
        frame_ts, frame = convert_pb_framedata_todict(frame_data)
        fdata[frame_ts] = frame

    timestamp_list = np.array(list(fdata.keys()), dtype=np.float64)
    assert len(timestamp_list) > 40, f"clip feature frame num le 40, count: {len(timestamp_list)}"

    fdata["timestamp_list"] = timestamp_list
    with open(output_file, "wb") as f:
        pickle.dump(fdata, f, protocol=pickle.HIGHEST_PROTOCOL)

    return output_file


class DataParser:
    def __init__(self):
        proto_file = os.path.join(os.path.dirname(__file__), "frame_data_pb2.py")
        self.mod = utils.import_pyfile(proto_file)

    def parse(self, pb_file: Union[str, bytes, io.IOBase]) -> dict:
        assert isinstance(pb_file, (str, bytes, io.IOBase)), "pb_file must be str or bytes or io.IOBase"
        in_file = pb_file
        if isinstance(pb_file, bytes):
            if pb_file[:2] == b"\x1f\x8b":
                in_file = gzip.decompress(pb_file)
        elif isinstance(pb_file, str):
            if pb_file.endswith(".pb.dat.gz"):
                in_file = gzip.decompress(fs.read_bytes(pb_file))

        frame_datas = mazu.parse_pb(in_file, self.mod.FrameData)
        fdata = {}
        nano_ts_list = []
        for frame_data in frame_datas:
            if not frame_data.has_valid_map_loc:
                continue
            if not frame_data.has_valid_heart_beat:
                continue
            frame_ts, frame = convert_pb_framedata_todict(frame_data)
            fdata[frame_ts] = frame
            nano_ts_list.append(frame_data.frame_ts)

        timestamp_list = np.array(list(fdata.keys()), dtype=np.float64)
        assert len(timestamp_list) > 40, f"clip feature frame num le 40, count: {len(timestamp_list)}"

        fdata["timestamp_list"] = timestamp_list
        fdata["nano_ts_list"] = nano_ts_list
        return fdata


global_data_parser = DataParser()
