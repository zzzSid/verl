# -*- coding: utf-8 -*-
import logging
from typing import Dict
from typing import List
from typing import Optional

import numpy as np
import torch
import torch.distributed as dist

from tpp_onemodel.data.dataset.sample_filters import RequiredFieldsFilter
from tpp_onemodel.data.dataset.sample_filters import SampleFilter
from tpp_onemodel.data.dataset.sample_filters import TagExcludeFilter
from tpp_onemodel.data.dataset.sample_filters import TagIncludeFilter
from tpp_onemodel.utils.common_utils import timer


logger = logging.getLogger(__name__)


def is_sample_include_tag(one_pair_infos, included_tag_list):
    """Check if sample include all of the tags."""
    if not included_tag_list:
        return True
    current_tags = one_pair_infos["current"][0]["tags"]
    for tag in included_tag_list:
        is_found = False
        for current_tag in current_tags:
            if tag in current_tag:
                is_found = True
                break
        if not is_found:
            return False
    return True


def is_sample_exclude_tag(one_pair_infos, excluded_tag_list):
    """Check if sample exclude any of the tags."""
    if not excluded_tag_list:
        return True
    current_tags = one_pair_infos["current"][0]["tags"]
    for tag in excluded_tag_list:
        for current_tag in current_tags:
            if tag in current_tag:
                return False
    return True


class SubIterator:
    """Mini Dataset for Lidar."""

    def __init__(
        self,
        anno_pairs,
        shuffle,
        batch_size,
        debug_mode=False,
        num_replicas: Optional[int] = None,
        rank: Optional[int] = None,
        num_workers=1,
    ):
        """Init."""
        self.anno_pairs = anno_pairs
        self.shuffle = shuffle
        self.batch_size = batch_size
        self.debug_mode = debug_mode
        self.num_replicas = num_replicas
        self.rank = rank
        self.num_workers = num_workers if num_workers > 0 else 1

        self.init_dist()

        # Note: index and annp_ids must be on share_memory for multi data_worker sync.
        # self.index = torch.tensor([0], dtype=torch.int64).share_memory_()
        # self.anno_ids = self.init_pair_index().share_memory_()

        # Note: subiter only handle len(dataset)/mp_split data, need not share_mem.
        self.index = torch.tensor([0], dtype=torch.int64)
        self.anno_ids = self.init_pair_index_mp_split()

    def init_pair_index(self):
        """Init pair index."""
        anno_ids = np.arange(0, len(self), dtype=np.int64)
        if self.shuffle:
            np.random.shuffle(anno_ids)
        length = self.num_replicas * int(len(self) / self.num_replicas)
        anno_ids_clipped = anno_ids[:length]
        shard_len = int(len(self) / self.num_replicas)
        start = self.rank * shard_len
        stop = (self.rank + 1) * shard_len
        anno_ids_this_shard = anno_ids_clipped[start:stop]
        if len(anno_ids_this_shard) != shard_len:
            raise RuntimeError("error happened in ids split")
        return torch.tensor(anno_ids_this_shard)

    def init_pair_index_mp_split(self):
        """Init pair index."""
        anno_ids = np.arange(0, len(self), dtype=np.int64)
        if self.shuffle:
            np.random.shuffle(anno_ids)
        length = self.num_replicas * int(len(self) / self.num_replicas)
        anno_ids_clipped = anno_ids[:length]
        shard_len = int(len(self) / self.num_replicas)
        start = self.rank * shard_len
        stop = (self.rank + 1) * shard_len
        anno_ids_this_shard = anno_ids_clipped[start:stop]
        if len(anno_ids_this_shard) != shard_len:
            raise RuntimeError("error happened in ids split")

        worker_len = int(len(anno_ids_this_shard) / self.num_workers)
        left_num = len(anno_ids_this_shard) % self.num_workers
        split_len = [worker_len] * self.num_workers
        for idx in range(left_num):
            split_len[idx] += 1
        split_len = np.concatenate([[0], np.cumsum(split_len)])

        anno_ids_this_shard_workers = []
        for idx in range(len(split_len) - 1):
            start = split_len[idx]
            stop = split_len[idx + 1]
            anno_ids_this_shard_workers.append(anno_ids_this_shard[start:stop])

        return anno_ids_this_shard_workers

    def init_dist(self):
        """Init dist."""
        if self.num_replicas is None:
            if not dist.is_available():
                raise RuntimeError("Requires distributed package to be available")
            self.num_replicas = dist.get_world_size()
        if self.rank is None:
            if not dist.is_available():
                raise RuntimeError("Requires distributed package to be available")
            self.rank = dist.get_rank()
        if self.rank not in range(0, self.num_replicas):
            raise ValueError(
                f"Invalid rank {self.rank}, rank should be in the interval" f" [0, {self.num_replicas - 1}].",
            )

    def __len__(self):
        """len."""
        return len(self.anno_pairs)

    def reset(self, step: int = 0):
        """reset."""
        self.index[0] = step
        # if self.shuffle:
        #     np.random.shuffle(self.anno_ids)

    def get_batch_data(self, worker_id):
        """get_batch_data."""
        if self.debug_mode:
            self.reset()

        stop_idx = self.index[0] + self.batch_size
        if stop_idx > len(self.anno_ids[worker_id]):
            self.reset()
            stop_idx = self.index[0] + self.batch_size
        sample_idx = self.anno_ids[worker_id][self.index[0] : stop_idx]
        self.index[0] = stop_idx

        results = []
        for idx in sample_idx:
            results.append(self.anno_pairs[idx])

        return results
        # return cPickle.loads(cPickle.dumps(results, -1))


class SubIteratorManager:
    def __init__(
        self, mode, subiterator_cfg, shuffle, batch_size, debug_mode, num_replicas, rank, dataloader_num_workers
    ):
        self.mode = mode
        self.subiterator_cfg = subiterator_cfg
        self.shuffle = shuffle
        self.batch_size = batch_size
        self.debug_mode = debug_mode
        self.num_replicas = num_replicas
        self.rank = rank
        self.rank_str = f"Rank: {rank}"
        self.dataloader_num_workers = dataloader_num_workers

        self.name_samples: Dict[str, List[Dict]] = {}
        self.name_max_samples: Dict[str, int] = {}
        self.name_subiterator_is_full: Dict[str, bool] = {}

        self.name_filters: Dict[str, List[SampleFilter]] = {}

        for name, cfg in subiterator_cfg.items():
            self.name_filters[name] = [
                TagIncludeFilter(included_tag_list=cfg.get("included_tag_list", [])),
                TagExcludeFilter(excluded_tag_list=cfg.get("excluded_tag_list", [])),
                RequiredFieldsFilter(required_fields=cfg.get("required_fields", [])),  # example: [""navi_line""]
            ]

            max_samples = max(0.0, float(cfg.get("max_samples", 0.0)))
            if not max_samples > 0:
                max_samples = float("inf")
            self.name_max_samples[name] = max_samples
            self.name_subiterator_is_full[name] = False
            self.name_samples[name] = []

    def is_all_subiterator_full(self):
        """Check if all subiterator is full."""
        return all(self.name_subiterator_is_full.values())

    @timer(vis=True)
    def add_samples(self, input_samples):
        """Add samples to subiterator."""
        for input_sample in input_samples:
            if self.is_all_subiterator_full():
                break
            for name, it_samples in self.name_samples.items():
                if len(it_samples) >= self.name_max_samples[name]:
                    self.name_subiterator_is_full[name] = True
                    continue
                filters = self.name_filters[name]
                cur_sample_is_valid = True
                for filter in filters:
                    is_success, filter_name = filter(input_sample["meta_info"])
                    if not is_success:
                        cur_sample_is_valid = False
                        break
                if not cur_sample_is_valid:
                    continue
                it_samples.append(input_sample)

    @timer(vis=True)
    def init_all_subiterator(self):
        """Init all subiterator."""
        self.name_subiterator: Dict[str, SubIterator] = {}
        self.name_update_subtasks: Dict[str, List[str]] = {}
        self.name_proportion: Dict[str, float] = {}

        if self.mode != "train":
            all_samples = []
            for name in self.name_samples:
                if not self.name_samples[name]:
                    continue
                all_samples.extend(self.name_samples[name])

            self.name_subiterator["all"] = SubIterator(
                anno_pairs=all_samples,
                shuffle=False,
                batch_size=self.batch_size,
                debug_mode=False,
                num_replicas=self.num_replicas,
                rank=self.rank,
                num_workers=self.dataloader_num_workers,
            )
            self.name_update_subtasks["all"] = []
            self.name_proportion["all"] = 1.0
            logger.info("Init all subiterator successfully!")
            logger.info("[Rank: %s]Subiterator num: %s", self.rank, len(self.name_subiterator))
            return None

        for name in self.name_samples:
            if not self.name_samples[name]:
                continue
            self.name_subiterator[name] = SubIterator(
                anno_pairs=self.name_samples[name],
                shuffle=self.shuffle,
                batch_size=self.batch_size,
                debug_mode=self.debug_mode,
                num_replicas=self.num_replicas,
                rank=self.rank,
                num_workers=self.dataloader_num_workers,
            )
            logger.info("Init all subiterator successfully!")
            logger.info("[Rank: %s] name: %s, subiterator len: %s", self.rank, name, len(self.name_subiterator[name]))
            self.name_update_subtasks[name] = self.subiterator_cfg[name].get("update_subtasks", [])
            self.name_proportion[name] = max(0.0, float(self.subiterator_cfg[name].get("proportion", 0.0)))

        # normalize proportion
        total_proportion = sum(self.name_proportion.values())
        if not total_proportion > 0:
            total_proportion = 1.0
            for name in self.name_proportion:
                self.name_proportion[name] = 1.0 / len(self.name_proportion)
        for name in self.name_proportion:
            self.name_proportion[name] /= total_proportion
        max_proprotion_name = max(self.name_proportion, key=self.name_proportion.get)
        self.name_proportion[max_proprotion_name] += 1 - sum(self.name_proportion.values())
        # assert sum(self.name_proportion.values()) == 1.0

    def __len__(self):
        """Return the number of samples."""
        return sum([len(subiterator.anno_pairs) for subiterator in self.name_subiterator.values()])

    def reset(self, step):
        """Reset all subiterator."""
        for subiterator in self.name_subiterator.values():
            subiterator.reset(step)

    def random_choice_subiterator(self, idx):
        """Random choice subiterator."""
        rng = np.random.default_rng(idx)
        name = rng.choice(list(self.name_subiterator.keys()), size=1, p=list(self.name_proportion.values()))[0]

        subiterator = self.name_subiterator[name]
        update_subtasks = self.name_update_subtasks[name]
        return subiterator, update_subtasks

    def yield_all_subiterator_samples(self):
        """Yield all subiterator samples."""
        for name, subiterator in self.name_subiterator.items():
            for sample in subiterator.anno_pairs:
                yield sample
