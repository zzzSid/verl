# -*- coding: utf-8 -*-
import logging

from torchpilot.data.dataloader.multitask_dataloader import MultiTaskDataLoader
from torchpilot.data.dataset.multitask_dataset import MultiTaskDataset
from typing import Any
from typing import Dict

logger = logging.getLogger(__name__)


class Plannn2DataLoader(MultiTaskDataLoader):
    """Plannn2 DataLoader."""

    def get_batch_data(self) -> Dict[str, Any]:
        """Get batch data with error recovery.

        - On timeout (hung worker): reset iterator and retry
        - On data error (corrupt file): skip bad batch and retry next
        Both cases retry up to 3 times to avoid NCCL desync from skip_exception.
        """
        max_retries = 3
        for attempt in range(max_retries):
            try:
                return super().get_batch_data()
            except Exception as e:
                is_timeout = isinstance(e, RuntimeError) and "timed out" in str(e)
                logger.warning(
                    "Data loading %s (attempt %d/%d): %s",
                    "timed out" if is_timeout else "failed",
                    attempt + 1,
                    max_retries,
                    str(e),
                )
                if is_timeout:
                    self.reset()
                if attempt == max_retries - 1:
                    raise

    def move_data_to_cuda(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Move data to cuda.

        Args:
            data Dict[str, Any]: Data to move.

        Returns:
            data Dict[str, Any]: Data on cuda.
        """
        if isinstance(self.dataset, MultiTaskDataset):
            for task_name, task_batch in data.items():
                self.stopwatch.set_time_cost_prefix(task_name)
                data[task_name] = super().move_data_to_cuda(task_batch)
            self.stopwatch.reset_time_cost_prefix()
        else:
            cpu_data = data.pop("cpu_data", None)
            data = super().move_data_to_cuda(data)
            data["cpu_data"] = cpu_data

        return data
