# -*- coding: utf-8 -*-
"""Plannn3 DataLoader with safe settings for GPU VT decode in workers."""

import contextlib
import logging
import os
import sys
from functools import partial
from typing import Any
from typing import Callable
from typing import Dict
from typing import Iterator
from typing import Optional

import torch
from torchpilot.data.dataloader.multitask_dataloader import MultiTaskDataLoader
from torchpilot.data.dataset.multitask_dataset import MultiTaskDataset

from tpp_onemodel.data.plannn3.nn3_constants import DEFAULT_CROP_SHAPE
from tpp_onemodel.data.plannn3.nn3_constants import DEFAULT_MULTIVIEW_CAMS
from tpp_onemodel.data.plannn3.nn3_constants import DEFAULT_VIDEO_SHAPE
from tpp_onemodel.data.dataset.plannn3_dataset import preload_meta_label_storage_for_worker
from tpp_onemodel.data.plannn3.nn3_shared_decoder import Nn3SharedDecoderService
from tpp_onemodel.data.plannn3.nn3_shared_decoder import nn3_shared_decoder_worker_init
from tpp_onemodel.data.plannn3.nn3_visual_cuda import resolve_vt_device_id


logger = logging.getLogger(__name__)


def _debugger_attached() -> bool:
    """Return True when a Python debugger (e.g. debugpy) is tracing this process."""
    return sys.gettrace() is not None


def _chain_nn3_worker_init(
    first_init: Callable[[int], None],
    second_init: Optional[Callable[[int], None]],
    worker_id: int,
) -> None:
    """Run NN3 worker attachment before the existing worker initialization."""
    first_init(worker_id)
    if second_init is not None:
        second_init(worker_id)


@contextlib.contextmanager
def _tp_worker_init_override(
    extra_init: Callable[[int], None],
    dataloader_kwargs: Dict[str, Any],
) -> Iterator[None]:
    """Inject a spawn-safe worker init into TorchPilot's fixed DataLoader init."""
    import torchpilot.data.dataloader.tp_dataloader as tp_dataloader_module
    from torchpilot.utils.file_manager import FileManager

    original = tp_dataloader_module._init_worker_funcion

    def _patched_init_worker(*_args: Any, **_kwargs: Any) -> Callable[[int], None]:
        workers_per_gpu = max(1, int(dataloader_kwargs.get("num_workers", 1) or 1))
        base_init = original(
            workers_per_gpu=workers_per_gpu,
            seed=dataloader_kwargs.get("seed"),
            logger_name=dataloader_kwargs.get("logger_name", "torchpilot"),
            log_dir=FileManager.get_log_dir() if FileManager.initialized else None,
        )
        return partial(_chain_nn3_worker_init, extra_init, base_init)

    tp_dataloader_module._init_worker_funcion = _patched_init_worker
    try:
        yield
    finally:
        tp_dataloader_module._init_worker_funcion = original


class Plannn3DataLoader(MultiTaskDataLoader):
    """Plannn3 DataLoader."""

    def __init__(
        self,
        enable_nn3_visual_decode: bool = False,
        enable_nn3_shared_decoder: bool = False,
        nn3_decoder_worker_num: int = 3,
        nn3_vt_device_id: Optional[int] = None,
        nn3_inner_resize_crop: bool = True,
        **kwargs,
    ):
        """Configure worker multiprocessing when VT GPU decode runs in workers.

        VT/argus_util needs a fresh CUDA context per worker. The default ``fork``
        start method breaks after the training process has already initialized CUDA
        (``CUDA_ERROR_NOT_INITIALIZED``). Use ``spawn`` and disable pin_memory for
        visual batches (frames are kept on CPU until ``move_data_to_cuda``).
        """
        visual_on = enable_nn3_visual_decode or os.getenv("ENABLE_NN3_VISUAL", "0") in (
            "1",
            "true",
            "True",
        )
        if visual_on:
            kwargs.setdefault("multiprocessing_context", "spawn")
            kwargs["pin_memory"] = False
            if _debugger_attached() and int(kwargs.get("num_workers", 0) or 0) > 0:
                logger.warning(
                    "Debugger detected with NN3 visual decode; forcing num_workers=0 "
                    "(spawn workers + debugpy are unstable)"
                )
                kwargs["num_workers"] = 0
            device_id = resolve_vt_device_id(nn3_vt_device_id)
            os.environ["NN3_VT_DEVICE_ID"] = str(device_id)
            logger.info(
                "NN3 visual decode: context=%s pin_memory=%s data_workers=%s shared=%s device=%s",
                kwargs.get("multiprocessing_context"),
                kwargs.get("pin_memory"),
                kwargs.get("num_workers"),
                enable_nn3_shared_decoder,
                device_id,
            )

        existing_worker_init = kwargs.pop("worker_init_fn", None)
        worker_init = existing_worker_init
        if int(kwargs.get("num_workers", 0) or 0) > 0:
            worker_init = partial(
                _chain_nn3_worker_init,
                preload_meta_label_storage_for_worker,
                worker_init,
            )
        if visual_on and enable_nn3_shared_decoder:
            os.environ["NN3_SHARED_DECODER"] = "1"
            data_worker_num = max(1, int(kwargs.get("num_workers", 0) or 0))
            service = Nn3SharedDecoderService.start(
                device_id=device_id,
                decoder_worker_num=nn3_decoder_worker_num,
                num_result_queues=data_worker_num,
                video_shape=DEFAULT_VIDEO_SHAPE,
                crop_shape=DEFAULT_CROP_SHAPE,
                multiview_cams=DEFAULT_MULTIVIEW_CAMS,
                inner_resize_crop=nn3_inner_resize_crop,
            )
            shared_worker_init = partial(
                nn3_shared_decoder_worker_init,
                service.job_queue,
                service.result_queues,
                service.alive_counter,
                service.recovery_flag,
            )
            worker_init = partial(
                _chain_nn3_worker_init,
                shared_worker_init,
                worker_init,
            )

        if int(kwargs.get("num_workers", 0) or 0) == 0:
            # Single-process loading: drop multiprocessing-only options.
            kwargs.pop("prefetch_factor", None)
            kwargs.pop("multiprocessing_context", None)
            kwargs["persistent_workers"] = False
            kwargs["timeout"] = 0

        if worker_init is None:
            super().__init__(**kwargs)
        else:
            with _tp_worker_init_override(worker_init, kwargs):
                super().__init__(**kwargs)

    def get_batch_data(self) -> Dict[str, Any]:
        """Get batch data with error recovery.

        - On timeout (hung worker): reset iterator and retry
        - On data error (corrupt file): skip bad batch and retry next
        Both cases retry up to 3 times to avoid NCCL desync from skip_exception.
        """
        max_retries = 3
        for attempt in range(max_retries):
            try:
                return super().get_batch_data()
            except Exception as e:
                is_timeout = isinstance(e, RuntimeError) and "timed out" in str(e)
                logger.warning(
                    "Data loading %s (attempt %d/%d): %s",
                    "timed out" if is_timeout else "failed",
                    attempt + 1,
                    max_retries,
                    str(e),
                )
                if is_timeout:
                    self.reset()
                if attempt == max_retries - 1:
                    raise

    def move_data_to_cuda(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Move data to cuda.

        Args:
            data Dict[str, Any]: Data to move.

        Returns:
            data Dict[str, Any]: Data on cuda.
        """
        if isinstance(self.dataset, MultiTaskDataset):
            for task_name, task_batch in data.items():
                self.stopwatch.set_time_cost_prefix(task_name)
                data[task_name] = super().move_data_to_cuda(task_batch)
            self.stopwatch.reset_time_cost_prefix()
        else:
            cpu_data = data.pop("cpu_data", None)
            nn3_image = data.pop("nn3_image", None)
            data = super().move_data_to_cuda(data)
            if isinstance(nn3_image, dict):
                data["nn3_image"] = {
                    key: tensor.cuda(non_blocking=True)
                    for key, tensor in nn3_image.items()
                    if isinstance(tensor, torch.Tensor)
                }
            data["cpu_data"] = cpu_data

        return data
