# -*- coding: utf-8 -*-
import logging
from typing import Dict
from typing import List

import numpy as np
import torch
from torchpilot.data.dataset.base_dataset import BaseVideoDataset
from torchpilot.data.sampler.multitask_distributed_sampler import (
    MultiTaskDistributedSampler,
)
from torchpilot.data.sampler.tp_distributed_video_sampler import (
    TPDistributedVideoSampler,
)


logger = logging.getLogger(__name__)


class TPPMultiTaskDistributedSampler(MultiTaskDistributedSampler):
    """MultiTaskDistributedSampler."""

    # pylint: disable=too-many-branches,too-many-nested-blocks.
    def _generate_indices(self):
        """Generate indices.

        Returns:
            If self._indices is not None, return self._indices, else return multitask
            indices (List[Dict[str, int]]) each item is (task_name, task_index) pairs.
        """
        # Init.
        group_indices: Dict[str, Dict[int, List[int]]] = {}

        if self._indices is not None:
            for task_name, task_dataset in self._dataset.task_datasets.items():
                if isinstance(task_dataset, BaseVideoDataset):
                    raise NotImplementedError(
                        f"{task_name} is video dataset, which is not implemented in" " MultiTaskDistributedSampler."
                    )
            if self._shuffle:
                np.random.seed(seed=self._epoch + self._seed)
                np.random.shuffle(self._indices)
                indices = self._indices
            else:
                indices = self._indices
        else:
            # WARNING: Do not use [{}] * len(self._dataset) to avoid pass by reference.
            indices: List[Dict[str, int]] = [{} for _ in range(len(self._dataset))]
            for seed_bias, (task_name, task_dataset) in enumerate(self._dataset.task_datasets.items()):
                if isinstance(task_dataset, BaseVideoDataset):
                    group_indices[task_name] = TPDistributedVideoSampler.generate_group_shuffle_indices(
                        seed=self._seed + seed_bias,
                        epoch=self._epoch,
                        group_num=task_dataset.group_num,
                        batch_size=self._batch_size,
                        num_samples=self._num_samples,
                        num_replicas=self._num_replicas,
                        shuffle=self._shuffle,
                        drop_last=self.drop_last,
                    )
                else:
                    if not self._shuffle:
                        logger.warning("Weighted sampling indices is disabled because of " "self._shuffle=False.")
                        task_indices = list(range(len(self._dataset)))
                        for task_name in self._dataset.task_names:
                            for i, task_index in enumerate(task_indices):
                                indices[i][task_name] = task_index
                    else:
                        # Loop each task to generate task-wise indices.
                        task_shuffle_seed = self._seed + self._epoch
                        dataset_size = len(self._dataset)
                        sample_weight = self._dataset.get_sample_weight()[task_name]
                        if len(sample_weight) != len(self._dataset):
                            raise ValueError(
                                f"Expect len(sample_weight)==len(self._dataset) but got"
                                f" len(sample_weight)={len(sample_weight)}, "
                                f"len(self._dataset)={len(self._dataset)}."
                            )
                        same_weight = len(set(sample_weight)) == 1

                        if hasattr(task_dataset, "get_indices"):
                            task_indices = task_dataset.get_indices(
                                task_shuffle_seed,
                                len(self._dataset),
                            )
                        else:
                            if dataset_size >= (2**24):
                                # Note(yuxiang.yan): torch would raise
                                # `RuntimeError: number of categories cannot exceed
                                # 2^24` if dataset_size >= (2**24), this is a known
                                # issues on github, more details at
                                # `https://github.com/pytorch/pytorch/issues/2576`
                                if not same_weight:
                                    raise RuntimeError(
                                        "Weighted sample is not supported if dataset"
                                        "size >= (2**24). Note: torch would raise "
                                        "`RuntimeError: number of categories cannot "
                                        "exceed 2^24 if dataset_size >= (2**24), this "
                                        "is a known issues on github, more details at "
                                        "`https://github.com/pytorch/pytorch/issues/"
                                        "2576`"
                                    )
                                np.random.seed(task_shuffle_seed)
                                task_indices = np.random.permutation(dataset_size)
                            else:
                                # Deterministically shuffle based on epoch and seed.
                                t_generator = torch.Generator()
                                t_generator.manual_seed(task_shuffle_seed)
                                # Sampling without replacement if sampling weight is all
                                # the same.
                                replacement = not same_weight
                                task_indices = torch.multinomial(
                                    torch.tensor(sample_weight).float(),
                                    len(self._dataset),
                                    replacement=replacement,
                                    generator=t_generator,
                                ).tolist()

                        for i, task_index in enumerate(task_indices):
                            indices[i][task_name] = task_index

        return indices, group_indices
