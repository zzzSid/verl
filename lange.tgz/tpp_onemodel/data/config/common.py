train_data_tag_config = {
    "front_vehicle_brake_data": {
        "front_vehicle_brake_suddenly": {
            "sample_type": "oversample",  # oversample or reject
            "sample_times": 4,  # ignore if sample_type is reject
            "sample_mode": "offline",  # online or offline
            "offline_tag_path": [
                "/share-global/xin.fu2/planning_data/causal_data/collision_data/0403/0403_front_vehicle_brake_suddenly.txt"
            ],  # to be filled with generated tag files
        },
    },
    "tl_start_data": {
        "tl_start": {
            "sample_type": "oversample",  # oversample or reject
            "sample_mode": "online",  # online or offline
            "key_frame_checker": "start",  # ignore when sample_mode is offline
        },
    },
    "follow_start_data": {
        "follow_start": {
            "sample_type": "oversample",  # oversample or reject
            "sample_mode": "online",  # online or offline
            "key_frame_checker": "start",  # ignore when sample_mode is offline
        },
    },
    "boyi_start_data": {
        "boyi_start": {
            "sample_type": "oversample",  # oversample or reject
            "sample_mode": "online",  # online or offline
            "key_frame_checker": "start",  # ignore when sample_mode is offline
        },
    },
    "longitudinal_data": {
        "collision": {
            "sample_type": "oversample",  # oversample or reject
            "sample_times": 4,  # ignore if sample_type is reject
            "sample_mode": "offline",  # online or offline
            "offline_tag_path": [
                "/share-global/shaoqian.li/plannn2/dataset/companion_checker_data/260405_14w_collision_0310ak_no_gt_static_05_json.txt",
                "/share-global/xu.shu/urban/follow_stop_1w.txt",
                "/share-global/xu.shu/urban/veh_cross_9223.txt",
                "/share-global/shane.wan/data_mining/vru_cross_json_32767.txt",
                "/share-global/zhonghao.deng/dataset/data_mining/encounter/narrRoad_encounter_json_9689.txt",
                "/share-global/zhonghao.deng/dataset/data_mining/follow_stop/0315/follow_stop_json_0314_1652.txt",
            ],  # ignore when sample_mode is online
        },
    },
    "effective_change_lane_data": {
        "effective_change_lane": {
            "sample_type": "oversample",  # oversample or reject
            "sample_mode": "online",  # online or offline
            "key_frame_checker": "effective_change_lane",  # ignore when sample_mode is offline
        },
    },
}

pretrain_meta_label_path = "/share-global/gengda.chen/data/0608_nn3_pretrain.pkl"
sft_meta_label_path = "/share-global/gengda.chen/data/0515_v013_all_v2.pkl"
