import numpy as np


class HumanoidChecker:
    def __init__(self, history_size=15):
        self.history_size = history_size

    def find_intersection_key_frames(self, data, timestamps, max_key_idx=0):
        """
        寻找关键帧

        参数:
           data:原始数据
           timestamps：原始时间帧

        返回:
        key_frames: 关键帧索引列表
        """
        key_frames = []
        start_index = self.history_size - 1
        if start_index > max_key_idx:
            return key_frames
        for i in range(start_index, max_key_idx):
            ts = timestamps[i]
            manner_scene_info = data[ts].get("manner_scene_info")
            if not manner_scene_info:
                continue
            junctions = np.array(
                [(jun["scene_type"], jun["distance_to_entry"], jun["distance_to_exit"], jun["turn_direction"])
                    for jun in manner_scene_info],
                dtype=[
                    ('scene_type', 'int64'),
                    ('distance_to_entry', 'float64'),
                    ('distance_to_exit', 'float64'),
                    ('turn_direction', 'int64')
                ]
            )
            mask = (
                (junctions['scene_type'] == 2) &
                (junctions['distance_to_entry'] < 20.0) &
                (junctions['distance_to_exit'] > -30.0)
            )
            ego_in_junction = np.any(mask)
            if ego_in_junction:
                key_frames.append(i)
        return key_frames
