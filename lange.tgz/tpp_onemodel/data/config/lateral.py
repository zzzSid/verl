import numpy as np
import statistics


class EffectiveChangeLaneChecker:
    def __init__(self, history_size=15, timestamp_size=40):
        self.history_size = history_size
        self.timestamp_size = timestamp_size

    def check_need_bypass_car(self, dynamic_dets, ego_speed): # 拿不到方向盘或者车轮转角信息，直接找众数，确保效率换道的precision
        logic1 = np.logical_and(np.abs(dynamic_dets[:, 1]) < 3, dynamic_dets[:, 0] > 0)
        logic2 = np.logical_and(logic1, ego_speed - dynamic_dets[:, 10] > 0)
        need_bypass_car_tid = -1
        if np.any(logic2):
            min_idx = np.argmin(dynamic_dets[logic2, 0])
            need_bypass_car_tid = dynamic_dets[logic2][min_idx, 9]
        return need_bypass_car_tid

    def check_effective_change_lane_key_frame(self, need_bypass_car_tid, dynamic_dets):
        care_dynamic_dets = dynamic_dets[dynamic_dets[:, 9] == need_bypass_car_tid]
        if len(care_dynamic_dets) == 0:
            return False
        return np.logical_and(np.abs(care_dynamic_dets[:, 1]) < 3, care_dynamic_dets[:, 0] > 0).tolist()[0]


    def find_effective_change_lane_key_frames(self, dyn_dets_list, ego_speeds_list):
        need_bypass_car_tids = []
        for i, (dyn_dets, ego_speed) in enumerate(zip(dyn_dets_list, ego_speeds_list)):
            if len(dyn_dets) == 0:
                continue
            need_bypass_car_tid = self.check_need_bypass_car(dyn_dets, ego_speed/3.6)
            if need_bypass_car_tid != -1:
                need_bypass_car_tids.append(need_bypass_car_tid)
        if len(need_bypass_car_tids) == 0:
            return []
        need_bypass_car_tid = statistics.mode(need_bypass_car_tids)
        key_frames_list = []
        for dyn_dets in dyn_dets_list:
            if len(dyn_dets) == 0:
                key_frames_list.append(False)
            else:
                key_frames_list.append(self.check_effective_change_lane_key_frame(need_bypass_car_tid, dyn_dets))

        # 最后一个 True 的位置，若无则为 -1
        last_true_idx = next(
            (i for i in range(len(key_frames_list) - 1, -1, -1) if key_frames_list[i]),
            -1,
        )
        if last_true_idx == -1 or last_true_idx - self.history_size + 1 + self.timestamp_size > len(ego_speeds_list) or last_true_idx-self.history_size+1 < 0:
            return []

        return list(range(max(last_true_idx-self.history_size, self.history_size+1), last_true_idx))
