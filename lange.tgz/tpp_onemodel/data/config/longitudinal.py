import numpy as np


class LongitudinalChecker:
    def __init__(self, history_size=15, timestamp_size=40):
        self.history_size = history_size
        self.timestamp_size = timestamp_size

    def find_start_key_frames(self, speed, time_step=0.1, threshold=0.3, duration_for_check=1.0):
        """
        寻找关键帧 (from pretrain 225)

        参数:
        speed: 速度数组 (km/h)
        time_step: 时间步长 (秒)，默认0.1秒
        threshold: 速度阈值 (m/s)，默认0.3 km/h
        duration_for_check:

        返回:
        key_frames: 关键帧索引列表
        """
        key_frames = []
        n = len(speed)
        max_start_idx = max(0, len(speed) - self.timestamp_size + (self.history_size - 1))
        max_key_idx = max_start_idx - 1
        frames_for_check = int(duration_for_check / time_step)
        for i in range(self.history_size - 1, min(n - frames_for_check - 1, max_key_idx)):
            if speed[i] == 0 and speed[i + 1] > 0:
                subsequent_speeds = speed[i + 1 : i + frames_for_check + 1]
                if np.all(np.array(subsequent_speeds) > 0):
                    avg_speed = np.mean(subsequent_speeds)
                    if avg_speed > threshold:
                        key_frames.append(i)

        return key_frames
