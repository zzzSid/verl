# -*- coding: utf-8 -*-
"""NN3-aligned data helpers (meta action, etc.)."""
