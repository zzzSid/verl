# -*- coding: utf-8 -*-
"""NN3 multiview visual decode entry (melange-local, no plannn3 import)."""

from __future__ import annotations

import asyncio
import gc
import logging
import os
from typing import Any
from typing import Dict
from typing import List
from typing import Optional

import torch

from tpp_onemodel.data.plannn3.nn3_constants import DEFAULT_CROP_SHAPE
from tpp_onemodel.data.plannn3.nn3_constants import DEFAULT_MULTIVIEW_CAMS
from tpp_onemodel.data.plannn3.nn3_constants import DEFAULT_VIDEO_SHAPE
from tpp_onemodel.data.plannn3.nn3_image_filler import Nn3ImageFiller
from tpp_onemodel.data.plannn3.nn3_image_filler import _requires_memory_reclaim
from tpp_onemodel.data.plannn3.nn3_visual_cuda import init_nn3_visual_cuda
from tpp_onemodel.data.plannn3.nn3_visual_cuda import resolve_vt_device_id


logger = logging.getLogger(__name__)


class Nn3VisualDecoder:
    """Decode ``visual_meta`` dict to per-view tensors on GPU."""

    def __init__(
        self,
        device_id: int = 0,
        multiview_cams: Optional[List[str]] = None,
        video_shape: Optional[Dict[str, List[int]]] = None,
        crop_shape: Optional[Dict[str, List[int]]] = None,
        inner_resize_crop: bool = False,
        add_black_mask_prob: float = 0.0,
    ):
        self.device_id = resolve_vt_device_id(device_id)
        self.multiview_cams = list(multiview_cams or DEFAULT_MULTIVIEW_CAMS)
        self.video_shape = video_shape or DEFAULT_VIDEO_SHAPE
        self.crop_shape = crop_shape or DEFAULT_CROP_SHAPE
        self.inner_resize_crop = inner_resize_crop
        self.add_black_mask_prob = add_black_mask_prob
        self._filler: Optional[Nn3ImageFiller] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None

    def _build_filler(self) -> Nn3ImageFiller:
        if self._filler is not None:
            return self._filler
        self._filler = Nn3ImageFiller(
            device_id=self.device_id,
            video_shape=self.video_shape,
            crop_shape=self.crop_shape,
            multiview_cams=self.multiview_cams,
            inner_resize_crop=self.inner_resize_crop,
            add_black_mask_prob=self.add_black_mask_prob,
        )
        return self._filler

    def _get_loop(self) -> asyncio.AbstractEventLoop:
        if self._loop is None or self._loop.is_closed():
            self._loop = asyncio.new_event_loop()
        return self._loop

    def decode(self, visual_meta: Dict[str, Any]) -> Optional[Dict[str, torch.Tensor]]:
        """Decode visual meta; returns ``video:{cam}`` tensors or None on failure."""
        filler = self._build_filler()
        payload = dict(visual_meta)
        payload["index"] = payload.get("index", -1)
        use_async = os.getenv("PLANNN3_VISUAL_ASYNC", "1") not in ("0", "false", "False")
        loop = self._get_loop()
        try:
            if loop.is_running():
                raise RuntimeError("Nn3VisualDecoder event loop already running")
            if use_async:
                result = loop.run_until_complete(self._decode_with_sync(filler, payload))
            else:
                result = asyncio.run(self._decode_with_sync(filler, payload))
        except Exception as exc:
            logger.warning("Nn3VisualDecoder failed: %s", exc)
            self._reset_after_failure(exc)
            return None
        return result

    def _reset_after_failure(self, exc: Optional[BaseException] = None) -> None:
        """Drop decoder state after CUDA/VT errors (forked workers can poison the context)."""
        reclaim_memory = _requires_memory_reclaim(exc) if exc is not None else False
        if self._filler is not None:
            try:
                self._filler.stop()
            except Exception:
                pass
            self._filler = None
        if self._loop is not None and not self._loop.is_closed():
            try:
                self._loop.close()
            except Exception:
                pass
            self._loop = None
        gc.collect()
        if torch.cuda.is_available():
            try:
                torch.cuda.synchronize(self.device_id)
            except Exception:
                pass
            if reclaim_memory:
                try:
                    torch.cuda.empty_cache()
                except Exception:
                    pass
        init_nn3_visual_cuda(self.device_id, force=True)

    @staticmethod
    async def _decode_with_sync(filler: Nn3ImageFiller, payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Same sync polling pattern as plannn3 ImageFiller.fill (no nested asyncio.run)."""
        raw = await filler.fill_with_sync(payload)
        if raw is None:
            return None
        outputs = {}
        for cam in filler.multiview_cams:
            key = f"video:{cam}"
            if key in raw and isinstance(raw[key], torch.Tensor):
                outputs[key] = raw[key].cpu()
        return outputs

    def close(self):
        """Release decoder resources."""
        if self._filler is not None:
            self._filler.stop()
            self._filler = None
        if self._loop is not None and not self._loop.is_closed():
            self._loop.close()
            self._loop = None
