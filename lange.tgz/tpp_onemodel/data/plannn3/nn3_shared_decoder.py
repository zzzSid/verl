# -*- coding: utf-8 -*-
"""Rank-local NN3 VT decoder processes with per-client result queues."""

from __future__ import annotations

import asyncio
import atexit
import logging
import multiprocessing as mp
import os
import queue
import threading
import time
import uuid
from typing import Any
from typing import Callable
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import torch


logger = logging.getLogger(__name__)

_SERVICE: Optional["Nn3SharedDecoderService"] = None
_RECOVERY_FLAG: Optional[Any] = None
_SHUTDOWN = "__nn3_decoder_shutdown__"


def _request_decoder_recovery() -> None:
    """Signal the rank-local watchdog to restart hung decoder workers."""
    if _RECOVERY_FLAG is None:
        return
    with _RECOVERY_FLAG.get_lock():
        _RECOVERY_FLAG.value += 1


def nn3_shared_decoder_worker_init(
    job_queue: "mp.Queue",
    result_queues: List["mp.Queue"],
    alive_counter: Any,
    recovery_flag: Any,
    worker_id: int,
) -> None:
    """Attach one DataLoader worker to its dedicated result queue."""
    Nn3SharedDecoderService.attach_client(
        job_queue=job_queue,
        result_queues=result_queues,
        alive_counter=alive_counter,
        recovery_flag=recovery_flag,
        client_id=int(worker_id) % max(1, len(result_queues)),
    )


def _decoder_job_timeout() -> float:
    return float(os.getenv("NN3_SHARED_DECODER_JOB_TIMEOUT", os.getenv("NN3_VT_DECODE_TIMEOUT", "240")))


def _decoder_process_main(
    worker_id: int,
    device_id: int,
    job_queue: "mp.Queue",
    result_queues: List["mp.Queue"],
    ready_queue: "mp.Queue",
    alive_counter: Any,
    video_shape: Optional[Dict],
    crop_shape: Optional[Dict],
    multiview_cams: Optional[list],
    inner_resize_crop: bool,
    job_started_time: Optional[Any] = None,
) -> None:
    """Own one CUDA/Argus decoder and serve jobs until shutdown."""
    os.environ["NN3_VT_DEVICE_ID"] = str(device_id)
    os.environ["LOCAL_RANK"] = str(device_id)
    filler = None
    loop = None
    job_timeout = _decoder_job_timeout()
    result_put_timeout = float(os.getenv("NN3_SHARED_DECODER_RESULT_PUT_TIMEOUT", "10"))
    try:
        from tpp_onemodel.data.plannn3.nn3_image_filler import Nn3ImageFiller
        from tpp_onemodel.data.plannn3.nn3_visual_cuda import init_nn3_visual_cuda

        if not init_nn3_visual_cuda(device_id):
            raise RuntimeError(f"cannot initialize NN3 VT CUDA on device {device_id}")
        filler = Nn3ImageFiller(
            device_id=device_id,
            video_shape=video_shape or {},
            crop_shape=crop_shape or {},
            multiview_cams=multiview_cams,
            inner_resize_crop=inner_resize_crop,
        )
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        ready_queue.put((worker_id, None))
    except Exception as exc:
        ready_queue.put((worker_id, repr(exc)))
        with alive_counter.get_lock():
            alive_counter.value -= 1
        return

    def _mark_job_started() -> None:
        if job_started_time is not None:
            with job_started_time.get_lock():
                job_started_time.value = time.time()

    def _mark_job_finished() -> None:
        if job_started_time is not None:
            with job_started_time.get_lock():
                job_started_time.value = 0.0

    try:
        while True:
            item = job_queue.get()
            if isinstance(item, tuple) and item and item[0] == _SHUTDOWN:
                break
            client_id, job_id, visual_meta = item
            result = None
            _mark_job_started()
            try:
                raw = loop.run_until_complete(
                    asyncio.wait_for(
                        filler.fill_with_sync(dict(visual_meta)),
                        timeout=job_timeout,
                    )
                )
                if raw:
                    result = {
                        key: value.detach().cpu().contiguous()
                        for key, value in raw.items()
                        if key.startswith("video:") and isinstance(value, torch.Tensor)
                    }
            except asyncio.TimeoutError:
                logger.error(
                    "NN3 decoder worker %s timed out after %.1fs on job %s",
                    worker_id,
                    job_timeout,
                    job_id,
                )
                try:
                    filler.reset_parser(reason=f"decoder worker {worker_id} job timeout")
                except Exception:
                    logger.exception("NN3 decoder worker %s parser reset failed", worker_id)
            except Exception:
                logger.exception("NN3 decoder worker %s failed job %s", worker_id, job_id)
                try:
                    filler.reset_parser(reason=f"decoder worker {worker_id} failure")
                except Exception:
                    logger.exception("NN3 decoder worker %s parser reset failed", worker_id)
            finally:
                _mark_job_finished()
            try:
                result_queues[client_id].put((job_id, result), timeout=result_put_timeout)
            except queue.Full:
                logger.warning(
                    "NN3 decoder worker %s dropped result for job %s: result queue %s full after %.1fs",
                    worker_id,
                    job_id,
                    client_id,
                    result_put_timeout,
                )
    finally:
        with alive_counter.get_lock():
            alive_counter.value -= 1
        try:
            if filler is not None:
                filler.stop()
        finally:
            if loop is not None:
                loop.close()


class Nn3SharedDecoderService:
    """Share a small number of GPU VT decoder contexts across DataLoader workers."""

    def __init__(
        self,
        job_queue: "mp.Queue",
        result_queues: List["mp.Queue"],
        alive_counter: Any,
        recovery_flag: Optional[Any] = None,
        client_id: int = 0,
        processes: Optional[List["mp.Process"]] = None,
        is_owner: bool = False,
        job_started_times: Optional[List[Any]] = None,
        spawn_context: Optional[Any] = None,
        spawn_args: Optional[Tuple[Any, ...]] = None,
        worker_target: Optional[Callable[..., None]] = None,
    ):
        self._job_queue = job_queue
        self._result_queues = result_queues
        self._alive_counter = alive_counter
        self._recovery_flag = recovery_flag
        self._client_id = client_id
        self._processes = processes or []
        self._is_owner = is_owner
        self._job_started_times = job_started_times or []
        self._spawn_context = spawn_context
        self._spawn_args = spawn_args
        self._worker_target = worker_target or _decoder_process_main
        self._watchdog_stop = threading.Event()
        self._watchdog_thread: Optional[threading.Thread] = None

    @property
    def job_queue(self) -> "mp.Queue":
        """Return the shared decoder job queue."""
        return self._job_queue

    @property
    def result_queues(self) -> List["mp.Queue"]:
        """Return per-DataLoader-worker result queues."""
        return self._result_queues

    @property
    def alive_counter(self) -> Any:
        """Return the shared live decoder count."""
        return self._alive_counter

    @property
    def client_id(self) -> int:
        """Return this process's result queue index."""
        return self._client_id

    def _decoders_alive(self) -> int:
        try:
            return int(self._alive_counter.value)
        except Exception:
            return 0

    @property
    def recovery_flag(self) -> Optional[Any]:
        """Return shared recovery trigger for client workers."""
        return self._recovery_flag

    def _reset_job_started_time(self, worker_id: int) -> None:
        if worker_id < len(self._job_started_times):
            with self._job_started_times[worker_id].get_lock():
                self._job_started_times[worker_id].value = 0.0

    def _sync_alive_counter(self) -> None:
        if not self._is_owner:
            return
        alive = sum(1 for process in self._processes if process.is_alive())
        with self._alive_counter.get_lock():
            self._alive_counter.value = alive

    def _put_job(self, item: Tuple[Any, ...]) -> None:
        put_timeout = float(os.getenv("NN3_SHARED_DECODER_PUT_TIMEOUT", "60"))
        try:
            self._job_queue.put(item, timeout=put_timeout)
        except queue.Full as exc:
            raise TimeoutError(
                f"NN3 shared decoder job queue full after {put_timeout:.1f}s "
                f"(alive={self._decoders_alive()})"
            ) from exc

    def decode(
        self,
        visual_meta: Dict[str, Any],
        timeout: Optional[float] = None,
    ) -> Optional[Dict[str, torch.Tensor]]:
        """Submit one clip and wait for the result routed to this client."""
        wait_timeout = timeout or float(os.getenv("NN3_SHARED_DECODER_TIMEOUT", "300"))
        job_id = uuid.uuid4().hex
        self._put_job((self._client_id, job_id, visual_meta))
        deadline = time.time() + wait_timeout
        result_queue = self._result_queues[self._client_id]
        while True:
            remaining = deadline - time.time()
            if remaining <= 0:
                _request_decoder_recovery()
                raise TimeoutError(f"NN3 shared decoder timed out after {wait_timeout}s")
            try:
                response_id, result = result_queue.get(timeout=min(remaining, 10))
            except queue.Empty:
                if self._decoders_alive() <= 0:
                    if self._is_owner:
                        self._respawn_dead_decoders()
                    raise RuntimeError("all NN3 shared decoder workers exited")
                continue
            if response_id != job_id:
                logger.warning(
                    "dropping stale NN3 decoder response %s for client %s",
                    response_id,
                    self._client_id,
                )
                continue
            return result

    def _spawn_decoder_process(self, worker_id: int, wait_ready: bool = False) -> "mp.Process":
        if self._spawn_context is None or self._spawn_args is None:
            raise RuntimeError("NN3 shared decoder spawn context is unavailable")
        (
            device_id,
            _worker_num,
            video_shape,
            crop_shape,
            multiview_cams,
            inner_resize_crop,
        ) = self._spawn_args
        job_started_time = self._job_started_times[worker_id] if worker_id < len(self._job_started_times) else None
        ready_queue = self._spawn_context.Queue()
        process = self._spawn_context.Process(
            target=self._worker_target,
            args=(
                worker_id,
                device_id,
                self._job_queue,
                self._result_queues,
                ready_queue,
                self._alive_counter,
                video_shape,
                crop_shape,
                multiview_cams,
                inner_resize_crop,
                job_started_time,
            ),
            daemon=True,
        )
        process.start()
        if wait_ready:
            startup_timeout = float(os.getenv("NN3_DECODER_STARTUP_TIMEOUT", "120"))
            try:
                _wid, error = ready_queue.get(timeout=startup_timeout)
            except queue.Empty as exc:
                if process.is_alive():
                    process.terminate()
                    process.join(timeout=5)
                raise RuntimeError(f"NN3 decoder worker {worker_id} respawn timed out") from exc
            if error is not None:
                if process.is_alive():
                    process.terminate()
                    process.join(timeout=5)
                raise RuntimeError(f"NN3 decoder worker {worker_id} respawn failed: {error}")
        return process

    def _respawn_dead_decoders(self) -> None:
        if not self._is_owner:
            return
        for worker_id, process in enumerate(self._processes):
            if process.is_alive():
                continue
            logger.warning("Restarting dead NN3 decoder worker %s", worker_id)
            try:
                self._reset_job_started_time(worker_id)
                self._processes[worker_id] = self._spawn_decoder_process(worker_id, wait_ready=True)
            except Exception:
                logger.exception("Failed to restart NN3 decoder worker %s", worker_id)
        self._sync_alive_counter()

    def _recover_hung_decoders(self, reason: str) -> None:
        if not self._is_owner:
            return
        hang_grace = float(os.getenv("NN3_DECODER_HANG_GRACE", "30"))
        job_timeout = _decoder_job_timeout()
        now = time.time()
        for worker_id, process in enumerate(self._processes):
            if not process.is_alive():
                continue
            started_at = 0.0
            if worker_id < len(self._job_started_times):
                with self._job_started_times[worker_id].get_lock():
                    started_at = float(self._job_started_times[worker_id].value)
            hung = started_at > 0.0 and (now - started_at) > (job_timeout + hang_grace)
            if not hung:
                continue
            logger.warning(
                "Terminating hung NN3 decoder worker %s (%s, started %.1fs ago)",
                worker_id,
                reason,
                now - started_at,
            )
            self._reset_job_started_time(worker_id)
            process.terminate()
            process.join(timeout=5)
            try:
                self._processes[worker_id] = self._spawn_decoder_process(worker_id, wait_ready=True)
            except Exception:
                logger.exception("Failed to restart hung NN3 decoder worker %s", worker_id)
        self._sync_alive_counter()

    def _watchdog_loop(self) -> None:
        poll_interval = float(os.getenv("NN3_DECODER_WATCHDOG_INTERVAL", "15"))
        while not self._watchdog_stop.wait(poll_interval):
            try:
                if _RECOVERY_FLAG is not None and _RECOVERY_FLAG.value > 0:
                    with _RECOVERY_FLAG.get_lock():
                        _RECOVERY_FLAG.value = 0
                    self._recover_hung_decoders(reason="client recovery request")
                self._respawn_dead_decoders()
                self._recover_hung_decoders(reason="watchdog")
                self._sync_alive_counter()
            except Exception:
                logger.exception("NN3 shared decoder watchdog failed")

    def _start_watchdog(self) -> None:
        if not self._is_owner or self._watchdog_thread is not None:
            return
        self._watchdog_thread = threading.Thread(
            target=self._watchdog_loop,
            name="nn3-decoder-watchdog",
            daemon=True,
        )
        self._watchdog_thread.start()

    def _stop_watchdog(self) -> None:
        if self._watchdog_thread is None:
            return
        self._watchdog_stop.set()
        self._watchdog_thread.join(timeout=5)
        self._watchdog_thread = None

    def close(self) -> None:
        """Stop decoder processes owned by this service."""
        if not self._is_owner:
            return
        self._stop_watchdog()
        for _process in self._processes:
            try:
                self._job_queue.put((_SHUTDOWN, None, None), timeout=5)
            except queue.Full:
                logger.warning("NN3 decoder shutdown message dropped because job queue is full")
        for process in self._processes:
            process.join(timeout=10)
            if process.is_alive():
                process.terminate()
                process.join(timeout=5)
        self._processes.clear()

    @classmethod
    def get(cls) -> Optional["Nn3SharedDecoderService"]:
        """Return the process-local service or attached client."""
        return _SERVICE

    @classmethod
    def start(
        cls,
        device_id: int,
        decoder_worker_num: int,
        num_result_queues: int,
        video_shape: Optional[Dict] = None,
        crop_shape: Optional[Dict] = None,
        multiview_cams: Optional[list] = None,
        inner_resize_crop: bool = True,
        worker_target: Optional[Callable[..., None]] = None,
    ) -> "Nn3SharedDecoderService":
        """Start the rank-local decoder workers and wait for readiness."""
        global _SERVICE
        global _RECOVERY_FLAG
        if _SERVICE is not None:
            return _SERVICE

        context = mp.get_context("spawn")
        _RECOVERY_FLAG = context.Value("i", 0)
        worker_num = max(1, int(decoder_worker_num))
        job_queue = context.Queue(maxsize=max(16, worker_num * 8))
        result_queues = [context.Queue(maxsize=4) for _ in range(max(1, int(num_result_queues)))]
        ready_queue = context.Queue()
        alive_counter = context.Value("i", worker_num)
        job_started_times = [context.Value("d", 0.0) for _ in range(worker_num)]
        target = worker_target or _decoder_process_main
        spawn_args = (
            device_id,
            worker_num,
            video_shape,
            crop_shape,
            multiview_cams,
            inner_resize_crop,
        )
        processes = []
        for worker_id in range(worker_num):
            process = context.Process(
                target=target,
                args=(
                    worker_id,
                    device_id,
                    job_queue,
                    result_queues,
                    ready_queue,
                    alive_counter,
                    video_shape,
                    crop_shape,
                    multiview_cams,
                    inner_resize_crop,
                    job_started_times[worker_id],
                ),
                daemon=True,
            )
            process.start()
            processes.append(process)

        startup_timeout = float(os.getenv("NN3_DECODER_STARTUP_TIMEOUT", "120"))
        deadline = time.time() + startup_timeout
        ready = 0
        try:
            while ready < worker_num:
                remaining = deadline - time.time()
                if remaining <= 0:
                    raise RuntimeError(f"NN3 shared decoder startup timed out: {ready}/{worker_num} ready")
                try:
                    worker_id, error = ready_queue.get(timeout=min(remaining, 5))
                except queue.Empty:
                    exited = [process.exitcode for process in processes if process.exitcode is not None]
                    if exited:
                        raise RuntimeError(f"NN3 shared decoder exited during startup: {exited}")
                    continue
                if error is not None:
                    raise RuntimeError(f"NN3 shared decoder worker {worker_id} failed startup: {error}")
                ready += 1
        except Exception:
            for process in processes:
                if process.is_alive():
                    process.terminate()
            for process in processes:
                process.join(timeout=5)
            raise

        _SERVICE = cls(
            job_queue=job_queue,
            result_queues=result_queues,
            alive_counter=alive_counter,
            recovery_flag=_RECOVERY_FLAG,
            processes=processes,
            is_owner=True,
            job_started_times=job_started_times,
            spawn_context=context,
            spawn_args=spawn_args,
            worker_target=target,
        )
        _SERVICE._start_watchdog()
        atexit.register(cls.shutdown)
        logger.info(
            "NN3 shared decoder ready: workers=%s device=%s clients=%s",
            worker_num,
            device_id,
            len(result_queues),
        )
        return _SERVICE

    @classmethod
    def attach_client(
        cls,
        job_queue: "mp.Queue",
        result_queues: List["mp.Queue"],
        alive_counter: Any,
        recovery_flag: Any,
        client_id: int,
    ) -> "Nn3SharedDecoderService":
        """Attach a spawned DataLoader worker to the rank-local service."""
        global _SERVICE
        global _RECOVERY_FLAG
        _RECOVERY_FLAG = recovery_flag
        _SERVICE = cls(
            job_queue=job_queue,
            result_queues=result_queues,
            alive_counter=alive_counter,
            recovery_flag=recovery_flag,
            client_id=client_id,
            is_owner=False,
        )
        return _SERVICE

    @classmethod
    def shutdown(cls) -> None:
        """Close and clear the process-local service."""
        global _SERVICE
        global _RECOVERY_FLAG
        if _SERVICE is not None:
            _SERVICE.close()
            _SERVICE = None
        _RECOVERY_FLAG = None
