# -*- coding: utf-8 -*-
"""NN3 clip bundle: nn3 Planning_DataHub + plann2_resample (with_nn2 meta)."""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from typing import Any
from typing import Dict
from typing import Optional
from typing import Tuple


@dataclass(frozen=True)
class Nn3ClipBundle:
    """Cached clip payloads for token + visual + navi paths."""

    nn3_clip: Dict[str, Any]
    resample_clip: Dict[str, Any]
    meta_line: str
    clip_tag: Optional[str] = None


def load_clip_bundle(
    meta_line: str,
    clip_tag: Optional[str] = None,
    need_road_boundary: bool = False,
) -> Nn3ClipBundle:
    """Load nn3 + resample with process-wide LRU cache."""
    return _load_clip_bundle_impl((clip_tag, meta_line.strip(), need_road_boundary))


def clear_clip_bundle_cache() -> None:
    """Clear bundle cache (e.g. after GC)."""
    _load_clip_bundle_impl.cache_clear()


@lru_cache(maxsize=32)
def _load_clip_bundle_impl(cache_key: Tuple[Optional[str], str, bool]) -> Nn3ClipBundle:
    clip_tag, meta_line, need_road_boundary = cache_key
    from tpp_onemodel.data.dataset.plannn3_dataset import _apply_post_load_processing
    from tpp_onemodel.data.dataset.plannn3_dataset import _ensure_frame_lane_defaults
    from tpp_onemodel.data.dataset.plannn3_dataset import _fill_envs_from_nn2
    from tpp_onemodel.data.dataset.plannn3_dataset import read_clip_info

    nn3_clip = read_clip_info(meta_line, clip_tag=clip_tag)
    resample_clip = nn3_clip.get("nn2_clip_info")
    if resample_clip is None:
        resample_clip = {key: value for key, value in nn3_clip.items() if key != "nn2_clip_info"}
    else:
        nn3_clip = _fill_envs_from_nn2(nn3_clip, resample_clip)
    _ensure_frame_lane_defaults(nn3_clip)
    nn3_clip = _apply_post_load_processing(
        nn3_clip,
        meta_line,
        clip_tag=clip_tag,
        need_road_boundary=need_road_boundary,
    )
    return Nn3ClipBundle(
        nn3_clip=nn3_clip,
        resample_clip=resample_clip,
        meta_line=meta_line,
        clip_tag=clip_tag,
    )
