# -*- coding: utf-8 -*-
"""CUDA setup for NN3 VT decode inside DataLoader workers."""

from __future__ import annotations

import logging
import os
from typing import Optional


logger = logging.getLogger(__name__)

_CUDA_READY: Optional[bool] = None
_CUDA_DEVICE_ID: Optional[int] = None


def _device_count() -> int:
    try:
        import torch

        return max(1, int(torch.cuda.device_count()))
    except Exception:
        return 1


def resolve_vt_device_id(explicit: Optional[int] = None) -> int:
    """Resolve the rank-local GPU already selected by the training process."""
    env_override = os.getenv("NN3_VT_DEVICE_ID")
    if env_override is not None:
        try:
            return int(env_override)
        except ValueError:
            pass
    if explicit is not None and explicit >= 0:
        return explicit
    try:
        import torch

        if torch.cuda.is_available() and torch.cuda.is_initialized():
            return int(torch.cuda.current_device())
    except Exception:
        pass
    local_rank = os.getenv("LOCAL_RANK")
    if local_rank is not None:
        try:
            return int(local_rank)
        except ValueError:
            pass
    rank = os.getenv("RANK")
    if rank is not None:
        try:
            return int(rank) % _device_count()
        except ValueError:
            pass
    return 0


def init_nn3_visual_cuda(device_id: int, force: bool = False) -> bool:
    """Initialize CUDA in the current process for argus VT (safe to call per worker)."""
    global _CUDA_READY, _CUDA_DEVICE_ID
    if not force and _CUDA_READY is not None and _CUDA_DEVICE_ID == device_id:
        return _CUDA_READY
    import torch

    if not torch.cuda.is_available():
        logger.warning("VT decode: CUDA is not available in this process")
        _CUDA_READY = False
        _CUDA_DEVICE_ID = device_id
        return False
    try:
        device_count = torch.cuda.device_count()
        if device_count < 1:
            _CUDA_READY = False
            _CUDA_DEVICE_ID = device_id
            return False
        safe_id = device_id % device_count
        torch.cuda.set_device(safe_id)
        torch.zeros(1, device=f"cuda:{safe_id}")
        torch.cuda.synchronize(safe_id)
        _CUDA_READY = True
        _CUDA_DEVICE_ID = safe_id
        return True
    except Exception as exc:
        logger.warning("VT decode: CUDA init failed on device %s: %s", device_id, exc)
        _CUDA_READY = False
        _CUDA_DEVICE_ID = device_id
        return False


__all__ = ["init_nn3_visual_cuda", "resolve_vt_device_id"]
