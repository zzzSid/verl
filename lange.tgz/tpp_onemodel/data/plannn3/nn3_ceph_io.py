# -*- coding: utf-8 -*-
"""Merged Ceph reads for NN3 VT video blocks."""

from __future__ import annotations

import re
from collections import defaultdict
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

from read_cache_op_py import read_cache_op_py


_VT_PATH_RE = re.compile(r"(.+?\.(?:h264|h265|tar)) (\d+) (\d+) (\d+)$")


def parse_vt_path(vt_path: str) -> Optional[Tuple[str, int, int, int]]:
    """Parse ``file total_size block_offset block_size`` from a VT path."""
    match = _VT_PATH_RE.match(vt_path.strip())
    if match is None:
        return None
    file_path, total_size, block_offset, block_size = match.groups()
    return file_path, int(total_size), int(block_offset), int(block_size)


def merge_vt_paths(path_list: List[str]) -> List[str]:
    """Merge block reads belonging to the same video into one contiguous range."""
    grouped: Dict[Tuple[str, int], List[Tuple[int, int]]] = defaultdict(list)
    passthrough: List[str] = []
    for vt_path in dict.fromkeys(path_list):
        parsed = parse_vt_path(vt_path)
        if parsed is None:
            passthrough.append(vt_path)
            continue
        file_path, total_size, block_offset, block_size = parsed
        grouped[(file_path, total_size)].append((block_offset, block_size))

    merged = []
    for (file_path, total_size), ranges in grouped.items():
        min_offset = min(offset for offset, _size in ranges)
        max_end = max(offset + size for offset, size in ranges)
        merged.append(f"{file_path} {total_size} {min_offset} {max_end - min_offset}")
    return merged + passthrough


def _slice_merged_buffer(
    merged_bytes: bytes,
    merged_vt_path: str,
    original_vt_path: str,
) -> bytes:
    """Return the original block slice from a merged read."""
    merged = parse_vt_path(merged_vt_path)
    original = parse_vt_path(original_vt_path)
    if merged is None or original is None:
        return merged_bytes
    start = original[2] - merged[2]
    return merged_bytes[start : start + original[3]]


def read_video_blocks_sync(path_list: List[str]) -> Dict[str, bytes]:
    """Read VT blocks synchronously, merging reads from the same video."""
    if not path_list:
        return {}
    unique_paths = list(dict.fromkeys(path_list))
    merged_paths = merge_vt_paths(unique_paths)
    merged_buffers = read_cache_op_py(merged_paths)
    merged_map = dict(zip(merged_paths, merged_buffers))

    outputs: Dict[str, bytes] = {}
    for vt_path in unique_paths:
        parsed = parse_vt_path(vt_path)
        if parsed is None:
            outputs[vt_path] = merged_map.get(vt_path, b"")
            continue
        matched_path = None
        for merged_path in merged_paths:
            merged = parse_vt_path(merged_path)
            if merged is None or merged[:2] != parsed[:2]:
                continue
            if merged[2] <= parsed[2] and merged[2] + merged[3] >= parsed[2] + parsed[3]:
                matched_path = merged_path
                break
        if matched_path is None:
            fallback = read_cache_op_py([vt_path])
            outputs[vt_path] = fallback[0] if fallback else b""
        else:
            outputs[vt_path] = _slice_merged_buffer(
                merged_map.get(matched_path, b""),
                matched_path,
                vt_path,
            )
    return outputs
