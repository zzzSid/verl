# -*- coding: utf-8 -*-
"""NN3 meta action manager (ported from plannn3 ``meta_action_manager.py``)."""

from __future__ import annotations

import logging
from dataclasses import asdict, dataclass, replace
from enum import IntEnum

import numpy as np
from scipy.interpolate import interp1d
from scipy.spatial.transform import Rotation, Slerp
from shapely.geometry import LineString, Point


LOGGER = logging.getLogger(__name__)


def ego2global(points, T=None):
    if T is None:
        return points
    if points.shape[1] == 2:
        pzeros = np.zeros((points.shape[0], 1), dtype=points.dtype)
        points = np.hstack((points, pzeros))
    outs = np.ones((points.shape[0], 4), dtype=np.float32)
    outs[:, :3] = points[:, :3]
    outs = (T @ outs.T).T
    points = points.copy()
    points[:, :3] = outs[:, :3]
    return points


def transform_obj(objs, T):
    objs = objs.copy()
    boxes = np.eye(4, 4, dtype=np.float32)
    boxes = np.array([boxes] * objs.shape[0], dtype=np.float32)
    cos = np.cos(objs[:, 6])
    sin = np.sin(objs[:, 6])
    boxes[:, 0, 0] = cos
    boxes[:, 0, 1] = -sin
    boxes[:, 1, 0] = sin
    boxes[:, 1, 1] = cos
    boxes[:, :3, 3] = objs[:, :3]
    boxes = np.matmul(T, boxes)
    objs[:, :3] = boxes[:, :3, 3]
    objs[:, 6] = np.arctan2(boxes[:, 1, 0], boxes[:, 0, 0])
    return objs


def parse_frame_env_v3(frame, T):
    """Parse raw environment information for one frame."""
    lanes = frame["manner_lane_points"]
    types = frame["manner_lane_types"]
    attrs = frame["manner_lane_attr"]

    hash_value = [l.sum() + t + a.sum() for l, t, a in zip(lanes, types, attrs)]
    filter_idx = np.unique(hash_value, return_index=True)[1]
    lanes = [lanes[i] for i in filter_idx]
    types = [types[i] for i in filter_idx]
    attrs = [attrs[i] for i in filter_idx]

    road_sign, lane_lines, road_edge, stop_line = [], [], [], []
    for p, t, a in zip(lanes, types, attrs):
        p = ego2global(p, T)
        if t == 0:
            lane_lines.append([p, a])
        elif t == 1:
            if len(p) > 1:
                road_edge.append(p)
        elif t == 2:
            stop_line.append(p)
        elif t == 3:
            road_sign.append([p, a[0][0]])
        else:
            raise ValueError(f"Unknown manner type: {t}")
    return road_sign, lane_lines, road_edge, stop_line


class LateralLabel(IntEnum):
    KEEP = 0
    LANE_CHANGE = 1
    TURN = 2
    U_TURN = 3
    NUDGE = 4
    INVALID = -100


class LongitudinalLabel(IntEnum):
    STOP = 0
    START_FROM_STOP = 1
    CREEP = 2
    UNIFORM = 3
    ACCEL = 4
    DECEL = 5
    DECEL_TO_STOP = 6
    INVALID = -100


@dataclass(frozen=True)
class MetaActionConfig:
    fps: int = 5
    step_size: float = 0.5
    window_m: float = 10.0
    distance_threshold: float = 2.0

    turn_duration_threshold_sec: float = 2.0
    turn_degree_threshold: float = 5.0
    lane_change_heading_threshold_deg: float = 15.0
    u_turn_threshold_deg: float = 100.0

    nudge_upper_threshold: float = 2.0
    nudge_lower_threshold: float = 0.25
    nudge_hump_distance_sec: float = 2.0

    max_search_frames: int = 25
    patience: int = 2
    min_peak_dist: float = 0.8
    min_duration_frames: int = 5
    lane_tangent_eps: float = 1.0
    max_lane_cross_angle_deg: float = 45.0
    no_lane_change_after_turn_sec: float = 1.0

    stop_speed_threshold: float = 0.3
    stop_accel_threshold: float = 0.2
    creep_speed_threshold: float = 1.5
    creep_speed_hysteresis: float = 0.2
    uniform_accel_threshold: float = 0.3
    accel_threshold: float = 0.5
    decel_threshold: float = -0.5
    stopping_accel_threshold: float = -0.3
    start_speed_threshold: float = 2.0
    start_max_duration_frames: int = 15
    lookahead_frames: int = 10
    lookback_frames: int = 10
    min_stop_duration_frames: int = 5
    min_segment_duration_frames: int = 5
    smooth_window_acc: int = 10

    default_lateral_label: int = int(LateralLabel.KEEP)
    default_longitudinal_label: int = int(LongitudinalLabel.UNIFORM)
    default_speed: float = 0.0
    default_acceleration: float = 0.0


@dataclass
class EgoTrajectoryState:
    timestamps: np.ndarray
    poses_array: np.ndarray
    pose_distance: np.ndarray
    full_motion: np.ndarray
    base_pose: np.ndarray


class EgoTrajectoryParser:
    def __init__(self, fps=5, step_size=0.5, window_m=10.0, distance_threshold=2.0):
        self.fps = fps
        self.step_size = step_size
        self.window_m = window_m
        self.distance_threshold = distance_threshold

    @staticmethod
    def inverse_transform(pose: np.ndarray):
        pose_inv = np.eye(4, dtype=pose.dtype)
        pose_inv[0:3, 0:3] = pose[0:3, 0:3].T
        pose_inv[0:3, 3] = -pose_inv[0:3, 0:3] @ pose[0:3, 3]
        return pose_inv

    @staticmethod
    def _rotation_to_yaw(rotation_mats: np.ndarray) -> np.ndarray:
        if len(rotation_mats) == 0:
            return np.zeros((0,), dtype=np.float64)
        yaw = Rotation.from_matrix(rotation_mats).as_euler("zyx", degrees=False)[:, 0]
        return np.unwrap(yaw)

    @staticmethod
    def _compute_motion_from_pose(timestamps: np.ndarray, poses: np.ndarray):
        num_frames = len(timestamps)
        if num_frames == 0:
            return np.zeros((0, 3), dtype=np.float32)
        if num_frames == 1:
            return np.zeros((1, 3), dtype=np.float32)

        positions = poses[:, :2, 3]
        yaw = EgoTrajectoryParser._rotation_to_yaw(poses[:, :3, :3])
        delta_t = np.maximum(np.diff(timestamps), 1e-3)

        speed = np.linalg.norm(np.diff(positions, axis=0), axis=1) / delta_t
        yaw_rate = np.diff(yaw) / delta_t

        vehspd = np.empty(num_frames, dtype=np.float32)
        vehspd[:-1] = speed.astype(np.float32)
        vehspd[-1] = vehspd[-2]

        yaw_rate_full = np.empty(num_frames, dtype=np.float32)
        yaw_rate_full[:-1] = yaw_rate.astype(np.float32)
        yaw_rate_full[-1] = yaw_rate_full[-2]

        return np.stack([vehspd, yaw_rate_full, yaw_rate_full], axis=1)

    def init(self, data):
        timestamps = np.array(sorted(data["timestamp_list"]), dtype=np.float64)
        if len(timestamps) == 0:
            return False

        full_car_pose = np.array([data[_ts]["car_pose"] for _ts in timestamps], dtype=np.float64)
        base_pose = full_car_pose[0]
        base_pose_inv = self.inverse_transform(base_pose)
        poses_array = np.einsum("ij,tjk->tik", base_pose_inv, full_car_pose)

        has_ego_motion = all(
            "ego_motion" in data[_ts]
            and data[_ts]["ego_motion"] is not None
            and len(data[_ts]["ego_motion"]) > 10
            for _ts in timestamps
        )
        if has_ego_motion:
            full_motion = np.array(
                [(data[_ts]["ego_motion"][8], data[_ts]["ego_motion"][5], data[_ts]["ego_motion"][10]) for _ts in timestamps],
                dtype=np.float32,
            )
        else:
            full_motion = self._compute_motion_from_pose(timestamps, full_car_pose)

        self.state = EgoTrajectoryState(
            timestamps=timestamps,
            poses_array=poses_array,
            pose_distance=np.zeros((len(timestamps),), dtype=np.float32),
            full_motion=np.array(full_motion, dtype=np.float32),
            base_pose=base_pose,
        )

        if not self._init_interpolator():
            return False
        self._build_traj_curve()
        return True

    def _init_interpolator(self) -> bool:
        pose_stamp = self.state.timestamps
        pose_position = self.state.poses_array[:, :3, 3]
        pose_rotation = self.state.poses_array[:, :3, :3]

        pose_distance = np.zeros((len(pose_stamp),), dtype=np.float32)
        if len(pose_stamp) > 1:
            delta = np.linalg.norm(np.diff(pose_position, axis=0), axis=1)
            pose_distance[1:] = np.cumsum(np.maximum(delta, 1e-3))
        self.state.pose_distance = pose_distance

        if pose_distance[-1] < self.distance_threshold:
            LOGGER.warning(
                "Clip total distance %.2fm is less than threshold %.2fm.",
                pose_distance[-1],
                self.distance_threshold,
            )
            return False

        self.slerp_distance = interp1d(
            pose_stamp,
            pose_distance,
            kind="linear",
            axis=0,
            bounds_error=False,
            fill_value="extrapolate",
        )
        self.slerp_position = interp1d(
            pose_distance,
            pose_position,
            kind="linear",
            axis=0,
            bounds_error=False,
            fill_value="extrapolate",
        )
        self.slerp_rotation = Slerp(pose_distance, Rotation.from_matrix(pose_rotation))

        yaw = self._rotation_to_yaw(pose_rotation)
        yaw_rate = np.zeros((len(yaw),), dtype=np.float32)
        if len(yaw) > 1:
            delta_yaw = np.diff(yaw)
            yaw_rate[:-1] = (delta_yaw * self.fps).astype(np.float32)
            yaw_rate[-1] = yaw_rate[-2]
        self.state.full_motion = np.concatenate([self.state.full_motion, yaw_rate[:, None]], axis=1)
        self.slerp_motion = interp1d(
            pose_stamp,
            self.state.full_motion,
            kind="linear",
            axis=0,
            bounds_error=False,
            fill_value="extrapolate",
        )
        return True

    def _build_traj_curve(self):
        total_distance = float(self.state.pose_distance[-1])
        num_steps = int(total_distance / self.step_size) + 1
        traj_distances = np.linspace(0, total_distance, num_steps, endpoint=True, dtype=np.float32)
        traj_distances = np.clip(traj_distances, 0, total_distance)

        ego_rotations = self.slerp_rotation(traj_distances).as_matrix()
        ego_headings = self._rotation_to_yaw(ego_rotations)
        ego_delta = np.zeros((len(ego_headings),), dtype=np.float32)
        if len(ego_headings) > 1:
            ego_delta[1:] = np.diff(ego_headings).astype(np.float32)
            ego_delta[0] = ego_delta[1]

        deg_accumu_wind = np.zeros((len(traj_distances),), dtype=np.float32)
        for idx in range(len(traj_distances)):
            wind_end = min(len(traj_distances) - 1, idx + int(self.window_m))
            deg_accumu_wind[idx] = np.degrees(np.sum(ego_delta[idx:wind_end]))

        self.slerp_deg_accumu = interp1d(
            traj_distances,
            deg_accumu_wind,
            kind="linear",
            axis=0,
            bounds_error=False,
            fill_value="extrapolate",
        )

    @property
    def poses_array(self):
        return self.state.poses_array

    def get_pose_by_timestamp(self, timestamp: float):
        distance = self.slerp_distance(timestamp)
        return self.get_pose_by_distance(float(distance))

    def get_pose_by_distance(self, distance: float):
        position = self.slerp_position(distance)
        rotation = self.slerp_rotation(distance).as_matrix()
        pose = np.eye(4, dtype=np.float32)
        pose[:3, :3] = rotation
        pose[:3, 3] = position
        return pose

    def get_motion_by_timestamp(self, timestamp: float):
        return self.slerp_motion(timestamp)

    def get_deg_accumu_by_timestamp(self, timestamp: float):
        distance = self.slerp_distance(timestamp)
        return self.get_deg_accumu_by_distance(float(distance))

    def get_deg_accumu_by_distance(self, distance: float):
        return self.slerp_deg_accumu(distance)


def smooth_signal(signal: np.ndarray, window: int = 3) -> np.ndarray:
    if len(signal) == 0 or window <= 1:
        return signal
    kernel = np.ones(window, dtype=np.float32) / window
    return np.convolve(signal, kernel, mode="same")


class MetaActionManager:
    THRE_TIME_TURN = 2.0
    THRE_TURN = 5.0
    THRE_LANE_CHANGE_DEG = 15.0
    THRE_U_TURN_DEG = 100.0
    THRE_NUDGE_UPPDER = 2.0
    THRE_NUDGE_LOWER = 0.25
    THRE_NUDGE_HUMP_DIST = 2.0
    LABEL_KEEP = int(LateralLabel.KEEP)
    LABEL_LANE_CHANGE = int(LateralLabel.LANE_CHANGE)
    LABEL_TURN_CHANGE = int(LateralLabel.TURN)
    LABEL_U_TURN = int(LateralLabel.U_TURN)
    LABEL_NUDGE = int(LateralLabel.NUDGE)

    MAX_SEARCH_FRAMES = 25
    PATIENCE = 2
    MIN_PEAK_DIST = 0.8
    MIN_DURATION = 5
    LANE_TANGENT_EPS = 1.0
    MAX_LANE_CROSS_ANGLE_DEG = 45.0
    NO_LANE_CHANGE_AFTER_TURN_SEC = 1.0

    THRE_STOP_SPEED = 0.25
    THRE_CREEP_SPEED = 1.0
    THRE_CREEP_SPEED_HYSTERESIS = 1.0
    THRE_ACCEL = 1.0
    THRE_DECEL = -1.0
    SMOOTH_WINDOW_ACC = 10
    LOOKAHEAD_FRAMES = 10
    LOOKBACK_FRAMES = 10
    MIN_STOP_DURATION_FRAMES = 15
    LABEL_STOP = int(LongitudinalLabel.STOP)
    LABEL_START_FROM_STOP = int(LongitudinalLabel.START_FROM_STOP)
    LABEL_CREEP = int(LongitudinalLabel.CREEP)
    LABEL_UNIFORM = int(LongitudinalLabel.UNIFORM)
    LABEL_ACCEL = int(LongitudinalLabel.ACCEL)
    LABEL_DECEL = int(LongitudinalLabel.DECEL)
    LABEL_DECEL_TO_STOP = int(LongitudinalLabel.DECEL_TO_STOP)

    LONGITUDE_LABEL_NUM = 7
    LONGITUDE_LABELS_MAP = {
        int(LongitudinalLabel.STOP): 0,
        int(LongitudinalLabel.START_FROM_STOP): 1,
        int(LongitudinalLabel.CREEP): 2,
        int(LongitudinalLabel.UNIFORM): 3,
        int(LongitudinalLabel.ACCEL): 4,
        int(LongitudinalLabel.DECEL): 5,
        int(LongitudinalLabel.DECEL_TO_STOP): 6,
    }
    LATITUDE_LABEL_NUM = 7
    LATITUDE_LABELS_MAP = {
        -int(LateralLabel.U_TURN): 0,
        -int(LateralLabel.TURN): 1,
        -int(LateralLabel.LANE_CHANGE): 2,
        int(LateralLabel.KEEP): 3,
        int(LateralLabel.LANE_CHANGE): 4,
        int(LateralLabel.TURN): 5,
        int(LateralLabel.U_TURN): 6,
    }

    def __init__(self, config: MetaActionConfig | None = None, **overrides):
        self.config = replace(config or MetaActionConfig(), **overrides)
        self._sync_legacy_attributes()

    def _sync_legacy_attributes(self):
        self.fps = self.config.fps
        self.step_size = self.config.step_size
        self.window_m = self.config.window_m

        self.THRE_TIME_TURN = self.config.turn_duration_threshold_sec
        self.THRE_TURN = self.config.turn_degree_threshold
        self.THRE_LANE_CHANGE_DEG = self.config.lane_change_heading_threshold_deg
        self.THRE_U_TURN_DEG = self.config.u_turn_threshold_deg
        self.THRE_NUDGE_UPPDER = self.config.nudge_upper_threshold
        self.THRE_NUDGE_LOWER = self.config.nudge_lower_threshold
        self.THRE_NUDGE_HUMP_DIST = self.config.nudge_hump_distance_sec

        self.MAX_SEARCH_FRAMES = self.config.max_search_frames
        self.PATIENCE = self.config.patience
        self.MIN_PEAK_DIST = self.config.min_peak_dist
        self.MIN_DURATION = self.config.min_duration_frames
        self.LANE_TANGENT_EPS = self.config.lane_tangent_eps
        self.MAX_LANE_CROSS_ANGLE_DEG = self.config.max_lane_cross_angle_deg
        self.NO_LANE_CHANGE_AFTER_TURN_SEC = self.config.no_lane_change_after_turn_sec

        self.THRE_STOP_SPEED = self.config.stop_speed_threshold
        self.THRE_STOP_ACCEL = self.config.stop_accel_threshold
        self.THRE_CREEP_SPEED = self.config.creep_speed_threshold
        self.THRE_CREEP_SPEED_HYSTERESIS = self.config.creep_speed_hysteresis
        self.THRE_UNIFORM_ACCEL = self.config.uniform_accel_threshold
        self.THRE_ACCEL = self.config.accel_threshold
        self.THRE_DECEL = self.config.decel_threshold
        self.THRE_STOPPING_ACCEL = self.config.stopping_accel_threshold
        self.THRE_START_SPEED = self.config.start_speed_threshold
        self.START_MAX_DURATION_FRAMES = self.config.start_max_duration_frames
        self.SMOOTH_WINDOW_ACC = self.config.smooth_window_acc
        self.LOOKAHEAD_FRAMES = self.config.lookahead_frames
        self.LOOKBACK_FRAMES = self.config.lookback_frames
        self.MIN_STOP_DURATION_FRAMES = self.config.min_stop_duration_frames
        self.MIN_SEGMENT_DURATION_FRAMES = self.config.min_segment_duration_frames

    def _default_status(self, idx: int, error: str | None = None):
        status = {
            "valid": False,
            "idx": idx,
            "lateral": int(self.config.default_lateral_label),
            "longitudinal": int(self.config.default_longitudinal_label),
            "closest_lane_dist": float("inf"),
            "vehspd": float(self.config.default_speed),
            "yaw_rate": 0.0,
            "chessis_yawrate": 0.0,
            "delta_yaw": 0.0,
            "deg_accumu": 0.0,
            "speed": float(self.config.default_speed),
            "acceleration": float(self.config.default_acceleration),
            "acceleration_raw": float(self.config.default_acceleration),
            "is_fallback": error is not None,
        }
        if error is not None:
            status["error"] = error
        return status

    def _build_default_clip_status(self, timestamps, error: str | None = None):
        return [self._default_status(idx, error) for idx, _ in enumerate(timestamps)]

    @staticmethod
    def _signed_label(base_label: int, direction: float) -> int:
        if direction == 0:
            return 0
        return base_label if direction > 0 else -base_label

    def _mark_frame_error(self, clip_motion_status: list, index: int, error: str):
        clip_motion_status[index]["is_fallback"] = True
        clip_motion_status[index]["error"] = error

    def _create_ego_traj_parser(self):
        return EgoTrajectoryParser(
            fps=self.config.fps,
            step_size=self.config.step_size,
            window_m=self.config.window_m,
            distance_threshold=self.config.distance_threshold,
        )

    def _build_ego_motion_features(self, ego_traj: EgoTrajectoryParser, timestamps: np.ndarray):
        ego_motions = np.array([ego_traj.get_motion_by_timestamp(ts) for ts in timestamps], dtype=np.float32)
        ego_motions[:, 1:] = np.degrees(ego_motions[:, 1:])
        ego_deg_accumu = np.array([ego_traj.get_deg_accumu_by_timestamp(ts) for ts in timestamps], dtype=np.float32)
        ego_motions = np.concatenate([ego_motions, ego_deg_accumu[:, None]], axis=1)
        return ego_motions, ego_deg_accumu

    def _populate_motion_fields(self, clip_motion_status: list, ego_motions: np.ndarray):
        
        for ego_motion, status in zip(ego_motions, clip_motion_status):
            status["vehspd"] = float(ego_motion[0])
            status["yaw_rate"] = float(ego_motion[1])
            status["chessis_yawrate"] = float(ego_motion[2])
            status["delta_yaw"] = float(ego_motion[3])
            status["deg_accumu"] = float(ego_motion[4])

        N = len(ego_motions)
        speeds = ego_motions[:, 0]
        acce_raw = np.zeros(N, dtype=np.float32)
        if N > 1:
            acce_raw[:-1] = np.diff(speeds) * self.fps
            acce_raw[-1] = acce_raw[-2]
        accelerations = smooth_signal(acce_raw, window=self.SMOOTH_WINDOW_ACC)
        for idx in range(N):
            clip_motion_status[idx]["acceleration_raw"] = float(acce_raw[idx])
            clip_motion_status[idx]["acceleration"] = float(accelerations[idx])

    @staticmethod
    def _iter_segments(labels: np.ndarray):
        if len(labels) == 0:
            return
        start = 0
        current = labels[0]
        for idx in range(1, len(labels)):
            if labels[idx] != current:
                yield start, idx - 1, current
                start = idx
                current = labels[idx]
        yield start, len(labels) - 1, current

    def _apply_turn_labels(self, clip_motion_status: list, ego_deg_accumu: np.ndarray, egocenter_pose: np.ndarray):
        for idx, deg_accumu in enumerate(ego_deg_accumu):
            if abs(deg_accumu) >= self.THRE_TURN:
                clip_motion_status[idx]["lateral"] = self._signed_label(self.LABEL_TURN_CHANGE, deg_accumu)

        labels = np.array([status["lateral"] for status in clip_motion_status], dtype=np.int32)
        min_turn_frames = int(self.THRE_TIME_TURN * self.fps)
        for start_idx, end_idx, label in self._iter_segments(labels):
            if abs(label) != self.LABEL_TURN_CHANGE:
                continue

            duration = end_idx - start_idx + 1
            if duration < min_turn_frames:
                for idx in range(start_idx, end_idx + 1):
                    clip_motion_status[idx]["lateral"] = self.LABEL_KEEP
                continue

            start_pose = egocenter_pose[start_idx]
            end_pose = egocenter_pose[end_idx]
            start_yaw = np.arctan2(start_pose[1, 0], start_pose[0, 0])
            end_yaw = np.arctan2(end_pose[1, 0], end_pose[0, 0])
            yaw_diff = np.degrees(np.unwrap(np.array([start_yaw, end_yaw]))[1] - np.unwrap(np.array([start_yaw, end_yaw]))[0])

            if abs(yaw_diff) < self.THRE_LANE_CHANGE_DEG:
                new_label = self.LABEL_KEEP
            elif abs(yaw_diff) >= self.THRE_U_TURN_DEG:
                new_label = self._signed_label(self.LABEL_U_TURN, label)
            else:
                continue

            for idx in range(start_idx, end_idx + 1):
                clip_motion_status[idx]["lateral"] = new_label

    def _extract_lane_lines(self, frame, ego_pose):
        _, lane_lines, _, _ = parse_frame_env_v3(frame, ego_pose)
        valid_lane_lines = []
        for lane_line, _ in lane_lines:
            if len(lane_line) > 2:
                valid_lane_lines.append(LineString(lane_line))
        return valid_lane_lines

    def _check_hump(self, yaw_rate, N, start_idx):
        i = start_idx
        hump_direction = np.sign(yaw_rate[i])
        while i < N and abs(yaw_rate[i]) >= self.THRE_NUDGE_LOWER:
            i += 1

        if i >= N:
            return False, N, hump_direction
        return True, i, hump_direction

    def _check_nudge(self, yaw_rate, timestamps, clip_motion_status):
        yaw_rate = smooth_signal(yaw_rate, window=3)

        i = 0
        N = len(timestamps)
        last_hump = None
        while i < N:
            if abs(yaw_rate[i]) > self.THRE_NUDGE_UPPDER:
                hump_start_idx = i
                is_hump, hump_end_idx, hump_dir = self._check_hump(yaw_rate, N, i)
                i = hump_end_idx

                if not is_hump:
                    continue

                cur_hump = {"start_idx": hump_start_idx, "end_idx": hump_end_idx, "direction": hump_dir}
                if last_hump and last_hump["direction"] == -hump_dir:
                    time_dist = (hump_start_idx - last_hump["end_idx"]) / self.fps
                    if time_dist <= self.THRE_NUDGE_HUMP_DIST:
                        nudge_label = -self.LABEL_NUDGE if last_hump["direction"] == -1 else self.LABEL_NUDGE
                        has_other_action = any(
                            clip_motion_status[j]["lateral"] != self.LABEL_KEEP
                            for j in range(last_hump["start_idx"], cur_hump["end_idx"])
                        )
                        if has_other_action:
                            last_hump = None
                            continue
                        for j in range(last_hump["start_idx"], cur_hump["end_idx"]):
                            clip_motion_status[j]["lateral"] = nudge_label
                    else:
                        last_hump = cur_hump
                else:
                    last_hump = cur_hump
            else:
                i += 1
        return clip_motion_status

    def _get_local_lane_tangent(self, lane_line: LineString, anchor_distance: float) -> np.ndarray | None:
        line_length = lane_line.length
        if line_length <= 1e-6:
            return None

        eps = min(self.LANE_TANGENT_EPS, max(line_length * 0.1, 0.2))
        start_dist = max(0.0, anchor_distance - eps)
        end_dist = min(line_length, anchor_distance + eps)
        if end_dist - start_dist <= 1e-6:
            return None

        start_point = np.array(lane_line.interpolate(start_dist).coords[0][:2], dtype=np.float32)
        end_point = np.array(lane_line.interpolate(end_dist).coords[0][:2], dtype=np.float32)
        tangent = end_point - start_point
        tangent_norm = np.linalg.norm(tangent)
        if tangent_norm <= 1e-6:
            return None
        return tangent / tangent_norm

    @staticmethod
    def _get_intersection_point(ego_move_line: LineString, lane_line: LineString) -> np.ndarray | None:
        intersection = ego_move_line.intersection(lane_line)
        if intersection.is_empty:
            return None
        if intersection.geom_type == "Point":
            return np.array(intersection.coords[0][:2], dtype=np.float32)
        if intersection.geom_type == "MultiPoint":
            ego_start = np.array(ego_move_line.coords[0][:2], dtype=np.float32)
            points = [np.array(point.coords[0][:2], dtype=np.float32) for point in intersection.geoms]
            distances = [np.linalg.norm(point - ego_start) for point in points]
            return points[int(np.argmin(distances))]
        return None

    @staticmethod
    def _get_crossing_angle_deg(lane_tangent: np.ndarray, ego_direction: np.ndarray) -> float:
        cosine = float(np.clip(abs(np.dot(lane_tangent, ego_direction)), 0.0, 1.0))
        return float(np.degrees(np.arccos(cosine)))

    @staticmethod
    def _get_lane_change_normal(lane_tangent: np.ndarray, ego_direction: np.ndarray) -> np.ndarray:
        ego_left = np.array([-ego_direction[1], ego_direction[0]], dtype=np.float32)
        normal = np.array([-lane_tangent[1], lane_tangent[0]], dtype=np.float32)
        if np.dot(normal, ego_left) < 0:
            normal = -normal
        return normal

    @staticmethod
    def _get_signed_offset(point_xy: np.ndarray, anchor_xy: np.ndarray, normal: np.ndarray) -> float:
        return float(np.dot(point_xy - anchor_xy, normal))

    def _infer_lane_change_direction(self, ego_move_line: LineString, lane_line: LineString) -> int:
        if ego_move_line.length <= 1e-6 or lane_line.length <= 1e-6:
            return 0
        if not ego_move_line.crosses(lane_line):
            return 0

        intersection_xy = self._get_intersection_point(ego_move_line, lane_line)
        if intersection_xy is None:
            return 0

        ego_start = np.array(ego_move_line.coords[0][:2], dtype=np.float32)
        ego_end = np.array(ego_move_line.coords[1][:2], dtype=np.float32)
        ego_direction = ego_end - ego_start
        ego_direction_norm = np.linalg.norm(ego_direction)
        if ego_direction_norm <= 1e-6:
            return 0
        ego_direction = ego_direction / ego_direction_norm

        anchor_distance = lane_line.project(Point(intersection_xy))
        lane_tangent = self._get_local_lane_tangent(lane_line, anchor_distance)
        if lane_tangent is None:
            return 0

        crossing_angle = self._get_crossing_angle_deg(lane_tangent, ego_direction)
        if crossing_angle > self.MAX_LANE_CROSS_ANGLE_DEG:
            return 0

        lane_normal = self._get_lane_change_normal(lane_tangent, ego_direction)
        start_offset = self._get_signed_offset(ego_start, intersection_xy, lane_normal)
        end_offset = self._get_signed_offset(ego_end, intersection_xy, lane_normal)
        offset_delta = end_offset - start_offset
        if abs(offset_delta) <= 1e-4:
            return 0
        return 1 if offset_delta > 0 else -1

    def _scan_lane_crossings(self, ego_move_line: LineString, lane_lines: list[LineString], ego_position: np.ndarray):
        closest_lane_dist = float("inf")
        cross_direction = 0
        direction_lane_dist = float("inf")

        for lane_line in lane_lines:
            dist = lane_line.distance(Point(ego_position))
            closest_lane_dist = min(closest_lane_dist, float(dist))

            lane_direction = self._infer_lane_change_direction(ego_move_line, lane_line)
            if lane_direction != 0 and dist <= direction_lane_dist:
                direction_lane_dist = float(dist)
                cross_direction = lane_direction

        return closest_lane_dist, cross_direction

    def _apply_lane_change_labels(self, data, timestamps, egocenter_pose, clip_motion_status):
        num_frames = len(timestamps)
        for idx, ts in enumerate(timestamps):
            ego_pose = egocenter_pose[idx]
            next_ego_pose = egocenter_pose[idx + 1] if idx + 1 < num_frames else egocenter_pose[idx]
            ego_move_line = LineString([ego_pose[:2, 3], next_ego_pose[:2, 3]])

            try:
                lane_lines = self._extract_lane_lines(data[ts], ego_pose)
                closest_lane_dist, cross_direction = self._scan_lane_crossings(
                    ego_move_line=ego_move_line,
                    lane_lines=lane_lines,
                    ego_position=ego_pose[:2, 3],
                )
            except Exception as exc:
                self._mark_frame_error(clip_motion_status, idx, f"lane_parse_failed: {exc}")
                continue

            clip_motion_status[idx]["closest_lane_dist"] = closest_lane_dist
            if idx != 0 and clip_motion_status[idx]["lateral"] == self.LABEL_KEEP and cross_direction != 0:
                clip_motion_status[idx]["lateral"] = cross_direction

    def _compute_longitudinal_status(self, ego_motions: np.ndarray, clip_motion_status: list):
        """
        计算纵向标签，按照设计文档 docs/meta_action_longitude.md 的规则。

        优先级顺序：
        1. STOP
        2. STOPPING (DECEL_TO_STOP)
        3. START (START_FROM_STOP) — 优先于 ACCEL，可覆盖 ACCEL
        4. ACCEL
        5. DECEL
        6. CREEP
        7. UNIFORM
        """
        N = len(clip_motion_status)
        if N == 0:
            return clip_motion_status

        # Pass 1: 基础标签分配 (STOP / ACCEL / DECEL / CREEP / UNIFORM)
        half_hyst = self.THRE_CREEP_SPEED_HYSTERESIS / 2.0
        creep_upper = self.THRE_CREEP_SPEED + half_hyst
        creep_lower = self.THRE_CREEP_SPEED - half_hyst

        labels = np.full(N, self.LABEL_UNIFORM, dtype=np.int32)
        prev_creep_uniform = self.LABEL_UNIFORM

        for i in range(N):
            speed = clip_motion_status[i]["vehspd"]
            accel = clip_motion_status[i]["acceleration"]

            labels[i] = self.LABEL_UNIFORM

            # CREEP (带滞回)
            if prev_creep_uniform == self.LABEL_CREEP:
                if speed < creep_upper:
                    labels[i] = self.LABEL_CREEP
            else:
                if speed < creep_lower:
                    labels[i] = self.LABEL_CREEP

            if labels[i] in (self.LABEL_CREEP, self.LABEL_UNIFORM):
                prev_creep_uniform = labels[i]

            if accel <= self.THRE_DECEL:
                labels[i] = self.LABEL_DECEL

            if accel >= self.THRE_ACCEL:
                labels[i] = self.LABEL_ACCEL

            if speed < self.THRE_STOP_SPEED:
                labels[i] = self.LABEL_STOP

        # Pass 1.5: 修正 clip 末尾平滑延迟导致的 ACCEL/DECEL 误判
        # 均值滤波(窗口10)有 ~5 帧延迟，当加速度突降时平滑值滞后。
        # 只修正末尾连续的 ACCEL/DECEL 段中原始加速度已不满足条件的帧。
        # 注意：使用 epsilon 容差避免浮点精度问题。
        eps = 1e-3
        if N > 0:
            # 从末尾向前找连续的 ACCEL 段
            i = N - 1
            while i >= 0 and labels[i] == self.LABEL_ACCEL:
                accel_raw = clip_motion_status[i]["acceleration_raw"]
                if accel_raw < self.THRE_ACCEL - eps:
                    speed = clip_motion_status[i]["vehspd"]
                    labels[i] = self.LABEL_CREEP if speed < self.THRE_CREEP_SPEED else self.LABEL_UNIFORM
                else:
                    break  # 遇到原始加速度仍满足条件的帧，停止修正
                i -= 1

            # 从末尾向前找连续的 DECEL 段
            i = N - 1
            while i >= 0 and labels[i] == self.LABEL_DECEL:
                accel_raw = clip_motion_status[i]["acceleration_raw"]
                if accel_raw > self.THRE_DECEL + eps:
                    speed = clip_motion_status[i]["vehspd"]
                    labels[i] = self.LABEL_CREEP if speed < self.THRE_CREEP_SPEED else self.LABEL_UNIFORM
                else:
                    break
                i -= 1

        # Pass 2: STOPPING (减速至停车)
        for i in range(N):
            if labels[i] == self.LABEL_STOP:
                continue

            accel = clip_motion_status[i]["acceleration"]
            if accel > self.THRE_STOPPING_ACCEL:
                continue

            lookahead_end = min(N, i + self.LOOKAHEAD_FRAMES + 1)
            for j in range(i + 1, lookahead_end):
                if labels[j] == self.LABEL_STOP:
                    labels[i] = self.LABEL_DECEL_TO_STOP
                    break

        # Pass 3: START_FROM_STOP (停车起步)
        # 优先级高于 ACCEL/UNIFORM，但低于 CREEP。
        # 遇到 CREEP 帧时停止标记。
        self._apply_start_from_stop(labels, clip_motion_status, N)

        # Pass 4: 保持走走停停场景下的 CREEP 连续性
        self._preserve_creep_continuity(labels, clip_motion_status)

        # Pass 5: 短片段过滤
        labels = self._merge_short_segments(labels)

        for idx in range(N):
            clip_motion_status[idx]["longitudinal"] = int(labels[idx])

        return clip_motion_status

    def _apply_start_from_stop(self, labels: np.ndarray, clip_motion_status: list, N: int):
        """
        从每个持续 >= min_stop_duration 的 STOP 段末尾开始向前扫描，
        将速度 < start_speed_threshold 的连续帧标记为 START_FROM_STOP。

        条件：
        - 前方存在持续 >= min_stop_duration_frames 的 STOP 段
        - 当前帧不是 STOP
        - 速度 < start_speed_threshold (2.0 m/s)
        - 距离 STOP 段末尾不超过 start_max_duration_frames 帧

        CREEP 优先级高于 START_FROM_STOP，不会被覆盖。
        START_FROM_STOP 优先级高于 ACCEL/UNIFORM，会覆盖它们。
        """
        i = 0
        while i < N:
            if labels[i] != self.LABEL_STOP:
                i += 1
                continue

            stop_start = i
            while i < N and labels[i] == self.LABEL_STOP:
                i += 1
            stop_end = i

            stop_duration = stop_end - stop_start
            if stop_duration < self.MIN_STOP_DURATION_FRAMES:
                continue

            max_end = min(N, stop_end + self.START_MAX_DURATION_FRAMES)
            for j in range(stop_end, max_end):
                speed = clip_motion_status[j]["vehspd"]
                if speed >= self.THRE_START_SPEED:
                    break
                if labels[j] in (self.LABEL_STOP, self.LABEL_CREEP):
                    break
                labels[j] = self.LABEL_START_FROM_STOP

    def _preserve_creep_continuity(self, labels: np.ndarray, clip_motion_status: list):
        """
        走走停停场景中，短暂停车和再次起步应视作连续的 CREEP，
        避免在 STOP / START_FROM_STOP / CREEP 之间频繁抖动。

        若一段连续的非 CREEP 片段被两侧 CREEP 包围，且整段速度都保持在
        start_speed_threshold 以下，则将整段回写为 CREEP。
        DECEL_TO_STOP 保持不变，避免覆盖明确的停车收敛过程。
        """
        for start, end, label in self._iter_segments(labels):
            if label in (self.LABEL_CREEP, self.LABEL_DECEL_TO_STOP):
                continue
            if start == 0 or end == len(labels) - 1:
                continue
            if labels[start - 1] != self.LABEL_CREEP or labels[end + 1] != self.LABEL_CREEP:
                continue

            speeds = [clip_motion_status[idx]["vehspd"] for idx in range(start, end + 1)]
            if all(speed < self.THRE_START_SPEED for speed in speeds):
                labels[start : end + 1] = self.LABEL_CREEP

    def _merge_short_segments(self, labels: np.ndarray) -> np.ndarray:
        """
        合并过短的片段到相邻片段。
        设计文档 3.2: 相邻同类标签中间若夹杂 < 1s 的短片段，可合并。
        """
        N = len(labels)
        if N == 0:
            return labels

        min_frames = self.MIN_SEGMENT_DURATION_FRAMES
        merged = labels.copy()

        # 识别所有 segment
        segments = []
        start_idx = 0
        for i in range(1, N):
            if merged[i] != merged[i - 1]:
                segments.append((start_idx, i, merged[start_idx]))
                start_idx = i
        segments.append((start_idx, N, merged[start_idx]))

        # 合并过短的 segment
        i = 0
        while i < len(segments):
            start, end, label = segments[i]
            duration = end - start

            if duration < min_frames and i > 0 and i < len(segments) - 1:
                # 短片段，合并到前一个或后一个
                prev_label = segments[i - 1][2]
                next_label = segments[i + 1][2]

                # 优先合并到相同标签
                if prev_label == next_label:
                    merged[start:end] = prev_label
                    # 合并 segment 列表
                    segments[i - 1] = (segments[i - 1][0], segments[i + 1][1], prev_label)
                    segments.pop(i)
                    segments.pop(i)
                    i -= 1
                else:
                    # 合并到前一个
                    merged[start:end] = prev_label
                    segments[i - 1] = (segments[i - 1][0], end, prev_label)
                    segments.pop(i)
                    i -= 1

            i += 1

        return merged

    def _expand_lane_change_by_peaks(self, clip_motion_status):
        N = len(clip_motion_status)
        raw_dists = np.array([s.get("closest_lane_dist", 10.0) for s in clip_motion_status], dtype=np.float32)
        dists = smooth_signal(raw_dists, window=3)
        original_labels = np.array([s["lateral"] for s in clip_motion_status], dtype=np.int32)

        anchor_indices = np.where(np.abs(original_labels) == self.LABEL_LANE_CHANGE)[0]
        if len(anchor_indices) == 0:
            return clip_motion_status

        new_labels = np.zeros(N, dtype=np.int32)
        processed_mask = np.zeros(N, dtype=bool)

        def find_peak(start_idx, step):
            curr = start_idx
            best_peak_idx = start_idx
            best_peak_val = dists[start_idx]
            patience_counter = 0
            for _ in range(self.MAX_SEARCH_FRAMES):
                next_idx = curr + step
                if next_idx < 0 or next_idx >= N:
                    break
                if abs(original_labels[next_idx]) not in [self.LABEL_KEEP, self.LABEL_LANE_CHANGE]:
                    break

                val = dists[next_idx]
                if val > best_peak_val:
                    best_peak_val = val
                    best_peak_idx = next_idx
                    patience_counter = 0
                else:
                    patience_counter += 1
                if patience_counter > self.PATIENCE:
                    break
                curr = next_idx
            return best_peak_idx, best_peak_val

        for idx in anchor_indices:
            if processed_mask[idx]:
                continue

            action_type = original_labels[idx]
            t_start, peak_val_start = find_peak(idx, -1)
            t_end, peak_val_end = find_peak(idx, 1)
            is_valid_amplitude = (peak_val_start > self.MIN_PEAK_DIST) or (peak_val_end > self.MIN_PEAK_DIST)
            is_valid_duration = (t_end - t_start) >= self.MIN_DURATION
            if not (is_valid_amplitude and is_valid_duration):
                continue

            for frame_idx in range(t_start, t_end + 1):
                if abs(original_labels[frame_idx]) in [self.LABEL_KEEP, self.LABEL_LANE_CHANGE]:
                    new_labels[frame_idx] = action_type
                    processed_mask[frame_idx] = True

        for idx in range(N):
            if abs(original_labels[idx]) in [self.LABEL_KEEP, self.LABEL_LANE_CHANGE]:
                clip_motion_status[idx]["lateral"] = int(new_labels[idx])
        return clip_motion_status

    def _remove_lane_change_after_turn(self, clip_motion_status: list):
        cooldown_frames = int(self.NO_LANE_CHANGE_AFTER_TURN_SEC * self.fps)
        if cooldown_frames <= 0:
            return clip_motion_status

        turn_labels = {self.LABEL_TURN_CHANGE, self.LABEL_U_TURN}
        num_frames = len(clip_motion_status)
        frame_idx = 0
        while frame_idx < num_frames:
            lateral_label = abs(clip_motion_status[frame_idx]["lateral"])
            if lateral_label not in turn_labels:
                frame_idx += 1
                continue

            turn_end_idx = frame_idx
            while turn_end_idx + 1 < num_frames and abs(clip_motion_status[turn_end_idx + 1]["lateral"]) == lateral_label:
                turn_end_idx += 1

            suppress_end_idx = min(num_frames, turn_end_idx + cooldown_frames + 1)
            for suppress_idx in range(turn_end_idx + 1, suppress_end_idx):
                if abs(clip_motion_status[suppress_idx]["lateral"]) == self.LABEL_LANE_CHANGE:
                    clip_motion_status[suppress_idx]["lateral"] = self.LABEL_KEEP

            frame_idx = turn_end_idx + 1
        return clip_motion_status

    def get_config(self):
        return asdict(self.config)

    def process(self, data):
        timestamps = np.array(sorted(data.get("timestamp_list", [])), dtype=np.float64)
        if len(timestamps) == 0:
            return []

        clip_motion_status = self._build_default_clip_status(timestamps)
        try:
            ego_traj = self._create_ego_traj_parser()
            if not ego_traj.init(data):
                return self._build_default_clip_status(timestamps, "ego_trajectory_init_failed")

            ego_motions, ego_deg_accumu = self._build_ego_motion_features(ego_traj, timestamps)
            self._populate_motion_fields(clip_motion_status, ego_motions)

            egocenter_pose = ego_traj.poses_array
            self._apply_turn_labels(clip_motion_status, ego_deg_accumu, egocenter_pose)
            self._apply_lane_change_labels(data, timestamps, egocenter_pose, clip_motion_status)

            yaw_rate = ego_motions[:, 1]
            # clip_motion_status = self._check_nudge(yaw_rate, timestamps, clip_motion_status)
            _ = yaw_rate

            clip_motion_status = self._remove_lane_change_after_turn(clip_motion_status)
            clip_motion_status = self._expand_lane_change_by_peaks(clip_motion_status)
            clip_motion_status = self._compute_longitudinal_status(ego_motions, clip_motion_status)
            
            # enable 
            for status in clip_motion_status:
                status["valid"] = True
                
            return clip_motion_status
        except Exception as exc:
            LOGGER.exception("Meta action processing failed.")
            return self._build_default_clip_status(timestamps, f"meta_action_process_failed: {exc}")
