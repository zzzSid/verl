# -*- coding: utf-8 -*-
"""Meta-action token labels aligned with plannn3 ``il_dataset``."""

from __future__ import annotations

from typing import Dict
from typing import List
from typing import Tuple

import numpy as np

from tpp_onemodel.data.plannn3.nn3_meta_action_manager import LateralLabel
from tpp_onemodel.data.plannn3.nn3_meta_action_manager import LongitudinalLabel
from tpp_onemodel.data.plannn3.nn3_meta_action_manager import MetaActionManager


def speed_delta_bin_left_edges() -> np.ndarray:
    """Bin edges for 3s speed-delta discretization (same as nn3 ``il_dataset``)."""
    return np.concatenate(
        [
            np.arange(-90.0, -30.0, 5.0),
            np.arange(-30.0, -10.0, 2.0),
            np.arange(-10.0, 10.0, 1.0),
            np.arange(10.0, 30.0, 2.0),
            np.arange(30.0, 90.0, 5.0),
        ]
    )


SPEED_DELTA_BIN_COUNT = len(speed_delta_bin_left_edges())


def nn3_meta_action_vocab_size() -> int:
    """Meta-action token slots in lm_head: 7 lon + 7 lat + gap + speed-delta bins."""
    return (
        MetaActionManager.LONGITUDE_LABEL_NUM
        + MetaActionManager.LATITUDE_LABEL_NUM
        + 1
        + SPEED_DELTA_BIN_COUNT
    )


def speculate_future_motion_status(
    clip_info: Dict,
    ts_list: List,
    cur_index: int,
    future_indices: List[int],
    num_classes: int,
) -> Tuple[int, int]:
    """Port of ``WMPlannerDatasetV3.speculate_future_motion_status``."""
    cur_motion_status = clip_info[ts_list[cur_index]]["motion_status"]
    future_motion_status = [clip_info[ts_list[_idx]]["motion_status"] for _idx in future_indices]

    longitude_label = -1
    lateral_label = -1
    if cur_motion_status["valid"] and len(future_motion_status) > 0:
        _steady_labels = {int(LongitudinalLabel.UNIFORM)}
        if future_motion_status[0]["longitudinal"] not in _steady_labels:
            longitude_label = future_motion_status[0]["longitudinal"]
        else:
            longitude_label = future_motion_status[0]["longitudinal"]
            for future_status in future_motion_status[1:10]:
                if future_status["longitudinal"] not in _steady_labels:
                    longitude_label = future_status["longitudinal"]
                    break
        if future_motion_status[0]["lateral"] != int(LateralLabel.KEEP):
            lateral_label = future_motion_status[0]["lateral"]
        else:
            lateral_label = int(LateralLabel.KEEP)
            for future_status in future_motion_status[1:]:
                if future_status["lateral"] != int(LateralLabel.KEEP):
                    lateral_label = future_status["lateral"]
                    break

    if longitude_label in MetaActionManager.LONGITUDE_LABELS_MAP:
        longitude_label = MetaActionManager.LONGITUDE_LABELS_MAP[longitude_label] + num_classes
    if lateral_label in MetaActionManager.LATITUDE_LABELS_MAP:
        lateral_label = (
            MetaActionManager.LATITUDE_LABELS_MAP[lateral_label]
            + MetaActionManager.LONGITUDE_LABEL_NUM
            + num_classes
        )
    return longitude_label, lateral_label


def discretize_speed_delta(speed_delta_kmh: float) -> int:
    """Port of ``WMPlannerDatasetV3.discretize_speed_delta``."""
    speed_delta_kmh = float(np.clip(speed_delta_kmh, -90.0, 90.0))
    bin_left_edges = speed_delta_bin_left_edges()
    token_index = int(np.searchsorted(bin_left_edges, speed_delta_kmh, side="right") - 1)
    return int(np.clip(token_index, 0, len(bin_left_edges) - 1))


def speculate_future_speed_delta_token(
    clip_info: Dict,
    ts_list: List,
    cur_index: int,
    future_indices: List[int],
    num_classes: int,
    future_seconds: float = 3.0,
    target_fps: int = 5,
) -> int:
    """Port of ``WMPlannerDatasetV3.speculate_future_speed_delta_token``."""
    future_offset = int(round(future_seconds * target_fps)) - 1
    if len(future_indices) == 0:
        future_index = cur_index
    else:
        future_index = future_indices[min(max(future_offset, 0), len(future_indices) - 1)]
        if future_index < 0:
            valid_future_indices = [idx for idx in future_indices if idx >= 0]
            future_index = valid_future_indices[-1] if len(valid_future_indices) > 0 else cur_index

    cur_speed = clip_info[ts_list[cur_index]].get("ego_motion", [0] * 12)[8]
    future_speed = clip_info[ts_list[future_index]].get("ego_motion", [0] * 12)[8]
    speed_delta_kmh = (future_speed - cur_speed) * 3.6
    speed_delta_bin = discretize_speed_delta(speed_delta_kmh)
    speed_token_offset = (
        num_classes + MetaActionManager.LONGITUDE_LABEL_NUM + MetaActionManager.LATITUDE_LABEL_NUM + 1
    )
    return speed_token_offset + speed_delta_bin


def default_longitude_token(num_classes: int) -> int:
    """Token id for UNIFORM when meta action is invalid."""
    return num_classes + MetaActionManager.LONGITUDE_LABELS_MAP[int(LongitudinalLabel.UNIFORM)]


def default_lateral_token(num_classes: int) -> int:
    """Token id for KEEP when meta action is invalid."""
    return (
        num_classes
        + MetaActionManager.LONGITUDE_LABEL_NUM
        + MetaActionManager.LATITUDE_LABELS_MAP[int(LateralLabel.KEEP)]
    )


def default_speed_delta_token(num_classes: int) -> int:
    """Token id for ~0 km/h delta when speed meta is unavailable."""
    speed_token_offset = (
        num_classes + MetaActionManager.LONGITUDE_LABEL_NUM + MetaActionManager.LATITUDE_LABEL_NUM + 1
    )
    return speed_token_offset + discretize_speed_delta(0.0)


def build_nn3_meta_action_labels(
    clip_info: Dict,
    ts_list: List,
    cur_index: int,
    future_indices: List[int],
    num_classes: int,
) -> Tuple[int, int, int]:
    """Return (longitude, lateral, speed_delta) token ids aligned with nn3 IL."""
    longitude_label, lateral_label = speculate_future_motion_status(
        clip_info,
        ts_list,
        cur_index,
        future_indices,
        num_classes,
    )
    if longitude_label < 0:
        longitude_label = default_longitude_token(num_classes)
    if lateral_label < 0:
        lateral_label = default_lateral_token(num_classes)
    speed_delta_label = speculate_future_speed_delta_token(
        clip_info,
        ts_list,
        cur_index,
        future_indices,
        num_classes,
    )
    return longitude_label, lateral_label, speed_delta_label
