# -*- coding: utf-8 -*-
"""NN3 uint8 image conversion and normalization helpers."""

from __future__ import annotations

import torch


NN3_IMAGE_PLACEHOLDER_U8 = 0
NN3_IMAGE_NORM_SCALE = 127.5


def to_uint8_frames(tensor: torch.Tensor) -> torch.Tensor:
    """Convert decoded RGB values in ``[0, 255]`` to contiguous uint8."""
    if tensor.dtype == torch.uint8:
        return tensor.contiguous()
    return tensor.round().clamp(0, 255).to(torch.uint8).contiguous()


def normalize_nn3_image_u8(tensor: torch.Tensor) -> torch.Tensor:
    """Map uint8 pixels from ``[0, 255]`` to floating point ``[-1, 1]``."""
    return tensor.float() / NN3_IMAGE_NORM_SCALE - 1.0
