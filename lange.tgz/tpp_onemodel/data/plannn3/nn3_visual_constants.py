# -*- coding: utf-8 -*-
"""NN3 v1.6 visual token layout (aligned with baseline_v1.6.py)."""

from __future__ import annotations

from typing import Dict
from typing import List
from typing import Sequence
from typing import Tuple

from tpp_onemodel.data.plannn3.nn3_constants import DEFAULT_CROP_SHAPE
from tpp_onemodel.data.plannn3.nn3_constants import DEFAULT_MULTIVIEW_CAMS
from tpp_onemodel.data.plannn3.nn3_constants import DEFAULT_TEMPORAL_MULTIVIEW_CONFIGS
from tpp_onemodel.data.plannn3.nn3_constants import DEFAULT_VIDEO_SHAPE


NN3_VIEW_START_TOKEN_LEN = 1
NN3_VIEW_END_TOKEN_LEN = 1
NN3_PATCH_SIZE: Tuple[int, int] = (32, 64)
NN3_AUX_VOCAB_SIZE = 11
NN3_AUX_LOSS_WEIGHT = 0.1
NN3_ADD_BLACK_MASK_PROB_TRAIN = 0.3
NN3_MASK_HISTORY_IMAGE_PROB = 0.2

def compute_cam_temporal_counts(
    temporal_multiview_configs: Sequence = DEFAULT_TEMPORAL_MULTIVIEW_CONFIGS,
    multiview_cams: Sequence[str] = DEFAULT_MULTIVIEW_CAMS,
) -> Dict[str, int]:
    """Per-camera frame count in ``[T,C,H,W]`` (how often each cam appears in temporal configs)."""
    counts: Dict[str, int] = {cam: 0 for cam in multiview_cams}
    for multiview_config in temporal_multiview_configs:
        cam_list, _ = multiview_config
        for cam in cam_list:
            if cam in counts:
                counts[cam] += 1
    return counts


NN3_CAM_TEMPORAL_COUNTS = compute_cam_temporal_counts()

NN3_DINOV3_TIMM_CONFIG = {
    "model_name": "vit_small_plus_patch16_dinov3.lvd1689m",
    "checkpoint": "/share-global/jin.chen4/shares/models/dinov3_encoder/vit_small_plus_patch16_dinov3_expand256.lvd1689m.bin",
}


def compute_visual_sequence_sizes(
    temporal_multiview_configs: Sequence = DEFAULT_TEMPORAL_MULTIVIEW_CONFIGS,
    video_shape: Dict[str, List[int]] = DEFAULT_VIDEO_SHAPE,
    patch_size: Tuple[int, int] = NN3_PATCH_SIZE,
    view_start_token_len: int = NN3_VIEW_START_TOKEN_LEN,
    view_end_token_len: int = NN3_VIEW_END_TOKEN_LEN,
) -> Tuple[int, int]:
    """Return ``(visual_sequence_size, history_visual_sequence_size)``."""
    visual_sequence_size = 0
    history_visual_sequence_size = 0
    num_temporal = len(temporal_multiview_configs)
    for temporal_index, multiview_config in enumerate(temporal_multiview_configs):
        multiview_cam_list, rescale_rate_list = multiview_config
        for multiview_cam, rescale_rate in zip(multiview_cam_list, rescale_rate_list):
            h, w = video_shape[multiview_cam][:2]
            visual_sequence_size += view_start_token_len
            frame_token_len = int(
                (h // patch_size[0] * rescale_rate[0]) * (w // patch_size[1] * rescale_rate[1])
            )
            visual_sequence_size += frame_token_len
            visual_sequence_size += view_end_token_len
            if temporal_index < num_temporal - 1:
                history_visual_sequence_size += frame_token_len
    return visual_sequence_size, history_visual_sequence_size


NN3_VISUAL_SEQ_LEN, NN3_HISTORY_VISUAL_SEQ_LEN = compute_visual_sequence_sizes()

__all__ = [
    "DEFAULT_CROP_SHAPE",
    "DEFAULT_MULTIVIEW_CAMS",
    "DEFAULT_TEMPORAL_MULTIVIEW_CONFIGS",
    "DEFAULT_VIDEO_SHAPE",
    "NN3_ADD_BLACK_MASK_PROB_TRAIN",
    "NN3_CAM_TEMPORAL_COUNTS",
    "NN3_AUX_LOSS_WEIGHT",
    "compute_cam_temporal_counts",
    "NN3_AUX_VOCAB_SIZE",
    "NN3_DINOV3_TIMM_CONFIG",
    "NN3_HISTORY_VISUAL_SEQ_LEN",
    "NN3_MASK_HISTORY_IMAGE_PROB",
    "NN3_PATCH_SIZE",
    "NN3_VIEW_END_TOKEN_LEN",
    "NN3_VIEW_START_TOKEN_LEN",
    "NN3_VISUAL_SEQ_LEN",
    "compute_visual_sequence_sizes",
]
