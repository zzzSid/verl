# -*- coding: utf-8 -*-
"""Navi token cls mappings (aligned with plannn3 IL)."""

from tpp_onemodel.data.plannn3.nn3_constants import NAVI_CLS_MAPPING
from tpp_onemodel.data.plannn3.nn3_constants import TLD_TO_LANE_DIRECTION_MAPPING


def get_spd_limit_cls2_mapping(spd_limit):
    """Map speed limit bucket to cls2 id."""
    cls_id = 21 + spd_limit
    assert 21 <= cls_id <= 33
    return cls_id


def get_lane_id_cls2_mapping(lane_id):
    """Map lane id to cls2 id."""
    cls_id = 34 + lane_id
    assert 34 <= cls_id <= 46
    return cls_id


def get_action_cls2_mapping(main_action_id):
    """Map main action to cls2 id."""
    if main_action_id > 14:
        main_action_id = 0
    cls_id = 47 + main_action_id
    assert 47 <= cls_id <= 61
    return cls_id


def get_lane_type_cls3_mapping(lane_type):
    """Map lane type to cls3 id."""
    return 10 + lane_type


def get_action_cls3_mapping(assistant_action_id):
    """Map assistant action to cls3 id."""
    if assistant_action_id > 18:
        assistant_action_id = 0
    return 14 + assistant_action_id


def get_remain_distance_cls4_mapping(remain_distance):
    """Map remain distance to cls4 id."""
    if remain_distance < 0:
        return 0
    if remain_distance < 100:
        cls_id = remain_distance // 10
    elif remain_distance < 1000:
        cls_id = remain_distance // 100 + 9
    elif remain_distance < 2000:
        cls_id = 19
    else:
        cls_id = 20
    return 1 + cls_id


def get_tld_cls2_mapping(tld_color):
    """Map tld color id to cls2 id (plannn3: 16 + color, colors 0..4)."""
    cls_id = 16 + int(tld_color)
    if cls_id < 16 or cls_id > 20:
        cls_id = 16
    return cls_id


__all__ = [
    "NAVI_CLS_MAPPING",
    "TLD_TO_LANE_DIRECTION_MAPPING",
    "get_action_cls2_mapping",
    "get_action_cls3_mapping",
    "get_lane_id_cls2_mapping",
    "get_lane_type_cls3_mapping",
    "get_remain_distance_cls4_mapping",
    "get_spd_limit_cls2_mapping",
    "get_tld_cls2_mapping",
]
