# -*- coding: utf-8 -*-
"""Attach nn3 visual meta + navi sidecar to Plannn3Dataset samples."""

from __future__ import annotations

from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Sequence

from tpp_onemodel.data.plannn3.nn3_constants import DEFAULT_CROP_SHAPE
from tpp_onemodel.data.plannn3.nn3_constants import DEFAULT_MULTIVIEW_CAMS
from tpp_onemodel.data.plannn3.nn3_constants import DEFAULT_TEMPORAL_MULTIVIEW_CONFIGS
from tpp_onemodel.data.plannn3.nn3_constants import DEFAULT_VIDEO_SHAPE
from tpp_onemodel.data.plannn3.nn3_history_traj_utils import pack_history_traj_for_clip
from tpp_onemodel.data.plannn3.nn3_mindist_label import gen_traj_min_dist_label_from_raw_env
from tpp_onemodel.data.plannn3.nn3_navi_pack import pack_navi_for_frame
from tpp_onemodel.data.plannn3.nn3_video_meta import build_multiview_visual_meta


def _video_crop_target_size(video_shape: Dict[str, List[int]]) -> Dict[str, tuple]:
    crop_target = {}
    for cam, shape in video_shape.items():
        if len(shape) == 2:
            crop_target[cam] = tuple(shape)
        else:
            crop_target[cam] = tuple(shape[:4])
    return crop_target


def _resize_target_size(crop_shape: Dict[str, tuple]) -> Dict[str, tuple]:
    return {cam: (shape[0], shape[1]) for cam, shape in crop_shape.items()}


def pack_nn3_sidecar(
    nn3_clip: Dict[str, Any],
    downsample_timestamps: Sequence[Any],
    start_idx: int,
    history_size: int,
    mode: str = "pretrain",
    enable_navi: bool = True,
    enable_history_traj: bool = True,
    enable_visual_meta: bool = True,
    multiview_cams: Optional[Sequence[str]] = None,
    temporal_multiview_configs: Optional[Sequence] = None,
    video_shape: Optional[Dict[str, List[int]]] = None,
    crop_shape: Optional[Dict[str, List[int]]] = None,
    temporal: Optional[int] = None,
    vision_temporal: Optional[int] = None,
    polyline_size: int = 4,
    max_lane_num: int = 13,
    max_subpath_segment_num: int = 30,
    raw_env_for_mindist: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Build optional nn3 multimodal sidecar (no pixel decode)."""
    multiview_cams = list(multiview_cams or DEFAULT_MULTIVIEW_CAMS)
    temporal_multiview_configs = temporal_multiview_configs or DEFAULT_TEMPORAL_MULTIVIEW_CONFIGS
    video_shape = video_shape or DEFAULT_VIDEO_SHAPE
    crop_shape = crop_shape or DEFAULT_CROP_SHAPE
    temporal = temporal or len(temporal_multiview_configs)
    vision_temporal = vision_temporal or temporal

    resample_clip = nn3_clip.get("nn2_clip_info")
    if resample_clip is None:
        resample_clip = nn3_clip

    select_curr_index = min(
        start_idx + history_size - 1,
        len(downsample_timestamps) - 1,
    )
    vision_temporal = min(vision_temporal, len(temporal_multiview_configs))
    # Align with nn3 IL: vision_temporal frames ending at select_curr (not history_size-wide).
    vision_start_idx = max(start_idx, select_curr_index - vision_temporal + 1)

    sidecar: Dict[str, Any] = {
        "select_ts": downsample_timestamps[select_curr_index],
        "vision_start_idx": vision_start_idx,
        "select_curr_index": select_curr_index,
    }

    if enable_navi:
        nn3_frame = nn3_clip[sidecar["select_ts"]]
        nn2_frame = None
        if resample_clip is not nn3_clip:
            nn2_frame = resample_clip.get(sidecar["select_ts"])
        navi_pack = pack_navi_for_frame(
            nn3_frame,
            nn2_frame=nn2_frame,
            mode=mode,
            polyline_size=polyline_size,
            max_lane_num=max_lane_num,
            max_subpath_segment_num=max_subpath_segment_num,
        )
        sidecar["navi_pack"] = navi_pack
    if enable_history_traj:
        speed_limit = -1.0
        navi_pack = sidecar.get("navi_pack")
        if navi_pack is not None:
            speed_limit = float(navi_pack.get("raw_navi_info", {}).get("speed_limit", -1))
        sidecar["history_traj_pack"] = pack_history_traj_for_clip(
            nn3_clip,
            downsample_timestamps,
            start_idx,
            select_curr_index,
            speed_limit,
        )

    if enable_visual_meta:
        crop_target_size = _video_crop_target_size(video_shape)
        resize_target_size = _resize_target_size(
            {cam: tuple(crop_shape[cam][:2]) for cam in multiview_cams}
        )
        # with_nn2 dual-pkl: video paths on main (plann2_resample), frame FW/block meta on perception pkl.
        frame_source_clip = resample_clip if resample_clip is not nn3_clip else None
        sidecar["visual_meta"] = build_multiview_visual_meta(
            nn3_clip,
            downsample_timestamps,
            vision_start_idx=vision_start_idx,
            select_curr_index=select_curr_index,
            multiview_cams=multiview_cams,
            temporal_multiview_configs=temporal_multiview_configs,
            resize_target_size=resize_target_size,
            crop_target_size=crop_target_size,
            frame_source_clip=frame_source_clip,
        )
    if enable_visual_meta or enable_navi:
        if raw_env_for_mindist is not None:
            # nn3 IL: label from perception at planner current frame only.
            curr_frame_idx = select_curr_index - start_idx
            sidecar["traj_min_dist_label"] = gen_traj_min_dist_label_from_raw_env(
                raw_env_for_mindist,
                curr_frame_idx=curr_frame_idx,
            )
        else:
            sidecar["traj_min_dist_label"] = -100
    return sidecar
