# -*- coding: utf-8 -*-
"""Async VT video decode (ported from plannn3, lives in melange)."""

from __future__ import annotations

import asyncio
import inspect
import logging
import os
import uuid
from collections import deque
from dataclasses import dataclass
from dataclasses import field
from functools import partial
from typing import List
from typing import Optional
from typing import Tuple

import torch

logger = logging.getLogger(__name__)


def _require_argus():
    try:
        from argus_util import Convertor
        from argus_util import Nv12DeviceFrame
        from argus_util import VideoBufferDecoder
    except ImportError as exc:
        raise ImportError(
            "argus_util (VideoBufferDecoder/Convertor) is required for NN3 VT decode."
        ) from exc
    return Convertor, Nv12DeviceFrame, VideoBufferDecoder


@dataclass
class _ParserVideoInfo:
    """In-flight decode state (internal to AsyncVideoParser)."""

    fut: asyncio.Future = field(default_factory=asyncio.Future)
    index_list: list = field(default_factory=list)
    offset_list: list = field(default_factory=list)
    raw_size: tuple = (0, 0)
    resize_size: tuple = (0, 0)
    crop_size: tuple = (0, 0)
    video_type: str = "h265"


@dataclass
class _DecoderInfo:
    dec: object = None
    last_video_name: Optional[str] = None
    last_video_flist: list = field(default_factory=list)
    video_list: deque = field(default_factory=deque)
    last_tick: int = 0
    start_flag: bool = False


class AsyncVideoParser:
    """GPU VT decoder with async futures per block (nn3 IL compatible API)."""

    def __init__(self, device_id: int, torch_resize: bool = False):
        _require_argus()
        self._decoder_dict = {}
        self._convertor_dict = {}
        self._device_id = device_id
        self._info_dict = {}
        self._tick = 0
        self._stop = False
        self._torch_resize = torch_resize
        self._output_uint8 = not torch_resize and os.getenv("PLANNN3_VT_UINT8", "1") not in ("0", "false", "False")
        self._monitor_task = None
        try:
            loop = asyncio.get_running_loop()
            self._monitor_task = loop.create_task(self._sync_monitor())
        except RuntimeError:
            pass

    def stop(self):
        """Stop background sync monitor and release native decoder handles."""
        self._stop = True
        if self._monitor_task is not None and not self._monitor_task.done():
            self._monitor_task.cancel()
        self._release_native_resources()

    def _release_native_resources(self) -> None:
        """Tear down Argus decoders/convertors so GC can reclaim native memory."""
        for dec_key in list(self._decoder_dict.keys()):
            self._clear_decoder(dec_key, None)
        self._convertor_dict.clear()
        for video_flag, video_info in list(self._info_dict.items()):
            if not video_info.fut.done():
                video_info.fut.set_result(None)
            self._info_dict.pop(video_flag, None)

    async def decode_video(
        self,
        video_path: str,
        video_buffer: bytes,
        raw_size: Tuple[int, int],
        resize_size: Tuple[int, int],
        crop_size: Tuple[int, ...],
        video_type: str,
        index_list: List[int],
    ):
        """Schedule decode; returns asyncio Future with NCHW cuda tensor."""
        video_flag = f"{video_path}.{video_type}"
        assert video_flag not in self._info_dict
        crop_height, crop_width, top, left = crop_size
        offset_list = [
            left,
            top,
            resize_size[1] - crop_width - left,
            resize_size[0] - crop_height - top,
        ]
        dec_out_size = raw_size if self._torch_resize else resize_size
        video_info = _ParserVideoInfo(
            index_list=index_list,
            offset_list=offset_list,
            raw_size=raw_size,
            resize_size=resize_size,
            crop_size=(crop_height, crop_width),
            video_type=video_type,
        )
        actual_flag = await self._dec_video(
            video_flag,
            video_buffer,
            raw_size,
            dec_out_size,
            video_type,
        )
        self._info_dict[actual_flag] = video_info
        self._tick += 1
        return video_info.fut

    def sync_dec(self, dec_info=None):
        """Flush decoder and run NV12->RGB conversion."""
        _, Nv12DeviceFrame, _ = _require_argus()
        empty_frame = Nv12DeviceFrame()
        if dec_info:
            dec_info.dec.get_all_decoded_frame()
            if not dec_info.last_video_name:
                return
            self._do_conversion(dec_info, empty_frame)
            return
        for _key, info in self._decoder_dict.items():
            info.dec.get_all_decoded_frame()
            self._do_conversion(info, empty_frame)

    def sync(self):
        """Sync all decoders."""
        for dec_info in self._decoder_dict.values():
            self.sync_dec(dec_info)

    @staticmethod
    def _indices_ready(frame_list: list, index_list: list) -> bool:
        return bool(frame_list and index_list and max(index_list) < len(frame_list))

    def clear_clip_state(self) -> None:
        """Clear completed per-clip bookkeeping while retaining decoder instances."""
        for dec_info in self._decoder_dict.values():
            dec_info.last_video_flist = []
            dec_info.last_video_name = None
            dec_info.video_list.clear()

    def _callback(self, dec_key, frame_list):
        dec_info = self._decoder_dict.get(dec_key)
        if not dec_info:
            return
        if not dec_info.last_video_name and frame_list:
            dec_info.last_video_name = frame_list[0].video_path
        for frame in frame_list:
            if frame.empty:
                continue
            if frame.video_path != dec_info.last_video_name:
                if dec_info.last_video_name in self._info_dict:
                    self._do_conversion(dec_info, frame)
                else:
                    dec_info.last_video_flist = []
                    dec_info.last_video_name = frame.video_path
            dec_info.last_video_flist.append(frame)

    def _do_conversion(self, dec_info, frame):
        Convertor, _, _ = _require_argus()
        cvt_key = None
        next_video_name = None if getattr(frame, "empty", False) else getattr(frame, "video_path", None)
        try:
            vi = self._info_dict.pop(dec_info.last_video_name, None)
            if vi is None:
                return
            batch_size = len(vi.index_list)
            try:
                index = dec_info.video_list.index(dec_info.last_video_name)
            except ValueError:
                if not vi.fut.done():
                    vi.fut.set_result(None)
                return
            while index > 0:
                video_flag = dec_info.video_list.popleft()
                if expired_vi := self._info_dict.pop(video_flag, None):
                    expired_vi.fut.set_result(None)
                index -= 1
            dec_info.video_list.popleft()
            if not self._indices_ready(dec_info.last_video_flist, vi.index_list):
                if not vi.fut.done():
                    vi.fut.set_result(None)
                return
            frame_list = [dec_info.last_video_flist[i] for i in vi.index_list]
            if self._torch_resize:
                crop_size = (frame_list[0].height, frame_list[0].width)
            else:
                crop_size = vi.crop_size
            cvt_key = (batch_size, vi.crop_size)
            if cvt_key in self._convertor_dict:
                convertor = self._convertor_dict[cvt_key]
            else:
                convertor_kwargs = dict(
                    device_id=self._device_id,
                    remap_w=crop_size[1],
                    remap_h=crop_size[0],
                    out_w=crop_size[1],
                    out_h=crop_size[0],
                    batch_size=batch_size,
                    stream_ptr=dec_info.dec.cuda_stream,
                )
                if self._output_uint8:
                    try:
                        from argus_util import PixelType

                        convertor_kwargs["pixel_type"] = PixelType.kNC3HW_U8
                    except (AttributeError, ImportError):
                        logger.warning("argus_util PixelType unavailable; using float VT output")
                        self._output_uint8 = False
                convertor = Convertor(**convertor_kwargs)
                self._convertor_dict[cvt_key] = convertor
            if self._torch_resize:
                dl_tensor = convertor.batch_convert_to_nn_tensor(frame_list, [[]] * batch_size, is_async=True)
                torch_tensor = torch.from_dlpack(dl_tensor)
                torch_tensor = torch.nn.functional.interpolate(
                    torch_tensor,
                    size=vi.resize_size,
                    mode="bilinear",
                    align_corners=False,
                )
                left, top = vi.offset_list[:2]
                height, width = vi.crop_size
                tensor_h, tensor_w = torch_tensor.shape[-2:]
                top = max(0, min(int(top), tensor_h - 1))
                left = max(0, min(int(left), tensor_w - 1))
                height = min(int(height), tensor_h - top)
                width = min(int(width), tensor_w - left)
                torch_tensor = torch_tensor[:, :, top : top + height, left : left + width]
            else:
                dl_tensor = convertor.batch_convert_to_nn_tensor(
                    frame_list, [vi.offset_list] * batch_size, is_async=True
                )
                torch_tensor = torch.from_dlpack(dl_tensor)
            if not vi.fut.done():
                vi.fut.set_result(torch_tensor)
        except Exception as exc:
            if "vi" in locals() and vi is not None and not vi.fut.done():
                vi.fut.set_result(None)
            if cvt_key is not None:
                self._convertor_dict.pop(cvt_key, None)
            logger.warning("VT conversion failed for %s: %s", dec_info.last_video_name, exc)
        finally:
            dec_info.last_video_flist = []
            dec_info.last_video_name = next_video_name

    async def _dec_video(self, video_flag, video_buffer, raw_size, out_size, video_type):
        """Submit one VT block and return its unique decoder flag."""
        _, _, VideoBufferDecoder = _require_argus()
        dec_key = (raw_size, out_size, video_type)
        try:
            if dec_key not in self._decoder_dict:
                decoder_kwargs = dict(
                    device_id=self._device_id,
                    video_flag=video_flag,
                    video_buffer=video_buffer,
                    gop=16,
                    stream_ptr=0,
                    out_w=out_size[1],
                    out_h=out_size[0],
                    scale_w=out_size[1] / raw_size[1],
                    scale_h=out_size[0] / raw_size[0],
                )
                if "callback_mode" in inspect.signature(VideoBufferDecoder.__init__).parameters:
                    decoder_kwargs["callback_mode"] = "plain"
                decoder = VideoBufferDecoder(**decoder_kwargs)
                decoder.set_callback(partial(self._callback, dec_key))
                dec_info = _DecoderInfo(dec=decoder, last_video_name=video_flag)
                self._decoder_dict[dec_key] = dec_info
            else:
                dec_info = self._decoder_dict[dec_key]
                decoder = dec_info.dec
                video_flag = f"{uuid.uuid4().hex}.{video_flag}"
                status = decoder.add_video_buffer(video_flag=video_flag, video_buffer=video_buffer)
                assert status, f"add video buffer:{video_flag} failed"
            dec_info.last_tick = self._tick
            dec_info.video_list.append(video_flag)
        except Exception as exc:
            self._clear_decoder(dec_key, exc)
            logger.warning("VT add_video_buffer failed for %s: %s", video_flag, exc)
            raise exc
        try:
            decoder.async_batch_decode_to_buffer_end()
        except Exception as exc:
            self._clear_decoder(dec_key, exc)
            raise exc
        return video_flag

    async def _sync_monitor(self):
        while not self._stop:
            try:
                dec_tick_dict = {key: dec_info.last_tick for key, dec_info in self._decoder_dict.items()}
                for _ in range(3):
                    await asyncio.sleep(10)
                    for key, dec_info in self._decoder_dict.items():
                        tick = dec_tick_dict.get(key)
                        if tick is not None and tick < dec_info.last_tick:
                            dec_tick_dict.pop(key)
                    if not dec_tick_dict:
                        break
                else:
                    for key in list(dec_tick_dict.keys()):
                        dec_info = self._decoder_dict.get(key)
                        if dec_info:
                            self.sync_dec(dec_info)
            except Exception as exc:
                logger.exception(exc)

    def _clear_decoder(self, dec_key, _exc):
        dec_info = self._decoder_dict.pop(dec_key, None)
        if not dec_info:
            return
        for video_flag in dec_info.video_list:
            if vi := self._info_dict.pop(video_flag, None):
                vi.fut.set_result(None)
