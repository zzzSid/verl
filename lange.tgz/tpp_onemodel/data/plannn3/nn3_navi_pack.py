# -*- coding: utf-8 -*-
"""NN3 navi parse/encode/labels for multimodal path (aligned with plannn3 IL)."""

from __future__ import annotations

from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np

from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils.geometry import cut_sub_path
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils.geometry import interpolate_points
from tpp_onemodel.data.plannn3.nn3_constants import NAVI_CLS_MAPPING
from tpp_onemodel.data.plannn3.nn3_constants import TLD_TO_LANE_DIRECTION_MAPPING
from tpp_onemodel.data.plannn3.nn3_navi_utils import get_action_cls2_mapping
from tpp_onemodel.data.plannn3.nn3_navi_utils import get_action_cls3_mapping
from tpp_onemodel.data.plannn3.nn3_navi_utils import get_lane_id_cls2_mapping
from tpp_onemodel.data.plannn3.nn3_navi_utils import get_lane_type_cls3_mapping
from tpp_onemodel.data.plannn3.nn3_navi_utils import get_remain_distance_cls4_mapping
from tpp_onemodel.data.plannn3.nn3_navi_utils import get_spd_limit_cls2_mapping
from tpp_onemodel.data.plannn3.nn3_navi_utils import get_tld_cls2_mapping


def create_empty_navi_info() -> Dict[str, Any]:
    """Empty navi dict (plannn3 IL schema)."""
    return {
        "main_action_1": 0,
        "assistant_action_1": 0,
        "link_main_distance_1": -1,
        "main_action_2": 0,
        "assistant_action_2": 0,
        "link_main_distance_2": -1,
        "lane_infos": [],
        "lane_nr_remain_distance": -1,
        "tld": [4, 4, 4, 4],
        "tld_timer": -1,
        "speed_limit": -1,
        "sub_path": [],
        "navi_centerlines": [],
        "not_navi_centerlines": [],
        "highlight_centerlines": [],
    }


def parse_frame_tld(cur_frame_info: Dict[str, Any]) -> List[int]:
    """Parse traffic light colors from frame."""
    tld = [4, 4, 4, 4]
    traffic_lights = cur_frame_info.get("traffic_lights")
    if not traffic_lights:
        return tld
    if len(traffic_lights) > 4:
        traffic_lights = traffic_lights[:4]
    for i, light in enumerate(traffic_lights):
        color, status, _timer = light
        if status != 0:
            color = 4
        tld[i] = color
    return tld


def parse_frame_spdlimit(cur_frame_info: Dict[str, Any]) -> int:
    """Parse speed limit from frame."""
    return max(cur_frame_info.get("speed_limit", -1), -1)


def parse_navi_info_v5(cur_frame_info: Dict[str, Any]) -> Dict[str, Any]:
    """Parse navi from ``local_lanenr_actions`` (v5)."""
    navi_info = create_empty_navi_info()
    lanenr_actions_info = cur_frame_info.get("local_lanenr_actions", {})
    if lanenr_actions_info:
        action_count = 0
        lanenr_count = 0
        for info in lanenr_actions_info:
            merged_action = info.get("merged_tbt_segment_action", {})
            if (
                merged_action.get("main_action", 0) > 0
                and (merged_action.get("distance", -1) >= 0.0 or merged_action.get("source") == 3)
            ):
                if action_count == 0:
                    action_count += 1
                    navi_info["main_action_1"] = merged_action["main_action"]
                    navi_info["assistant_action_1"] = merged_action["assistant_action"]
                    navi_info["link_main_distance_1"] = merged_action["distance"]
                elif action_count == 1:
                    action_count += 1
                    navi_info["main_action_2"] = merged_action["main_action"]
                    navi_info["assistant_action_2"] = merged_action["assistant_action"]
                    navi_info["link_main_distance_2"] = merged_action["distance"]
            merged_lane = info.get("merged_multi_lane_info", {})
            if merged_lane.get("parsed_lane_nr_info") and (
                merged_lane.get("distance", -1) >= 0.0 or merged_lane.get("source") == 3
            ):
                if lanenr_count == 0:
                    lanenr_count += 1
                    navi_info["lane_nr_remain_distance"] = merged_lane["distance"]
                    for lane_info in merged_lane["parsed_lane_nr_info"]:
                        navi_info["lane_infos"].append(
                            [
                                lane_info["lane_direction"],
                                lane_info["lane_highline_direction"],
                                lane_info["lane_is_drivable"],
                                lane_info["lane_is_highline"],
                                lane_info["lane_type"],
                            ]
                        )
            if action_count >= 2 and lanenr_count >= 1:
                break
    navi_info["tld"] = parse_frame_tld(cur_frame_info)
    navi_info["speed_limit"] = parse_frame_spdlimit(cur_frame_info)
    sub_path = cur_frame_info.get("sub_path", {})
    navi_info["sub_path"] = sub_path.get("sub_path_main_path_points", [])
    return navi_info


def parse_navi_info_closed(cur_frame_info: Dict[str, Any]) -> Dict[str, Any]:
    """Parse navi for current frame (v5 when available)."""
    if "local_lanenr_actions" in cur_frame_info:
        return parse_navi_info_v5(cur_frame_info)
    return parse_navi_info_v5(cur_frame_info)


def get_navi_label(frame: Dict[str, Any]) -> Tuple[np.ndarray, Dict[str, Any]]:
    """Navi centerline arb label (plannn3 IL)."""
    navi_centerline_info: Dict[str, Any] = {
        "navi_centerlines": [],
        "not_navi_centerlines": [],
        "highlight_centerlines": [],
    }
    for key, out_key in [
        ("navi_centerlines", "navi_centerlines"),
        ("not_navi_centerlines", "not_navi_centerlines"),
        ("highlight_centerlines", "highlight_centerlines"),
    ]:
        centerlines = frame.get(key)
        if centerlines is None:
            continue
        for navi_lane in centerlines:
            if navi_lane["points"].shape[0] < 2:
                continue
            new_points = np.array(navi_lane["points"], dtype=np.float32)
            navi_centerline_info[out_key].append(
                [new_points, navi_lane["solid_line_start_index"], navi_lane["id"]]
            )

    all_navi = [ele[0] for ele in navi_centerline_info["navi_centerlines"]]
    all_not_navi = [ele[0] for ele in navi_centerline_info["not_navi_centerlines"]]
    all_highlight = [ele[0] for ele in navi_centerline_info["highlight_centerlines"]]
    ego_pose = np.array([0.0, 0.0])

    def _min_y_dist(points_list):
        if not points_list:
            return 1e6
        points = np.concatenate(points_list, axis=0)
        mask = (
            (points[:, 0] >= ego_pose[0])
            & (points[:, 0] <= ego_pose[0] + 10.0)
            & (points[:, 1] >= ego_pose[1] - 5.0)
            & (points[:, 1] <= ego_pose[1] + 5.0)
        )
        filt = points[mask]
        if filt.shape[0] == 0:
            return 1e6
        return np.min(np.abs(filt[:, :2] - ego_pose)[:, 1])

    highlight_dist = _min_y_dist(all_highlight)
    navi_dist = _min_y_dist(all_navi)
    not_navi_dist = _min_y_dist(all_not_navi)
    navi_label_id = 0
    if highlight_dist < 1.5:
        navi_label_id = 3
    elif navi_dist < 1.5:
        navi_label_id = 1
    elif not_navi_dist < 1.5:
        navi_label_id = 2
    return np.array([navi_label_id]), navi_centerline_info


def get_env_navi_label(frame: Dict[str, Any], navi_infos: Dict[str, Any], max_lane_num: int = 13) -> np.ndarray:
    """Per-lane env navi label grid (simplified ego at origin)."""
    centerlines = []
    for centerline in frame.get("manner_lane_center_lines", ()):
        if centerline["type"] == 99 or centerline["id"] < 90000 or centerline["id"] > 100000:
            continue
        if len(centerline["points"]) < 1:
            continue
        new_points = np.array([[p["x"], p["y"], p["z"]] for p in centerline["points"]], dtype=np.float32)
        centerlines.append([new_points, centerline["type"], centerline["confidence"], centerline["id"]])

    drivable_center_line = []
    ego_pose = np.array([0.0, 0.0])
    y_dist = 1e6
    min_id = -1
    for points, lane_type, _conf, lane_id in centerlines:
        if lane_type in [2, 16]:
            mask = (points[:, 0] >= ego_pose[0] + 4.0) & (points[:, 0] <= ego_pose[0] + 9.0)
            if mask.any():
                drivable_center_line.append([points[mask], lane_type, _conf, lane_id])
                if abs(points[mask][0, 1]) < y_dist:
                    y_dist = np.min(np.abs(points[mask][:, 1]))
                    min_id = lane_id

    drivable_center_line.sort(key=lambda x: x[0][-1, 1], reverse=True)
    all_navi_id = [ele[2] for ele in navi_infos["navi_centerlines"]]
    all_not_navi_id = [ele[2] for ele in navi_infos["not_navi_centerlines"]]
    all_highlight_id = [ele[2] for ele in navi_infos["highlight_centerlines"]]
    max_mid_id = max_lane_num // 2
    if len(drivable_center_line) < 1:
        return np.full((max_lane_num, 2), 0)

    pos_list = []
    for _id_left, ele in enumerate(drivable_center_line):
        tmp_list = [0, 0]
        tmp_list[1] = 2 if ele[3] == min_id else 1
        if ele[3] in all_highlight_id:
            tmp_list[0] = 4
        elif ele[3] in all_navi_id:
            tmp_list[0] = 3
        elif ele[3] in all_not_navi_id:
            tmp_list[0] = 2
        else:
            tmp_list[0] = 1
        pos_list.append(tmp_list)
    pos_np = np.array(pos_list)
    ego_index_arr = np.where(pos_np[:, 1] == 2)[0]
    ego_index = ego_index_arr.item() if len(ego_index_arr) > 0 else -1
    label = np.full((max_lane_num, 2), 0)
    if ego_index > -1:
        right_pos = pos_np[ego_index + 1:] if ego_index < (pos_np.shape[0] - 1) else []
        left_pos = pos_np[:ego_index] if ego_index > 0 else []
        label[max_mid_id, :] = pos_np[ego_index]
        for i, ele in enumerate(left_pos[::-1]):
            target_idx = max_mid_id - i - 1
            if target_idx >= 0:
                label[target_idx, :] = ele
        for i, ele in enumerate(right_pos):
            target_idx = max_mid_id + i + 1
            if target_idx < max_lane_num:
                label[target_idx, :] = ele
    return label


def _split_line(points: np.ndarray, segment_length: int = 4) -> List[np.ndarray]:
    n = len(points)
    idx = np.arange(0, n, segment_length - 1)
    return [points[i: i + segment_length] for i in idx]


def _get_lane_id_position(lane_id, num_lane_infos, max_lane_num, mode):
    if num_lane_infos <= 0:
        raise ValueError(f"num_lane_infos must be positive, got {num_lane_infos}")
    from_left = True
    position = lane_id
    from_right_position = num_lane_infos - lane_id - 1
    if mode == "pretrain":
        if lane_id >= max_lane_num / 2:
            from_left = False
            position = from_right_position
        elif from_right_position >= max_lane_num // 2:
            pass
        elif np.random.rand() > 0.5:
            from_left = False
            position = from_right_position
    else:
        if lane_id > num_lane_infos / 2:
            from_left = False
            position = from_right_position
    return from_left, position


def _encode_lane_navi_info(lane_is_ok, lane_direction):
    result = 0
    result |= lane_direction << 1
    result |= lane_is_ok
    return result


def get_subpath_polyline_polymask(
    sub_path,
    polyline_size: int = 4,
    max_subpath_segment_num: int = 30,
):
    """Subpath polyline tensors for navi encoder."""
    sub_path_polylines = []
    sub_path_polymask = []
    if sub_path is not None and len(sub_path) > 0:
        points = [point[:2] for point in sub_path]
        points = interpolate_points(points, 5)
        points = cut_sub_path(points, np.array([0, 0]))
        if np.isfinite(points).all():
            segments = _split_line(np.array(points), polyline_size)
            segments = segments[:max_subpath_segment_num]
            for segment in segments:
                sub_path_polymask.append(np.array(min(polyline_size, len(segment))))
                if segment.shape[0] < polyline_size:
                    segment = np.concatenate(
                        [segment, np.zeros((polyline_size - segment.shape[0], 2))],
                        axis=0,
                    )
                sub_path_polylines.append(segment)
        padded_sub_path = padding_sub_path(
            np.array(points),
            guideline_max_num=max_subpath_segment_num * polyline_size,
        )
    else:
        padded_sub_path = -np.ones((max_subpath_segment_num * polyline_size, 2), dtype=np.float32) * 1e3

    sub_path_polylines = (
        np.stack(sub_path_polylines, axis=0) if sub_path_polylines else np.zeros((0, polyline_size, 2))
    )
    sub_path_polymask = np.stack(sub_path_polymask, axis=0) if sub_path_polymask else np.zeros((0))
    sub_path_polylines = np.concatenate(
        [sub_path_polylines, np.zeros((max_subpath_segment_num - len(sub_path_polylines), polyline_size, 2))],
        axis=0,
    )
    sub_path_polymask = np.concatenate(
        [sub_path_polymask, np.zeros((max_subpath_segment_num - len(sub_path_polymask)))],
        axis=0,
    )
    return sub_path_polylines, sub_path_polymask, padded_sub_path


def padding_sub_path(sub_path, guideline_max_num=120):
    """Pad subpath polyline."""
    sub_path = sub_path.astype(np.float32)
    if len(sub_path) < guideline_max_num:
        return np.concatenate(
            [sub_path, -np.ones((guideline_max_num - len(sub_path), 2), dtype=np.float32) * 1e3],
            axis=0,
        )
    return sub_path[:guideline_max_num]


def encode_navi_info(
    navi_info: Dict[str, Any],
    property_dim: int = 5,
    max_lane_num: int = 13,
    mode: str = "pretrain",
    polyline_size: int = 4,
    max_subpath_segment_num: int = 30,
):
    """Encode navi property rows (plannn3 IL layout)."""
    total_rows = 7 + 2 * max_lane_num
    env_property = np.zeros((total_rows, property_dim), dtype=np.float32)
    row = 0
    env_property[row, 0] = NAVI_CLS_MAPPING["action_1"]
    env_property[row, 1] = get_action_cls2_mapping(navi_info["main_action_1"])
    env_property[row, 2] = get_action_cls3_mapping(navi_info["assistant_action_1"])
    env_property[row, 3] = get_remain_distance_cls4_mapping(navi_info["link_main_distance_1"])
    row += 1
    env_property[row, 0] = NAVI_CLS_MAPPING["action_2"]
    env_property[row, 1] = get_action_cls2_mapping(navi_info["main_action_2"])
    env_property[row, 2] = get_action_cls3_mapping(navi_info["assistant_action_2"])
    env_property[row, 3] = get_remain_distance_cls4_mapping(navi_info["link_main_distance_2"])
    row += 1
    lane_infos = navi_info["lane_infos"][:max_lane_num]
    num_lane_infos = len(lane_infos)
    lane_nr_remain_distance = navi_info["lane_nr_remain_distance"]
    lane_info_start = row
    lane_highline_start = row + max_lane_num
    env_property[lane_info_start: lane_info_start + num_lane_infos, 0] = NAVI_CLS_MAPPING["lane_info"]
    env_property[lane_highline_start: lane_highline_start + num_lane_infos, 0] = NAVI_CLS_MAPPING["lane_highline_info"]
    for lane_id, lane_info in enumerate(lane_infos):
        lane_direction, lane_highline_direction, lane_is_drivable, lane_is_highline, lane_type = lane_info
        from_left, position = _get_lane_id_position(lane_id, num_lane_infos, max_lane_num, mode)
        encode_lane_id = position * 2 if from_left else position * 2 + 1
        cls2_val = get_lane_id_cls2_mapping(encode_lane_id)
        cls3_val = get_lane_type_cls3_mapping(lane_type)
        cls4_val = get_remain_distance_cls4_mapping(lane_nr_remain_distance)
        env_property[lane_info_start + lane_id, 1] = cls2_val
        env_property[lane_info_start + lane_id, 2] = cls3_val
        env_property[lane_info_start + lane_id, 3] = cls4_val
        env_property[lane_info_start + lane_id, 4] = _encode_lane_navi_info(lane_is_drivable, lane_direction)
        env_property[lane_highline_start + lane_id, 1] = cls2_val
        env_property[lane_highline_start + lane_id, 2] = cls3_val
        env_property[lane_highline_start + lane_id, 3] = cls4_val
        env_property[lane_highline_start + lane_id, 4] = _encode_lane_navi_info(
            lane_is_highline, lane_highline_direction
        )
    row += max_lane_num * 2
    env_property[row: row + 4, 0] = NAVI_CLS_MAPPING["tld"]
    env_property[row: row + 4, 1] = [get_tld_cls2_mapping(tld_id) for tld_id in navi_info["tld"]]
    env_property[row: row + 4, 4] = np.array(TLD_TO_LANE_DIRECTION_MAPPING) << 1
    row += 4
    env_property[row, 0] = NAVI_CLS_MAPPING["spd_limit"]
    env_property[row, 1] = get_spd_limit_cls2_mapping(np.clip(navi_info["speed_limit"], 0, 120) // 10)
    sub_path_polylines, sub_path_polymask, padded_sub_path = get_subpath_polyline_polymask(
        navi_info["sub_path"],
        polyline_size=polyline_size,
        max_subpath_segment_num=max_subpath_segment_num,
    )
    return env_property, sub_path_polylines, sub_path_polymask, padded_sub_path


def pack_navi_for_frame(
    nn3_frame: Dict[str, Any],
    nn2_frame: Optional[Dict[str, Any]] = None,
    mode: str = "pretrain",
    property_dim: int = 5,
    max_lane_num: int = 13,
    polyline_size: int = 4,
    max_subpath_segment_num: int = 30,
    add_nn2_speedlimit: bool = True,
) -> Dict[str, Any]:
    """Build navi tensors for one planner frame."""
    raw_navi_info = parse_navi_info_closed(nn3_frame)
    if nn2_frame is not None:
        if add_nn2_speedlimit and raw_navi_info["speed_limit"] <= 0:
            raw_navi_info["speed_limit"] = parse_frame_spdlimit(nn2_frame)
        _navi_label_id, navi_centerline_info = get_navi_label(nn2_frame)
        raw_navi_info.update(navi_centerline_info)
        env_navi_label = get_env_navi_label(nn2_frame, navi_centerline_info, max_lane_num=max_lane_num)
    else:
        env_navi_label = np.full((max_lane_num, 2), 0)

    encoded_navi_info, sub_path_polylines, sub_path_polymask, padded_sub_path = encode_navi_info(
        raw_navi_info,
        property_dim=property_dim,
        max_lane_num=max_lane_num,
        mode=mode,
        polyline_size=polyline_size,
        max_subpath_segment_num=max_subpath_segment_num,
    )
    raw_navi_info["padded_sub_path"] = padded_sub_path
    return {
        "navi_info": encoded_navi_info,
        "subpath_polylines": sub_path_polylines,
        "subpath_polylines_mask": sub_path_polymask,
        "navi_label": env_navi_label[:, 0].astype(np.int64),
        "raw_navi_info": raw_navi_info,
    }
