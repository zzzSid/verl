# -*- coding: utf-8 -*-
"""Multiview image/video fill (ported from plannn3 ImageFiller, melange-local)."""

from __future__ import annotations

import asyncio
import gc
import logging
import os
import random
import time
from concurrent.futures import ThreadPoolExecutor
from enum import Enum
from typing import Any
from typing import Dict
from typing import List
from typing import Optional

import cv2
import numpy as np
import torch

from read_cache_op_py import read_cache_op_py

from tpp_onemodel.data.plannn3.nn3_async_video_parser import AsyncVideoParser
from tpp_onemodel.data.plannn3.nn3_ceph_io import read_video_blocks_sync
from tpp_onemodel.data.plannn3.nn3_constants import CAMERA_MAPPER
from tpp_onemodel.data.plannn3.nn3_image_norm import to_uint8_frames
from tpp_onemodel.data.plannn3.nn3_visual_cuda import init_nn3_visual_cuda
from tpp_onemodel.data.plannn3.nn3_video_meta import Nn3ImageInfo
from tpp_onemodel.data.plannn3.nn3_video_meta import Nn3VideoInfo


logger = logging.getLogger(__name__)

FW_CAM = "/camera/front/main"

_CEPH_READ_TIMEOUT = float(os.getenv("NN3_CEPH_READ_TIMEOUT", "120"))
_VT_DECODE_TIMEOUT = float(os.getenv("NN3_VT_DECODE_TIMEOUT", "240"))
_VT_BLOCK_TIMEOUT = float(os.getenv("NN3_VT_BLOCK_TIMEOUT", "60"))


class DecStatus(Enum):
    """Decode pipeline state for sync polling."""

    IDLE = 0
    PROCESSING = 1
    WAITING = 2


def _crop_hw(crop_size: tuple) -> tuple:
    if len(crop_size) >= 2:
        return int(crop_size[0]), int(crop_size[1])
    return 0, 0


def _is_empty_video_info(video_info: Nn3VideoInfo) -> bool:
    if not video_info.path_list:
        return True
    if not video_info.frame_list:
        return True
    return all(len(fl) == 0 for fl in video_info.frame_list)


def _placeholder_for_video_info(video_info: Nn3VideoInfo) -> torch.Tensor:
    """Create an all-zero uint8 placeholder for one camera."""
    crop_h, crop_w = _crop_hw(video_info.crop_size)
    return torch.zeros(
        (max(1, len(video_info.frame_list)), 3, crop_h, crop_w),
        dtype=torch.uint8,
    )


def _target_hw_for_cam(video_shape: Dict[str, Any], cam: str) -> tuple:
    """Final ``(H, W)`` after crop (matches ``DEFAULT_VIDEO_SHAPE`` layout)."""
    shape = video_shape.get(cam)
    if shape is None:
        return 0, 0
    if len(shape) >= 2:
        return int(shape[0]), int(shape[1])
    return 0, 0


def _exception_summary(exc: BaseException) -> str:
    """Return an informative message even for exceptions with an empty string."""
    detail = str(exc).strip()
    name = type(exc).__name__
    return f"{name}: {detail}" if detail else name


def _requires_parser_reset(exc: BaseException) -> bool:
    """Return whether a VT failure can leave the native decoder unusable."""
    if isinstance(exc, (asyncio.TimeoutError, TimeoutError, MemoryError)):
        return True
    message = str(exc).lower()
    reset_markers = (
        "out of memory",
        "hw decoder faced error",
        "re-create instance",
        "cuda error",
        "cudaerror",
        "add video buffer",
    )
    return any(marker in message for marker in reset_markers)


def _requires_memory_reclaim(exc: BaseException) -> bool:
    """Whether a reset must run the expensive gc + CUDA cache flush.

    Only memory-pressure / CUDA-context failures actually need it. The common
    cases (``HW decoder faced error`` and ``block decode deadline reached``)
    just need a fresh parser instance, so we skip the heavy reclamation that
    would otherwise stall the decoder worker (and, via DDP grad sync, every
    rank) on each failure.
    """
    if isinstance(exc, MemoryError):
        return True
    message = str(exc).lower()
    return any(marker in message for marker in ("out of memory", "cuda error", "cudaerror"))


def _finalize_view_tensor(
    view_tensor: torch.Tensor,
    target_h: int,
    target_w: int,
    mask: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    """Resize decoded frames to fixed size while preserving uint8 output."""
    if view_tensor.dim() != 4:
        raise ValueError(f"expected NCHW video tensor, got shape {tuple(view_tensor.shape)}")
    if target_h <= 0 or target_w <= 0:
        return view_tensor
    source_dtype = view_tensor.dtype
    h, w = view_tensor.shape[-2:]
    if h != target_h or w != target_w:
        view_tensor = torch.nn.functional.interpolate(
            view_tensor.float(),
            size=(target_h, target_w),
            mode="bilinear",
            align_corners=False,
        )
        if source_dtype == torch.uint8:
            view_tensor = view_tensor.round_().clamp_(0, 255).to(torch.uint8)
    if mask is not None:
        if mask.shape[-2:] != (target_h, target_w):
            mask = torch.nn.functional.interpolate(
                mask[None, None].float(),
                size=(target_h, target_w),
                mode="nearest",
            )[0, 0] > 0.5
        view_tensor = view_tensor * mask[None].to(view_tensor.dtype)
    return view_tensor


class Nn3ImageFiller:
    """Decode ``visual_meta`` into normalized ``video:{cam}`` tensors."""

    def __init__(
        self,
        device_id: int = 0,
        debug: bool = False,
        add_black_mask_prob: float = 0.0,
        video_shape: Optional[Dict[str, tuple]] = None,
        crop_shape: Optional[Dict[str, tuple]] = None,
        inner_resize_crop: bool = True,
        multiview_cams: Optional[List[str]] = None,
    ):
        self.debug = debug
        self.add_black_mask_prob = add_black_mask_prob
        self.video_shape = video_shape or {}
        self.crop_shape = crop_shape or {}
        self.multiview_cams = list(multiview_cams or [FW_CAM])
        self._inner_resize_crop = inner_resize_crop
        cv2.setNumThreads(0)
        init_nn3_visual_cuda(device_id)
        self.decoding_status = DecStatus.IDLE
        self.device_id = device_id
        self.fw_full_mask = None
        self.mask = {}
        self._ceph_executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="nn3_ceph")
        self._ceph_read_timeout = _CEPH_READ_TIMEOUT
        self._vt_decode_timeout = _VT_DECODE_TIMEOUT
        self._vt_block_timeout = _VT_BLOCK_TIMEOUT
        self._init_black_masks()
        self.video_parser = self._build_video_parser()

    def _build_video_parser(self) -> AsyncVideoParser:
        """Build a fresh parser for this decoder process."""
        return AsyncVideoParser(self.device_id, not self._inner_resize_crop)

    def reset_parser(self, reason: str = "", reclaim_memory: bool = False) -> None:
        """Recreate parser state after a timeout or decoder failure.

        Decoder callbacks retain references to the parser, so ``gc.collect()``
        is required to release the old native decoder graph. CUDA cache flushing
        is reserved for memory-pressure failures because it stalls the decoder
        worker and can delay every rank through DDP synchronization.
        """
        if reason:
            logger.warning("Reset NN3 VT parser on cuda:%s: %s", self.device_id, reason)
        old_parser = self.video_parser
        try:
            old_parser.stop()
        except Exception:
            logger.debug("Failed to stop old NN3 VT parser", exc_info=True)
        self.video_parser = None
        del old_parser
        gc.collect()
        if reclaim_memory:
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        self.video_parser = self._build_video_parser()
        self.decoding_status = DecStatus.IDLE

    def _shutdown_ceph_executor(self, executor: ThreadPoolExecutor) -> None:
        """Best-effort shutdown; cancel pending reads when the runtime supports it."""
        try:
            executor.shutdown(wait=False, cancel_futures=True)
        except TypeError:
            executor.shutdown(wait=False)

    def _reset_ceph_executor(self) -> None:
        """Replace a read thread that may still be blocked in the cache client."""
        old_executor = self._ceph_executor
        self._ceph_executor = ThreadPoolExecutor(
            max_workers=1,
            thread_name_prefix="nn3_ceph",
        )
        self._shutdown_ceph_executor(old_executor)

    def _init_black_masks(self):
        if self.add_black_mask_prob <= 0.0:
            return
        mask_dir = "/perception-hl/jin.chen4/pygaussian/resources/mask"
        for cam in self.multiview_cams:
            short = CAMERA_MAPPER.get(cam)
            if short is None:
                continue
            mask_img = f"{mask_dir}/{short}.png"
            img = cv2.imread(mask_img)
            if img is None:
                continue
            resize_target = self.crop_shape.get(cam, (576, 1024))
            img = cv2.resize(img, (resize_target[1], resize_target[0]), interpolation=cv2.INTER_NEAREST)
            img = img.transpose(2, 0, 1)
            crop_target = self.video_shape.get(cam, resize_target[:2])
            if len(crop_target) == 2:
                height_start = (resize_target[0] - crop_target[0]) // 2
                width_start = (resize_target[1] - crop_target[1]) // 2
            else:
                crop_height, crop_width, height_start, width_start = crop_target
                crop_target = (crop_height, crop_width)
            crop_img = img[
                :,
                height_start: height_start + crop_target[0],
                width_start: width_start + crop_target[1],
            ]
            self.mask[cam] = torch.from_numpy(crop_img > 128).cuda(self.device_id)
        if FW_CAM in self.multiview_cams and FW_CAM in self.mask:
            self.fw_full_mask = self.mask[FW_CAM]

    def stop(self):
        """Stop the parser and Ceph read executor."""
        if self.video_parser is not None:
            self.video_parser.stop()
        self._shutdown_ceph_executor(self._ceph_executor)

    async def _read_video_blocks(
        self,
        path_list: List[str],
    ) -> Dict[str, bytes]:
        """Read and merge VT blocks without blocking the decoder event loop."""
        loop = asyncio.get_running_loop()
        try:
            return await asyncio.wait_for(
                loop.run_in_executor(
                    self._ceph_executor,
                    read_video_blocks_sync,
                    path_list,
                ),
                timeout=self._ceph_read_timeout,
            )
        except asyncio.TimeoutError as exc:
            self._reset_ceph_executor()
            raise asyncio.TimeoutError(
                f"Ceph video read timed out after {self._ceph_read_timeout:.1f}s " f"for {len(path_list)} block(s)"
            ) from exc

    async def _read_images(self, path_list: List[str]) -> List[bytes]:
        """Read image paths without blocking the decoder event loop."""
        loop = asyncio.get_running_loop()
        try:
            return await asyncio.wait_for(
                loop.run_in_executor(
                    self._ceph_executor,
                    read_cache_op_py,
                    path_list,
                ),
                timeout=self._ceph_read_timeout,
            )
        except asyncio.TimeoutError as exc:
            self._reset_ceph_executor()
            raise asyncio.TimeoutError(
                f"Ceph image read timed out after {self._ceph_read_timeout:.1f}s " f"for {len(path_list)} image(s)"
            ) from exc

    async def _await_vt_future(
        self,
        future: "asyncio.Future",
        deadline: float,
        context: str,
    ) -> Optional[torch.Tensor]:
        """Poll Argus sync until one VT future completes or reaches its deadline."""
        while not future.done():
            if time.time() >= deadline:
                raise asyncio.TimeoutError(f"VT block decode deadline reached ({context})")
            self.video_parser.sync()
            await asyncio.sleep(0.01)
        return future.result()

    async def fill_with_sync(self, input_dict: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Decode one clip while periodically flushing Argus callbacks."""
        task = asyncio.create_task(self.fill_async(input_dict))
        while True:
            done, _pending = await asyncio.wait({task}, timeout=1)
            if done:
                return task.result()
            if self.decoding_status == DecStatus.WAITING:
                try:
                    self.video_parser.sync()
                except Exception:
                    pass

    async def fill_async(self, input_dict: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Async decode all views."""
        if not init_nn3_visual_cuda(self.device_id):
            return None
        parser_failed = False
        reclaim_memory = False
        error_summary = ""
        try:
            return await self._fill(input_dict)
        except Exception as exc:
            parser_failed = _requires_parser_reset(exc)
            reclaim_memory = _requires_memory_reclaim(exc)
            error_summary = _exception_summary(exc)
            logger.warning(
                "VT decode failed (clip idx=%s): %s",
                input_dict.get("index"),
                error_summary,
            )
            if self.debug:
                logger.exception("VT decode traceback")
            return None
        finally:
            self.decoding_status = DecStatus.IDLE
            if parser_failed:
                self.reset_parser(
                    reason=f"clip idx={input_dict.get('index')}, error={error_summary}",
                    reclaim_memory=reclaim_memory,
                )
            else:
                try:
                    self.video_parser.sync()
                    self.video_parser.clear_clip_state()
                except Exception:
                    self.reset_parser(reason=f"sync failed clip idx={input_dict.get('index')}")

    async def _fill(self, input_dict: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        self.decoding_status = DecStatus.PROCESSING
        if input_dict.get("image_type") == "image":
            return await self._fill_image_clip(input_dict)
        return await self._fill_video_clip(input_dict)

    async def _fill_image_clip(self, input_dict: Dict[str, Any]) -> Dict[str, Any]:
        for view in self.multiview_cams:
            key = f"video:{view}"
            image_info: Nn3ImageInfo = input_dict[key]
            image_bytes_list = await self._read_images(image_info.ceph_path_list)
            frame_list = []
            for image_bytes in image_bytes_list:
                np_buffer = np.frombuffer(image_bytes, np.uint8)
                image = cv2.imdecode(np_buffer, cv2.IMREAD_UNCHANGED)
                frame_list.append(torch.from_numpy(image).permute(2, 0, 1)[[2, 1, 0], :, :].float())
            view_tensor = torch.stack(frame_list, dim=0)
            if image_info.cur_h != image_info.target_h or image_info.cur_w != image_info.target_w:
                view_tensor = torch.nn.functional.interpolate(
                    view_tensor,
                    size=(image_info.target_h, image_info.target_w),
                    mode="bilinear",
                )
            input_dict[key] = to_uint8_frames(view_tensor)
        return input_dict

    async def _fill_video_clip(self, input_dict: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        add_black_mask = self.add_black_mask_prob > 0 and random.random() < self.add_black_mask_prob
        path_list = []
        for view in self.multiview_cams:
            video_info: Nn3VideoInfo = input_dict[f"video:{view}"]
            path_list.extend(video_info.path_list)
        if not path_list:
            return None
        buffer_map = await self._read_video_blocks(path_list)
        decode_deadline = time.time() + self._vt_decode_timeout
        self.decoding_status = DecStatus.WAITING
        for view in self.multiview_cams:
            key = f"video:{view}"
            video_info: Nn3VideoInfo = input_dict[key]
            if _is_empty_video_info(video_info):
                input_dict[key] = _placeholder_for_video_info(video_info)
                continue

            block_tensors = []
            for vt_path, index_list in zip(video_info.path_list, video_info.frame_list):
                future = await self.video_parser.decode_video(
                    vt_path,
                    buffer_map.get(vt_path, b""),
                    video_info.raw_size,
                    video_info.resize_size,
                    video_info.crop_size,
                    video_info.video_type,
                    index_list,
                )
                block_deadline = min(
                    decode_deadline,
                    time.time() + self._vt_block_timeout,
                )
                context = f"clip idx={input_dict.get('index')}, view={view}, " f"path={vt_path[:200]}"
                block_tensors.append(
                    await self._await_vt_future(
                        future,
                        block_deadline,
                        context,
                    )
                )
            if any(tensor is None for tensor in block_tensors):
                logger.warning(
                    "VT decode returned empty frames (clip idx=%s, view=%s)",
                    input_dict.get("index"),
                    view,
                )
                input_dict[key] = _placeholder_for_video_info(video_info)
                continue

            view_tensor = torch.cat(block_tensors, dim=0)
            target_h, target_w = _target_hw_for_cam(self.video_shape, view)
            apply_mask = None
            if add_black_mask and view == FW_CAM and self.fw_full_mask is not None:
                apply_mask = self.fw_full_mask
            elif add_black_mask and view in self.mask:
                apply_mask = self.mask[view]
            view_tensor = _finalize_view_tensor(view_tensor, target_h, target_w, apply_mask)
            input_dict[key] = to_uint8_frames(view_tensor)
        self.decoding_status = DecStatus.IDLE
        return input_dict
