# -*- coding: utf-8 -*-
"""History trajectory waypoint and speed-gap labels (nn3 IL aligned)."""

from __future__ import annotations

from typing import Any
from typing import Dict
from typing import Sequence

import numpy as np


def compute_next_waypoint(ego2global_list, consider_broken=False, reverse=False):
    """Compute ego-frame next waypoints from consecutive ``car_pose`` matrices.

    Args:
        ego2global_list: ``[N+1, 4, 4]`` pose sequence.
        consider_broken: zero-out waypoints after the first invalid step.
        reverse: apply broken masking from newest to oldest.

    Returns:
        next_waypoint: ``[N, 3]`` (dx, dy, dyaw) in ego frame.
        mask: ``[N]`` validity mask.
    """
    def rot2yaw(rotation):
        sy = np.sqrt(np.sum((rotation[:, :2, 0] ** 2), axis=1))
        nonsingular = sy >= 1e-6
        yaw = np.arctan2(rotation[:, 1, 0], rotation[:, 0, 0]) * nonsingular
        return yaw

    global2ego_list = np.linalg.inv(ego2global_list)
    next_ego2ego_list = global2ego_list[:-1] @ ego2global_list[1:]

    xy_array = next_ego2ego_list[:, :2, 3]
    yaw_array = rot2yaw(next_ego2ego_list[:, :3, :3])
    next_waypoint = np.concatenate((xy_array, yaw_array[:, None]), axis=1)
    mask = (
        (next_waypoint[:, 0] <= 10)
        & (next_waypoint[:, 0] >= -1.7)
        & (next_waypoint[:, 1] <= 2)
        & (next_waypoint[:, 1] >= -2)
    )
    if consider_broken:
        broken = False
        for i in range(len(mask)):
            ind = len(mask) - i - 1 if reverse else i
            if not mask[ind]:
                broken = True
            mask[ind] = not broken
    return next_waypoint, mask


def compute_speed_gap_label(cur_speed_kmh: float, speed_limit_kmh: float) -> int:
    """Map speed gap to 10-class label (0--9), or -1 when invalid."""
    if speed_limit_kmh > 0 and cur_speed_kmh >= 0:
        speed_gap = speed_limit_kmh - cur_speed_kmh
        return int(min(max(speed_gap, 0), 49) // 5)
    return -1


def pack_history_traj_for_clip(
    nn3_clip: Dict[str, Any],
    downsample_timestamps: Sequence[Any],
    start_idx: int,
    select_curr_index: int,
    speed_limit: float,
    min_poses: int = 5,
) -> Dict[str, Any]:
    """Build history-traj tensors for one sample (aligned with plannn3 IL)."""
    hist_ts = downsample_timestamps[start_idx : select_curr_index + 1]
    car_poses = []
    for ts in hist_ts:
        frame = nn3_clip.get(ts)
        if frame is None or "car_pose" not in frame:
            continue
        car_poses.append(np.asarray(frame["car_pose"], dtype=np.float64))

    if len(car_poses) < 2:
        next_waypoint = np.zeros((max(min_poses - 1, 1), 3), dtype=np.float32)
        mask = np.zeros((next_waypoint.shape[0],), dtype=np.float32)
    else:
        car_poses_arr = np.stack(car_poses, axis=0)
        next_waypoint, mask = compute_next_waypoint(car_poses_arr, consider_broken=True, reverse=True)
        next_waypoint = next_waypoint.astype(np.float32)
        mask = mask.astype(np.float32)

    select_ts = downsample_timestamps[select_curr_index]
    cur_frame = nn3_clip.get(select_ts, {})
    ego_motion = cur_frame.get("ego_motion")
    cur_speed = float(ego_motion[8] * 3.6) if ego_motion is not None else -1.0
    speed_gap = compute_speed_gap_label(cur_speed, float(speed_limit))

    return {
        "his_traj_next_waypoint": next_waypoint,
        "egos_his_mask": mask,
        "speed_gap": np.array([speed_gap], dtype=np.int64),
    }
