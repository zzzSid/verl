# -*- coding: utf-8 -*-
"""Build visual decode descriptors (VideoInfo / ImageInfo) from resample clip."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Sequence
from typing import Tuple

from tpp_onemodel.data.plannn3.nn3_constants import CAMERA_MAPPER
from tpp_onemodel.data.plannn3.nn3_constants import RAW_MULTIVIEW_CAM_SIZE


@dataclass
class Nn3VideoInfo:
    """VT block read spec (aligned with plannn3 il_dataset VideoInfo)."""

    path_list: List[str]
    raw_size: Optional[Tuple[int, int]]
    resize_size: Tuple[int, int]
    crop_size: Tuple[int, ...]
    video_type: Optional[str]
    frame_list: List[List[int]]


@dataclass
class Nn3ImageInfo:
    """Per-frame ceph jpeg paths for gs_render / image clips."""

    ceph_path_list: List[str]
    target_h: int
    target_w: int
    cur_h: int
    cur_w: int


def infer_visual_type(resample_clip: Dict[str, Any]) -> str:
    """Return ``video`` or ``image`` (plannn3 IL convention)."""
    camera_info = resample_clip.get("camera_info")
    if camera_info == "image":
        return "image"
    return "video"


def _clip_timestamps(clip: Dict[str, Any]) -> List[Any]:
    ts = clip.get("timestamp_list")
    if ts is None:
        return sorted(k for k in clip.keys() if isinstance(k, (int, float)))
    if hasattr(ts, "tolist"):
        return sorted(ts.tolist())
    return sorted(list(ts))


def _lookup_frame(clip: Dict[str, Any], ts: Any) -> Dict[str, Any]:
    frame = clip.get(ts)
    if isinstance(frame, dict):
        return frame
    ts_float = float(ts)
    candidates = _clip_timestamps(clip)
    if not candidates:
        return {}
    best_ts = min(candidates, key=lambda item: abs(float(item) - ts_float))
    if abs(float(best_ts) - ts_float) > 0.15:
        return {}
    frame = clip.get(best_ts)
    return frame if isinstance(frame, dict) else {}


def _get_per_frame_camera_field(
    main_clip: Dict[str, Any],
    frame_source_clip: Optional[Dict[str, Any]],
    ts: Any,
    field: str,
) -> Any:
    """Read per-frame camera meta; fall back to perception clip for with_nn2 dual-pkl."""
    frame = _lookup_frame(main_clip, ts)
    value = frame.get(field) if frame else None
    if value or frame_source_clip is None:
        return value
    alt_frame = _lookup_frame(frame_source_clip, ts)
    return alt_frame.get(field) if alt_frame else None


def build_multiview_visual_meta(
    nn3_clip: Dict[str, Any],
    timestamp_list: Sequence[Any],
    vision_start_idx: int,
    select_curr_index: int,
    multiview_cams: Sequence[str],
    temporal_multiview_configs: Sequence,
    resize_target_size: Dict[str, Tuple[int, int]],
    crop_target_size: Dict[str, Tuple[int, ...]],
    frame_source_clip: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Build ``video:{view}`` -> VideoInfo/ImageInfo without decoding pixels.

    ``nn3_clip`` supplies top-level ``camera_info`` (video paths on plann2_resample).
    ``frame_source_clip`` supplies per-frame ``FW``/block meta (often on nn3 perception pkl).
    """
    visual_type = infer_visual_type(nn3_clip)
    if visual_type == "image":
        return _build_image_meta(
            nn3_clip,
            timestamp_list,
            vision_start_idx,
            select_curr_index,
            multiview_cams,
            temporal_multiview_configs,
            crop_target_size,
            frame_source_clip=frame_source_clip,
        )
    return _build_video_meta(
        nn3_clip,
        timestamp_list,
        vision_start_idx,
        select_curr_index,
        multiview_cams,
        temporal_multiview_configs,
        resize_target_size,
        crop_target_size,
        frame_source_clip=frame_source_clip,
    )


def _build_video_meta(
    nn3_clip: Dict[str, Any],
    timestamp_list: Sequence[Any],
    vision_start_idx: int,
    select_curr_index: int,
    multiview_cams: Sequence[str],
    temporal_multiview_configs: Sequence,
    resize_target_size: Dict[str, Tuple[int, int]],
    crop_target_size: Dict[str, Tuple[int, ...]],
    frame_source_clip: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    camera_info = nn3_clip.get("camera_info") or {}
    outputs: Dict[str, Any] = {"image_type": "video"}
    for view in multiview_cams:
        view_info = camera_info.get(view, {})
        video_path = view_info.get("file_s3_path", "")
        video_size = view_info.get("file_s3_size", 0)
        tgt_index = list(range(vision_start_idx, select_curr_index + 1))
        tgt_index = [
            frame_idx
            for i, frame_idx in enumerate(tgt_index)
            if i < len(temporal_multiview_configs)
            and view in temporal_multiview_configs[i][0]
        ]
        key = f"video:{view}"
        if video_size <= 0 or not video_path:
            outputs[key] = Nn3VideoInfo(
                path_list=[],
                raw_size=None,
                resize_size=resize_target_size[view],
                crop_size=crop_target_size[view],
                video_type=None,
                frame_list=[[] for _ in tgt_index],
            )
            continue
        vid_part_dict: Dict[Tuple[int, int], List[int]] = defaultdict(list)
        camera_name = CAMERA_MAPPER[view]
        for tgt_idx in tgt_index:
            ts = timestamp_list[tgt_idx]
            meta = _get_per_frame_camera_field(nn3_clip, frame_source_clip, ts, camera_name)
            if not meta:
                continue
            block_key = (meta["block_offset"], meta["block_size"])
            vid_part_dict[block_key].append(meta["id_offset"])
        video_path_norm = f"/{video_path.split(':')[1]}"
        video_type = video_path_norm.rsplit(".", maxsplit=1)[-1]
        if video_type == "tar":
            video_type = "h265"
        path_list = []
        frame_list = []
        for (block_offset, block_size), flist in vid_part_dict.items():
            vt_path = f"{video_path_norm} {video_size} {block_offset} {block_size}"
            path_list.append(vt_path)
            frame_list.append(flist)
        outputs[key] = Nn3VideoInfo(
            path_list=path_list,
            raw_size=RAW_MULTIVIEW_CAM_SIZE[camera_name],
            resize_size=resize_target_size[view],
            crop_size=crop_target_size[view],
            video_type=video_type,
            frame_list=frame_list,
        )
    return outputs


def _build_image_meta(
    nn3_clip: Dict[str, Any],
    timestamp_list: Sequence[Any],
    vision_start_idx: int,
    select_curr_index: int,
    multiview_cams: Sequence[str],
    temporal_multiview_configs: Sequence,
    crop_target_size: Dict[str, Tuple[int, ...]],
    frame_source_clip: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    outputs: Dict[str, Any] = {"image_type": "image"}
    for view in multiview_cams:
        tgt_index = list(range(vision_start_idx, select_curr_index + 1))
        tgt_index = [
            frame_idx
            for i, frame_idx in enumerate(tgt_index)
            if i < len(temporal_multiview_configs)
            and view in temporal_multiview_configs[i][0]
        ]
        ceph_path_list = []
        target_h, target_w = crop_target_size[view][:2]
        for tgt_idx in tgt_index:
            ts = timestamp_list[tgt_idx]
            img_path = _get_per_frame_camera_field(nn3_clip, frame_source_clip, ts, CAMERA_MAPPER[view])
            if img_path:
                ceph_path_list.append(img_path)
        outputs[f"video:{view}"] = Nn3ImageInfo(
            ceph_path_list=ceph_path_list,
            target_h=target_h,
            target_w=target_w,
            cur_h=target_h,
            cur_w=target_w,
        )
    return outputs
