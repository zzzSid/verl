# -*- coding: utf-8 -*-
"""Ego min-distance aux label (plannn3 IL ``gen_mindist_label``)."""

from __future__ import annotations

from typing import Any
from typing import Dict
from typing import Iterable
from typing import List
from typing import Optional

import numpy as np
from shapely.geometry import LineString
from shapely.geometry import MultiLineString
from shapely.geometry import MultiPolygon
from shapely.geometry import Polygon


def _mindist_to_label(min_d: float) -> int:
    """Map ego–obstacle min distance (m) to nn3 ``EgoMinDist2Obstacles`` bin."""
    if min_d <= 0.1:
        return 0
    if min_d <= 0.2:
        return 1
    if min_d <= 0.3:
        return 2
    if min_d <= 0.4:
        return 3
    if min_d <= 0.5:
        return 4
    if min_d <= 0.6:
        return 5
    if min_d <= 0.7:
        return 6
    if min_d <= 0.8:
        return 7
    if min_d <= 0.9:
        return 8
    if min_d <= 1.0:
        return 9
    return 10


def _get_distance(geo1, geo2, target_range: float = 200.0) -> float:
    if isinstance(geo2, Polygon):
        return float(geo1.distance(geo2))
    if hasattr(geo2, "geoms") and len(geo2.geoms) > 0:
        return float(geo1.distance(geo2))
    return target_range


def _get_obb(transform: np.ndarray, width: float, length: float) -> np.ndarray:
    """Four corners of oriented box in ego frame."""
    half_l = length / 2.0
    half_w = width / 2.0
    corners = np.array(
        [
            [half_l, half_w],
            [half_l, -half_w],
            [-half_l, -half_w],
            [-half_l, half_w],
        ],
        dtype=np.float64,
    )
    rot = transform[:2, :2]
    trans = transform[:2, 3]
    return corners @ rot.T + trans


def _safe_env_list(value: Any) -> List[Any]:
    """Normalize env polygon/line lists (avoid numpy ``or []`` ambiguity)."""
    if value is None:
        return []
    if isinstance(value, np.ndarray):
        if value.size == 0:
            return []
        if value.ndim >= 3:
            return [value[i] for i in range(value.shape[0])]
        if value.ndim == 2:
            return [value]
        return []
    if isinstance(value, (list, tuple)):
        return list(value)
    return []


def _safe_polygon(poly_coords: Any) -> Optional[Polygon]:
    """Build one shapely polygon; return None if coords are invalid."""
    try:
        arr = np.asarray(poly_coords, dtype=np.float64)
        if arr.ndim != 2 or arr.shape[0] < 3 or arr.shape[1] < 2:
            return None
        arr = arr[:, :2]
        if not np.isfinite(arr).all():
            return None
        poly = Polygon(arr)
        if poly.is_empty:
            return None
        if not poly.is_valid:
            poly = poly.buffer(0)
        if poly.is_empty or not poly.is_valid:
            return None
        return poly
    except Exception:
        return None


def _safe_multipolygon(polygon_list: Iterable[Any]) -> MultiPolygon:
    polys = []
    for item in polygon_list:
        poly = _safe_polygon(item)
        if poly is not None:
            polys.append(poly)
    return MultiPolygon(polys) if polys else MultiPolygon()


def _safe_multilinestring(line_list: Iterable[Any]) -> MultiLineString:
    lines = []
    for item in line_list:
        try:
            arr = np.asarray(item, dtype=np.float64)
            if arr.ndim != 2 or arr.shape[0] < 2 or arr.shape[1] < 2:
                continue
            arr = arr[:, :2]
            if not np.isfinite(arr).all():
                continue
            line = LineString(arr)
            if not line.is_empty:
                lines.append(line)
        except Exception:
            continue
    return MultiLineString(lines) if lines else MultiLineString()


def _frame_env_from_raw_env(raw_env: Dict[str, Any], curr_frame_idx: Optional[int] = None) -> Dict[str, Any]:
    """Extract one-frame perception for mindist (nn3 ``raw_env[t0]`` layout).

    ``dobjs_polygon`` in melange ``raw_env`` is a per-frame list ``[T]`` of ``[N, 4, 2]``
    arrays. Only the current planner frame is used, with each dynamic object expanded
    to a separate polygon (nn3 ``MultiPolygon([Polygon(p) for p in ...])``).
    """
    dobjs_source = raw_env.get("dobjs_polygon")
    dobjs_polygon: List[Any] = []
    if dobjs_source is not None:
        if curr_frame_idx is not None and isinstance(dobjs_source, (list, tuple)):
            if 0 <= curr_frame_idx < len(dobjs_source):
                dobjs_polygon = _safe_env_list(dobjs_source[curr_frame_idx])
            else:
                dobjs_polygon = []
        else:
            dobjs_polygon = _safe_env_list(dobjs_source)
    return {
        "dobjs_polygon": dobjs_polygon,
        "sobjs_polygon": _safe_env_list(raw_env.get("sobjs_polygon")),
        "road_edge": _safe_env_list(raw_env.get("road_edge")),
    }


def gen_traj_min_dist_label_from_raw_env(
    raw_env: Dict[str, Any],
    curr_frame_idx: Optional[int] = None,
) -> int:
    """Build label from melange ``get_one_sample`` ``raw_env`` at the planner current frame."""
    if not isinstance(raw_env, dict):
        return -100
    return gen_traj_min_dist_label(_frame_env_from_raw_env(raw_env, curr_frame_idx))


def gen_traj_min_dist_label(frame_env: Dict[str, Any]) -> int:
    """Compute ``traj_min_dist_label`` for one frame (11 bins, -100 invalid)."""
    try:
        if not isinstance(frame_env, dict):
            return -100

        ego_whl = [1.96, 1.499, 4.79]
        ego_l = 2.888
        t_center2ego = np.eye(4, dtype=np.float64)
        t_center2ego[0, 3] = ego_l / 2.0
        ego_verts = _get_obb(t_center2ego, ego_whl[0], ego_whl[2])
        ego_poly = Polygon(ego_verts)

        dobjs = _safe_env_list(frame_env.get("dobjs_polygon"))
        sobjs = _safe_env_list(frame_env.get("sobjs_polygon"))
        road_edge = _safe_env_list(frame_env.get("road_edge"))

        dynamic_polys = _safe_multipolygon(dobjs)
        static_polys = _safe_multipolygon(sobjs)
        curb_lines = _safe_multilinestring(road_edge)

        dynamic_dist = _get_distance(ego_poly, dynamic_polys)
        static_dist = _get_distance(ego_poly, static_polys)
        curb_dist = _get_distance(ego_poly, curb_lines)
        return _mindist_to_label(min(dynamic_dist, static_dist, curb_dist))
    except Exception:
        return -100


__all__ = [
    "gen_traj_min_dist_label",
    "gen_traj_min_dist_label_from_raw_env",
    "_frame_env_from_raw_env",
]
