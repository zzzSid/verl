# -*- coding: utf-8 -*-
"""Constants aligned with plannn3 IL (camera + navi token layout)."""

from tpp_onemodel.data.dataset.plannn2_dataset_utils.common import tld_to_lane_direction_mapping


RAW_MULTIVIEW_CAM_SIZE = {
    "FW": (2168, 3848),
    "FR": (2168, 3848),
    "FL": (2168, 3848),
    "RR": (2168, 3848),
    "RL": (2168, 3848),
    "RN": (2168, 3848),
    "FN": (2168, 3848),
    "SRCW": (1536, 1920),
    "SFW": (1536, 1920),
    "SLW": (1536, 1920),
    "SRW": (1536, 1920),
}

CAMERA_MAPPER = {
    "/camera/front/main": "FW",
    "/camera/front/narrow": "FN",
    "/camera/side/front/left": "FL",
    "/camera/side/front/right": "FR",
    "/camera/side/rear/left": "RL",
    "/camera/side/rear/right": "RR",
    "/camera/rear": "RN",
    "/camera/surrouding/front": "SFW",
    "/camera/surrouding/left": "SLW",
    "/camera/surrouding/right": "SRW",
    "/camera/surrouding/rear": "SRCW",
}

NAVI_CLS_MAPPING = {
    "pad": 0,
    "tld": 1,
    "spd_limit": 2,
    "action_1": 3,
    "action_2": 4,
    "lane_info": 5,
    "lane_highline_info": 6,
}

TLD_TO_LANE_DIRECTION_MAPPING = tld_to_lane_direction_mapping

# Default nn3 v1.6 visual (5v + temporal configs in cfg).
DEFAULT_MULTIVIEW_CAMS = [
    "/camera/front/main",
    "/camera/side/front/left",
    "/camera/side/front/right",
    "/camera/side/rear/left",
    "/camera/side/rear/right",
]

DEFAULT_TEMPORAL_MULTIVIEW_CONFIGS = [
    [["/camera/front/main"], [(0.5, 0.5)]],
    [["/camera/front/main"], [(0.5, 0.5)]],
    [
        [
            "/camera/front/main",
            "/camera/side/front/left",
            "/camera/side/front/right",
            "/camera/side/rear/left",
            "/camera/side/rear/right",
        ],
        [(0.5, 0.5), (0.5, 0.5), (0.5, 0.5), (0.5, 0.5), (0.5, 0.5)],
    ],
    [
        [
            "/camera/front/main",
            "/camera/side/front/left",
            "/camera/side/front/right",
            "/camera/side/rear/left",
            "/camera/side/rear/right",
        ],
        [(0.5, 0.5), (0.5, 0.5), (0.5, 0.5), (0.5, 0.5), (0.5, 0.5)],
    ],
    [
        [
            "/camera/front/main",
            "/camera/side/front/left",
            "/camera/side/front/right",
            "/camera/side/rear/left",
            "/camera/side/rear/right",
        ],
        [(1, 1), (1, 1), (1, 1), (1, 1), (1, 1)],
    ],
]

DEFAULT_VIDEO_SHAPE = {
    "/camera/front/main": [512, 1536, 224, 7],
    "/camera/side/front/left": [512, 512, 0, 0],
    "/camera/side/front/right": [512, 512, 0, 512],
    "/camera/side/rear/left": [512, 512, 0, 0],
    "/camera/side/rear/right": [512, 512, 0, 512],
}

DEFAULT_CROP_SHAPE = {
    "/camera/front/main": [1024, 1550],
    "/camera/side/front/left": [512, 1024],
    "/camera/side/front/right": [512, 1024],
    "/camera/side/rear/left": [512, 1024],
    "/camera/side/rear/right": [512, 1024],
}
