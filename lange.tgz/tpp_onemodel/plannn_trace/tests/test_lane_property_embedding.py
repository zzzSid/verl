import torch

from tpp_onemodel.plannn_trace.net_abc import NetA
from tpp_onemodel.plannn_trace.net_abc import NetB


class Config:
    def __init__(self):
        # minimal fields used by lane_property_embedding
        self.lane_info_id = 1
        self.lane_highline_info_id = 2
        self.road_arrow_id = 3
        self.tld_id = 4
        # embedding sizes required by NetA/NetB init
        self.n_embd = 1
        self.property_cls1_vocab_size = 10
        self.property_cls2_vocab_size = 10
        self.property_cls3_vocab_size = 10
        self.property_cls4_vocab_size = 10
        self.property_cls6_vocab_size = 10
        self.property_cls7_vocab_size = 10
        self.tid_vocab_size = 10
        self.timestamp_vocab_size = 10
        self.ego_history_token_size: int = 1028
        self.history_size: int = 15
        self.max_token_len: int = 15


def generate_properties(batch_size: int, timesteps: int, cfg: Config, seed: int = 0):
    torch.manual_seed(seed)
    type_ids = torch.tensor([cfg.lane_info_id, cfg.lane_highline_info_id, cfg.road_arrow_id, cfg.tld_id, 99, 100], dtype=torch.long)
    type_idx = torch.randint(0, len(type_ids), (batch_size, timesteps), dtype=torch.long)
    type_field = type_ids[type_idx]

    flags_field = torch.randint(0, 64, (batch_size, timesteps), dtype=torch.long)

    # construct property with required fields up to index 6
    property_tensor = torch.zeros((batch_size, timesteps, 7), dtype=torch.long)
    property_tensor[:, :, 0] = type_field
    property_tensor[:, :, 6] = flags_field
    return property_tensor


def test_lane_property_embedding_equivalence():
    cfg = Config()
    net_a = NetA(cfg)
    net_b = NetB(cfg)

    shapes = [(1, 1), (2, 3), (4, 5), (8, 16)]
    seeds = [0, 1, 2, 123, 999]

    for (b, t) in shapes:
        for s in seeds:
            prop = generate_properties(b, t, cfg, seed=s)

            out_old_a = net_a.lane_property_embedding_old_impl(prop)
            out_new_a = net_a.lane_property_embedding(prop)
            assert out_old_a.shape == out_new_a.shape
            assert torch.equal(out_old_a, out_new_a), f"NetA mismatch shape {(b, t)} seed {s}\nold: {out_old_a}\nnew: {out_new_a}"

            out_old_b = net_b.lane_property_embedding_old_impl(prop)
            out_new_b = net_b.lane_property_embedding(prop)
            assert out_old_b.shape == out_new_b.shape
            assert torch.equal(out_old_b, out_new_b), f"NetB mismatch shape {(b, t)} seed {s}\nold: {out_old_b}\nnew: {out_new_b}"



if __name__ == "__main__":
    test_lane_property_embedding_equivalence()
