import torch
import pickle
import numpy as np
import glob
import onnx
import onnxruntime as ort
from torch.distributions.categorical import Categorical
from torch.nn import functional as F

from src.net import NetC, VehicleTokenizer

# load data
input_a = pickle.load(open("./data/input_a.pkl", 'rb'))
selected_indices = pickle.load(open("./data/selected_indices.pkl", 'rb'))
input_b_list = pickle.load(open("./data/input_b_list.pkl", 'rb'))

inputa_polygan, inputa_polyline, inputa_poly_mask, inputa_property = input_a
inputb_polygans, inputb_polylines, inputb_poly_masks, inputb_propertys = input_b_list

# load tokenizer
template_set = glob.glob("*.npy")[0]
vehicle_tokenizer = VehicleTokenizer(np.load(template_set, allow_pickle=True))

# load model
sess_a = ort.InferenceSession("./model/ab/model_a.onnx")
sess_b = ort.InferenceSession("./model/ab/model_b.onnx")
model_c = NetC.from_pretrained("./model/c")
model_c.cuda()
model_c.eval()

top_k = 10
temperature = 1.0
state_range = 400.0
hist_bolck_size = 380 + 800
t = 15   # config.history_size
pred_nums = 25
input_pos = None

sample_labels = []
max_labels = []

torch.manual_seed(1)
np.random.seed(1)

for i in range(pred_nums):
    if i == 0:
        input_a = dict(
            polygan=inputa_polygan,
            polyline=inputa_polyline,
            mask=inputa_poly_mask,
            property=inputa_property,
        )
        pred_a = sess_a.run(["output"], input_a)[0]
        input_c = torch.from_numpy(pred_a).cuda().to(torch.float32)
        selected_indices = torch.from_numpy(selected_indices).cuda().to(torch.int64)
    else:
        input_b = dict(
            polygan=inputb_polygans[i-1:i],
            polyline=inputb_polylines[i-1:i],
            mask=inputb_poly_masks[i-1:i],
            property=inputb_propertys[i-1:i],
        )
        pred_b = sess_b.run(["output"], input_b)[0]
        input_c = torch.cat([input_c, torch.from_numpy(pred_b).cuda().to(torch.float32)], dim=1)
        selected_indices = torch.cat([selected_indices, torch.tensor([hist_bolck_size + i - 1], device=input_c.device, dtype=torch.int64)], dim=0)

    logits = model_c(input_c, selected_indices=selected_indices)    # [b, pl, output_num]
    # if i == 0:
    #     with open(f'./data/logits_pred{i}.pkl', 'wb') as fw:
    #         pickle.dump(logits.detach().cpu().numpy(), fw)
    #     print(f'save logits pred{i}')

    max_label = torch.argmax(logits, dim=-1, keepdim=True)  # 形状变为 (1, 1, 1)
    max_labels.append(max_label.squeeze(-1))

    # logits = logits / temperature
    # if top_k is not None:
    #     v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
    #     logits[logits < v[:, :, [-1]]] = -float("Inf")
    # probs = F.softmax(logits, dim=-1)  # b * pl * output_num
    # sample_label = Categorical(probs).sample()  # b * pl
    # print(f'next sample_label: {sample_label},\tmax_label: {max_label}')


    sample_labels.append(max_label)
    print(f'max label: {max_label}')

sample_labels = torch.cat(sample_labels, dim=1)  # [b, pred_times * pl]
max_labels = torch.cat(max_labels, dim=1)  # [b, pred_times * pl]
print(f'sample_labels: {sample_labels}')
print(f'max_labels: {max_labels}')
