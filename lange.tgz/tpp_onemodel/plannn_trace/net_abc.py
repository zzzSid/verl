import inspect
import math
from typing import Optional
from typing import Tuple

import numpy as np
import torch
from scipy.spatial.transform import Rotation as R
from torch import nn
from torch.distributions.categorical import Categorical
from torch.nn import functional as F
from transformers import PretrainedConfig
from transformers import PreTrainedModel

from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import get_corner
from tpp_onemodel.data.dataset.plannn2_dataset_utils.utils import get_corners


class VehicleTokenizer:
    def __init__(self, template_set):
        self.template_set = template_set
        self.template_corners = np.array([get_corner(t) for t in self.template_set])  # n x 4 x 2

    def __call__(self, target, with_error=False):
        # target: [x, y, yaw]
        target_corner = get_corner(target)[None, ...]  # 1 x 4 x 2
        distances = np.mean(np.linalg.norm(self.template_corners - target_corner, axis=2), axis=1)
        if with_error:
            argidx = np.argmin(distances)
            return argidx, distances[argidx]
        return np.argmin(distances)

    def batch_tokenize(self, targets, with_error=False):
        target_corners = get_corners(targets)  # b x 4 x 2
        diff = target_corners[:, None, :, :] - self.template_corners[None, :, :, :]  # b x n x 4 x 2
        distances = np.mean(np.linalg.norm(diff, axis=3), axis=2)  # b x n
        if with_error:
            argidx = np.argmin(distances, axis=1)  # b
            return argidx, np.min(distances, axis=1)  # b
        return np.argmin(distances, axis=1)  # b

    def distance(self, target):
        target_corner = get_corner(target)[None, ...]  # 1 x 4 x 2
        distances = np.mean(np.linalg.norm(self.template_corners - target_corner, axis=2), axis=1)
        return np.min(distances)

    def decode(self, token_id):
        return self.template_set[token_id]

    def __len__(self):
        return len(self.template_set)


class LayerNorm(nn.Module):
    """LayerNorm but with an optional bias. PyTorch doesn't support simply bias=False"""

    def __init__(self, ndim, bias):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(ndim))
        self.bias = nn.Parameter(torch.zeros(ndim)) if bias else None

    def forward(self, input):
        return F.layer_norm(input, self.weight.shape, self.weight, self.bias, 1e-5)


class RMSNorm(torch.nn.Module):
    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))

    def _norm(self, x):
        return x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps)

    def forward(self, x):
        output = self._norm(x.float()).type_as(x)
        return output * self.weight


class DyT(nn.Module):
    def __init__(self, num_features, alpha_init_value=0.5):
        super().__init__()
        self.alpha = nn.Parameter(torch.ones(1) * alpha_init_value)
        self.weight = nn.Parameter(torch.ones(num_features))
        self.bias = nn.Parameter(torch.zeros(num_features))

    def forward(self, x):
        x = torch.tanh(self.alpha * x)
        return x * self.weight + self.bias


def build_mlps(c_in, mlp_channels=None, ret_before_act=False, without_norm=False):
    layers = []
    num_layers = len(mlp_channels)

    for k in range(num_layers):
        if k + 1 == num_layers and ret_before_act:
            layers.append(nn.Linear(c_in, mlp_channels[k], bias=True))
        else:
            if without_norm:
                layers.extend([nn.Linear(c_in, mlp_channels[k], bias=True), nn.GELU()])
            else:
                layers.extend(
                    [nn.Linear(c_in, mlp_channels[k], bias=False), LayerNorm(mlp_channels[k], bias=False), nn.GELU()]
                )
            c_in = mlp_channels[k]

    return nn.Sequential(*layers)


class Plannn2PointNetDynPolylineEncoder(nn.Module):
    def __init__(self, in_channels, hidden_dim, num_layers=3, num_pre_layers=1, out_channels=None):
        super().__init__()
        self.pre_mlps = build_mlps(c_in=in_channels, mlp_channels=[hidden_dim] * num_pre_layers, ret_before_act=False)
        self.mlps = build_mlps(
            c_in=hidden_dim, mlp_channels=[hidden_dim] * (num_layers - num_pre_layers), ret_before_act=False
        )

        if out_channels is not None:
            self.out_mlps = build_mlps(
                c_in=hidden_dim, mlp_channels=[hidden_dim, out_channels], ret_before_act=True, without_norm=True
            )
        else:
            self.out_mlps = None

    def forward(self, polylines, polylines_mask):
        """
        Args:
            polylines (batch_size, num_polylines, num_points):
            polylines_mask (batch_size, num_polylines, num_points):

        Returns:
            feature (batch_size, num_polylines, hidden_dim or out_channels)
        """
        batch_size, num_polylines, channels = polylines.shape

        # pre-mlp
        polylines_feature = self.pre_mlps(polylines)  # (N, C)
        polylines_feature = torch.where(polylines_mask.unsqueeze(-1), polylines_feature, torch.zeros_like(polylines_feature))

        # mlp
        polylines_feature = self.mlps(polylines_feature)
        feature_buffers = torch.where(
            polylines_mask.unsqueeze(-1),
            polylines_feature,
            torch.zeros((1, num_polylines, 768), device=polylines_feature.device, dtype=polylines_feature.dtype),
        )

        # out-mlp
        if self.out_mlps is not None:
            valid_mask = polylines_mask.sum(dim=-1) > 0
            feature_buffers = self.out_mlps(feature_buffers)  # (N, C)
            feature_buffers = torch.where(valid_mask.unsqueeze(-1), feature_buffers, torch.zeros_like(polylines_feature))
        return feature_buffers


class PointNetPolylineEncoder(nn.Module):
    def __init__(self, in_channels, hidden_dim, num_layers=3, num_pre_layers=1, out_channels=None):
        super().__init__()
        self.pre_mlps = build_mlps(c_in=in_channels, mlp_channels=[hidden_dim] * num_pre_layers, ret_before_act=False)
        self.mlps = build_mlps(
            c_in=hidden_dim * 2, mlp_channels=[hidden_dim] * (num_layers - num_pre_layers), ret_before_act=False
        )

        if out_channels is not None:
            self.out_mlps = build_mlps(
                c_in=hidden_dim, mlp_channels=[hidden_dim, out_channels], ret_before_act=True, without_norm=True
            )
        else:
            self.out_mlps = None

    def forward(self, polylines, polylines_mask):
        """
        Args:
            polylines (batch_size, num_polylines, num_points, C):
            polylines_mask (batch_size, num_polylines, num_points):

        Returns:
            feature (batch_size, num_polylines, hidden_dim or out_channels)
        """
        # batch_size, num_polylines, num_points, C = polylines.shape
        batch_size, token_size, num_points, C = polylines.shape

        # pre-mlp
        polylines_feature = self.pre_mlps(polylines)  # (N, na, nb, C)
        polylines_feature = torch.where(polylines_mask.unsqueeze(-1), polylines_feature, torch.zeros_like(polylines_feature))

        # get global feature
        pooled_feature = polylines_feature.max(dim=2)[0]
        polylines_feature = torch.cat(
            # (polylines_feature, pooled_feature[:, :, None, :].repeat(1, 1, num_points, 1)), dim=-1
            (
                polylines_feature,
                pooled_feature[:, :, None, :].reshape(1, token_size, 1, 768).expand(1, token_size, num_points, 768),
            ),
            dim=-1,
        )

        # mlp
        polylines_feature = self.mlps(polylines_feature)
        # feature_buffers = torch.where(polylines_mask.unsqueeze(-1), polylines_feature, torch.zeros_like(polylines_feature) )
        feature_buffers = torch.where(
            polylines_mask.unsqueeze(-1),
            polylines_feature,
            torch.zeros((1, token_size, 4, 768), device=polylines_feature.device, dtype=polylines_feature.dtype),
        )

        # max-pooling
        feature_buffers = feature_buffers.max(dim=2)[0]  # (batch_size, token_size, C)

        # out-mlp
        if self.out_mlps is not None:
            valid_mask = polylines_mask.sum(dim=-1) > 0
            feature_buffers = self.out_mlps(feature_buffers)  # (N, C)
            feature_buffers = torch.where(valid_mask.unsqueeze(-1), feature_buffers, torch.zeros_like(polylines_feature))
        return feature_buffers


class CausalSelfAttention(nn.Module):

    def __init__(self, config):
        super().__init__()
        assert config.n_embd % config.n_head == 0
        # key, query, value projections for all heads, but in a batch
        self.c_attn = nn.Linear(config.n_embd, 3 * config.n_embd, bias=config.bias)
        # output projection
        self.c_proj = nn.Linear(config.n_embd, config.n_embd, bias=config.bias)
        # regularization
        self.attn_dropout = nn.Dropout(config.dropout)
        self.resid_dropout = nn.Dropout(config.dropout)
        self.n_head = config.n_head
        self.n_embd = config.n_embd
        self.dropout = config.dropout
        self.env_block_size = config.env_block_size
        self.use_kv_cache = config.use_kv_cache
        self.is_planner = config.is_planner
        self.ego_token_num = config.ego_token_num
        block_size = config.env_block_size + config.state_block_size + config.max_token_len

        # flash attention make GPU go brrrrr but support is only in PyTorch >= 2.0
        self.flash = hasattr(torch.nn.functional, "scaled_dot_product_attention")
        if not self.flash:
            print("WARNING: using slow attention. Flash Attention requires PyTorch >= 2.0")
        # # causal mask to ensure that attention is only applied to the left in the input sequence
        bias = torch.tril(torch.ones(block_size, block_size)).bool()    # 标准下三角矩阵
        # # env区域全部可见
        bias[:, : config.env_block_size + config.state_block_size] = 1

        bias = bias.view(1, 1, block_size, block_size)
        self.register_buffer("bias", bias)

        # import cv2
        # import numpy as np
        # bias_image = (bias[0][0].cpu().numpy() * 255).astype(np.uint8)
        # cv2.imwrite('bias_matrix_visualization_prefillpadding.png', bias_image)
        # import ipdb;ipdb.set_trace()

    def forward(self, x, padding_index=None, input_pos=None, selected_indices=None):
        """
        padding_index: B x T_full boolean tensor indicating which tokens are padding.
        """
        B, T, C = x.size()  # batch size, sequence length, embedding dimensionality (n_embd)

        # calculate query, key, values for all heads in batch and move head forward to be the batch dim
        q, k, v = self.c_attn(x).split(self.n_embd, dim=2)

        k = k.view(B, T, self.n_head, C // self.n_head).transpose(1, 2)  # (B, nh, T, hs)
        q = q.view(B, T, self.n_head, C // self.n_head).transpose(1, 2)  # (B, nh, T, hs)
        v = v.view(B, T, self.n_head, C // self.n_head).transpose(1, 2)  # (B, nh, T, hs)

        bias = self.bias
        _, _, block_size, _ = bias.shape
        bias = bias.expand(B, 1, block_size, block_size)
        # update kv cache
        assert input_pos is None
        if selected_indices is not None:
            bias = bias[..., selected_indices, :][..., selected_indices]    # 在后两维保留对应索引的元素
        else:
            bias = bias[:, :, :T, :T]
            # padding位置的列全部填0
            padding_index = padding_index.unsqueeze(1).unsqueeze(2).expand(B, 1, T, T)
            bias = bias.masked_fill(padding_index, 0)
            # 防止envlength为0导致所有env token都为nan
            bias[:, :, : self.env_block_size, 0] = 1

        # causal self-attention; Self-attend: (B, nh, T, hs) x (B, nh, hs, T) -> (B, nh, T, T)
        if self.flash:
            # efficient attention using Flash Attention CUDA kernels
            y = torch.nn.functional.scaled_dot_product_attention(
                q, k, v, attn_mask=bias, dropout_p=self.dropout if self.training else 0
            )
            y = y.transpose(1, 2).contiguous().view(B, T, C)  # re-assemble all head outputs side by side
        else:
            # manual implementation of attention
            att = (q @ k.transpose(-2, -1)) * (1.0 / math.sqrt(k.size(-1)))
            att = att.masked_fill(bias.logical_not(), float("-inf"))
            att = F.softmax(att, dim=-1)
            att = self.attn_dropout(att)
            y = att @ v  # (B, nh, T, T) x (B, nh, T, hs) -> (B, nh, T, hs)
            y = y.transpose(1, 2).contiguous().view(B, T, C)  # re-assemble all head outputs side by side

        # output projection
        y = self.resid_dropout(self.c_proj(y))
        return y


class MLP(nn.Module):

    def __init__(self, config):
        super().__init__()
        self.c_fc = nn.Linear(config.n_embd, 4 * config.n_embd, bias=config.bias)
        self.gelu = nn.GELU()
        self.c_proj = nn.Linear(4 * config.n_embd, config.n_embd, bias=config.bias)
        self.dropout = nn.Dropout(config.dropout)

    def forward(self, x):
        x = self.c_fc(x)
        x = self.gelu(x)
        x = self.c_proj(x)
        x = self.dropout(x)
        return x


class Block(nn.Module):

    def __init__(self, config):
        super().__init__()
        # self.ln_1 = RMSNorm(config.n_embd)
        # self.ln_2 = RMSNorm(config.n_embd)
        # self.ln_1 = DyT(config.n_embd)
        # self.ln_2 = DyT(config.n_embd)
        self.ln_1 = LayerNorm(config.n_embd, bias=config.bias)
        self.ln_2 = LayerNorm(config.n_embd, bias=config.bias)
        self.attn = CausalSelfAttention(config)
        self.mlp = MLP(config)

    def forward(self, x, padding_index=None, input_pos=None, selected_indices=None):
        x = x + self.attn(self.ln_1(x), padding_index=padding_index, input_pos=input_pos, selected_indices=selected_indices)
        x = x + self.mlp(self.ln_2(x))
        return x


class MyCustomConfig(PretrainedConfig):
    model_type = "plannn2-drive"

    def __init__(
        self,
        is_planner: bool = False,
        # 大类：pad, ego, vehicle, bicycle, pedestrian, sobjs, road_sign, lane_lines, road_edge, stop_line, tld
        property_cls1_vocab_size: int = 16,
        # cls2：pad, 40个roadsign, 15个lane_line type，4个tld color
        property_cls2_vocab_size: int = 74,
        # cls3: pad, 9个lane_line color
        property_cls3_vocab_size: int = 10,
        # cls6: pad, left = 1, right = 2
        property_cls6_vocab_size: int = 3,
        # cls7: pad, np_lcc_activate = 1, np_lcc_deactivate = 2
        property_cls7_vocab_size: int = 3,
        property_cls11_vocab_size: int = 5,
        tid_vocab_size: int = 300,  # 第一个为pad
        timestamp_vocab_size: int = 100,
        # data config
        env_block_size: int = 200,
        state_block_size: int = 200,
        history_state_size: int = 200,
        output_num: int = 512,
        history_size: int = 3,
        polyline_size: int = 50,
        # net config
        n_layer: int = 12,
        n_head: int = 12,
        n_embd: int = 768,
        dropout: float = 0.0,
        bias: bool = False,  # True: bias in Linears and LayerNorms, like GPT-2. False: a bit better and faster
        use_kv_cache: bool = False,
        kv_cache_batch_size: int = 1,
        ego_token_num: int = 40,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.is_planner = is_planner
        self.property_cls1_vocab_size = property_cls1_vocab_size
        self.property_cls2_vocab_size = property_cls2_vocab_size
        self.property_cls3_vocab_size = property_cls3_vocab_size
        self.property_cls6_vocab_size = property_cls6_vocab_size
        self.property_cls7_vocab_size = property_cls7_vocab_size
        self.property_cls11_vocab_size = property_cls11_vocab_size
        self.tid_vocab_size = tid_vocab_size
        self.timestamp_vocab_size = timestamp_vocab_size
        self.env_block_size = env_block_size
        self.state_block_size = state_block_size
        self.output_num = output_num
        self.history_size = history_size
        self.polyline_size = polyline_size
        self.n_layer = n_layer
        self.n_head = n_head
        self.n_embd = n_embd
        self.dropout = dropout
        self.bias = bias
        self.use_kv_cache = use_kv_cache
        self.kv_cache_batch_size = kv_cache_batch_size
        self.ego_token_num = ego_token_num


class NetA(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.polyline_encoder = PointNetPolylineEncoder(2, config.n_embd)
        self.polygan_encoder = PointNetPolylineEncoder(2, config.n_embd)
        self.dyn_polyline_encoder = PointNetPolylineEncoder(2, config.n_embd)
        self.dyn_polygon_encoder = Plannn2PointNetDynPolylineEncoder(120, config.n_embd)
        self.property_embedding_1 = nn.Embedding(config.property_cls1_vocab_size, config.n_embd, padding_idx=0)
        self.property_embedding_2 = nn.Embedding(config.property_cls2_vocab_size, config.n_embd, padding_idx=0)
        self.property_embedding_3 = nn.Embedding(config.property_cls3_vocab_size, config.n_embd, padding_idx=0)
        self.property_embedding_4 = nn.Embedding(config.property_cls4_vocab_size, config.n_embd, padding_idx=0)
        self.property_embedding_6 = nn.Embedding(config.property_cls6_vocab_size, config.n_embd, padding_idx=0)
        self.property_embedding_7 = nn.Embedding(config.property_cls7_vocab_size, config.n_embd, padding_idx=0)
        self.property_embedding_11 = nn.Embedding(config.property_cls11_vocab_size, config.n_embd)
        self.lane_direction_embeddings = nn.ModuleList([nn.Embedding(2, config.n_embd) for _ in range(5)])
        self.lane_ok_embeddings = nn.Embedding(2, config.n_embd)

        self.tid_embedding = nn.Embedding(config.tid_vocab_size, config.n_embd, padding_idx=0)

        self.timestamp_embedding = nn.Embedding(config.history_size + config.max_token_len, config.n_embd)
        self.ego_speed_proj = nn.Linear(1, config.n_embd)

    def forward(self, env_polygons, env_polylines, env_polymask, env_property, dyn_polygons, dyn_polylines, dyn_polymask, dyn_property, ego_polygons, ego_polylines, ego_polymask, ego_property):
        """
        Args:
            polygans: [batch_size, state_num, 4, 2]
            polylines: [batch_size, state_num, num_points, 2]
            polymask: [batch_size, state_num, 2]
            property: [batch_size, state_num, property_dim]

        """

        env_polymask = env_polymask.to(torch.int64)
        env_property = env_property.to(torch.float32)
        dyn_polymask = dyn_polymask.to(torch.int64)
        dyn_property = dyn_property.to(torch.float32)
        ego_polymask = ego_polymask.to(torch.int64)
        ego_property = ego_property.to(torch.float32)

        env_index_select_range = torch.arange(1, env_property.shape[1], device=env_property.device)
        dyn_index_select_range = torch.arange(1, dyn_property.shape[1], device=dyn_property.device)

        property = torch.cat([torch.index_select(env_property, 1, env_index_select_range), torch.index_select(dyn_property, 1, dyn_index_select_range), ego_property], dim=1)

        dyn_polygon_embeddings = self.dyn_polygon_embedding(dyn_polygons, dyn_polymask[:, :, 0])
        dyn_polyline_embeddings = self.dyn_polyline_embedding(dyn_polylines, dyn_polymask[:, :, 1])

        env_polygon_embeding = self.polygan_embedding(env_polygons, env_polymask[:, :, 0])
        env_polyline_embeding = self.polyline_embedding(env_polylines, env_polymask[:, :, 1])

        ego_polygon_embeding = self.polygan_embedding(ego_polygons, ego_polymask[:, :, 0])
        ego_polyline_embeding = self.polyline_embedding(ego_polylines, ego_polymask[:, :, 1])

        property_embeding = self.property_embedding(property)

        polygon_embeding = torch.cat([torch.index_select(env_polygon_embeding, 1, env_index_select_range), torch.index_select(dyn_polygon_embeddings, 1, dyn_index_select_range), ego_polygon_embeding], dim=1)
        polyline_embeding = torch.cat([torch.index_select(env_polyline_embeding, 1, env_index_select_range), torch.index_select(dyn_polyline_embeddings, 1, dyn_index_select_range), ego_polyline_embeding], dim=1)

        x = polygon_embeding + polyline_embeding + property_embeding
        # ego_speed_embeding = F.linear(ego_speed, self.ego_speed_proj.weight,self.ego_speed_proj.bias
        # ).unsqueeze(1)
        # x[:,-1:,:] = x[:,-1:,:] + ego_speed_embeding

        return x.half()

    def polyline_embedding(self, polylines, polylinemask):
        b, n, polyline_len, _ = polylines.shape
        # convert B x N mask (each element indicate True num of points)
        # to B x N x polyline_len x 2 mask
        # polylinemask_full = torch.arange(polyline_len, device=polylines.device)
        polylinemask_full = torch.arange(4)
        # polylinemask_full = polylinemask_full.view(1, 1, polyline_len).expand(b, n, polyline_len)
        polylinemask_full = polylinemask_full.view(1, 1, 4).expand(b, n, 4)
        polylinemask_full = polylinemask_full < polylinemask.unsqueeze(-1)

        polyline_embeding = self.polyline_encoder(polylines, polylinemask_full)  # B x N x d
        polyline_embeding = polyline_embeding * (polylinemask.unsqueeze(-1) > 0)  # set masked embedding to 0
        return polyline_embeding

    def polygan_embedding(self, polygans, polyganmask):
        token_size = polyganmask.shape[1]
        polyganmask_full = polyganmask.unsqueeze(-1).expand(1, token_size, 4).bool()
        polygan_embeding = self.polygan_encoder(polygans, polyganmask_full)
        polygan_embeding = polygan_embeding * (polyganmask.unsqueeze(-1) > 0)
        return polygan_embeding

    def property_embedding(self, property):
        # ego_v_embedding =property[:, :, 10:11] *  F.linear(property[:, :, 10:11], self.ego_speed_proj.weight,self.ego_speed_proj.bias)
        ego_v_w = self.ego_speed_proj.weight.squeeze(1).view(1, 1, -1)
        ego_v_bias = self.ego_speed_proj.bias.view(1, 1, -1)
        ego_v_embedding = property[:, :, 10:11] * ego_v_w + ego_v_bias
        property = property.to(torch.int64)
        cls1_embeding = self.property_embedding_1(property[:, :, 0])
        cls2_embeding = self.property_embedding_2(property[:, :, 1])
        cls3_embeding = self.property_embedding_3(property[:, :, 2])
        cls4_embeding = self.property_embedding_4(property[:, :, 5])
        cls6_embeding = self.property_embedding_6(property[:, :, 7])
        cls7_embeding = self.property_embedding_7(property[:, :, 8])
        cls11_embeding = self.property_embedding_11(property[:, :, 11])
        tid_embeding = self.tid_embedding(property[:, :, 3])
        timestamp_embeding = self.timestamp_embedding(property[:, :, 4])
        lane_info_embeding = self.lane_property_embedding(property)

        property_embeding = ego_v_embedding + cls1_embeding + cls2_embeding + cls3_embeding + cls4_embeding + cls6_embeding + cls7_embeding + tid_embeding + timestamp_embeding + lane_info_embeding + cls11_embeding
        return property_embeding

    def dyn_polygon_embedding(self, dyn_polygons, dyn_polygonmask):
        B, N, *_ = dyn_polygons.shape
        polygonmask_full = dyn_polygonmask.bool()
        polygon_embeding = self.dyn_polygon_encoder(dyn_polygons.reshape(B, N, -1), polygonmask_full)
        polygon_embeding = polygon_embeding * (dyn_polygonmask.unsqueeze(-1) > 0)
        return polygon_embeding

    def dyn_polyline_embedding(self, polylines, polylinemask):
        b, n, polyline_len, _ = polylines.shape
        # convert B x N mask (each element indicate True num of points)
        # to B x N x polyline_len x 2 mask
        polylinemask_full = torch.arange(polyline_len, device=polylines.device)
        polylinemask_full = polylinemask_full.view(1, 1, polyline_len).expand(b, n, polyline_len)
        polylinemask_full = polylinemask_full < polylinemask.unsqueeze(-1)

        polyline_embeding = self.dyn_polyline_encoder(polylines, polylinemask_full)  # B x N x d
        polyline_embeding = polyline_embeding * (polylinemask.unsqueeze(-1) > 0)  # set masked embedding to 0
        return polyline_embeding

    def lane_property_embedding(self, property):
        direction_index = ((property[:, :, 0] == self.config.lane_info_id)
                           | (property[:, :, 0] == self.config.lane_highline_info_id)
                           | (property[:, :, 0] == self.config.road_arrow_id)
                           | (property[:, :, 0] == self.config.tld_id))
        lane_index = ((property[:, :, 0] == self.config.lane_info_id)
                      | (property[:, :, 0] == self.config.lane_highline_info_id))

        # # 非车道token没有lane_is_ok和右掉头信息.
        # lane_is_ok = self.lane_ok_embeddings(property[:, :, 6] & 0x1) * lane_index.unsqueeze(2)
        # lane_direction_rightturn = self.lane_direction_embeddings[0]((property[:, :, 6] >> 1) & 0x1) * lane_index.unsqueeze(2)
        # lane_direction_right = self.lane_direction_embeddings[1]((property[:, :, 6] >> 2) & 0x1)
        # lane_direction_straight = self.lane_direction_embeddings[2]((property[:, :, 6] >> 3) & 0x1)
        # lane_direction_left= self.lane_direction_embeddings[3]((property[:, :, 6] >> 4) & 0x1)
        # lane_direction_leftturn= self.lane_direction_embeddings[4]((property[:, :, 6] >> 5) & 0x1)

        flags = property[:, :, 6]                      # [B, T]  int64 或 int32
        lane_mask = lane_index.unsqueeze(-1)           # [B, T, 1]

        # 1. 只保留最低位（lane_is_ok）
        bit0 = flags % 2                               # [B, T]

        # 2. 第 1~5 位：先整除 2^k 再模 2
        pow2 = torch.tensor([2, 4, 8, 16, 32], device=flags.device)  # [5]
        tmp = flags.unsqueeze(-1) // pow2            # [B, T, 5]
        bits = tmp % 2                                # [B, T, 5]

        # 3. 查表
        embed_ok = self.lane_ok_embeddings(bit0) * lane_mask
        embed_rightturn = self.lane_direction_embeddings[0](bits[..., 0]) * lane_mask
        embed_right = self.lane_direction_embeddings[1](bits[..., 1])
        embed_straight = self.lane_direction_embeddings[2](bits[..., 2])
        embed_left = self.lane_direction_embeddings[3](bits[..., 3])
        embed_leftturn = self.lane_direction_embeddings[4](bits[..., 4])

        # 4. 求和
        lane_embedding = (embed_ok + embed_rightturn + embed_right
                          + embed_straight + embed_left + embed_leftturn)
        lane_embedding = lane_embedding * direction_index.unsqueeze(-1)
        return lane_embedding

    def lane_property_embedding_old_impl(self, property):
        direction_index = ((property[:, :, 0] == self.config.lane_info_id)
                           | (property[:, :, 0] == self.config.lane_highline_info_id)
                           | (property[:, :, 0] == self.config.road_arrow_id)
                           | (property[:, :, 0] == self.config.tld_id))
        lane_index = ((property[:, :, 0] == self.config.lane_info_id)
                      | (property[:, :, 0] == self.config.lane_highline_info_id))

        flags = property[:, :, 6]

        lane_is_ok_flag = torch.remainder(flags, 2)
        lane_is_ok = self.lane_ok_embeddings(lane_is_ok_flag) * lane_index.unsqueeze(2)

        lane_direction_rightturn_flag = torch.remainder(torch.div(flags, 2, rounding_mode='floor'), 2)
        lane_direction_rightturn = self.lane_direction_embeddings[0](lane_direction_rightturn_flag) * lane_index.unsqueeze(2)

        lane_direction_right_flag = torch.remainder(torch.div(flags, 4, rounding_mode='floor'), 2)
        lane_direction_right = self.lane_direction_embeddings[1](lane_direction_right_flag)

        lane_direction_straight_flag = torch.remainder(torch.div(flags, 8, rounding_mode='floor'), 2)
        lane_direction_straight = self.lane_direction_embeddings[2](lane_direction_straight_flag)

        lane_direction_left_flag = torch.remainder(torch.div(flags, 16, rounding_mode='floor'), 2)
        lane_direction_left = self.lane_direction_embeddings[3](lane_direction_left_flag)

        lane_direction_leftturn_flag = torch.remainder(torch.div(flags, 32, rounding_mode='floor'), 2)
        lane_direction_leftturn = self.lane_direction_embeddings[4](lane_direction_leftturn_flag)

        lane_embeding = lane_is_ok + lane_direction_rightturn + lane_direction_right + lane_direction_straight + \
            lane_direction_left + lane_direction_leftturn
        lane_embeding = lane_embeding * direction_index.unsqueeze(2)
        return lane_embeding


class NetB(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.polyline_encoder = PointNetPolylineEncoder(2, config.n_embd)
        self.polygan_encoder = PointNetPolylineEncoder(2, config.n_embd)
        self.property_embedding_1 = nn.Embedding(config.property_cls1_vocab_size, config.n_embd, padding_idx=0)
        self.property_embedding_2 = nn.Embedding(config.property_cls2_vocab_size, config.n_embd, padding_idx=0)
        self.property_embedding_3 = nn.Embedding(config.property_cls3_vocab_size, config.n_embd, padding_idx=0)
        self.property_embedding_4 = nn.Embedding(config.property_cls4_vocab_size, config.n_embd, padding_idx=0)
        self.property_embedding_6 = nn.Embedding(config.property_cls6_vocab_size, config.n_embd, padding_idx=0)
        self.property_embedding_7 = nn.Embedding(config.property_cls7_vocab_size, config.n_embd, padding_idx=0)
        self.lane_direction_embeddings = nn.ModuleList([nn.Embedding(2, config.n_embd) for _ in range(5)])
        self.lane_ok_embeddings = nn.Embedding(2, config.n_embd)

        self.tid_embedding = nn.Embedding(config.tid_vocab_size, config.n_embd, padding_idx=0)
        self.timestamp_embedding = nn.Embedding(config.timestamp_vocab_size, config.n_embd)

    def forward(self, polygans, polylines, polymask, property):
        """
        Args:
            polygans: [batch_size, state_num, 4, 2]
            polylines: [batch_size, state_num, num_points, 2]
            polymask: [batch_size, state_num, 2]
            property: [batch_size, state_num, property_dim]
            label: [batch_size, state_num-envblock_size]
            pred_length: int, default 1
            input_pos: [real_state_num] if provided, label must be None.
        """
        polymask = polymask.to(torch.int64)
        property = property.to(torch.int64)

        polygan_embeding = self.polygan_embedding(polygans, polymask[:, :, 0])
        polyline_embeding = self.polyline_embedding(polylines, polymask[:, :, 1])
        property_embeding = self.property_embedding(property)
        x = polygan_embeding + polyline_embeding + property_embeding
        return x.half()

    def polyline_embedding(self, polylines, polylinemask):
        b, n, polyline_len, _ = polylines.shape
        # convert B x N mask (each element indicate True num of points)
        # to B x N x polyline_len x 2 mask
        # polylinemask_full = torch.arange(polyline_len, device=polylines.device)
        polylinemask_full = torch.arange(4)
        # polylinemask_full = polylinemask_full.view(1, 1, polyline_len).expand(b, n, polyline_len)
        polylinemask_full = polylinemask_full.reshape(1, 1, 4).expand(b, n, 4)
        polylinemask_full = polylinemask_full < polylinemask.unsqueeze(-1)

        polyline_embeding = self.polyline_encoder(polylines, polylinemask_full)  # B x N x d
        polyline_embeding = polyline_embeding * (polylinemask.unsqueeze(-1) > 0)  # set masked embedding to 0
        return polyline_embeding

    def polygan_embedding(self, polygans, polyganmask):
        polyganmask_full = polyganmask.unsqueeze(-1).expand(1, 1, 4).bool()
        polygan_embeding = self.polygan_encoder(polygans, polyganmask_full)
        polygan_embeding = polygan_embeding * (polyganmask.unsqueeze(-1) > 0)
        return polygan_embeding

    def property_embedding(self, property):
        cls1_embeding = self.property_embedding_1(property[:, :, 0])
        cls2_embeding = self.property_embedding_2(property[:, :, 1])
        cls3_embeding = self.property_embedding_3(property[:, :, 2])
        cls4_embeding = self.property_embedding_4(property[:, :, 5])
        cls6_embeding = self.property_embedding_6(property[:, :, 7])
        cls7_embeding = self.property_embedding_7(property[:, :, 8])
        tid_embeding = self.tid_embedding(property[:, :, 3])
        timestamp_embeding = self.timestamp_embedding(property[:, :, 4])
        lane_info_embeding = self.lane_property_embedding(property)

        property_embeding = cls1_embeding + cls2_embeding + cls3_embeding + cls4_embeding + cls6_embeding + cls7_embeding + tid_embeding + timestamp_embeding + lane_info_embeding
        return property_embeding

    def lane_property_embedding(self, property):
        direction_index = ((property[:, :, 0] == self.config.lane_info_id)
                           | (property[:, :, 0] == self.config.lane_highline_info_id)
                           | (property[:, :, 0] == self.config.road_arrow_id)
                           | (property[:, :, 0] == self.config.tld_id))
        lane_index = ((property[:, :, 0] == self.config.lane_info_id)
                      | (property[:, :, 0] == self.config.lane_highline_info_id))

        flags = property[:, :, 6]                      # [B, T]  int64 或 int32
        lane_mask = lane_index.unsqueeze(-1)           # [B, T, 1]

        # 1. 只保留最低位（lane_is_ok）
        bit0 = flags % 2                               # [B, T]

        # 2. 第 1~5 位：先整除 2^k 再模 2
        pow2 = torch.tensor([2, 4, 8, 16, 32], device=flags.device)  # [5]
        tmp = flags.unsqueeze(-1) // pow2            # [B, T, 5]
        bits = tmp % 2                                # [B, T, 5]

        # 3. 查表
        embed_ok = self.lane_ok_embeddings(bit0) * lane_mask
        embed_rightturn = self.lane_direction_embeddings[0](bits[..., 0]) * lane_mask
        embed_right = self.lane_direction_embeddings[1](bits[..., 1])
        embed_straight = self.lane_direction_embeddings[2](bits[..., 2])
        embed_left = self.lane_direction_embeddings[3](bits[..., 3])
        embed_leftturn = self.lane_direction_embeddings[4](bits[..., 4])

        # 4. 求和
        lane_embedding = (embed_ok + embed_rightturn + embed_right
                          + embed_straight + embed_left + embed_leftturn)
        lane_embedding = lane_embedding * direction_index.unsqueeze(-1)
        return lane_embedding

    def lane_property_embedding_old_impl(self, property):
        direction_index = ((property[:, :, 0] == self.config.lane_info_id)
                           | (property[:, :, 0] == self.config.lane_highline_info_id)
                           | (property[:, :, 0] == self.config.road_arrow_id)
                           | (property[:, :, 0] == self.config.tld_id))
        lane_index = ((property[:, :, 0] == self.config.lane_info_id)
                      | (property[:, :, 0] == self.config.lane_highline_info_id))

        flags = property[:, :, 6]

        lane_is_ok_flag = torch.remainder(flags, 2)
        lane_is_ok = self.lane_ok_embeddings(lane_is_ok_flag) * lane_index.unsqueeze(2)

        lane_direction_rightturn_flag = torch.remainder(torch.div(flags, 2, rounding_mode='floor'), 2)
        lane_direction_rightturn = self.lane_direction_embeddings[0](lane_direction_rightturn_flag) * lane_index.unsqueeze(2)

        lane_direction_right_flag = torch.remainder(torch.div(flags, 4, rounding_mode='floor'), 2)
        lane_direction_right = self.lane_direction_embeddings[1](lane_direction_right_flag)

        lane_direction_straight_flag = torch.remainder(torch.div(flags, 8, rounding_mode='floor'), 2)
        lane_direction_straight = self.lane_direction_embeddings[2](lane_direction_straight_flag)

        lane_direction_left_flag = torch.remainder(torch.div(flags, 16, rounding_mode='floor'), 2)
        lane_direction_left = self.lane_direction_embeddings[3](lane_direction_left_flag)

        lane_direction_leftturn_flag = torch.remainder(torch.div(flags, 32, rounding_mode='floor'), 2)
        lane_direction_leftturn = self.lane_direction_embeddings[4](lane_direction_leftturn_flag)

        lane_embeding = lane_is_ok + lane_direction_rightturn + lane_direction_right + lane_direction_straight + \
            lane_direction_left + lane_direction_leftturn
        lane_embeding = lane_embeding * direction_index.unsqueeze(2)
        return lane_embeding


class NetC(PreTrainedModel):
    config_class = MyCustomConfig

    def __init__(self, config):
        super(NetC, self).__init__(config)
        self.config = config
        self.transfomer = nn.ModuleDict(
            dict(
                h=nn.ModuleList(Block(config) for _ in range(config.n_layer)),
                # ln_f=RMSNorm(config.n_embd),
                # ln_f=DyT(config.n_embd),
                ln_f=LayerNorm(config.n_embd, bias=config.bias),
            )
        )
        self.lm_head = nn.Linear(config.n_embd, config.output_num, bias=False)
        self.action_embedding = nn.Embedding(config.output_num, config.n_embd)
        self.timestamp_embedding = nn.Embedding(config.history_size + config.max_token_len, config.n_embd)

    def prefill(self, x, padding_index=None, input_pos=None, selected_indices=None):
        """
        Args:
            x: [batch_size, state_num, 768]
            input_pos: [real_state_num] if provided, label must be None.
        """

        for layer in self.transfomer["h"]:
            x = layer(x, selected_indices=selected_indices)
        x = self.transfomer["ln_f"](x[:, -1:, :])
        return self.lm_head(x)

    def decode(self, x, actions, padding_index=None, input_pos=None, selected_indices=None):
        """
        Args:
            x: [batch_size, state_num, 768]
            input_pos: [real_state_num] if provided, label must be None.
        """
        action_timestamp = torch.arange(actions.shape[1], device=actions.device) + self.config.history_size
        action_ts_embedding = self.timestamp_embedding(action_timestamp)
        ego_action_embedding = self.action_embedding(actions) + action_ts_embedding.unsqueeze(0)
        x = torch.cat((x, ego_action_embedding), dim=1)
        for layer in self.transfomer["h"]:
            x = layer(x, selected_indices=selected_indices)
        x = self.transfomer["ln_f"](x[:, -1:, :])
        return self.lm_head(x)
