from dataclasses import dataclass
import numpy as np
import torch


cls_mapping = {
    "pad": 0,
    "ego": 1,
    "vehicle": 2,
    "bicycle": 3,
    "pedestrian": 4,
    "static_vehicle": 5,
    "static_bicycle": 6,
    "static_pedestrian": 7,
    "sobj": 8,
    "road_sign": 9,
    "road_arrow": 10,
    "lane_lines": 11,
    "road_edge": 12,
    "stop_line": 13,
    "tld": 14,
    "spd_limit": 15,
    "action_1": 16,
    "action_2": 17,
    "sub_path": 18,
    "lane_info": 19,
    "lane_highline_info": 20,
    "god_polygon": 21,
    "nomap_road_edge": 22,
    "gate_machine": 23,
}

"""
RoadSignClass {
        RoadSignClass_Unknown = 0;
        RoadSignClass_StopLine = 100;
        RoadSignClass_RoadArrow = 200;
        RoadSignClass_RoadArrow_Left = 201;
        RoadSignClass_RoadArrow_Right = 202;
        RoadSignClass_RoadArrow_Left_Right = 203;
        RoadSignClass_RoadArrow_Straight = 204;
        RoadSignClass_RoadArrow_Straight_Right = 205;
        RoadSignClass_RoadArrow_Straight_Left = 206;
        RoadSignClass_RoadArrow_Only_Turn = 207;
        RoadSignClass_RoadArrow_Left_Turn = 208;
        RoadSignClass_RoadArrow_Straight_Turn = 209;
        RoadSignClass_RoadArrow_Left_Merge = 210;
        RoadSignClass_RoadArrow_Right_Merge = 211;
        RoadSignClass_RoadArrow_Forbid_Sign = 212 [deprecated=true];
        RoadSignClass_RoadArrow_Forbid_Only_Sign = 213;   // BL320新增213~220
        RoadSignClass_RoadArrow_Forbid_Left_Sign = 214;
        RoadSignClass_RoadArrow_Forbid_Right_Sign = 215;
        RoadSignClass_RoadArrow_Forbid_Straight_Sign = 216;
        RoadSignClass_RoadArrow_Forbid_Turn_Sign = 217;
        RoadSignClass_RoadArrow_Forbid_Left_Merge_Sign = 218;
        RoadSignClass_RoadArrow_Forbid_Right_Merge_Sign = 219;
        RoadSignClass_RoadArrow_Forbid_Left_And_Turn_Sign = 220;
        RoadSignClass_ZebraCross = 300;
        RoadSignClass_NoParkingArea = 400;
        RoadSignClass_SlowZone = 500;
        RoadSignClass_SpeedBump = 600;
        RoadSignClass_PolePillar = 700;
        RoadSignClass_LimitSpd_Max = 801;
        RoadSignClass_LimitSpd_Min = 802;
        RoadSignClass_TextPattern = 900;
        RoadSignClass_TextPattern_Yield = 901;
        RoadSignClass_TextPattern_Stop = 902;
        RoadSignClass_TextPattern_Variable = 903;
        RoadSignClass_TextPattern_Reversible = 904;
        RoadSignClass_TextPattern_Bike = 905;
        RoadSignClass_TextPattern_Bus = 906;
        RoadSignClass_TextPattern_HOV = 907;
        RoadSignClass_TextPattern_TIME = 908;
        RoadSignClass_TextPattern_WALK = 909;
    }
"""

# {0b0001, "right_turn"}, # no exist always 0
# {0b0010, "right"},
# {0b0100, "Straight"},
# {0b1000, "left"},
# {0b10000, "turn"}
etc_sematic_to_road_sign = {
    204: 1000,  # ETC
    209: 1002,  # UNKNOWN
    212: 1001,  # OTHER
}

road_arrow_to_lane_direction_mapping = {
    201: 0b01000,  # RoadSignClass_RoadArrow_Left
    202: 0b00010,  # RoadSignClass_RoadArrow_Right
    203: 0b01010,  # RoadSignClass_RoadArrow_Left_Right
    204: 0b00100,  # RoadSignClass_RoadArrow_Straight
    205: 0b00110,  # RoadSignClass_RoadArrow_Straight_Right
    206: 0b01100,  # RoadSignClass_RoadArrow_Straight_Left
    207: 0b10000,  # RoadSignClass_RoadArrow_Only_Turn
    208: 0b11000,  # RoadSignClass_RoadArrow_Left_Turn
    209: 0b10100,  # RoadSignClass_RoadArrow_Straight_Turn
    210: 0b00100,  # RoadSignClass_RoadArrow_Left_Merge
    211: 0b00100,  # RoadSignClass_RoadArrow_Right_Merge
    213: 0b00000,  # RoadSignClass_RoadArrow_Forbid_Only_Sign
    214: 0b10110,  # RoadSignClass_RoadArrow_Forbid_Left_Sign
    215: 0b11100,  # RoadSignClass_RoadArrow_Forbid_Right_Sign
    216: 0b11010,  # RoadSignClass_RoadArrow_Forbid_Straight_Sign
    217: 0b01110,  # RoadSignClass_RoadArrow_Forbid_Turn_Sign
    220: 0b00110,  # RoadSignClass_RoadArrow_Forbid_Left_And_Turn_Sign
}

tld_to_lane_direction_mapping = [
    0b10000,  # 0 left turn
    0b1000,  # 1 left
    0b0100,  # 2 straight
    0b0010  # 3 right
]

lane_direction_to_tld_id_mapping = {
    0b10000: 0,
    0b1000: 1,
    0b0100: 2,
    0b0010: 3,
    0b0001: 3,
}

_road_sign_cls2_mapping = {
    0: 1,
    100: 2,
    200: 3,
    201: 4,
    202: 5,
    203: 6,
    204: 7,
    205: 8,
    206: 9,
    207: 10,
    208: 11,
    209: 12,
    210: 13,
    211: 14,
    212: 15,
    213: 16,
    214: 17,
    215: 18,
    216: 19,
    217: 20,
    218: 21,
    219: 22,
    220: 23,
    300: 24,
    400: 25,
    500: 26,
    600: 27,
    700: 28,
    801: 29,
    802: 30,
    900: 31,
    901: 32,
    902: 33,
    903: 34,
    904: 35,
    905: 36,
    906: 37,
    907: 38,
    908: 39,
    909: 40,
    1000: 108,
    1001: 109,
    1002: 110,
    1003: 111,
}


# 二级label映射
def get_road_sign_cls2_mapping(clsid):
    id = _road_sign_cls2_mapping.get(clsid, 0)
    assert 0 <= id <= 40 or 108 <= id <= 111
    return id


_gate_machine_cls2_mapping = {
    10000: 0,  # GateMachine_unknown
    10001: 1,  # GateMachine_closed,
    10002: 2,  # GateMachine_opening,
    10003: 3,  # GateMachine_opened,
}


def get_gate_machine_cls2_mapping(clsid):
    if isinstance(clsid, np.ndarray):
        vfunc = np.vectorize(get_gate_machine_cls2_mapping, otypes=[np.int32])
        return vfunc(clsid)

    _id = _gate_machine_cls2_mapping.get(int(clsid), 0)
    assert 0 <= _id <= 3
    # origin id is 104, id from 0,
    return _id + 104


"""enum LDColor {
        LDColor_Unknown = 0;  // unavailable
        LDColor_White = 1;
        LDColor_Yellow = 2;
        LDColor_Orange = 3;  // unavailable
        LDColor_Blue = 4;    // unavailable
        LDColor_Others = 5;
        LDColor_Green = 6;
        LDColor_Yellow_White = 7;
        LDColor_White_Yellow = 8;
        }
    enum LDType{
        LDType_Unknown = 0;
        LDType_Solid = 1;
        LDType_Dash = 2;
        LDType_Solid_Dash = 3;
        LDType_Dash_Solid = 4;
        LDType_Solid_Solid = 5;
        LDType_Deceleration_Dash = 6;
        LDType_Deceleration_Solid = 7;
        LDType_Guide = 8;//导流线
        LDType_Dash_Dash = 9;//双虚线
        LDType_Direct = 10;//可变导向线
        LDType_Solid_Four = 11;
        LDType_Serrate = 12; //锯齿线
        LDType_Composite = 13; //复合线（预留接口，暂不使用）
        LDType_Parking_Space_Entrace = 14;//车位入口线
    }
"""


def get_lane_line_cls2_mapping(ldtype):
    id = 41 + ldtype
    assert 41 <= id <= 55
    return id


def get_tld_cls2_mapping(tld_color):
    id = 56 + tld_color
    assert 56 <= id <= 60
    return id


def get_spd_limit_cls2_mapping(spd_limit):
    id = 61 + spd_limit
    assert 61 <= id <= 73
    return id


def get_lane_id_cls2_mapping(lane_id):
    id = 74 + lane_id  # [74, 86]
    assert 74 <= id <= 86
    return id


def get_action_cls2_mapping(main_action_id):
    # 超过id 14的都按照0处理
    if main_action_id > 14:
        main_action_id = 0
    id = 87 + main_action_id  # [87, 101]
    assert 87 <= id <= 101
    return id


def get_lane_type_cls3_mapping(lane_type):
    return 10 + lane_type  # [10, 13]


def get_action_cls3_mapping(assistant_action_id):
    # 超过id 18的都按照0处理
    if assistant_action_id > 18:
        assistant_action_id = 0
    return 14 + assistant_action_id  # [14, 32]


def get_remain_distance_cls4_mapping(remain_distance):
    # 0: pad value < 0
    # 1 + 0: [0, 10) 1: [10, 20) ... 9: [90, 100)
    # 1 + 10: [100, 200) 11: [200, 300) ... 18: [900, 1000)
    # 1 + 19: [1000, 2000) 20: [2000, inf]
    if remain_distance < 0:
        return 0
    elif remain_distance < 100:
        cls_id = remain_distance // 10
    elif remain_distance < 1000:
        cls_id = remain_distance // 100 + 9
    elif remain_distance < 2000:
        cls_id = 19
    else:
        cls_id = 20
    return 1 + cls_id  # [1, 21]


def remain_distance_reverse_mapping(cls_id):
    if cls_id == 0:
        return -1
    cls_id -= 1
    if cls_id < 10:
        return cls_id * 10
    elif cls_id < 19:
        return (cls_id - 9) * 100
    elif cls_id == 19:
        return 1000
    else:
        return 2000

# 三级label映射


def get_map_cls_to_3cls(od_cls_id):
    if od_cls_id < 300:
        return "vehicle"
    elif od_cls_id < 500:
        return "bicycle"
    else:
        return "pedestrian"


@dataclass
class NetConfig:
    is_planner: bool = False
    # 大类：pad, ego, vehicle, bicycle, pedistrian, static_vehicle, static_bicycle, static_pedestrian, sobjs, road_sign, road_arrow, lane_lines, road_edge, stop_line,
    # tld, spd_limit, action_1, action_2, sub_path, lane_info, lane_highline_info, god_polygon, nomap_road_edge
    property_cls1_vocab_size: int = 24
    # cls2：pad, 44个roadsign(40个普通+4个ETC), 15个lane_line type，5个tld color(k, r, y, g, gray), 13个spd_limit [0-12], 13个lane_id,
    # 15个主action
    property_cls2_vocab_size: int = 112
    # cls3: pad, 9个lane_line color, 4个lane type(无效车道，普通车道，公交车道，潮汐车道叉号), 19个辅助action,
    property_cls3_vocab_size: int = 33
    tid_vocab_size: int = 300  # 第一个为pad
    timestamp_vocab_size: int = 40
    max_token_len: int = 15
    # cls4: pad, 21个remain_distance
    property_cls4_vocab_size: int = 22
    # cls6: pad, left = 1, right = 2
    property_cls6_vocab_size: int = 3
    # cls7: pad, np_lcc_activate = 1, np_lcc_deactivate = 2
    property_cls7_vocab_size: int = 3
    property_cls11_vocab_size: int = 5
    # cls5: lane direction专用cls, 直接在net中hard code
    # 用于给lane direction单独embeding, 作用于lane_info, lane_highline_info, road_arrow, tld
    tld_id: int = cls_mapping['tld']
    road_arrow_id: int = cls_mapping['road_arrow']
    lane_info_id: int = cls_mapping['lane_info']
    lane_highline_info_id: int = cls_mapping['lane_highline_info']

    # data config
    env_block_size: int = 200
    history_state_size: int = 200
    state_block_size: int = 200
    output_num: int = 512
    history_size: int = 3
    polyline_size: int = 50

    # net config
    n_layer: int = 12
    n_head: int = 12
    n_embd: int = 768
    dropout: float = 0.0
    bias: bool = False  # True: bias in Linears and LayerNorms, like GPT-2. False: a bit better and faster
    use_rmsnorm: bool = False
    ego_history_token_size: int = 1028

    # kv cache
    use_kv_cache: bool = False
    kv_cache_batch_size: int = 1
    kv_cache_dtype: torch.dtype = torch.float32
