# -*- coding: utf-8 -*-
"""Event manager.

Manage event in asynchronous pattern.
"""
from __future__ import annotations

import json
import logging
import time
from queue import Queue
from threading import Thread
from typing import Any
from typing import Callable
from typing import ClassVar
from typing import Dict
from typing import Type
from typing import Union

from kafka import KafkaProducer
from kafka.errors import KafkaTimeoutError
from kafka.errors import NoBrokersAvailable

from torchpilot.utils.constants import JobType
from torchpilot.utils.exceptions import TorchpilotNotInitializedException
from torchpilot.utils.settings import global_settings
from torchpilot.utils.settings import settings


logger = logging.getLogger(__name__)
kafka_logger = logging.getLogger("kafka")
kafka_logger.setLevel(logging.WARNING)


def need_init(func: Callable[..., Any]) -> Callable[..., Any]:
    """Check initialization."""

    def wrapper(cls: Type[EventManager], *args: Any, **kwargs: Any) -> Any:
        """Check initialization."""
        if not cls.initialized:
            raise TorchpilotNotInitializedException(
                f"{cls.__name__} is not initialized."
            )
        return func(cls, *args, **kwargs)

    return wrapper


class EventManager:
    """Event Manager."""

    _producer: ClassVar[KafkaProducer]
    _queue: ClassVar[Queue]
    _thread: ClassVar[Thread]
    initialized: ClassVar[bool] = False

    @classmethod
    def init(cls) -> None:
        """Init for event manager."""
        if cls.initialized:
            logger.warning("Event Manager has already been initialized. Skipping ...")
            return

        if not settings.event_metrics and not settings.event_tagging_cost:
            logger.warning("No events configured, skip initializing.")
            return

        logger.info("Initialing EventManager...")
        # Set Kafka logger level dynamically from settings
        kafka_log_level = getattr(
            logging, settings.kafka_log_level.upper(), logging.WARNING
        )
        kafka_logger.setLevel(kafka_log_level)

        retry_limit = 3
        retry_interval = 2
        while retry_limit > 0:
            try:
                cls._producer = KafkaProducer(
                    bootstrap_servers=settings.kafka_servers,
                    value_serializer=lambda v: json.dumps(v).encode("utf-8"),
                )
                cls.initialized = True
                logger.warning("Kafka producer initialized successfully.")
                break
            except NoBrokersAvailable:
                logger.warning(
                    "EventManager unable to connect to Kafka cluster, retrying... "
                    "Retries left: %d. ",
                    retry_limit,
                )
                retry_limit -= 1
                time.sleep(retry_interval)
            except Exception:  # pylint: disable=broad-except
                logger.exception("Failed to send event. Retries left: %d", retry_limit)
                retry_limit -= 1
                time.sleep(retry_interval)

        if retry_limit == 0:
            logger.error(
                "EventManager initialization failed after retries."
                "Disabling event-related configurations."
            )
            settings.event_metrics = False
            settings.event_tagging_cost = False
            settings.event_max_upload = 0
            settings.event_upload_interval = 0
            cls.initialized = False
            return

        cls._queue = Queue()
        cls._thread = Thread(target=cls.regular_upload, daemon=True)
        cls._thread.start()
        logger.info("Event Manager initialized successfully.")

    @classmethod
    def put(cls, item: Dict[str, Union[str, Any]]):
        """Put event into event queue."""
        if not cls.initialized:
            logger.debug("EventManager is not initialized, skip putting event.")
            return

        if global_settings.nts_job_name is None:
            logger.debug("NTS_JOB_NAME is None, skip putting event.")
            return

        if global_settings.nts_job_type != JobType.JOB.value:
            logger.debug("NTS_JOB_TYPE is NOT 'job', skip putting event.")
            return

        item["timestamp"] = int(time.time())
        cls._queue.put(item)

    @classmethod
    @need_init
    def upload(cls):
        """Upload events in event queue."""
        event_num = min(cls._queue.qsize(), settings.event_max_upload)

        if event_num == 0:
            return

        msg = {
            "source": "torchpilot",
            "job_name": global_settings.nts_job_name,
            "msg": [cls._queue.get() for _ in range(event_num)],
        }

        retry_limit = 3
        while retry_limit > 0:
            try:
                cls._producer.send("training", msg)
                logger.debug("Send event with `%s` successfully.", msg)
                break
            except KafkaTimeoutError:
                retry_limit -= 1

        if retry_limit == 0:
            logger.error("Failed to send event `%s`.", msg)

        if cls._queue.qsize() >= settings.event_max_upload:
            cls.upload()

    @classmethod
    def regular_upload(cls):
        """Upload event regularly for background trigger."""
        while cls.initialized:
            cls.upload()
            time.sleep(settings.event_upload_interval)

    @classmethod
    def teardown(cls):
        """Teardown for event manager."""
        if cls.initialized:
            while not cls._queue.empty():
                cls.upload()
            cls.initialized = False
            cls._thread.join()

            del cls._thread
            del cls._producer
            del cls._queue

            logger.info("Stopping the Event Manager.")
        else:
            logger.warning("Event manager is not initialized. Skip the teardown.")
