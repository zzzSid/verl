# -*- coding: utf-8 -*-
"""Torchpilot custom exceptions."""
import logging
import sys
import traceback
from types import TracebackType
from typing import Optional
from typing import Type

from torchpilot.utils.dist_manager import dist_abort


logger = logging.getLogger(__name__)


def exception_hook(
    ex_type: Type[BaseException],
    ex_value: BaseException,
    ex_trackback: Optional[TracebackType],
) -> None:
    """Global exception hook for logging."""
    log_list = traceback.format_tb(ex_trackback)
    log_list.append(f"{ex_type.__name__}: {ex_value}")
    logger.error("".join(log_list))
    if not ex_trackback:
        raise ex_value
    sys.__excepthook__(ex_type, ex_value, ex_trackback)
    dist_abort()


class TorchpilotBaseException(Exception):
    """Base exception for torchpilot."""


class TorchpilotDuplicateRunNameException(TorchpilotBaseException):
    """Exception for duplicate run name."""


class TorchpilotExistingRunDirNotFoundException(TorchpilotBaseException):
    """Exception for existing run name not found."""


class TorchpilotExpectedCfgFileNotFoundException(TorchpilotBaseException):
    """Exception for expected config file not found."""


class TorchpilotInconsistentCfgFileException(TorchpilotBaseException):
    """Exception for inconsistent config file."""


class TorchpilotInvalidCfgNameException(TorchpilotBaseException):
    """Exception for invalid cfg_name."""


class TorchpilotInvalidCfgPathException(TorchpilotBaseException):
    """Exception for invalid cfg_path."""


class TorchpilotInvalidExpNameException(TorchpilotBaseException):
    """Exception for invalid exp_name."""


class TorchpilotInvalidRunNameException(TorchpilotBaseException):
    """Exception for invalid run_name."""


class TorchpilotInvalidTaskNameException(TorchpilotBaseException):
    """Exception for invalid task_name."""


class TorchpilotNotInitializedException(TorchpilotBaseException):
    """Exception for file manager not initialized."""


class TorchpilotOutputDirIsNotLinkException(TorchpilotBaseException):
    """Exception for output dir is not link."""
