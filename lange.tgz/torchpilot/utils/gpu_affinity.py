# -*- coding: utf-8 -*-
"""The utility of GPU Affinity."""

import logging
import os

import pynvml


logger = logging.getLogger(__name__)


def set_affinity(gpu_id):
    """Set affinity of the process to the GPU."""
    pynvml.nvmlInit()
    nvml_handle = pynvml.nvmlDeviceGetHandleByIndex(gpu_id)
    affinity_string = ""
    for j in pynvml.nvmlDeviceGetCpuAffinity(nvml_handle, 2):
        affinity_string = f"{j:064b}" + affinity_string
    affinity_list = [int(x) for x in affinity_string]
    affinity_list.reverse()
    affinity_list = [i for i, e in enumerate(affinity_list) if e != 0]
    os.sched_setaffinity(0, affinity_list)
    pynvml.nvmlShutdown()
    return os.sched_getaffinity(0)
