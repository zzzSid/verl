# -*- coding: utf-8 -*-
"""The Stopwatch utility."""

import logging
import statistics
import time
from collections import defaultdict
from typing import Any
from typing import Dict
from typing import List
from typing import Optional

import torch
from prettytable import PrettyTable


logger = logging.getLogger(__name__)


class Stopwatch:
    """The matlab-style Stopwatch."""

    def __init__(self, start=False):
        """Initialize.

        Args:
          start (bool): whether start the clock immediately.
        """
        self.beg = None
        self.end = None
        self.duration = 0.0

        self.create_timestamp = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())

        if start:
            self.tic()

    def tic(self):
        """Start the Stopwatch."""
        self.beg = time.time()
        self.end = None

    def toc(self):
        """Stop the Stopwatch."""
        if self.beg is None:
            raise RuntimeError("Please run tic before toc.")
        self.end = time.time()
        return self.end - self.beg

    def toc2(self):
        """Record duration, and Restart the Stopwatch."""
        delta = self.toc()
        self.tic()
        return delta

    def acc(self):
        """Accumulates the duration."""
        delta = self.toc()
        self.duration += delta
        self.tic()
        return delta

    def reset(self):
        """Reset the whole Stopwatch."""
        self.tic()
        self.duration = 0.0


class StopwatchV2:
    """Stopwatchv2.

    Support cpu and cuda timing. Cpu timing use time.time(), cuda timing use
    torch.cuda.Event.

    example::

        >>> stopwatch = StopwatchV2()
        >>> stopwatch.tic("key1")
        >>> time.sleep(1)
        >>> stopwatch.record_time_cost("key1", "key2")
        >>> time.sleep(2)
        >>> stopwatch.record_time_cost("key2", None)
        >>> stopwatch.sync_for_cur_iter_and_prepare_for_next_iter()
        >>> print(stopwatch.time_cost)
    """

    def __init__(self, need_cpu: bool = True, need_cuda: bool = True):
        """Initialize."""
        self._time_mode_cost: Dict[str, Dict[str, List[float]]] = {}
        self._time_mode_beg_end: Dict[str, Dict[str, Any]] = {}
        self._time_cost_prefix = ""
        self._cur_key = None
        if not need_cpu and not need_cuda:
            raise ValueError("At least one of need_cpu and need_cuda should be True.")
        self._need_cpu = need_cpu
        self._need_cuda = need_cuda

    def tic(self, key):
        """Start the Stopwatch for `key`, both on cpu and cuda."""
        self._cur_key = self.get_complete_key(key)
        if self._need_cpu:
            self.tic_cpu(self._cur_key)
        if self._need_cuda:
            self.tic_cuda(self._cur_key)

    def record_time_cost(
        self,
        key: str,
        next_key: Optional[str],
    ):
        """
        Record time cost.

        Record cpu & cuda time cost of `key` according to `need_cpu` & `need_cuda`,
        Then, if `next_key` is not None, restart a new tic of `next_key`.
        """
        complete_key = self.get_complete_key(key)
        if complete_key not in self._time_mode_beg_end:
            raise RuntimeError(
                f"Expected to call .tic() before record_time_cost(key=`{key}`)."
            )
        if self._need_cpu:
            self.toc_cpu(complete_key)
        if self._need_cuda:
            self.toc_cuda(complete_key)

        if next_key is None:
            return
        self.tic(next_key)

    def tic_cpu(self, key: str):
        """Start the cpu timing."""
        if key not in self._time_mode_beg_end:
            self._time_mode_beg_end[key] = {}
        self._time_mode_beg_end[key].update({"cpu": {"beg": time.time(), "end": None}})

    def toc_cpu(self, key: str):
        """Stop the cpu timing."""
        if key not in self._time_mode_beg_end:
            raise ValueError(f"Key {key} not found in all_time_beg_end.")
        if "cpu" not in self._time_mode_beg_end[key]:
            raise ValueError(f"Key {key} not found in cpu timing.")
        self._time_mode_beg_end[key]["cpu"]["end"] = time.time()
        delta_time = (
            self._time_mode_beg_end[key]["cpu"]["end"]
            - self._time_mode_beg_end[key]["cpu"]["beg"]
        )
        self._add_time_mode_cost(key, "cpu", delta_time)

    def tic_cuda(self, key: str):
        """Start the cuda timing."""
        if key not in self._time_mode_beg_end:
            self._time_mode_beg_end[key] = {}
        self._time_mode_beg_end[key].update(
            {
                "cuda": {
                    "beg": torch.cuda.Event(enable_timing=True),
                    "end": torch.cuda.Event(enable_timing=True),
                }
            }
        )
        self._time_mode_beg_end[key]["cuda"]["beg"].record()

    def toc_cuda(self, key: str):
        """Stop the cuda timing."""
        if key not in self._time_mode_beg_end:
            raise ValueError(f"Key {key} not found in all_time_beg_end.")
        if "cuda" not in self._time_mode_beg_end[key]:
            raise ValueError(f"Key {key} not found in cuda timing.")
        self._time_mode_beg_end[key]["cuda"]["end"].record()

    def sync_all_cuda_toc(self):
        """Synchronoize all cuda timing."""
        # event.synchronize() for all cuda event
        for time_cost_key, mode_and_beg_end_dict in self._time_mode_beg_end.items():
            if "cuda" not in mode_and_beg_end_dict:
                continue
            beg = mode_and_beg_end_dict["cuda"]["beg"]
            end = mode_and_beg_end_dict["cuda"]["end"]
            end.synchronize()
            try:
                delta_cuda = beg.elapsed_time(end) / 1e3
            except RuntimeError as ex:
                logger.exception("Failed to get cuda time cost for %s", time_cost_key)
                raise ex
            self._add_time_mode_cost(time_cost_key, "cuda", delta_cuda)

    def sync_for_cur_iter_and_prepare_for_next_iter(self):
        """Prepare for next round."""
        self.sync_all_cuda_toc()
        self.reset_time_cost_prefix()
        self._time_mode_beg_end.clear()

    def _add_time_mode_cost(self, key: str, mode: str, time_cost: float):
        """Add time cost to `self._time_mode_cost` accord to `key` and `mode`."""
        if key not in self._time_mode_cost:
            self._time_mode_cost[key] = {}
        if mode not in self._time_mode_cost[key]:
            self._time_mode_cost[key][mode] = []
        self._time_mode_cost[key][mode].append(time_cost)

    def set_time_cost_prefix(self, prefix: str):
        """Set time cost prefix, default is empty string."""
        self._time_cost_prefix = prefix

    def reset_time_cost_prefix(self):
        """Reset time cost prefix."""
        self._time_cost_prefix = ""

    def reset(self):
        """Reset all time cost."""
        self._time_mode_cost.clear()
        self._time_mode_beg_end.clear()

    def get_complete_key(self, key):
        """Get complete key, a combination of `self._time_cost_prefix` and `key`."""
        if self._time_cost_prefix != "":
            return f"{self._time_cost_prefix}/{key}"
        return key

    @property
    def time_cost(self) -> Dict[str, List[float]]:
        """Get all time cost, both cpu and cuda."""
        show_time_cost = {}
        # flatten self._time_mode_cost's [key][mode] into one layer [key-mode]
        for key, mode_time_dict in self._time_mode_cost.items():
            for mode, time_list in mode_time_dict.items():
                new_key = key + "-" + mode
                show_time_cost[new_key] = time_list
        return show_time_cost

    @property
    def time_cost_cpu(self) -> Dict[str, List[float]]:
        """Get cpu time cost."""
        show_time_cost = {}
        for key, mode_time_dict in self._time_mode_cost.items():
            if "cpu" in mode_time_dict:
                show_time_cost[key] = mode_time_dict["cpu"]
        return show_time_cost

    @property
    def time_cost_cuda(self) -> Dict[str, List[float]]:
        """Get cuda time cost."""
        show_time_cost = {}
        for key, mode_time_dict in self._time_mode_cost.items():
            if "cuda" in mode_time_dict:
                show_time_cost[key] = mode_time_dict["cuda"]
        return show_time_cost

    def time_cost_mean(self, mode):
        """Get time cost mean according to `mode`."""
        if mode == "cpu":
            time_cost_dict = self.time_cost_cpu
        elif mode == "cuda":
            time_cost_dict = self.time_cost_cuda
        elif mode == "all":
            time_cost_dict = self.time_cost
        else:
            raise ValueError(f"Unsupported mode: {mode}")

        # calculate mean of each item's time cost
        time_cost_mean = {}
        for item_name, item_value in time_cost_dict.items():
            time_cost_mean[item_name] = statistics.mean(item_value)
        return time_cost_mean

    def has_start_timing(self, key) -> bool:
        """Whether has start timing."""
        return self.get_complete_key(key) in self._time_mode_beg_end


class ProfileStopwatch(StopwatchV2):
    """Stopwatch for profile.

    docs: https://nio.feishu.cn/wiki/RErcwSlUrid76Dklkznc13bIn5c

    Examples::

        >>> # Init ProfileStopwatch
        >>> profile_stopwatch = ProfileStopwatch(
                stopwatch_name="ProfileStopwatch",
                log_interval=1,
            )
        >>> profile_stopwatch.tic()
        >>> # Code1 to be profile
        >>> time.sleep(1)
        >>> # Record time cost
        >>> profile_stopwatch.record_time_cost("Code1")
        >>> # Code2 to be profile
        >>> time.sleep(2)
        >>> # Record time cost
        >>> profile_stopwatch.record_time_cost("Code2")
        >>> # Log time cost
        >>> profile_stopwatch.log_time_cost()
        >>> # Outputs:
        +------------------+---------------+-----------+----------------+------------+
        | ProfileStopwatch | CPU Time Cost | CPU Ratio | CUDA Time Cost | CUDA Ratio |
        +------------------+---------------+-----------+----------------+------------+
        |            Total |      3.003805 | 100.0000% |       3.003897 |  100.0000% |
        |            Code2 |      2.002216 |  66.6560% |       2.002392 |   66.6598% |
        |            Code1 |      1.001589 |  33.3440% |       1.001504 |   33.3402% |
        +------------------+---------------+-----------+----------------+------------+
    """

    def __init__(
        self,
        stopwatch_name: str,
        log_interval: int = 20,
        reset_after_log_time_cost: bool = True,
        enable_stopwatch: bool = True,
        **kwargs,
    ):
        """Initialize.

        Args:
            stopwatch_name (str): Stopwatch name.
            log_interval (int): Log time cost table every log_interval times calling
                self.log_time_cost method. Default=20.
            reset_after_log_time_cost (bool): Whether clear recorded time previously and
                start new record. Default=True.
            enable_stopwatch (bool): whether use stopwatch. Default=True.
        """
        super().__init__(**kwargs)
        self._time_cost: Dict[str, List[float]] = defaultdict(list)
        self._stopwatch_name = stopwatch_name
        self._count = 0
        self._log_interval = log_interval
        self._reset_after_log_time_cost = reset_after_log_time_cost
        self._cur_timing_key = None
        self._cur_timing: Dict[str, Any] = {}
        self._enable_stopwatch = enable_stopwatch
        if not self._enable_stopwatch:
            logger.warning("Profilestopwatch has been disabled")
        else:
            self._init_table()

    def _init_table(self):
        if not self._enable_stopwatch:
            return
        self._table = PrettyTable()
        filed_names = [self._stopwatch_name]
        if self._need_cpu:
            filed_names.append("CPU Time Cost")
            filed_names.append("CPU Ratio")
        if self._need_cuda:
            filed_names.append("CUDA Time Cost")
            filed_names.append("CUDA Ratio")
        self._table.field_names = filed_names
        for name in filed_names:
            self._table.align[name] = "r"

    def reset(self):
        """Reset the whole Stopwatch."""
        if not self._enable_stopwatch:
            return
        super().reset()
        self._table.clear_rows()
        self._count = 0

    def tic(self):  # type: ignore[override]  # pylint: disable=arguments-differ.
        """Tic."""
        if not self._enable_stopwatch:
            return
        self._time_mode_beg_end.pop(self._cur_timing_key, None)
        self._cur_timing_key = len(self._time_mode_beg_end)
        super().tic(self._cur_timing_key)

    # pylint: disable=arguments-differ.
    def record_time_cost(self, key: str) -> None:  # type: ignore[override]
        """Record time cost and start a new tic."""
        if not self._enable_stopwatch:
            return
        if (
            self._cur_timing_key is None
            or self._cur_timing_key not in self._time_mode_beg_end
        ):
            raise RuntimeError("Please run tic before record_time_cost.")
        self._time_mode_beg_end[key] = self._time_mode_beg_end.pop(self._cur_timing_key)
        super().record_time_cost(key, None)
        self.tic()

    def set_time_cost_prefix(self, prefix: str):
        """Set time cost prefix."""
        if not self._enable_stopwatch:
            return
        del prefix
        raise NotImplementedError("Not supported for ProfileStopwatch.")

    def log_time_cost(self):
        """Log time cost."""
        self._count += 1
        if self._count % self._log_interval != 0 or not self._enable_stopwatch:
            return

        # sync to assure all cuda timing is done, except last tic timing
        self._cur_timing = {
            self._cur_timing_key: self._time_mode_beg_end.pop(
                self._cur_timing_key, None
            )
        }
        self.sync_for_cur_iter_and_prepare_for_next_iter()

        if self._need_cpu:
            time_cost_mean_cpu = self.time_cost_mean("cpu")
            total_time_cost_cpu = sum(time_cost_mean_cpu.values())
        if self._need_cuda:
            time_cost_mean_cuda = self.time_cost_mean("cuda")
            total_time_cost_cuda = sum(time_cost_mean_cuda.values())

        # first row
        first_raw = ["Total"]
        if self._need_cpu:
            first_raw.extend(
                [
                    f"{total_time_cost_cpu:.6f}",
                    f"{(total_time_cost_cpu/total_time_cost_cpu) * 100:.4f}%",
                ]
            )
        if self._need_cuda:
            first_raw.extend(
                [
                    f"{total_time_cost_cuda:.6f}",
                    f"{(total_time_cost_cuda/total_time_cost_cuda) * 100:.4f}%",
                ]
            )
        self._table.add_row(first_raw)

        # detail rows
        key_list = (
            list(time_cost_mean_cpu.keys())
            if self._need_cpu
            else list(time_cost_mean_cuda.keys())
        )
        for key in key_list:
            detail_row = [key]
            if self._need_cpu:
                mean_cpu = time_cost_mean_cpu[key]
                detail_row.extend(
                    [
                        f"{mean_cpu:.6f}",
                        f"{(mean_cpu/total_time_cost_cpu) * 100:.4f}%",
                    ]
                )
            if self._need_cuda:
                mean_cuda = time_cost_mean_cuda[key]
                detail_row.extend(
                    [
                        f"{mean_cuda:.6f}",
                        f"{(mean_cuda/total_time_cost_cuda) * 100:.4f}%",
                    ]
                )
            self._table.add_row(detail_row)

        if self._need_cuda:
            sort_key = "CUDA Time Cost"
        else:
            sort_key = "CPU Time Cost"
        logger.warning(
            "\n%s",
            self._table.get_string(sortby=sort_key, reversesort=True),
        )

        if self._reset_after_log_time_cost:
            self.reset()

        # no end timing for last timing, so add it back
        self._time_mode_beg_end.update(self._cur_timing)
        self._cur_timing.clear()

    def __getstate__(self):
        """Pop unpicklable attributes to make itself picklable."""
        if not self._enable_stopwatch:
            return None
        self.__dict__.pop("_table", None)
        return self.__dict__

    def __setstate__(self, state):
        """Recover all attributes."""
        if not self._enable_stopwatch:
            return
        self.__dict__.update(state)
        # reinit unpickable
        self._init_table()


stopwatch = StopwatchV2()
