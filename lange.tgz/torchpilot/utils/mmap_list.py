# -*- coding: utf-8 -*-
"""MmapSerializedList based on mmap."""

import logging
import mmap
import multiprocessing
import os
import pickle
import time
import uuid

import numpy as np

from torchpilot.utils.dist_manager import get_local_rank
from torchpilot.utils.dist_manager import get_world_size
from torchpilot.utils.dist_manager import mpi_broadcast_obj


logger = logging.getLogger(__name__)


def safe_delete(file_path, lock):
    """Delete file safely."""
    with lock:
        if os.path.exists(file_path):
            os.remove(file_path)


class MmapSerializedList:
    """MmapSerializedList.

    Serialize list into mmap file and load item from mmap file when needed. After create
    MmapSerializedList instance, you can get one item by index as usual list.

    mmap docs:
        https://docs.python.org/zh-cn/3/library/mmap.html

    MmapSerializedList Usage:
        1. Create MmapSerializedList instance.
            mmap_list_instance = MmapSerializedList(list_instance, "xxx.pkl")
        2. Get length of instance.
            len_of_mmap_list = len(mmap_list_instance)
        3. Get one item by index.
            first_item = mmap_list_instance[0]
        4. Not support other operation to MmapSerializedList instance.
    Args:
        list_to_mmap (list): List to mmap.
        mmap_filename (str): Mmap file name, need has format like "xxx.pkl".
        del_input_list (bool): Whether to delete input list to save memory. Defaults to
            True.
        mmap_root_dir (str): Mmap root dir. Defaults to "/tmp/torchpilot_mmap".
    """

    def __init__(
        self,
        list_to_mmap: list,
        mmap_filename,
        del_input_list=True,
        mmap_stride: int = 8,
        mmap_root_dir="/tmp/torchpilot_mmap",  # noqa: S108
    ):
        """Init."""
        self._no_mmap_flag = False
        self.mmap_root_dir = mmap_root_dir
        self.lock = multiprocessing.Lock()
        # stride for pack
        self.stride = mmap_stride
        # after pack len will change, so record base len
        self.base_len = len(list_to_mmap)

        if len(list_to_mmap) == 0:
            # when no content in the list, no need to create mmap file
            self._no_mmap_flag = True
            return

        local_rank = get_local_rank()
        self.set_mmap_path_and_prepare_empty_dir(mmap_filename)

        if local_rank == 0:
            # rank 0 dump the list into file
            logger.warning(
                "rank %d Creating mmap file...%s", get_local_rank(), self.mmap_file_path
            )
            (
                concated_bytes,
                self.start_bytes,
            ) = self.convert_into_bytes_and_record_index(list_to_mmap)
            self.write_into_file(concated_bytes)
            logger.warning(
                "Serialized a list of %d elements, takes %.2f MiB at %s",
                len(list_to_mmap),
                len(concated_bytes) / 1024**2,
                self.mmap_file_path,
            )
            del concated_bytes
        else:
            # wait rank0 finish dumping the list into file, then set start_bytes
            self.wait_until_has_file()
            self.set_start_bytes()
        # all ranks set mmap
        self.set_mmap()

        if del_input_list:
            list_to_mmap.clear()

        logger.warning("ready to use mmap file %s", self.mmap_file_path)

    def get_stride(self):
        """Get stride."""
        return self.stride

    def set_mmap(self):
        """Set mmap from file."""
        if not os.path.exists(self.mmap_file_path):
            raise RuntimeError(f"Mmap file {self.mmap_file_path} not exists")
        swap_file = open(  # pylint: disable=consider-using-with
            self.mmap_file_path, "r+b"
        )
        self.mmap = mmap.mmap(swap_file.fileno(), 0)
        swap_file.close()
        del swap_file

    def set_start_bytes(self):
        """Set start bytes from file."""
        if not os.path.exists(self.start_bytes_path):
            raise RuntimeError(f"Start bytes file {self.start_bytes_path} not exists")
        with open(self.start_bytes_path, "rb") as start_bytes_file:
            self.start_bytes = pickle.load(start_bytes_file)

    def convert_into_bytes_and_record_index(self, list_to_convert):
        """Convert list into bytes and record start bytes."""
        list_of_bytes = [
            pickle.dumps(
                list_to_convert[i : i + self.stride], protocol=pickle.HIGHEST_PROTOCOL
            )
            for i in range(0, len(list_to_convert), self.stride)
        ]

        list_of_each_len = np.asarray([len(x) for x in list_of_bytes], dtype=np.int64)
        list_of_each_start_bytes = np.cumsum(list_of_each_len)
        concated_bytes = b"".join(list_of_bytes)
        return concated_bytes, list_of_each_start_bytes

    def write_into_file(self, data_to_wirte):
        """Write data into file."""
        with open(self.mmap_file_path, "wb") as mmap_file:
            mmap_file.write(data_to_wirte)
        with open(self.start_bytes_path, "wb") as start_bytes_file:
            pickle.dump(self.start_bytes, start_bytes_file)
        with open(self.done_flag_path, "wb") as _:
            pass

    def wait_until_has_file(self):
        """Wait until file exists."""
        while not os.path.exists(self.done_flag_path):
            time.sleep(0.1)

    def set_mmap_path_and_prepare_empty_dir(self, mmap_filename):
        """Set mmap file path and prepare empty dir."""
        # uuid for avoiding two different instances dumping into the same file
        unique_id = str(uuid.uuid4())
        if get_world_size() > 1:
            # NOTE: if call mpi_broadcast_obj in online ci test, pytest won't exit
            unique_id = mpi_broadcast_obj(unique_id)
        mmap_filename_no_format = mmap_filename.replace(".pkl", "")
        unique_dir_name = "_".join([mmap_filename_no_format, unique_id])
        root_dir = os.path.join(self.mmap_root_dir, unique_dir_name)
        self.mmap_file_path = os.path.join(root_dir, mmap_filename)
        self.start_bytes_path = os.path.join(
            root_dir, f"{mmap_filename_no_format}_start_bytes.pkl"
        )
        self.done_flag_path = f"{self.start_bytes_path}.done"
        if get_local_rank() == 0:
            # rank0 prepare dir and remove old files if exists
            os.makedirs(root_dir, exist_ok=True)
            if os.path.exists(self.mmap_file_path):
                os.remove(self.mmap_file_path)
            if os.path.exists(self.start_bytes_path):
                os.remove(self.start_bytes_path)
            if os.path.exists(self.done_flag_path):
                os.remove(self.done_flag_path)

    def __len__(self):
        """Len."""
        # return base len not pack len
        return self.base_len

    def __getitem__(self, idx):
        """Getitem."""
        if self._no_mmap_flag:
            raise RuntimeError("MmapSerializedList is empty.")
        pos = idx // self.stride
        inner_pos = int(idx % self.stride)
        start_addr = 0 if pos == 0 else self.start_bytes[pos - 1].item()
        end_addr = self.start_bytes[pos].item()

        data_bytes = memoryview(self.mmap)[start_addr:end_addr]
        pickle_obj = pickle.loads(data_bytes)
        return pickle_obj[inner_pos]

    def __del__(self):
        """Del."""
        if get_local_rank() != 0:
            return
        if hasattr(self, "mmap") and self.mmap is not None:
            self.mmap.close()
        if hasattr(self, "mmap_file_path") and os.path.exists(self.mmap_file_path):
            safe_delete(self.mmap_file_path, self.lock)
        if hasattr(self, "start_bytes_path") and os.path.exists(self.start_bytes_path):
            safe_delete(self.start_bytes_path, self.lock)
        if hasattr(self, "done_flag_path") and os.path.exists(self.done_flag_path):
            safe_delete(self.done_flag_path, self.lock)
        if hasattr(self, "mmap_file_path"):
            dir_name = os.path.dirname(self.mmap_file_path)
            if os.path.isdir(dir_name) and len(os.listdir(dir_name)) == 0:
                os.rmdir(dir_name)

    def __getstate__(self):
        """Getstate for serialization."""
        if self._no_mmap_flag:
            return self.__dict__
        pickeable_state = {}
        for attr_name, attr_value in self.__dict__.items():
            # self.mmap is unpickable, and self.start_bytes is already dump in file, so
            # no need to pickle
            if attr_name in ["mmap", "start_bytes"]:
                continue
            pickeable_state[attr_name] = attr_value
        return pickeable_state

    def __setstate__(self, state):
        """Setstate for deserialization."""
        self.__dict__.update(state)
        if self._no_mmap_flag:
            return
        self.set_mmap()
        self.set_start_bytes()
