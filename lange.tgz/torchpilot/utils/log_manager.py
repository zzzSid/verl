# -*- coding: utf-8 -*-
"""Log Manager.

Config loggers with necessary handlers and formatters with support of distributed
systems and experiment management.
"""
import inspect
import logging
import os
import sys
import threading
from typing import Any
from typing import List
from typing import Optional
from typing import TextIO

import torch.distributed as dist
from coloredlogs import BasicFormatter
from coloredlogs import ColoredFormatter
from prettytable import PrettyTable

from torchpilot.utils.dist_manager import get_global_rank
from torchpilot.utils.file_manager import FileManager
from torchpilot.utils.settings import settings


LOGGING_FORMAT = "%(asctime)s %(levelname)s %(name)s: %(message)s"

_lock = threading.RLock()


class CustomFormatter(logging.Formatter):
    """formatter."""

    def __init__(self, prefix, *args, **kwargs):
        """init."""
        super().__init__(*args, **kwargs)
        self.prefix = prefix

    def format(self, record):
        """Format func."""
        record.msg = f"rank={self.prefix} - {record.msg}"
        return super().format(record)


class CustomFileHandler(logging.FileHandler):
    """handler."""

    def __init__(
        self, filename, mode="a", encoding=None, delay=False, log_lvl=logging.ERROR
    ):
        """init."""
        super().__init__(filename, mode, encoding, delay)
        self.log_lvl = log_lvl

    def emit(self, record):
        """Emit func."""
        if record.levelno == self.log_lvl:
            super().emit(record)
        else:
            return


def log_init(
    name: str, *, stream: TextIO = sys.stdout, rank: Optional[int] = None
) -> None:
    """Init logger with stream handler for specific name."""
    init_logger = logging.getLogger(name)
    init_logger.setLevel(settings.logging_level)
    init_logger.propagate = False
    # clear handlers to avoid add repeatly.
    init_logger.handlers.clear()

    if (not dist.is_available() or not dist.is_initialized()) and rank is None:
        init_logger.info("Dist is not avaliable with no specific rank.")
        return
    rank = rank or get_global_rank()
    if rank != 0:
        init_logger.info(
            "Existing logger `%s` \
                    initialization for rank `%s` ...",
            name,
            rank,
        )
        return
    stream_handler = logging.StreamHandler(stream)
    stream_handler.setFormatter(ColoredFormatter(LOGGING_FORMAT))
    init_logger.addHandler(stream_handler)

    init_logger.info("Logger `%s` initialized with StreamHandler successfully.", name)


def log_file_init(
    name: str, rank: int = 0, max_times_try: int = 10, log_dir: str = None
) -> None:
    """Init logger with file handler for specific name."""
    with _lock:
        stack = inspect.stack()
        caller_info = stack[1]
        caller_module = inspect.getmodule(caller_info[0]).__name__
        if caller_module == name:
            rank = rank or get_global_rank()

        init_logger = logging.getLogger(name)

        file_handler_exists = any(
            isinstance(h, logging.FileHandler) for h in init_logger.handlers
        )
        if file_handler_exists:
            return
        log_dir = log_dir or FileManager.get_log_dir()
        log_file_name = f"{rank}.log"
        log_file_path = os.path.join(log_dir, log_file_name)

        init_logger.info("Initializing logger '%s' with FileHandler ...", name)
        file_handler = logging.FileHandler(log_file_path)
        file_handler.setFormatter(BasicFormatter(LOGGING_FORMAT))
        init_logger.addHandler(file_handler)

        for _ in range(max_times_try):
            try:
                warning_handler = CustomFileHandler(
                    os.path.join(log_dir, "warning.log"), log_lvl=logging.WARNING
                )
                warning_handler.setFormatter(CustomFormatter(str(rank), LOGGING_FORMAT))
                init_logger.addHandler(warning_handler)
                break
            except FileExistsError:
                if _ < max_times_try - 1:
                    init_logger.warning("File exists error encountered, retrying")
                else:
                    init_logger.error("init log error")

        for _ in range(max_times_try):
            try:
                error_handler = logging.FileHandler(os.path.join(log_dir, "error.log"))
                error_handler.setFormatter(CustomFormatter(str(rank), LOGGING_FORMAT))
                error_handler.setLevel(logging.ERROR)
                init_logger.addHandler(error_handler)
                break
            except FileExistsError:
                if _ < max_times_try - 1:
                    init_logger.warning("File exists error encountered, retrying")
                else:
                    init_logger.error("init log error")

        init_logger.info(
            "Logger '%s' rank'%s' initialized with FileHandler at `%s` successfully.",
            name,
            rank,
            log_file_path,
        )


def log_as_table(
    data_list: List[Any],
    num_col: int = 5,
    local_logger: Optional[logging.Logger] = None,
) -> None:
    """Log a data list with specific column number."""
    data_lists = [data_list[i : i + num_col] for i in range(0, len(data_list), num_col)]
    if len(data_lists) > 0:
        data_lists[-1].extend([""] * (num_col - len(data_lists[-1])))

    table = PrettyTable()
    table.add_rows(data_lists)

    local_logger = local_logger or logging.getLogger(__name__)
    local_logger.info("\n%s", table.get_string(header=False))
