# -*- coding: utf-8 -*-
"""Reader utility for TorchPilot."""
import inspect
import logging
from typing import List
from urllib.parse import urlparse

from torchpilot.logging.message_type import ErrorEnum
from torchpilot.utils.settings import settings


# pylint: disable=broad-except

_IS_READ_CACHE_OP_AVAILABLE = True


try:
    from read_cache_op_py import read_cache_op_py
except ImportError:
    _IS_READ_CACHE_OP_AVAILABLE = False


logger = logging.getLogger(__name__)


def is_read_cache_op_available() -> bool:
    """Indicate whether read_cache_op is available."""
    return _IS_READ_CACHE_OP_AVAILABLE


def read_bytes(data_path_list: List[str]) -> List[bytes]:
    """Read bytes with data path list."""
    if is_read_cache_op_available():
        try:
            data_bytes_list = read_cache_op_py(data_path_list)
            # # The following snippet is for dumping data. Uncomment to use it.
            # import os
            # for idx, data_path in enumerate(data_path_list):
            #     real_data_path, _ = data_path.split()
            #     real_data_path = urlparse(real_data_path).path
            #     dump_data_path = os.path.abspath("dump") + real_data_path
            #     logger.warning("Dump from `%s` to `%s`",
            #                       real_data_path, dump_data_path)
            #     dump_data_dir = os.path.dirname(dump_data_path)
            #     os.makedirs(dump_data_dir, exist_ok=True)
            #     with open(dump_data_path, "wb") as fout:
            #         fout.write(data_bytes_list[idx])
            return data_bytes_list
        except Exception as err:
            stack = inspect.stack()
            caller_frame = stack[1]
            caller_instance = caller_frame.frame.f_locals.get("self", None)
            if getattr(caller_instance, "log_callback", None):
                caller_instance.log_callback(
                    "read-cache-op", err.args[0], ErrorEnum.READ_CACHE_OP_ERROR
                )
            return []

    # Read from local is needed on orin, so we hack with `data_path_prefix` here.
    res = []
    for data_path in data_path_list:
        real_data_path, _ = data_path.split()
        # When `data_path` is a s3 url, we only get the `path` part.
        real_data_path = urlparse(real_data_path).path
        if len(settings.data_path_prefix) > 0:
            real_data_path = settings.data_path_prefix + real_data_path
        with open(real_data_path, "rb") as fin:
            res.append(fin.read())
    return res
