# -*- coding: utf-8 -*-
"""Torchpilot Registries."""
from torchpilot.utils.cls_register import Registry


# NOTE: Ordered by logic rather than alphabetically here.

# Runner
INFERRER = Registry("torchpilot.inferrer")
TRAINER = Registry("torchpilot.trainer")

# Data
DATASET = Registry("torchpilot.dataset")
DATALOADER = Registry("torchpilot.dataloader")
TRANSFORM = Registry("torchpilot.transform")
SAMPLER = Registry("torchpilot.sampler")

# Model
TASK_FLOW = Registry("torchpilot.task_flow")
TASK_MODEL = Registry("torchpilot.task_model")
BASE_MODEL = Registry("torchpilot.base_model")
MODULE = Registry("torchpilot.module")
LAYER = Registry("torchpilot.layer")
HEAD = Registry("torchpilot.head")
LOSSES = Registry("torchpilot.losses")
POSTPROCESS = Registry("torchpilot.postprocess")

# Optimizer
LR_SCHEDULER = Registry("torchpilot.lr_scheduler")
OPTIMIZER = Registry("torchpilot.optimizer")

# Evaluator
EVALUATOR = Registry("torchpilot.evaluator")
