# -*- coding: utf-8 -*-
"""experiment manage."""

import json
import logging
import os
import time
from typing import Dict
from typing import List
from typing import Optional

import requests


EXPERIMENT_MANAGE = (
    "http://experiment-manage-http.aip-excution.svc.idc-prod.amp.nioint.com"
)
DEFAULT_SCHEME_ID = 512

logger = logging.getLogger(__name__)


def experiment_manage_submit_task(
    scheme_id: int,
    nurss_token: Dict,
    resource: Dict,
    task_name: str,
    commit: Optional[str] = None,
    injections: Optional[Dict] = None,
    label: Optional[List] = None,
) -> int:
    """Submit task."""
    if label is None:
        label = []
    user = os.environ.get("USER")
    token = nurss_token["token"]

    url = EXPERIMENT_MANAGE + "/api/v1/trigger/general"
    headers = {
        "x-aip-username": user,
        "training-token": token,
        "Content-Type": "application/json",
    }

    if injections is None:
        injections = {}

    if commit is not None:
        resource["git_commit_id"] = commit

    resource = {
        "scheme_id": scheme_id,
        "injections": injections,
        "name": task_name,
        "resource": resource,
        "label": label,
    }

    logger.info("Current nurss user: %s", nurss_token["user"])
    logger.info("Current experiment manage task: %s", resource)
    data = json.dumps(resource)
    for i in range(3):
        try:
            res = requests.post(
                url=url,
                data=data,
                headers=headers,
                timeout=10,
            ).json()

            logger.info("submit task return: %s", res)

            if res["message"] != "SUCCEED":
                raise Exception(res)  # pylint: disable=broad-except
            break

        except Exception as ex:  # pylint: disable=broad-except
            # raise ex
            ex_message = ex.args[0] if len(ex.args) > 0 else ""
            logger.error("Retrying %s", i)
            logger.error("submit task error: %s", ex_message)

            time.sleep(5)
            continue

    else:
        raise Exception("submit task error.")

    return res["data"]
