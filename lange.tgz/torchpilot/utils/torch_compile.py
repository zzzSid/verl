# -*- coding: utf-8 -*-
"""The utility of torch compile."""

import functools
import inspect
import logging

import torch
from packaging import version

from torchpilot.utils.settings import settings


logger = logging.getLogger(__name__)


@functools.lru_cache(maxsize=None)
def compile_wrapper(func, **kwargs):
    """Implement wrapper for torch.compile."""
    # check PyTorch version
    torch_version = torch.__version__
    if version.parse(torch_version) < version.parse("2.0.0"):
        logger.warning(
            "Skipping torch.compile because PyTorch >= 2.0.0 is required. "
            "Current version: %s.",
            torch_version,
        )
        return func

    # check setting
    if not settings.enable_compile:
        logger.warning(
            "Skipping torch.compile because TORCHPILOT_ENABLE_COMPILE is not set."
        )
        return func

    # compile function
    compiled_func = torch.compile(func, **kwargs)
    try:
        frame = inspect.currentframe()
        caller_frame = frame.f_back
        filename = caller_frame.f_code.co_filename
        line_number = caller_frame.f_lineno

        logger.warning(
            "torch.compile called from %s:%d. The first iterations may be slow.",
            filename,
            line_number,
        )
    except Exception:  # pylint: disable=broad-except
        logger.warning(
            "torch.compile called. but unable to determine the calling location."
        )

    return compiled_func
