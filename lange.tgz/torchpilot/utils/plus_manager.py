# -*- coding: utf-8 -*-
"""Plus Manager."""
import logging
import sys
from importlib import import_module

from torchpilot.utils.registries import BASE_MODEL
from torchpilot.utils.registries import DATALOADER
from torchpilot.utils.registries import DATASET
from torchpilot.utils.registries import EVALUATOR
from torchpilot.utils.registries import HEAD
from torchpilot.utils.registries import INFERRER
from torchpilot.utils.registries import LAYER
from torchpilot.utils.registries import LOSSES
from torchpilot.utils.registries import LR_SCHEDULER
from torchpilot.utils.registries import MODULE
from torchpilot.utils.registries import OPTIMIZER
from torchpilot.utils.registries import POSTPROCESS
from torchpilot.utils.registries import SAMPLER
from torchpilot.utils.registries import TASK_FLOW
from torchpilot.utils.registries import TASK_MODEL
from torchpilot.utils.registries import TRAINER
from torchpilot.utils.registries import TRANSFORM


if sys.version_info < (3, 10):
    from importlib_metadata import entry_points
else:
    from importlib.metadata import entry_points


logger = logging.getLogger(__name__)


REGISTRY_MAPPING = {
    DATALOADER.name: DATALOADER,
    DATASET.name: DATASET,
    SAMPLER.name: SAMPLER,
    TRANSFORM.name: TRANSFORM,
    EVALUATOR.name: EVALUATOR,
    BASE_MODEL.name: BASE_MODEL,
    HEAD.name: HEAD,
    LAYER.name: LAYER,
    LOSSES.name: LOSSES,
    MODULE.name: MODULE,
    POSTPROCESS.name: POSTPROCESS,
    TASK_FLOW.name: TASK_FLOW,
    TASK_MODEL.name: TASK_MODEL,
    LR_SCHEDULER.name: LR_SCHEDULER,
    OPTIMIZER.name: OPTIMIZER,
    INFERRER.name: INFERRER,
    TRAINER.name: TRAINER,
}


def load_plus() -> None:
    """Load plus."""
    for registry_key, registry in REGISTRY_MAPPING.items():
        for entry_point in entry_points(group=registry_key):
            logger.debug(
                "Register `%s` with name `%s` to `%s` Registry.",
                entry_point.value,
                entry_point.name,
                registry_key,
            )
            module = import_module(entry_point.value)
            registry.register_module(module=getattr(module, entry_point.name))
