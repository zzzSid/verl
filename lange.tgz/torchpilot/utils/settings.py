# -*- coding: utf-8 -*-
"""Settings for torchpilot.

Manage environment variable based settings with default values.
"""
import logging
from logging import getLevelName
from typing import List
from typing import Optional

from pydantic import BaseSettings

from torchpilot.utils.constants import Backend
from torchpilot.utils.constants import LaunchMode


# pylint: disable=too-few-public-methods, line-too-long


class Settings(BaseSettings):
    """Settings of torchpilot."""

    backend: Optional[Backend] = None
    data_path_prefix: str = ""
    event_max_upload: int = 100
    event_metrics: bool = False
    event_tagging_cost: bool = False
    event_upload_interval: int = 10
    kafka_servers: str = "train-kafka-dev.middleware.middleware-prod.k.nioint.com:35127"
    kafka_log_level: str = "WARNING"
    launch_mode: LaunchMode = LaunchMode.MPI
    logging_level: str = getLevelName(logging.INFO)
    output_dir: str = "torchpilot_outputs"
    enable_compile: bool = False
    monitor_url: Optional[
        str
    ] = "http://experiment-manage-http.aip-excution.svc.idc-prod.amp.nioint.com/"  # noqa: E501

    class Config:  # pylint: disable=too-few-public-methods
        """Config for settings."""

        env_prefix = "TORCHPILOT_"


class GlobalSettings(BaseSettings):  # pylint: disable=too-few-public-methods
    """Settings for the global environment."""

    ci: bool = False
    cuda_visible_devices: Optional[str] = None
    gitlab_user_login: Optional[str] = None
    nts_job_name: Optional[str] = None
    nts_job_type: Optional[str] = None
    user: Optional[str] = None
    vc_master_hosts: str = "localhost"
    nts_url: Optional[str] = None
    nioflow_experiment_id: Optional[str] = None


class PrefetchDecodeSettings(BaseSettings):  # pylint: disable=too-few-public-methods
    """Settings for the Prefetch parameters."""

    warmup_time: int = 30
    max_retry_times: int = 1000

    class Config:  # pylint: disable=too-few-public-methods
        """Config for settings."""

        env_prefix = "PREFETCH_DECODE_"


class ArgusInferSettings(BaseSettings):  # pylint: disable=too-few-public-methods
    """Settings for the Argus Inference parameters."""

    PKL_LIST: Optional[List] = None

    class Config:  # pylint: disable=too-few-public-methods
        """Config for settings."""

        env_prefix = "ARGUS_INFER_"


class EvalInTrainSettings(BaseSettings):  # pylint: disable=too-few-public-methods
    """Settings for the Argus Inference parameters."""

    token: Optional[str] = None
    cfg: Optional[str] = None

    class Config:  # pylint: disable=too-few-public-methods
        """Config for settings."""

        env_prefix = "EVAL_IN_TRAIN_"


settings = Settings()
global_settings = GlobalSettings()
prefetch_decode_settings = PrefetchDecodeSettings()
argus_infer_settings = ArgusInferSettings()
eval_in_train = EvalInTrainSettings()
