# -*- coding: utf-8 -*-
"""TorchPilot tensorboard manager."""
import logging
import os
import socket
import time
from typing import List
from typing import Optional

from torch.utils.tensorboard import SummaryWriter

from torchpilot.utils.event_manager import EventManager
from torchpilot.utils.settings import settings


logger = logging.getLogger(__name__)


class TensorboardManager:
    """Tensorboard Manager."""

    def __init__(
        self,
        log_dir: str = "./",
        comment: str = "",
        filename_suffix: str = "",
        max_queue: int = 10,
        flush_secs: int = 120,
        rank: int = 0,
    ):
        """Init TensorboardManager Params.

        Args:
          log_dir (str): Save directory location.
          comment (str): Comment log_dir suffix appended to the default log_dir.
            For example, log_dir/xxxx.[comment]
          filename_suffix (str): Suffix added to all event filenames \
            in the log_dir directory.  For example, log_dir/xxxx.[comment].suffix
          max_queue (int): Size of the queue for pending events and summaries \
            before one of the ‘add’ calls forces a flush to disk. \
            Default: 10.
          flush_secs (int): How often, in seconds, \
            to flush the pending events and summaries to disk.\
            Default: 120 s.
        """
        filename_suffix = filename_suffix + f"_rank_{rank}"
        self.rank = rank
        self._writer = SummaryWriter(
            log_dir=log_dir,
            comment=comment,
            max_queue=max_queue,
            flush_secs=flush_secs,
            filename_suffix=filename_suffix,
        )

    def log_scaler(
        self, value_list_per_step: List, global_step_idx: int = 0, tag_prefix: str = ""
    ):
        """Log scaler value.

        Args:
          value_list_per_step (list): ["name: value",...]
          global_step_idx (int): The index of global step.
        """
        # process value_list_per_step as dict:
        for str_item in value_list_per_step:
            tag = str_item.split(":")[0].strip()
            value = str_item.split(":")[1].strip()
            if tag == "Task":
                continue
            if ("lr" in tag) and ("cost" not in tag):
                tag = "learning-rate/" + tag
            if ("loss" in tag) and ("cost" not in tag):
                tag = "loss-info/" + tag
            if (
                ("cost" in tag)
                or ("iter" in tag)
                or (("sample" in tag) and ("lr" not in tag))
            ):
                tag = "efficiency/" + tag
            if tag_prefix != "":
                tag = "/".join([tag_prefix, tag])
            self._writer.add_scalar(tag, float(value), global_step=global_step_idx)
            if settings.event_metrics:
                EventManager.put(
                    {
                        "key": tag,
                        "rank": self.rank,
                        "step": global_step_idx,
                        "type": "metrics",
                        "value": float(value),
                    }
                )

    def close(self):
        """Close Writer."""
        self._writer.close()


def tensorboard_trace_handler(
    dir_name: str, worker_name: Optional[str] = None, use_gzip: bool = False
):
    """
    torch.profiler import tensorboard_trace_handler.

    Outputs tracing files to directory of ``dir_name``, then that directory can be
    directly delivered to tensorboard as logdir.
    ``worker_name`` should be unique for each worker in distributed scenario,
    it will be set to '[hostname]_[pid]' by default.
    """

    def handler_fn(prof) -> None:
        nonlocal worker_name
        if not os.path.isdir(dir_name):
            try:
                os.makedirs(dir_name, exist_ok=True)
            except Exception as err:
                raise RuntimeError("Can't create directory: " + dir_name) from err
        if not worker_name:
            worker_name = f"{socket.gethostname()}_{os.getpid()}"
        # Use nanosecond here to avoid naming clash when exporting the trace
        file_name = f"{worker_name}.{time.time_ns()}.pt.trace.json"
        if use_gzip:
            file_name = file_name + ".gz"
        prof.export_chrome_trace(os.path.join(dir_name, file_name))
        # Export memroy overview
        try:
            prof.export_memory_timeline(
                f"{os.path.join(dir_name, file_name)}.html", device="cuda:0"
            )
        except Exception as err:  # pylint: disable=broad-except
            logger.warning(  # noqa: G200
                "%s export_memory_timeline is suported in > torch2.x", str(err)
            )

    return handler_fn
