# -*- coding: utf-8 -*-
"""MISC."""

import re

import torch
from packaging import version


def convert_to_seconds(time_str):
    """Conver to seconds."""
    # 匹配不同单位的正则表达式
    match = re.match(r"([0-9]*\.?[0-9]+)([a-zA-Z]+)", time_str)
    if not match:
        return "Invalid input"

    value, unit = float(match.group(1)), match.group(2)

    # 定义转换为秒的因子
    unit_conversion = {
        "s": 1,  # 秒
        "ms": 1e-3,  # 毫秒
        "us": 1e-6,  # 微秒
        "ns": 1e-9,  # 纳秒
        "min": 60,  # 分钟
        "h": 3600,  # 小时
        "d": 86400,  # 天
    }

    if unit not in unit_conversion:
        return "Unsupported unit"

    # 将时间值转换为秒
    seconds = value * unit_conversion[unit]

    return f"{seconds}s"


def is_torch_2_or_later():
    """Check torch version >= 2.0."""
    return version.parse(torch.__version__) >= version.parse("2.0.0")
