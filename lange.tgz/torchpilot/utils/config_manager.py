# -*- coding: utf-8 -*-
"""
config_manager.py.

Configuration file expansion and management.
"""

import inspect
import json
import logging
import multiprocessing
import os
import subprocess  # noqa: S404
from types import ModuleType

import torch


# Configure logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
handler = logging.StreamHandler()
formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
handler.setFormatter(formatter)
logger.addHandler(handler)

exclude_list = [
    "tp_multiprocessing_context_fork",
    "tp_multiprocessing_context_spawn",
    "params",
    "param_groups",
    "_dataset_name_list",
    "_meta_info_list",
    "meta_file",
    "label_files",
    "_meta_file",
    "grid_point",
    "params_policy",
    "loggerMap",
    "transforms",
    "_transforms",
    "frame_paths",
    "index",
]


def extract_nested_info(value, max_depth=20, current_depth=0):
    """
    Recursively extract information from nested objects with a depth limit.

    Args:
        value: The object to extract information from.
        max_depth (int): The maximum recursion depth.
        current_depth (int): The current recursion depth.

    Returns:
        Extracted information in a JSON-compatible format.
    """
    if current_depth > max_depth:
        return "Too deep"

    if isinstance(value, bytes):  # Check if it's bytes
        try:
            return value.decode("utf-8")  # Decode bytes to string
        except UnicodeDecodeError:
            return "Decoding failed"
    elif isinstance(value, ModuleType):  # Check if it's a module
        return None  # Skip modules
    if isinstance(value, dict):  # dict
        result = {
            k: extract_nested_info(v, max_depth, current_depth + 1)
            for k, v in value.items()
            if k not in exclude_list
        }
    elif isinstance(value, (list, tuple, set)):  # list, tuple, set
        result = [
            extract_nested_info(item, max_depth, current_depth + 1)
            for item in list(value)
        ]
    elif isinstance(value, torch.Tensor):  # pytorch.Tensor
        result = "tensor"
    elif isinstance(value, (bool, int, float, str, type(None))):  # Primitive type
        result = value
    elif isinstance(value, type):  # Check if it's a type (class itself)
        result = f"{value.__module__}.{value.__name__}"
    elif inspect.isfunction(value) and not inspect.isbuiltin(
        value
    ):  # Check if it's a function
        result = extract_function_info(value)  # Extract function info
    elif inspect.isclass(value) or hasattr(
        value, "__dict__"
    ):  # Check if it's a class instance
        result = extract_class_info(
            value, max_depth, current_depth + 1
        )  # Extract class info
    else:
        result = str(value)  # Fallback to string representation

    return result


def extract_function_info(func):
    """
    Extract information about a function, including its parameters.

    Args:
        func: The function to extract information from.

    Returns:
        A dictionary containing function information.
    """
    function_signature = inspect.signature(func)
    return {
        "parameters": {
            param_name: param.default if param.default is not param.empty else None
            for param_name, param in function_signature.parameters.items()
        }
    }


def extract_class_info(obj=None, max_depth=20, current_depth=0):
    """
    Extract information about a class instance, including attributes and methods.

    Args:
        obj: The class instance to extract information from.

    Returns:
        A dictionary containing class information.
    """
    if obj is None:
        return {}

    if current_depth > max_depth:
        return "Too deep"

    # Determine if obj is a class or an instance
    if inspect.isclass(obj):
        cls = obj
        class_info = {}
        # Get the Method Resolution Order (MRO) for the class
        mro = inspect.getmro(cls)

        for cls in mro:
            methods_info = {}
            for name, member in inspect.getmembers(cls, inspect.isfunction):
                if not inspect.isbuiltin(member):
                    methods_info[name] = extract_function_info(member)
            if "__init__" not in methods_info:
                return None

            # Recursively extract parent class information
            parent_info = {}
            for parent_cls in cls.__bases__:
                if parent_cls is not object:  # Skip the base object class
                    parent_info[parent_cls.__name__] = extract_class_info(
                        parent_cls, max_depth, current_depth + 1
                    )

            class_info[cls.__name__] = {
                "parameters": methods_info["__init__"]["parameters"],
                "parent_classes": parent_info,
            }

            return class_info

    else:
        instance_attributes = {
            key: extract_nested_info(value, max_depth, current_depth + 1)
            for key, value in obj.__dict__.items()
            if key not in exclude_list
        }

        methods_info = {}
        for name, member in inspect.getmembers(obj, inspect.ismethod):
            if not name.startswith("_") and not inspect.isbuiltin(
                member
            ):  # Ignore built-in methods
                methods_info[name] = extract_function_info(member)

        return {
            obj.__class__.__name__: {
                "instance_attributes": instance_attributes,
                "methods": methods_info,
            }
        }


def get_class_info(class_dict):
    """Save class information to a JSON file."""
    # Define the classes and functions to extract information from
    classes_and_functions = [
        (class_dict[0], "trainer"),
        # (TPInferrer, "inferrer"), # Currently only train is considered
        (class_dict[1], "lr_scheduler"),
        (class_dict[2], "optimizer"),
        (class_dict[3], "task_flow"),
        (class_dict[4], "dataloader"),
    ]

    # Extract information and store it in a dictionary
    info = {}
    for obj, name in classes_and_functions:
        if inspect.isclass(obj):
            info[name] = extract_class_info(obj)
        elif inspect.isfunction(obj):
            info[name] = extract_function_info(obj)
        else:
            info[name] = extract_class_info(obj.__class__)

    return info


def merge_json(queue, *args):  # class_dict, data, root_save_dir):
    """
    Save training configuration to a JSON file.

    Args:
        data (dict): The training configuration to save.
        output_dir (str): The directory to save the JSON file.
    """
    try:
        class_dict, data, root_save_dir = args
        class_info = get_class_info(class_dict)
        include_list = [
            "trainer",
            "inferrer",
            "lr_scheduler",
            "optimizer",
            "task_flow",
            "dataloader",
        ]
        serializable_data = {
            key: extract_nested_info(value, 9)
            for key, value in data.items()
            if key in include_list
        }
        for key, value in class_info.items():  # Currently only train is considered
            if key in serializable_data:
                temp = list(value.keys())[0]
                value[temp]["parameters"].update(serializable_data[key])
        # save
        output_dir = root_save_dir + "/cfg/"
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

        output_file = os.path.join(output_dir, "cfg.json")
        with open(output_file, "w", encoding="utf-8") as json_file:
            json.dump(class_info, json_file, indent=4)
        # logger.info("Class information saved to %s", output_file)
        success_message = f"Class information saved to {output_file}"
        queue.put((True, success_message))
    except Exception as exc:  # pylint:disable = broad-except
        error_message = f"Error:{exc}"
        queue.put((False, error_message))


def run_with_merge_json(func, timeout, rank, *args):
    """Run merge_json in multiprocessing."""
    if rank == 0:
        queue = multiprocessing.Queue()
        process = multiprocessing.Process(target=func, args=(queue,) + args)
        process.start()
        process.join(timeout)

        if process.is_alive():
            logger.warning("merge json is too large to be processed in a limited time")
            process.terminate()
            process.join()


def run_command(command, workdir=None, timeout=300):
    """
    Run a command and capture its output.

    Args:
        command (list): The command to run as a list of arguments.
        workdir (str): The working directory to run the command in.

    Returns:
        str: The stdout of the command.
    """
    try:
        result = subprocess.run(
            command,
            shell=False,  # noqa: S603
            timeout=timeout,
            text=True,
            capture_output=True,
            cwd=workdir,
            check=True,
        )
        return result.stdout
    except subprocess.CalledProcessError as error:
        error_message = f"Command failed: {command}\n" f"Error: {error.stderr}"
        raise RuntimeError(error_message) from error


def git_diff_and_patch(root_save_dir, rank):
    """
    Get the differences between the current working directory and HEAD.

    Save them as a patch file. Then apply the patch file locally.
    """
    if rank == 0:
        # Get the current HEAD commit ID
        commit_id = run_command(["git", "rev-parse", "HEAD"], workdir="./")
        logger.info("Current HEAD commit ID: %s", commit_id.strip())

        # Get the differences between the current working directory and HEAD
        diff_output = run_command(["git", "diff"], workdir="./")

        # Save the differences as a .patch file named after the commit ID
        repo_path = root_save_dir + "/cfg/"
        if not os.path.exists(repo_path):
            os.makedirs(repo_path)
        patch_file_name = f"{commit_id.strip()}.patch"
        patch_file_path = os.path.join(repo_path, patch_file_name)
        with open(patch_file_path, "w", encoding="utf-8") as patch_file:
            patch_file.write(diff_output)
        logger.info("Patch file saved to: %s", patch_file_path)


if __name__ == "__main__":
    pass
