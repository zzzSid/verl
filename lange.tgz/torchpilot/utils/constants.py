# -*- coding: utf-8 -*-
"""Constants for TorchPilot."""

from enum import Enum


seed: int = 666
run_name: str = "E0001"


class Backend(Enum):
    """Backend Enum."""

    GLOO = "gloo"
    MPI = "mpi"
    NCCL = "nccl"


class JobType(Enum):
    """Job Type Enum."""

    JOB = "job"
    WORKSHOP = "workshop"
    WORKSPACE = "workspace"


class LaunchMode(Enum):
    """Launch Mode Enum."""

    MPI = "mpi"
    SPAWN = "spawn"
