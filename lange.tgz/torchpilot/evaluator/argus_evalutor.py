# -*- coding: utf-8 -*-
"""Dataset for Argus format input."""


import logging
import os
from copy import deepcopy
from datetime import datetime
from glob import glob
from typing import Any
from typing import Dict
from typing import Iterable
from typing import List
from typing import Optional
from typing import Tuple
from typing import Union

from torchpilot.evaluator.base_evaluator import BaseEvaluator
from torchpilot.utils.file_manager import FileManager
from torchpilot.utils.registries import EVALUATOR


logger = logging.getLogger(__name__)


def argus_parse_model_outputs(
    evaluator_list,
    model_outputs: Union[Dict[str, Any], Tuple],
    targets: Dict[str, Any],
):
    """Parse sample data format to FrameSample.

    Args:
        inputs (Union[Dict, Tuple]): Eval inputs.
        targets (namedtuple): Targets, i.e. ground truth.

    Returns:
        List[FrameSample].
    """
    sample_list = []
    num_batches = len(targets["camera_ids"])

    for idx in range(num_batches):
        if isinstance(targets["gt"]["input_metas"][idx], list):
            sample = targets["gt"]["input_metas"][idx][-1]
        else:
            sample = targets["gt"]["input_metas"][idx]

        for _evaluator in evaluator_list:
            sample = _evaluator.argus_parse_model_outputs(
                model_outputs, idx, sample, targets
            )

        # NOTE: append after all evaluators processed.
        sample_list.append(sample)

    return sample_list


class EvaluatorMethod:
    """Evaluator method."""

    @staticmethod
    def evaluator_init(
        sub_evaluators_cfgs,
        task_name,
        use_gpu,
        use_dist,
    ):
        """Init evaluator."""
        sub_evaluators_cfgs[task_name].update(
            use_gpu=use_gpu,
            use_dist=use_dist,
        )
        return EVALUATOR.build(sub_evaluators_cfgs[task_name])

    @staticmethod
    def argus_eval(
        evaluator,
        model_outputs,
        model_inputs,
    ):
        """Argus eval."""

    single_frame_generator: List
    list_frame_generator: List


# pylint: disable=too-many-public-methods,disable=too-many-instance-attributes
# pylint: disable=consider-iterating-dictionary
class ArgusEvaluator(BaseEvaluator):
    """ArgusEvaluator."""

    def __init__(  # pylint: disable=too-many-branches.
        self,
        enable_tasks: Tuple[str],
        sub_evaluators_cfgs: Dict[str, Dict[str, Any]],
        eval_method_dict: Dict,
        ceph_reader,
        sensor_id,
        pred_path,
        ceph_root,
        pinhole_types,
        svc_types,
        generate_proto,
        proto_cfgs: Optional[Dict[str, Any]] = None,
        video_training_mode: bool = False,
        use_gpu: bool = False,
        use_dist: bool = False,
        cam_types=None,
        **kwargs,  # pylint: disable=unused-argument
    ) -> None:
        """Argus Evaluator."""
        super().__init__(use_gpu=use_gpu)
        self._task_evaluators: Dict[str, List] = {}
        self._enable_tasks = enable_tasks
        self._sub_evaluators_cfgs = sub_evaluators_cfgs
        self._cam_types = cam_types
        self._video_training_mode = video_training_mode
        self.eval_method_dict = eval_method_dict
        self.ceph_reader = ceph_reader
        self.sensor_id = sensor_id
        self.pred_path = pred_path
        self.ceph_root = ceph_root
        self.pinhole_types = pinhole_types
        self.svc_types = svc_types
        self._generate_proto = generate_proto
        for task_name, _value in self.eval_method_dict.items():
            if task_name in enable_tasks:
                self._task_evaluators[task_name] = _value.evaluator_init(
                    sub_evaluators_cfgs, task_name, use_gpu, use_dist
                )

        logger.warning("Using default proto_cfgs.")
        if proto_cfgs is not None:
            self._proto_cfgs = proto_cfgs
        else:
            self._proto_cfgs = dict(
                enable_convert_proto=True,
                convert_proto_cfgs=dict(
                    common={},
                    task_cfg=dict(
                        common={},
                    ),
                ),
            )

        # overwrite proto cfgs
        self._proto_cfgs["enable_convert_proto"] = True
        self._proto_cfgs["convert_proto_cfgs"]["common"][
            "enable_tasks"
        ] = self._enable_tasks
        self._proto_cfgs["convert_proto_cfgs"]["task_cfg"]["common"][
            "sensor_id"
        ] = 23  # default sensor id
        self._proto_cfgs["convert_proto_cfgs"]["common"]["dump_folder"] = os.path.join(
            FileManager.get_export_dir(),
            "proto",
        )
        # process sensor id
        if sensor_id is not None:
            self._proto_cfgs["convert_proto_cfgs"]["task_cfg"]["common"][
                "sensor_id"
            ] = sensor_id

        if use_dist and not use_gpu:
            raise ValueError("Distributed mode must use gpu.")
        self._use_dist = use_dist

        self._cur_rank_sample_count = 0
        self._eval_results: Dict = {task: {} for task in enable_tasks}

    def set_zero(self) -> None:
        """Set Init evaluator."""
        for evaluator in self._task_evaluators.values():
            if not isinstance(evaluator, Iterable):
                evaluator = [evaluator]
            for _evaluator in evaluator:
                if hasattr(_evaluator, "set_zero") and callable(_evaluator.set_zero):
                    _evaluator.set_zero()

    def remove_useless_resources(
        self,
        list_frame_samples: List,
    ) -> List:
        """Clear useless resources for evalution.

        Args:
            list_frame_samples (List[FrameSample]): List of frame samples.

        Returns:
            List[FrameSample].
        """
        processed_frame_samples = []
        for frame_sample in list_frame_samples:
            frame_sample = self.remove_unpickable_resources(frame_sample)
            # Pop unnecessary meta when eval.
            for cam_type in (
                self.pinhole_types.value_list() + self.svc_types.value_list()
            ):
                cam_meta = getattr(frame_sample, cam_type, None)
                if cam_meta is not None and "vt_image_meta" in cam_meta:
                    cam_meta["vt_image_meta"] = None
                if cam_meta is not None and "remap" in cam_meta:
                    cam_meta["remap"] = None
            processed_frame_samples.append(frame_sample)
        return processed_frame_samples

    @staticmethod
    def remove_unpickable_resources(frame_sample):
        """Clear unpickable resources for evalution.

        Args:
            frame_sample (FrameSample): frame sample.

        Returns:
            FrameSample.
        """
        if hasattr(frame_sample, "image_tensor"):
            setattr(frame_sample, "image_tensor", None)
        if hasattr(frame_sample, "mono3d_inputs"):
            setattr(frame_sample, "mono3d_inputs", None)
        return frame_sample

    def eval(  # type: ignore[override]
        self,
        model_outputs: Dict[str, Any],
        model_inputs: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Implement of Evaluator.

        Args:
            model_outputs (namedtuple): Model outputs.
            model_inputs (namedtuple): Targets, i.e. ground truth.
            dump_folder (str): dump folder for visualize results.

        Returns:
            Dict[str, Any].
        """
        # Data preprocess.
        for _task_name, _evaluator in self._task_evaluators.items():
            if _task_name in self._enable_tasks:
                frame_sample_list = self.eval_method_dict[_task_name].argus_eval(
                    _evaluator, model_outputs, model_inputs
                )

        # Generate proto.
        for sample in frame_sample_list:
            _proto_cfg = deepcopy(self._proto_cfgs["convert_proto_cfgs"])
            _proto_cfg["common"]["convert_type"] = "pred"

            for support_task in self.eval_method_dict.keys():
                if support_task in self._enable_tasks:
                    for _generator in self.eval_method_dict[
                        support_task
                    ].single_frame_generator:
                        self._generate_proto(
                            _generator,
                            _proto_cfg,
                            sample,
                        )
        return self._eval_results

    def generate_proto(self) -> None:
        """Generate proto (OD output)."""
        convert_type = "pred"
        proto_root_path = os.path.join(
            self._proto_cfgs["convert_proto_cfgs"]["common"]["dump_folder"]
        )

        subclip_list = [
            #  [case name, case id]
            i.rsplit("/", 2)[-2:]
            for i in glob(f"{proto_root_path}/*/*")
        ]

        if len(subclip_list) == 0:
            logger.warning("No subclip founded.")

        logger.warning("generate proto list, %s clip in total.", len(subclip_list))
        for case_name, case_id in subclip_list:
            subclip = case_name + case_id
            proto_data = os.path.join(proto_root_path, case_name, case_id, convert_type)
            _proto_cfg = deepcopy(self._proto_cfgs["convert_proto_cfgs"])
            _proto_cfg["common"]["convert_type"] = convert_type

            for support_task in self.eval_method_dict.keys():
                if support_task in self._enable_tasks:
                    for _generator in self.eval_method_dict[
                        support_task
                    ].list_frame_generator:
                        self._generate_proto(
                            _generator,
                            cfg={
                                "clip_id": subclip,
                                **_proto_cfg,
                            },
                            # dump root + clip id + pred
                            data=proto_data,
                        )

    def clip_upload(self):
        """Do MIL issue regression.

        NOTE: This function need trigger by MIL executor, and only suppose to infer one
        issue data at once.
        """
        logger.info("Start upload.")

        proto_root_path = os.path.join(
            self._proto_cfgs["convert_proto_cfgs"]["common"]["dump_folder"]
        )

        file_path_list = glob(f"{proto_root_path}/*/*/pred/*/*.dat")

        for file_path in file_path_list:
            self.ceph_reader.upload_file(
                file_path,
                os.path.join(
                    self.pred_path
                    or os.path.join(
                        self.ceph_root, "tpp_ci", datetime.now().strftime("%H_%M_%S")
                    ),
                    file_path.split("/")[-5],
                    file_path.split("/")[-4],
                    "record",
                    os.path.basename(file_path),
                ),
            )

        logger.warning("Uploaded infer result to %s", self.pred_path)

    def dist_all_reduce(  # pylint: disable=arguments-differ,too-many-branches
        self,
        eval_results: Dict[Any, Any],
    ) -> Dict[Any, Any]:
        """All reduce eval results and do some post processing.

        Args:
            eval_results (Dict[Any, Any]): Eval results of all epoch.

        Returns:
            eval_results.
        """
        self.generate_proto()
        self.clip_upload()

        return eval_results
