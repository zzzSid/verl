# -*- coding: utf-8 -*-
"""MultiTask Evaluator."""

import logging
from typing import Any
from typing import Dict
from typing import Tuple

from torchpilot.evaluator.base_evaluator import BaseEvaluator
from torchpilot.utils.registries import EVALUATOR


logger = logging.getLogger(__name__)


class MultiTaskEvaluator(BaseEvaluator):
    """MultiTask Evaluator.

    Args:
        enable_tasks (Tuple[str, ...]): Enable tasks.
        sub_evaluators_cfg [Dict[str, Dict[str, Any]]]: {task_name, task_evaluators}
            pairs.
    """

    def __init__(
        self,
        enable_tasks: Tuple[str, ...],
        sub_evaluators_cfg: Dict[str, Dict[str, Any]],
        **kwargs,
    ) -> None:
        """Initialize."""
        super().__init__(**kwargs)

        self._results: Dict[str, Dict[str, Any]] = {}
        self._task_evaluators = {}
        self._enable_tasks = enable_tasks

        for task_name in enable_tasks:
            sub_evaluators_cfg[task_name].update(**kwargs)
            self._task_evaluators[task_name] = EVALUATOR.build(
                sub_evaluators_cfg[task_name]
            )

        self._eval_results: Dict = {task: {} for task in enable_tasks}

    def set_zero(self):
        """Set evaluator to zero."""
        for task_name, task_evaluator in self._task_evaluators.items():
            logger.info("Set zero for %s evaluator.", task_name)
            task_evaluator.set_zero()

    def eval(
        self,
        model_outputs: Tuple[Any, ...],
        model_inputs: Dict[str, Any],
    ) -> Dict[str, Dict[str, Any]]:
        """Implement of Evaluator.

        Args:
            model_outputs (Tuple[Any, ...]): Model outputs.
            model_inputs (Dict[str, Any]): Task batch data.

        Returns:
            {task_name task_evaluator_result} pairs.
        """
        task_name = model_inputs["task_name"]
        if task_name in self._enable_tasks:
            self._results[task_name] = self._task_evaluators[task_name].eval(
                model_outputs,
                model_inputs,
            )
        else:
            raise RuntimeError(
                f"{task_name} not in enable tasks: {self._enable_tasks}."
            )

        return self._results

    # pylint: disable=arguments-differ.
    def get_specific_result(  # type: ignore[override]
        self,
        task_name: str,
        query_key: str,
    ) -> Dict[str, Any]:
        """Return evaluation result by query key.

        Args:
            task_name (str): Key of task name.
            query_key (str): Key of evaluation result.

        Returns:
            Specific result of query key.
        """
        return self._results[task_name][query_key]

    def dist_all_reduce(
        self,
        eval_results: Dict[Any, Any],
    ) -> Dict[Any, Any]:
        """All reduce by torch.distributed as dist.

        Args:
            eval_results (Dict[Any, Any]): Eval results of all epoch.

        Returns:
            eval_results.
        """
        outputs = {}
        for task_name, task_eval_results in eval_results.items():
            outputs[task_name] = self._task_evaluators[task_name].dist_all_reduce(
                task_eval_results
            )

        return eval_results
