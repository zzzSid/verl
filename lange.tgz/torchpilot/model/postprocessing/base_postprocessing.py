# -*- coding: utf-8 -*-
"""Torchpilot base post process."""

from abc import ABC
from abc import abstractmethod
from typing import Any
from typing import Dict
from typing import Tuple
from typing import Union

import torch


class BasePostProcess(torch.nn.Module, ABC):
    """BasePostProcess Abstract Interface.

    Args:
        train_mode (bool): Whether to enable training mode.
        **kwargs (Dict[str, Any]): Extra inputs for torch.nn.Module.
    """

    def __init__(
        self,
        train_mode: bool = True,
        **kwargs,
    ) -> None:
        """Initialize base post process."""
        super().__init__(**kwargs)
        self._train_mode = train_mode

    def set_mode(
        self,
        train_mode: bool = True,
    ) -> None:
        """Set training mode.

        Args:
            train_mode (bool): Whether to enable training mode.
        """
        self._train_mode = train_mode

    @abstractmethod
    def infer_postprocessing(
        self,
        model_outputs: Tuple[Any, ...],
        model_inputs: Union[Tuple[Any, ...], Dict[str, Any]],
    ) -> Tuple[Any, ...]:
        """Infer post processing forward.

        Args:
            model_outputs: (namedtuple): Model outputs.
            model_inputs: (namedtuple or Dict[str, Any]): Model inputs.

        Returns:
            Outputs of infer postprocessing, namedtuple.
        """
        raise NotImplementedError()

    @abstractmethod
    def train_postprocessing(
        self,
        model_outputs: Dict[str, Any],
        model_inputs: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Train post processing forward.

        Args:
            model_inputs: (Dict[str, Any]): Model inputs.
            model_outputs: (Dict[str, Any]): Model outputs.

        Returns:
            Outputs of train postprocessing, Dict[str, Any].
        """
        raise NotImplementedError()

    def forward(
        self,
        model_outputs: Union[Dict[str, Any], Tuple[Any, ...]],
        model_inputs: Union[Dict[str, Any], Tuple[Any, ...]],
    ) -> Union[Dict[str, Any], Tuple[Any, ...]]:
        """Forward post processing.

        Args:
            model_outputs (Dict[str, Any] or namedtuple): Model outputs.
            model_inputs (namedtuple or Dict[str, Any]) : Model inputs.

        Returns:
            If `train_mode`=True, return train postprocessing outputs,
                Dict[str, Any].
            If `train_mode`=False, return infer postprocessing outputs,
                namedtuple.
        """
        if not self._train_mode:
            if not isinstance(model_outputs, tuple):
                raise ValueError(
                    "`model_outputs` for infer postprocessing should be namedtuple, "
                    f"but got `{type(model_outputs)}`."
                )
            return self.infer_postprocessing(model_outputs, model_inputs)

        if not isinstance(model_outputs, dict):
            raise ValueError(
                "`model_outputs` for train postprocessing should be dict, "
                f"but got `{type(model_outputs)}`."
            )
        if not isinstance(model_inputs, dict):
            raise ValueError(
                "`model_inputs` for train postprocessing should be dict, "
                f"but got `{type(model_inputs)}`."
            )
        return self.train_postprocessing(model_outputs, model_inputs)
