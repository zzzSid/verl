# -*- coding: utf-8 -*-
"""torchpilot.model.head."""
