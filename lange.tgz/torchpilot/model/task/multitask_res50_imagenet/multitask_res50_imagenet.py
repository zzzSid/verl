# -*- coding: utf-8 -*-
"""MultiTaskRes50ImageNetTaskModel."""

from collections import namedtuple
from typing import Any
from typing import Dict
from typing import Tuple

from torch import Tensor
from torch import nn

from torchpilot.model.module_interface import BaseTaskModel
from torchpilot.utils.registries import BASE_MODEL


class MultiTaskRes50ImageNetTaskModel(BaseTaskModel):
    """MultiTaskRes50ImageNetTaskModel.

    Args:
        enable_tasks (Tuple[str, ...]): Enable tasks.
        sub_module_cfg (Dict[str, Any]): Config dict of sub module.
        train_mode (bool): Whether to enable training. Default=`True`.
    """

    def __init__(
        self,
        enable_tasks: Tuple[str, ...],
        sub_module_cfg: Dict[str, Any],
        train_mode: bool = True,
        num_classes: int = 1000,
        **kwargs,
    ) -> None:
        """Init Task Model base sub components."""
        super().__init__(
            sub_module_cfg=sub_module_cfg,
            train_mode=train_mode,
            **kwargs,
        )
        self._backbone = BASE_MODEL.build(sub_module_cfg["backbone"])
        self._cls_full_catenate0 = None
        self._cls_full_catenate1 = None
        self._enable_tasks = enable_tasks

        if "cls0" in enable_tasks:
            self._cls_full_catenate0 = nn.Linear(
                num_classes, sub_module_cfg["cls0"]["num_classes"]
            )
        if "cls1" in enable_tasks:
            self._cls_full_catenate1 = nn.Linear(
                num_classes, sub_module_cfg["cls1"]["num_classes"]
            )

    def init_weight(self) -> None:
        """Init model weight."""
        self._backbone.init_weight()

    def infer_forward(self, image: Tensor) -> Tuple[Any, ...]:
        """Infer forward.

        Args:
            image (Tensor): Image Tensor.

        Returns:
            Outputs of infer, Union[Dict[str, Any], torch.Tensor].
        """
        backbone_outputs = self._backbone(image)

        # Prepare output namedtuple.
        output_namedtuple_key = []
        output_namedtuple_value = []

        # Task cls0.
        if self._cls_full_catenate0 is not None:
            cls_fc0_out = self._cls_full_catenate0(backbone_outputs)
            output_namedtuple_key += ["cls0"]
            output_namedtuple_value += [cls_fc0_out]

        # Task cls1.
        if self._cls_full_catenate1 is not None:
            cls_fc1_out = self._cls_full_catenate1(backbone_outputs)
            output_namedtuple_key += ["cls1"]
            output_namedtuple_value += [cls_fc1_out]

        return namedtuple(
            "multitask_model_outputs_namedtuple",
            output_namedtuple_key,
        )(*output_namedtuple_value)

    def train_forward(
        self,
        inputs: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Train forward.

        Args:
            inputs (Dict[str, Any]): Inputs of infer.

        Returns:
            Outputs of train, Dict[str, Any].
        """
        backbone_outputs = self._backbone(inputs["image"])

        task_name = inputs["task_name"]
        outputs = {}

        if task_name == "cls0":
            if self._cls_full_catenate0 is None:
                raise RuntimeError("Task cls0 not in enable tasks.")
            cls_fc0_out = self._cls_full_catenate0(backbone_outputs)
            outputs[task_name] = {"model_outputs": cls_fc0_out}
        elif task_name == "cls1":
            if self._cls_full_catenate1 is None:
                raise RuntimeError("Task cls1 not in enable tasks.")
            cls_fc1_out = self._cls_full_catenate1(backbone_outputs)
            outputs[task_name] = {"model_outputs": cls_fc1_out}
        else:
            raise NotImplementedError()

        return outputs

    @property
    def enable_tasks(self):
        """Return enable tasks."""
        return self._enable_tasks
