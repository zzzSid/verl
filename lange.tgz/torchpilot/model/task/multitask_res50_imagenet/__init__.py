# -*- coding: utf-8 -*-
"""torchpilot.model.task.multitask_res50_imagenet."""
