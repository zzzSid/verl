# -*- coding: utf-8 -*-
"""demo model.

contributors:
jinyuanfeng@nio.com
"""
from collections import namedtuple
from typing import Any
from typing import Dict
from typing import Tuple

from torch import Tensor

from torchpilot.model.module_interface import BaseTaskModel
from torchpilot.utils.registries import BASE_MODEL


class Res50ImageNetModel(BaseTaskModel):
    """Define Task Model.

    Args:
        sub_module_cfg (Dict[str, Any]): Config dict of sub module.
        train_mode (bool): Whether to enable training. Default=`True`.
    """

    def __init__(
        self,
        sub_module_cfg: Dict[str, Any],
        train_mode: bool = True,
        **kwargs,
    ) -> None:
        """Init Task Model base sub components."""
        super().__init__(
            sub_module_cfg=sub_module_cfg,
            train_mode=train_mode,
            **kwargs,
        )
        self._backbone = BASE_MODEL.build(sub_module_cfg)

    def init_weight(self) -> None:
        """Init model weight."""
        self._backbone.init_weight()

    def infer_forward(self, image: Tensor) -> Tuple[Any, ...]:
        """Infer forward.

        Args:
            image (Tensor): Image Tensor.

        Returns:
            Outputs of infer, Union[Dict[str, Any], torch.Tensor].
        """
        return namedtuple("model_outputs", ["model_outputs"])(self._backbone(image))

    def train_forward(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """Train forward.

        Args:
            inputs (Dict[str, Any]): Inputs of infer.

        Returns:
            Outputs of train, Dict[str, Any].
        """
        return {"model_outputs": self._backbone(inputs["image"])}
