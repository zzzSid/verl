# -*- coding: utf-8 -*-
"""Torchpilot TaskFlow."""
from typing import Any
from typing import Callable
from typing import Dict
from typing import List
from typing import Tuple
from typing import Union

import torch

# pylint: disable=no-name-in-module
from argus_model_py.argus_model_py import DLDeviceType
from argus_model_py.samples.tvm_model_api.tvm_model_api import TVMModelAPI
from torch import nn

from torchpilot.model.module_interface import BaseTaskModel
from torchpilot.utils.misc import is_torch_2_or_later
from torchpilot.utils.registries import TASK_MODEL
from torchpilot.utils.stopwatch import stopwatch


# pylint: disable=import-error,no-name-in-module
if is_torch_2_or_later():
    # pylint: disable=ungrouped-imports
    from torch.distributed.fsdp.fully_sharded_data_parallel import (
        FullyShardedDataParallel,
    )
    from torch.distributed.fsdp.fully_sharded_data_parallel import MixedPrecision


# pylint: disable=no-self-use


class TPTaskFlow(torch.nn.Module):
    """Interface of base task model.

    Args:
        task_model_cfg (Dict[str, Any]): Config dict of task model.
        loss_func_cfg (Dict[str, Any]): Config dict of loss function. Default=`None`.
        postprocess_cfg (Dict[str, Any]): Config dict of postprocess.
        train_mode (bool): Whether to enable training mode. Default=`True`.
        enable_pbn (bool): Whether to enable pbn. Default=`False`.
    """

    def __init__(
        self,
        task_model_cfg: Dict[str, Any],
        loss_func_cfg: Dict[str, Any] = None,
        postprocess_cfg: Dict[str, Any] = None,
        train_mode: bool = True,
        enable_pbn: bool = False,
        **kwargs,
    ) -> None:
        """Initialize the basic components of task model."""
        super().__init__(**kwargs)
        self.stopwatch = stopwatch
        self._task_model = TASK_MODEL.build(task_model_cfg)
        if not isinstance(self._task_model, BaseTaskModel):
            raise ValueError(
                f"Expect type(self._task_model)=TPDataLoader, "
                f"but got {type(self._task_model)}."
            )

        self._loss_func: Union[nn.ModuleDict, Callable, None] = None
        if train_mode:
            # Note: Implement build losses is needed if enable train mode.
            if loss_func_cfg is None:
                raise ValueError(
                    "If enable train mode, expect loss_func_cfg is not None, "
                    "but got None"
                )

        # Note: Implement build postprocess is needed if postprocess cfg is not None.
        if postprocess_cfg is None:
            self._postprocess_layer = None

        self._task_model.set_mode(train_mode)
        self._train_mode = train_mode
        self._enable_pbn = enable_pbn

    def tvm_model_inputs_hook(self, model_inputs: Any) -> Any:
        """Convert DataLoader's Data as the inputs of tvm model."""
        raise NotImplementedError()

    def tvm_model_outputs_hook(self, model_outputs: Any) -> Any:
        """Convert the outputs of tvm model as Evaluator's inputs."""
        raise NotImplementedError()

    def trace_model_inputs_hook(self, model_inputs: Any) -> Any:
        """Convert DataLoader's Data as the inputs of trace model."""
        raise NotImplementedError()

    def trace_model_outputs_hook(self, model_outputs: Any) -> Any:
        """Convert the outputs of trace model as Evaluator's inputs."""
        raise NotImplementedError()

    @staticmethod
    def load_traced_model(ckpt_path) -> Any:
        """Load traced model."""
        traced_model = torch.jit.load(
            ckpt_path, map_location=torch.device(torch.cuda.current_device())
        )
        traced_model = traced_model.cuda(device=torch.cuda.current_device())

        return traced_model

    @staticmethod
    def load_tvm_model(ckpt_path) -> Any:
        """Load tvm model."""
        model = TVMModelAPI(
            model_path=ckpt_path, device_type=DLDeviceType.kDLCUDA, model_entry="main"
        )
        return model

    def forward(
        self,
        inputs: Dict[str, Any],
    ) -> Union[Tuple[Dict[str, Any], Dict[str, Any]], Tuple[Any, ...]]:
        """Forward.

        Args:
            inputs (Dict[str, Any]): Model inputs.

        Returns:
            If `train_mode`=True, return model train outputs and loss_dict.
            If `train_mode`=False, return model infer outputs.
        """
        if self.stopwatch.has_start_timing("ddp_cost"):
            self.stopwatch.record_time_cost("ddp_cost", "model_forward_cost")
        else:  # expect for test: no trainer/ inferrer to start `ddp_cost` timing.
            self.stopwatch.tic("model_forward_cost")
        if not self._train_mode:
            # NOTE: For `torch.jit.trace()`, the arguments should be several Tensors,
            # so `**inputs` instead of `inputs` (a dict) itself is used here.
            infer_outputs: Tuple[Any, ...] = self._task_model(**inputs)
            self.stopwatch.record_time_cost("model_forward_cost", None)

            if self._postprocess_layer:
                self.stopwatch.tic("postprocess_layer_cost")
                infer_outputs = self._postprocess_layer(infer_outputs)
                self.stopwatch.record_time_cost("postprocess_layer_cost", None)

            return infer_outputs

        train_outputs = self._task_model(inputs)
        self.stopwatch.record_time_cost("model_forward_cost", None)

        if self._postprocess_layer:
            self.stopwatch.tic("postprocess_layer_cost")
            train_outputs = self._postprocess_layer(train_outputs)
            self.stopwatch.record_time_cost("postprocess_layer_cost", None)

        self.stopwatch.tic("compute_loss_cost")
        loss_dict = self.compute_loss(train_outputs, inputs)
        self.stopwatch.record_time_cost("compute_loss_cost", None)

        return train_outputs, loss_dict

    def compute_loss(
        self,
        inputs: Dict[str, Any],
        targets: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Compute task model loss.

        Args:
            inputs (Dict[str, Any]): Module inputs.
            targets (Dict[str, Any]): Ground truth.

        Returns:
            Loss results.
        """
        if self._loss_func is not None and callable(self._loss_func):
            return self._loss_func(inputs, targets)
        raise NotImplementedError()

    def get_trace_model(self) -> Any:
        """Return trace model."""
        example_forward_input = torch.rand(1, 3, 224, 224)

        return torch.jit.trace(self, example_forward_input)

    def get_optim_policies(
        self,
    ) -> List[Dict[str, Any]]:
        """Get optimizer policies.

        Returns:
            Return optim policies for different model layer.
        """
        return [
            {
                "params": list(self.parameters()),
                "lr_mult": 1,
                "decay_mult": 1,
                "name": "all_params",
            },
        ]

    def warpper_model_for_fsdp_training(self):
        """Get FSDP auto warp policy."""
        self._task_model = FullyShardedDataParallel(
            module=self._task_model,
            device_id=torch.cuda.current_device(),
            use_orig_params=True,
            sync_module_states=True,
            mixed_precision=(  # fp32 because of precision first.
                MixedPrecision(
                    param_dtype=torch.float32,
                    reduce_dtype=torch.float32,
                    buffer_dtype=torch.float32,
                )
            ),
        )
