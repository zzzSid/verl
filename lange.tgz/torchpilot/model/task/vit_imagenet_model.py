# -*- coding: utf-8 -*-
"""VIT model on imagenet."""
from collections import namedtuple
from functools import partial
from typing import Any
from typing import Dict
from typing import Tuple

import torch
from torch import Tensor
from torch import nn

from torchpilot.model.base_model.vision_transformer import Block
from torchpilot.model.base_model.vision_transformer import DinoVisionTransformer
from torchpilot.model.layer.vit.attention import MemEffAttention
from torchpilot.model.module_interface import BaseTaskModel
from torchpilot.utils.registries import BASE_MODEL


class VITImageNetModel(BaseTaskModel):
    """Define Task Model.

    Args:
        sub_module_cfg (Dict[str, Any]): Config dict of sub module.
        train_mode (bool): Whether to enable training. Default=`True`.
    """

    def __init__(
        self,
        sub_module_cfg: Dict[str, Any],
        train_mode: bool = True,
        embedding_dim: int = 256,
        num_classes: int = 1000,
        freeze_backbone: bool = False,
        **kwargs,
    ) -> None:
        """Init Task Model base sub components."""
        super().__init__(
            sub_module_cfg=sub_module_cfg,
            train_mode=train_mode,
            **kwargs,
        )
        self._backbone = BASE_MODEL.build(sub_module_cfg)
        self._fc = nn.Linear(embedding_dim, num_classes)
        self.freeze_backbone = freeze_backbone

    def init_weight(self) -> None:
        """Init model weight."""
        self._backbone.init_weight()

    def train(self, mode=True):
        """Keep normalization layer freezed."""
        super().train(mode)
        if self.freeze_backbone:
            self._backbone.eval()
            for param in self._backbone.parameters():
                param.requires_grad = False

    def infer_forward(self, image: Tensor) -> Tuple[Any, ...]:
        """Infer forward.

        Args:
            image (Tensor): Image Tensor.

        Returns:
            Outputs of infer, Union[Dict[str, Any], torch.Tensor].
        """
        outputs = self._backbone(image)
        cls_token = outputs["x_norm_clstoken"]
        patch_tokens = outputs["x_norm_patchtokens"]
        linear_input = torch.cat(
            [
                cls_token,
                patch_tokens.mean(dim=1),
            ],
            dim=1,
        )
        logits = self._fc(linear_input)
        return namedtuple("model_outputs", ["model_outputs"])(logits)

    def train_forward(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """Train forward.

        Args:
            inputs (Dict[str, Any]): Inputs of infer.

        Returns:
            Outputs of train, Dict[str, Any].
        """
        outputs = self._backbone(inputs["image"], is_training=True)
        cls_token = outputs["x_norm_clstoken"]
        patch_tokens = outputs["x_norm_patchtokens"]
        linear_input = torch.cat(
            [
                cls_token,
                patch_tokens.mean(dim=1),
            ],
            dim=1,
        )
        logits = self._fc(linear_input)
        return {"model_outputs": logits}


def create_vit_tiny(
    patch_size=16,
    num_register_tokens=0,
    freeze_backbone=False,
    mlp_checkpoint=False,
    **kwargs,
):
    """Params: 11.8M."""
    return dict(
        type=VITImageNetModel,
        sub_module_cfg=dict(
            type=DinoVisionTransformer,
            img_size=518,
            patch_size=patch_size,
            embed_dim=288,
            depth=12,
            num_heads=4,
            mlp_ratio=4,
            block_fn=partial(
                Block, attn_class=MemEffAttention, mlp_checkpoint=mlp_checkpoint
            ),
            init_values=1.0,
            interpolate_offset=0.1,
            interpolate_antialias=False,
            ffn_layer="mlp",
            num_register_tokens=num_register_tokens,
            **kwargs,
        ),
        embedding_dim=288 * 2,
        freeze_backbone=freeze_backbone,
    )


def create_vit_small(
    patch_size=16,
    num_register_tokens=0,
    freeze_backbone=False,
    mlp_checkpoint=False,
    **kwargs,
):
    """Params: 21M."""
    return dict(
        type=VITImageNetModel,
        sub_module_cfg=dict(
            type=DinoVisionTransformer,
            img_size=518,
            patch_size=patch_size,
            embed_dim=384,
            depth=12,
            num_heads=6,
            mlp_ratio=4,
            block_fn=partial(
                Block, attn_class=MemEffAttention, mlp_checkpoint=mlp_checkpoint
            ),
            init_values=1.0,
            interpolate_offset=0.1,
            interpolate_antialias=False,
            ffn_layer="mlp",
            num_register_tokens=num_register_tokens,
            **kwargs,
        ),
        embedding_dim=384 * 2,  # cls token + patch_tokens
        freeze_backbone=freeze_backbone,
    )


def create_vit_base(
    patch_size=16,
    num_register_tokens=0,
    freeze_backbone=False,
    mlp_checkpoint=False,
    **kwargs,
):
    """Params: 86M."""
    return dict(
        type=VITImageNetModel,
        sub_module_cfg=dict(
            type=DinoVisionTransformer,
            img_size=518,
            patch_size=patch_size,
            embed_dim=768,
            depth=12,
            num_heads=12,
            mlp_ratio=4,
            block_fn=partial(
                Block, attn_class=MemEffAttention, mlp_checkpoint=mlp_checkpoint
            ),
            init_values=1.0,
            interpolate_offset=0.1,
            interpolate_antialias=False,
            ffn_layer="mlp",
            num_register_tokens=num_register_tokens,
            **kwargs,
        ),
        embedding_dim=768 * 2,
        freeze_backbone=freeze_backbone,
    )


def create_vit_large(
    patch_size=16,
    num_register_tokens=0,
    freeze_backbone=False,
    mlp_checkpoint=False,
    **kwargs,
):
    """Params: 307M."""
    return dict(
        type=VITImageNetModel,
        sub_module_cfg=dict(
            type=DinoVisionTransformer,
            img_size=518,
            patch_size=patch_size,
            embed_dim=1024,
            depth=24,
            num_heads=16,
            mlp_ratio=4,
            block_fn=partial(
                Block, attn_class=MemEffAttention, mlp_checkpoint=mlp_checkpoint
            ),
            init_values=1.0,
            interpolate_offset=0.1,
            interpolate_antialias=False,
            ffn_layer="mlp",
            num_register_tokens=num_register_tokens,
            **kwargs,
        ),
        embedding_dim=1024 * 2,
        freeze_backbone=freeze_backbone,
    )


def create_vit_giant2(
    patch_size=16,
    num_register_tokens=0,
    freeze_backbone=False,
    mlp_checkpoint=False,
    **kwargs,
):
    """Params: 1151.25M.

    Close to ViT-giant, with embed-dim 1536 and 24 heads => embed-dim per head 64
    """
    return dict(
        type=VITImageNetModel,
        sub_module_cfg=dict(
            type=DinoVisionTransformer,
            patch_size=patch_size,
            embed_dim=1536,
            depth=40,
            num_heads=24,
            mlp_ratio=4,
            block_fn=partial(
                Block, attn_class=MemEffAttention, mlp_checkpoint=mlp_checkpoint
            ),
            init_values=1.0,
            interpolate_offset=0.1,
            interpolate_antialias=False,
            ffn_layer="mlp",
            num_register_tokens=num_register_tokens,
            **kwargs,
        ),
        embedding_dim=1536 * 2,
        freeze_backbone=freeze_backbone,
    )
