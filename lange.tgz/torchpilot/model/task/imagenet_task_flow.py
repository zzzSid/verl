# -*- coding: utf-8 -*-
"""Torchpilot TaskFlow."""
from collections import namedtuple
from typing import Any
from typing import Dict
from typing import List
from typing import Tuple
from typing import Union

import torch

from torchpilot.model.task.tp_task_flow import TPTaskFlow
from torchpilot.utils.registries import LOSSES
from torchpilot.utils.registries import POSTPROCESS


class ImageNetTaskFlow(TPTaskFlow):
    """ImageNet Task Flow.

    Args:
        task_model_cfg (Dict[str, Any]): Config dict of task model.
        loss_func_cfg (Dict[str, Any]): Config dict of loss function. Default=`None`.
        postprocess_cfg (Dict[str, Any]): Config dict of postprocess.
        train_mode (bool): Whether to enable training mode. Default=`True`.
        enable_pbn (bool): Whether to enable pbn. Default=`False`.
    """

    def __init__(
        self,
        loss_func_cfg: Dict[str, Any] = None,
        postprocess_cfg: Dict[str, Any] = None,
        train_mode: bool = True,
        **kwargs,
    ) -> None:
        """Init."""
        super().__init__(
            loss_func_cfg=loss_func_cfg,
            postprocess_cfg=postprocess_cfg,
            train_mode=train_mode,
            **kwargs,
        )
        if train_mode:
            self._loss_func = LOSSES.build(loss_func_cfg)

        if postprocess_cfg is not None:
            self._postprocess_layer = POSTPROCESS.build(postprocess_cfg)

    def get_trace_model(self) -> Any:
        """Return trace model."""
        example_forward_input = torch.rand(1, 3, 224, 224)

        return torch.jit.trace(self._task_model, example_forward_input)

    def tvm_model_inputs_hook(
        self,
        model_inputs: Any,
    ) -> Any:
        """Convert DataLoader's Data as the inputs of tvm model."""
        return {"inputs_0": model_inputs["image"].detach().cpu().numpy()}

    def tvm_model_outputs_hook(
        self,
        model_outputs: Any,
    ) -> Any:
        """Convert the outputs of tvm model as Evaluator's inputs."""
        return namedtuple("model_outputs", ["model_outputs"])(
            torch.from_numpy(model_outputs["1334"]).cuda()
        )

    def trace_model_inputs_hook(
        self,
        model_inputs: Any,
    ) -> Any:
        """Convert DataLoader's Data as the inputs of trace model."""
        return model_inputs["image"]

    def trace_model_outputs_hook(
        self,
        model_outputs: Any,
    ) -> Any:
        """Convert the outputs of trace model as Evaluator's inputs."""
        return namedtuple("model_outputs", ["model_outputs"])(model_outputs[0])

    def forward(
        self, inputs: Dict[str, Any]
    ) -> Union[Tuple[Dict[str, Any], Dict[str, Any]], Tuple[Any, ...]]:
        """Forward.

        Args:
            inputs (Dict[str, Any]): Model inputs.

        Returns:
            If `train_mode`=True, return model outputs and loss_dict.
            If `train_mode`=False, return model outputs.
        """
        if self.stopwatch.has_start_timing("ddp_cost"):
            self.stopwatch.record_time_cost("ddp_cost", "model_forward_cost")
        else:  # expect for test: no trainer/ inferrer to start `ddp_cost` timing.
            self.stopwatch.tic("model_forward_cost")
        if not self._train_mode:
            infer_outputs = self._task_model(inputs["image"])
            self.stopwatch.record_time_cost("model_forward_cost", None)
            return infer_outputs

        train_outputs = self._task_model(inputs)
        self.stopwatch.record_time_cost("model_forward_cost", "compute_loss_cost")
        loss_dict = self.compute_loss(train_outputs, inputs)
        self.stopwatch.record_time_cost("compute_loss_cost", None)
        return train_outputs, loss_dict

    def get_optim_policies(  # pylint: disable=too-many-branches
        self,
    ) -> List[Dict[str, Any]]:
        """Get optimizer policies.

        Returns:
            Return optim policies for different model layer.
        """
        first_conv_weight = []
        first_conv_bias = []
        normal_weight = []
        normal_bias = []
        batch_norm = []
        other_modules = []

        conv_cnt = 0
        bn_cnt = 0

        for module in self.modules():
            if isinstance(module, (torch.nn.Conv2d, torch.nn.Conv1d)):
                params = list(module.parameters())
                conv_cnt += 1
                if conv_cnt == 1:
                    first_conv_weight.append(params[0])
                    if len(params) == 2:
                        first_conv_bias.append(params[1])
                else:
                    normal_weight.append(params[0])
                    if len(params) == 2:
                        normal_bias.append(params[1])
            elif isinstance(module, torch.nn.Linear):
                params = list(module.parameters())
                normal_weight.append(params[0])
                if len(params) == 2:
                    normal_bias.append(params[1])

            elif isinstance(module, torch.nn.BatchNorm1d):
                batch_norm.extend(list(module.parameters()))
            elif isinstance(module, torch.nn.modules.normalization.GroupNorm):
                batch_norm.extend(list(module.parameters()))
            elif isinstance(module, torch.nn.modules.batchnorm.SyncBatchNorm):
                batch_norm.extend(list(module.parameters()))
            elif isinstance(module, torch.nn.modules.normalization.LayerNorm):
                batch_norm.extend(list(module.parameters()))
            elif isinstance(module, torch.nn.BatchNorm2d):
                bn_cnt += 1  # later BN's are frozen
                if not self._enable_pbn or bn_cnt == 1:
                    batch_norm.extend(list(module.parameters()))
            elif len(module._modules) == 0:  # pylint: disable=protected-access
                if len(list(module.parameters())) > 0:
                    other_modules.extend(list(module.parameters()))
        return [
            {
                "params": first_conv_weight,
                "lr_mult": 1,
                "decay_mult": 1,
                "name": "first_conv_weight",
            },
            {
                "params": first_conv_bias,
                "lr_mult": 1,
                "decay_mult": 1,
                "name": "first_conv_bias",
            },
            {
                "params": normal_weight,
                "lr_mult": 1,
                "decay_mult": 1,
                "name": "normal_weight",
            },
            {
                "params": normal_bias,
                "lr_mult": 1,
                "decay_mult": 1,
                "name": "normal_bias",
            },
            {
                "params": batch_norm,
                "lr_mult": 1,
                "decay_mult": 1,
                "name": "BN scale/shift",
            },
            {
                "params": other_modules,
                "lr_mult": 1,
                "decay_mult": 1,
                "name": "other_modules",
            },
        ]
