# -*- coding: utf-8 -*-
"""One model front rear TaskFlow."""

import logging
from collections import namedtuple
from typing import Any
from typing import Dict
from typing import Tuple
from typing import Union

import torch

from torchpilot.model.task.tp_task_flow import TPTaskFlow
from torchpilot.utils.registries import LOSSES
from torchpilot.utils.registries import POSTPROCESS


logger = logging.getLogger(__name__)


class MultiTaskRes50ImageNetTaskFlow(TPTaskFlow):
    """MultiTaskRes50ImageNetTaskFlow.

    Args:
        task_model_cfg (Dict[str, Any]): Config dict of task model.
        loss_func_cfg (Dict[str, Any]): Config dict of loss function. Default=`None`.
        postprocess_cfg (Dict[str, Any]): Config dict of postprocess.
        train_mode (bool): Whether to enable training mode. Default=`True`.
    """

    def __init__(
        self,
        task_model_cfg: Dict[str, Any],
        loss_func_cfg: Dict[str, Any] = None,
        postprocess_cfg: Dict[str, Any] = None,
        train_mode: bool = True,
        **kwargs,
    ) -> None:
        """Initialize the basic components of od front task model."""
        super().__init__(
            task_model_cfg=task_model_cfg,
            loss_func_cfg=loss_func_cfg,
            postprocess_cfg=postprocess_cfg,
            train_mode=train_mode,
            **kwargs,
        )
        if train_mode:
            self._loss_func = LOSSES.build(loss_func_cfg)

        if postprocess_cfg is not None:
            self._postprocess_layer = POSTPROCESS.build(postprocess_cfg)

    def forward(
        self,
        inputs: Dict[str, Any],
    ) -> Union[Tuple[Dict[str, Any], Dict[str, Any]], Tuple[Any, ...]]:
        """Forward.

        Args:
            inputs (Dict[str, Any]): Model inputs.

        Returns:
            If `train_mode`=True, return model train outputs and loss_dict.
            If `train_mode`=False, return model infer outputs.
        """
        if self.stopwatch.has_start_timing("ddp_cost"):
            self.stopwatch.record_time_cost("ddp_cost", "model_forward_cost")
        else:  # expect for test: no trainer/ inferrer to start `ddp_cost` timing.
            self.stopwatch.tic("model_forward_cost")
        if not self._train_mode:
            infer_outputs = self._task_model(inputs["image"])
            self.stopwatch.record_time_cost("model_forward_cost", None)
            return infer_outputs

        train_outputs = self._task_model(inputs)
        self.stopwatch.record_time_cost("model_forward_cost", "compute_loss_cost")
        loss_dict = self.compute_loss(train_outputs, inputs)
        self.stopwatch.record_time_cost("compute_loss_cost", None)
        return train_outputs, loss_dict

    def tvm_model_inputs_hook(
        self,
        model_inputs: Any,
    ) -> Any:
        """Convert DataLoader's Data as the inputs of tvm model."""
        raise NotImplementedError()

    def tvm_model_outputs_hook(
        self,
        model_outputs: Any,
    ) -> Any:
        """Convert the outputs of tvm model as Evaluator's inputs."""
        raise NotImplementedError()

    def trace_model_inputs_hook(
        self,
        model_inputs: Any,
    ) -> Any:
        """Convert DataLoader's Data as the inputs of trace model."""
        enable_task = self._task_model.enable_tasks[0]
        return model_inputs[enable_task]["image"]

    def trace_model_outputs_hook(
        self,
        model_outputs: Any,
    ) -> Any:
        """Convert the outputs of trace model as Evaluator's inputs."""
        enable_task = self._task_model.enable_tasks[0]

        if enable_task == "cls0":
            return namedtuple("multitask_model_outputs_namedtuple", ("cls0",),)(
                model_outputs[0],
            )
        if enable_task == "cls1":
            return namedtuple("multitask_model_outputs_namedtuple", ("cls1",),)(
                model_outputs[1],
            )
        raise NotImplementedError()

    def get_trace_model(self) -> Any:
        """Return trace model."""
        example_forward_input = torch.rand(1, 3, 224, 224)

        return torch.jit.trace(self._task_model, example_forward_input)
