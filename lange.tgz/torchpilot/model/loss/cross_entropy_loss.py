# -*- coding: utf-8 -*-
"""CrossEntropyLoss."""

from typing import Any
from typing import Dict

import torch

from torchpilot.model.loss.base_loss import BaseLoss


class CrossEntropyLoss(BaseLoss):
    """CrossEntropyLoss."""

    def __init__(
        self,
        name: str = "cross_entropy_loss",
    ) -> None:
        """Initialize."""
        super().__init__(name=name)

    def forward(  # pylint: disable=no-self-use
        self,
        model_outputs: Dict[str, Any],
        model_inputs: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Calculate Loss."""
        # pred_logits shape: [BS, N]
        # label shape: [N]
        # normalize and log
        pred_logits, label = model_outputs["model_outputs"], model_inputs["gt"]
        pred_logits_norm_log = torch.log(torch.softmax(pred_logits, dim=1))
        loss = torch.nn.NLLLoss()(pred_logits_norm_log, label.long())

        return {"loss_cls": loss}


class CrossEntropyLossDistill(BaseLoss):
    """CrossEntropyLoss."""

    def __init__(
        self,
        name: str = "cross_entropy_loss",
    ) -> None:
        """Initialize."""
        super().__init__(name=name)

    def forward(  # pylint: disable=no-self-use
        self,
        model_outputs: Dict[str, Any],
        model_inputs: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Calculate Loss."""
        # pred_logits shape: [BS, N]
        # label shape: [N]
        # normalize and log
        student_pred_logits = model_outputs["model_outputs"]
        teacher_pred_logits = model_inputs["teacher_outputs"][0]
        gt_label = model_inputs["gt"].long()

        student_pred_label = torch.softmax(student_pred_logits, dim=1)
        teacher_soft_label = torch.log_softmax(teacher_pred_logits, dim=1)

        loss_distill = torch.nn.KLDivLoss()(student_pred_label, teacher_soft_label)

        student_pred_logits_norm_log = torch.log(
            torch.softmax(student_pred_logits, dim=1)
        )
        teacher_pred_logits_norm_log = torch.log(
            torch.softmax(teacher_pred_logits, dim=1)
        )
        loss_student = torch.nn.NLLLoss()(student_pred_logits_norm_log, gt_label)
        loss_teacher = torch.nn.NLLLoss()(teacher_pred_logits_norm_log, gt_label)

        return {
            "loss_distill": loss_distill,
            "loss_student": loss_student,
            "loss_teacher": loss_teacher,
        }
