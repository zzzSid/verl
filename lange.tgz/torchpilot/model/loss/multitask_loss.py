# -*- coding: utf-8 -*-
"""MultiTask loss."""

import logging
from typing import Any
from typing import Dict
from typing import Tuple

import torch
from torch import nn

from torchpilot.model.loss.base_loss import BaseLoss
from torchpilot.utils.registries import LOSSES


logger = logging.getLogger(__name__)


class MultiTaskLoss(BaseLoss):
    """MultiTask loss.

    Args
        enable_tasks (Tuple[str]): Enable tasks.
        sub_loss_cfg (Dict[str, Dict[str, Any]]): Sub loss config dict.
        task_loss_weight (Dict[str, float]): {task_name, loss_weight} pairs.
            Default=`None`.
    """

    def __init__(
        self,
        enable_tasks: Tuple[str],
        sub_loss_cfg: Dict[str, Dict[str, Any]],
        task_loss_weight: Dict[str, float] = None,
        **kwargs,
    ) -> None:
        """Init."""
        if task_loss_weight is not None:
            if not isinstance(task_loss_weight, dict):
                raise ValueError(
                    f"Expect type(task_loss_weight)==dict, but got "
                    f"{type(task_loss_weight)}."
                )
            for task_name, _task_loss_weight in task_loss_weight.items():
                if not isinstance(_task_loss_weight, float):
                    raise ValueError(
                        f"Expect type(task_loss_weight)==float, but got "
                        f"{type(_task_loss_weight)}."
                    )

        super().__init__(**kwargs)
        self._enable_tasks = enable_tasks
        self._task_loss_func = nn.ModuleDict()
        self._task_loss_weight = task_loss_weight or {
            task_name: 1.0 for task_name in enable_tasks
        }

        for task_name in self._enable_tasks:
            self._task_loss_func[task_name] = LOSSES.build(sub_loss_cfg[task_name])

            if task_name not in self._task_loss_weight:
                logger.warning("Set loss weight of %s to `1.0`.", task_name)
                self._task_loss_weight[task_name] = 1.0

    def forward(
        self,
        model_outputs: Dict[str, Any],
        model_inputs: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Forward loss.

        Args:
            model_outputs (Dict[str, Any]): Pred result of model.
            model_inputs (Dict[str, Any]): Ground truth.

        Returns:
            Loss dict.
        """
        task_loss = self._task_loss_func[model_inputs["task_name"]](
            model_outputs, model_inputs
        )
        if not isinstance(task_loss, dict):
            raise ValueError(
                f"Expect task_loss is {str, torch.Tensor} pairs but got type "
                f"task_loss={task_loss}."
            )
        for loss_name, loss_value in task_loss.items():
            if not isinstance(loss_value, torch.Tensor):
                raise TypeError(f"{loss_name} is not a tensor.")

            task_loss[loss_name] *= self._task_loss_weight[model_inputs["task_name"]]
        return task_loss
