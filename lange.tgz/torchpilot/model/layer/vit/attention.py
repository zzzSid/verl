# -*- coding: utf-8 -*-
"""Provide attention module."""
# flake8: noqa
# pylint: skip-file
# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# This source code is licensed under the Apache License, Version 2.0
# found in the LICENSE file in the root directory of this source tree.

# References:
#   https://github.com/facebookresearch/dino/blob/master/vision_transformer.py
#   https://github.com/rwightman/pytorch-image-models/tree/master/timm/models/vision_transformer.py

import logging
import os
import warnings

import torch
from torch import Tensor
from torch import nn


logger = logging.getLogger(__name__)


XFORMERS_ENABLED = os.environ.get("XFORMERS_DISABLED") is None
try:
    if XFORMERS_ENABLED:
        from xformers.ops import memory_efficient_attention
        from xformers.ops import unbind

        XFORMERS_AVAILABLE = True
        warnings.warn("xFormers is available (Attention)")
    else:
        warnings.warn("xFormers is disabled (Attention)")
        XFORMERS_AVAILABLE = False
except ImportError:
    XFORMERS_AVAILABLE = False
    warnings.warn("xFormers is not available (Attention)")


class Attention(nn.Module):
    def __init__(
        self,
        dim: int,
        num_heads: int = 8,
        qkv_bias: bool = False,
        proj_bias: bool = True,
        attn_drop: float = 0.0,
        proj_drop: float = 0.0,
    ) -> None:
        super().__init__()
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = head_dim**-0.5

        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop, inplace=True)
        self.proj = nn.Linear(dim, dim, bias=proj_bias)
        self.proj_drop = nn.Dropout(proj_drop, inplace=True)

    def forward(self, x: Tensor) -> Tensor:
        ndim = x.ndim
        if ndim == 3:
            B, N, C = x.shape
        else:
            B, H, W, C = x.shape
            N = H * W
        qkv = (
            self.qkv(x)
            .reshape(B, N, 3, self.num_heads, C // self.num_heads)
            .permute(2, 0, 3, 1, 4)
        )

        q, k, v = qkv[0] * self.scale, qkv[1], qkv[2]
        attn = q @ k.transpose(-2, -1)

        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)

        x = (attn @ v).transpose(1, 2)
        if ndim > 3:
            x = x.reshape(B, H, W, C)
        else:
            x = x.reshape(B, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x


class MemEffAttention(Attention):
    def forward(self, x: Tensor, attn_bias=None) -> Tensor:
        ndim = x.ndim
        if ndim == 3:
            B, N, C = x.shape
        else:
            B, H, W, C = x.shape
            N = H * W

        if not XFORMERS_AVAILABLE:
            # flash attention, suport in > torch2.1
            qkv = (
                self.qkv(x)
                .reshape(B, N, 3, self.num_heads, C // self.num_heads)
                .permute(0, 3, 2, 1, 4)
                .contiguous()
            )
            q, k, v = torch.unbind(qkv, 2)
            x = nn.functional.scaled_dot_product_attention(q, k, v)
            if ndim == 3:
                x = x.reshape([B, N, C])
            else:
                x = x.reshape([B, H, W, C])

            x = self.proj(x)
            x = self.proj_drop(x)
            return x
            # if attn_bias is not None:
            #     raise AssertionError("xFormers is required for using nested tensors")
            # return super().forward(x)
        qkv = self.qkv(x).reshape(
            B, N, 3, self.num_heads, C // self.num_heads
        )  # 6Bsh^2

        q, k, v = unbind(qkv, 2)

        x = memory_efficient_attention(q, k, v, attn_bias=attn_bias)  # 4Bs^2h
        if ndim == 3:
            x = x.reshape([B, N, C])
        else:
            x = x.reshape([B, H, W, C])

        x = self.proj(x)  # 2Bsh^2
        x = self.proj_drop(x)
        return x
