# -*- coding: utf-8 -*-
"""Provide vit module."""
