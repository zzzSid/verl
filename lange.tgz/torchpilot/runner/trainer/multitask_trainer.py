# -*- coding: utf-8 -*-
"""MultiTaskTrainer."""

from typing import Any
from typing import Dict

from torchpilot.runner.trainer.tp_trainer import TPTrainer


class MultiTaskTrainer(TPTrainer):
    """Trainer for training multitask.

    Args:
        multi_step_training (bool): Whether to enable multi step training.
            Default=`True`.
    """

    def forward_backward_model(
        self,
        batch_data: Dict[str, Any],
        task_name: str = "",
    ) -> Dict[str, Any]:
        """Forward model.

        Args:
            batch_data (Dict[str, Any]): One Batch data.
            task_name (str): Time cost prefix. Default=`""`.

        Returns:
            Model outputs (Dict[str, Any]).
        """
        # For multi-step training, `batch_data` is expected to be a dict of
        # task-specific input data. Otherwise, `batch_data` is just the input
        # data for a single task.
        if self._multi_step_training:
            del task_name

            # Loop over task-specific data and accumulate the gradients.
            model_outputs = {}
            for current_task_name, task_batch in batch_data.items():
                model_outputs[current_task_name] = super().forward_backward_model(
                    task_batch, current_task_name
                )
        else:
            model_outputs = super().forward_backward_model(batch_data, task_name)
        return model_outputs
