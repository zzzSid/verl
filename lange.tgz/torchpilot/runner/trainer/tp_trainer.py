# -*- coding: utf-8 -*-
"""Torchpilot Trainer."""

import itertools
import logging
import math
import os
import random
import time
from collections import OrderedDict
from collections import defaultdict
from datetime import timedelta
from typing import Any
from typing import Callable
from typing import Dict
from typing import Iterable
from typing import List
from typing import Literal
from typing import Optional
from typing import Union

import numpy as np
import requests
import torch
import torch.distributed as dist
from packaging import version
from prettytable import PrettyTable
from torch.distributed.algorithms.ddp_comm_hooks.powerSGD_hook import PowerSGDState
from torch.distributed.algorithms.ddp_comm_hooks.powerSGD_hook import (
    batched_powerSGD_hook,
)
from torch.nn.parameter import Parameter
from torch.nn.utils import clip_grad_norm_
from torch.optim import Optimizer

from torchpilot.logging.message_hub import MessageHub
from torchpilot.logging.message_hub import UploadErrorListener
from torchpilot.model.task.tp_task_flow import TPTaskFlow
from torchpilot.optimizer.base_lr_scheduler import BaseLrScheduler
from torchpilot.optimizer.base_optimizer import build_optimizer
from torchpilot.runner.trainer.base_trainer import BaseTrainer
from torchpilot.runner.trainer.grad_scaler import build_grad_scaler
from torchpilot.utils import constants
from torchpilot.utils.cfg_parser import PyConfig
from torchpilot.utils.checkpoint_manager import CheckpointManager
from torchpilot.utils.config_manager import git_diff_and_patch
from torchpilot.utils.config_manager import merge_json
from torchpilot.utils.config_manager import run_with_merge_json
from torchpilot.utils.experiment_manage import DEFAULT_SCHEME_ID
from torchpilot.utils.experiment_manage import experiment_manage_submit_task
from torchpilot.utils.file_manager import FileManager
from torchpilot.utils.misc import convert_to_seconds
from torchpilot.utils.misc import is_torch_2_or_later
from torchpilot.utils.registries import DATALOADER
from torchpilot.utils.registries import LR_SCHEDULER
from torchpilot.utils.registries import TASK_FLOW
from torchpilot.utils.settings import eval_in_train
from torchpilot.utils.settings import global_settings
from torchpilot.utils.settings import settings
from torchpilot.utils.stopwatch import stopwatch
from torchpilot.utils.tensorboard_manager import TensorboardManager
from torchpilot.utils.tensorboard_manager import tensorboard_trace_handler


# from torch.profiler import tensorboard_trace_handler

# pylint: disable=broad-except,too-many-nested-blocks,logging-fstring-interpolation
# pylint: disable=too-many-instance-attributes,too-many-branches,ungrouped-imports
# pylint: disable=import-error,no-name-in-module,use-a-generator,no-self-use
# pylint: disable=too-many-branches,too-many-statements,unused-argument
# pylint: disable=protected-access.

if is_torch_2_or_later():
    from torch.distributed.fsdp.fully_sharded_data_parallel import FullStateDictConfig
    from torch.distributed.fsdp.fully_sharded_data_parallel import (
        FullyShardedDataParallel,
    )
    from torch.distributed.fsdp.fully_sharded_data_parallel import StateDictType


logger = logging.getLogger(__name__)


class TPTrainer(BaseTrainer):
    """TPTrainer provides based training workflow.

    Args:
        MONITOR_URLsg_path is experiment config file path.
        run_name (str): run_name is tag of experiment, that is used to distinguish
            different experiments.
        resume (bool, optional): Experiments run name. Default=`False`.
        total_epochs (int, optional): Training epochs. Default=`1`.
        print_freq_by_step (int, optional): Print frequency. Default=`20`.
        save_ckpt_freq_by_epoch (int, optional): Save checkpoint frequency of epoch.
            Default=`None`.
        save_ckpt_freq_by_step (int, optional): Save checkpoint frequency of step.
            Default=`None`.
        enable_sync_loss (bool, optional): Whether to use sync loss. Note: Using rank0
            loss if this set to false. Default=`True`.
        ues_fp16 (bool, optional): Whether to enable fp16 forward. Default=`False`.
        use_bf16 (bool, optional): Whether to enable bf16 forward. Default=`False`.
        use_sync_bn (bool, optional): Whether to use sync bn. Note: disable could
            accelerate, but may cost reduce the accuracy. Default=`False`.
        clip_gradient (int, optional): If gradient value bigger than clip_gradient, clip
            to `clip_gradient`. Default=`35`.
        lr_per_sample (int, optional): Learning rate per sample. Default=`1e-4`.
        use_deterministic (bool, optional): Whether to enable deterministic algorithms
            of pytorch. Default=`False`.
        use_profiler (bool): Whether to enable torch profiler tool, the output will
            save into output/exp_xxx/your_experiments_name/export. Default=`False`.
        use_tensorboard (bool): Whether to enable tensorboard, the output will
            save into output/exp_xxx/your_experiments_name/summary. Default=`False`.
        use_grad_none (bool): Whether to set None in optimizer.zero_grad() and
            model.zero_grad(). Default=`False`.
        use_model_channel_last (bool): Whether to enable channel last in model.
            This trick will make full use of TensorCore. It is worth noting
            that operators need to be supported. Default=`False`.
        use_powersgd (bool): Whether to use PowerSGD Gradient Compression.
            https://pytorch.org/docs/stable/ddp_comm_hooks.html. Default=`False`.
        use_cudnn_benchmark (bool): Whether to use cudnn benchmark accelerate pipeline.
            Default=`False`.
        use_data_stream (bool): Whether to use data stream to asynchronous Memcpy(H2D).
        grad_accumulate_step (bool): Set gradient accumulate's step times. Default=1.
        amp_scaler_params (dict): The params of AutoMixedPrecision grad scaler.
            https://pytorch.org/docs/stable/amp.html#torch.cuda.amp.GradScaler.
        ddp_params (dict): The params of DistributedDataParallel.
            https://pytorch.org/docs/1.9.0/_modules/torch/nn/parallel/distributed.html
        seed (int, optional): Seed for deterministic. Default=`666`.
        log_precision (int, optional): Decimal precision. Default=`4`.
        pure_dataloading (bool): Whether to use pure dataloading. If `True`,
            just loading data without training model. Use pure dtaloading and pure model
            at the same time is not allowed. Default=`False`.
        pure_model (bool): Whether to use pure model. If `True`, training model
            with a fixed batch data.  Use pure dtaloading and pure model at the same
            time is not allowed. Default=`False`.
        skip_exception (bool): Whether to skip exception. If `True`, continue next step
            training if occurs error, else abort training. Default=`False`.
        profile_mode (Union[bool, Dict[str, Any]): Whether to enable profile mode.
            If `True`, only train 1000 steps and do not save checkpoint. If Dict type,
            can set train step by 1. `total_epochs` and`one_epoch_size`, or
            2.`total_samples`, or 3.`total_steps`; can set "enable_save_ckpt".
            Default=`False`.
    """

    # pylint: disable=too-many-arguments,too-many-statements，too-many-locals
    def __init__(
        self,
        cfg: PyConfig,
        run_name: str,
        resume: bool = False,
        total_epochs: int = 1,
        print_freq_by_step: int = 20,
        save_ckpt_freq_by_epoch: Optional[int] = None,
        save_ckpt_freq_by_step: Optional[int] = None,
        max_save_ckpt_num: Optional[int] = None,
        enable_sync_loss: bool = True,
        use_fp16: bool = False,
        use_bf16: bool = False,
        use_sync_bn: bool = False,
        clip_gradient: int = 35,
        lr_per_sample: float = 1e-3,
        use_deterministic: bool = False,
        use_profiler: bool = False,
        use_tensorboard: bool = False,
        use_grad_none: bool = False,
        use_model_channel_last: bool = False,
        use_powersgd: bool = False,
        use_cudnn_benchmark: bool = False,
        use_data_stream: bool = False,
        use_unsupervised_hook: bool = False,
        multi_step_training: bool = False,
        grad_accumulate_step: int = 1,
        amp_scaler_params: Dict = None,
        ddp_params: Dict = None,
        seed: int = constants.seed,
        log_precision: int = 4,
        pure_dataloading: bool = False,
        pure_model: bool = False,
        skip_exception: bool = False,
        profile_mode: Union[bool, Dict[str, Any]] = False,
        fsdp: bool = False,
        max_iters: Optional[int] = None,
        rl_training: bool = False,
        rl_update_epochs: int = 1,
        enable_eval: bool = False,
    ) -> None:
        """Init BaseTrainer based config dict."""
        super().__init__(cfg)
        torch.cuda.empty_cache()

        self._run_name = run_name
        self._resume = resume
        self._func_hook_list: dict = {}
        # enable eval
        self._enable_eval = enable_eval

        # init trainer paramters
        self._total_epochs = total_epochs
        self._epoch_idx = 0
        self._start_epoch = 0
        self._one_epoch_size = 1
        self._step_idx = 0
        self._start_step = 0
        self._time_anchor = 0.0
        self._max_iters = max_iters
        self._global_step = 0
        self._rl_training = rl_training
        self._rl_update_epochs = rl_update_epochs
        self._pure_dataloading = pure_dataloading
        self._pure_model = pure_model
        self._profile_mode = profile_mode
        self._enable_save_ckpt = True
        self._total_steps = 0
        self._batch_data: Optional[Dict[str, Any]] = None
        if self._pure_dataloading and self._pure_model:
            raise ValueError(
                "pure_dataloading and pure_model can't be `true` at the same time."
            )

        # placeholders mostly for logging.
        self._log_vars: OrderedDict[Any, Any] = OrderedDict()
        self._extra_summary: OrderedDict[Any, Any] = OrderedDict()

        self._print_freq_by_step = print_freq_by_step
        self._save_ckpt_freq_by_epoch = save_ckpt_freq_by_epoch
        self._save_ckpt_freq_by_step = save_ckpt_freq_by_step
        self._max_save_ckpt_num = max_save_ckpt_num
        if (
            self._save_ckpt_freq_by_epoch is None
            and self._save_ckpt_freq_by_step is None
        ):
            raise ValueError(
                "you must set save_ckpt_freq_by_epoch or save_ckpt_freq_by_step!!!"
            )
        if self._save_ckpt_freq_by_epoch is not None:
            self._save_ckpt_freq_by_step = None

        self._use_sync_bn = use_sync_bn
        self._enable_sync_loss = enable_sync_loss
        if enable_sync_loss:
            logger.warning("Enable sync loss to log.")
        else:
            logger.warning(
                "Disable sync loss to log. This will acclerate train_parse_loss."
            )
        self._clip_gradient = clip_gradient
        self._lr_per_sample = lr_per_sample

        self._rank = dist.get_rank()
        self._gpu_num = dist.get_world_size()
        self._total_norm: torch.Tensor = torch.Tensor([0.0])
        self._best_eval = 0
        self._log_prec = log_precision
        # enable enable_deterministic
        self._seed = seed
        self._use_deterministic = use_deterministic
        # enable torch profiler
        self._use_profiler = use_profiler
        if self._use_profiler:
            self._total_epochs = 1
            self._profiler_handler = None
        # enable tensorboard
        self._use_tensorboard = use_tensorboard
        if self._use_tensorboard:
            self._summary = TensorboardManager(
                log_dir=os.path.join(
                    FileManager.get_summary_dir(), f"rank{self._rank}"
                ),
                comment=self._run_name,
                rank=self._rank,
            )
        # will grad set as None
        self._use_grad_none = use_grad_none
        # enable model channel last
        self._use_model_channel_last = use_model_channel_last
        # enable powersgd
        self._use_powersgd = use_powersgd
        # enable CUDNN benchmark
        self._use_cudnn_benchmark = use_cudnn_benchmark
        # enable multi step training
        self._multi_step_training = multi_step_training
        # enable teacher model momentum and temp
        self._use_unsupervised_hook = use_unsupervised_hook
        # check gradient accumulate step
        self._gradient_accumulate_step = grad_accumulate_step
        if self._gradient_accumulate_step < 1:
            raise ValueError("grad_accumulate_step must be >=1 ")
        logger.warning(
            "=====> Use Gradient Accumulate Step: %d <======",
            self._gradient_accumulate_step,
        )

        # check ddp_params
        self._ddp_params = ddp_params
        self._ddp_static_graph = False

        # check fsdp
        self._fsdp = fsdp

        # check mixed precision
        self._use_fp16 = use_fp16
        self._use_bf16 = use_bf16
        if self._use_fp16 and self._use_bf16:
            raise ValueError("use_fp16 and use_bf16 can't be `true` at the same time.")
        self._use_amp = self._use_fp16 or self._use_bf16
        self._amp_dtype = None
        if self._use_fp16:
            self._amp_dtype = torch.float16
        if self._use_bf16:
            self._amp_dtype = torch.bfloat16
        self._use_grad_scaler = self._use_amp or self._fsdp
        self._scaler: Optional[torch.cuda.amp.GradScaler] = None
        self._amp_scaler_params = amp_scaler_params or {}

        # enable data stream
        self._use_data_stream = use_data_stream
        if self._use_data_stream:
            self._device: Any = None
            self._data_stream: Optional[torch.cuda.Stream] = None
            self._wrap_dataloader: Any = None
            self._first: bool = True
            self._next_data: Any = None

        self.enable_deterministic()

        # Init Trainer Control Params
        self._build_dataloader()
        self._build_taskflow()
        self._build_ckpt_manager_and_load_model()
        self._build_optimizer()
        self._warp_taskflow_to_ddp_model()
        self._build_performance_components()
        self._build_lr_scheduler()
        self._ckpt_manager._optimizer = self._optimizer
        self._ckpt_manager._lr_scheduler = self._lr_scheduler
        self._ckpt_manager._scaler = self._scaler
        self._ckpt_manager._model = self._model
        self.check_resume_states()

        # Create stopwatch
        self._stopwatch = stopwatch
        self._skip_exception = skip_exception
        self._train_success = False
        if self._dataloader.record_worker_log:
            self.init_error_callback()
        else:
            self.msghub = None

        class_list = [
            self.__class__,
            self._lr_scheduler,
            self._optimizer,
            self._model,
            self._dataloader,
        ]
        run_with_merge_json(
            merge_json,
            300,
            self._rank,
            class_list,
            self._cfg._cfg_dict,
            FileManager.get_run_dir(),
        )
        git_diff_and_patch(FileManager.get_run_dir(), self._rank)

    def init_error_callback(
        self,
    ):
        """Init error callback."""
        self.msghub = MessageHub.get_current_instance()
        main_instance = self
        dynamic_listener = type(
            "ErrorHandler",
            (UploadErrorListener,),
            {
                "on_upload_error": lambda self, err_type: main_instance.upload_errors(
                    err_type
                )
            },
        )
        self.msghub.set_upload_error_listener(dynamic_listener())

    def enable_deterministic(self) -> None:
        """Enable system deterministic."""
        torch.use_deterministic_algorithms(self._use_deterministic)
        random.seed(self._seed)
        np.random.seed(self._seed)
        torch.manual_seed(self._seed)
        torch.cuda.manual_seed(self._seed)

    def _build_dataloader(self) -> None:
        """Build dataloader."""
        self._dataloader = DATALOADER.build(self._cfg.dataloader)
        self._sample_num_per_gpu = self._dataloader.get_sample_num_per_gpu()
        self._sample_per_epoch = self._dataloader.get_sample_per_epoch()
        self._one_epoch_size = self._dataloader.get_one_epoch_step_per_gpu()

        # 当设置了max_iters时，将total_epochs设为1，total_steps设为max_iters
        if self._max_iters is not None:
            self._total_epochs = 1
            self._total_steps = self._max_iters
            self._one_epoch_size = self._max_iters
        else:
            self._total_steps = self._total_epochs * self._one_epoch_size
        logger.warning(
            "Set max_iters, total_epochs: %d, total_steps: %d, one_epoch_size: %d",
            self._total_epochs,
            self._total_steps,
            self._one_epoch_size,
        )

        self._bs_per_gpu = self._dataloader.get_batch_size_per_gpu()

    def _build_taskflow(self) -> None:
        """Build taskflow."""
        self._model = TASK_FLOW.build(self._cfg.task_flow)
        if not isinstance(self._model, TPTaskFlow):
            raise ValueError(
                f"Expect type(self._model)=TPTaskFlow, but got {type(self._model)}."
            )

    def _build_optimizer(self) -> None:
        """Build optimizer."""
        model_params_policy = self._model.get_optim_policies()
        self._cfg.optimizer.params_policy = model_params_policy
        self._cfg.optimizer.lr = self._lr_per_sample * self._gpu_num * self._bs_per_gpu
        self._optimizer = build_optimizer(**(self._cfg.optimizer))
        if not isinstance(self._optimizer, Optimizer):
            raise ValueError(
                f"Expect type(self._optimizer)=Optimizer, "
                f"but got {type(self._optimizer)}."
            )

        for group in model_params_policy:
            logger.info(
                "group: %s has %d params, lr_mult: %f, decay_mult: %f.",
                group["name"],
                len(group["params"]),
                group["lr_mult"],
                group["decay_mult"],
            )

    def _warp_taskflow_to_ddp_model(self) -> None:  # pylint: disable=too-many-branches
        """Warp taskflow to ddp model."""
        # Record gpu memory from now
        if self._use_profiler and version.parse(torch.__version__) >= version.parse(
            "2.0"
        ):
            torch.cuda.memory._record_memory_history()  # pylint: disable=protected-access # noqa: E501
        # Parallel Model
        gpus_cur_machine = torch.cuda.device_count()
        device_ids = list(range(0, gpus_cur_machine))
        logger.info(
            "[%s] rank = %d, world_size = %d, n = %d, device_ids = %s.",
            os.getpid(),
            dist.get_rank(),
            dist.get_world_size(),
            gpus_cur_machine,
            str(device_ids),
        )
        cur_device = torch.cuda.current_device()
        self._model = self._model.cuda(device=cur_device)

        # enable model channel last
        if self._use_model_channel_last:
            self._model = self._model.to(memory_format=torch.channels_last)

        if self._use_sync_bn:
            # optim sync_bn
            group_size = 8
            if group_size > dist.get_world_size():
                group_size = dist.get_world_size()
            num_groups = dist.get_world_size() // group_size

            global_process_groups = []
            for j in range(num_groups):
                start_id = j * group_size
                group_ids = []
                for i in range(group_size):
                    group_ids.append(start_id + i)
                global_process_groups.append(
                    dist.new_group(ranks=group_ids, backend="nccl")
                )
            self._model = torch.nn.SyncBatchNorm.convert_sync_batchnorm(
                self._model, global_process_groups[dist.get_rank() // group_size]
            )

        actual_ddp_params = {}
        if self._ddp_params is not None:
            if "bucket_cap_mb" in self._ddp_params:
                actual_ddp_params["bucket_cap_mb"] = self._ddp_params["bucket_cap_mb"]
            if "find_unused_parameters" in self._ddp_params:
                actual_ddp_params["find_unused_parameters"] = self._ddp_params[
                    "find_unused_parameters"
                ]
            if "gradient_as_bucket_view" in self._ddp_params:
                actual_ddp_params["gradient_as_bucket_view"] = self._ddp_params[
                    "gradient_as_bucket_view"
                ]
            if "static_graph" in self._ddp_params:
                self._ddp_static_graph = self._ddp_params["static_graph"]
            logger.warning("You set ddp_params as %s", actual_ddp_params)

        model_stream = torch.cuda.Stream(cur_device)
        model_stream.wait_stream(torch.cuda.current_stream(cur_device))
        if not self._fsdp:
            with torch.cuda.stream(model_stream):
                self._model = torch.nn.parallel.DistributedDataParallel(
                    module=self._model,
                    device_ids=[cur_device],
                    output_device=cur_device,
                    **actual_ddp_params,
                )
        else:
            # the fsdp wrapper needs to be implemented in task flow
            self._model.warpper_model_for_fsdp_training()

        logger.info("Model: \n%s", self._model)
        torch.cuda.current_stream(cur_device).wait_stream(model_stream)
        # NOTE: Set static graph explicitly to be compatible with PyTorch before 1.11.
        if not self._fsdp and self._ddp_static_graph:
            self._model._set_static_graph()  # pylint: disable=protected-access

    def _build_performance_components(self) -> None:
        """Build performance components."""
        # Powersgd.
        if self._use_powersgd:
            process_group = dist.new_group(ranks=None, backend="nccl")
            self._model.register_comm_hook(
                PowerSGDState(process_group=process_group, matrix_approximation_rank=1),
                batched_powerSGD_hook,
            )
            logger.warning("=> Will use PowerSGD Gradient Compression.")

        # Enable GradScaler.
        if self._use_grad_scaler:
            scaler_type = self._amp_scaler_params.get("scaler_type", None)

            if scaler_type is None:
                if self._use_fp16:
                    scaler_type = "GradScaler"
                elif self._use_bf16:
                    scaler_type = "FixedGradScaler"
                elif self._fsdp:
                    scaler_type = "ShardedGradScaler"
            logger.warning("Use %s as gradient scaler", scaler_type)

            # Filter relevant scaler parameters.
            relevant_params = [
                "init_scale",
                "growth_factor",
                "backoff_factor",
                "growth_interval",
            ]
            actual_amp_scaler_params = {
                key: self._amp_scaler_params[key]
                for key in relevant_params
                if key in self._amp_scaler_params
            }

            actual_amp_scaler_params["enabled"] = self._use_grad_scaler
            logger.warning("You set amp_scaler_params as %s", actual_amp_scaler_params)

            self._scaler = build_grad_scaler(scaler_type, actual_amp_scaler_params)

    def _build_lr_scheduler(self) -> None:
        """Build lr scheduler."""
        self._cfg.lr_scheduler.optimizer = self._optimizer
        self._lr_scheduler = LR_SCHEDULER.build(self._cfg.lr_scheduler)
        if not isinstance(self._lr_scheduler, BaseLrScheduler):
            raise ValueError(
                f"Expect type(self._lr_scheduler)=BaseLrScheduler, "
                f"but got {type(self._lr_scheduler)}."
            )

    def _build_ckpt_manager_and_load_model(self) -> None:
        """Build ckpt manager."""
        ckpt_cfg = self._cfg.ckpt
        ckpt_cfg.update(
            dict(
                model=self._model,
                optimizer=None,
                lr_scheduler=None,
                scaler=None,
                save_dir=FileManager.get_ckpt_dir(),
                resume=self._resume,
                fsdp=self._fsdp,
            )
        )
        self._ckpt_manager = CheckpointManager(**ckpt_cfg)

        self._ckpt_manager.load_model()

    def check_resume_states(self) -> None:
        """Auto load ckpt."""
        self._ckpt_manager.load_lr_scheduler()
        self._ckpt_manager.load_optimizer()
        self._ckpt_manager.load_scaler()
        self._start_epoch = self._ckpt_manager.load_epoch()
        self._start_step = self._ckpt_manager.load_step()
        self._step_idx = self._start_step
        if self._max_iters is not None:
            self._global_step = self._start_step
        else:
            self._global_step = (
                self._start_step + self._start_epoch * self._one_epoch_size
            )
        logger.warning(
            "==> Rank %d, Starting Training Epoch %d Step %d.",
            self._rank,
            self._start_epoch,
            self._start_step,
        )

    def log_cuda_events(self):
        """Log mfu."""
        # Log total info.
        logger.warning(
            self._profiler_handler.key_averages(group_by_stack_n=5).table(
                sort_by="self_cuda_time_total"
            )
        )

        # Get all cuda events.
        events = self._profiler_handler.events()
        cpu_events_id_dict = {}
        cuda_events = []
        for event in events:
            if "CUDA" in str(event.device_type):
                cuda_events.append(event)
            else:
                if event.id in cpu_events_id_dict:
                    logger.warning(
                        "Event id conflicts, %s %s",
                        cpu_events_id_dict[event.id],
                        event,
                    )
                cpu_events_id_dict[event.id] = event

        # 使用字典来按操作符名称分组统计每个操作符的总CUDA时间
        op_to_total_cuda_time = defaultdict(dict)

        for event in cuda_events:
            op_name = (
                cpu_events_id_dict[event.id].cpu_parent.name
                if event.id in cpu_events_id_dict
                and cpu_events_id_dict[event.id].cpu_parent is not None
                else event.name.split("<")[0]
            )
            timestamp_s = convert_to_seconds(event.self_cuda_time_total_str)
            duration = float(timestamp_s[:-1])  # 去掉字符串末尾的 's'

            # 更新操作符的总CUDA时间
            if op_name in op_to_total_cuda_time:
                op_to_total_cuda_time[op_name]["duration"] += duration
                op_to_total_cuda_time[op_name]["count"] += 1
            else:
                op_to_total_cuda_time[op_name]["duration"] = duration
                op_to_total_cuda_time[op_name]["count"] = 1

        # 计算所有操作符的总CUDA时间
        total_cuda_ts = sum(  # pylint: disable=consider-using-generator
            [item["duration"] for item in op_to_total_cuda_time.values()]
        )

        # 对操作符按照CUDA时间从大到小排序
        sorted_ops = sorted(
            op_to_total_cuda_time.items(),
            key=lambda item: item[1]["duration"],
            reverse=True,
        )

        # Log info.
        table = PrettyTable()
        table.field_names = [
            "Op name",
            "Total CUDA Time (s)",
            "Total Percentage (%)",
            "Count",
            "Avg CUDA Time (s)",
        ]
        table.align["Total CUDA Time (s)"] = "r"
        table.align["Total Percentage (%)"] = "r"
        table.align["Count"] = "r"
        table.align["Avg CUDA Time (s)"] = "r"
        table.add_row(
            [
                "Total",
                f"{total_cuda_ts:.6f}",
                "100.00",
                "1",
                f"{total_cuda_ts:.6f}",
            ]
        )

        # 计算算子之和
        dense_computation_op_timecost_sum = 0.0
        sparse_computation_op_timecost_sum = 0.0
        dense_computation_op_flag_list = [
            "mm",
            "flash",
        ]
        sparse_computation_op_flag_list = [
            "vectorized_elementwise",
            "unrolled_elementwise",
        ]

        # 打印每个操作符的总CUDA时间和占比
        for op_name, value_dict in sorted_ops:
            total_time = value_dict["duration"]
            avg_time = total_time / value_dict["count"]  # 计算平均时间
            percentage = (total_time / total_cuda_ts) * 100  # 计算占比

            # 如果操作名中包含 'mm' 或 'flash' 字段，累加到计算操作符的总时间消耗中
            if any(
                [
                    True
                    for computation_op_flag in dense_computation_op_flag_list
                    if computation_op_flag in op_name
                ]
            ):
                dense_computation_op_timecost_sum += total_time
            if any(
                [
                    True
                    for computation_op_flag in sparse_computation_op_flag_list
                    if computation_op_flag in op_name
                ]
            ):
                sparse_computation_op_timecost_sum += total_time

            # 将数据添加到表格中
            table.add_row(
                [
                    op_name[:100],
                    f"{total_time:.6f}",
                    f"{percentage:.2f}",
                    f"{value_dict['count']}",
                    f"{avg_time:.6f}",
                ]
            )
        logger.warning("\n%s", table.get_string())
        logger.warning(
            "定义 dense 计算算子为 op name 中包含以下任意字段 %s",
            str(dense_computation_op_flag_list),
        )
        logger.warning(
            "统计得到 dense 计算算子耗时占比 %s",
            f"{dense_computation_op_timecost_sum / total_cuda_ts * 100:.2f}%",
        )
        logger.warning(
            "定义 sparse 计算算子为 op name 中包含以下任意字段 %s",
            str(sparse_computation_op_flag_list),
        )
        logger.warning(
            "统计得到 sparse 计算算子耗时占比 %s",
            f"{sparse_computation_op_timecost_sum / total_cuda_ts * 100:.2f}%",
        )

    def train(self) -> None:  # pylint: disable=too-many-branches
        """Training Process."""

        class WrapDataLoader:  # pylint: disable=too-few-public-methods
            """Wrap Data Loader."""

            def __init__(self, dataloader, stream):
                """Init."""
                self.stream = stream
                self.dataloader = dataloader

            def next(self):
                """Return next data."""
                with torch.cuda.stream(self.stream):
                    batch_data = self.dataloader.get_batch_data()
                return batch_data

        if self._use_data_stream:
            self._device = torch.cuda.current_device()
            self._data_stream = torch.cuda.Stream(self._device)
            self._wrap_dataloader = WrapDataLoader(self._dataloader, self._data_stream)

        self._time_anchor = time.time()
        try:
            torch.backends.cudnn.benchmark = self._use_cudnn_benchmark
            self._lr_scheduler.init_base_lr()
            self._model.train()

            if self._profile_mode:  # True or has value
                if isinstance(self._profile_mode, bool):
                    self._enable_save_ckpt = False
                    self._total_epochs = 1
                    self._one_epoch_size = min(self._one_epoch_size, 1000)
                    self._total_steps = self._total_epochs * self._one_epoch_size

                if isinstance(self._profile_mode, Dict):
                    self._enable_save_ckpt = self._profile_mode.get(
                        "enable_save_ckpt", False
                    )
                    if (
                        "total_epochs" in self._profile_mode
                        and "one_epoch_size" in self._profile_mode
                    ):
                        self._total_epochs = self._profile_mode["total_epochs"]
                        self._one_epoch_size = self._profile_mode["one_epoch_size"]
                        self._total_steps = self._total_epochs * self._one_epoch_size
                    elif "total_steps" in self._profile_mode:
                        self._total_steps = self._profile_mode["total_steps"]
                        self._total_epochs = math.ceil(
                            self._total_steps / self._one_epoch_size
                        )
                        self._one_epoch_size = min(
                            self._one_epoch_size, self._total_steps
                        )
                    elif "total_samples" in self._profile_mode:
                        world_size = dist.get_world_size() if dist.is_available() else 1
                        one_step_samples = self._bs_per_gpu * world_size
                        self._total_steps = math.ceil(
                            self._profile_mode["total_samples"] / one_step_samples
                        )
                        self._total_epochs = math.ceil(
                            self._total_steps / self._one_epoch_size
                        )
                        self._one_epoch_size = min(
                            self._one_epoch_size, self._total_steps
                        )
                    else:
                        raise NotImplementedError("profile_mode not supported")

                logger.warning(
                    "Use profile mode, total_epochs: %d, one_epoch_size: %d, total_steps: %d",  # pylint: disable=line-too-long # noqa: E501
                    self._total_epochs,
                    self._one_epoch_size,
                    self._total_steps,
                )

            for self._epoch_idx in range(self._start_epoch, self._total_epochs):
                if "custom_indices_generator" in self._func_hook_list:
                    indices = self._func_hook_list["custom_indices_generator"]()
                else:
                    indices = None

                # Set state to ensure data indices different at each epoch.
                self._dataloader.set_state(
                    epoch=self._epoch_idx, step=self._step_idx, indices=indices
                )
                if self._use_profiler:
                    with torch.profiler.profile(
                        activities=[
                            torch.profiler.ProfilerActivity.CPU,
                            torch.profiler.ProfilerActivity.CUDA,
                        ],
                        schedule=torch.profiler.schedule(
                            wait=2,  # for init memroy usage profile , set 0
                            warmup=2,  # for init memroy usage profile , set 0
                            active=5,
                        ),
                        on_trace_ready=tensorboard_trace_handler(
                            os.path.join(FileManager.get_export_dir(), "profiler"),
                            worker_name=f"worker_{self._rank}",
                            use_gzip=True,
                        ),
                        record_shapes=True,
                        profile_memory=True,
                        with_stack=True,
                        with_flops=True,
                    ) as self._profiler_handler:
                        self._one_epoch_size = 10
                        self.train_one_epoch(self._epoch_idx)

                        # Dump pickle.
                        try:
                            torch.cuda.memory._dump_snapshot(  # pylint: disable=protected-access # noqa: E501
                                os.path.join(
                                    FileManager.get_export_dir(),
                                    "profiler",
                                    "mem_snapshot.pickle",
                                )
                            )
                            # Stop recording memory snapshot history
                            if version.parse(torch.__version__) >= version.parse("2.0"):
                                torch.cuda.memory._record_memory_history(  # pylint: disable=protected-access # noqa: E501
                                    enabled=None
                                )
                        except Exception as err:  # pylint: disable=broad-except
                            logger.warning(  # noqa: G200
                                "%s _dump_snapshot is suported in > torch2.x",
                                str(err),
                            )

                        self.log_cuda_events()
                else:
                    self.train_one_epoch(self._epoch_idx)
                if self._save_ckpt_freq_by_epoch is not None and self._enable_save_ckpt:
                    save_by_freq = self._epoch_idx % self._save_ckpt_freq_by_epoch == 0
                    if self._fsdp:
                        with FullyShardedDataParallel.state_dict_type(
                            self._model,
                            StateDictType.FULL_STATE_DICT,
                            FullStateDictConfig(offload_to_cpu=True, rank0_only=True),
                        ):
                            self._ckpt_manager.save_checkpoint(
                                epoch=self._epoch_idx + 1,
                                step=self._step_idx,
                                max_save_ckpt_num=self._max_save_ckpt_num,
                                save_by_freq=save_by_freq,
                            )
                    else:
                        self._ckpt_manager.save_checkpoint(
                            epoch=self._epoch_idx + 1,
                            step=self._step_idx,
                            max_save_ckpt_num=self._max_save_ckpt_num,
                            save_by_freq=save_by_freq,
                        )
            self._train_success = True
            # save last epoch ckpt when needed.
            if (
                self._save_ckpt_freq_by_epoch is not None
                and self._epoch_idx % self._save_ckpt_freq_by_epoch != 0
                and self._enable_save_ckpt
            ):
                if self._fsdp:
                    with FullyShardedDataParallel.state_dict_type(
                        self._model,
                        StateDictType.FULL_STATE_DICT,
                        FullStateDictConfig(offload_to_cpu=True, rank0_only=True),
                    ):
                        self._ckpt_manager.save_checkpoint(
                            epoch=self._epoch_idx + 1,
                            step=self._step_idx,
                        )
                else:
                    self._ckpt_manager.save_checkpoint(
                        epoch=self._epoch_idx + 1,
                        step=self._step_idx,
                    )

            # close tensorboard
            if self._use_tensorboard:
                self._summary.close()

        except Exception as ex:  # pylint: disable=broad-except
            dist.barrier()
            ex_message = ex.args[0] if len(ex.args) > 0 else ""
            logger.error(
                "Training occurs error, aborting this experiments. Will save all state "
                "info...{%s}",
                ex_message,
            )
            # save loader state
            if self._fsdp:
                with FullyShardedDataParallel.state_dict_type(
                    self._model,
                    StateDictType.FULL_STATE_DICT,
                    FullStateDictConfig(offload_to_cpu=True, rank0_only=True),
                ):
                    self._ckpt_manager.save_checkpoint(
                        epoch=self._epoch_idx,
                        step=self._step_idx,
                    )
            else:
                self._ckpt_manager.save_checkpoint(
                    epoch=self._epoch_idx,
                    step=self._step_idx,
                )
            # close tensorboard
            if self._use_tensorboard:
                self._summary.close()

            raise ex

        finally:
            # release all resources
            self._dataloader.release_all()
            if self.msghub is not None:
                # update status
                if dist.get_rank() == 0:
                    self.upload_training_progress(
                        epoch=self._epoch_idx, step=self._step_idx, status="finished"
                    )
                self.upload_errors()

    def train_one_epoch(
        self,
        epoch: int,
    ) -> None:
        """One epoch training.

        Args:
            epoch (int): Current epoch.
        """
        if epoch > 0 and epoch == self._total_epochs - 1:  # last epoch
            cur_epoch_end_step = self._total_steps - epoch * self._one_epoch_size
        else:
            cur_epoch_end_step = self._one_epoch_size
        for self._step_idx in range(self._start_step, cur_epoch_end_step):
            # if self.skip_exception, skip this one step when occuring error,
            # else raise error and aborting this experiments
            try:
                self._stopwatch.tic("one_step_cost")
                if self._rl_training:
                    outputs = self.train_one_step_rl(epoch, self._step_idx)
                else:
                    outputs = self.train_one_step(epoch, self._step_idx)
                self._stopwatch.record_time_cost("one_step_cost", None)
                self._stopwatch.sync_for_cur_iter_and_prepare_for_next_iter()

            except Exception as ex:  # pylint: disable=broad-except
                logger.exception("Found error in step %d", self._step_idx)
                if not self._skip_exception:
                    raise ex
            else:
                # rely on outputs
                if "custom_sampler_indices" in self._func_hook_list:
                    indices = self._func_hook_list["custom_sampler_indices"](
                        self._log_vars, outputs
                    )
                    self._dataloader.set_state(
                        epoch=epoch, step=self._step_idx, indices=indices
                    )

            if self.msghub is not None:
                if len(self.msghub.get_read_cache_errors()) > self.msghub.tgt_err_num:
                    self._skip_exception = True
                    self.upload_errors(type_="read-cache-op")
                    raise Exception(
                        "read cache op error exceeds thresholds(default=woker_num*100"
                    )

            if self._use_profiler:
                self._profiler_handler.step()  # type: ignore[attr-defined]

            if self._step_idx % self._print_freq_by_step == 0:
                logger.info(self)  # see more details at `self.__str__()`.
                self._stopwatch.reset()
                if dist.get_rank() == 0:
                    self.upload_training_progress(epoch, self._step_idx)

            if (
                self._save_ckpt_freq_by_step is not None
                and self._step_idx % self._save_ckpt_freq_by_step == 0
                and self._enable_save_ckpt
            ):
                if self._fsdp:
                    with FullyShardedDataParallel.state_dict_type(
                        self._model,
                        StateDictType.FULL_STATE_DICT,
                        FullStateDictConfig(offload_to_cpu=True, rank0_only=True),
                    ):
                        self._ckpt_manager.save_checkpoint(
                            epoch=epoch,
                            step=self._step_idx + 1,
                            max_save_ckpt_num=self._max_save_ckpt_num,
                            save_by_freq=True,
                        )
                else:
                    self._ckpt_manager.save_checkpoint(
                        epoch=epoch,
                        step=self._step_idx + 1,
                        max_save_ckpt_num=self._max_save_ckpt_num,
                        save_by_freq=True,
                    )

                if self._enable_eval:
                    if (not dist.is_initialized()) or dist.get_rank() == 0:
                        if (
                            not eval_in_train.token
                            or not eval_in_train.cfg
                            or not self._ckpt_manager._save_dir
                        ):
                            logger.error("Miss needed value")
                        else:
                            _step = self._step_idx + 1
                            epoch_or_step = f"epoch{epoch:0>3}_step{_step:0>4}"
                            ckpt_file_path = os.path.join(
                                self._ckpt_manager._save_dir,
                                f"checkpoint_{epoch_or_step}.pth.tar",
                            )
                            _cmd = (
                                f"bash run.sh 1 {eval_in_train.cfg} -it torch "
                                + f"--ckpt  {ckpt_file_path} -n "
                                + os.path.basename(FileManager.get_run_dir())
                                + f"_{epoch_or_step}"
                            )
                            experiment_manage_submit_task(
                                DEFAULT_SCHEME_ID,
                                nurss_token={
                                    "user": os.environ.get("USER"),
                                    "token": eval_in_train.token,
                                },
                                resource={
                                    "cmd": _cmd,
                                    "working_dir": os.getcwd(),
                                },
                                task_name="eval in train for "
                                + os.path.basename(FileManager.get_run_dir()),
                                label=["eval_in_train"],
                            )

            self._global_step += 1

        # save last step ckpt
        if self._fsdp:
            with FullyShardedDataParallel.state_dict_type(
                self._model,
                StateDictType.FULL_STATE_DICT,
                FullStateDictConfig(offload_to_cpu=True, rank0_only=True),
            ):
                self._ckpt_manager.save_checkpoint(
                    epoch=self._epoch_idx + 1,
                    step=self._step_idx,
                )
        else:
            self._ckpt_manager.save_checkpoint(
                epoch=self._epoch_idx + 1,
                step=self._step_idx,
            )

        if self._step_idx % self._print_freq_by_step != 0:
            logger.info(self)
            self._stopwatch.reset()

        # reset start_step
        self._start_step = 0
        self._step_idx = 0

    def get_batch_data(self) -> Dict[str, Any]:
        """Get batch data.

        Returns:
            One batch data (Dict[str, Any]).
        """
        if self._use_data_stream:
            torch.cuda.current_stream(self._device).wait_stream(self._data_stream)
            if self._first:
                batch_data = self._wrap_dataloader.next()
                self._next_data = self._wrap_dataloader.next()
                self._first = False
            else:
                batch_data = self._next_data
                self._next_data = self._wrap_dataloader.next()
        else:
            batch_data = self._dataloader.get_batch_data()

        return batch_data

    def forward_backward_model(
        self,
        batch_data: Dict[str, Any],
        task_name: str = "",
    ) -> Dict[str, Any]:
        """Froward and backward model.

        Args:
            batch_data (Dict[str, Any]): One Batch data.
            task_name (str): Time cost prefix. Default=`""`.

        Returns:
            Model outputs (Dict[str, Any]).
        """
        # Get model outputs.
        self._stopwatch.set_time_cost_prefix(task_name)
        self._stopwatch.tic("ddp_cost")
        if not self._use_amp:
            model_outputs, losses = self._model(batch_data)
        else:
            with torch.cuda.amp.autocast(enabled=True, dtype=self._amp_dtype):
                model_outputs, losses = self._model(batch_data)
        self._extra_summary[task_name] = model_outputs.get(
            "extra_summary",
            {},
        )
        # All Reduce loss value.
        self._stopwatch.tic("parse_loss_cost")
        loss_per_gpu = self._train_parse_losses(losses, task_name)
        self._stopwatch.record_time_cost("parse_loss_cost", "grad_cost")

        # Normalize loss to account for batch accumulation.
        # 动态计算实际的累积步数，处理epoch末尾不能整除的情况
        actual_accumulate_steps = self._gradient_accumulate_step

        # 如果epoch大小无法被梯度累积步数整除，最后几步的累积数量会不同
        remaining_steps_in_epoch = self._one_epoch_size % self._gradient_accumulate_step
        if remaining_steps_in_epoch != 0:
            # 计算最后一个不完整累积周期的起始step
            last_incomplete_cycle_start = (
                self._one_epoch_size - remaining_steps_in_epoch
            )

            # 如果当前step在最后一个不完整的累积周期内
            if self._step_idx >= last_incomplete_cycle_start:
                actual_accumulate_steps = remaining_steps_in_epoch

        loss_per_gpu /= actual_accumulate_steps

        # Calculate Gradient
        if self._use_grad_scaler:
            self._scaler.scale(loss_per_gpu).backward()
        else:
            loss_per_gpu.backward()
        self._stopwatch.record_time_cost("grad_cost", None)
        self._stopwatch.reset_time_cost_prefix()
        return model_outputs

    def train_one_step(  # pylint: disable=too-many-branches,too-many-statements
        self,
        epoch: int,
        step: int,
    ) -> Union[Dict[str, Any], torch.Tensor, Dict[str, Dict[str, Any]]]:
        """One step training.

        Args:
            epoch (int): Current epoch.
            step (int): Current step.

        Returns:
            Model outputs (Union[Dict[str, torch.Tensor], torch.Tensor]) and
            time cost (Dict[str, float]).
        """
        self._log_vars = OrderedDict()
        self._extra_summary = OrderedDict()
        # Get batch data
        if self._pure_model:
            if self._batch_data is None:  # get one successful batch data
                self._batch_data = self.get_batch_data()
            batch_data = self._batch_data
        else:
            batch_data = self.get_batch_data()

        if not batch_data:
            return None

        if self._pure_dataloading:
            # If self._pure_dataloading, no need to train model.
            return None  # type: ignore[return-value]

        # Not self._pure_dataloading and not self._pure_model, train as usual.
        # 判断是否需要梯度同步：正常累积完成或epoch结束
        is_accumulation_step = (step + 1) % self._gradient_accumulate_step == 0
        is_epoch_end = step + 1 == self._one_epoch_size
        need_sync = is_accumulation_step or is_epoch_end

        if need_sync:
            # 需要同步时，正常执行前向后向传播
            if self._use_unsupervised_hook:
                teacher_temperature = self._lr_scheduler.teacher_temp_schedule[step]
                if self._multi_step_training and "dinov2" in batch_data:
                    batch_data["dinov2"]["teacher_temp"] = teacher_temperature
                elif not self._multi_step_training:
                    batch_data["teacher_temp"] = teacher_temperature
            model_outputs = self.forward_backward_model(batch_data)

            # clip gradients
            if self._clip_gradient > 0:
                self._stopwatch.tic("clip_grad_cost")
                if self._use_grad_scaler:
                    self._scaler.unscale_(self._optimizer)
                self._total_norm = self._train_clip_grads(self._model.parameters())
                self._stopwatch.record_time_cost("clip_grad_cost", None)
        else:
            # 不需要同步时，使用no_sync模式
            with self._model.no_sync():
                model_outputs = self.forward_backward_model(batch_data)

        # optimizer step
        self._stopwatch.tic("opt_cost")
        if ((step + 1) % self._gradient_accumulate_step == 0) or (
            step + 1 == self._one_epoch_size
        ):
            if self._use_grad_scaler:
                self._scaler.step(self._optimizer)
                self._scaler.update()
                self._model.zero_grad()
                self._optimizer.zero_grad(set_to_none=True)
            else:
                self._optimizer.step()
                self._model.zero_grad(set_to_none=self._use_grad_none)
                self._optimizer.zero_grad(set_to_none=self._use_grad_none)
        self._stopwatch.record_time_cost("opt_cost", "lr_cost")

        # lr_scheduler step
        if hasattr(self._lr_scheduler, "step"):
            self._lr_scheduler.step(self._global_step, epoch)
        self._stopwatch.record_time_cost("lr_cost", None)

        # update teacher params
        if self._use_unsupervised_hook:
            self._stopwatch.tic("update_teacher_cost")
            teacher_momentum = self._lr_scheduler.momentum_schedule[self._global_step]
            if not self._fsdp:
                self._model.module.update_teacher(teacher_momentum)
            else:
                self._model.update_teacher(teacher_momentum)

            # distill mode: update current lr info for tensorboard
            self._lr_per_sample = self._lr_scheduler.get_lr(self._global_step)
            self._stopwatch.record_time_cost("update_teacher_cost", None)

        del batch_data
        return model_outputs

    def train_one_step_rl(
        self,
        epoch: int,
        step: int,
    ) -> Union[Dict[str, Any], torch.Tensor, Dict[str, Dict[str, Any]]]:
        """One step training.

        Args:
            epoch (int): Current epoch.
            step (int): Current step.

        Returns:
            Model outputs (Union[Dict[str, torch.Tensor], torch.Tensor]) and
            time cost (Dict[str, float]).
        """
        self._log_vars = OrderedDict()
        self._extra_summary = OrderedDict()
        # Get batch data
        if self._pure_model:
            if self._batch_data is None:  # get one successful batch data
                self._batch_data = self.get_batch_data()
            batch_data = self._batch_data
        else:
            batch_data = self.get_batch_data()

        if not batch_data:
            return None

        if self._pure_dataloading:
            # If self._pure_dataloading, no need to train model.
            return None  # type: ignore[return-value]

        if self._rl_training:
            batch_data["iter_num"] = self._global_step
            self._stopwatch.tic("rollout_forward_cost")
            rollout_res = self._model.module.rollout_forward(batch_data)
            self._stopwatch.record_time_cost("rollout_forward_cost", None)

        if hasattr(self._lr_scheduler, "step"):
            self._lr_scheduler.step(self._global_step, epoch)

        update_epochs_buffer: Dict[str, List[torch.Tensor]] = defaultdict(list)
        for _ in range(self._rl_update_epochs):
            with self._model.no_sync():
                rollout_res["scaler"] = self._scaler
                rollout_res["update_epochs_buffer"] = update_epochs_buffer
                self._stopwatch.tic("train_policy_step_cost")
                model_outputs = self._model.module.train_policy_step(rollout_res)
                self._stopwatch.record_time_cost("train_policy_step_cost", None)

            self._stopwatch.tic("sync_grad_cost")
            for param in self._model.parameters():
                if param.requires_grad and param.grad is not None:
                    torch.distributed.all_reduce(
                        param.grad, op=torch.distributed.ReduceOp.SUM
                    )
                    param.grad /= torch.distributed.get_world_size()
            self._stopwatch.record_time_cost("sync_grad_cost", None)

            self._stopwatch.tic("opt_cost")
            if self._clip_gradient != 0.0:
                self._scaler.unscale_(self._optimizer)
                torch.nn.utils.clip_grad_norm_(
                    self._model.parameters(), self._clip_gradient
                )
            self._scaler.step(self._optimizer)
            if self._scaler._enabled:  # pylint: disable=protected-access
                self._scaler.update()
            self._optimizer.zero_grad(set_to_none=True)
            self._stopwatch.record_time_cost("opt_cost", None)

        self._extra_summary[""] = model_outputs.get(
            "extra_summary",
            {},
        )
        self._log_vars[""] = model_outputs["loss"]
        return model_outputs

    def _train_parse_losses(
        self,
        losses: dict,
        task_name: str = "",
    ) -> Union[torch.Tensor, float]:
        """Parse the raw outputs (losses) of the network.

        Args:
            losses (dict): Raw output of the network, which usually contain
                losses and other necessary information.
                It mainly supports two forms.
                1. {'loss_name': [l_1, l_2, ...,l_bs_size](type: torch.Tensor)}
                2. {'loss_name': [[l_1, l_2, ...,l_bs_size],...](type: list)}.
            task_name (str): Indicate to parse losses for the specific task,
                defaults to `""` if no task specified.

        Returns:
            Tensor: loss, loss is the loss tensor which may be a weighted sum of all
            losses.
        """
        local_loss_vars: Dict[str, Union[torch.Tensor, Literal[0]]] = {}

        # BatchSize mean.
        for loss_name, loss_value in losses.items():
            if isinstance(loss_value, torch.Tensor):
                local_loss_vars[loss_name] = loss_value.mean()
            elif isinstance(loss_value, list):
                local_loss_vars[loss_name] = sum(_loss.mean() for _loss in loss_value)
            else:
                raise TypeError(f"{loss_name} is not a tensor or list of tensors")

        # Task sum.
        loss = sum(_value for _key, _value in local_loss_vars.items() if "loss" in _key)

        local_loss_vars["loss"] = loss

        # Device mean.
        for loss_name, loss_value in local_loss_vars.items():
            # reduce loss when distributed training
            if dist.is_available() and dist.is_initialized():
                loss_value = loss_value.data.clone()
                if self._enable_sync_loss:
                    dist.all_reduce(loss_value.div_(dist.get_world_size()))
            local_loss_vars[loss_name] = loss_value

        self._log_vars[task_name] = local_loss_vars

        return loss

    def _train_clip_grads(
        self,
        params: Iterable[Parameter],
    ) -> torch.Tensor:
        """Clip grad value.

        Args:
            params (Iterator[Parameter]): Iterator of Parameter.

        Returns:
            Total norm of the parameters (viewed as a single vector).
        """
        params = list(
            filter(lambda p: p.requires_grad and p.grad is not None, params),
        )

        if len(params) > 0:
            return clip_grad_norm_(params, max_norm=self._clip_gradient, norm_type=2.0)

        raise ValueError("Clip Gradient Params Size <=0 !!!")

    def register_hook(
        self,
        func_name: str,
        func: Callable,
    ) -> None:
        """Register custom function, that is inserted into training flow.

        Args:
            func_name (str): Register hook name.
            func (Callable): Register hook func.
        """
        if not callable(func):
            raise ValueError(
                f"Expect callable(func)=True, but got False. func: {func}."
            )

        self._func_hook_list[func_name] = func

    def get_model(self) -> Any:
        """Return model is used to training."""
        return self._model

    def get_optimizer(self) -> Any:
        """Return optimizer is used to training."""
        return self._optimizer

    def get_lr_scheduler(self) -> Any:
        """Return lr scheduler is used to training."""
        return self._lr_scheduler

    def get_dataloader(self) -> Any:
        """Return dataloader is used to training."""
        return self._dataloader

    def format_time_cost(self, time_cost_dict, extra_msg):
        """Format time cost dict."""
        fomated_time_cost = []
        for key, mean_time_cost in time_cost_dict.items():
            fomated_time_cost.append(
                f"{key}-{extra_msg}: {mean_time_cost:.{self._log_prec}f}"
            )
        return fomated_time_cost

    def __str__(self) -> str:
        """Represent trainer info as table."""
        table = PrettyTable()

        # loss
        loss_info_list = []
        for task_name, task_loss in self._log_vars.items():
            if task_name != "":
                loss_info_list.append(f"Task: {task_name}")
                loss_prefix = task_name + "/"
            else:
                loss_prefix = ""
            loss_info_list.append(
                f"{loss_prefix}loss: {task_loss['loss']:.{self._log_prec}f}"
            )
            loss_info_list.extend(
                [
                    f"{loss_prefix}{loss_name}: {loss_value:.{self._log_prec}f}"
                    for loss_name, loss_value in task_loss.items()
                    if loss_name != "loss"
                ]
            )
        # extra summary
        extra_summary_list = []
        has_extra_summary = False
        for task_name, task_extra_summary in self._extra_summary.items():
            if len(task_extra_summary) == 0:
                continue
            has_extra_summary = True
            if task_name != "":
                extra_summary_list.append(f"Task: {task_name}")
                extra_summary_prefix = task_name + "/"
            else:
                extra_summary_prefix = ""
            for extra_summary_name, extra_summary_value in task_extra_summary.items():
                _extra_summary_value = (
                    extra_summary_value.item()
                    if isinstance(extra_summary_value, torch.Tensor)
                    else extra_summary_value
                )
                extra_summary_list.append(
                    f"{extra_summary_prefix}{extra_summary_name}: {_extra_summary_value:.{self._log_prec}f}"  # pylint: disable=line-too-long # noqa: E501
                )

        filed_names = ["Basic Info", "Loss", "CPU Time Cost", "CUDA Time Cost"]
        if has_extra_summary:
            filed_names.insert(2, "Extra Summary")
        table.field_names = filed_names
        table.align["Loss"] = "r"
        table.align["CPU Time Cost"] = "r"
        table.align["CUDA Time Cost"] = "r"
        if has_extra_summary:
            table.align["Extra Summary"] = "r"

        # time_cost
        time_cost_mean_dict = self._stopwatch.time_cost_mean("cpu")
        one_step_time_cost = time_cost_mean_dict.pop("one_step_cost", 0.0)
        time_cost = self.format_time_cost(time_cost_mean_dict, "cpu")

        time_cost_mean_dict_cuda = self._stopwatch.time_cost_mean("cuda")
        one_step_time_cost_cuda = time_cost_mean_dict_cuda.pop("one_step_cost", 0.0)
        time_cost_cuda = self.format_time_cost(time_cost_mean_dict_cuda, "cuda")

        world_size = dist.get_world_size() if dist.is_available() else 1
        # compute training consumed and eta time
        time_consumed = timedelta(seconds=int(time.time() - self._time_anchor))
        # 由于max_iters模式下total_steps已经设为max_iters，直接使用total_steps即可
        remaining_steps = self._total_steps - self._global_step
        eta_training_seconds = one_step_time_cost * remaining_steps
        eta_training = timedelta(seconds=int(eta_training_seconds))
        # ETA of current epoch
        eta_curr_epoch_seconds = one_step_time_cost * (
            self._one_epoch_size - self._global_step % self._one_epoch_size
        )
        eta_curr_epoch = timedelta(seconds=int(eta_curr_epoch_seconds))

        one_step_samples = self._bs_per_gpu * world_size

        if one_step_time_cost > 0.0:
            time_cost = [
                f"sample/s: {one_step_samples / one_step_time_cost:.{self._log_prec}f}",
                f"iter/s: {1.0 / one_step_time_cost:.{self._log_prec}f}",
            ] + time_cost
        if one_step_time_cost_cuda:
            time_cost_cuda = [
                f"sample/s: {one_step_samples / one_step_time_cost_cuda:.{self._log_prec}f}",  # pylint: disable=line-too-long # noqa: E501
                f"iter/s: {1.0 / one_step_time_cost_cuda:.{self._log_prec}f}",
            ] + time_cost_cuda
        # use tensorboard log info
        if self._use_tensorboard:
            lr_info = [
                f"lr_total: {self._optimizer.param_groups[0]['lr']}",
                f"lr_per_sample: {self._lr_per_sample}",
            ]
            self._summary.log_scaler(loss_info_list, self._global_step)
            self._summary.log_scaler(time_cost, self._global_step)
            self._summary.log_scaler(time_cost_cuda, self._global_step)
            self._summary.log_scaler(lr_info, self._global_step)
            if has_extra_summary:
                self._summary.log_scaler(
                    extra_summary_list, self._global_step, tag_prefix="extra-summary"
                )

        time_cost = [
            f"time_consumed: {time_consumed.__str__()}",
            f"eta_training: {eta_training.__str__()}",
            f"eta_curr_epoch: {eta_curr_epoch.__str__()}",
        ] + time_cost

        time_cost_cuda = [""] * 3 + time_cost_cuda
        # basic info
        basic_info = [
            f"run_name: {self._run_name}",
            f"rank: {self._rank}",
            f"word_size: {self._gpu_num}",
            f"batch_per_gpu: {self._bs_per_gpu}",
            f"lr_total: {self._optimizer.param_groups[0]['lr']}",
            f"lr_per_sample: {self._lr_per_sample}",
            f"sample_per_epoch: {self._sample_per_epoch}",
            f"sample_num_per_gpu: {self._sample_num_per_gpu}",
            f"epoch: {self._epoch_idx}/{self._total_epochs}, "
            f"{int(self._epoch_idx / self._total_epochs * 100)}%",
            f"step: {self._global_step}/{self._total_steps}, "
            f"{int(self._global_step / self._total_steps * 100)}%",
            f"total_norm: {self._total_norm.item()}",
        ]

        all_info_list = [
            basic_info,
            loss_info_list,
            time_cost,
            time_cost_cuda,
        ]
        if has_extra_summary:
            all_info_list.insert(2, extra_summary_list)
        for data_row_list in itertools.zip_longest(
            *all_info_list,
            fillvalue="",
        ):
            table.add_row(data_row_list)
        return f"\n{table.get_string()}"

    def upload_training_progress(self, epoch, step, status="running"):
        """Upload progress."""
        json_data = {
            "source": "torchpilot",
            "cluster_url": global_settings.nts_url,
            "user": global_settings.user,
            "experiment_id": (
                int(global_settings.nioflow_experiment_id)
                if global_settings.nioflow_experiment_id
                else 0
            ),
            "job_name": global_settings.nts_job_name,
            "timestamp": int(time.time()),
            "current_step": step,
            "total_step": self._total_steps,
            "current_epoch": epoch,
            "total_epoch": self._total_epochs,
            "status": status,
        }
        url = settings.monitor_url + "api/monitor/framework/heartbeat"
        try:
            response = requests.post(url, json=json_data, timeout=1)
            if response.status_code == 200:
                body = response.text
                logger.debug(f"upload_training_progress, ret={body}")  # noqa: G004
            else:
                logger.debug(
                    f"Request failed with status code: \
                        {response.status_code}"  # noqa: G004
                )
        except Exception as err_:
            logger.debug(f"upload_training_progress failed, {str(err_)}")  # noqa: G004

    def upload_errors(self, type_="read-cache-op"):
        """Upload error."""
        if type_ == "read-cache-op":
            err_list = self.msghub.get_read_cache_errors()
        else:
            err_list = self.msghub.get_errors()

        json_data = {
            "source": "torchpilot",
            "cluster_url": global_settings.nts_url,
            "user": global_settings.user,
            "experiment_id": (
                int(global_settings.nioflow_experiment_id)
                if global_settings.nioflow_experiment_id
                else 0
            ),
            "rank_id": self._rank,
            "job_name": global_settings.nts_job_name,
            "timestamp": int(time.time()),
            "err_type": "read-cache-op",
            "err_msg": "\n".join(err_list) if err_list else "",
            "exit_code": 0 if self._train_success else 1,
            "sum_metrics": {},
        }
        url = settings.monitor_url + "api/monitor/framework/errcode"
        try:
            response = requests.post(url, json=json_data, timeout=1)
            if response.status_code == 200:
                body = response.text
                logger.debug(f"upload_error successfully, ret={body}")  # noqa: G004
            else:
                logger.debug(
                    f"Request failed with status code: \
                        {response.status_code}"  # noqa: G004
                )

        except Exception as err_:
            logger.debug(f"upload_errors failed, {str(err_)}")  # noqa: G004
