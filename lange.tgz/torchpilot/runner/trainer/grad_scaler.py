# -*- coding: utf-8 -*-
"""grad scaler."""
from typing import Dict

from torch.cuda.amp.grad_scaler import GradScaler


try:
    from torch.distributed.fsdp.sharded_grad_scaler import ShardedGradScaler
except ImportError:
    ShardedGradScaler = None  # 兼容 torch < 2.0


class FixedGradScaler(GradScaler):
    """
    A subclass of `GradScaler` that implements a fixed gradient scaling strategy.

    This class overrides the `update` method from `GradScaler` but does not perform
    any scaling update, keeping the scale constant.

    Methods:
        update(new_scale=None):
            This method does not change the scale. It is a placeholder to satisfy the
            `GradScaler` API and is effectively a no-op.
    """

    def update(self, new_scale=None):
        """Update."""
        super().update(self._init_scale)


def build_grad_scaler(
    scaler_type: str,
    scaler_params: Dict,
) -> GradScaler:
    """Build grad scaler."""
    if scaler_type == "GradScaler":
        return GradScaler(**scaler_params)
    if scaler_type == "FixedGradScaler":
        return FixedGradScaler(**scaler_params)
    if scaler_type == "ShardedGradScaler":
        return ShardedGradScaler(**scaler_params)
    raise ValueError(f"grad_scaler {scaler_type} not supported!!!")
