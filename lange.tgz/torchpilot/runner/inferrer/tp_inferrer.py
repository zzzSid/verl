# -*- coding: utf-8 -*-
"""TorchPilot Inferrer."""
import itertools
import json
import logging
import os
import random
import time
from collections import defaultdict
from datetime import timedelta
from enum import Enum
from typing import Any
from typing import Callable
from typing import DefaultDict
from typing import Dict
from typing import List
from typing import Optional

import numpy as np
import torch
import torch.distributed as dist
from prettytable import PrettyTable
from torch.profiler import tensorboard_trace_handler
from tqdm import tqdm

from torchpilot.data.dataloader.tp_dataloader import TPDataLoader
from torchpilot.evaluator.base_evaluator import BaseEvaluator
from torchpilot.model.task.tp_task_flow import TPTaskFlow
from torchpilot.runner.inferrer.base_inferrer import BaseInferrer
from torchpilot.utils import constants
from torchpilot.utils.cfg_parser import PyConfig
from torchpilot.utils.checkpoint_manager import CheckpointManager
from torchpilot.utils.file_manager import FileManager
from torchpilot.utils.json_encoder import TPJsonEncoder
from torchpilot.utils.registries import DATALOADER
from torchpilot.utils.registries import EVALUATOR
from torchpilot.utils.registries import TASK_FLOW
from torchpilot.utils.stopwatch import stopwatch


logger = logging.getLogger(__name__)


class ExportType(Enum):
    """Export type enum."""

    TRACE = "trace"

    @classmethod
    def isin(cls, key):
        """Whether the key is in the enum."""
        return key in cls.__members__

    @classmethod
    def isin_value(cls, value):
        """Whether the value is in the enum."""
        return value in [_x.value for _x in cls]


class InferType(Enum):
    """Infer type enum."""

    TORCH = "torch"
    TRACE = "trace"
    TVM = "tvm"

    @classmethod
    def isin(cls, key):
        """Whether the key is in the enum."""
        return key in cls.__members__

    @classmethod
    def isin_value(cls, value):
        """Whether the value is in the enum."""
        return value in [_x.value for _x in cls]


class TPInferrer(BaseInferrer):  # pylint: disable=too-many-instance-attributes
    """BaseInferrer provides based infer workflow.

    Args:
        cfg (PyConfig): cfg_path is experiment config file path.
        run_name (str): run_name is tag of experiment, that is used to distinguish
            different experiments.
        eval_ckpt_list (List[str]): List of checkpoint pathes to evaluate.
        resume (bool, optional): Experiments run name. Default=`False`.
        use_fp16 (bool, optional): Whether to enable fp16 forward. Default=`False`.
        use_sync_bn (bool, optional): Whether to use sync bn. Note: disable could
            accelerate, but may cost reduce the accuracy. Default=`False`.
        use_deterministic (bool, optional): Whether to enable deterministic algorithms
            of pytorch. Default=`False`.
        use_model_channel_last (bool): Whether to enable channel last in model.
            This trick will make full use of TensorCore. It is worth noting
            that operators need to be supported. Default=`False`.
        seed (int, optional): Seed for deterministic. Default=`666`.
        log_precision (int, optional): Decimal precision. Default=`4`.
        print_freq_by_step (int, optional): Print frequency. Default=`20`.
        infer_type (str): Model infer type. Expected in ("torch", "trace", "tvm").
            Default=`None`.
        export_type (str): Model export type. Expected in ("trace"). Default=`None`.
        pure_dataloading (bool): Whether to use pure dataloading. If `True`,
            just loading data without inference. Use pure dtaloading and pure model
            at the same time is not allowed. Default=`False`.
        pure_model (bool): Whether to use pure model. If `True`, infering model
            with a fixed batch data.  Use pure dtaloading and pure model at the same
            time is not allowed. Default=`False`.
        skip_exception (bool): Whether to skip exception. If `True`, continue next step
            inference if occurs error, else abort inference. Default=`False`.
        use_profiler (bool): Whether to enable torch profiler tool, the output will
            save into output/exp_xxx/your_experiments_name/export. Default=`False`.
        profile_mode (bool): Whether to enable profile mode. If `True`, only infer 300
            steps and do not save checkpoint.
    """

    def __init__(  # pylint: disable=too-many-arguments,too-many-statements
        self,
        cfg: PyConfig,
        run_name: str,
        eval_ckpt_list: List[str],
        resume: bool = False,
        use_fp16: bool = False,
        use_sync_bn: bool = False,
        use_deterministic: bool = False,
        find_unused_parameters: bool = False,
        use_model_channel_last: bool = False,
        seed: int = constants.seed,
        log_precision: int = 4,
        print_freq_by_step: int = 20,
        infer_type: str = None,
        export_type: str = None,
        pure_dataloading: bool = False,
        pure_model: bool = False,
        skip_exception: bool = False,
        use_profiler: bool = False,
        profile_mode: bool = False,
    ) -> None:
        """Init TPInferrer based config dict."""
        super().__init__(cfg)
        torch.cuda.empty_cache()

        if not eval_ckpt_list or not isinstance(eval_ckpt_list, list):
            raise ValueError(
                f"Expect eval_ckpt_list or ckpt are list of checkpoint path, "
                f"but got eval_ckpt_list = {eval_ckpt_list}."
            )

        if not export_type and not infer_type:
            raise ValueError("`export_type` and `infer_type` can not both be None.")

        if export_type and infer_type:
            raise ValueError(
                "`export_type` and `infer_type` can not both be specified, "
                f"but got `export_type`: {export_type}, `infer_type`: {infer_type}"
            )

        if infer_type and not InferType.isin_value(infer_type):
            raise ValueError(f"Expect infer type in {InferType} but got {infer_type}.")

        if export_type and not ExportType.isin_value(export_type):
            raise ValueError(
                f"Expect export type in {ExportType} but got {export_type}."
            )

        self._run_name = run_name
        self._resume = resume
        self._func_hook_list: dict = {}

        # init inferrer paramters
        self._eval_ckpt_list = eval_ckpt_list
        self._step_idx = 0
        self._one_epoch_size = 1
        self._use_fp16 = use_fp16
        self._rank = dist.get_rank()
        self._gpu_num = dist.get_world_size()
        self._use_sync_bn = use_sync_bn
        self._best_eval = 0
        self._time_cost: DefaultDict[str, List[float]] = defaultdict(list)
        self._time_anchor = 0.0
        self._print_freq_by_step = print_freq_by_step
        self._log_prec = log_precision
        self._trace_model: Any = None  # Need: explicit type
        self._find_unused_parameters = find_unused_parameters
        self._infer_type = infer_type
        self._export_type = export_type
        self._pure_dataloading = pure_dataloading
        self._pure_model = pure_model
        self._use_profiler = use_profiler
        if self._use_profiler:
            self._total_epochs = 1
            self._profiler_handler = None
        self._profile_mode = profile_mode
        self._batch_data: Optional[Dict[str, Any]] = None
        if self._pure_dataloading and self._pure_model:
            raise ValueError(
                "pure_dataloading and pure_model can't be `true` at the same time."
            )

        # enable model channel last
        self._use_model_channel_last = use_model_channel_last

        # enable enable_deterministic
        self._seed = seed
        self._use_deterministic = use_deterministic
        self.enable_deterministic()

        # Init Trainer Control Params
        self._build_dataloader()
        self._build_evaluator()
        self._build_ddp_taskflow()
        self._stopwatch = stopwatch

        self._skip_exception = skip_exception

    def _build_dataloader(self) -> None:
        """Build dataloader."""
        self._dataloader = DATALOADER.build(self._cfg.infer_dataloader)
        if not isinstance(self._dataloader, TPDataLoader):
            raise ValueError(
                f"Expect type(self._dataloader)=TPDataLoader, "
                f"but got {type(self._dataloader)}."
            )
        self._sample_num_per_gpu = self._dataloader.get_sample_num_per_gpu()
        self._sample_per_epoch = self._dataloader.get_sample_per_epoch()
        self._one_epoch_size = self._dataloader.get_one_epoch_step_per_gpu()
        self._bs_per_gpu = self._dataloader.get_batch_size_per_gpu()

    def _build_evaluator(self) -> None:
        """Build evaluator."""
        self._evaluator = EVALUATOR.build(self._cfg.evaluator)
        if not isinstance(self._evaluator, BaseEvaluator):
            raise ValueError(
                f"Expect type(self._evaluator)=BaseEvaluator, "
                f"but got {type(self._evaluator)}."
            )

    def _build_ddp_taskflow(self) -> None:
        """Build ddp model."""
        self._model = TASK_FLOW.build(self._cfg.infer_task_flow)
        if not isinstance(self._model, TPTaskFlow):
            raise ValueError(
                f"Expect type(self._model)=TPTaskFlow, but got {type(self._model)}."
            )
        self._taskflow = self._model

        if self._export_type or self._infer_type != InferType.TORCH.value:
            return

        gpus_cur_machine = torch.cuda.device_count()
        device_ids = list(range(0, gpus_cur_machine))
        logger.info(
            "[%s] rank = %d, world_size = %d, n = %d, device_ids = %s.",
            os.getpid(),
            dist.get_rank(),
            dist.get_world_size(),
            gpus_cur_machine,
            str(device_ids),
        )
        cur_device = torch.cuda.current_device()
        self._model = self._model.cuda(device=cur_device)
        if self._use_model_channel_last:
            self._model = self._model.to(  # type: ignore[call-overload]
                memory_format=torch.channels_last
            )

        if self._use_sync_bn:
            # optim sync_bn
            group_size = 8
            if group_size > dist.get_world_size():
                group_size = dist.get_world_size()
            num_groups = dist.get_world_size() // group_size

            global_process_groups = []
            for j in range(num_groups):
                start_id = j * group_size
                group_ids = []
                for i in range(group_size):
                    group_ids.append(start_id + i)
                global_process_groups.append(
                    dist.new_group(ranks=group_ids, backend="nccl")
                )
            self._model = torch.nn.SyncBatchNorm.convert_sync_batchnorm(
                self._model, global_process_groups[dist.get_rank() // group_size]
            )

        self._model = torch.nn.parallel.DistributedDataParallel(
            module=self._model,
            device_ids=[cur_device],
            # output_device=cur_device,
            broadcast_buffers=True,
            find_unused_parameters=self._find_unused_parameters,
        )

    def enable_deterministic(self) -> None:
        """Enable system deterministic."""
        torch.use_deterministic_algorithms(self._use_deterministic)
        random.seed(self._seed)
        np.random.seed(self._seed)
        torch.manual_seed(self._seed)
        torch.cuda.manual_seed(self._seed)

    def load_model_file(
        self,
        ckpt_path: str,
    ) -> None:
        """Load ckpt or resume ckpt.

        Args:
            ckpt_path (str): Path to checkpoint.
        """
        # pylint: disable=attribute-defined-outside-init.
        if self._infer_type == InferType.TRACE.value:
            self._model = self._taskflow.load_traced_model(ckpt_path)
            logger.warning("Load traced model: %s", ckpt_path)
        elif self._infer_type == InferType.TVM.value:
            self._model = self._taskflow.load_tvm_model(ckpt_path)
            logger.warning("Load tvm model: %s", ckpt_path)
        else:
            CheckpointManager(
                model=self._model,
                optimizer=None,
                lr_scheduler=None,
                scaler=None,
                save_dir=None,
                pretrain_model=ckpt_path,
                resume=False,
                to_cuda=self._cfg.infer_ckpt.to_cuda,
                ckpt2model_json=self._cfg.infer_ckpt.ckpt2model_json,
                trace_mode=self._export_type == ExportType.TRACE.value,
            ).load_model()

    def save_eval_results(
        self,
        save_path: str,
        eval_results: Dict,
    ) -> Any:
        """Save evaluation's results.

        Args:
            save_path (str): Path to save eval results.
            eval_results (Any): Eval results to save.
        """
        if self._rank == 0:
            try:
                json_str = json.dumps(
                    eval_results, indent=4, sort_keys=True, cls=TPJsonEncoder
                )
            except TypeError as ex:
                raise TypeError(
                    "The `eval_results` should be composed of dict or list "
                    "without tensor or ndarray."
                ) from ex
            with open(save_path, "a", encoding="utf8") as json_file:
                json_file.write(json_str)

    def upload_tracing_model(
        self,
        tracing_model_path: str,
    ) -> None:
        """Upload tracing model to Cloud.

        Args:
            tracing_model_path (str): Path to tracing model.
        """
        torch.jit.save(self._trace_model, tracing_model_path)
        logger.warning("Export Traced Model to %s", tracing_model_path)

    def export_trace_model(self) -> None:
        """Export trace model."""
        if not hasattr(self._model, "get_trace_model"):
            raise ValueError(
                "When you set export_type=trace, "
                "you should implements `get_trace_model` in your TaskFlow."
            )
        # load ckpt
        ckpt_name = self._eval_ckpt_list[0]
        self.load_model_file(ckpt_name)
        self._model.eval()
        # get trace model
        self._trace_model = self._model.get_trace_model()
        if ckpt_name is None:
            trace_model_name = "deploy_model.pth.tar"
        else:
            trace_model_name = ckpt_name.split("/")[-1]
        save_trace_model_path = os.path.join(
            FileManager.get_export_dir(), f"Trace_{trace_model_name}"
        )
        # save trace model
        self.upload_tracing_model(save_trace_model_path)

    def infer(self) -> None:
        """Infering Flow."""
        # export trace model
        if self._export_type == ExportType.TRACE.value:
            # Tear down the process group
            self.export_trace_model()
            return

        self._time_anchor = time.time()
        try:
            if self._profile_mode:
                self._total_epochs = 1
                self._one_epoch_size = min(self._one_epoch_size, 300)

            with torch.no_grad():
                # eval mode.
                for ckpt_path in self._eval_ckpt_list:
                    self.load_model_file(ckpt_path)
                    if self._infer_type != InferType.TVM.value:
                        self._model.eval()
                    self._evaluator.set_zero()
                    self._dataloader.set_state(epoch=0, step=0, indices=None)
                    if self._use_profiler:
                        with torch.profiler.profile(
                            activities=[
                                torch.profiler.ProfilerActivity.CPU,
                                torch.profiler.ProfilerActivity.CUDA,
                            ],
                            schedule=torch.profiler.schedule(
                                wait=2,
                                warmup=2,
                                active=5,
                            ),
                            on_trace_ready=tensorboard_trace_handler(
                                os.path.join(FileManager.get_export_dir(), "profiler"),
                                worker_name=f"worker_{self._rank}",
                                use_gzip=True,
                            ),
                            record_shapes=True,
                            profile_memory=True,
                            # with_stack=True,
                            with_flops=True,
                        ) as self._profiler_handler:
                            self._one_epoch_size = 10
                            eval_results = self.infer_one_epoch()
                    else:
                        eval_results = self.infer_one_epoch()
                    if eval_results is not None:
                        save_path = os.path.join(
                            FileManager.get_export_dir(),
                            f"{os.path.basename(ckpt_path)}_eval_result.json",
                        )
                        logger.info(
                            "Saving evaluate results of checkpoint %s to %s.\n"
                            "Evaluate result: %s.",
                            ckpt_path,
                            save_path,
                            eval_results,
                        )

                        self.save_eval_results(save_path, eval_results)
                    else:
                        logger.warning("The return of infer_one_epoch() is None.")

        except Exception as ex:  # pylint: disable=broad-except
            dist.barrier()
            ex_message = ex.args[0] if len(ex.args) > 0 else ""
            logger.error(
                "Infering occurs error, aborting this infer process."
                "Will save all state info. %s",
                ex_message,
            )
            raise ex

        finally:
            # clean shm.
            if self._dataloader.data_iter:
                self._dataloader.data_iter.infer_prefetch_clean()

    def infer_one_epoch(self) -> Any:
        """One epoch infering."""
        eval_results = None
        for self._step_idx in tqdm(range(0, self._one_epoch_size)):
            # if self.skip_exception, skip this one step when occuring error,
            # else raise error and aborting this experiments
            try:
                self._stopwatch.tic("one_step_cost")
                eval_results = self.infer_one_step()
                self._stopwatch.record_time_cost("one_step_cost", None)
                self._stopwatch.sync_for_cur_iter_and_prepare_for_next_iter()
            except Exception as ex:  # pylint: disable=broad-except
                logger.exception("Found error in step %d", self._step_idx)
                if not self._skip_exception:
                    raise ex

            if self._use_profiler:
                self._profiler_handler.step()  # type: ignore[attr-defined]

            if self._step_idx % self._print_freq_by_step == 0:
                logger.info(self)  # see more details at `self.__str__()`.
                self._stopwatch.reset()

        if self._step_idx % self._print_freq_by_step != 0:
            logger.info(self)
            self._stopwatch.reset()

        return self._evaluator.dist_all_reduce(eval_results)

    def convert_model_inputs(self, batch_data):
        """Convert model inputs."""
        if self._infer_type == InferType.TRACE.value:
            self._stopwatch.tic("trace_model_inputs_hook")
            model_inputs = self._taskflow.trace_model_inputs_hook(batch_data)
            if not isinstance(model_inputs, (list, tuple)):
                model_inputs = [model_inputs]
            self._stopwatch.record_time_cost("trace_model_inputs_hook", None)
        elif self._infer_type == InferType.TVM.value:
            self._stopwatch.tic("tvm_model_inputs_hook")
            model_inputs = self._taskflow.tvm_model_inputs_hook(batch_data)
            self._stopwatch.record_time_cost("tvm_model_inputs_hook", None)
        else:
            model_inputs = batch_data

        return model_inputs

    def convert_model_outputs(self, outputs):
        """Convert model outputs."""
        if self._infer_type == InferType.TRACE.value:
            self._stopwatch.tic("trace_model_outputs_hook")
            outputs = self._taskflow.trace_model_outputs_hook(outputs)
            self._stopwatch.record_time_cost("trace_model_outputs_hook", None)
        elif self._infer_type == InferType.TVM.value:
            self._stopwatch.tic("tvm_model_outputs_hook")
            outputs = self._taskflow.tvm_model_outputs_hook(outputs)
            self._stopwatch.record_time_cost("tvm_model_outputs_hook", None)

        return outputs

    def forward_model(self, model_inputs, task_name=""):
        """Forward model."""
        self._stopwatch.set_time_cost_prefix(task_name)
        if self._infer_type == InferType.TVM.value:
            self._stopwatch.tic("model_run_cost")
            outputs = self._model.run(model_inputs)
            self._stopwatch.record_time_cost("model_run_cost", None)
        elif self._infer_type == InferType.TRACE.value:
            self._stopwatch.tic("model_forward_cost")
            if self._use_fp16:
                with torch.cuda.amp.autocast(enabled=self._use_fp16):
                    outputs = self._model(*model_inputs)
            else:
                outputs = self._model(*model_inputs)
            self._stopwatch.record_time_cost("model_forward_cost", None)
        else:
            self._stopwatch.tic("ddp_cost")
            if self._use_fp16:
                with torch.cuda.amp.autocast(enabled=self._use_fp16):
                    outputs = self._model(model_inputs)
            else:
                outputs = self._model(model_inputs)
        self._stopwatch.reset_time_cost_prefix()

        return outputs

    def infer_one_step(self) -> Any:
        """One step infering.

        Returns:
            One step eval results.

        """
        # Get batch data
        if (self._batch_data is None) or not self._pure_model:
            self._batch_data = self._dataloader.get_batch_data()
        if self._batch_data is None:
            raise ValueError("Expect batch data is not None.")
        batch_data = self._batch_data

        if self._pure_dataloading:
            # If self._pure_dataloading, no need to infer model.
            return None

        # Not self._pure_dataloading and not self._pure_model, infer as usual.
        # Preprocess data for tracing model.
        model_inputs = self.convert_model_inputs(batch_data)

        # Get model outputs
        outputs = self.forward_model(model_inputs)

        # Preprocess data for tracing model.
        outputs = self.convert_model_outputs(outputs)

        self._stopwatch.tic("eval_cost")
        eval_results = self._evaluator.eval(outputs, batch_data)
        self._stopwatch.record_time_cost("eval_cost", None)

        return eval_results

    def get_model(self) -> Any:
        """Return model is used to infering.

        Returns:
            The model.
        """
        return self._model

    def get_dataloader(self) -> Any:
        """Return dataloader is used to infering.

        Returns:
            The dataloader.
        """
        return self._dataloader

    def register_hook(
        self,
        func_name: str,
        func: Callable,
    ) -> None:
        """Register custom function, that is inserted into training flow.

        Args:
            func_name (str): Register hook name.
            func (Callable): Register hook func.
        """
        self._func_hook_list[func_name] = func

    def format_time_cost(self, time_cost_dict, extra_msg):
        """Format time cost dict."""
        fomated_time_cost = []
        for key, mean_time_cost in time_cost_dict.items():
            fomated_time_cost.append(
                f"{key}-{extra_msg}: {mean_time_cost:.{self._log_prec}f}"
            )
        return fomated_time_cost

    def __str__(self) -> str:
        """Represent trainer info as table."""
        table = PrettyTable()
        table.field_names = ["Basic Info", "CPU Time Cost", "CUDA Time Cost"]
        table.align["CPU Time Cost"] = "r"
        table.align["CUDA Time Cost"] = "r"

        # basic info
        basic_info = [
            f"run_name: {self._run_name}",
            f"rank: {self._rank}",
            f"word_size: {self._gpu_num}",
            f"batch_per_gpu: {self._bs_per_gpu}",
            f"sample_per_epoch: {self._sample_per_epoch}",
            f"sample_num_per_gpu: {self._sample_num_per_gpu}",
            f"step: {self._step_idx}/{self._one_epoch_size}, "
            f"{int(self._step_idx/self._one_epoch_size*100)}%",
        ]

        # time cost
        time_cost_mean_dict = self._stopwatch.time_cost_mean("cpu")
        one_step_time_cost = time_cost_mean_dict.pop("one_step_cost", 0.0)
        time_cost = self.format_time_cost(time_cost_mean_dict, "cpu")

        time_cost_mean_dict_cuda = self._stopwatch.time_cost_mean("cuda")
        one_step_time_cost_cuda = time_cost_mean_dict_cuda.pop("one_step_cost", 0.0)
        time_cost_cuda = self.format_time_cost(time_cost_mean_dict_cuda, "cuda")

        world_size = dist.get_world_size() if dist.is_available() else 1
        # compute training consumed and eta time
        time_consumed = timedelta(seconds=int(time.time() - self._time_anchor))
        eta_infer_seconds = one_step_time_cost * (self._one_epoch_size - self._step_idx)
        eta_infer = timedelta(seconds=int(eta_infer_seconds))

        one_step_samples = self._bs_per_gpu * world_size

        if one_step_time_cost > 0.0:
            time_cost = [
                f"sample/s: {one_step_samples / one_step_time_cost:.{self._log_prec}f}",
                f"iter/s: {1.0 / one_step_time_cost:.{self._log_prec}f}",
            ] + time_cost
        if one_step_time_cost_cuda > 0.0:
            time_cost_cuda = [
                f"sample/s: {one_step_samples / one_step_time_cost_cuda:.{self._log_prec}f}",  # pylint: disable=line-too-long # noqa: E501
                f"iter/s: {1.0 / one_step_time_cost_cuda:.{self._log_prec}f}",
            ] + time_cost_cuda

        time_cost = [
            f"time_consumed: {time_consumed.__str__()}",
            f"eta_infer: {eta_infer.__str__()}",
        ] + time_cost
        time_cost_cuda = [""] * 2 + time_cost_cuda

        for data_row_list in itertools.zip_longest(
            basic_info, time_cost, time_cost_cuda, fillvalue=""
        ):
            table.add_row(data_row_list)
        return f"\n{table.get_string()}"
