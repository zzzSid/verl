# -*- coding: utf-8 -*-
"""TorchPilot MultiTaskInferrer."""


from typing import Any

from torchpilot.runner.inferrer.tp_inferrer import InferType
from torchpilot.runner.inferrer.tp_inferrer import TPInferrer


class MultiTaskInferrer(TPInferrer):
    """MultiTaskInferer.

    Args:
        multi_step_inferring (bool): Whether to enable multi step inferring.
            Default=`True`.
    """

    def __init__(
        self,
        multi_step_inferring: bool = True,
        **kwargs,
    ) -> None:
        """Initialize trainer."""
        super().__init__(**kwargs)
        self._multi_step_inferring = multi_step_inferring

    def infer_one_step(self) -> Any:
        """One step infering.

        Returns:
            One step eval results.

        """
        # Get batch data
        batch_data = self._dataloader.get_batch_data()

        # Preprocess data for tracing model.
        model_inputs = self.convert_model_inputs(batch_data)

        # For multi-step inferring, `batch_data` is expected to be a dict of
        # task-specific input data. Otherwise, `batch_data` is just the input
        # data for a single task.
        if self._infer_type == InferType.TORCH.value and self._multi_step_inferring:
            # Loop over task-specific data and eval outputs.
            for current_task_name, task_batch in model_inputs.items():
                task_outputs = super().forward_model(task_batch, current_task_name)

                # Preprocess data for tracing model.
                self._stopwatch.set_time_cost_prefix(current_task_name)
                outputs = self.convert_model_outputs(task_outputs)

                self._stopwatch.tic("eval_cost")
                eval_results = self._evaluator.eval(outputs, task_batch)
                self._stopwatch.record_time_cost("eval_cost", None)
                self._stopwatch.reset_time_cost_prefix()

        else:
            model_outputs = super().forward_model(model_inputs)

            # Preprocess data for tracing model.
            outputs = self.convert_model_outputs(model_outputs)

            if self._infer_type == InferType.TRACE.value:
                if len(batch_data.values()) != 1:
                    raise RuntimeError(
                        f"Only one task eval is supported when eval trace model, "
                        f"but got tasks {batch_data.keys()}."
                    )
                # For feature extensions.
                for current_task_name, task_batch in batch_data.items():
                    self._stopwatch.set_time_cost_prefix(current_task_name)
                    self._stopwatch.tic("eval_cost")
                    eval_results = self._evaluator.eval(outputs, task_batch)
                    self._stopwatch.record_time_cost("eval_cost", None)
                    self._stopwatch.reset_time_cost_prefix()
            else:
                self._stopwatch.tic("eval_cost")
                eval_results = self._evaluator.eval(outputs, batch_data)
                self._stopwatch.record_time_cost("eval_cost", None)

        return eval_results
