# -*- coding: utf-8 -*-
"""TorchPilot BaseInferrer."""
import logging
from abc import ABC
from abc import abstractmethod
from typing import Any
from typing import Callable

from torchpilot.utils.cfg_parser import PyConfig


logger = logging.getLogger(__name__)


class BaseInferrer(ABC):
    """BaseInferrer provides based infer workflow.

    Args:
        cfg (PyConfig): cfg is consist of experiment paramters.
            `torchpilot.utils.cfg_parser.PyConfig` parse exp_xxx.py as cfg(Dict).
    """

    def __init__(
        self,
        cfg: PyConfig,
    ) -> None:
        """Init BaseInferrer based config dict."""
        self._cfg = cfg

    @abstractmethod
    def enable_deterministic(self) -> None:
        """Enable Deterministic Algorithm."""
        raise NotImplementedError()

    @abstractmethod
    def load_model_file(
        self,
        ckpt_path: str,
    ) -> None:
        """Load ckpt or resume ckpt.

        Args:
            ckpt_path (str): Path to checkpoint.
        """
        raise NotImplementedError()

    def upload_ckpt(
        self,
        ckpt_path: str,
    ) -> Any:
        """Upload ckpt to Cloud.

        Args:
            ckpt_path (str): Path to checkpoint.
        """
        raise NotImplementedError()

    def upload_tracing_model(
        self,
        tracing_model_path: str,
    ) -> Any:
        """Upload tracing model to Cloud.

        Args:
            tracing_model_path (str): Path to tracing model.
        """
        raise NotImplementedError()

    def save_model_outputs(
        self,
        save_path: str,
        outputs: Any,
    ) -> Any:
        """Save model's outputs.

        Args:
            save_path (str): Path to save model outputs.
            outputs (Any): Model outputs to save.
        """
        raise NotImplementedError()

    def save_postprocess_outputs(
        self,
        save_path: str,
        postprocess_outputs: Any,
    ) -> Any:
        """Save outputs after postprocess.

        Args:
            save_path (str): Path to save postprocess outputs.
            outputs (Any): Postprocess outputs to save.
        """
        raise NotImplementedError()

    @abstractmethod
    def save_eval_results(
        self,
        save_path: str,
        eval_results: Any,
    ) -> Any:
        """Save evaluation's results.

        Args:
            save_path (str): Path to save eval results.
            outputs (Any): Eval results to save.
        """
        raise NotImplementedError()

    @abstractmethod
    def infer(self) -> None:
        """Infering Flow."""
        raise NotImplementedError()

    @abstractmethod
    def infer_one_epoch(self) -> Any:
        """One epoch infering."""
        raise NotImplementedError()

    @abstractmethod
    def infer_one_step(self) -> Any:
        """One step infering."""
        raise NotImplementedError()

    @abstractmethod
    def get_model(self) -> Any:
        """Return model is used to infering."""
        raise NotImplementedError()

    @abstractmethod
    def get_dataloader(self) -> Any:
        """Return dataloader is used to infering."""
        raise NotImplementedError()

    @abstractmethod
    def register_hook(
        self,
        func_name: str,
        func: Callable,
    ) -> None:
        """Register custom function, that is inserted into training flow.

        Args:
            func_name (str):
        """
        raise NotImplementedError()
