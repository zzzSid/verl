# -*- coding: utf-8 -*-
"""MessageHub Types."""
from enum import Enum


class StatusEnum(Enum):
    """StatusEnum."""

    START = "start"
    DECODE_DONE = "decode_done"
    CONVERT_DONE = "convert_done"
    FINISH = "finish"
    VIDEO_BUFFER_ERROR = "video_buffer_error"
    DECODE_ERROR = "decode_error"
    TARGET_NUM = "target_num"
    TORCH_WORKER_START = "torch_worker_start"
    TORCH_WORKER_FINISH = "torch_worker_finish"
    TORCH_WORKER_CAM_START = "torch_worker_cam_start"
    TORCH_WORKER_CAM_FINISH = "torch_worker_cam_finish"


class ErrorEnum(Enum):
    """ErrorEnum."""

    READ_CACHE_OP_ERROR = "read_cache_op_error"
    UNKNOWN = "unknown"  # 未知状态 仅供测试.
