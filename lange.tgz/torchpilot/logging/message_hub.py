# -*- coding: utf-8 -*-
"""Message Hub."""
import logging
import multiprocessing
import queue
import time
from collections import deque
from typing import Any
from typing import Deque
from typing import Dict
from typing import Optional

from torchpilot.data.dataloader.decode_info import DecodedInfo
from torchpilot.logging.log_manager import ManagerMixin
from torchpilot.logging.logger import print_log
from torchpilot.logging.message_type import ErrorEnum
from torchpilot.logging.message_type import StatusEnum


# pylint: disable=too-many-branches, invalid-name, line-too-long, too-many-statements
# pylint: disable=too-few-public-methods, too-many-nested-blocks, unnecessary-pass


class UploadErrorListener:
    """UploadErrorListener.

    MessageHub is created and accessed in the same way as ManagerMixin.
    """

    def on_upload_error(self, err_type: str):
        """Upload error."""
        pass


class MessageHub(ManagerMixin):
    """Message hub for component interaction.

    MessageHub is created and accessed in the same way as ManagerMixin.
    """

    def __init__(self, name: str, decoder_worker_n: int, torch_worker_n: int):
        """Init."""
        super().__init__(name)

        self._runtime_info: Dict[str, str] = {}
        self._torch_worker_runtime_info: Dict[str, str] = {}
        self._torch_worker_runtime_info_tmp: Dict[str, str] = {}
        deque_readcache: Deque[str] = deque()
        self._error_info: Dict[str, Any] = {
            "read_cache_op_error": deque_readcache,
            "others": [],
        }
        # step 1. m + n processor queue initialization
        self.decoder_queues = [
            multiprocessing.get_context("spawn").Queue()
            for _ in range(decoder_worker_n)
        ]

        queue_constructor = (
            multiprocessing.get_context("fork")
            if decoder_worker_n > 0
            else multiprocessing.get_context("spawn")
        )

        self.torchworker_queues: Any = [
            queue_constructor.Queue() for _ in range(torch_worker_n)
        ]

        self.decoder_worker_n = decoder_worker_n
        self.torch_worker_n = torch_worker_n
        self.tgt_err_num = torch_worker_n * 100  # if exceed, stop running and upload.
        self.upload_error_listener: Optional[UploadErrorListener] = None

    @classmethod
    def get_current_instance(cls) -> "MessageHub":
        """Get latest created ``MessageHub`` instance.

        :obj:`MessageHub` can call :meth:`get_current_instance` before any
        instance has been created, and return a message hub with the instance
        name "mmengine".

        Returns:
            MessageHub: Empty ``MessageHub`` instance.
        """
        if not cls._instance_dict:
            cls.get_instance("messagehub")

        return super().get_current_instance()

    def set_upload_error_listener(self, upload_error_listener: UploadErrorListener):
        """Set listener."""
        self.upload_error_listener = upload_error_listener

    def parse_decoder_log(self, rank_id):
        """Parse decoder log."""
        for i in range(self.decoder_worker_n):
            try:
                r = self.decoder_queues[i].get()
            except queue.Empty:
                continue

            (name, value, _type) = r
            if _type in (ErrorEnum.UNKNOWN, ErrorEnum.READ_CACHE_OP_ERROR):
                # # only print_log, no processing.
                print_log(
                    f"decoder worker {i}, {name, value, _type}",
                    logger="current",
                    level=logging.ERROR,
                )
                if _type == ErrorEnum.READ_CACHE_OP_ERROR:
                    self._error_info["read_cache_op_error"].append(value)
            else:
                if _type == StatusEnum.START:
                    info_name, cam_type = name.split("___")
                    if info_name not in self._runtime_info:
                        decode_info = DecodedInfo(info_name, i, rank_id)
                        self._runtime_info[info_name] = decode_info
                    else:
                        decode_info = self._runtime_info[info_name]
                    decode_info.set_cur_index_start_time(cam_type, value)

                if _type == StatusEnum.DECODE_DONE:
                    info_name, cam_type = name.split("___")
                    decode_info = self._runtime_info[info_name]
                    decode_info.set_decode_done_time(cam_type, value)
                elif _type == StatusEnum.CONVERT_DONE:
                    info_name, cam_type = name.split("___")
                    decode_info = self._runtime_info[info_name]
                    decode_info.set_convert_done_time(cam_type, value)
                elif _type == StatusEnum.FINISH:
                    info_name, cam_type = name.split("___")
                    decode_info = self._runtime_info[info_name]
                    decode_info.update_stats(cam_type, value)
                elif _type == StatusEnum.TARGET_NUM:
                    info_name = name
                    decode_info = self._runtime_info[name]
                    decode_info.set_tgt_decode_num(value)
                elif _type == StatusEnum.VIDEO_BUFFER_ERROR:
                    info_name = name.split("___")[0]
                    decode_info = self._runtime_info[info_name]
                    decode_info.set_video_buffer_error(name, value)
                elif _type == StatusEnum.DECODE_ERROR:
                    info_name = name.split("___")[0]
                    decode_info = self._runtime_info[info_name]
                    decode_info.set_decode_error(name, value)

                if decode_info.check_is_finished():
                    # print_log(str(decode_info), \
                    # logger="current", level=logging.INFO)
                    # del decode_info  # save mem for now.
                    # 有不同步的问题 eg. prefetch decoder log 解析处理比当前log慢
                    # 将解码完成的保存
                    self._torch_worker_runtime_info[info_name] = decode_info
                    self._runtime_info.pop(info_name, None)
                else:
                    if _type in (
                        StatusEnum.DECODE_ERROR,
                        StatusEnum.VIDEO_BUFFER_ERROR,
                    ):
                        _loglvl = logging.WARNING
                    else:
                        _loglvl = logging.DEBUG

                    if decode_info.tgt_decode_num > -1:
                        message = f"worker_id = {i}, {name} - type = {_type} - awaiting len_cam = {decode_info.tgt_decode_num - len(decode_info.decoded_cam)}."  # noqa: E501
                    else:
                        message = f"worker_id = {i}, {name} - type = {_type}."

                    print_log(message, logger="current", level=_loglvl)

    def parse_torchworker_log(self, rank_id):
        """Parse torch worker log.

        Example:
        r: [taskname, message, status]
        """
        for i in range(self.torch_worker_n):
            try:
                r = self.torchworker_queues[i].get_nowait()
            except queue.Empty:
                time.sleep(0.5)
                continue

            torch_worker_info = None
            (_name, msg, _type) = r
            if _type == ErrorEnum.READ_CACHE_OP_ERROR:
                self._error_info["read_cache_op_error"].append(msg)
                print_log(
                    f"gpu_id={rank_id}, worker_{i}, message={r}",
                    logger="current",
                    level=logging.ERROR,
                )
            elif _type == StatusEnum.TORCH_WORKER_START:
                torch_worker_info = self._torch_worker_runtime_info.get(_name, None)
                if torch_worker_info:
                    torch_worker_info.set_torch_worker_entry_time(msg)
                else:
                    if _name not in self._torch_worker_runtime_info_tmp:
                        self._torch_worker_runtime_info_tmp[_name] = {}
                    self._torch_worker_runtime_info_tmp[_name]["entry"] = msg

            elif _type == StatusEnum.TORCH_WORKER_CAM_START:
                info_name, cam_type = _name.split("___")
                torch_worker_info = self._torch_worker_runtime_info.get(info_name, None)
                if torch_worker_info is not None:
                    torch_worker_info.set_torch_worker_start_time(cam_type, msg)
                else:
                    if _name not in self._torch_worker_runtime_info_tmp:
                        self._torch_worker_runtime_info_tmp[_name] = {}
                    self._torch_worker_runtime_info_tmp[_name][
                        cam_type + "_start"
                    ] = msg
            elif _type == StatusEnum.TORCH_WORKER_CAM_FINISH:
                info_name, cam_type = _name.split("___")
                torch_worker_info = self._torch_worker_runtime_info.get(info_name, None)
                if torch_worker_info is not None:
                    torch_worker_info.set_torch_worker_finish_time(cam_type, msg)
                else:
                    if _name not in self._torch_worker_runtime_info_tmp:
                        self._torch_worker_runtime_info_tmp[_name] = {}
                    self._torch_worker_runtime_info_tmp[_name][cam_type + "_end"] = msg
            elif _type == StatusEnum.TORCH_WORKER_FINISH:
                # must wait until decode finished, then print info.
                torch_worker_info = self._torch_worker_runtime_info.get(_name, None)
                if torch_worker_info:
                    torch_worker_info.set_torch_worker_end_time(msg)
                    print_log(
                        str(torch_worker_info), logger="current", level=logging.DEBUG
                    )
                    self._torch_worker_runtime_info.pop(_name)  # save mem
                else:
                    if _name not in self._torch_worker_runtime_info_tmp:
                        self._torch_worker_runtime_info_tmp[_name] = {}
                    self._torch_worker_runtime_info_tmp[_name]["end"] = msg
            else:
                print_log(
                    "UNKNOWN_MSG" + str(msg), logger="current", level=logging.ERROR
                )

        # 有不同步的问题 eg. prefetch decoder log 解析处理比当前torch worker慢.
        # 目的：直到已经确定decoder结束 在进行log统计。
        _tmp = []
        for k, v in self._torch_worker_runtime_info_tmp.items():
            torch_worker_info = self._torch_worker_runtime_info.get(k, None)
            if torch_worker_info:
                _tmp.append(k)
                # set up
                for x, y in v.items():
                    if x == "entry":
                        torch_worker_info.set_torch_worker_entry_time(y)
                    elif "start" in x:
                        cam_type = x.split("_")[0]
                        torch_worker_info.set_torch_worker_start_time(cam_type, y)
                    elif "end" in x:
                        cam_type = x.split("_")[0]
                        torch_worker_info.set_torch_worker_finish_time(cam_type, y)
                    elif x == "end":
                        torch_worker_info.set_torch_worker_end_time(y)

        for k in _tmp:
            self._torch_worker_runtime_info_tmp.pop(k)  # save mem.

    def collect_decoder_logs(self, done_event, rank_id):
        """Collect logs."""
        while not done_event.is_set():
            if self.decoder_worker_n:
                self.parse_decoder_log(rank_id)

    def collect_torch_worker_logs(self, done_event, rank_id):
        """Collect logs for torch worker."""
        while not done_event.is_set():
            self.parse_torchworker_log(rank_id)

    def close(self):
        """Release."""
        for q in self.decoder_queues:
            q.cancel_join_thread()
            q.close()

        for q in self.torchworker_queues:
            q.cancel_join_thread()
            q.close()

    def get_read_cache_errors(
        self,
    ):
        """Get error."""
        return self._error_info["read_cache_op_error"]

    def get_errors(
        self,
    ):
        """Get error."""
        return self._error_info["others"]
