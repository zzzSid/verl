# -*- coding: utf-8 -*-
"""Logger Init."""
from torchpilot.logging.logger import TPLogger
from torchpilot.logging.logger import print_log
from torchpilot.logging.message_hub import MessageHub


__all__ = ["MessageHub", "TPLogger", "print_log"]
