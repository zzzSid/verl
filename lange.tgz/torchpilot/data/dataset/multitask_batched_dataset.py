# -*- coding: utf-8 -*-
"""MultiTask dataset."""

from typing import Any
from typing import Dict
from typing import List

from torch.utils.data._utils.collate import default_collate

from torchpilot.data.dataset.multitask_dataset import MultiTaskDataset


class MultiTaskBatchedDataset(MultiTaskDataset):
    """MultiTaskBatchedDataset."""

    def __getitem__(  # type: ignore[override]
        self,
        index: Dict[str, List[int]],
    ) -> Dict[str, Dict[str, Any]]:
        """Get one item.

        Args:
            idx (Dict[str, int]): The {task_name, index} pairs.

        Returns:
            {task_name, task_data_dict} pairs.
        """
        task_wise_batched_data = {}
        for task_name, task_idx_list in index.items():
            task_data_item = []
            for task_idx in task_idx_list:
                task_data_item.append(
                    self._task_datasets[task_name][
                        task_idx % self._len_datasets[task_name]
                    ]
                )
            task_wise_batched_data[task_name] = default_collate(task_data_item)

        for task_name, task_batched_data in task_wise_batched_data.items():
            task_batched_data["task_name"] = task_name

        return task_wise_batched_data

    @staticmethod
    def batch_collate(data: List[Any]) -> Dict[str, Dict[str, Any]]:
        """Collate function for current dataset."""
        if len(data) != 1:
            raise RuntimeError("Expect batch size of dataloader is 1.")
        return data[0]
