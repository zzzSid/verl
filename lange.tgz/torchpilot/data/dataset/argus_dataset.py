# -*- coding: utf-8 -*-
"""Dataset of argus BEV model."""


import logging
import pickle
import time
import traceback
from copy import deepcopy
from enum import Enum
from multiprocessing import shared_memory
from queue import Queue
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple
from typing import Union

import numpy as np
import torch

from torchpilot.data.dataset.base_dataset import BaseDataset
from torchpilot.data.dataset.video_dataset import PrefetchDecodeInterface
from torchpilot.utils.settings import argus_infer_settings


# pylint: disable=broad-except,too-many-nested-blocks,too-few-public-methods
# pylint: disable=too-many-locals,line-too-long,too-many-statements,too-many-branches


logger = logging.getLogger(__name__)


def inverse_rt(ego):
    """Inverse Rt."""
    ego_inv = np.eye(4, dtype=np.float32)
    ego_inv[:3, :3] = ego[:3, :3].T
    ego_inv[:3, 3] = (ego[:3, :3]).T.dot(-ego[:3, 3])
    return ego_inv


def create_meta_info_dict_none(meta_input):
    """Generate zero values of the same shape."""
    meta_output = {}
    for k, value in meta_input.items():
        meta_output[k] = np.zeros(value.shape, dtype=value.dtype)
    return meta_output


class InferTaskMode(str, Enum):
    """Infer Task Mode."""

    TASK2D = "task_2d"
    TEMPORAL = "temporal"
    SINGLE_FRAME = "sing_frame"


class ArgusCameraDatasetDecodeInterface:
    """Argus dataset decode interface."""

    using_2k_video: bool
    key_frames: List
    _cam_types: List
    _enable_tasks: List
    _local_rank: int
    validate_mode: bool
    num_workers: int
    enable_shared_decoder: bool
    decode_res_queue: Queue
    decode_meta_queue: Queue
    multi_decoder: Dict
    multi_convertor: Dict
    cams_decode_key: Dict[str, Tuple]
    cams_removed_indices: Dict[str, List[int]]
    cams_deduplicate_decode_timestamp: Dict[str, List[int]]
    cams_video_path: List[str]
    cams_decode_res: Dict

    def _decode_fill_black_method(self, *args, **kwargs):
        raise NotImplementedError()

    def _decode_video_func(self, *args, **kwargs):
        raise NotImplementedError()

    def _load_all_s3_file_for_video(self, *args, **kwargs):
        raise NotImplementedError()

    def _is_4k_camera(self, *args, **kwargs):
        raise NotImplementedError()

    def _get_super_camera(self, *args, **kwargs):
        raise NotImplementedError()

    def video_decode_images(
        self,
        decode_video_meta: Dict,
        sensor_video_info_dict: Dict,
        data_type: str,
        idx: int,
    ):
        """Load bytes from video."""
        sensor_video_info_dict, decode_video_meta = self._load_all_s3_file_for_video(
            sensor_video_info_dict=sensor_video_info_dict,
            decode_video_meta=decode_video_meta,
            using_2k_video=self.using_2k_video,
        )
        # 需要video_info_dict 长度个 meta，然后时间戳为0的地方补None
        # only copy for no cached  timestamp in streming infer
        vt_meta_list = [
            deepcopy(sensor_video_info_dict)
            for _ in range(len(decode_video_meta["fw"]["decode_timestamp"]))
        ]
        for camera, camera_info in deepcopy(decode_video_meta).items():
            for i, timestamp in enumerate(camera_info["decode_timestamp"]):
                if timestamp == 0:
                    vt_meta_list[i][camera] = None
            decode_video_meta[camera]["decode_timestamp"] = [
                j for j in decode_video_meta[camera]["decode_timestamp"] if j != 0
            ]

        all_cam_types = sorted(sensor_video_info_dict.keys(), key=self._cam_types.index)

        decode_video_func_kwargs = {
            "task_name": self._enable_tasks[0],
            "sensor_video_info_dict": sensor_video_info_dict,
            "decode_video_meta": decode_video_meta,
            "all_cam_types": all_cam_types,
            "local_rank": self._local_rank,
            "data_type": data_type,
            "vt_meta_list": vt_meta_list,
            "validate_mode": self.validate_mode,
            "get_raw_image_shape": False,
            "using_2k_video": self.using_2k_video,
            "black_empty_method": self._decode_fill_black_method,
        }
        if (
            self.num_workers != 0 and self.enable_shared_decoder
        ):  # has multi subprocess as worker
            self.decode_meta_queue.put(
                (
                    idx,
                    decode_video_func_kwargs,
                )
            )
            # Decode func: decode_video_func
            decoder_idx, decode_res = self.decode_res_queue.get()
            if decoder_idx != idx:
                raise ValueError("Decode index mismatch.")
            if isinstance(decode_res, Exception):
                raise decode_res
            torch_tensor_list, _ = decode_res
        else:  # num_worker == 0, in main subprocess
            torch_tensor_list, _ = self._decode_video_func(
                multi_decoder=self.multi_decoder,
                multi_convertor=self.multi_convertor,
                **decode_video_func_kwargs,
                cams_decode_key=self.cams_decode_key,
                cams_removed_indices=self.cams_removed_indices,
                cams_deduplicate_decode_timestamp=self.cams_deduplicate_decode_timestamp,  # pylint: disable=line-too-long # noqa:E501
                cams_video_path=self.cams_video_path,
                cams_decode_res=self.cams_decode_res,
            )

        return torch_tensor_list


class ArgusCameraAsyncDecodeInterface(PrefetchDecodeInterface):
    """Argus async decode interface."""

    _meta_info_list: List
    _cam_types: List
    using_2k_video: bool
    key_frames: List
    _enable_tasks: List
    _local_rank: int
    validate_mode: bool
    merge_timestamp: Dict
    index_timestamp_map: Dict
    prefetch_decode_meta_info_list: List
    _pinhole_types: List
    _svc_types: List

    def _decode_fill_black_method(self, *args, **kwargs):
        raise NotImplementedError()

    def _decode_video_func_async(self, *args, **kwargs):
        raise NotImplementedError()

    def _load_all_s3_file_for_video(self, *args, **kwargs):
        raise NotImplementedError()

    def _is_4k_camera(self, *args, **kwargs):
        raise NotImplementedError()

    def _get_super_camera(self, *args, **kwargs):
        raise NotImplementedError()

    def get_decoder_kwargs(
        self,
        idx,
        device_id,  # pylint: disable=unused-argument
    ):
        """Get decoder kwargs."""
        idx = idx["default"]["idx"]
        current_data = self._meta_info_list[idx]
        for cam in self._cam_types:

            if self._is_4k_camera(cam):
                continue

            decode_func_inputs = self.prefetch_decode_meta_info_list[idx][cam]

            current_data["decode_video_meta_list"][cam][
                "decode_func_inputs"
            ] = decode_func_inputs

            if decode_func_inputs != []:
                _decode_timestamp = self.merge_timestamp[
                    self.get_clip_id(self._meta_info_list[idx])
                ][cam][1]
                current_data["decode_video_meta_list"][cam][
                    "decode_timestamp"
                ] = _decode_timestamp
            else:
                current_data["decode_video_meta_list"][cam]["decode_timestamp"] = []

        # NOTE: 图片/meta 输入顺序与 cam_types对应
        current_data["decode_video_meta_list"] = dict(
            sorted(
                current_data["decode_video_meta_list"].items(),
                key=lambda x: self._cam_types.index(x[0]),  # sort by camera order
            )
        )

        current_data["sensor_video_info_dict"] = dict(
            sorted(
                current_data["sensor_video_info_dict"].items(),
                key=lambda x: self._cam_types.index(x[0]),  # sort by camera order
            )
        )

        decode_video_meta = deepcopy(current_data["decode_video_meta_list"])
        sensor_video_info_dict = current_data["sensor_video_info_dict"]
        data_type = "dlb"

        sensor_video_info_dict, decode_video_meta = self._load_all_s3_file_for_video(
            sensor_video_info_dict=sensor_video_info_dict,
            decode_video_meta=decode_video_meta,
            using_2k_video=self.using_2k_video,
        )
        # 需要video_info_dict 长度个 meta，然后时间戳为0的地方补None
        vt_meta_list = [
            deepcopy(sensor_video_info_dict) for _ in range(len(self.key_frames))
        ]

        for camera, camera_info in decode_video_meta.items():
            if sum(camera_info["decode_timestamp"]) == 0:
                # all time stamp is 0, skip decode.
                # NOTE: hack for single frame.
                vt_meta_list[0][camera] = None
            decode_video_meta[camera]["decode_timestamp"] = [
                j for j in decode_video_meta[camera]["decode_timestamp"] if j != 0
            ]

        for camera in list(decode_video_meta.keys()):
            if decode_video_meta[camera]["decode_timestamp"] == []:
                decode_video_meta.pop(camera)

        all_cam_types = sorted(sensor_video_info_dict.keys(), key=self._cam_types.index)

        decode_video_func_kwargs = {
            "task_name": self._enable_tasks[0],
            "sensor_video_info_dict": sensor_video_info_dict,
            "decode_video_meta": decode_video_meta,
            "all_cam_types": all_cam_types,
            "local_rank": self._local_rank,
            "data_type": data_type,
            "vt_meta_list": vt_meta_list,
            "validate_mode": self.validate_mode,
            "get_raw_image_shape": False,
            "using_2k_video": self.using_2k_video,
            "black_empty_method": self._decode_fill_black_method,
        }

        return decode_video_func_kwargs

    def get_prefetch_decoder_attrs(
        self,
        prefetch_decoder_using_mem_percent,
        batch_size,  # pylint: disable=unused-argument
        decoder_worker_num,
    ):
        """Get prefetch decoder attrs."""
        # Prefetch decoder
        # 注：_prefetch_decoder_factor 必须跟设置的shm大小匹配, 太大会有flush掉的风险。
        # step 1. 按使用本机 60% 内存计算，预期每个 decoder worker prefetch 的 batch 数量为:
        #   16张2k图像占用内存(MB) = 1920*1080*3*16/1024/1024 = 94MB
        #   预期 shm 存放的 batch 数 = 1920(机器内存GB) * 1024(GB/MB) * 60%(预期内存占用) / (94MB * 4batch_size) = 3137 # noqa: E501
        #   预期每个 decoder worker prefetch 的 batch 数(即 _prefetch_decoder_factor) = 3137 / (4decoder_workers * 8rank_num) = 98 【注：时序需要再除以时序长度】 # noqa: E501

        cam_num = len(self._cam_types)
        cam_type_set = self._cam_types

        pinhole_num, srcw_num, svc_num = 0, 0, 0
        for cam_type in cam_type_set:
            if cam_type == "srcw":
                srcw_num = 1
            elif cam_type in self._pinhole_types:
                pinhole_num += 1
            elif cam_type in self._svc_types:
                svc_num += 1
            else:
                raise ValueError(f"Unexpected cam type {cam_type}")

        prefetch_decoder_factor = 60 / decoder_worker_num

        # bs=8, 16cam, 对应2500 buffer
        buffer_num = 2500 * cam_num / 16

        pinhole_buffer_num = int(buffer_num * pinhole_num / cam_num)
        srcw_buffer_num = int(buffer_num * srcw_num / cam_num)
        svc_buffer_num = int(buffer_num * svc_num / cam_num)
        pinhole_img_shape = (3, 1056, 1824)
        svc_img_shape = (3, 384, 480)

        logger.warning(
            "auto-calculating mem_percent = %s , _prefetch_decoder_factor = %s, buffer num = %s",  # noqa: E501
            prefetch_decoder_using_mem_percent,
            prefetch_decoder_factor,
            buffer_num,
        )
        return (
            prefetch_decoder_factor,
            buffer_num,
            pinhole_buffer_num,
            srcw_buffer_num,
            svc_buffer_num,
            pinhole_img_shape,
            svc_img_shape,
            prefetch_decoder_factor,
        )

    def update_decode_res_to_index(
        self,
        _idx,  # pylint: disable=unused-argument
        index,
        max_retry_times,
        decoder_interactive_dict_list,
        shm_shapes,
        _id,  # pylint: disable=unused-argument
        device_id,  # pylint: disable=unused-argument
        global_rank,  # pylint: disable=unused-argument
    ):
        """Update decode res to index."""
        decoder_res_pop_set = set()
        shm_shape_12, shm_shape_3, shm_shape_1 = shm_shapes

        skip_batch = False
        try:
            for _, _idx_dict in enumerate(index):
                for __, (task_name, task_idx) in enumerate(_idx_dict.items()):
                    global_idx = task_idx["global_idx"]
                    task_idx = task_idx["idx"]

                    decode_need_to_wait = []

                    for camera in self._cam_types:
                        # ONLY FOR SINGLE CLIP.
                        timestamp = self._meta_info_list[task_idx][
                            "decode_video_meta_list"
                        ][camera]["decode_timestamp"][0]
                        if timestamp != 0:
                            decode_need_to_wait.append(camera)

                    cur_task_idx_cam_list = [
                        f"{task_idx}__{cam_type}" for cam_type in self._cam_types
                    ]
                    pinhole_res = []
                    svc_res = []
                    cam_res = []
                    ori_shape_res = []

                    # 解出了多少帧
                    valid_len = 0
                    for (
                        _decoder_torch_worker_interactive_dict
                    ) in decoder_interactive_dict_list:
                        valid_len += len(
                            [
                                i
                                for i in _decoder_torch_worker_interactive_dict.keys()
                                if i.startswith(f"{task_idx}__")
                            ]
                        )

                    for _ in range(max_retry_times):
                        curr_cam = []

                        for (
                            _decoder_torch_worker_interactive_dict
                        ) in decoder_interactive_dict_list:
                            curr_cam += [
                                i
                                for i in _decoder_torch_worker_interactive_dict.keys()
                                if i.startswith(f"{task_idx}__")
                            ]

                        if len(decode_need_to_wait) > len(curr_cam):
                            time.sleep(0.1)
                            continue
                        break

                    else:
                        logger.error("Get result from shm failed.")
                        logger.error("Global index %s ", global_idx)
                        logger.error("Task index %s ", task_idx)
                        logger.error("Curr available cam: %s", curr_cam)
                        logger.error("Curr need cam: %s", decode_need_to_wait)

                    for task_idx_cam_k in cur_task_idx_cam_list:
                        cam_type = task_idx_cam_k.split("__")[-1]

                        # ONLY FOR SINGLE CLIP.
                        timestamp = self._meta_info_list[task_idx][
                            "sensor_video_info_dict"
                        ]
                        # Get black image for empty frame.
                        if timestamp == 0:
                            shm_res = None

                        else:
                            # check each dict in the list
                            for (
                                _decoder_torch_worker_interactive_dict
                            ) in decoder_interactive_dict_list:
                                shm_res = _decoder_torch_worker_interactive_dict.get(
                                    task_idx_cam_k, None
                                )
                                if shm_res is not None:
                                    decoder_res_pop_set.add(
                                        (
                                            _decoder_torch_worker_interactive_dict,
                                            task_idx_cam_k,
                                        )
                                    )

                                    break
                        if isinstance(shm_res, dict):
                            shm_idx = shm_res["idx"]
                            shm_mem_name = shm_res["shm_name"]
                            ori_shape = shm_res["ori_shape"]

                            if cam_type in ("sfw", "slw", "srw"):
                                existing_shm_svc = shared_memory.SharedMemory(
                                    name=shm_mem_name
                                )
                                np_array_3 = np.ndarray(
                                    shm_shape_3,
                                    dtype=np.uint8,
                                    buffer=existing_shm_svc.buf,
                                )  # backed by shared_memory
                                decode_res = np_array_3[shm_idx]  # this part cost mem
                                svc_res.append(decode_res.copy())
                                existing_shm_svc.close()  # save mem
                            elif cam_type in ("srcw"):
                                existing_shm_srcw = shared_memory.SharedMemory(
                                    name=shm_mem_name
                                )
                                np_array_1 = np.ndarray(
                                    shm_shape_1,
                                    dtype=np.uint8,
                                    buffer=existing_shm_srcw.buf,
                                )  # backed by shared_memory
                                decode_res = np_array_1[shm_idx]  # this part cost mem
                                pinhole_res.append(decode_res.copy())
                                existing_shm_srcw.close()  # save mem
                            else:
                                existing_shm_pinhole = shared_memory.SharedMemory(
                                    name=shm_mem_name
                                )
                                np_array_13 = np.ndarray(
                                    shm_shape_12,
                                    dtype=np.uint8,
                                    buffer=existing_shm_pinhole.buf,
                                )  # backed by shared_memory
                                decode_res = np_array_13[shm_idx]
                                pinhole_res.append(decode_res.copy())
                                existing_shm_pinhole.close()  # save mem

                            ori_shape_res.append(ori_shape)
                            del decode_res  # save mem
                        else:  # No shm res, add black img.
                            if cam_type in ("sfw", "slw", "srw"):
                                svc_res.append(
                                    np.zeros((1, 3, 384, 480), dtype=np.uint8)
                                )
                            else:
                                pinhole_res.append(
                                    np.zeros((1, 3, 1056, 1824), dtype=np.uint8)
                                )

                    cam_res += list(
                        torch.from_numpy(np.concatenate(pinhole_res, axis=0))
                    )
                    cam_res += list(torch.from_numpy(np.concatenate(svc_res, axis=0)))

                    _idx_dict[task_name] = {
                        "idx": task_idx,  # idx
                        "global_idx": global_idx,
                        "decode_res": [cam_res],
                        "ori_shape_res": ori_shape_res,
                    }

                    del pinhole_res, svc_res, cam_res, ori_shape_res  # save mem

        except Exception as error:

            logger.error(
                "%s \n",
                " ".join(traceback.format_exception(None, error, error.__traceback__)),
            )
            if skip_batch:
                raise RuntimeError(
                    "decode res cannot be retrieved, skip "
                    f"task name = {task_name}, task idx = {task_idx}, "
                    f"global idx = {global_idx}"
                ) from error
        finally:
            for _dict, _k in decoder_res_pop_set:
                _dict.pop(_k, None)  # save mem

    def predecode_video_func(
        self,
        idx,
        bs_idx,  # pylint: disable=unused-argument
        device_id,  # pylint: disable=unused-argument
    ):
        """Decode video prepare func."""
        decoder_kwargs = self.get_decoder_kwargs(idx, device_id)
        idx["default"]["decoder_kwargs"] = decoder_kwargs
        idx["default"]["task_idx"] = idx["default"]["idx"]

    @staticmethod
    def get_clip_id(sample: Dict) -> str:
        """Get sample id from sample."""
        return sample["sample_id"].rsplit("_", 1)[0]

    def decode_video_func_async(
        self,
        multi_decoder,
        shared_mem,
        _matching_dict_,
        _remap_dict,
        idx,
        bs_idx,  # pylint: disable=unused-argument
        cams_decode_res,
        _resume_dict,
        device_id,  # pylint: disable=unused-argument
        cams_deduplicate_decode_timestamp,
        thread_queue,
        worker_id,
        global_rank,  # pylint: disable=unused-argument
        **kwargs,
    ):
        """Decode video func. Note that it must be staticmethod.

        Args:
            sensor_video_info_dict: Dict[str, Any],
            decode_video_meta: Dict[str, Any],
            all_cam_types: List[str],
            local_rank: int,
            data_type: str,
            vt_meta_list: List[Dict[str, Any]],
            validate_mode: bool,
            get_raw_image_shape: bool,
            using_2k_video: bool,
            # The following input will be provided by dataloader
            multi_decoder: Dict[Tuple, VideoBufferDecoder],
            multi_convertor: Dict[Tuple, Convertor],
            cams_decode_key: Dict[str, Tuple],
            cams_removed_indices: Dict[str, List[int]],
            cams_deduplicate_decode_timestamp: Dict[str, List[int]],
            cams_video_path: List[str],
            cams_decode_res: Dict[str, List[Nv12DeviceFrame]],
            task_name: str,
            convertor_target_pinhole: Optional[Tuple[int]] = None,
            convertor_target_svc: Optional[Tuple[int]] = None,
        """
        del kwargs
        task_idx_with_kwargs = idx["default"]

        for _, (_, task_idx_with_kwargs) in enumerate(idx.items()):
            try:
                task_idx = task_idx_with_kwargs.get("task_idx")
                # global_idx = task_idx_with_kwargs.get("global_idx")
                decoder_kwargs = task_idx_with_kwargs.get("decoder_kwargs")
                if decoder_kwargs is None:
                    return

                self._decode_video_func_async(
                    multi_decoder=multi_decoder,
                    shared_mem=shared_mem,
                    _matching_dict_=_matching_dict_,
                    _remap_dict=_remap_dict,
                    idx=task_idx,
                    cams_decode_res=cams_decode_res,
                    _resume_dict=_resume_dict,
                    cams_deduplicate_decode_timestamp=cams_deduplicate_decode_timestamp,
                    thread_queue=thread_queue,
                    worker_id=worker_id,
                    timestamp_dict=self.index_timestamp_map,
                    clip_id=self.get_clip_id(self._meta_info_list[task_idx]),
                    **decoder_kwargs,
                )

            except Exception as error:
                logger.error(
                    "%s \n",
                    " ".join(
                        traceback.format_exception(None, error, error.__traceback__)
                    ),
                )

    def _parse_timestamp_index_mapping(self):
        """Parse timestamp index mapping."""
        # Init.
        self.index_timestamp_map = {}
        for i in self._meta_info_list:
            if self.get_clip_id(i) not in self.index_timestamp_map:
                self.index_timestamp_map[self.get_clip_id(i)] = {}
                for cam in self._cam_types:
                    self.index_timestamp_map[self.get_clip_id(i)][cam] = {}

        # Fill mapping.
        for i, j in enumerate(self._meta_info_list):
            if j["frame_idx_in_clip"] < 0:
                continue
            data = j["decode_video_meta_list"]
            for cam in self._cam_types:
                if self._is_4k_camera(cam):
                    continue
                for decode_timestamp in data[cam]["decode_timestamp"][-1:]:
                    if (
                        decode_timestamp
                        not in self.index_timestamp_map[self.get_clip_id(j)][cam]
                    ):
                        self.index_timestamp_map[self.get_clip_id(j)][cam][
                            decode_timestamp
                        ] = []

                    self.index_timestamp_map[self.get_clip_id(j)][cam][
                        decode_timestamp
                    ].append(i)

        for clip_info in self.index_timestamp_map.values():
            for cam in self._cam_types:
                if self._is_4k_camera(cam):
                    clip_info[cam] = clip_info[self._get_super_camera(cam)]

    def _parse_merge_timestamp(self):
        """
        Parse merge timestamp.

        merge_timestamp: clip_id -> cam name -> [video, ts]
        """
        # Init.
        self.merge_timestamp = {}
        for i in self._meta_info_list:
            if self.get_clip_id(i) not in self.merge_timestamp:
                self.merge_timestamp[self.get_clip_id(i)] = {}
                for cam in self._cam_types:
                    self.merge_timestamp[self.get_clip_id(i)][cam] = [
                        [],  # video
                        [],  # ts
                    ]

        for i in self._meta_info_list:
            for cam in self._cam_types:

                self.merge_timestamp[self.get_clip_id(i)][cam][0] += i[
                    "decode_video_meta_list"
                ][cam]["decode_func_inputs"][-1:]

                self.merge_timestamp[self.get_clip_id(i)][cam][1] += i[
                    "decode_video_meta_list"
                ][cam]["decode_timestamp"][-1:]

        # sort and remove duplicate
        for clip_info in self.merge_timestamp.values():
            for cam in self._cam_types:
                clip_info[cam][0] = sorted(
                    (set(clip_info[cam][0])),
                    key=lambda x: int(x.split(" ")[-2]),
                )
                clip_info[cam][0] = [i for i in clip_info[cam][0] if i != 0]
                clip_info[cam][1] = sorted(set(clip_info[cam][1]))


class ArgusCameraDataset(  # pylint: disable=too-many-ancestors
    ArgusCameraAsyncDecodeInterface, ArgusCameraDatasetDecodeInterface, BaseDataset
):  # pylint: disable=too-many-instance-attributes.
    """Dataset for argus.

    Args:
        mode (str): Mode in _VALID_MODE.
        meta_file (str or None) : Meta file, expect Dict[str, Dict[str, List[str]]],
        transforms (list, dict or None): List of transforms.

    .. code-block:: python

        >>> meta_file={
        ...     'ceph_dir'={
        ...         'train'='train_meta_file_dir',
        ...         'val'='val_meta_file_dir',
        ...         'test'='test_meta_file_dir',
        ...     },
        ...     'label_dir'={...},
        ...     ...
        ... }.
    """

    DATASET_META_FILE: Dict[str, List[Dict]] = {
        "debug_caseppl": [
            {
                "label_files": [
                    # "/share-global/vesper.ni/temp_file/vt_caseppl/4264b88f-736a-422a-9191-ae9b4d38d962/video_info.pkl",  # pylint: disable=line-too-long # noqa:E501
                    # "/share-global/vesper.ni/demo_video_info/eb021926-8e4c-4cae-b55b-fd4a36842cc3/video_info.pkl"  # pylint: disable=line-too-long # noqa:E501
                    # "/share-global/vesper.ni/demo_video_info/11c_v0.6/ff6d4149-44ba-40e9-9c87-ee4592a24811/ff6d4149-44ba-40e9-9c87-ee4592a24811/video_info.pkl"  # pylint: disable=line-too-long # noqa:E501
                    # "/share-global/vesper.ni/demo_video_info/11c_v0.6/20230802T160500_LJ1E6A3U6PG535016__1690963707__1690963717/20230802T160500_LJ1E6A3U6PG535016/video_info.pkl",  # pylint: disable=line-too-long # noqa:E501
                    "/share-global/vesper.ni/demo_video_info/11c_v0.6/20230724T201500_LJ1EFAUU6NG000005__1690201167__1690201177/20230724T201500_LJ1EFAUU6NG000005/video_info.pkl"  # pylint: disable=line-too-long # noqa:E501
                ]
            }
        ],
        "val_qa_mil": [{"label_files": argus_infer_settings.PKL_LIST}],
    }

    def __init__(  # pylint: disable=dangerous-default-value
        self,
        enable_tasks,
        pinhole_types: List,
        svc_types: List,
        enable_prefetch_decoder: bool,
        *args,  # pylint: disable=unused-argument
        validate_mode: bool = False,
        using_2k_video: bool = False,
        cam_types: List[str] = [
            "fw",
            "fl",
            "fn",
            "fr",
            "rl",
            "rn",
            "rr",
        ],
        enable_shared_decoder: bool = False,
        infer_task_type,  # InferTaskMode.SINGLE_FRAME
        mode: str,
        transforms: Union[List[Any], Dict[str, Any], None] = None,
        video_training_mode: Optional[bool] = False,
        interval: int = 1,
        argusppl_temporal_interval=1,
        argusppl_temporal_his_num=5,
        key_frames=None,
        streaming_infer=False,
        **kwargs,  # pylint: disable=unused-argument
    ) -> None:
        """Init."""
        super().__init__(  # pylint: disable=unexpected-keyword-arg
            mode=mode,
            transforms=transforms,
            video_training_mode=video_training_mode,
            enable_prefetch_decoder=enable_prefetch_decoder,
            **{
                "batch_size": kwargs["batch_size"],
                "num_workers": kwargs["num_workers"],
            },
        )
        self._enable_tasks = enable_tasks
        self.validate_mode = validate_mode
        self.using_2k_video = using_2k_video
        self._cam_types = cam_types
        self.num_workers = 0
        self.enable_shared_decoder = enable_shared_decoder
        self._pinhole_types = [cam.value for cam in pinhole_types]
        self._svc_types = [cam.value for cam in svc_types]
        self._meta_info_list = []
        self.argusppl_temporal_interval = argusppl_temporal_interval
        self.argusppl_temporal_his_num = argusppl_temporal_his_num
        self.infer_task_type = infer_task_type

        if key_frames is None:
            key_frames = [0]
        elif len(key_frames) > 0:
            for key_frame1, key_frame2 in zip(key_frames[:-1], key_frames[1:]):
                if (
                    key_frame2 - key_frame1
                    > self.argusppl_temporal_interval * self.argusppl_temporal_his_num
                ):
                    raise ValueError(
                        "key_frame_interval should less than "
                        "self.argusppl_temporal_interval * "
                        "self.argusppl_temporal_his_num"
                    )
        self.key_frames = key_frames
        self.temporal_window_size = key_frames[-1] - key_frames[0] + 1
        self.temporal_interval = (
            self.key_frames[1] - self.key_frames[0] if len(self.key_frames) > 1 else 1
        )

        self._interval = interval

        self._data_paths = self.DATASET_META_FILE[self._mode][0]["label_files"]

        self._dist_world_size = 1
        self._cur_rank = 0
        self._local_rank = 0

        self._parse_datasets()
        logger.info("Data path: %s.", self._data_paths)

        self._parse_timestamp_index_mapping()  # for prefetch decode
        self._parse_merge_timestamp()  # for prefetch decode
        self._prepare_prefetch_decode_meta()  # for prefetch decode

        self.streaming_infer = streaming_infer
        logger.info("Enable streaming infer: %s", str(self.streaming_infer))

    def _prepare_prefetch_decode_meta(self):
        """
        Prepare prefetch decode meta.

        只在第一次需要decode得时候保留meta.
        """
        self.prefetch_decode_meta_info_list = []

        for idx, _ in enumerate(self._meta_info_list):
            if idx < 0:
                continue

            current_data = self._meta_info_list[idx]

            curr_decode_func_inputs = {}

            for cam in self._cam_types:
                if self._is_4k_camera(cam):
                    continue

                decode_func_inputs = deepcopy(
                    current_data["decode_video_meta_list"][cam]["decode_func_inputs"]
                )[-1:]
                for i in decode_func_inputs:
                    _curr = self.merge_timestamp[
                        self.get_clip_id(self._meta_info_list[idx])
                    ][cam][0]
                    if i not in _curr:  # already be decoded, don't need decode again.
                        decode_func_inputs.remove(i)
                    else:  # need decode.
                        self.merge_timestamp[
                            self.get_clip_id(self._meta_info_list[idx])
                        ][cam][0].remove(i)
                curr_decode_func_inputs[cam] = decode_func_inputs

            self.prefetch_decode_meta_info_list.append(curr_decode_func_inputs)

    def _parse_datasets(
        self,
    ):
        """Parse pkl files and get meta info."""
        for i in self._data_paths:
            with open(i, "rb") as fin:
                pkl_dict = pickle.load(fin)

            local_meta_info_list = self.convert_clip_meta_into_frame_level(pkl_dict)
            self._meta_info_list.extend(local_meta_info_list)

    def get_temporal(
        self, image_tensor_list, raw_image_shape, meta_input, current_data
    ):
        """Get temporal func."""
        # Generate e2g and g2e from argus egomotion.
        adjacent_e2es = [
            (
                meta_input[idx + 1]["egomotion"][key_frame1 - key_frame2 - 1]
                @ meta_input[idx + 1]["egomotion"][-1]
            )
            for idx, (key_frame1, key_frame2) in enumerate(
                zip(self.key_frames[:-1], self.key_frames[1:])
            )
        ]
        ego2global_inv_list = [inverse_rt(meta_input[-1]["egomotion"][-1])]
        for adjacent_e2e in adjacent_e2es[::-1]:
            current_ego2global_inv = adjacent_e2e @ ego2global_inv_list[0]
            ego2global_inv_list = [current_ego2global_inv] + ego2global_inv_list
        ego2global_list = [
            inverse_rt(ego2global_inv) for ego2global_inv in ego2global_inv_list
        ]

        data_dict_list = []
        for i in range(len(self.key_frames)):
            sub_dict = {
                "image_tensor": (
                    image_tensor_list[i] if i < len(image_tensor_list) else None
                ),
                "raw_image_shape": raw_image_shape,
                "camera_ids": [
                    (self._pinhole_types + self._svc_types).index(j)
                    for j in self._cam_types
                ],
                "ego2global": torch.tensor(ego2global_list[i]),  # latest ts
                "ego2global_inv": torch.tensor(ego2global_inv_list[i]),  # latest ts
                "intrinsic": meta_input[i]["bev_intrinsic"],
                "extrinsic": meta_input[i]["extrinsic"],
                "valid_key_frame": [True for _ in meta_input],
                "gt": self.frame_sample(
                    sample_id=current_data["sample_id"],
                    mil_case_name=current_data["mil_case_name"],
                    mil_case_id=current_data["mil_case_id"],
                    **{
                        k: {"timestamp": (v["decode_timestamp"][i])}
                        for k, v in current_data["decode_video_meta_list"].items()
                    },
                    clip_id=current_data["clip_id"],
                ),
                "lidar2img": "",
                "lidar2cam": "",
                "od_gt_key_list": [],
                "use_last_feat": [],
                "enable_tasks": "",
                "valid_tasks": "",
                "seq_sample": "",
                "num_history_frames": "",
                "is_new_clip": [False for i in meta_input],
                "cam_types": self._cam_types,
                "label_file": "",
                "dataset_id": "",
                "cam_type_groups": "",
                "mpv_dict": "",
            }
            if self._transforms is not None:
                sub_dict = self._transforms(sub_dict)

            data_dict_list.append(sub_dict)

        stacked_data_dict: Dict[str, Any] = {}
        for key in data_dict_list[0]:

            if isinstance(data_dict_list[0][key], torch.Tensor):
                stacked_data_dict[key] = torch.stack(
                    [data_dict[key] for data_dict in data_dict_list], dim=0
                )
            elif isinstance(data_dict_list[0][key], np.ndarray):
                stacked_data_dict[key] = np.stack(
                    [data_dict[key] for data_dict in data_dict_list], axis=0
                )
            else:
                stacked_data_dict[key] = [
                    data_dict[key] for data_dict in data_dict_list
                ]
        return stacked_data_dict

    def get_single_frame(
        self, image_tensor_list, raw_image_shape, meta_input, current_data
    ):
        """Get single frame func."""
        data_dict = {
            "image_tensor": image_tensor_list[-1],
            "raw_image_shape": raw_image_shape,
            "camera_ids": [
                (self._pinhole_types + self._svc_types).index(i)
                for i in self._cam_types
            ],
            "intrinsic": meta_input[-1]["bev_intrinsic"],
            "extrinsic": meta_input[-1]["extrinsic"],
            "cam_types": self._cam_types,
            "label_file": "",
            "dataset_id": "",
            "lidar2img": "",
            "lidar2cam": "",
            "od_gt_key_list": [],
            "use_last_feat": [],
            "enable_tasks": "",
            "valid_tasks": "",
            "frame_sample": self.frame_sample(
                sample_id=current_data["sample_id"],
                mil_case_name=current_data["mil_case_name"],
                mil_case_id=current_data["mil_case_id"],
                **{
                    k: {"timestamp": v["decode_timestamp"][-1]}
                    for k, v in current_data["decode_video_meta_list"].items()
                },
                clip_id=current_data["clip_id"],
            ),
        }
        if self._transforms is not None:
            data_dict = self._transforms(data_dict)
        return data_dict

    def __getitem__(  # pylint: disable=too-many-branches,too-many-statements
        self, index
    ) -> Dict:
        """Get one item.

        Args:
            idx (int): index or dict.

        Returns:
            One data item, which only contains `image` .
        """
        if self._enable_prefetch_decoder:
            idx, image_tensor_list, _ = (
                index["default"]["idx"],
                index["default"]["decode_res"],
                index["default"]["ori_shape_res"],
            )
        else:
            idx = index

        current_data = self._meta_info_list[idx]
        meta_input = current_data["meta_input"]
        decode_video_meta = deepcopy(current_data["decode_video_meta_list"])
        # for streaming inference, we only need the last frame.
        if self.streaming_infer:
            for cam in decode_video_meta:
                decode_video_meta[cam]["decode_timestamp"] = decode_video_meta[cam][
                    "decode_timestamp"
                ][-1:]
                decode_video_meta[cam]["decode_func_inputs"] = decode_video_meta[cam][
                    "decode_func_inputs"
                ][-1:]

        if not self._enable_prefetch_decoder:
            image_tensor_list = self.video_decode_images(
                # NOTE: stacked_data_dict need timestamp info, which would be change by
                # video decode.
                decode_video_meta=decode_video_meta,
                sensor_video_info_dict=current_data["sensor_video_info_dict"],
                data_type="dlb",
                idx=idx,
            )
        raw_image_shape = [
            tuple(current_data["sensor_video_info_dict"][cam_type]["shape"])
            for cam_type in self._cam_types
        ]

        if self.infer_task_type == InferTaskMode.TEMPORAL:
            stacked_data_dict = self.get_temporal(
                image_tensor_list, raw_image_shape, meta_input, current_data
            )
        elif self.infer_task_type == InferTaskMode.SINGLE_FRAME:
            stacked_data_dict = self.get_single_frame(
                image_tensor_list, raw_image_shape, meta_input, current_data
            )
        else:
            raise NotImplementedError()
        return stacked_data_dict

    def convert_clip_meta_into_frame_level(self, meta_info_dict) -> List:
        """
        Convert clip meta into frame level.

        For argus meta, input pkl will be clip level. Need convert to frame level first.
        """
        meta_info_list = []

        for i in range(
            1 - self.temporal_window_size,
            len(meta_info_dict["raw_decode_video_meta_list"])
            - self.temporal_window_size
            + 1,
        ):
            key_frame_ids = [
                i + self.temporal_window_size + key_frame - 1
                for key_frame in self.key_frames
            ]

            meta_info = {
                "sensor_video_info_dict": meta_info_dict["sensor_video_info_dict"],
                "meta_input": [
                    meta_info_dict["raw_meta_input_list"][key_frame_id]
                    if key_frame_id >= 0
                    else create_meta_info_dict_none(
                        meta_info_dict["raw_meta_input_list"][0]
                    )
                    for key_frame_id in key_frame_ids
                ],
                "sample_id": f"{meta_info_dict['sample_id']}_{key_frame_ids[-1]}",
                "frame_idx_in_clip": i,
                "clip_id": meta_info_dict["sample_id"].rsplit("_", 1)[0],
            }

            decode_video_meta_list: Dict[str, Dict] = {
                k: {"decode_timestamp": [], "decode_func_inputs": []}
                for k in self._cam_types
            }

            for cam in self._cam_types:
                for key_frame_id in key_frame_ids:
                    if self._is_4k_camera(cam):
                        continue

                    decode_timestamp = (
                        meta_info_dict["raw_decode_video_meta_list"][key_frame_id][
                            cam
                        ].get("decode_timestamp", 0)
                        if key_frame_id >= 0
                        else 0
                    )

                    decode_video_meta_list[cam]["decode_timestamp"].append(
                        decode_timestamp
                    )

                    if decode_timestamp != 0:
                        decode_video_meta_list[cam]["decode_func_inputs"].append(
                            meta_info_dict["raw_decode_video_meta_list"][key_frame_id][
                                cam
                            ]["decode_func_inputs"]
                        )

                # remove same cut video path.
                decode_video_meta_list[cam]["decode_func_inputs"] = sorted(
                    (set(decode_video_meta_list[cam]["decode_func_inputs"])),
                    key=lambda x: int(x.split(" ")[-2]),
                )

            # 补齐16 cam
            for camera in ["fw", "fn", "fl", "fr", "rn"]:
                if f"{camera}_crop" in self._cam_types:
                    decode_video_meta_list[f"{camera}_crop"] = decode_video_meta_list[
                        camera
                    ]
                    meta_info["sensor_video_info_dict"][f"{camera}_crop"] = meta_info[
                        "sensor_video_info_dict"
                    ][camera]

            # NOTE: 图片/meta 输入顺序与 cam_types对应
            decode_video_meta_list = dict(
                sorted(
                    decode_video_meta_list.items(),
                    key=lambda x: self._cam_types.index(x[0]),  # sort by camera order
                )
            )

            meta_info["sensor_video_info_dict"] = dict(
                sorted(
                    meta_info["sensor_video_info_dict"].items(),
                    key=lambda x: self._cam_types.index(x[0]),  # sort by camera order
                )
            )

            meta_info["decode_video_meta_list"] = decode_video_meta_list
            meta_info["mil_case_id"] = meta_info_dict["mil_case_id"]
            meta_info["mil_case_name"] = meta_info_dict["mil_case_name"]
            meta_info_list.append(meta_info)

        return meta_info_list

    def __len__(self) -> int:
        """Get length."""
        return len(self._meta_info_list)

    def set_decode_queue(
        self,
        decode_meta_queue,
        decode_res_queue,
    ):
        """Set decode queue."""
        # pylint: disable=attribute-defined-outside-init
        self.decode_meta_queue = decode_meta_queue
        self.decode_res_queue = decode_res_queue

    def set_num_workers(
        self,
        num_workers,
    ):
        """Set num_workers."""
        # pylint: disable=attribute-defined-outside-init
        self.num_workers = num_workers
