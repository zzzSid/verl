# -*- coding: utf-8 -*-
"""Video BaseDataset."""

from abc import ABCMeta
from abc import abstractmethod
from typing import Tuple


class PrefetchDecodeInterface(metaclass=ABCMeta):
    """Prefetch decode interface."""

    @abstractmethod
    def get_prefetch_decoder_attrs(
        self,
        prefetch_decoder_using_mem_percent: float,
        batch_size: int,
        decoder_worker_num: int,
    ) -> Tuple:
        """Calculate prefetch decoder resource occupied.

        Args:
            prefetch_decoder_using_mem_percent (float): Percent of memory used by
            prefetch decoder.
            batch_size (int): batch size.
            decoder_worker_num (int): Decoder worker number.

        Returns:
            Tuple:
                prefetch_decoder_factor,
                buffer_num,
                pinhole_buffer_num,
                srcw_buffer_num,
                svc_buffer_num,
                pinhole_img_shape,
                svc_img_shape,
                prefetch_decoder_factor,
        """

    @abstractmethod
    def update_decode_res_to_index(
        self,
        _idx,
        index,
        max_retry_times,
        decoder_interactive_dict_list,
        shm_shapes,
        _id,
        device_id,
        global_rank,
    ):
        """Put decode result to index."""

    @abstractmethod
    def predecode_video_func(
        self,
        idx,
        bs_idx,
        device_id,
    ):
        """Prepare prefetch decode video func keywords."""

    @abstractmethod
    def decode_video_func_async(
        self,
        multi_decoder,
        shared_mem,
        _matching_dict_,
        _remap_dict,
        idx,
        bs_idx,
        cams_decode_res,
        _resume_dict,
        device_id,
        cams_deduplicate_decode_timestamp,
        thread_queue,
        worker_id,
        global_rank,
        **kwargs,
    ):
        """Decode video func. Note that it must be staticmethod.

        Args:
            sensor_video_info_dict: Dict[str, Any],
            decode_video_meta: Dict[str, Any],
            all_cam_types: List[str],
            local_rank: int,
            data_type: str,
            vt_meta_list: List[Dict[str, Any]],
            validate_mode: bool,
            get_raw_image_shape: bool,
            using_2k_video: bool,
            # The following input will be provided by dataloader
            multi_decoder: Dict[Tuple, VideoBufferDecoder],
            multi_convertor: Dict[Tuple, Convertor],
            cams_decode_key: Dict[str, Tuple],
            cams_removed_indices: Dict[str, List[int]],
            cams_deduplicate_decode_timestamp: Dict[str, List[int]],
            cams_video_path: List[str],
            cams_decode_res: Dict[str, List[Nv12DeviceFrame]],
            task_name: str,
            convertor_target_pinhole: Optional[Tuple[int]] = None,
            convertor_target_svc: Optional[Tuple[int]] = None,
        """
