# -*- coding: utf-8 -*-
"""TorchPilot BaseDataset."""

import logging
from abc import ABC
from abc import abstractmethod
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple
from typing import Union

from torch.utils.data import ConcatDataset
from torch.utils.data import Dataset
from torch.utils.data._utils.collate import default_collate
from torch.utils.data.dataset import T_co
from torchvision.transforms import Compose

from torchpilot.utils.dist_manager import get_global_rank
from torchpilot.utils.event_manager import EventManager
from torchpilot.utils.registries import TRANSFORM
from torchpilot.utils.settings import settings


logger = logging.getLogger(__name__)


class BaseDataset(Dataset[T_co], ABC):
    """An abstract class representing a :class:`Dataset`.

    All datasets that represent a map from keys to data samples should subclass
    it. All subclasses should overwrite :meth:`__getitem__`, supporting fetching a
    data sample for a given key. Different from torch, we recommend all subclass
    overwrite :meth:`__len__`, which is expected to return the size of the dataset by
    many :class:`~torch.utils.data.Sampler` implementations and the default options
    of :class:`~torch.utils.data.DataLoader`.

    Args:
        mode (str): Mode in _VALID_MODE.
        meta_file (str or None) : Meta file, expect Dict[str, Dict[str, List[str]]],
        transforms (list, dict or None): List of transforms.
        video_training_mode (bool): Enable video training mode, default is `False`.

    .. code-block:: python

        >>> meta_file={
        ...     'lidar'={
        ...         'train'=['train_meta_file1', 'train_meta_file1'...],
        ...         'val'=['val_meta_file1', 'val_meta_file1'...],
        ...         'test'=['test_meta_file1', 'test_meta_file1'...],
        ...     },
        ...     'camera'={...},
        ...     ...
        ... }.

    .. note::
        :class:`~torch.utils.data.DataLoader` by default constructs a index
        sampler that yields integral indices.  To make it work with a map-style
        dataset with non-integral indices/keys, a custom sampler must be provided.

    Example:
        See ``torchpilot/data/dataset/imagenet.py/ImageNetDataset``.
    """

    _VALID_MODE = (
        "train",
        "val",
        "test",
        "cicd_train",
        "cicd_infer",
        "tiny_infer",
    )

    def __init__(  # pylint: disable=dangerous-default-value
        self,
        mode: str,
        batch_size: int = None,
        num_workers: int = None,
        meta_file: Optional[Dict[str, Dict[str, List[str]]]] = None,
        transforms: Union[List[Any], Dict[str, Any], None] = None,
        video_training_mode: Optional[bool] = False,
        enable_prefetch_decoder: bool = False,
        multi_decoder: Dict[Tuple, Any] = {},
        multi_convertor: Dict[Tuple, Any] = {},
        cams_decode_res: Dict[str, Any] = {},
        cams_deduplicate_decode_timestamp: Dict[str, List[int]] = {},
        cams_removed_indices: Dict[str, List[int]] = {},
        cams_video_path: List[str] = [],
        cams_decode_key: Dict[str, Tuple] = {},
    ) -> None:
        """Init."""
        if mode not in self._VALID_MODE:
            logger.warning(
                "Expect mode in %s, but got %s.",
                str(self._VALID_MODE),
                mode,
            )
        self.log_callback = None
        self._mode = mode
        self._meta_file = meta_file
        self._enable_prefetch_decoder = enable_prefetch_decoder
        self._batch_size = batch_size
        self._num_workers = num_workers
        if transforms is None:
            self._transforms = None
        elif isinstance(transforms, dict):
            self._transforms = TRANSFORM.build(transforms)
        elif isinstance(transforms, list):
            _transforms = []
            for transform in transforms:
                _transforms.append(TRANSFORM.build(transform))
            self._transforms = Compose(_transforms)
        else:
            raise ValueError(
                f"Expect `type(transforms)` in (list, dict), if transforms is not "
                f"None, but got {type(transforms)}."
            )
        self.video_training_mode = video_training_mode
        self.multi_decoder = multi_decoder
        self.multi_convertor = multi_convertor
        self.cams_decode_res = cams_decode_res
        self.cams_deduplicate_decode_timestamp = cams_deduplicate_decode_timestamp
        self.cams_removed_indices = cams_removed_indices
        self.cams_video_path = cams_video_path
        self.cams_decode_key = cams_decode_key

    def get_decoder_kwargs(self, idx, device_id):  # pylint: disable=no-self-use
        """Get decoder kwargs."""
        del idx
        del device_id

    def check_idx_in_prefetch_decoder(self, idx):  # pylint: disable=no-self-use
        """Check idx in prefetch decoder."""
        del idx
        return True

    def set_log_callback(self, callback_func):
        """Set log callback."""
        self.log_callback = callback_func

    @abstractmethod
    def __getitem__(self, index: int) -> T_co:
        """Get one data item."""
        raise NotImplementedError()

    def __add__(self, other: "Dataset[T_co]") -> "ConcatDataset[T_co]":
        """Concat Datasets."""
        return ConcatDataset([self, other])

    @abstractmethod
    def __len__(self) -> int:
        """Return the size of the dataset."""
        raise NotImplementedError()

    def __getstate__(self):
        """Getstate for serialization."""
        if not self._enable_prefetch_decoder:
            for decoder in self.multi_decoder.values():
                decoder.get_all_decoded_frame()
            self.multi_decoder.clear()
            self.multi_convertor.clear()
            self.cams_decode_res.clear()
            self.cams_deduplicate_decode_timestamp.clear()
            self.cams_removed_indices.clear()
            self.cams_video_path.clear()
            self.cams_decode_key.clear()
        return self.__dict__

    def __setstate__(self, state):
        """Setstate for deserialization."""
        self.__dict__.update(state)

    @staticmethod
    def batch_collate(data: List[Any]) -> Any:
        """Batch collate function.

        Args:
            data (List): List of `__getitem__` returns.
        """
        return default_collate(data)

    def get_sample_weight(self) -> Union[List[float], Dict[str, List[float]]]:
        """Get sample weight.

        Returns:
            List of float or {str, List of float} pairs: each element in list
            corresponds to the sampling weight of the current index element.
            Default same probability for each sample.

        """
        return [1.0] * len(self)

    def get_labeling_task_ids(self) -> List[str]:  # pylint: disable=no-self-use
        """Get labeling task ids.

        The default return is empty list. And it should be overridden by subclasses.
        Return empty list now to avoid breaking incompatible training tasks.

        Returns:
            List of str: each element is a labeling task id.
        """
        return []

    def send_data_cost(self) -> None:
        """Send data cost to kafka for downstream processing."""
        if not settings.event_tagging_cost:
            logger.info("Skip sending data cost according to settings.")
            return

        if get_global_rank() != 0:
            logger.info("Only send data cost on rank 0, skipping.")
            return

        EventManager.put(
            {
                "type": "tagging_cost",
                "labeling_task_ids": self.get_labeling_task_ids(),
            }
        )


class BaseVideoDataset(BaseDataset):
    """BaseVideoDataset."""

    def __init__(
        self,
        mode: str = "train",
        transforms: Union[List[Any], Dict[str, Any], None] = None,
        group_num: int = 10,
        video_shuffle: bool = False,
        frame_sample_per_video: int = 200,
        **kwargs,
    ) -> None:
        """Init."""
        super().__init__(
            mode=mode,
            transforms=transforms,
            **kwargs,
        )
        self._group_num = group_num
        self._video_shuffle = video_shuffle
        self._frame_sample_per_video = frame_sample_per_video

    @abstractmethod
    def shuffle_and_init_video_list(self, epoch: int):
        """Reshuffle."""
        raise NotImplementedError()

    @property
    def group_num(self):
        """Return group num."""
        return self._group_num
