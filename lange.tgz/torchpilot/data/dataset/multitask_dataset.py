# -*- coding: utf-8 -*-
"""MultiTask dataset."""

import logging
import random
from itertools import cycle
from itertools import islice
from typing import Any
from typing import Dict
from typing import List
from typing import Tuple

from torch.utils.data._utils.collate import default_collate

from torchpilot.data.dataset.base_dataset import BaseDataset
from torchpilot.utils.registries import DATASET


logger = logging.getLogger(__name__)


class MultiTaskDataset(BaseDataset):
    """MultiTask Dataset.

    Args:
        mode (str): Mode in _VALID_MODE.
        datasets (Dict[str, Dict[str, Any]]): (task_name, task_dataset_cfg) pairs.
        enable_tasks (Tuple[str, ...]): Enable tasks.
        fetch_until_success (bool): Whether to fetch dataset until success or raise
            Error.
    """

    def __init__(
        self,
        mode: str,
        datasets_cfg: Dict[str, Dict[str, Any]],
        enable_tasks: Tuple[str, ...],
        batch_size: int = None,
        num_workers: int = None,
        fetch_until_success: bool = False,
        **kwargs,
    ):
        """Init."""
        super().__init__(
            mode=mode,
            batch_size=batch_size,
            num_workers=num_workers,
            **kwargs,
        )
        self.log_callback = None
        self._task_datasets: Dict[str, BaseDataset] = {}
        self._len_datasets: Dict[str, int] = {}
        self._len_datasets_each_rank: Dict[str, int] = {}
        self._enable_tasks = enable_tasks
        self._fetch_until_success = fetch_until_success

        for task_name in self._enable_tasks:
            if task_name not in datasets_cfg:
                raise ValueError(
                    f"Enable task `{task_name}` but key `{task_name}` not in "
                    f"datasets_cfg.keys(): {datasets_cfg.keys()}."
                )
            if mode:
                logger.warning(
                    "Specify '%s' as %s dataset mode.",
                    mode,
                    task_name,
                )
                datasets_cfg[task_name]["mode"] = mode
            datasets_cfg[task_name]["batch_size"] = batch_size
            datasets_cfg[task_name]["num_workers"] = num_workers
            datasets_cfg[task_name]["multi_decoder"] = self.multi_decoder
            datasets_cfg[task_name]["multi_convertor"] = self.multi_convertor
            datasets_cfg[task_name]["cams_decode_res"] = self.cams_decode_res
            datasets_cfg[task_name][
                "cams_deduplicate_decode_timestamp"
            ] = self.cams_deduplicate_decode_timestamp
            datasets_cfg[task_name]["cams_removed_indices"] = self.cams_removed_indices
            datasets_cfg[task_name]["cams_video_path"] = self.cams_video_path
            datasets_cfg[task_name]["cams_decode_key"] = self.cams_decode_key

            task_dataset = DATASET.build(datasets_cfg[task_name])
            if not isinstance(task_dataset, BaseDataset):
                raise ValueError(
                    f"Expect type(dataset)=BaseDataset but got {type(task_dataset)}."
                )
            if not hasattr(task_dataset, "task_name"):
                setattr(task_dataset, "task_name", task_name)
            self._task_datasets[task_name] = task_dataset
            self._len_datasets[task_name] = len(task_dataset)
            if hasattr(task_dataset, "get_rank_dataset_len"):
                self._len_datasets_each_rank[
                    task_name
                ] = task_dataset.get_rank_dataset_len()
            else:
                self._len_datasets_each_rank[task_name] = len(task_dataset)
            logger.warning(
                "%s total datasize is %d and each rank datasize is %d",
                task_name,
                self._len_datasets[task_name],
                self._len_datasets_each_rank[task_name],
            )

        self._task_names = list(self._task_datasets.keys())
        self._sub_dataset_max_length = max(self._len_datasets.values())

    @staticmethod
    def decode_video_func(
        multi_decoder,
        multi_convertor,
        **kwargs,
    ):
        """Decode video func.

        Args:
            multi_decoder (_type_): _description_
            multi_convertor (_type_): _description_
        """
        raise NotImplementedError()
        # if "task_name" not in kwargs:
        #     raise KeyError("Except task_name in decode video inputs.")
        # TASK_VIDEO_DECODE_FUNC(kwargs['task_name'])(**kwargs)

    def set_decode_queue(
        self,
        decode_meta_queue,
        decode_res_queue,
    ):
        """Set decode queue.

        Args:
            decode_meta_queue (_type_): _description_
            decode_res_queue (_type_): _description_
        """
        for task_dataset in self._task_datasets.values():
            if hasattr(task_dataset, "set_decode_queue"):
                task_dataset.set_decode_queue(
                    decode_meta_queue=decode_meta_queue,
                    decode_res_queue=decode_res_queue,
                )
            else:
                task_dataset.decode_meta_queue = decode_meta_queue
                task_dataset.decode_res_queue = decode_res_queue

    def set_num_workers(
        self,
        num_workers,
    ):
        """Set num_workers.

        Args:
            num_workers (int): Num workers.
        """
        for task_dataset in self._task_datasets.values():
            if hasattr(task_dataset, "set_num_workers"):
                task_dataset.set_num_workers(
                    num_workers=num_workers,
                )
            else:
                task_dataset.num_workers = num_workers

    def set_log_callback(self, callback_func):
        """Set log callback."""
        self.log_callback = callback_func
        for _, task in self._task_datasets.items():
            task.set_log_callback(callback_func)

    def __getitem__(  # type: ignore[override]
        self,
        index: Dict[str, Any],
    ) -> Dict[str, Dict[str, Any]]:
        """Get one item.

        Args:
            idx (Dict[str, int]): The {task_name, index} pairs.

        Returns:
            {task_name, task_data_dict} pairs.
        """
        # For pythonic.
        if self._fetch_until_success:
            data_dict: Dict[str, Dict[str, Any]] = {}
            for task_name, task_idx in index.items():
                get_item_success = False
                task_dataset = self._task_datasets[task_name]
                while not get_item_success:
                    try:
                        data_dict[task_name] = task_dataset[
                            task_idx % self._len_datasets_each_rank[task_name]
                        ]
                        get_item_success = True
                    except Exception as ex:  # pylint: disable=broad-except
                        ex_message = ex.args[0] if len(ex.args) > 0 else ""
                        logger.warning(
                            "%s get item idx %d failed, try to get next one. "
                            "Error message: %s",
                            task_name,
                            task_idx,
                            ex_message,
                        )
                        task_idx = random.randint(
                            0, self._len_datasets_each_rank[task_name]
                        )
                        continue
            return data_dict

        if self._enable_prefetch_decoder:
            return {
                task_name: self._task_datasets[task_name][idx_with_decoder_res]
                for task_name, idx_with_decoder_res in index.items()
            }

        return {
            task_name: self._task_datasets[task_name][
                task_idx % self._len_datasets_each_rank[task_name]
            ]
            for task_name, task_idx in index.items()
        }

    def __len__(self) -> int:
        """Return the max length of sub datasets as the length of multitask dataset."""
        return self._sub_dataset_max_length

    @staticmethod
    def batch_collate(data: List[Any]) -> Dict[str, Dict[str, Any]]:
        """Collate function for current dataset.

        Args:
            data (List[Dict[str, Dict[str, Any]]]): List of map-style data. Each item is
                dict, each dict is (task_name, task_data_dict) pairs.

        Returns:
            Dict[str, Dict[str, Any]] each item is (task_name, task_batched_data_dict).

        Note:
            If the sub dataset has a custom batch collate function, override this batch
            collate function is needed. Here is an example
            ```
                multitask_batched_data: Dict[str, Dict[str, Any]] = {}
                task_list_data: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
                for _data in data:
                    for task_name, task_data in _data:
                        task_list_data[task_name].append(task_data)

                for task_name, _task_list_data in task_list_data.items():
                    multitask_batched_data[task_name] = BATCH_COLLATES_FUNCTIONS.get(
                        task_name, default_collate
                    )(_task_list_data)

                for task_name, task_batched_data in data_dict.items():
                    task_batched_data["task_name"] = task_name
                return data_dict
            ```
            It should be noted that BATCH_COLLATES_FUNCTIONS is a
            {task_name, task_dataset.batch_collate} pairs.
        """
        # For pythonic.
        data_dict = {
            task_name: default_collate(
                [multitask_data[task_name] for multitask_data in data]
            )
            for task_name in data[0].keys()
        }

        # Add task_name key in task_batch.
        for task_name, task_batched_data in data_dict.items():
            task_batched_data["task_name"] = task_name
        return data_dict

    @property
    def task_names(self) -> List[str]:
        """Get num task."""
        return self._task_names

    @property
    def task_datasets(self):
        """Get task datasets."""
        return self._task_datasets

    def get_sample_weight(self) -> Dict[str, List[float]]:
        """Get sample weight.

        Returns:
            {task_name, task_weight} pairs, each task_weight is List of float, each
            element corresponds to the sampling weight of the current index element.
        """
        sample_weight = {}
        for task_name, task_dataset in self._task_datasets.items():
            task_sample_weight = task_dataset.get_sample_weight()
            if len(task_sample_weight) != len(task_dataset):
                raise ValueError(
                    f"Expect len(task_sample_weight)==len(task_dataset) but got "
                    f"len(task_sample_weight)={len(task_sample_weight)}, "
                    f"len(task_dataset)={len(task_dataset)}, task_name={task_name}."
                )
            # Repeat task_sample_weight fill to len(self).
            sample_weight[task_name] = list(
                islice(cycle(task_sample_weight), len(self))
            )
        return sample_weight  # type: ignore[return-value]

    def get_labeling_task_ids(self) -> List[str]:  # pylint: disable=no-self-use
        """Get labeling task ids.

        The default return is the combination of task datasets.
        It should be overridden if necessary.

        Returns:
            List of str: each element is a labeling task id.
        """
        labeling_task_ids = set()
        for _, task_dataset in self._task_datasets.items():
            labeling_task_ids |= set(task_dataset.get_labeling_task_ids())
        return list(labeling_task_ids)
