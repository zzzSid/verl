# -*- coding: utf-8 -*-
"""Torchpilot MultiTask DataLoader."""

import logging
from typing import Any
from typing import Dict

from torchpilot.data.dataloader.tp_dataloader import TPDataLoader
from torchpilot.data.dataset.multitask_dataset import MultiTaskDataset


logger = logging.getLogger(__name__)


class MultiTaskDataLoader(TPDataLoader):
    """MultiTask DataLoader."""

    def move_data_to_cuda(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Move data to cuda.

        Args:
            data Dict[str, Any]: Data to move.

        Returns:
            data Dict[str, Any]: Data on cuda.
        """
        if isinstance(self.dataset, MultiTaskDataset):
            for task_name, task_batch in data.items():
                self.stopwatch.set_time_cost_prefix(task_name)
                data[task_name] = super().move_data_to_cuda(task_batch)
            self.stopwatch.reset_time_cost_prefix()
        else:
            data = super().move_data_to_cuda(data)

        return data
