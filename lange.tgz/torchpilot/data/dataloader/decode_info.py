# -*- coding: utf-8 -*-
"""DecodedInfo."""
from collections import OrderedDict
from typing import Dict
from typing import List
from typing import Optional


# pylint: disable=too-many-branches, invalid-name, line-too-long
# pylint: disable=too-many-instance-attributes, consider-using-f-string


class DecodedInfo:
    """
    Class to track decoding status and statistics for video streams.

    Attributes:
        name (str): The name of the instance.
        worker_id (int): The ID of the worker processing the instance.
        rank_id (int): The rank ID of the instance.
        tgt_decode_num (int): Target number of decodes, defaults to -1.
        is_finished (bool): Whether the decoding process is finished.
        decoded_cam (List[str]): List of decoded camera types.
        _start_time (Dict[str, float]): Start times for each camera type.
        _end_time (Dict[str, float]): End times for each camera type.
        video_buffer_error (Dict[str, str]): Video buffer error messages.
        decode_error (Dict[str, str]): Decode error messages.
        total_decode_time (float): Total decoding time.
    """

    def __init__(
        self, name: str, worker_id: int, rank_id: int, tgt_decode_num: int = -1
    ):
        """Init."""
        self.name = name
        self.worker_id = worker_id
        self.rank_id = rank_id
        self.tgt_decode_num = tgt_decode_num
        self.is_finished = False
        self.decoded_cam: List[str] = []
        self._start_time: Dict[str, float] = OrderedDict()
        self._decode_done_time: Dict[str, float] = OrderedDict()
        self._convert_done_time: Dict[str, float] = OrderedDict()
        self._end_time: Dict[str, float] = OrderedDict()
        self.video_buffer_error: Dict[str, str] = OrderedDict()
        self.decode_error: Dict[str, str] = OrderedDict()
        self.readcacheop_error: Optional[str] = ""
        self.total_decode_time: float = 0.0
        self.torch_worker_start_time: Dict[str, float] = OrderedDict()
        self.torch_worker_finish_time: Dict[str, float] = OrderedDict()
        self.torch_worker_entry_time: float = 0.0
        self.torch_worker_end_time: float = 0.0
        self.item_ready_time: float = 0.0

    def _set_cur_index_end_time(self, cam_type: str, time: float) -> None:
        """Set end time."""
        if cam_type in self._end_time:
            raise ValueError(f"Duplicated cam found in end_time: {cam_type}.")
        self._end_time[cam_type] = time

    def set_cur_index_start_time(self, cam_type: str, time: float) -> None:
        """Set start time."""
        if cam_type in self._start_time:
            raise ValueError(
                f"Duplicated {cam_type} found in start_time for {self.name}."
            )
        self._start_time[cam_type] = time

    def update_stats(self, cam_type: str, time: float) -> None:
        """Update."""
        self.decoded_cam.append(cam_type)
        if cam_type not in self._start_time:
            raise ValueError(f"cam decode end before start time: {self._start_time}.")
        self._set_cur_index_end_time(cam_type, time)

    def set_convert_done_time(self, cam_type, time):
        """Set convert done time."""
        self._convert_done_time[cam_type] = time

    def set_decode_done_time(self, cam_type, time):
        """Set decode done time."""
        self._decode_done_time[cam_type] = time

    def set_tgt_decode_num(self, tgt_decode_num: int) -> None:
        """Set target num."""
        self.tgt_decode_num = tgt_decode_num

    def set_video_buffer_error(self, cam_type: str, err_msg: str) -> None:
        """Set error msg."""
        self.video_buffer_error[cam_type] = err_msg

    def set_decode_error(self, cam_type: str, err_msg: str) -> None:
        """Set error msg."""
        self.decode_error[cam_type] = err_msg

    def set_readcacheop_error(self, err_msg: Optional[str]) -> None:
        """Set error msg."""
        self.readcacheop_error = err_msg

    def check_is_finished(self) -> bool:
        """Check Status."""
        if self.tgt_decode_num == len(self.decoded_cam):
            self.is_finished = True
            last_value = list(self._end_time.values())[-1]
            first_value = list(self._start_time.values())[0]
            self.total_decode_time = last_value - first_value
            self.item_ready_time = last_value

        return self.is_finished

    def set_torch_worker_start_time(self, cam_type, time):
        """Set each cam start time."""
        self.torch_worker_start_time[cam_type] = time

    def set_torch_worker_finish_time(self, cam_type, time):
        """Set each cam end time."""
        self.torch_worker_finish_time[cam_type] = time

    def set_torch_worker_entry_time(self, time):
        """Set index entry time."""
        self.torch_worker_entry_time = time

    def set_torch_worker_end_time(self, time):
        """Set index finished time."""
        self.torch_worker_end_time = time

    def __str__(self) -> str:
        """Generate a string representation of the DecodedInfo object."""
        result = [
            f"Rank ID: {self.rank_id}, Worker ID: {self.worker_id},  Name: {self.name} \
            global_rank|device_id|task_name|task_idx|global_idx|bs_idx|sub_idx",
            f"Target Decode Number: {self.tgt_decode_num}",
            f"Is Finished: {self.is_finished}",
            f"Total decode time cost: {self.total_decode_time}",
            f"decode res waiting for torch worker (higher is better): {self.torch_worker_entry_time - self.item_ready_time}",  # noqa: E501
            f"Time spent by Torch worker on (shm + communication) (lower is better): {self.torch_worker_end_time - self.torch_worker_entry_time}",  # noqa: E501
        ]

        result.append(
            f"Decoded Cameras: {', '.join(self.decoded_cam) if self.decoded_cam else 'None'}"  # noqa: E501
        )

        result.append(
            "{:<10} {:>15} {:>15} {:>15} {:>15} {:>15}".format(  # noqa: FS002
                "Camera",
                "Start",
                "Decode cost",
                "Convert cost",
                "Total cost",
                "Shm cost",
            )
        )

        result.append("-" * 120)

        for cam in sorted(
            set(self._start_time)
            | set(self._decode_done_time)
            | set(self._convert_done_time)
            | set(self._end_time)
        ):
            start = self._start_time.get(cam, None)
            decode = self._decode_done_time.get(cam, None)
            convert = self._convert_done_time.get(cam, None)
            end = self._end_time.get(cam, None)

            torch_worker_start = self.torch_worker_start_time.get(cam, None)
            torch_worker_finish = self.torch_worker_finish_time.get(cam, None)

            decode_time = (decode - start) if (decode and start) else None
            convert_time = (convert - decode) if (convert and decode) else None
            end_time = (end - start) if (end and start) else None
            process_time = (
                (torch_worker_finish - torch_worker_start)
                if (torch_worker_start and torch_worker_finish)
                else None
            )

            result.append(
                "{:<10} {:>15.5f} {:>15.5f} {:>15.5f} {:>15.5f} {:>15.5f}".format(  # noqa: FS002, E501
                    cam,
                    start if start else 0,
                    decode_time if decode_time else 0,
                    convert_time if convert_time else 0,
                    end_time if end_time else 0,
                    process_time if process_time else 0,
                )
            )

        if self.video_buffer_error:
            buffer_errors = "\n    ".join(
                f"{cam}: {msg}" for cam, msg in self.video_buffer_error.items()
            )
            result.append(f"Video Buffer Errors:\n    {buffer_errors}")
        else:
            result.append("Video Buffer Errors: None")

        if self.decode_error:
            decode_errors = "\n    ".join(
                f"{cam}: {msg}" for cam, msg in self.decode_error.items()
            )
            result.append(f"Decode Errors:\n    {decode_errors}")
        else:
            result.append("Decode Errors: None")

        if self.readcacheop_error:
            result.append(f"Read Cache Errors:\n    {self.readcacheop_error}")
        else:
            result.append("Read Cache Errors: None")

        return "\n".join(result)
