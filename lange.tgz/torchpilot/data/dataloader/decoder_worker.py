# -*- coding: utf-8 -*-
"""Decoder worker."""
import logging
import queue
import threading
from dataclasses import dataclass
from multiprocessing import shared_memory
from typing import Any
from typing import Dict
from typing import List
from typing import Tuple
from collections import OrderedDict
import time

import numpy as np
import torch
import torch.multiprocessing
import torch.multiprocessing.queue
from torch.utils.data._utils import MP_STATUS_CHECK_INTERVAL
from torch.utils.data._utils import signal_handling
from torchpilot.data.dataloader import torch_worker
from torchpilot.logging.message_type import StatusEnum

# pylint: skip-file
# flake8: noqa

logger = logging.getLogger(__name__)


get_worker_info = torch_worker.get_worker_info


def create_log_callback(decode_info_queue):
    """
    Factory function to create a callback with a specific queue.
    """

    def log_callback(key, value, _type):
        """
        key: normally idx or idx_{cam_type}
        value: data.
        type: could be exception.
        """
        decode_info_queue.put((key, value, _type))

    return log_callback


def _set_shm_loop(
    in_queue, done_event, _matching_dict, shm_shapes, worker_id, device_id, log_callback
):
    """为了保证 shm index 可追溯 / decoder在reinit之后shm的一致性 所有的通信操作放到队列执行."""
    _send_idx_svc, _send_idx_scrw, _send_idx_pinhole = 0, 0, 0
    shm_pinhole_shape, shm_svc_shape, shm_srcw_shape = shm_shapes

    while not done_event.is_set():
        try:
            r = in_queue.get(timeout=MP_STATUS_CHECK_INTERVAL)
        except queue.Empty:
            continue

        if not done_event.is_set():
            if len(r) == 3:
                key, value, _type = r
                if log_callback is not None:
                    log_callback(key, value, _type)
                continue

            key_list, ndarray, cam_type, shm_name, ori_shape = r
            if not isinstance(key_list, tuple):
                key_list = [key_list]
            existing_shm = shared_memory.SharedMemory(name=shm_name)
            for key in key_list:
                if cam_type in ("sfw", "slw", "srw"):
                    shm_ndarray_3 = np.ndarray(
                        shm_svc_shape,
                        dtype=np.uint8,
                        buffer=existing_shm.buf,
                    )
                    if ndarray is None:
                        ndarray = np.zeros(shm_svc_shape[1:], dtype=np.uint8)
                    shm_ndarray_3[_send_idx_svc % shm_svc_shape[0]] = ndarray
                    v = {
                        "idx": _send_idx_svc % shm_svc_shape[0],
                        "shm_name": shm_name,
                        "ori_shape": ori_shape,
                    }
                    _send_idx_svc += 1
                elif cam_type in ("srcw",):
                    shm_ndarray_1 = np.ndarray(
                        shm_srcw_shape,
                        dtype=np.uint8,
                        buffer=existing_shm.buf,
                    )
                    if ndarray is None:
                        ndarray = np.zeros(shm_srcw_shape[1:], dtype=np.uint8)
                    shm_ndarray_1[_send_idx_scrw % shm_srcw_shape[0]] = ndarray
                    v = {
                        "idx": _send_idx_scrw % shm_srcw_shape[0],
                        "shm_name": shm_name,
                        "ori_shape": ori_shape,
                    }
                    _send_idx_scrw += 1
                else:
                    shm_ndarray_12 = np.ndarray(
                        shm_pinhole_shape,
                        dtype=np.uint8,
                        buffer=existing_shm.buf,
                    )
                    if ndarray is None:
                        ndarray = np.zeros(shm_pinhole_shape[1:], dtype=np.uint8)
                    shm_ndarray_12[_send_idx_pinhole % shm_pinhole_shape[0]] = ndarray
                    v = {
                        "idx": _send_idx_pinhole % shm_pinhole_shape[0],
                        "shm_name": shm_name,
                        "ori_shape": ori_shape,
                    }
                    _send_idx_pinhole += 1

                _matching_dict[key] = v
                if log_callback is not None:
                    log_callback(
                        "__".join(key.split("__")[:-1]) + "___" + key.split("__")[-1],
                        time.time(),
                        StatusEnum.FINISH,
                    )
            existing_shm.close()

        del r  # save memory


def _load_s3_loop(
    input_queue,
    out_queue,
    done_event,
    load_s3_func,
    device_id,
    global_rank,
):
    while not done_event.is_set():
        try:
            r = input_queue.get(timeout=MP_STATUS_CHECK_INTERVAL)

            if isinstance(r, tuple):
                idx, index = r
                for bs_idx, idx_dict in enumerate(index):
                    # format: idx[task_name] = {'task_idx':task_idx, 'decoder_kwargs':decoder_kwargs}
                    load_s3_func(idx_dict, bs_idx, device_id)

            out_queue.put(r)

        except queue.Empty:
            pass


@dataclass(frozen=True)
class _ResumeIteration(object):
    """Dummy class used to resume the fetching when worker reuse is enabled"""

    pass


def decoder_loop_prefetch_decoder(
    dataset,
    index_queue,
    shared_mem,
    decoder_data_dict,
    done_event,
    device_id,
    global_rank,
    decode_video_func,
    decoder_resume_queue,
    worker_id,
    shm_shapes,
    decode_info_queue,
):
    """Decoder loop."""
    try:
        signal_handling._set_worker_signal_handlers()
        torch.cuda.set_device(device_id)

        watchdog = torch_worker.ManagerWatchdog()
        multi_decoder: Dict[Tuple, Any] = {}
        cams_decode_res = {}
        _remap_dict = {}
        cams_deduplicate_decode_timestamp = {}
        _resume_dict = {"_resume_idx_pinhole": 0, "_resume_idx_svc": 0}
        if decode_info_queue is not None:
            log_callback = create_log_callback(decode_info_queue)
            if getattr(dataset, "set_log_callback", None):
                dataset.set_log_callback(log_callback)

        # Queue is not type-annotated
        _decode_res_queue = queue.Queue()  # type: ignore[var-annotated]
        # add a thread for each decoder
        _set_shm_thread_done_event = threading.Event()
        set_shm_thread = threading.Thread(
            target=_set_shm_loop,
            args=(
                _decode_res_queue,
                _set_shm_thread_done_event,
                decoder_data_dict,
                shm_shapes,
                worker_id,
                device_id,
                log_callback if decode_info_queue is not None else None,
            ),
        )
        set_shm_thread.daemon = True
        set_shm_thread.start()

        _load3_queue = queue.Queue(maxsize=5)  # type: ignore[var-annotated]
        _set_load_s3_thread_done_event = threading.Event()

        # add a thread for each decoder
        load_s3_thread = threading.Thread(
            target=_load_s3_loop,
            args=(
                index_queue,
                _load3_queue,
                _set_load_s3_thread_done_event,
                dataset.predecode_video_func,
                device_id,
                global_rank,
            ),
        )
        load_s3_thread.daemon = True
        load_s3_thread.start()

        while watchdog.is_alive():
            try:
                r = _load3_queue.get(timeout=MP_STATUS_CHECK_INTERVAL)
            except queue.Empty:
                continue

            if isinstance(r, _ResumeIteration):
                # Acknowledge the main process
                for _, _decoder in multi_decoder.items():
                    _decoder.get_all_decoded_frame()
                decoder_resume_queue.put((r, None))

                # resume represent new epoch, clear all except decoder
                cams_decode_res.clear()
                cams_deduplicate_decode_timestamp.clear()
                _remap_dict.clear()
                continue
            elif r == "StopIteration":
                # decoder_sampler_iter raise StopIteration
                for _, _decoder in multi_decoder.items():
                    _decoder.get_all_decoded_frame()
                continue
            elif r is None:
                # Received the final signal
                assert done_event.is_set()
                multi_decoder.clear()
                cams_decode_res.clear()
                _remap_dict.clear()
                set_shm_thread.join()
                _set_shm_thread_done_event.set()
                _set_load_s3_thread_done_event.set()
                break
            elif done_event.is_set():
                # `done_event` is set. But I haven't received the final signal
                # (None) yet. I will keep continuing until get it, and skip the
                # processing steps.
                continue

            (
                idx,
                index,
            ) = r  # eg. index [{'marker3d':100, 'sod':200, 'od':300}, {'marker3d':100, 'sod':200, 'od':300}]

            for bs_idx, idx_dict in enumerate(index):
                decode_video_func(
                    multi_decoder=multi_decoder,
                    shared_mem=shared_mem,
                    _matching_dict_=decoder_data_dict,
                    _remap_dict=_remap_dict,
                    idx=idx_dict,
                    bs_idx=bs_idx,
                    cams_decode_res=cams_decode_res,
                    _resume_dict=_resume_dict,
                    device_id=device_id,
                    global_rank=global_rank,
                    cams_deduplicate_decode_timestamp=cams_deduplicate_decode_timestamp,
                    thread_queue=_decode_res_queue,
                    worker_id=worker_id,
                )

            del idx, index, r  # save memory
    except KeyboardInterrupt:
        # Main process will raise KeyboardInterrupt anyways.
        pass


def decoder_loop_shared_decoder(
    in_queue_list,
    out_queue_list,
    device_id,
    done_event,
    decode_video_func,
):
    # This setting is thread local, and prevents the copy in pin_memory from
    # consuming all CPU cores.
    # torch.set_num_threads(1)
    torch.cuda.set_device(device_id)
    multi_decoder: Dict[Tuple, Any] = {}  # VideoBufferDecoder
    multi_convertor: Dict[Tuple, Any] = {}  # Convertor
    cams_decode_key: Dict[str, Tuple] = {}  # to save each cam's decode key
    cams_removed_indices: Dict[
        str, List[int]
    ] = {}  # to save each cam's removed indices
    cams_deduplicate_decode_timestamp: Dict[str, List[int]] = {}
    cams_video_path: List[str] = []
    cams_decode_res: Dict[str, List[Any]] = {}  # Nv12DeviceFrame
    try:
        # Initialize C side signal handlers for SIGBUS and SIGSEGV. Python signal
        # module's handlers are executed after Python returns from C low-level
        # handlers, likely when the same fatal signal had already happened
        # again.
        # https://docs.python.org/3/library/signal.html#execution-of-python-signal-handlers
        signal_handling._set_worker_signal_handlers()

        torch.set_num_threads(1)
        np_seed = torch_worker._generate_state(666, 666)
        import numpy as np

        np.random.seed(np_seed)

        watchdog = torch_worker.ManagerWatchdog()

        while watchdog.is_alive():
            for in_queue, out_queue in zip(in_queue_list, out_queue_list):
                try:
                    idx, kwargs = in_queue.get(timeout=MP_STATUS_CHECK_INTERVAL)
                except queue.Empty:
                    continue
                try:
                    # decode_res = torch.tensor(decode_meta).cuda().cpu()
                    decode_res = decode_video_func(
                        multi_decoder=multi_decoder,
                        multi_convertor=multi_convertor,
                        **kwargs,
                        cams_decode_key=cams_decode_key,
                        cams_removed_indices=cams_removed_indices,
                        cams_deduplicate_decode_timestamp=cams_deduplicate_decode_timestamp,
                        cams_video_path=cams_video_path,
                        cams_decode_res=cams_decode_res,
                    )
                except Exception as e:
                    out_queue.put((idx, e))
                    del kwargs  # save memory  # NOTE: dict release？
                    continue
                out_queue.put((idx, decode_res))
                del decode_res, kwargs  # save memory  # NOTE: dict release？
    except KeyboardInterrupt:
        # Main process will raise KeyboardInterrupt anyways.
        pass
    if done_event.is_set():
        in_queue.cancel_join_thread()
        out_queue.cancel_join_thread()
        in_queue.close()
        out_queue.close()
