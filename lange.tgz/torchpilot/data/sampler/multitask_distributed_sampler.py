# -*- coding: utf-8 -*-
"""MultiTask distributed sampler."""
import logging
import math
from itertools import cycle
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple
from typing import Union

import numpy as np
import torch

from torchpilot.data.dataset.base_dataset import BaseVideoDataset
from torchpilot.data.sampler.tp_distributed_sampler import TPDistributedSampler
from torchpilot.data.sampler.tp_distributed_video_sampler import (
    TPDistributedVideoSampler,
)


logger = logging.getLogger(__name__)

# pylint: disable=too-many-branches,too-many-nested-blocks.


def get_indices_len(indices: Union[Dict, List]):
    """Get indices' length."""
    if isinstance(indices, list):
        indices_len = len(indices)
    else:
        indices_len = max(len(task_indices) for task_indices in indices.values())
    return indices_len


def slice_indices(indices, start_idx, end_idx):
    """Slice indices."""
    if isinstance(indices, list):
        return indices[start_idx:end_idx]
    for task_name, task_indices in indices.items():
        indices[task_name] = task_indices[start_idx:end_idx]
    return indices


def padding_indices(indices, target_len, padding_value: Optional[int] = None):
    """Pad indices."""
    if isinstance(indices, np.ndarray):
        indices = indices.tolist()
    if isinstance(indices, list):
        indices_len = len(indices)
        if target_len <= indices_len:
            # no need to padding
            return indices
        padding_size = target_len - len(indices)
        if padding_value is not None:
            # use a number as padding value
            indices += [padding_value] * padding_size
            return indices
        # use original value as padding value
        if padding_size <= indices_len:
            indices += indices[:padding_size]
        else:
            indices += (indices * math.ceil(padding_size / indices_len))[:padding_size]
        return indices
    if isinstance(indices, dict):
        for task_name, task_indices in indices.items():
            indices[task_name] = padding_indices(
                task_indices, target_len, padding_value
            )
        return indices
    raise NotImplementedError(f"Unsupported type {type(indices)}")


class MultiTaskDistributedSampler(TPDistributedSampler):
    """MultiTaskDistributedSampler."""

    def __init__(
        self,
        *args,
        valid_task_loop: Tuple[Tuple[str, ...], ...] = None,
        **kwargs,
    ) -> None:
        """Init."""
        super().__init__(*args, **kwargs)
        for task_name, task_dataset in self._dataset.task_datasets.items():
            if (
                isinstance(task_dataset, BaseVideoDataset)
                and self._batch_size > task_dataset.group_num
            ):
                raise ValueError(
                    f"Expect group_num >= batch_size, task name is {task_name}."
                )

        self._valid_task_loop: Optional[List[Tuple[str, ...]]] = None
        if valid_task_loop is not None:
            if (
                not isinstance(valid_task_loop, tuple)
                or not isinstance(valid_task_loop[0], tuple)
                or not isinstance(valid_task_loop[0][0], str)
            ):
                raise ValueError("Expect valid_task_loop is tuple of tuple of str.")

            # Batch level sampling valid tasks.
            self._valid_task_loop = []
            for valid_tasks in valid_task_loop:
                self._valid_task_loop.extend((valid_tasks,) * self._batch_size)

    def indices_sampling_per_rank_hook(
        self, indices: List[Dict[str, int]]
    ) -> List[Dict[str, int]]:
        """Sample valid task.

        Args:
            indices (List[Dict[str, int]]): Indices to sampling.

        Returns:
            indices (List[Dict[str, int]]): Indices to sampled.
        """
        if self._valid_task_loop is None:
            return indices

        new_indices: List[Dict[str, int]] = []
        for idx, valid_tasks in zip(indices, cycle(self._valid_task_loop)):
            new_indices.append({task: idx[task] for task in valid_tasks})
        return new_indices

    def _generate_indices(self):
        """Generate indices.

        Returns:
            If self._indices is not None, return self._indices, else return multitask
            indices (List[Dict[str, int]]) each item is (task_name, task_index) pairs.
        """
        # Init.
        group_indices: Dict[str, Dict[int, List[int]]] = {}

        if self._indices is not None:
            for task_name, task_dataset in self._dataset.task_datasets.items():
                if isinstance(task_dataset, BaseVideoDataset):
                    raise NotImplementedError(
                        f"{task_name} is video dataset, which is not implemented in"
                        " MultiTaskDistributedSampler."
                    )
            if self._shuffle:
                np.random.seed(seed=self._epoch + self._seed)
                np.random.shuffle(self._indices)
                indices = self._indices
            else:
                indices = self._indices
        else:
            # WARNING: Do not use [{}] * len(self._dataset) to avoid pass by reference.
            indices: List[Dict[str, int]] = [{} for _ in range(len(self._dataset))]
            for seed_bias, (task_name, task_dataset) in enumerate(
                self._dataset.task_datasets.items()
            ):
                if isinstance(task_dataset, BaseVideoDataset):
                    group_indices[
                        task_name
                    ] = TPDistributedVideoSampler.generate_group_shuffle_indices(
                        seed=self._seed + seed_bias,
                        epoch=self._epoch,
                        group_num=task_dataset.group_num,
                        batch_size=self._batch_size,
                        num_samples=self._num_samples,
                        num_replicas=self._num_replicas,
                        shuffle=self._shuffle,
                        drop_last=self.drop_last,
                    )
                else:
                    if not self._shuffle:
                        logger.warning(
                            "Weighted sampling indices is disabled because of "
                            "self._shuffle=False."
                        )
                        task_indices = list(range(len(self._dataset)))
                        for task_name in self._dataset.task_names:
                            for i, task_index in enumerate(task_indices):
                                indices[i][task_name] = task_index
                    else:
                        # Loop each task to generate task-wise indices.
                        task_shuffle_seed = self._seed + self._epoch + seed_bias
                        dataset_size = len(self._dataset)
                        sample_weight = self._dataset.get_sample_weight()[task_name]
                        if len(sample_weight) != len(self._dataset):
                            raise ValueError(
                                f"Expect len(sample_weight)==len(self._dataset) but got"
                                f" len(sample_weight)={len(sample_weight)}, "
                                f"len(self._dataset)={len(self._dataset)}."
                            )
                        same_weight = len(set(sample_weight)) == 1

                        if hasattr(task_dataset, "get_indices"):
                            task_dataset.batch_size = self._batch_size  # Temporal hack.
                            task_dataset.num_workers = (
                                self._num_workers
                            )  # Temporal hack.
                            task_indices = task_dataset.get_indices(
                                task_shuffle_seed,
                                len(self._dataset),
                            )
                        else:
                            if dataset_size >= (2**24):
                                # Note(yuxiang.yan): torch would raise
                                # `RuntimeError: number of categories cannot exceed
                                # 2^24` if dataset_size >= (2**24), this is a known
                                # issues on github, more details at
                                # `https://github.com/pytorch/pytorch/issues/2576`
                                if not same_weight:
                                    raise RuntimeError(
                                        "Weighted sample is not supported if dataset"
                                        "size >= (2**24). Note: torch would raise "
                                        "`RuntimeError: number of categories cannot "
                                        "exceed 2^24 if dataset_size >= (2**24), this "
                                        "is a known issues on github, more details at "
                                        "`https://github.com/pytorch/pytorch/issues/"
                                        "2576`"
                                    )
                                np.random.seed(task_shuffle_seed)
                                task_indices = np.random.permutation(dataset_size)
                            else:
                                # Deterministically shuffle based on epoch and seed.
                                t_generator = torch.Generator()
                                t_generator.manual_seed(task_shuffle_seed)
                                # Sampling without replacement if sampling weight is all
                                # the same.
                                replacement = not same_weight
                                task_indices = torch.multinomial(
                                    torch.tensor(sample_weight).float(),
                                    len(self._dataset),
                                    replacement=replacement,
                                    generator=t_generator,
                                ).tolist()

                        for i, task_index in enumerate(task_indices):
                            indices[i][task_name] = task_index

        return indices, group_indices

    def __iter__(self):
        """Overwrite iter."""
        indices, group_indices = self._generate_indices()
        if indices:
            if isinstance(indices, dict):
                invalid_pad_value = -1
                # padding each task indices to same len
                indices_max_len = get_indices_len(indices)
                padding_indices(
                    indices, target_len=indices_max_len, padding_value=invalid_pad_value
                )
            if not self._drop_last:
                # add extra samples to make it evenly divisible
                indices = padding_indices(indices, target_len=self._total_size)
            else:
                # remove tail of data to make it evenly divisible.
                indices = slice_indices(indices, start_idx=0, end_idx=self._total_size)

            if get_indices_len(indices) != self._total_size:
                raise RuntimeError(
                    f"Expect indices_len == self.total_size, but got "
                    f"indices_len={get_indices_len(indices)}, "
                    f"self.total_size={self._total_size}.",
                )

            # subsample
            offset = self._num_samples * self._rank
            indices = slice_indices(
                indices, start_idx=offset, end_idx=offset + self._num_samples
            )

            if isinstance(indices, dict):
                indices_max_len = get_indices_len(indices)
                # dict of list -> list of dict
                indices = [
                    {
                        task_name: task_indices[i]
                        for task_name, task_indices in indices.items()
                        if task_indices[i] != invalid_pad_value
                    }
                    for i in range(indices_max_len)
                ]

            if len(indices) != self._num_samples:
                raise RuntimeError(
                    f"Expect len(indices) == self._num_samples, but got "
                    f"len(indices)={len(indices)}, "
                    f"self.num_samples={self._num_samples}",
                )

        if group_indices:
            if not self._drop_last:
                raise NotImplementedError(
                    "If using video dataset, set drop last to true."
                )
            for task_name, task_group_indices in group_indices.items():
                if len(task_group_indices[0]) != self._num_samples:
                    raise RuntimeError(
                        f"Expect len(task_group_indices[0]) == self._num_samples, but "
                        f"got len(task_group_indices[0])={len(task_group_indices[0])}, "
                        f"self.num_samples={self._num_samples}",
                    )
                if len(task_group_indices[0]) * self._num_replicas != self._total_size:
                    raise RuntimeError(
                        f"Expect len(indices[0]) * self._num_replicas == "
                        f"self.total_size, but got len(indices)={len(indices)}, "
                        f"self.total_size={self._total_size}. Task name is {task_name}",
                    )
                cur_rank_group_indices = task_group_indices[self._rank]
                for idx, group_index in enumerate(cur_rank_group_indices):
                    indices[idx][task_name] = group_index

        # Resume.
        indices = indices[self._step * self._batch_size :]

        indices = self.indices_sampling_per_rank_hook(indices)
        self._step = 0

        return iter(indices)


class MultiTaskDistributedSamplerPrefetchDecoder(MultiTaskDistributedSampler):
    """MultiTaskDistributedSamplerPrefetchDecoder."""

    def __init__(
        self,
        *args,
        valid_task_loop: Tuple[Tuple[str, ...], ...] = None,
        **kwargs,
    ) -> None:
        """Init."""
        super().__init__(*args, **kwargs)
        self.iter_cnt = 0

    def __iter__(self):  # pylint: disable=too-many-branches
        """Overwrite iter."""
        indices, group_indices = self._generate_indices()

        if indices:
            if not self._drop_last:
                # add extra samples to make it evenly divisible
                padding_size = self._total_size - len(indices)
                if padding_size <= len(indices):
                    indices += indices[:padding_size]
                else:
                    indices += (indices * math.ceil(padding_size / len(indices)))[
                        :padding_size
                    ]
            else:
                # remove tail of data to make it evenly divisible.
                indices = indices[: self._total_size]

            if len(indices) != self._total_size:
                raise RuntimeError(
                    f"Expect len(indices) == self.total_size, but got "
                    f"len(indices)={len(indices)}, "
                    f"self.total_size={self._total_size}.",
                )

            # subsample
            offset = self._num_samples * self._rank
            indices = indices[offset : offset + self._num_samples]
            if len(indices) != self._num_samples:
                raise RuntimeError(
                    f"Expect len(indices) == self._num_samples, but got "
                    f"len(indices)={len(indices)}, "
                    f"self.num_samples={self._num_samples}",
                )

        if group_indices:
            if not self._drop_last:
                raise NotImplementedError(
                    "If using video dataset, set drop last to true."
                )
            for task_name, task_group_indices in group_indices.items():
                if len(task_group_indices[0]) != self._num_samples:
                    raise RuntimeError(
                        f"Expect len(task_group_indices[0]) == self._num_samples, but "
                        f"got len(task_group_indices[0])={len(task_group_indices[0])}, "
                        f"self.num_samples={self._num_samples}",
                    )
                if len(task_group_indices[0]) * self._num_replicas != self._total_size:
                    raise RuntimeError(
                        f"Expect len(indices[0]) * self._num_replicas == "
                        f"self.total_size, but got len(indices)={len(indices)}, "
                        f"self.total_size={self._total_size}. Task name is {task_name}",
                    )
                cur_rank_group_indices = task_group_indices[self._rank]
                for idx, group_index in enumerate(cur_rank_group_indices):
                    indices[idx][task_name] = group_index

        # Resume.
        indices = indices[self._step * self._batch_size :]

        indices = self.indices_sampling_per_rank_hook(indices)

        self.iter_cnt += 1

        if self.iter_cnt == 2:
            self.iter_cnt = 0
            self._step = 0

        return iter(indices)
