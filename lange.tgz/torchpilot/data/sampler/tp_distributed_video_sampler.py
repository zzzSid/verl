# -*- coding: utf-8 -*-
"""TorchPilot Distributed Video Sampler."""

import logging
import random
from typing import List

import numpy as np

from torchpilot.data.sampler.tp_distributed_sampler import TPDistributedSampler


logger = logging.getLogger(__name__)


class TPDistributedVideoSampler(TPDistributedSampler):
    """Sampler that restricts data loading to a subset of the dataset.

    Args:
        Group: Video decoder group number.
    """

    def __init__(  # pylint: disable=super-init-not-called
        self,
        *args,
        group_num: int,
        **kwargs,
    ):
        """TPDistributedVideoSampler."""
        super().__init__(*args, **kwargs)
        self._group_num = group_num
        if self._batch_size > self._group_num:
            raise ValueError("Expect group_num >= batch_size.")

    # pylint: disable=too-many-branches,too-many-nested-blocks.
    @staticmethod
    def generate_group_shuffle_indices(
        seed: int,
        epoch: int,
        group_num: int,
        batch_size: int,
        num_samples: int,
        num_replicas: int,
        shuffle: bool,
        drop_last: bool,
    ):
        """Generate group shuffle indices."""
        indices = {}
        for cur_rank in range(num_replicas):
            if not shuffle:
                logger.warning(
                    "Weighted sampling indices is disabled because of "
                    "self._shuffle=False."
                )
                cur_rank_indices = list(range(group_num)) * (num_samples // group_num)
            else:
                shuffle_seed = seed + epoch + cur_rank
                np.random.seed(shuffle_seed)
                random.seed(shuffle_seed)

                # Initialize the output list
                cur_rank_indices = []

                # Check whether it's possible to avoid repetition in consecutive batches
                can_avoid_repetition = group_num >= 2 * batch_size

                # Init batch size num.
                batch_size_num = int(num_samples / batch_size + 1)

                # Process each batch
                if can_avoid_repetition:
                    # Initialize the candidate group elements
                    group_indices = list(range(group_num))
                    last_batch: List[int] = []

                    for _ in range(batch_size_num):
                        while True:
                            # Check if the group elements have all been used
                            if len(group_indices) < batch_size:
                                # If they are all used, regenerate the group elements
                                group_indices = list(range(group_num))
                                # Remove the selected elements from the group elements
                                for item in last_batch:
                                    group_indices.remove(item)
                            # Randomly select batch_size elements from the group
                            # elements, without replacement
                            batch = random.sample(group_indices, batch_size)

                            # There are no duplicate elements between the two groups.
                            if len(set(batch) & set(last_batch)) > 0:
                                continue

                            # Add these elements to the output list
                            cur_rank_indices.extend(batch)
                            # Record the current batch
                            last_batch = batch
                            break

                        # Remove the selected elements from the group elements
                        for item in last_batch:
                            group_indices.remove(item)
                else:
                    group_indices = np.arange(group_num)
                    for _ in range(batch_size_num):
                        cur_rank_indices.extend(
                            np.random.choice(
                                group_indices, batch_size, replace=False
                            ).tolist()
                        )

            if not drop_last:
                raise NotImplementedError("NotImplemented.")
            cur_rank_indices = cur_rank_indices[:num_samples]

            indices[cur_rank] = cur_rank_indices

        return indices  # Dict[int, List[int]]

    # pylint: disable=too-many-nested-blocks,too-many-branches
    def _generate_indices(self):
        """Generate indices.

        Returns:
            If self._indices is not None, return self._indices, else return
            Union[List[int], List[Dict[str, int]]].
        """
        if self._indices is not None:
            raise NotImplementedError()
        return self.generate_group_shuffle_indices(
            seed=self._seed,
            epoch=self._epoch,
            group_num=self._group_num,
            batch_size=self._batch_size,
            num_samples=self._num_samples,
            num_replicas=self._num_replicas,
            shuffle=self._shuffle,
            drop_last=self._drop_last,
        )

    def __iter__(self):
        """Overwrite iter."""
        indices = self._generate_indices()

        if len(indices[0]) * self._num_replicas != self._total_size:
            raise RuntimeError(
                f"Expect len(indices[0]) * self._num_replicas == self.total_size, "
                f"but got len(indices)={len(indices)}, "
                f"self.total_size={self._total_size}.",
            )

        # subsample
        indices = indices[self._rank]
        indices = self.indices_sampling_per_rank_hook(indices)
        self._step = 0

        return iter(indices)

    def set_epoch(self, epoch: int) -> None:
        """Set the epoch for this sampler.

        When :attr:`shuffle=True`, this ensures all replicas use a different random
        ordering for each epoch. Otherwise, the next iteration of this sampler will
        yield the same ordering.

        Args:
            epoch (int): Epoch number.
        """
        if not isinstance(epoch, int) or epoch < 0:
            raise ValueError(
                f"Expect epoch is a non-negative integer integer, bug got {epoch}."
            )

        self._epoch = epoch

        if self._shuffle:
            if not hasattr(self._dataset, "shuffle_and_init_video_list"):
                raise NotImplementedError("Expect dataset has shuffle_video method.")
            self._dataset.shuffle_and_init_video_list(epoch)
