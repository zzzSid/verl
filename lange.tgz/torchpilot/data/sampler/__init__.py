# -*- coding: utf-8 -*-
"""TorchPilot sampler packages."""

import logging
import random
from typing import List

import numpy as np
import torch.distributed as dist
from tqdm import tqdm


logger = logging.getLogger(__name__)


def shuffle_gop_aware_indices(  # pylint: disable=too-many-branches
    gop_aware_idx_list: List[List[int]],
    seed: int,
    batch_size: int,
    skip_iter: int,
    num_workers: int,
    cache_cnt: int,
    mixed_cache_policy: bool = True,
):
    """Shuffle gop aware indices.

    0) 如果不采用 mixed cache policy, 则只保留可以恰好缓存 cache_cnt 个 frame 的 gop, 并统计
        丢弃的 frame 个数，在最终的 shuffle list 末尾补齐.
    1) 将每个 gop 内当前帧的 index 和要 cache 的 index 打包到一个小 list 中, 并将所有候选 list
        放到一个大 list 中, 最终形成 list of gop idx list。由于部分任务的数据 interval 后只有
        少量来自于同一个 gop, 因此定义 cache 的个数定义为最大 cache 个数, 而非固定 cache 个数。
        当 cache cnt 为 2 时, 这个 list 可能是 [[0, 1, 2],  [140], [7, 8, 9], [21, 22]...],
        其中 0 就是当前 index, 1, 2 就是要 cache 的 index
    2) 为了保证一个 gop 的数据出现在同一 worker 中的指定连续个 batch 中,
        提出 worker_aware_batch_idx_item 概念, 即针对每个 worker 的连续 batch 分别处理,
        同时为了避免一个 gop 内的数据出现在同一个 batch, 也需要对每个 batch 的不同 idx 拆分处理;
        如 num_worker 为 2, batch size 为 2 时, 对于 0 号 worker 连续 batch 的 0 号位和 1 号
        位分别处理, 生成 0 号 worker 对应 batch 0 号位的 index 结果 list 和 batch 1 号位的
        index 结果 list, 1 号 worker 同理，后续进行拼接。
    3) 对于 batch n 号位的当前帧, 随机从 1)中的 list 选取一组 idx, 并且将当前帧加入到当前 batch n
        号位的结果 list 中, 同时将需要 cache 的 idx 放到对应 batch n 号位的 cache queue 中备用。
    4) 当达到 skip iter (即一个 gop 内 cache 的帧间隔多少 iter 后继续使用),
        对 2)中 batch idx n 的 cache queue 做如下处理, 对于所有被 cache 的第一帧陆续加入到
        batch idx n 的结果 list 中, 第二种陆续放入 batch idx n 的结果 list 中,
        直到当前 cache queue 中的所有元素都被消耗完。
    5) 循环 3)4)直到1)的所有元素被消耗完。
    6) 将 worker aware batch n 号位的结果 list 陆续拼接到最终的结果 list 中。
        原则是循环 pop 0 号元素, 直到被消耗完。
    7) 最终结果就达到了下图效果, 即通过配置 cache cnt、skip iter 和 batch size,
        实现一个 gop cache 的元素可以陆续出现在间隔 skip iter 个的 batch 中。

    Args:
        gop_aware_idx_list (List[List[int]]): List of gop indices,  each gop indices is
            a list of index,  contains all indexes in the gop.
        seed (int): Shuffle seed.
        batch_size (int): Batch size.
        skip_iter (int): Batch wise interval between consecutive occurrences of data
            within a gop.
        num_workers (int): Num of dataloader workers.
        cache_cnt (int): Num of cache cnt.
        mixed_cache_policy (bool): Enable mixed cache policy or not.
    """
    # 0. Check each cache cnt.
    if not mixed_cache_policy:
        logger.warning("Do not use mixed cache policy, filter out gop list.")
        total_size = 0
        for gop_aware_idx in gop_aware_idx_list:
            total_size += len(gop_aware_idx)

        gop_aware_idx_list = [
            gop_aware_idx
            for gop_aware_idx in gop_aware_idx_list
            if len(gop_aware_idx) == cache_cnt + 1
        ]

    # 1. Shuffle each gop indices.
    np.random.seed(seed)
    random.seed(seed)

    # 2. Init worker aware batch item queue.
    worker_aware_batch_size = batch_size * num_workers
    batch_item_idx_queue_list: List[List[List[int]]] = [
        [[] for __ in range(cache_cnt)] for _ in range(worker_aware_batch_size)
    ]
    batch_item_idx_list: List[List[int]] = [[] for _ in range(worker_aware_batch_size)]

    # 3. 无放回随机采样 gop_aware_idx_list
    idx_list = list(range(len(gop_aware_idx_list)))
    random.shuffle(idx_list)
    skip_iter_cnt = -1
    for _ in range(len(gop_aware_idx_list) // worker_aware_batch_size):
        for batch_item_idx, batch_item_idx_queue in zip(
            batch_item_idx_list, batch_item_idx_queue_list
        ):
            if not idx_list:
                break
            gop_idx = idx_list.pop(0)
            batch_item_idx.append(gop_aware_idx_list[gop_idx][0])
            cur_gop_catch_idx_list = gop_aware_idx_list[gop_idx][1:]
            for batch_item_idx_queue_cache, cur_gop_catch_idx in zip(
                batch_item_idx_queue,
                cur_gop_catch_idx_list,
            ):
                batch_item_idx_queue_cache.append(cur_gop_catch_idx)

        skip_iter_cnt += 1
        if skip_iter_cnt == skip_iter:
            for batch_item_idx, batch_item_idx_queue in zip(
                batch_item_idx_list, batch_item_idx_queue_list
            ):
                for batch_item_idx_queue_cache in batch_item_idx_queue:
                    for _ in range(len(batch_item_idx_queue_cache)):
                        batch_item_idx.append(batch_item_idx_queue_cache.pop(0))
            skip_iter_cnt = -1

    # 清空 queue list
    for batch_item_idx, batch_item_idx_queue in zip(
        batch_item_idx_list, batch_item_idx_queue_list
    ):
        for _ in range(len(batch_item_idx_queue[0])):
            for batch_item_idx_queue_cache in batch_item_idx_queue:
                if batch_item_idx_queue_cache:
                    batch_item_idx.append(batch_item_idx_queue_cache.pop(0))

    # Idx result.
    idx_result = []
    for i in range(
        max(  # pylint: disable=consider-using-generator
            [len(batch_item_idx) for batch_item_idx in batch_item_idx_list]
        )
    ):
        for batch_item_idx in batch_item_idx_list:
            if i < len(batch_item_idx):
                idx_result.append(batch_item_idx[i])

    # 补充
    if not mixed_cache_policy:
        if total_size < len(idx_result):
            raise ValueError()
        idx_result = idx_result + idx_result[: total_size - len(idx_result)]

    return idx_result


# pylint: disable=consider-using-generator
def shuffle_subclip_aware_indices(  # pylint: disable=too-many-branches
    subclip_aware_idx_list: List[List[int]],
    seed: int,
    batch_size: int,
    num_workers: int,
    with_worker_split: bool = True,
    with_rank_split: bool = True,
):
    """Subclip shuffle."""
    if with_worker_split and with_rank_split:
        raise ValueError(
            "with_worker_split and with_rank_split cannot be True at the same time."
        )

    world_size = dist.get_world_size() if dist.is_available() else 1
    if batch_size * world_size > len(subclip_aware_idx_list):
        raise ValueError(
            "Unable to distribute subclips evenly, reduce batch_size/rank or "
            "increase the number of subclips."
        )

    # 1. Shuffle each gop indices.
    np.random.seed(seed)
    random.seed(seed)

    # 2. Init worker aware batch item queue.
    if with_worker_split:
        worker_aware_batch_size = batch_size * num_workers
    elif with_rank_split:
        worker_aware_batch_size = batch_size * world_size
    else:
        worker_aware_batch_size = batch_size
    batch_item_idx_list: List[List[int]] = [[] for _ in range(worker_aware_batch_size)]

    # 3. 无放回随机采样 shuffle_subclip_aware_indices
    idx_list = list(range(len(subclip_aware_idx_list)))
    random.shuffle(idx_list)
    for _ in range(len(subclip_aware_idx_list) // worker_aware_batch_size):
        for batch_item_idx in batch_item_idx_list:
            if not idx_list:
                break
            gop_idx = idx_list.pop(0)
            batch_item_idx.extend(subclip_aware_idx_list[gop_idx])

    # Idx result.
    idx_result = []
    if with_rank_split:
        # 4. 补齐每个 batch_item_idx_list 的长度，使其等长
        max_len = max(  # pylint: disable=consider-using-generator
            [len(batch_item_idx) for batch_item_idx in batch_item_idx_list]
        )
        for i, batch_item_idx in enumerate(batch_item_idx_list):
            logger.warning(
                "For batch_idx_list %s, "
                "the completion length is %s, original length is %s",
                i,
                max_len - len(batch_item_idx),
                len(batch_item_idx),
            )
            while len(batch_item_idx) < max_len:
                batch_item_idx = (
                    batch_item_idx[
                        : min(max_len - len(batch_item_idx), len(batch_item_idx))
                    ]
                    + batch_item_idx
                )
            batch_item_idx_list[i] = batch_item_idx

        # 将 batch_item_idx_list 回退到 batch size 个
        _batch_item_idx_list: List[List[int]] = [[] for _ in range(batch_size)]
        for i in range(batch_size):
            for j in range(world_size):
                _batch_item_idx_list[i] += batch_item_idx_list[i * world_size + j]
        batch_item_idx_list = _batch_item_idx_list

    for i in tqdm(
        range(
            max(  # pylint: disable=consider-using-generator
                [len(batch_item_idx) for batch_item_idx in batch_item_idx_list]
            )
        )
    ):
        for batch_item_idx in batch_item_idx_list:
            if i < len(batch_item_idx):
                idx_result.append(batch_item_idx[i])

    if not with_rank_split:
        idx_result = (
            idx_result
            + idx_result[
                : sum([len(i) for i in subclip_aware_idx_list]) - len(idx_result)
            ]
        )
    return idx_result
