# -*- coding: utf-8 -*-
"""MultiTask distributed sampler."""
import logging
from itertools import cycle
from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import torch

from torchpilot.data.dataset.multitask_dataset import MultiTaskDataset
from torchpilot.data.sampler.tp_distributed_sampler import TPDistributedSampler


logger = logging.getLogger(__name__)


class MultiTaskBatchedDistributedSampler(TPDistributedSampler):
    """MultiTaskBatchedDistributedSampler."""

    def __init__(
        self,
        *args,
        batch_size,
        valid_task_loop: Tuple[Tuple[str, ...], ...] = None,
        **kwargs,
    ) -> None:
        """Init."""
        super().__init__(*args, **kwargs)

        if not isinstance(self._dataset, (MultiTaskDataset)):
            raise ValueError(
                f"Expect type(self._dataset)=MultiTaskDataset but got "
                f"{type(self._dataset)}."
            )

        task_batch_size = batch_size
        if set(task_batch_size.keys()) != set(self._dataset.task_names):
            raise ValueError("Key diff.")
        if self._indices is not None:
            raise NotImplementedError()
        if not isinstance(task_batch_size, dict):
            raise NotImplementedError()
        if not self._drop_last:
            raise NotImplementedError()

        self._valid_task_loop: Optional[List[Tuple[str, ...]]] = None
        if valid_task_loop is not None:
            if (
                not isinstance(valid_task_loop, tuple)
                or not isinstance(valid_task_loop[0], tuple)
                or not isinstance(valid_task_loop[0][0], str)
            ):
                raise ValueError("Expect valid_task_loop is tuple of tuple of str.")

            # Batch level sampling valid tasks.
            self._valid_task_loop = []
            for valid_tasks in valid_task_loop:
                self._valid_task_loop.extend((valid_tasks,) * self._batch_size)

        if not isinstance(task_batch_size, dict):
            raise ValueError("Expect task_batch_size is {task_name, task_batch} pairs.")

        self._task_batch_size = task_batch_size

        # Generate task_indices.
        self.max_batched_sample = -1
        self._task_indices_len = {}
        for task_batch_size in self._task_batch_size.values():
            self.max_batched_sample = max(
                self.max_batched_sample, len(self._dataset) // task_batch_size
            )

        for task_name, task_batch_size in self._task_batch_size.items():
            self._task_indices_len[task_name] = (
                task_batch_size * self.max_batched_sample
            )

        self._num_samples = self.max_batched_sample // self._num_replicas

    def batch_indices(
        self,
        task_indices_dict,
    ):
        """TBD.

        Args:
            indices (_type_): _description_
        """
        indices: List[Dict[str, List[int]]] = [
            {} for _ in range(self.max_batched_sample)
        ]

        # Check step aligned.
        step_align_to = -1
        for task_name, task_indices_len in self._task_indices_len.items():
            task_batch_size = self._task_batch_size[task_name]
            task_indices = task_indices_dict[task_name]

            if len(task_indices) != task_indices_len:
                raise ValueError("Expect same.")
            if step_align_to == -1:
                step_align_to = task_indices_len / task_batch_size
            else:
                if task_indices_len / task_batch_size != step_align_to:
                    raise ValueError("Expect same.")

        for task_name, task_indices in task_indices_dict.items():
            task_batch_size = self._task_batch_size[task_name]
            _task_indices = [
                task_indices[i * task_batch_size : (i + 1) * task_batch_size]
                for i in range(self.max_batched_sample)
            ]

            for i, task_index in enumerate(_task_indices):
                indices[i][task_name] = task_index
        return indices

    def indices_sampling_per_rank_hook(
        self,
        indices: List[Dict[str, int]],
    ) -> List[Dict[str, int]]:
        """Sample valid task.

        Args:
            indices (List[Dict[str, int]]): Indices to sampling.

        Returns:
            indices (List[Dict[str, int]]): Indices to sampled.
        """
        if self._valid_task_loop is None:
            return indices

        new_indices: List[Dict[str, int]] = []
        for idx, valid_tasks in zip(indices, cycle(self._valid_task_loop)):
            new_indices.append({task: idx[task] for task in valid_tasks})
        return new_indices

    def _generate_indices(self):  # pylint: disable=too-many-branches.
        """Generate indices.

        Returns:
            If self._indices is not None, return self._indices, else return multitask
            indices (List[Dict[str, int]]) each item is (task_name, task_index) pairs.
        """
        raise NotImplementedError()

    @staticmethod
    def _generate_task_indices(
        task_name,
        multitask_dataset,
        dataset_size,
        shuffle,
        seed,
        epoch,
        seed_bias,
    ):
        """Generate task indices."""
        if not shuffle:
            logger.warning(
                "Weighted sampling indices is disabled because of "
                "self._shuffle=False."
            )
            task_indices = list(range(dataset_size))
        else:
            # Loop each task to generate task-wise indices.
            task_shuffle_seed = seed + epoch + seed_bias
            sample_weight = multitask_dataset.get_sample_weight()[task_name]
            same_weight = len(set(sample_weight)) == 1
            if same_weight:
                sample_weight = [1.0] * dataset_size
            elif len(sample_weight) != dataset_size:
                raise ValueError(
                    f"Expect len(sample_weight)==dataset_size but got "
                    f"len(sample_weight)={len(sample_weight)}, "
                    f"dataset_size={dataset_size}."
                )

            task_dataset = multitask_dataset.task_datasets[task_name]
            if hasattr(task_dataset, "get_indices"):
                task_indices = task_dataset.get_indices(
                    task_shuffle_seed,
                    dataset_size,
                )
            else:
                if dataset_size >= (2**24):
                    # Note(yuxiang.yan): torch would raise
                    # `RuntimeError: number of categories cannot exceed 2^24` if
                    # dataset_size >= (2**24), this is a known issues on github,
                    # more details at
                    # `https://github.com/pytorch/pytorch/issues/2576`
                    if not same_weight:
                        raise RuntimeError(
                            "Weighted sample is not supported if dataset size >= "
                            "(2**24). Note: torch would raise "
                            "`RuntimeError: number of categories cannot exceed "
                            "2^24 if dataset_size >= (2**24), this is a known "
                            "issues on github, more details at "
                            "`https://github.com/pytorch/pytorch/issues/2576`"
                        )
                    np.random.seed(task_shuffle_seed)
                    task_indices = np.random.permutation(dataset_size)
                else:
                    # Deterministically shuffle based on epoch and seed.
                    t_generator = torch.Generator()
                    t_generator.manual_seed(task_shuffle_seed)
                    # Sampling without replacement if sampling weight is all
                    # the same.
                    replacement = not same_weight
                    task_indices = torch.multinomial(
                        torch.tensor(sample_weight).float(),
                        dataset_size,
                        replacement=replacement,
                        generator=t_generator,
                    ).tolist()
        return task_indices

    def __iter__(self):
        """Overwrite iter."""
        task_indices_dict: Dict[str, List[int]] = {}
        for seed_bias, (task_name, task_data_size) in enumerate(
            self._task_indices_len.items()
        ):
            task_indices_dict[task_name] = self._generate_task_indices(
                task_name,
                self._dataset,
                task_data_size,
                self._shuffle,
                self._seed,
                self._epoch,
                seed_bias,
            )

        indices = self.batch_indices(task_indices_dict)
        # per sample: {
        #   task_name: List[int]
        #   task_name: List[int]
        #   task_name: List[int]
        # }

        # remove tail of data to make it evenly divisible.
        indices = indices[: self._total_size]

        if len(indices) != self.max_batched_sample:
            raise RuntimeError(
                f"Expect len(indices) == self.max_batched_sample, but got "
                f"len(indices)={len(indices)}, "
                f"self.max_batched_sample={self.max_batched_sample}.",
            )

        # subsample
        offset = self._num_samples * self._rank
        indices = indices[offset : offset + self._num_samples]
        if len(indices) != self._num_samples:
            raise RuntimeError(
                f"Expect len(indices) == self._num_samples, but got "
                f"len(indices)={len(indices)}, "
                f"self.num_samples={self._num_samples}",
            )

        indices = indices[self._step * self._batch_size :]
        self._step = 0

        indices = self.indices_sampling_per_rank_hook(indices)

        return iter(indices)
