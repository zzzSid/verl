# -*- coding: utf-8 -*-
"""Command Line Interface for TorchPilot."""
from typing import List
from typing import Union

import click

from torchpilot.runner import ddp_launcher_run


CONTEXT_SETTINGS = {
    "help_option_names": ["-h", "--help"],
    "show_default": True,
}


@click.group(context_settings=CONTEXT_SETTINGS)
@click.version_option()
def cli() -> None:
    """Command Line Interface for TorchPilot."""


@cli.command()
@click.argument(
    "device-num",
    type=int,
)
@click.argument(
    "config",
    type=click.Path(exists=True),
)
@click.option(
    "-n",
    "--run-name",
    envvar="TORCHPILOT_RUN_NAME",
    help="The name of the run.",
)
@click.option(
    "-it",
    "--infer-type",
    type=click.Choice(["torch", "trace", "tvm"], case_sensitive=False),
    default=None,
    help="Specify the type of infer model file, support [torch, trace, tvm].",
)
@click.option(
    "-et",
    "--export-type",
    type=click.Choice(["trace"], case_sensitive=False),
    default=None,
    help="Specify the type of export model file, support [trace] only currently.",
)
@click.option(
    "-c",
    "--ckpt",
    default=None,
    multiple=True,
    help="Specify the ckpt list for inferring.",
)
@click.option(
    "-r",
    "--resume",
    is_flag=True,
    help="Whether to continue transmission at breakpoint.",
)
@click.option(
    "-p",
    "--port",
    type=click.IntRange(1024, 65535),
    envvar="TORCHPILOT_PORT",
    show_default="random integer",
    help="Specify the port of TCP for the distributed communication.",
)
@click.option(
    "-dm",
    "--dataset-mode",
    type=str,
    default=None,
    help="Specify the dataset mode for training or inferring.",
)
def run(
    device_num: int,
    config: str,
    run_name: str,
    infer_type: str,
    export_type: str,
    ckpt: Union[None, str, List[str]],
    resume: bool,
    port: int,
    dataset_mode: str,
) -> None:
    """Entry for torchpilot transmits variables from here."""
    ddp_launcher_run.run(
        device_num,
        config,
        run_name,
        infer_type,
        export_type,
        ckpt,
        resume,
        port,
        dataset_mode,
    )
