# -*- coding: utf-8 -*-
"""Checkpoint tools."""
import json
import logging
import os
from typing import Dict
from typing import Tuple

import click

from torchpilot.cli import cli
from torchpilot.utils.checkpoint_manager import load_checkpoint


logger = logging.getLogger(__name__)


class CheckpointMappingTools:
    """Tools of checkpoint to mapping keys.

    Args:
        ckpt_path (str): Path to checkpoint.
        dump_dir (str): Directory to dump json file.
        replace (Tuple[str, str] or None): If set, receive Tuple(A: str, B: str),
            and replace A to B. Default=`None`.
        prefix (str or None): If set, update prefix. Default=`None`.

    Image we have checkpoint like this.

    .. code-block:: python

        >>> import torch
        >>> checkpoint = torch.load(
        ...    "/share-global/yuxiang.yan/torchpilot/cicd/checkpoint_cicd.pth.tar")
        >>> checkpoint.keys()
        ... dict_keys(['epoch', 'step', 'model', 'optimizer', 'lr_scheduler'])
        >>> checkpoint['model'].keys()
        ... odict_keys(['_task_model._backbone.base_model.conv1.weight',
        ...            '_task_model._backbone.base_model.bn1.weight',
        ...            '_task_model._backbone.base_model.bn1.bias',
        ...            '_task_model._backbone.base_model.bn1.running_mean',
        ...           ...])

    If you want to replace `_task_model._backbone` to `my_model`, you should
    do:

    .. code-block:: python

        >>> cd /path/to/torchpilot/tools
        >>> python3 checkpoint_tools.py -m -cp /path/to/ckpt -dd /path/to/dump/json
        ... -r _task_model._backbone my_model

    Then you will get a json file at `/path/to/dump/json/ckpt2model_mapping.json`:

    .. code-block:: python

        >>> import json
        >>> with open('/path/to/dump/json/ckpt2model_mapping.json', 'r') as f:
        ...     json_dict = json.load(f)
        >>> json_dict
        ... {
        ...    '_task_model._backbone.base_model.conv1.weight':
        ...        'my_model.base_model.conv1.weight',
        ...    '_task_model._backbone.base_model.bn1.weight':
        ...        'my_model.base_model.bn1.weight',
        ...    '_task_model._backbone.base_model.bn1.bias':
        ...        'my_model.base_model.bn1.bias',
        ...    '_task_model._backbone.base_model.bn1.running_mean':
        ...        'my_model.base_model.bn1.running_mean',
        ...    ...
        ... }


    If you want to add `module.` at each head of keys, you should do:

    .. code-block:: python

        >>> cd /path/to/torchpilot/tools
        >>> python3 checkpoint_tools.py -m -cp /path/to/ckpt -dd /path/to/dump/json -p
        ... module.

    Then you will get a json file at `/path/to/dump/json/ckpt2model_mapping.json`:

    .. code-block:: python

        >>> import json
        >>> with open('/path/to/dump/json/ckpt2model_mapping.json', 'r') as f:
        ...     json_dict = json.load(f)
        >>> json_dict
        ... {
        ...    '_task_model._backbone.base_model.conv1.weight':
        ...        'module._task_model._backbone.base_model.conv1.weight',
        ...    '_task_model._backbone.base_model.bn1.weight':
        ...        'module._task_model._backbone.base_model.bn1.weight',
        ...    '_task_model._backbone.base_model.bn1.bias':
        ...        'module._task_model._backbone.base_model.bn1.bias',
        ...    '_task_model._backbone.base_model.bn1.running_mean':
        ...        'module._task_model._backbone.base_model.bn1.running_mean',
        ...    ...
        ... }

    If you want to add `module.` at each head of keys, and replace
    `_task_model._backbone` to `my_model`, you should do:

    .. code-block:: python

        >>> cd /path/to/torchpilot/tools
        >>> python3 checkpoint_tools.py -m -cp /path/to/ckpt -dd /path/to/dump/json -r
        ... _task_model._backbone my_model -p module.

    Then you will get a json file at `/path/to/dump/json/ckpt2model_mapping.json`:

    .. code-block:: python

        >>> import json
        >>> with open('/path/to/dump/json/ckpt2model_mapping.json', 'r') as f:
        ...     json_dict = json.load(f)
        >>> json_dict
        ... {
        ...    '_task_model._backbone.base_model.conv1.weight':
        ...        'module.my_model.base_model.conv1.weight',
        ...    '_task_model._backbone.base_model.bn1.weight':
        ...        'module.my_model.base_model.bn1.weight',
        ...    '_task_model._backbone.base_model.bn1.bias':
        ...        'module.my_model.base_model.bn1.bias',
        ...    '_task_model._backbone.base_model.bn1.running_mean':
        ...        'module.my_model.base_model.bn1.running_mean',
        ...    ...
        ... }
    """

    def __init__(
        self,
        ckpt_path: str,
        dump_dir: str,
        replace: Tuple[str, str] = None,
        prefix: str = None,
    ) -> None:
        """Initialize."""
        if not os.path.exists(ckpt_path):
            raise FileNotFoundError(f"File {ckpt_path} does not exist.")

        if not os.path.isdir(dump_dir):
            raise NotADirectoryError(f"{dump_dir} is not a directory.")

        json_dump_path = os.path.join(dump_dir, "ckpt2model_mapping.json")
        if os.path.exists(json_dump_path):
            raise FileExistsError(f"File {json_dump_path} exists! Remove it manually.")

        if replace is None and prefix is None:
            raise ValueError(
                "Expect at least one of replace or prefix is not None, "
                "but got replace=None and prefix=None."
            )

        self._ckpt_path = ckpt_path
        self._replace = replace
        self._prefix = prefix
        self._json_dump_path = json_dump_path
        self._ckpt2model = self._init_ckpt2model_mapping()

    def _init_ckpt2model_mapping(self) -> Dict[str, str]:
        """Initialize ckpt2model mapping.

        Returns:
            Dict of {str, str} pairs.
        """
        # Get model state dict.
        checkpoint = load_checkpoint(self._ckpt_path)

        if "model" not in checkpoint:
            logger.warning(
                "Key `model` not in checkpoint, checkpoint_keys()=%s.\n"
                "Will treat checkpoint as model_state_dict.",
                str(checkpoint.keys()),
            )
            model_state_dict = checkpoint
        else:
            model_state_dict = checkpoint["model"]

        # Initialize checkpoint to model mapping.
        init_ckpt2model = {k: k for k in model_state_dict}

        return init_ckpt2model

    def _do_replace(self) -> None:
        """Generate keys by replace substr of original keys."""
        if len(self._replace) != 2:  # type: ignore[arg-type]
            raise ValueError(
                f"Expect len(replace)==2, but got replace={self._replace}."
            )

        logger.info("Replacing substr of original keys...")

        to_replace, replace_to = self._replace  # type: ignore[misc]

        if to_replace == replace_to:
            raise ValueError(
                f"Expect substr to replace and substr replace to is not same but got "
                f"str to replace is `{to_replace}`, str replace to is `{replace_to}`."
            )

        matched = 0
        for ckpt_key, expected_key in self._ckpt2model.items():

            if to_replace in expected_key:
                matched += 1

            new_expected_key = expected_key.replace(to_replace, replace_to)
            logger.info("Replace `%s` to `%s`.", expected_key, new_expected_key)
            self._ckpt2model[ckpt_key] = new_expected_key

        if matched == 0:
            raise ValueError(
                f"Expect match str at least once, but got 0. Did you give the correct "
                f"substr to replace? str to replace is `{to_replace}`, str replace to "
                f"is `{replace_to}`."
            )

        logger.info("Total replace times is %d.", matched)
        logger.info("Replacing substr of original keys done.")

    def _update_prefix(self) -> None:
        """Update prefix."""
        logger.info("Add prefix of original keys.")

        prefix = self._prefix

        for ckpt_key, expected_key in self._ckpt2model.items():

            new_expected_key = prefix + expected_key  # type: ignore[operator]
            logger.info(
                "Add prefix, before %s after %s.",
                expected_key,
                new_expected_key,
            )
            self._ckpt2model[ckpt_key] = new_expected_key

        logger.info("Add prefix of original keys done.")

    def do_mapping(self) -> None:
        """Do mapping."""
        if self._replace is not None:
            self._do_replace()

        if self._prefix is not None:
            self._update_prefix()

    def dump_json(self) -> None:
        """Dump json file to args.dump_dir."""
        logger.info("Dump json to %s.", self._json_dump_path)

        with open(self._json_dump_path, "a", encoding="utf8") as json_file:
            json_str = json.dumps(self._ckpt2model, indent=4, sort_keys=True)
            json_file.write(json_str)

    @property
    def json_dump_path(self) -> str:
        """Return json dump path."""
        return self._json_dump_path


@cli.command()
@click.option(
    "-cp",
    "--ckpt_path",
    help="Path to checkpoint.",
    required=True,
)
@click.option(
    "-dd",
    "--dump_dir",
    help="Json dump path.",
    required=True,
)
@click.option(
    "-m",
    "--mapping",
    is_flag=True,
    help="Enable mapping tools.",
)
@click.option(
    "-r",
    "--replace",
    type=(str, str),
    help="If set, receive two values list [A: str, B: str], and replace A to B.",
)
@click.option(
    "-p",
    "--prefix",
    help="If set, update prefix.",
)
def ckpt(
    ckpt_path: str,
    dump_dir: str,
    mapping: bool,
    replace: Tuple[str, str],
    prefix: str,
) -> None:
    """Checkpoint tools."""
    if mapping:
        ckpt_mapping_tool = CheckpointMappingTools(
            ckpt_path=ckpt_path,
            dump_dir=dump_dir,
            replace=replace,
            prefix=prefix,
        )
        logger.info("Do checkpoint mapping...")
        ckpt_mapping_tool.do_mapping()
        ckpt_mapping_tool.dump_json()


if __name__ == "__main__":
    ckpt()  # pylint: disable=no-value-for-parameter
