# -*- coding: utf-8 -*-
"""torchpilot."""
import logging
from importlib.metadata import version

from torchpilot.utils.dist_manager import disable_kmp_affinity
from torchpilot.utils.log_manager import log_init


__version__ = version(__package__)


log_init(__name__)
logger = logging.getLogger(__name__)

disable_kmp_affinity()
