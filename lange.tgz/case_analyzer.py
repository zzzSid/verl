# -*- coding: utf-8 -*-
import os

import torch
from torchpilot.utils.plus_manager import load_plus

from tpp_onemodel.runner.frame_runner.astraplanner_single_frame_runner import (
    AstraPlannerSingleCaseRunner,
)
from tpp_onemodel.utils.experiments_utils import configure_torch_backend


configure_torch_backend()

os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"

torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False
torch.use_deterministic_algorithms(True)  # type: ignore
torch.backends.cudnn.allow_tf32 = True  # type: ignore
torch.backends.cuda.matmul.allow_tf32 = True

infer_cfg_name = "cfg_intersec_3s7s_debug.py"
infer_output_path = "/home/jingyuan.ma/melange/output/exp_debug/planner_debug_infer_with_inputs/"
ckpt_path = "/home/jingyuan.ma/melange/output/exp_debug/planner_debug/ckpt/checkpoint_last.pth.tar"
clip_path = "20221220T174000_LJ1EFAUU6NG000019_1671529320.000000_1671529379.000000.pkl"

if __name__ == "__main__":
    load_plus()
    runner = AstraPlannerSingleCaseRunner(
        output_path=infer_output_path, cfg_name=infer_cfg_name, checkpoint=ckpt_path, clip_path=clip_path
    )

    runner.build_model_and_set_mode()
    all_data = runner.load_frame_data()

    for data in all_data:
        model_output = runner.run_one_batch(data)
