set -e

# This environment variable is a temporary hack on cu114 for cpu affinity.
export KMP_AFFINITY=disabled
export TORCHPILOT_ENABLE_COMPILE=False
# export CUBLAS_WORKSPACE_CONFIG=:4096:8
# export CACHE_URI=tcp://10.60.75.215:2022
export CACHE_URI=tcp://10.61.1.17:2022 # jinshan URI

DEVICE_NUM=$1
if [ "$DEVICE_NUM" = "" ]; then
  echo "You must set device num"
  exit -1
else
  echo "You set device num $DEVICE_NUM"
fi
LAUNCHER="mpirun -bind-to none -map-by slot -x KMP_AFFINITY -x LD_LIBRARY_PATH -x PATH -x CACHE_URI -x CUBLAS_WORKSPACE_CONFIG -x TORCHPILOT_ENABLE_COMPILE -x TORCHPILOT_OUTPUT_DIR -mca pml ob1 -mca btl ^openib --hostfile /etc/volcano/all.host"

if [ "$NIOFLOW_RUN_ID" != "" ]; then
  echo $LAUNCHER -np $DEVICE_NUM torchpilot run ${@:1}
  $LAUNCHER -np $DEVICE_NUM torchpilot run ${@:1}
else
  echo $LAUNCHER -np $DEVICE_NUM pipenv run torchpilot run ${@:1}
  $LAUNCHER -np $DEVICE_NUM pipenv run torchpilot run ${@:1}
fi
