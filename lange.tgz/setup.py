# -*- coding: utf-8 -*-
"""The setup.py for tpp-onemodel."""

import os
import platform
from typing import Any
from typing import Dict
from typing import List
from typing import Optional

import torch
from pkg_resources import parse_requirements
from setuptools import find_packages
from setuptools import setup
from torch.utils.cpp_extension import BuildExtension
from torch.utils.cpp_extension import CppExtension
from torch.utils.cpp_extension import CUDAExtension


# Parse content from `README.md` as long description.
with open("README.md", encoding="utf-8") as fh:
    long_description = fh.read()

# Parse content from `requirements/base.txt` as install requires.
# torch / torchvision are excluded from base.txt intentionally:
#   - ncard: installed separately via requirements/ncard.txt in Makefile
#   - ppu:   provided by the system image (--system-site-packages)
with open("requirements/base.txt", encoding="utf-8") as fh:
    install_requires = [str(requirement) for requirement in parse_requirements(fh)]

# pylint: disable=line-too-long

# Build Setup Extension Module which support compile CUDA file.
# set cuda/cpp source file.
# set cpp macro
# set include dirs
# set compile args


def make_cuda_ext(
    name: str,
    module: str,
    sources: List,
    sources_cuda: Optional[List[Any]] = None,
    extra_args: Optional[List[Any]] = None,
    extra_include_path: Optional[List[Any]] = None,
):
    """Make CUDA Extention Info."""
    if sources_cuda is None:
        sources_cuda = []
    if extra_args is None:
        extra_args = []
    if extra_include_path is None:
        extra_include_path = []
    define_macros = []
    extra_compile_args: Dict = {"cxx": [] + extra_args}

    if torch.cuda.is_available() or os.getenv("FORCE_CUDA", "0") == "1":
        define_macros += [("WITH_CUDA", None)]
        extension = CUDAExtension
        extra_compile_args["nvcc"] = extra_args + [
            "-D__CUDA_NO_HALF_OPERATORS__",
            "-D__CUDA_NO_HALF_CONVERSIONS__",
            "-D__CUDA_NO_HALF2_OPERATORS__",
        ]
        sources += sources_cuda
    else:
        extension = CppExtension
        # raise EnvironmentError('CUDA is required to compile MMDetection!')

    return extension(
        name=f"{module}.{name}",
        sources=[os.path.join(*module.split("."), p) for p in sources],
        include_dirs=extra_include_path,
        define_macros=define_macros,
        extra_compile_args=extra_compile_args,
    )


def get_extensions():
    """Get extention list."""
    extensions = []

    if (
        platform.machine() == "aarch64"
        or os.environ.get("CI_CPU_JOB", "0") == "1"
        or os.environ.get("NTS_GPU_TYPE", "").startswith("ppu")
    ):
        # We DO NOT build extensions on arm platform for now.
        # CI_CPU_JOB=1: skip in CPU-only CI jobs.
        # NTS_GPU_TYPE=ppu*: ms_deform_attn, iou3d etc. are NVIDIA-specific and not needed on PPU.
        return extensions

    extensions.extend(
        [
            make_cuda_ext(
                name="ms_deform_attn_cuda",
                module="tpp_onemodel.model.ops.ms_deform_attn",
                sources=[
                    "src/ms_deform_attn.cpp",
                    "src/ms_deform_attn_cuda.cu",
                ],
            ),
            make_cuda_ext(
                name="ms_deform_attn_cuda_v2",
                module="tpp_onemodel.model.ops.ms_deform_attn_v2",
                sources=[
                    "src/ms_deform_attn.cpp",
                    "src/ms_deform_attn_cuda.cu",
                ],
            ),
            make_cuda_ext(
                name="iou3d_cuda",
                module="tpp_onemodel.model.ops.iou3d",
                sources=[
                    "src/iou3d.cpp",
                    "src/iou3d_kernel.cu",
                ],
            ),
        ]
    )

    return extensions


setup(
    author="TorchPilot",
    author_email="torchpilot@nio.com",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: Apache Software License",
        "Programming Language :: Python :: 3.8",
    ],
    description="TorchPilot-Plus-OneModel",
    entry_points={
        "torchpilot.dataset": [
            "PlannerMultiDataset=tpp_onemodel.data.dataset.planner_dataset",
            "AstraPlannerDataset=tpp_onemodel.data.dataset.astra_planner_dataset",
        ],
        "torchpilot.dataloader": [
            "Plannn2DataLoader=tpp_onemodel.data.dataloader.plannn2_dataloader",
            "Plannn3DataLoader=tpp_onemodel.data.dataloader.plannn3_dataloader",
        ],
        "torchpilot.sampler": [
            "TPPMultiTaskDistributedSampler=tpp_onemodel.data.sampler.multitask_distributed_sampler",
            "Plannn2DistributedLengthGroupedSampler=tpp_onemodel.data.dataset.plannn2_sampler",
        ],
        "torchpilot.transform": [
            "AgentsStateTransform=tpp_onemodel.data.transform.auto_regressive_transform",
            "AgentsActionTransform=tpp_onemodel.data.transform.auto_regressive_transform",
            "Convert2PlannerOldVersionFormat=tpp_onemodel.data.transform.astra_planner_transform",
            "EgoStateTransform=tpp_onemodel.data.transform.auto_regressive_transform",
            "EgoActionTransform=tpp_onemodel.data.transform.auto_regressive_transform",
            "MannerLane2LaneKey=tpp_onemodel.data.transform.astra_planner_transform",
            "EgoGearGen=tpp_onemodel.data.transform.astra_planner_transform",
            "LaneRemoveStopline=tpp_onemodel.data.transform.astra_planner_transform",
            "LaneRemoveMarker=tpp_onemodel.data.transform.astra_planner_transform",
            "ControlPointGen=tpp_onemodel.data.transform.astra_planner_transform",
            "ControlPointAug=tpp_onemodel.data.transform.astra_planner_transform",
            "SaveDynamicDets4AR=tpp_onemodel.data.transform.auto_regressive_transform",
            "StampGeneratePredLabel=tpp_onemodel.data.transform.astra_planner_transform",
            "StampGenerateEgoPredLabel=tpp_onemodel.data.transform.astra_planner_transform",
            "StampGenerateEgoPredVelLabel=tpp_onemodel.data.transform.astra_planner_transform",
            "StampGenerateEgoPredSteeringWheelLabel=tpp_onemodel.data.transform.astra_planner_transform",
            "StampGenerateEgoPreAccLabel=tpp_onemodel.data.transform.astra_planner_transform",
            "StampGenerateEgoPreYawRateLabel=tpp_onemodel.data.transform.astra_planner_transform",
            "StampTLDDataAug=tpp_onemodel.data.transform.astra_planner_transform",
            "ODPriorFormat=tpp_onemodel.data.transform.prediction_transform",
            "ODPriorMaskGen=tpp_onemodel.data.transform.astra_planner_transform",
            "PlannerAlignEgoToRef=tpp_onemodel.data.transform.astra_planner_transform",
            "PlannerAlignToRef=tpp_onemodel.data.transform.astra_planner_transform",
            "PlannerGenStaticTransMat=tpp_onemodel.data.transform.astra_planner_transform",
            "PlannerShufflePadBox=tpp_onemodel.data.transform.astra_planner_transform",
            "PlannerShufflePadPolyline2D=tpp_onemodel.data.transform.astra_planner_transform",
            "PlannerShufflePadPolyline2DLane=tpp_onemodel.data.transform.astra_planner_transform",
            "PlannerShufflePadPolyline2DAtlas=tpp_onemodel.data.transform.astra_planner_transform",
            "PlannerShufflePadPolyline2DSdmap=tpp_onemodel.data.transform.astra_planner_transform",
            "PlannerPadTLD=tpp_onemodel.data.transform.astra_planner_transform",
            "PlannerGenerateTracklet=tpp_onemodel.data.transform.astra_planner_transform",
            "PlannerShufflePadPolygonAttr=tpp_onemodel.data.transform.astra_planner_transform",
            "PlannerStaticDetsPadBox=tpp_onemodel.data.transform.astra_planner_transform",
            "PlannerShufflePadPolyline2DDynamicGod=tpp_onemodel.data.transform.astra_planner_transform",
            "PlannerShufflePadPolyline2DNaviLine=tpp_onemodel.data.transform.astra_planner_transform",
            "PlannerShufflePadPolyline2DNaviPath=tpp_onemodel.data.transform.astra_planner_transform",
            "PlannerGenerateAlignedGT=tpp_onemodel.data.transform.astra_planner_transform",
            "PlannerEgoDeltaSpeedAug=tpp_onemodel.data.transform.astra_planner_transform",
            "PlannerEgoFutureTruncate=tpp_onemodel.data.transform.astra_planner_transform",
            "PlannerAlignAgentPrediction=tpp_onemodel.data.transform.astra_planner_transform",
            "Plannn2InferSliceTransform=tpp_onemodel.data.transform.plannn2_transform",
            "Plannn2SeqOdIdShuffle=tpp_onemodel.data.transform.plannn2_transform",
            "Plannn3NaviPackTransform=tpp_onemodel.data.transform.plannn3_transform",
            "Plannn3HistoryTrajPackTransform=tpp_onemodel.data.transform.plannn3_transform",
            "Plannn3VisualDecodeTransform=tpp_onemodel.data.transform.plannn3_transform",
            "Plannn3InferSliceTransform=tpp_onemodel.data.transform.plannn3_transform",
            "Plannn3MaskHistoryImage=tpp_onemodel.data.transform.nn3_data_augmentation",
            "Plannn2DCTTokenGen=tpp_onemodel.data.transform.plannn2_transform",
            "Plannn2PCATokenGen=tpp_onemodel.data.transform.plannn2_transform",
            "Plannn2PCAEgoHistoryTokenize=tpp_onemodel.data.transform.plannn2_transform",
            "SetOtherTokenPCAProperty=tpp_onemodel.data.transform.plannn2_transform",
            "Plannn2MaskHistEgoLabel=tpp_onemodel.data.transform.plannn2_transform",
            "PadEmptyEgoActions=tpp_onemodel.data.transform.plannn2_transform",
            "PlannnSegmentMask=tpp_onemodel.data.transform.plannn2_transform",
            "GetTrackableAgentPrediction=tpp_onemodel.data.transform.astra_planner_transform",
        ],
        "torchpilot.evaluator": [
            "AstraPlannerSceneEvaluator=tpp_onemodel.evaluator.astra_planner_scene_evaluator",
            "EvaluationBaseConfig=tpp_onemodel.evaluator.cfg.base_config",
            "Plannn2Evaluator=tpp_onemodel.evaluator.plannn2_evaluator",
        ],
        "torchpilot.base_model": [
            "SampleBaseModel=tpp_onemodel.model.base_model.base_model_sample",
        ],
        "torchpilot.head": [
            "AstraPlannerHead=tpp_onemodel.model.head.astra_planner_head",
            "AstraPlannerStage2Head=tpp_onemodel.model.head.astra_planner_stage2_head",
            "GoalPointPlannerHead=tpp_onemodel.model.head.goal_point_planner_head",
            "ODPriorHead=tpp_onemodel.model.head.prediction_od_prior_head",
            "ODPriorLaneFeatExtractor=tpp_onemodel.model.head.prediction_od_prior_head",
            "UTurnPlannerHead=tpp_onemodel.model.head.uturn_planner_head",
            "PredictionHead=tpp_onemodel.model.head.prediction_head",
            "StampAssociatePredictor=tpp_onemodel.model.head.stamp_predictor_head",
            "StampAssociateDecoder=tpp_onemodel.model.head.stamp_predictor_head",
            "StampDangerPredictor=tpp_onemodel.model.head.stamp_predictor_head",
            "StampScratchPredictor=tpp_onemodel.model.head.stamp_predictor_head",
            "StampDangerDecoder=tpp_onemodel.model.head.stamp_predictor_head",
            "StampDynamicBGAssociateDecoder=tpp_onemodel.model.head.stamp_predictor_head",
            "StampMotionTypePredictor=tpp_onemodel.model.head.stamp_predictor_head",
            "StampDecisionPredictor=tpp_onemodel.model.head.stamp_predictor_head",
            "StampDecisionUncertaintyPredictor=tpp_onemodel.model.head.stamp_predictor_head",
            "StampPredictionPredictor=tpp_onemodel.model.head.stamp_predictor_head",
            "StampStatePredictor=tpp_onemodel.model.head.stamp_predictor_head",
            "StampStateVariancePredictor=tpp_onemodel.model.head.stamp_predictor_head",
            "StampStateDecoder=tpp_onemodel.model.head.stamp_predictor_head",
            "StampSubtypePredictor=tpp_onemodel.model.head.stamp_predictor_head",
            "BaseMLP=tpp_onemodel.model.head.stamp_predictor_head",
            "UniDecisionBaseHead=tpp_onemodel.model.head.uni_decision_head",
        ],
        "torchpilot.layer": [
            "BBoxOverlap=tpp_onemodel.model.layer.bbox_overlap",
            "Conv2DTranspose=tpp_onemodel.model.layer.deconv2d",
            "PlannerCrossAttention=tpp_onemodel.model.layer.planner_attention",
            "NearestUpsampling=tpp_onemodel.model.layer.nearest_up_sampling",
            "NMS=tpp_onemodel.model.layer.nms",
            "StampMultiheadAttention=tpp_onemodel.model.layer.stamp_attention",
            # "FPNAssigner=tpp_onemodel.model.layer.fpn_assigner",
            # "OpFPNAssigner=tpp_onemodel.model.layer.fpn_assigner",
        ],
        "torchpilot.losses": [
            "AutoRegressivePlannerLoss=tpp_onemodel.model.loss.auto_regressive_planner_loss",
            "AutoRegressiveEgoActionLoss=tpp_onemodel.model.loss.auto_regressive_planner_loss",
            "AutoRegressiveEgoFinetuneLoss=tpp_onemodel.model.loss.auto_regressive_planner_loss",
            "AutoRegressiveAgentsActionLoss=tpp_onemodel.model.loss.auto_regressive_planner_loss",
            "AutoRegressiveMTPEgoActionLoss=tpp_onemodel.model.loss.auto_regressive_planner_loss",
            "AutoRegressiveMTPAgentsActionLoss=tpp_onemodel.model.loss.auto_regressive_planner_loss",
            "AutoRegressiveDrivePathLoss=tpp_onemodel.model.loss.auto_regressive_planner_loss",
            "AutoRegressiveAgentsFinetuneLoss=tpp_onemodel.model.loss.auto_regressive_planner_loss",
            "AutoRegressiveCloseTrainEgoActionLoss=tpp_onemodel.model.loss.auto_regressive_planner_loss",
            "AutoRegressiveCloseTrainAgentsActionLoss=tpp_onemodel.model.loss.auto_regressive_planner_loss",
            "EnvGuassianCollisionLoss=tpp_onemodel.model.loss.astraplanner_loss",
            "ODPriorLoss=tpp_onemodel.model.loss.astraplanner_loss",
            "StampAebIntegratedLoss=tpp_onemodel.model.loss.stamp_aeb_loss",
            "StampIntegratedLoss=tpp_onemodel.model.loss.stamp_loss",
            "StampDangerLoss=tpp_onemodel.model.loss.stamp_aeb_loss",
            "StampScratchLoss=tpp_onemodel.model.loss.stamp_aeb_loss",
            "StampDynamicBGMatchingLoss=tpp_onemodel.model.loss.stamp_loss",
            "StampDecisionLoss=tpp_onemodel.model.loss.stamp_aeb_loss",
            "StampMatchingLoss=tpp_onemodel.model.loss.stamp_loss",
            "StampPredictionLoss=tpp_onemodel.model.loss.stamp_aeb_loss",
            "StampStateLoss=tpp_onemodel.model.loss.stamp_loss",
            "StampStateVarLoss=tpp_onemodel.model.loss.stamp_loss",
            "StampStateMotionTypeLoss=tpp_onemodel.model.loss.stamp_loss",
            "StationMultiRPNLoss=tpp_onemodel.model.loss.station_loss",
            "StationDepthDistLoss=tpp_onemodel.model.loss.station_loss",
            "AstraPlannerIntegratedLoss=tpp_onemodel.model.loss.astraplanner_loss",
            "AstraPlannerIntegratedLossV2=tpp_onemodel.model.loss.astraplanner_loss",
            "FocalLoss=tpp_onemodel.model.loss.focal_loss",
            "JointScenePredictionLoss=tpp_onemodel.model.loss.astraplanner_loss",
            "MarginalPredictionLoss=tpp_onemodel.model.loss.astraplanner_loss",
            "PlannerTGMPositionLoss=tpp_onemodel.model.loss.astraplanner_loss",
            "PlannerTGMSpeedLoss=tpp_onemodel.model.loss.astraplanner_loss",
            "PlannerTGMCurvatureLoss=tpp_onemodel.model.loss.astraplanner_loss",
            "PlannerTGMCollisionLoss=tpp_onemodel.model.loss.astraplanner_loss",
            "UDTGMJEAPIntegratedLoss=tpp_onemodel.model.loss.planner_uni_decision_loss",
            "UniDecisionSingleSceneLoss=tpp_onemodel.model.loss.planner_uni_decision_loss",
            "PlannerAuxLateralLongitudinalLoss=tpp_onemodel.model.loss.astraplanner_loss",
            "LaneKeepingLoss=tpp_onemodel.model.loss.astraplanner_loss",
            "LateralLongitudinalLoss=tpp_onemodel.model.loss.astraplanner_loss",
            "DrivePathLaneKeepingLoss=tpp_onemodel.model.loss.astraplanner_loss",
            "PlannerAgentPredictionLoss=tpp_onemodel.model.loss.stamp_aeb_loss",
            "PlannerEgoPredictionLoss=tpp_onemodel.model.loss.stamp_aeb_loss",
            "LaneBoundaryCollisionLoss=tpp_onemodel.model.loss.astraplanner_loss",
            "UnsafeAreaCollisionLoss=tpp_onemodel.model.loss.astraplanner_loss",
            "DrivePathCollisionLoss=tpp_onemodel.model.loss.astraplanner_loss",
            "SodCollisionLoss=tpp_onemodel.model.loss.astraplanner_loss",
            "LaneCenteringLoss=tpp_onemodel.model.loss.astraplanner_loss",
            "NaviMissingLoss=tpp_onemodel.model.loss.astraplanner_loss",
            "OdCollisionLoss=tpp_onemodel.model.loss.astraplanner_loss",
            "ExtraImitationLoss=tpp_onemodel.model.loss.astraplanner_loss",
            "CELoss=tpp_onemodel.model.loss.astraplanner_loss",
            "LaneKeepLoss=tpp_onemodel.model.loss.astraplanner_loss",
            "GoalPointPlannerLoss=tpp_onemodel.model.loss.goal_point_planner_loss",
            "GoalPointPlannerL2Loss=tpp_onemodel.model.loss.goal_point_planner_loss",
            "ControlPointLoss=tpp_onemodel.model.loss.goal_point_planner_loss",
            "MultiLayerLoss=tpp_onemodel.model.loss.multi_layer_loss",
            "PlannerMultiTaskLoss=tpp_onemodel.model.loss.planner_multitask_loss",
            "Plannn2CELoss=tpp_onemodel.model.loss.plannn2_loss",
            "Plannn3MultimodalLoss=tpp_onemodel.model.loss.plannn3_multimodal_loss",
        ],
        "torchpilot.module": [
            "AstraPlannerAgentDecoder=tpp_onemodel.model.module.astraplanner_decoder",
            "AstraPlannerEgoDecoder=tpp_onemodel.model.module.astraplanner_decoder",
            "AstraPlannerStage2Decoder=tpp_onemodel.model.module.astraplanner_stage2_decoder",
            "AutoRegressiveSampler=tpp_onemodel.model.module.auto_regressive_sampler",
            "AutoRegressiveMTPSampler=tpp_onemodel.model.module.auto_regressive_sampler",
            "ARTopkToppTempSampleModule=tpp_onemodel.model.module.auto_regressive_sampler",
            "ARTopkToppTempMTPSampleModule=tpp_onemodel.model.module.auto_regressive_sampler",
            "ARCloseLoopTopkToppTempSampleModule=tpp_onemodel.model.module.auto_regressive_sampler",
            "ARTop1DeterministicSampleModule=tpp_onemodel.model.module.auto_regressive_sampler",
            "ARTokenDecoderKappaAccFake=tpp_onemodel.model.module.auto_regressive_token_decoder",
            "ARTokenDecoderAccOmega=tpp_onemodel.model.module.auto_regressive_token_decoder",
            "ARTokenDecoderAccOmegaMultiStep=tpp_onemodel.model.module.auto_regressive_token_decoder",
            "ARTokenDecoderAccOmegaCloseLoop=tpp_onemodel.model.module.auto_regressive_token_decoder",
            "ARTokenDecoderAccOmegaMTP=tpp_onemodel.model.module.auto_regressive_token_decoder",
            "AutoRegressivePlanner=tpp_onemodel.model.module.auto_regressive_planner",
            "AutoRegressiveActionModel=tpp_onemodel.model.module.auto_regressive_action_model",
            "ARActionModelV1=tpp_onemodel.model.module.auto_regressive_action_model",
            "ARActionV1TAttnBlock=tpp_onemodel.model.module.auto_regressive_action_model",
            "ARAddOnModule=tpp_onemodel.model.module.auto_regressive_add_on_module",
            "ARAddOnFakeOutput=tpp_onemodel.model.module.auto_regressive_add_on_module",
            "ARAddOnDrivePath=tpp_onemodel.model.module.auto_regressive_add_on_module",
            "ActionModelV1TAttn=tpp_onemodel.model.module.auto_regressive_action_model",
            "ActionModelV1AttnBlock=tpp_onemodel.model.module.auto_regressive_action_model",
            "ActionModelV1EgoAgentSelfAttn=tpp_onemodel.model.module.auto_regressive_action_model",
            "ActionModelV1EgoAgentCrossAttn=tpp_onemodel.model.module.auto_regressive_action_model",
            "ARStateUpdaterV1=tpp_onemodel.model.module.auto_regressive_state_updater",
            "ARStateUpdaterV2=tpp_onemodel.model.module.auto_regressive_state_updater",
            "ControlPointEncoder=tpp_onemodel.model.module.control_point_encoder",
            "EmbeddingMLP=tpp_onemodel.model.module.auto_regressive_common_module",
            "NaviPathAggregationLayer=tpp_onemodel.model.module.auto_regressive_common_module",
            "ARDecodeMLP=tpp_onemodel.model.module.auto_regressive_common_module",
            "ARDecodeMTP=tpp_onemodel.model.module.auto_regressive_common_module",
            "GoalPointPlannerEgoDecoder=tpp_onemodel.model.module.goal_point_astraplanner_decoder",
            "LaneEncoder=tpp_onemodel.model.module.lane_encoder",
            "NaviPathEncoder=tpp_onemodel.model.module.navi_path_encoder",
            "StampAebTransformer=tpp_onemodel.model.module.stamp_aeb_transformer",
            "StampSimpleAebTransformer=tpp_onemodel.model.module.stamp_aeb_transformer",
            "StampDecisionTransformer=tpp_onemodel.model.module.stamp_aeb_transformer",
            "StampAebTransformerDecoder=tpp_onemodel.model.module.stamp_aeb_transformer",
            "StampAebTransformerEncoder=tpp_onemodel.model.module.stamp_aeb_transformer",
            "StaticSceneTokenizer=tpp_onemodel.model.module.static_scene_tokenizer",
            "DynamicStateTokenizer=tpp_onemodel.model.module.dynamic_state_tokenizer",
            "EgoStateTokenizer=tpp_onemodel.model.module.dynamic_state_tokenizer",
            "AgentStateTokenizer=tpp_onemodel.model.module.dynamic_state_tokenizer",
            "StaticLaneTokenizer=tpp_onemodel.model.module.static_scene_tokenizer",
            "StaticCurrentODTokenizer=tpp_onemodel.model.module.static_scene_tokenizer",
            "CommandControlPointResidualBlock=tpp_onemodel.model.module.static_scene_tokenizer",
            "CommandControlPointTokenizer=tpp_onemodel.model.module.static_scene_tokenizer",
            "CommandNaviPathTokenizer=tpp_onemodel.model.module.static_scene_tokenizer",
            "CommandTLDTokenizer=tpp_onemodel.model.module.static_scene_tokenizer",
            "CommandSensorTokenizer=tpp_onemodel.model.module.static_scene_tokenizer",
            "StaticSensorTokenizer=tpp_onemodel.model.module.static_scene_tokenizer",
            "StaticSceneCrossAttn=tpp_onemodel.model.module.auto_regressive_common_module",
            "PlannerAxisAttnEncoder=tpp_onemodel.model.module.planner_scene_transformer",
            "PlannerAxisAttnPredDecoder=tpp_onemodel.model.module.planner_scene_transformer",
            "PlannerSceneEncoder=tpp_onemodel.model.module.planner_scene_transformer",
            "GoalPointPlannerSceneEncoder=tpp_onemodel.model.module.goal_point_planner_scene_transformer",
            "PlannerScenePredDecoder=tpp_onemodel.model.module.planner_scene_transformer",
            "PlannerIntentionAxisAttnPredDecoder=tpp_onemodel.model.module.planner_scene_transformer",
            "PlannerIntentionScenePredDecoder=tpp_onemodel.model.module.planner_scene_transformer",
            "PlannerAtlasSineEmbedding=tpp_onemodel.model.module.planner_embedding",
            "PlannerAtlasPolygonSineEmbedding=tpp_onemodel.model.module.planner_embedding",
            "PlannerVisionTransformerEncoder=tpp_onemodel.model.module.vit_model",
            "Plannn2LayerNorm=tpp_onemodel.model.module.plannn2_modules",
            "Plannn2RMSNorm=tpp_onemodel.model.module.plannn2_modules",
            "Plannn2CausalSelfAttention=tpp_onemodel.model.module.plannn2_modules",
            "Plannn3Dinov3Encoder=tpp_onemodel.model.module.nn3_dinov3_encoder",
            "Plannn2Block=tpp_onemodel.model.module.plannn2_modules",
            "Plannn2MLP=tpp_onemodel.model.module.plannn2_modules",
            "Plannn2PointNetPolylineEncoder=tpp_onemodel.model.module.plannn2_modules",
            "Plannn2PointNetDynPolylineEncoder=tpp_onemodel.model.module.plannn2_modules",
            "LearnableQueryCrossAttentionModule=tpp_onemodel.model.module.planner_transformer",
            "AstraPlannerDecoder=tpp_onemodel.model.module.astraplanner_decoder",
            "StampAttnMask=tpp_onemodel.model.module.stamp_attn_mask",
            "StampLocalAttnMask=tpp_onemodel.model.module.stamp_attn_mask",
            "StampDynamicBackground=tpp_onemodel.model.module.stamp_decoupled_dynamic_bg_transformer",
            "StampEmbedding=tpp_onemodel.model.module.stamp_embedding",
            "StampEmbeddingSine=tpp_onemodel.model.module.stamp_embedding",
            "StampLaneEncoder=tpp_onemodel.model.module.stamp_aeb_transformer",
            "StampTransformer=tpp_onemodel.model.module.stamp_transformer",
            "StampTransformerDecoder=tpp_onemodel.model.module.stamp_decoupled_dynamic_bg_transformer",
            "StampTransformerEncoder=tpp_onemodel.model.module.stamp_decoupled_dynamic_bg_transformer",
            "StampTransformerEncoderGAU=tpp_onemodel.model.module.stamp_decoupled_dynamic_bg_transformer",
            "TransformerDecoder=tpp_onemodel.model.module.stamp_transformer",
            "UniDecisioMultiObsAttnDecoderVersionOne=tpp_onemodel.model.module.uni_decision_decoder",
            "UniDecisionMlpDecoder=tpp_onemodel.model.module.uni_decision_decoder",
            "UniDecisionSingleObsDecoderVersionTwo=tpp_onemodel.model.module.uni_decision_decoder",
            "VectorNet=tpp_onemodel.model.module.planner_scene_transformer",
            "GoalVectorNet=tpp_onemodel.model.module.planner_scene_transformer",
            "AxisAttnEmbedding=tpp_onemodel.model.module.planner_scene_transformer",
            "StampChannelMatcher=tpp_onemodel.model.module.stamp_transformer",
            "FourierEncoder=tpp_onemodel.model.layer.fourier_embedding",
            "UTurnPlannerSceneEncoder=tpp_onemodel.model.module.uturn_planner_scene_transformer",
            "UTurnPlannerEgoDecoder=tpp_onemodel.model.module.uturn_planner_decoder",
        ],
        "torchpilot.task_flow": [
            "PlannerMultiTaskFlow=tpp_onemodel.model.task.planner_multitask_flow",
            "Plannn2TaskFlow=tpp_onemodel.model.task.plannn2_task_flow",
            "Plannn3TaskFlow=tpp_onemodel.model.task.plannn3_task_flow",
        ],
        "torchpilot.task_model": [
            "PlannerMultiTaskModel=tpp_onemodel.model.task.planner_multitask_model",
            "ARPlannerMultiTaskModel=tpp_onemodel.model.task.ar_planner_multitask_model",
            "Plannn2TaskModel=tpp_onemodel.model.task.plannn2_task_model",
            "Plannn3TaskModel=tpp_onemodel.model.task.plannn3_task_model",
        ],
        "torchpilot.lr_scheduler": [
            "IterBasedCosineLrScheduler=tpp_onemodel.optimizer.iter_based_cosine_lr_scheduler",
            "EpochBasedMultiStepLrScheduler=tpp_onemodel.optimizer.epoch_based_multi_step_lr_scheduler",
            "Plannn2CosineLrScheduler=tpp_onemodel.optimizer.plannn2_cosine_lr_scheduler",
        ],
        "torchpilot.optimizer": [],
        "torchpilot.trainer": [
            "PlannerMultiTaskTrainer=tpp_onemodel.runner.trainer.planner_multitask_trainer",
            "Plannn2Trainer=tpp_onemodel.runner.trainer.plannn2_trainer",
        ],
        "torchpilot.inferrer": [
            "PlannerMultiTaskInferrer=tpp_onemodel.runner.inferer.planner_multitask_inferrer",
        ],
        "console_scripts": ["launch_job=tpp_onemodel.utils.nts.scripts.launch_job:main"],
    },
    install_requires=install_requires,
    license="Apache License 2.0",
    long_description=long_description,
    long_description_content_type="text/markdown",
    name="tpp-onemodel",
    packages=find_packages(exclude=["dist.*", "dist", "tests.*", "tests"]),
    python_requires=">=3.8",
    url="https://ad-gitlab.nioint.com/ad/perception/perception_fte/melange",
    include_package_data=True,
    package_data={"tpp_onemodel.model.ops": ["*/*.so"]},
    ext_modules=get_extensions(),
    cmdclass={"build_ext": BuildExtension},
)
