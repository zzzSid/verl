import requests
url = "https://perception-mapping.nioint.com/dataloop/api/v1/autotrain/business/trigger"
for cmt, trace_cmt, nnode, name, base in [
    [
        'bd6336b5f2b5df5b5b24c8d8afe9cdcb778a1eb6',  # 训练 commit
        'bd6336b5f2b5df5b5b24c8d8afe9cdcb778a1eb6',  # trace commit
        1,                                           # 节点数
        'pre_0426_v4',                               # 实验名
        '25942043'                                   # Base bundle
    ],
]:
    data = {
        "create_user": "xin.fu2",
        "model_type": "plannn2_urban_small",  # 模型类型，与integration集成中的模型类型保持一致
        "nadp_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE4MDgyOTk5MDAsImp0aSI6Inhpbi5mdTIiLCJpc3MiOiJOVFMifQ.LrKkLPNDjLq0pjWwBLrUD6d19BPTXOwRcpgPbFImFn0",  # nadp_token
        "special_mode": ["pca"],  # 模型模式, 默认为[]。如果需要pca模式，则应修改为["pca"]
        "train_node_params": {
            "training_type": "pretrain",
            "pretrain_config": {
                "commit_id": cmt,  # 训练任务commit
                "output_dir": name,  # 启动命令-n后字符串
                "node_num": nnode,
                "gpu_num": 16,
                "cfg_path": "experiments/task_planner/exp_plannn2/cfg_plannn2_sft.py",
                "task_label_name": "算法3-planner-RL-ppu",  # KTP任务标签 数据算法-主动安全的Pretrain/SFT/预标 数据算法-行车&低速的挖掘/预标/评测 数据算法-主动安全的Pretrain/SFT/预标-ppu
                "gpu_type": "ppu-96g-2t",  # KTP GPU类型 a100-15c ppu-96g-2t
                "is_clean_artifacts": False,  # 是否清理铲物
                "key_task": False,  # KTP重保任务，新机制只允许部分任务重保，选True的话会报错。可以起任务之后手动点重保
                "extra_cmd": "",  # KTP启动命令
                # 下面配置专门为PPU设置
                "image": "adas-img.nioint.com/nts/ppu_base:xfm-pretrain2-20260323-no-pipenv",
                "cluster": "ppu-gpu",
                "cpu_num": 176,
                "memory": 1728
            },
            "version": name,  # KTP实验名称
        },
        "trace_node_params": {
            "commit_id": trace_cmt,  # trace任务commit ppl需要带b0181612d87e307b88d5999b985eabc44c4051e2
        },
        "tvm_node_params": {
            "compile_config": {
                "compile_by": "quantization",
                "branch": "zwq/meta_acc_pca_v_0427",  # 注意是否用了正确的量化分支
                "type": "mlc_llm",
            },
            "task_tag": name,  # laser-board中的task_tag
        },
        "patch_bundle_params": {
            "base_bundle_uuid": base,  # 打bundle时的base bundle
        },
        # logsim提测
        "logsim_test_params": {
            "logsim_base_bundle_uuid": "23761188",
            "logsim_cand_bundle_uuid": "23761188",
            "test_purpose": f"NN2TorchMIL pre_0421 vs {name}",
            "is_torch_mil": 1,
            "field_data": {
                "感知阶段logsim_version": "2.0.0.dev33612029",
                "ODD": ["城区"],
                "评测内容": ["Issue Regression-PlannerNN", "隐性风险-Urban", "FN专项-Urban"],
                "测试类型": "模块提测",
                "仿真任务运行模式": "Melange仿真",
                "Base指定Pre预训练版本_Melange": "pre0317",
                "Cand指定Pre预训练版本_Melange": "pre0317",
                "Base版本指定Melange Model File": "/share-global/AIP/nioml/ad-cn-hlidc-aip-experiment/Perception-Visual-Dynamic/prod/experiment/755599/task_planner/exp_plannn2/pre_0420_v3/ckpt/checkpoint_last.pth.tar",
                "Base版本指定Melange Commit ID": "0c6d51f835cc007e54b1237e8b878765ceb9998b",
                "Cand版本指定Melange Commit ID": "44ccd12d53db70d7a7e1f0365b5d8ceb9d68fb7f"
            }
        }
    }
    response = requests.post(url, json=data)
    response = response.json()
    instance_id = response["data"]
    print(f'https://perception-mapping.nioint.com/data/flow/instance/{instance_id}')
