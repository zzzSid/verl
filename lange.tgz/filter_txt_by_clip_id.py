#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
脚本功能：用A组的新数据更新B组数据
1. 读取两组txt文件路径列表（A: 更新后的新数据, B: 需要更新的数据列表）
2. 从每行数据中提取clip_id（第一个.前的部分）
3. 按B的顺序遍历，如果B中的clip_id在A中存在，就用A中的数据保存
4. 如果B中的clip_id在A中不存在，就删除（不保存）
5. 输出文件名为：原B文件名 + "_updated"

用途：当A是更新后的数据集，需要用A的数据去更新B中相同clip_id的数据
"""

import os
import re
from pathlib import Path


def extract_clip_id(line):
    """
    从数据行中提取clip_id

    示例输入：
    huailai_cos:ad-cn-hlidc-fdm-multimodal/Planning_DataHub/plannn2_closeloop_323w_not_nudge_v26_yutao_roadpost1004-2/000697cd-2be6-4aa3-8bbe-1038b60c561e_0.000000_0.000000/output/000697cd-2be6-4aa3-8bbe-1038b60c561e_0.000000_0.000000.pkl 9565832 145

    提取结果：000697cd-2be6-4aa3-8bbe-1038b60c561e_0
    """
    line = line.strip()
    if not line:
        return None

    # 取第一个空格前的路径部分
    path_part = line.split()[0] if ' ' in line else line

    # 从路径中提取文件名或目录名
    # 找到最后一个/后的部分，然后取第一个.之前的部分
    if '/' in path_part:
        filename = path_part.split('/')[-1]
    else:
        filename = path_part

    # 取第一个.之前的部分作为clip_id
    clip_id = filename.split('.')[0]

    return clip_id


def read_txt_and_extract_clip_ids(txt_path):
    """
    读取txt文件，返回clip_id集合和原始行数据的映射

    返回：
        clip_id_to_lines: dict, {clip_id: [line1, line2, ...]}
        clip_ids: set, clip_id的集合
    """
    clip_id_to_lines = {}
    clip_ids = set()

    with open(txt_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            clip_id = extract_clip_id(line)
            if clip_id:
                clip_ids.add(clip_id)
                if clip_id not in clip_id_to_lines:
                    clip_id_to_lines[clip_id] = []
                clip_id_to_lines[clip_id].append(line)

    return clip_id_to_lines, clip_ids


def filter_and_save(reference_txt_paths, target_txt_paths, output_dir):
    """
    主函数：用A组的新数据更新B组数据并保存

    Args:
        reference_txt_paths: list, A组（更新后的新数据）txt文件路径列表
        target_txt_paths: list, B组（需要更新的数据列表）txt文件路径列表
        output_dir: str, 输出文件的统一路径前缀

    逻辑：
        1. 读取A组所有数据，建立 clip_id -> lines 的映射
        2. 遍历B组文件，按B的顺序处理每个clip_id
        3. 如果B中的clip_id在A中存在，就用A中的数据保存
        4. 如果B中的clip_id在A中不存在，就删除（不保存）
    """
    # 确保输出目录存在
    os.makedirs(output_dir, exist_ok=True)

    # 1. 收集A组所有的数据，建立 clip_id -> lines 的映射
    print("正在读取A组（更新后的新数据）...")
    a_clip_id_to_lines = {}
    a_clip_ids = set()

    for txt_path in reference_txt_paths:
        print(f"  读取: {txt_path}")
        clip_id_to_lines, clip_ids = read_txt_and_extract_clip_ids(txt_path)
        a_clip_ids.update(clip_ids)
        # 合并映射（如果有重复的clip_id，后面的会覆盖前面的）
        for clip_id, lines in clip_id_to_lines.items():
            if clip_id not in a_clip_id_to_lines:
                a_clip_id_to_lines[clip_id] = []
            a_clip_id_to_lines[clip_id].extend(lines)

    print(f"A组共有 {len(a_clip_ids)} 个唯一clip_id")

    # 2. 对B组的每个txt文件进行处理
    print("\n正在处理B组文件（用A组数据更新）...")
    total_original_lines = 0
    total_filtered_lines = 0
    total_matched_clip_ids = 0
    total_missing_clip_ids = 0

    for txt_path in target_txt_paths:
        print(f"\n  处理: {txt_path}")

        # 统计原始有效行数
        original_line_count = 0
        with open(txt_path, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    original_line_count += 1

        # 读取B组文件的clip_id（按顺序）
        b_clip_ids_ordered = []
        with open(txt_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                clip_id = extract_clip_id(line)
                if clip_id:
                    b_clip_ids_ordered.append(clip_id)

        b_unique_clip_ids = set(b_clip_ids_ordered)
        print(f"    B组原始数据: {len(b_unique_clip_ids)} 个唯一clip_id, {original_line_count} 行数据")

        # 按B的顺序，用A的数据替换
        filtered_lines = []
        matched_clip_ids = set()
        missing_clip_ids = set()

        for clip_id in b_clip_ids_ordered:
            if clip_id in a_clip_id_to_lines:
                # 在A中找到了，使用A的数据
                matched_clip_ids.add(clip_id)
                filtered_lines.extend(a_clip_id_to_lines[clip_id])
            else:
                # 在A中没找到，删除（不保存）
                missing_clip_ids.add(clip_id)

        # 计算保留比例
        retain_ratio = (len(filtered_lines) / original_line_count * 100) if original_line_count > 0 else 0

        print(f"    匹配结果: {len(matched_clip_ids)} 个clip_id在A中找到, {len(missing_clip_ids)} 个未找到")
        print(f"    输出数据: {len(filtered_lines)} 行（来自A组）")
        print(
            f"    保留比例: {len(matched_clip_ids)}/{len(b_unique_clip_ids)} clip_id = {len(matched_clip_ids)/len(b_unique_clip_ids)*100:.2f}%"
        )

        # 累计统计
        total_original_lines += original_line_count
        total_filtered_lines += len(filtered_lines)
        total_matched_clip_ids += len(matched_clip_ids)
        total_missing_clip_ids += len(missing_clip_ids)

        # 3. 保存到新文件
        # 生成输出文件名：原文件名 + "_updated"
        original_filename = Path(txt_path).name
        base_name = original_filename.rsplit('.', 1)[0]  # 去掉扩展名
        extension = original_filename.rsplit('.', 1)[1] if '.' in original_filename else 'txt'
        output_filename = f"{base_name}_updated.{extension}"
        output_path = os.path.join(output_dir, output_filename)

        with open(output_path, 'w', encoding='utf-8') as f:
            for line in filtered_lines:
                f.write(line + '\n')

        print(f"    已保存到: {output_path}")

    # 输出总体统计信息
    print("\n" + "="*60)
    print("总体统计:")
    print(f"  B组文件总数: {len(target_txt_paths)}")
    print(f"  B组原始总行数: {total_original_lines}")
    print(f"  匹配的clip_id总数: {total_matched_clip_ids}")
    print(f"  未匹配的clip_id总数: {total_missing_clip_ids}")
    print(f"  输出总行数（A组数据）: {total_filtered_lines}")
    print("="*60)
    print("\n处理完成！")


def main():
    """
    主入口：配置文件路径并执行筛选
    """
    # ============ 配置区域 ============

    # A组：Reference list（参考列表）
    reference_txt_paths = [
        "/share-global/menghan.pan/planner_nn_data/rl_data_all_clip_ids_1117_149496_140173.txt"
        # 添加更多参考文件...
    ]

    # B组：待筛选的list
    target_txt_paths = [
        "/share-global/oliver.cheng/planner_data/rl_clip_ids_104686_1107_93890.txt",
        "/share-global/xinyue.tang2/scalling/collision_scalling_1020/collision_40w/dynamic_collision_vru_type_clip_new.txt",
        "/share-global/tenglong.xi/data/1029_combine_mxn_left_on_right_scene_data_2366.txt",
        "/share-global/tenglong.xi/data/1024_1500_left_right_turn_t_junction_0929_pbtrans.txt",
        "/share-global/wufei.fu/selected_345_repeat_19_6555.txt",
        "/share-global/rong.zhang2/plannn2_data/1106_dedup_main_side_split_data_5318.txt",
        "/share-global/rong.zhang2/plannn2_data/1106_dedup_main_side_split_data_5318.txt",
        "/share-global/rong.zhang2/plannn2_data/1106_badcase_main_side_split_data_172x5.txt",
        ]

    # 输出目录：筛选后文件的统一路径前缀
    output_dir = "./filtered_output"

    # ============ 配置区域结束 ============

    # 执行筛选
    filter_and_save(reference_txt_paths, target_txt_paths, output_dir)


if __name__ == "__main__":
    # 示例用法
    main()

    # 或者直接调用函数
    """
    filter_and_save(
        reference_txt_paths=[
            "/share-global/menghan.pan/planner_nn_data/plannn2_closeloop_323w_not_nudge_v26_yutao_roadpost1004-2_6249.txt"
        ],
        target_txt_paths=[
            "/share-global/menghan.pan/planner_nn_data/pre_train_data_all_clip_ids_1103V2_1376572_1105_1144787.txt"
        ],
        output_dir="/home/mccree.zhao/project/offline/2024/melange_all/2025_10/melange_NN_1014/filtered_output"
    )
    """
