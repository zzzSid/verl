# Agent Guidelines for tpp-onemodel

## Build Commands

```bash
# Setup development environment
make dev                    # Install package in editable mode with dev dependencies
make install               # Install package without dev dependencies

# Build package
make build                 # Build distribution packages
make clean                 # Remove intermediate files
make deepclean            # Clean + remove virtualenv and pre-commit hooks

# Additional commands
make trace                # Run plannn2 trace test
make conf                 # Generate planner configs
make proto                # Generate protobuf Python files
```

## Lint/Test Commands

```bash
# Run all linting
make lint                  # Run mypy, flake8, toml-sort

# Individual lint tools
make black                 # Format code with black
make mypy                  # Type checking
make flake8               # Style checking
make toml-sort            # Sort pyproject.toml
make pre-commit           # Run pre-commit on all files

# Testing
make test                  # Run all tests with coverage
pytest tests/pkg_test.py                    # Run single test file
pytest tests/data/dataset/planner_dataset_test.py::test_planner_dataset  # Run single test
pytest -xvs tests/                         # Run with verbose output, fail fast
pytest -k "test_planner" tests/            # Run tests matching pattern
```

## Code Style Guidelines

### File Headers
- Use UTF-8 encoding declaration: `# -*- coding: utf-8 -*-`
- Add module docstring after encoding declaration

### Formatting
- **Line length**: 120 characters (configured in black and flake8)
- **Formatter**: Black (enforced)
- **Import style**: Single-line imports only (force_single_line = true)
- **Quotes**: Double quotes for strings, docstrings, and multiline strings

### Imports
- Use `force_single_line = true` - each import on its own line
- Group imports: stdlib, third-party, local
- Two blank lines after imports
- Use absolute imports only
- Example:
```python
# -*- coding: utf-8 -*-
"""Module docstring."""
from typing import List

import numpy as np
import torch

from tpp_onemodel.utils.common_utils import timer
```

### Type Hints
- Use type hints for function parameters and return types
- Use `typing` module imports (List, Dict, Optional, etc.)
- Mypy is enforced with `ignore_missing_imports = true`
- Disable union-attr warnings: `disable_error_code = ["union-attr", "annotation-unchecked"]`

### Naming Conventions
- **Functions/variables**: snake_case
- **Classes**: PascalCase
- **Constants**: UPPER_SNAKE_CASE
- **Private**: _leading_underscore for internal use
- Module names: snake_case

### Docstrings
- Use double quotes for docstrings
- First line is a brief summary
- Follow Google style or PEP257
- All public modules, functions, classes need docstrings

### Error Handling
- Use specific exceptions over generic ones
- Log errors with context using torchpilot.logger
- Avoid bare except clauses

## Project Structure

```
tpp_onemodel/              # Main package
├── data/                  # Dataset and dataloader
├── model/                 # Model architectures
│   ├── head/             # Model heads
│   ├── loss/             # Loss functions
│   ├── module/           # Model modules
│   └── ops/              # Custom CUDA ops
├── runner/               # Training/inference runners
├── evaluator/            # Evaluation metrics
└── utils/                # Utility functions

tests/                     # Test directory
├── conftest.py           # Pytest fixtures
├── data/                 # Data-related tests
├── end2end/              # End-to-end tests
└── utils/                # Utility tests
```

## Pre-commit Hooks

Pre-commit runs automatically on push. Configured hooks:
- check-added-large-files, check-json, check-yaml
- end-of-file-fixer, trailing-whitespace
- black, mypy, flake8, toml-sort

Install manually: `pre-commit install --hook-type pre-push`

## Testing Guidelines

- Test files: `*_test.py` pattern
- Use pytest fixtures defined in `conftest.py`
- Tests require NCCL backend initialization (see conftest.py)
- Coverage threshold: 80% (enforced in CI)
- End-to-end tests in `tests/end2end/`

## Environment Variables

Key variables for testing:
- `CACHE_URI`: NIOFS cache URI
- `NIOFS_ACCESS_KEY` / `NIOFS_SECRET_KEY`: NIOFS credentials
- `CI_CPU_JOB=1`: Skip CUDA compilation
- `TORCH_VERSION`: Specify PyTorch version

## Dependencies

- Python >= 3.8
- PyTorch with CUDA support
- See `requirements.txt` for runtime deps
- See `requirements-dev.txt` for dev deps

### NN3 visual / ceph IO (aligned with `plannn3/setup_env.sh`)

| Package | Where pinned | nn3 reference |
|---------|--------------|---------------|
| `read-cache-op-py` | `requirements/base.txt` → `1.9.6.dev7` | `setup_env.sh` |
| `argus_util` | `requirements/ncard.txt` or `requirements/ppu.txt` (internal wheel) | GPU / PPU wheel paths |

Installed with `make install` / `make dev` (no extra script). Enable visual in `cfg_plannn3.py` via `ENABLE_NN3_VISUAL=1`.

## CI/CD

- GitLab CI with `.gitlab-ci.yml`
- Stages: lint_test
- GPU tests run on A100 nodes
- CPU jobs use `CI_CPU_JOB=1` to skip CUDA builds
