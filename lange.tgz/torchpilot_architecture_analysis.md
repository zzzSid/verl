# TorchPilot 仓库深度分析报告

> 分析对象：`/home/joeden.zhuang/melange/torchpilot/`
> 代码规模：核心 ~14k+ 行（不含 layer/ 与 base_model/ 详细实现）
> 定位：自动驾驶/视觉任务下的**分布式训练 + 推理 + 模型导出**的统一框架，重度强调可配置、可扩展、可观测，并对多任务、视频、多相机数据有专门优化。

---

## 1. 总览（Executive Summary）

TorchPilot 是一个**配置驱动 + 注册表组装**的训练框架，其上层抽象很像 MMEngine / Detectron2，但底层做了几个针对量产场景的强化：

- **任务流抽象 `TPTaskFlow`**：一个对象同时承载训练前向、推理前向、loss 组装、postprocess、trace/TVM 导出钩子、FSDP 包装、optimizer policy。模型是"组件"，TaskFlow 是"流水线"。
- **数据子系统是真正的差异点**：自研 `TPDataLoader` + 共享内存解码池 + `ArgusCameraDataset`（多相机视频元信息）+ 多任务采样器，专门服务"几路相机视频从 S3 拉取 → 异步解码 → 零拷贝喂卡"的吞吐瓶颈场景。
- **训练器 `TPTrainer` 是生命周期式的** ：DDP/FSDP/SyncBN/PowerSGD/AMP(FP16/BF16)/梯度累积/梯度裁剪/Profiler/CUDA Memory Snapshot/CUDA op 级耗时分解 全部内置且通过开关控制。
- **基础设施模块化**：Registry、PyConfig、CheckpointManager、FileManager、EventManager（Kafka）、MessageHub（多进程错误聚合）、Stopwatch、TensorboardManager、Plus（entry_points 插件）每个都是独立的、init-once-then-use 的管理器。
- **入口极简**：CLI 只有一个 `torchpilot run <device_num> <config>`，所有差异通过 `cfg`、`infer_type`、`export_type` 三个开关与配置文件表达。

---

## 2. 顶层目录结构

```
torchpilot/
├── __init__.py              # 仅做 log_init + disable_kmp_affinity
├── cli.py                   # click 命令行入口
├── runner/                  # 训练 / 推理 / 启动器
│   ├── ddp_launcher.py      # __main__ → cli.run
│   ├── ddp_launcher_run.py  # spawn / mpi 两种启动模式
│   ├── trainer/             # BaseTrainer → TPTrainer → MultiTaskTrainer
│   └── inferrer/            # BaseInferrer → TPInferrer → MultiTaskInferrer
├── model/
│   ├── module_interface.py  # BaseModule, BaseTaskModel
│   ├── task/                # TPTaskFlow + 各任务流
│   ├── base_model/          # ResNet / ViT 主干
│   ├── layer/vit/           # ViT 子层（block/attn/mlp/...）
│   ├── loss/                # BaseLoss + Compose / MultiTask / CE / Smooth
│   ├── postprocessing/
│   ├── head/ module/ ops/   # 占位/扩展点（通过 registry 注入）
├── optimizer/               # build_optimizer + BaseLrScheduler 体系
├── data/
│   ├── dataloader/          # TPDataLoader + torch_dataloader/worker/fetch + 解码 worker
│   ├── dataset/             # BaseDataset / Argus / Multitask / Video / Imagenet
│   ├── sampler/             # 分布式 / 多任务 / 视频采样器
│   └── transform/           # 2D / 3D 变换
├── evaluator/               # ImageNet / MultiTask / Argus 评估器
├── logging/                 # TPLogger / MessageHub / message_type
├── tools/                   # checkpoint 工具脚本
└── utils/                   # PyConfig / Registry / Dist / Ckpt / File /
                             # Event / Stopwatch / Tensorboard / Settings ...
```

---

## 3. 启动链路（从命令行到一次训练 step）

[cli.py:23](torchpilot/cli.py#L23) → [ddp_launcher_run.run()](torchpilot/runner/ddp_launcher_run.py#L327) → `spawn_launcher` 或 `mpi_launcher` → `runtime_program` → `TRAINER.build(args).train()`

主要阶段：

1. **CLI 解析**：参数包括 `device_num`、`config`、`run_name`、`infer_type`、`export_type`、`ckpt`、`resume`、`port`、`dataset_mode`。
2. **广播运行参数**：`run_name` 与 `port` 由 rank0 通过 `mpi_broadcast_obj` 广播，保证多机一致。
3. **后端选择**：`settings.backend` 自动从 `NCCL > MPI > GLOO` 选择；`launch_mode` 决定走 `spawn` 还是 `mpi`。
4. **每个进程入口** (`spawn_run` / `mpi_run`)：
   - `torch.distributed.init_process_group`
   - `FileManager.init(cfg, run_name, resume, rank)` 创建 / 校验实验目录
   - `log_init` + `log_file_init` 初始化分级日志
   - `load_plus()` 通过 entry_points 装载外部注册的组件
   - GPU 亲和性绑核（`set_affinity`）
5. **`runtime_program`**：用 `PyConfig.fromfile` 解析配置；按是否有 `infer_type/export_type` 二选一，从 `TRAINER` 或 `INFERRER` 注册表 build 对象并调用 `.train()` / `.infer()`。
6. **退出**：`atexit.register(cleanup)` 启用一个 10 秒超时定时器去 `destroy_process_group`，避免卡死。

> 设计观察：`runtime_program` 是单一职责的"配置 → runner 实例 → 跑"分发器；所有"如何分布式启动"被封装在 launcher 里，runner 本身不知道 spawn 还是 mpi。

---

## 4. 配置与注册系统

### 4.1 `PyConfig`（[utils/cfg_parser.py](torchpilot/utils/cfg_parser.py)）

- 配置文件就是普通 Python 文件（典型命名 `exp_xxx.py`），通过临时插入 `sys.path` 导入。
- 顶层非 dunder 变量被包成 `ConfigDict`（基于 `addict.Dict`），同时支持 `cfg.foo` 与 `cfg["foo"]`。
- 没有 MMEngine 那种 `_base_` 多重继承机制 —— 鼓励**通过 Python import 显式组合**。

### 4.2 注册表（[utils/cls_register.py](torchpilot/utils/cls_register.py) + [utils/registries.py](torchpilot/utils/registries.py)）

提供 `Registry`、`build_from_cfg` 与装饰器 `register_module`，并预定义近 17 个全局注册表：

```
INFERRER, TRAINER,
DATASET, DATALOADER, TRANSFORM, SAMPLER,
TASK_FLOW, TASK_MODEL, BASE_MODEL, MODULE, LAYER, HEAD,
LOSSES, OPTIMIZER, LR_SCHEDULER, EVALUATOR, POSTPROCESS
```

构建模式统一为：
```python
obj = SOMEREG.build({"type": "ClassName", "<其它构造参数>": ...})
```

### 4.3 Plus（[utils/plus_manager.py](torchpilot/utils/plus_manager.py)）

通过 Python `entry_points` 把外部包的类映射到上述注册表中的某一项 —— 这就是用户**不改 torchpilot 源码也能扩展**的方式。`load_plus()` 在每个 worker 进程启动后被调用。

### 4.4 Settings（[utils/settings.py](torchpilot/utils/settings.py) / [utils/constants.py](torchpilot/utils/constants.py)）

Pydantic 模型读取环境变量，关键枚举：
- `LaunchMode`: `MPI` / `SPAWN`
- `Backend`: `gloo` / `mpi` / `nccl`
- `JobType`: `job` / `workshop` / `workspace`
- 还有 `output_dir`、`enable_compile`、Kafka broker、CI flag、`NTS_JOB_NAME` 等。

---

## 5. 数据子系统

数据是 torchpilot 区分于普通训练框架的**最重的子系统**，用来扛多相机视频训练的 IO 压力。

### 5.1 类层级

```
torch.utils.data.DataLoader
   └── TPDataLoader            (data/dataloader/tp_dataloader.py:34)
         └── MultiTaskDataLoader (data/dataloader/multitask_dataloader.py:15)

BaseDataset (ABC)              (data/dataset/base_dataset.py:29)
   ├── BaseVideoDataset        (data/dataset/base_dataset.py:223)
   ├── ImageNetDataset
   ├── MultiTaskDataset        (聚合多个子任务数据集)
   └── ArgusCameraDataset      (data/dataset/argus_dataset.py:700)
            (混合: ArgusCameraAsyncDecodeInterface + ArgusCameraDatasetDecodeInterface + BaseDataset)

torch.utils.data.Sampler
   └── TPDistributedSampler                       (tp_distributed_sampler.py:32)
        ├── MultiTaskDistributedSampler           (按任务返回 dict[task]→indices)
        ├── MultiTaskDistributedBatchedSampler
        └── TPDistributedVideoSampler             (按视频组采样、保持时序)
```

### 5.2 流水线（DataLoader → Worker → Dataset → Decoder）

1. `TPDataLoader.__init__`（[tp_dataloader.py:108](torchpilot/data/dataloader/tp_dataloader.py#L108)）：
   - 由 `DATASET.build` 构建 dataset，校验是 `BaseDataset`；
   - 抽出 dataset 自带的 `batch_collate`；
   - 由 `SAMPLER.build` 构建 sampler；
   - 调用父类 `DataLoader.__init__` 同时传入解码 worker 配置（`enable_prefetch_decoder`、`decoder_worker_num`、`enable_shared_decoder`、`prefetch_decoder_using_mem_percent`）。
2. **Worker 进程**（torch_worker.py）调用 `_DatasetKind.create_fetcher` → `dataset.__getitem__(index)` → `collate_fn`。
3. **Pin Memory** 经过定制（`tp_dataloader.py:207-223`），允许 batch 同时含 CPU/GPU 张量。
4. **State 管理**：`set_state(epoch, step, indices)` / `get_state()`（[tp_dataloader.py:219](torchpilot/data/dataloader/tp_dataloader.py#L219)）保证训练中断后从同一索引位置恢复 —— 这是和 trainer 的 `check_resume_states` 配套工作的。

### 5.3 异步视频解码池（性能关键）

当 `enable_prefetch_decoder=True`（[decoder_worker.py:163](torchpilot/data/dataloader/decoder_worker.py#L163) `decoder_loop_prefetch_decoder`）：

- 在 DataLoader 进程中开三块**共享内存**（pinhole / srcw / svc 三种相机），单块约 ~2500 个 buffer。
- 起两个后台线程：
  - `_set_shm_loop`：把解码后的帧写入 SHM 环形缓冲区。
  - `_load_s3_loop`：调 `dataset.predecode_video_func()` 提前把视频从 S3/Ceph 拉本地。
- 主解码循环：调 `dataset.decode_video_func_async()`，使用多解码器并发（`multi_decoder` / `multi_convertor`）。
- Torch worker 通过 `update_decode_res_to_index` 把 SHM 位置交给 `__getitem__`，**避免跨进程内存拷贝**。

### 5.4 ArgusCameraDataset 关键事实

- 多相机命名：`fw / fl / fn / fr / rl / rn / rr`（前/前左/前中/前右/后左/后中/后右）。
- 关键帧窗口：`key_frames=[0, 5, 10]` 表示当前及历史第 5、10 帧 —— 时序信息可控。
- 元信息：嵌套 dict，含 `sensor_video_info_dict`、`decode_video_meta_list`，由 pickle 保存。
- 典型张量形状：
  - 针孔相机：`(3, 1056, 1824)`
  - SVC 环视：`(3, 384, 480)`

### 5.5 多任务

- `MultiTaskDataset` 持有 `task_name → sub_dataset`，且各子 dataset **共享同一组解码器/转换器**，`__getitem__` 返回 `Dict[task_name] → batch_data`。
- `MultiTaskDistributedSampler` 一次产出 `Dict[task] → List[idx]`，用 `valid_task_loop` 控制任务调度顺序。
- `MultiTaskDataLoader` 重写 `move_data_to_cuda` 递归 pin。

### 5.6 关键配置项摘录

| Key | 作用 |
|---|---|
| `dataset_cfg` / `sampler_cfg` | 注册表 build 输入 |
| `batch_size` (int 或 dict) | 单卡 batch；多任务可按任务设 |
| `num_workers` / `persistent_workers` | torch DataLoader 标准项 |
| `enable_prefetch_decoder` | 打开异步解码池 |
| `decoder_worker_num` | 解码进程数（受限于 num_workers） |
| `enable_shared_decoder` | 与 prefetch 互斥的共享解码器 |
| `prefetch_decoder_using_mem_percent` | 解码池内存预算（默认 0.2） |
| `to_cuda` | DataLoader 内部完成 H2D |
| `pin_memory` | 自定义 pin（兼容混合张量） |

---

## 6. 模型子系统

### 6.1 三层抽象

| 层 | 抽象 | 职责 |
|---|---|---|
| L1：组件 | `BaseModule` ([module_interface.py:23](torchpilot/model/module_interface.py#L23)) | 通用块；`forward` 按 `_train_mode` 路由到 `train_forward` / `infer_forward` |
| L2：任务模型 | `BaseTaskModel` ([module_interface.py:74](torchpilot/model/module_interface.py#L74)) | 整端到端模型；`train_forward(Dict)→Dict`，`infer_forward(Tensor)→Tuple/namedtuple` |
| L3：任务流 | `TPTaskFlow` ([tp_task_flow.py:35](torchpilot/model/task/tp_task_flow.py#L35)) | 任务模型 + 损失 + 后处理 + trace/TVM 钩子 + FSDP wrap + optim policy |

> 关键约定：训练态返回 dict（损失计算需要按 key 取），推理态返回有序 tuple/namedtuple（trace/TVM 必需）。这条约定贯穿整个框架。

### 6.2 `TPTaskFlow` 训练 / 推理流水线管理

`TPTaskFlow` 本质上是个 `torch.nn.Module` 包装器：对外暴露统一的 `forward(inputs)`，对内根据 `_train_mode` 把输入分发到两条**完全不同的多阶段执行链路**，并用同一个 `stopwatch` 把每个阶段串成可观测的 timeline。它本身不训练，被 `TPTrainer` / `TPInferrer` 当成模型用 —— 所以"流水线管理"指的是它在**一次前向调用内部**完成的多阶段编排。

#### 6.2.1 构造期：编排所需组件（[tp_task_flow.py:46-80](torchpilot/model/task/tp_task_flow.py#L46-L80)）

`__init__` 完成"零件装配"，决定后续 forward 走哪些阶段：

| 步骤 | 代码位置 | 做什么 |
|---|---|---|
| 1 | line 57 | 绑定全局 `stopwatch` 单例 |
| 2 | line 58 | `self._task_model = TASK_MODEL.build(task_model_cfg)` —— 注册表实例化任务模型 |
| 3 | line 59-63 | 校验 `task_model` 必须是 `BaseTaskModel` 子类 |
| 4 | line 65-72 | 训练态强制要求 `loss_func_cfg`；基类只占位（`self._loss_func = None`），**子类负责真正构建**（如 [imagenet_task_flow.py:42-43](torchpilot/model/task/imagenet_task_flow.py#L42-L43) 的 `LOSSES.build(loss_func_cfg)`） |
| 5 | line 74-76 | 没有 postprocess 配置则置空，否则由子类 `POSTPROCESS.build` 构建 |
| 6 | line 78 | `self._task_model.set_mode(train_mode)` —— **把模式向下传给 task_model**，让它内部 `forward` 也能分发 |
| 7 | line 79-80 | 缓存 `_train_mode` / `_enable_pbn` 标志 |

> `TPTaskFlow` 把"用哪个 loss / 哪个 postprocess / 是否 trace 友好"的差异留给子类，自身只规定流水线骨架。

#### 6.2.2 训练态前向流水线（`_train_mode=True`，[tp_task_flow.py:146-158](torchpilot/model/task/tp_task_flow.py#L146-L158)）

调用方：`TPTrainer.forward_backward_model` → `model(batch_data)`，输入是 dataloader 出的 `Dict[str, Any]`。

```
DataLoader batch (Dict)
        │
        ▼
┌──────────────────────────────────────────────────────────────┐
│ Step 1: stopwatch 接力计时                                   │
│   有 ddp_cost 计时 → record_time_cost("ddp_cost",            │
│                            "model_forward_cost")             │
│   否则                → tic("model_forward_cost")            │
│   (line 129-132)                                             │
├──────────────────────────────────────────────────────────────┤
│ Step 2: 调任务模型 train_forward                             │
│   train_outputs = self._task_model(inputs)   # line 146      │
│     ── BaseTaskModel.forward 因 set_mode(True) 已生效         │
│        → 路由到 train_forward(inputs: Dict) → Dict           │
├──────────────────────────────────────────────────────────────┤
│ Step 3: 关闭 model_forward 计时                              │
│   record_time_cost("model_forward_cost", None)  # line 147   │
├──────────────────────────────────────────────────────────────┤
│ Step 4: 可选 postprocess（仅当 _postprocess_layer != None）  │
│   tic("postprocess_layer_cost")                              │
│   train_outputs = self._postprocess_layer(train_outputs)     │
│   record_time_cost("postprocess_layer_cost", None)           │
│   (line 149-152)                                             │
├──────────────────────────────────────────────────────────────┤
│ Step 5: 计算 loss                                            │
│   tic("compute_loss_cost")                                   │
│   loss_dict = self.compute_loss(train_outputs, inputs)       │
│       └── 默认实现: self._loss_func(outputs, inputs)         │
│           子类可重写 compute_loss 走更复杂的 dispatch         │
│   record_time_cost("compute_loss_cost", None)                │
│   (line 154-156)                                             │
├──────────────────────────────────────────────────────────────┤
│ Step 6: 返回 (train_outputs, loss_dict)  (line 158)          │
└──────────────────────────────────────────────────────────────┘
        │
        ▼
TPTrainer 拿到 (outputs, loss_dict) → _train_parse_losses → backward
```

要点：

- **输入 Dict、输出 (Dict, Dict)**：是和推理态最关键的格式区别。`compute_loss(outputs, inputs)` 同时拿到模型输出和原始 batch（含 gt），所以 loss 函数签名是 `forward(model_outputs, model_inputs)`。
- **stopwatch 与 trainer 的 `ddp_cost` 接力**：trainer 在每步开头记 `ddp_cost`，TaskFlow 进来立刻把它收尾、并启动 `model_forward_cost`，从而拼出"通信→前向→后处理→loss"的连续 timeline。
- **子类可整段重写 forward**：[imagenet_task_flow.py:84-109](torchpilot/model/task/imagenet_task_flow.py#L84-L109) 直接抽 `inputs["image"]` 走更简洁的 `record_time_cost("model_forward_cost", "compute_loss_cost")` 一次性接力。

#### 6.2.3 推理态前向流水线（`_train_mode=False`，[tp_task_flow.py:133-144](torchpilot/model/task/tp_task_flow.py#L133-L144)）

调用方：`TPInferrer.forward_model` → `model(batch_data)`。

```
DataLoader batch (Dict, 已经过 convert_model_inputs)
        │
        ▼
┌──────────────────────────────────────────────────────────────┐
│ Step 1: 同样的 stopwatch 接力 (line 129-132)                 │
├──────────────────────────────────────────────────────────────┤
│ Step 2: 调任务模型 infer_forward —— 注意是 **inputs 解包      │
│   infer_outputs = self._task_model(**inputs)   # line 136    │
│     ── BaseTaskModel.forward 因 set_mode(False) 已生效        │
│        → 路由到 infer_forward(*tensors) → Tuple/namedtuple   │
│                                                              │
│   为什么用 **inputs 而不是 inputs?                           │
│     注释 line 134-135: "torch.jit.trace 要求参数是若干 Tensor"│
│     所以推理签名是位置参数 Tensor，trace 才能拿到正确的图     │
├──────────────────────────────────────────────────────────────┤
│ Step 3: 关闭 model_forward 计时 (line 137)                   │
├──────────────────────────────────────────────────────────────┤
│ Step 4: 可选 postprocess (line 139-142)                      │
├──────────────────────────────────────────────────────────────┤
│ Step 5: 直接返回 infer_outputs (没有 loss)  (line 144)       │
└──────────────────────────────────────────────────────────────┘
        │
        ▼
TPInferrer.convert_model_outputs → evaluator.eval(outputs, batch)
```

推理态关键设计：

- **输出必须是 Tuple/namedtuple**：`torch.jit.trace` 不支持 dict 返回。`ImageNetTaskFlow` 在 `trace_model_outputs_hook` 中显式包成 `namedtuple("model_outputs", ["model_outputs"])(...)`（[imagenet_task_flow.py:82](torchpilot/model/task/imagenet_task_flow.py#L82)），保证 trace 后还能用属性访问。
- **不计算 loss、不回写 postprocess**：评估指标由外部 `evaluator.eval` 完成。

#### 6.2.4 三种推理后端的 IO 适配钩子（[tp_task_flow.py:82-96](torchpilot/model/task/tp_task_flow.py#L82-L96)）

`TPTaskFlow` forward 本身只一份，但 trace / TVM 的 IO 形式不同，所以 `TPInferrer` 在调用模型前后会调用如下钩子做格式转换：

| Hook | 何时调用 | 干什么 |
|---|---|---|
| `tvm_model_inputs_hook` | TVM 推理前 | Dict → numpy array dict（如 `{"inputs_0": img.cpu().numpy()}`） |
| `tvm_model_outputs_hook` | TVM 推理后 | numpy → Tensor → namedtuple |
| `trace_model_inputs_hook` | trace 推理前 | Dict → 单个 Tensor（trace 必须） |
| `trace_model_outputs_hook` | trace 推理后 | tuple → namedtuple，恢复属性访问 |

#### 6.2.5 流水线相关但不在 forward 内的两件事

- **FSDP 包装**（[tp_task_flow.py:201-215](torchpilot/model/task/tp_task_flow.py#L201-L215)）：trainer 检测 `_fsdp=True` 时调 `task_flow.warpper_model_for_fsdp_training()`，TaskFlow 把 `_task_model` 用 `FullyShardedDataParallel` 重新包一层（`MixedPrecision(fp32,fp32,fp32)`，注释写明"精度优先"），分片通信对 forward 透明。
- **优化器分组策略**（[tp_task_flow.py:184-199](torchpilot/model/task/tp_task_flow.py#L184-L199)）：trainer build optimizer 前调 `task_flow.get_optim_policies()`。基类只返回单组；子类如 [imagenet_task_flow.py:111-199](torchpilot/model/task/imagenet_task_flow.py#L111-L199) 遍历 `self.modules()` 拆成 `first_conv_weight / first_conv_bias / normal_weight / normal_bias / batch_norm / other_modules` 六组，附 `lr_mult / decay_mult / name`，给 trainer 做差分 LR / 差分 wd。

#### 6.2.6 一句话总结

`TPTaskFlow` 用**一个 `_train_mode` 开关 + 两条阶段化 forward 路径 + 一组导出钩子**实现"同一份模型代码同时支撑训练 / 推理 / trace / TVM 四种执行场景"，每个阶段都被 `stopwatch` 串成可观测 timeline：

```
训练: ddp_cost → model_forward_cost → [postprocess_layer_cost] → compute_loss_cost  → (outputs, loss_dict)
推理: ddp_cost → model_forward_cost → [postprocess_layer_cost]                      → infer_outputs(tuple)
导出: get_trace_model() / load_tvm_model() + (trace|tvm)_model_(inputs|outputs)_hook
FSDP: warpper_model_for_fsdp_training() 在 forward 之前对 _task_model 重新包装
```

### 6.3 多任务模型 `MultiTaskRes50ImageNet*`

- Backbone 共享、按任务 FC 头：`_cls_full_catenate0`, `_cls_full_catenate1`...
- `train_forward` 按 `inputs["task_name"]` 选头；
- `infer_forward` 计算所有头并打包为 namedtuple（trace 友好）。

### 6.4 主干

- ResNet：标准 BasicBlock/Bottleneck 实现。
- ViT：`DinoVisionTransformer` + `NestedTensorBlock` + `MemEffAttention` + `LayerScale` + `SwiGLUFFN`，明显是 DINOv2 派生的实现栈，工厂函数 `vit_tiny/small/base/large/giant2`。

### 6.5 Loss

- `BaseLoss.forward(outputs: Dict, inputs: Dict) → Dict[str, Tensor]`。
- `ComposeWeightedLoss`：列表 `[{loss_cfg, loss_weight}]`，逐个加权后**合并到一个扁平 dict**，键冲突会显式报错。
- `MultiTaskLoss`：按 `task_name` 路由到子 loss，再乘以 `task_loss_weight[task_name]`。
- `CrossEntropyLoss` / `CrossEntropyLossDistill`（teacher-student KL + NLL）/ `SmoothLoss`。

### 6.6 Postprocess

`BasePostProcess` 拆 `train_postprocessing` 与 `infer_postprocessing`，作为 TaskFlow 中的可选层。

---

## 7. 优化器与 LR 调度

### 7.1 `build_optimizer`（[optimizer/base_optimizer.py:24](torchpilot/optimizer/base_optimizer.py#L24)）

输入 `params_policy = [{"params": [...], "lr_mult": float, "decay_mult": float, "name": str}, ...]`：

- 按 `lr_mult` 缩放每组 LR；
- 若 `enable_use_decay_mult=True`，按 `decay_mult` 缩放 weight decay；
- 若 `enable_bn_weight_decay=False`，BN 组的 wd 置零；
- 包成 `SGD` / `Adam` / `AdamW`。

`TaskFlow.get_optim_policies()` 决定参数分组。`ImageNetTaskFlow` 显式拆出 first conv / normal weight / bias / BN / others 五大类，各自带 `name` 便于日志追踪。

> 关键缩放规则（trainer 中应用）：`lr = lr_per_sample * gpu_num * bs_per_gpu`（[tp_trainer.py:426](torchpilot/runner/trainer/tp_trainer.py#L426)）—— 即 LR 跟全局 batch 线性缩放。

### 7.2 LR Scheduler（[optimizer/base_lr_scheduler.py](torchpilot/optimizer/base_lr_scheduler.py)）

- `BaseLrScheduler`：管理每个 param group 的 base_lr，通过 `lr_mult` 在 `init_base_lr` 阶段建立基线；支持 `constant / linear / exp` warmup。
- 内置 `EpochLrScheduler`（按 epoch 边界 step decay）与 `CosineLrScheduler`（带 min_lr）。
- 对外接口：`step(global_step, cur_epoch)` 由 trainer 在每步后调用。
- 支持多个 optimizer（多任务场景）。

---

## 8. 训练子系统：`TPTrainer` 全景

`TPTrainer`（~1700 行）是整个框架最复杂的类，实现"训练生命周期 + 分布式 + 混精度 + 性能剖析 + 日志 + 检查点"的复合状态机。

### 8.1 初始化流水线（[tp_trainer.py:146](torchpilot/runner/trainer/tp_trainer.py#L146)）

1. 设置随机种子 / 可选确定性（`enable_deterministic`）。
2. `DATALOADER.build` 构建 dataloader；推算 epoch_size、batch sizes。
3. `TASK_FLOW.build` 构建模型，校验是 `TPTaskFlow`。
4. 构建 `CheckpointManager` 并按需 `load_pretrain` 或 `resume`。
5. 用 `task_flow.get_optim_policies()` + 全局 LR 调用 `build_optimizer`。
6. `_warp_taskflow_to_ddp_model`（[tp_trainer.py:443](torchpilot/runner/trainer/tp_trainer.py#L443)）：
   - 可选 `SyncBatchNorm.convert_sync_batchnorm`（按 8 卡一组的 process_group）；
   - DDP 包裹（`bucket_size`、`find_unused_parameters`、`static_graph` 可调）；
   - 可选 PowerSGD 通信压缩 hook；
   - 或走 FSDP（要求 model 实现 `warpper_model_for_fsdp_training`）。
7. 构建 GradScaler：FP16 → `GradScaler`，BF16 → `FixedGradScaler`（永不更新 scale），FSDP → `ShardedGradScaler`。
8. 构建 LR Scheduler。
9. 注册 dataloader 的 worker 错误回调（接 `MessageHub`）。

### 8.2 三级训练循环

- `train()` ([tp_trainer.py:760](torchpilot/runner/trainer/tp_trainer.py#L760))：epoch 外循环 + 异常时落盘 + 资源释放。
- `train_one_epoch()` ([tp_trainer.py:982](torchpilot/runner/trainer/tp_trainer.py#L982))：步内循环 + 周期性日志 + 周期性 ckpt + 可选的"训练中评估"（异步分支）。
- `train_one_step()` ([tp_trainer.py:1204](torchpilot/runner/trainer/tp_trainer.py#L1204))：
  - `need_sync = (step+1)%grad_accumulate_step==0 or epoch_end`；
  - 不需要同步时用 `model.no_sync()` 上下文，避免无意义的 all-reduce；
  - `forward_backward_model` → 可选梯度裁剪（`scaler.unscale_` 后）→ `scaler.step(opt)` + `scaler.update()`；
  - `lr_scheduler.step(global_step, epoch)`；
  - 教师动量更新（自监督支持）。
- `forward_backward_model()` ([tp_trainer.py:1146](torchpilot/runner/trainer/tp_trainer.py#L1146))：可选 `autocast(dtype=_amp_dtype)` → `_train_parse_losses` → `loss / grad_accumulate_step` → `scaler.scale(loss).backward()`。

### 8.3 并行 / 混精度细节速查

| 特性 | 开关 / 实现 |
|---|---|
| DDP | 默认；`bucket_size` / `find_unused_parameters` / `static_graph` 可配 |
| FSDP | `_fsdp=True`；TaskFlow 必须实现 `warpper_model_for_fsdp_training` |
| SyncBN | `_use_sync_bn=True`；按 8 卡分 process_group |
| PowerSGD | DDP comm hook；几行代码注册 |
| AMP FP16 | `_use_fp16=True` + `GradScaler` |
| AMP BF16 | `_use_bf16=True` + `FixedGradScaler`（保持 scale 常数） |
| 梯度累积 | `_grad_accumulate_step`；中间步 `no_sync()` |
| 梯度裁剪 | `scaler.unscale_(optimizer)` 后做 `clip_grad_norm_` |
| Loss 同步 | `_enable_sync_loss=True` 时 all-reduce loss 用于打印 |

### 8.4 性能剖析

- 全局 `stopwatch` 单例（[utils/stopwatch.py:69](torchpilot/utils/stopwatch.py#L69)）：CPU + CUDA Event 双计时；`tic / record_time_cost(prev, next)` 串成 timeline。
- `_use_profiler=True` 时挂 PyTorch Profiler（schedule wait/warmup/active），同时 dump CUDA memory snapshot（torch>=2.0）。
- `log_cuda_events`（[tp_trainer.py:615](torchpilot/runner/trainer/tp_trainer.py#L615)）按 op name 聚合 CUDA 时间，区分 dense / sparse 计算占比。

### 8.5 Hook 系统

`register_hook(func_name, func)` ([tp_trainer.py:1449](torchpilot/runner/trainer/tp_trainer.py#L1449))，目前框架内置识别：

- `custom_indices_generator`：每 epoch 生成 sampler 索引；
- `custom_sampler_indices`：每 step 拿到 log_vars / outputs 后回写采样索引（在线 hard mining）。

虽然不是 mmengine 那种万能 hook 链，但足以支撑"动态采样、按 loss 调度数据"等需求。

### 8.6 子类化示例

`MultiTaskTrainer` 仅重写 `forward_backward_model`，循环遍历各任务 batch 即可 —— 体现了 base trainer 的扩展点设计。

---

## 9. 推理与导出：`TPInferrer`

[runner/inferrer/tp_inferrer.py](torchpilot/runner/inferrer/tp_inferrer.py)

- 同样使用 `BaseInferrer` 模板：`load_model_file → infer → infer_one_epoch → infer_one_step`。
- 三种后端通过 `infer_type` 切换：
  - `torch`：DDP 包裹的常规 PyTorch 模型；
  - `trace`：`task_flow.load_traced_model` + autocast；
  - `tvm`：`task_flow.load_tvm_model` + 直接 `model.run`。
- `convert_model_inputs / convert_model_outputs` 在每 step 调用对应 hook，把 dataloader 的 batch 转成各后端期望的形式。
- `infer()` 流程：导出模式（`export_type=trace`）跑一次 `export_trace_model` → `torch.jit.save`；评估模式则遍历 `_eval_ckpt_list`，每个 ckpt 跑完一遍 `infer_one_epoch`，结尾 `evaluator.dist_all_reduce()` + `save_eval_results` 写 JSON。
- `MultiTaskInferrer` 仅扩展 `infer_one_step` 以遍历多任务 batch。

---

## 10. 检查点与文件管理

### 10.1 `CheckpointManager`（[utils/checkpoint_manager.py](torchpilot/utils/checkpoint_manager.py)）

- 落盘内容：`{epoch, step, model, optimizer, lr_scheduler, scaler}`，rank0 单写（`@rank_zero_only`）。
- 文件命名：`checkpoint_last.pth.tar` + 按 epoch/step 周期保存的 `epoch_XXX_step_XXXX.pth.tar`，并用 deque 实现 LRU 旋转（`max_save_ckpt_num`）。
- Resume：strict load；Pretrain：non-strict + 缺失/多余 key 报告。
- 自动处理：
  - `module.` 前缀（DDP ↔ 单卡）；
  - `_orig_mod.` 前缀（torch.compile）；
  - JSON `ckpt2model_json` 用于结构性 rename；
  - FSDP 通过 `FullyShardedDataParallel.optim_state_dict` 落盘。
- "排除 teacher 权重"等具体规则：默认 ckpt 不带 `teacher.*` 键，避免推理 ckpt 体积膨胀。

### 10.2 `FileManager`（[utils/file_manager.py](torchpilot/utils/file_manager.py)）

强制目录约定：

```
output_dir / task_*  / exp_*  / run_name / { ckpt, export, log, summary }
```

- 新 run：rank0 创建目录、复制配置；非 rank0 通过 `dist_barrier()` 等待。
- Resume：用 `filecmp.cmp` 校验当前 cfg 与磁盘上保存的 cfg **逐字节相同**，否则报错（防止配置漂移）。
- 忽略模式：`.*`、`_*`、output 目录本身。

> 这套约定意味着：要 resume，必须用**完全相同的配置文件**重新启动。

---

## 11. 分布式管理（[utils/dist_manager.py](torchpilot/utils/dist_manager.py)）

- 双后端抽象：torch.distributed + mpi4py（可选）。
- `DistSpawnInfo`：spawn 模式下，从 hostname 解析 `node_rank`，再算 `global_rank = node_rank * gpus_per_node + local_rank`。
- `build_machine_connection`：rank0 起 TCP server，其它节点 client 握手；返回值 `status` 决定是否进入训练。
- `mpi_broadcast_obj` / `dist_abort`：跨节点广播 / 异常时优雅退出（`MPI.Comm.Abort()`）。
- `get_actual_gpu_rank`：考虑 `CUDA_VISIBLE_DEVICES` 后的真实物理 GPU 号，配合 `gpu_affinity.set_affinity` 做 NUMA 亲和。

---

## 12. 日志与可观测性

### 12.1 日志栈

- `TPLogger`（[logging/logger.py:139](torchpilot/logging/logger.py#L139)）：单例，rank0 输出 WARNING+，其他 rank 输出 ERROR+；多机/DEBUG 时按 `<host>_<dev>_<rank>` 拆文件；TTY 上彩色。
- `MessageHub`（[logging/message_hub.py:35](torchpilot/logging/message_hub.py#L35)）：跨进程的状态 / 错误聚合，区分 spawn 与 fork。`parse_decoder_log` / `parse_torchworker_log` 把字符串 → `StatusEnum/ErrorEnum`，错误数超阈值（`torch_worker_n * 100`）后整 job abort。
- `MultiTaskTrainer` / decoder worker 的报错通过这个 hub 上浮到 trainer 主线程。

### 12.2 性能指标

- `StopwatchV2` + `ProfileStopwatch`：每 step 输出含 `model_forward_cost`、`compute_loss_cost`、`postprocess_layer_cost`、`ddp_cost`、各阶段 dataload 等的 timeline，按 `_print_freq_by_step` 重置。
- `TensorboardManager`（[utils/tensorboard_manager.py](torchpilot/utils/tensorboard_manager.py)）：自动按 `loss-*` / `learning-rate-*` / `efficiency-*` 三类 tag 分组；对每一条同时上报到 EventManager（如开启）。
- `EventManager`（[utils/event_manager.py](torchpilot/utils/event_manager.py)）：基于 Kafka 的异步指标上报（带后台线程 + 重试），失败可静默降级 —— 框架不会因为 Kafka 不可用挂掉。
- `ConfigManager`（[utils/config_manager.py](torchpilot/utils/config_manager.py)）：训练开始时用子进程序列化 trainer / optimizer / scheduler / dataloader 的类签名，并 `git_diff_and_patch` 保存当前未提交修改 —— 复现性兜底。

---

## 13. 关键设计模式与扩展点小结

| 模式 | 在哪里出现 | 影响 |
|---|---|---|
| **注册表 + 工厂** | 17 个 Registry，`build({"type": ..., ...})` | 所有组件可替换；插件通过 entry_points 注入 |
| **模板方法** | `BaseTrainer` / `BaseInferrer` 抽象骨架 | 多任务 trainer/inferrer 只覆写一两个方法 |
| **训练态/推理态双 forward** | `BaseModule` / `BaseTaskModel` / `TPTaskFlow` | 训练用 dict、推理用 tuple → 直接 trace/TVM |
| **Hook 注册** | trainer 的 `register_hook` | 支持在线 hard mining、动态采样 |
| **Manager 单例 + lazy init** | FileManager / EventManager / Stopwatch | rank-0 only IO；`@need_init` 卫语句 |
| **共享内存 + 进程池 + 后台线程** | decoder_worker | 视频解码与训练并发解耦 |
| **Rank-aware decorator** | `@rank_zero_only` | 防止多 rank 同时写盘 |
| **优雅降级** | EventManager / Kafka / Plus | 缺失依赖不阻断主流程 |

---

## 14. 当用户在 torchpilot 上构建端到端模型时，需要做什么？

按从内到外的顺序，**最小落地路径**通常是：

1. **数据集**：实现 `BaseDataset`（或 `BaseVideoDataset` / `MultiTaskDataset`），暴露 `__getitem__`、`__len__`、`batch_collate`、（视频时）`predecode_video_func` / `decode_video_func_async`，注册到 `DATASET`。
2. **采样器**：复用 `TPDistributedSampler`；多任务时改用 `MultiTaskDistributedSampler` 并提供任务调度策略。
3. **Transform**：继承 `BaseTransform`，注册到 `TRANSFORM`，在 dataset 内 `Compose` 调用。
4. **任务模型**：继承 `BaseTaskModel`，**严格区分**：
   - `train_forward(inputs: Dict) → Dict`
   - `infer_forward(*tensors) → namedtuple/tuple`
5. **任务流**：继承 `TPTaskFlow`：
   - 重写 `compute_loss`（或在 `__init__` 里通过 `LOSSES.build` 装配 `_loss_func`）；
   - 重写 `get_optim_policies` 做参数分组（差分 LR / wd）；
   - 重写 `trace/tvm_model_inputs_hook` & `outputs_hook` 让 trace 友好；
   - 如要 FSDP，覆盖 `warpper_model_for_fsdp_training`。
6. **损失**：继承 `BaseLoss`，注册到 `LOSSES`；多任务用 `MultiTaskLoss`/`ComposeWeightedLoss` 在 cfg 层组合。
7. **评估器**：继承 `BaseEvaluator`，实现 `eval` / `set_zero` / `dist_all_reduce`。
8. **配置文件 `exp_xxx.py`**：把上述各个 `type=`、超参、训练开关写到 `cfg.trainer / cfg.inferrer / cfg.dataloader / cfg.infer_dataloader / cfg.optimizer / cfg.lr_scheduler` 等字段里。
9. **运行**：`torchpilot run <ngpu> exp_xxx.py [-r] [-it trace] [-c ckpt.pth ...]`。

> 进阶：如果希望不动 torchpilot 源码，把上面的所有类放到独立 Python 包里，注册成 entry_points，靠 `load_plus()` 注入即可。

---

## 15. 风险点与改进观察

> 这一节是基于代码阅读的工程性观察，并非缺陷判定，但接入时建议留意。

1. **`TPTrainer` 单类约 1700 行**，状态字段非常多（`_use_fp16` / `_use_bf16` / `_fsdp` / `_pure_model` / `_use_profiler` / 各种 freq 字段）。新加特性时容易踩到耦合：建议复用现有开关而非新增字段。
2. **trace 默认 example 输入是 `torch.rand(1,3,224,224)`**（[tp_task_flow.py:180](torchpilot/model/task/tp_task_flow.py#L180)）—— 多相机/多输入任务必须重写 `get_trace_model`，否则会得到错误的图。
3. **resume 强制 cfg 字节级一致**（FileManager 的 `_validate`）。任何 git 改动 / 注释变化都会让 resume 失败，工程上要求"先固定 cfg，再训"。
4. **共享内存解码器**对内存预算敏感（`prefetch_decoder_using_mem_percent`）。在多机异构内存的环境里，建议先单机验证 `decoder_worker_num` 的安全上限。
5. **`MessageHub` 的错误阈值（`worker_n * 100`）** 超过会触发整 job abort —— 如果数据集脏样本较多，可能误伤；建议预先评估错误率。
6. **FSDP 路径强制 `MixedPrecision(fp32,fp32,fp32)`**，注释里写明"精度优先"。对显存敏感场景需要自己改写包装函数。
7. **`disable_kmp_affinity` 在 import 时执行**（[`__init__.py`](torchpilot/__init__.py)），如果用户也想自行设 `KMP_*` 环境变量，需要意识到框架会重置它。
8. **配置组合通过 Python import** 实现，没有继承机制；超大型实验组（共享大量超参）会出现配置膨胀，需要靠工程纪律封装公共组件。

---

## 16. 一图概括（数据流）

```
┌─────────────────────────────────────────────────────────────────┐
│ CLI (cli.py)                                                    │
│   │                                                             │
│   ▼                                                             │
│ ddp_launcher_run.run                                            │
│   ├── spawn_launcher / mpi_launcher                             │
│   └── 每进程: init_process_group + FileManager + log + plus     │
│        │                                                        │
│        ▼                                                        │
│   runtime_program: PyConfig → TRAINER/INFERRER.build → train/infer
│                            │                                    │
│ ┌──────────────────────────┴──────────────────────────────────┐ │
│ │              TPTrainer / TPInferrer                          │ │
│ │   ┌──────────────────────────────────────────────────────┐   │ │
│ │   │ TPDataLoader ── workers ── decoder pool (SHM)        │   │ │
│ │   │       │                                              │   │ │
│ │   │       └──> Sampler (TP/MultiTask/Video Distributed) │   │ │
│ │   │       └──> Dataset (Argus / MultiTask / Video / IN) │   │ │
│ │   │       └──> Transform (2D/3D)                        │   │ │
│ │   └──────────────────────────────────────────────────────┘   │ │
│ │                          │                                   │ │
│ │                          ▼                                   │ │
│ │   ┌──────────────────────────────────────────────────────┐   │ │
│ │   │ TPTaskFlow (DDP/FSDP wrapped)                       │   │ │
│ │   │   task_model.forward → (postprocess) → loss_func    │   │ │
│ │   │   optim_policies / trace / tvm hooks                │   │ │
│ │   └──────────────────────────────────────────────────────┘   │ │
│ │                          │                                   │ │
│ │   AMP autocast + GradScaler                                  │ │
│ │   Optimizer + LR Scheduler                                    │ │
│ │   CheckpointManager  ←→ FileManager (output_dir/task/exp/run)│ │
│ │   Stopwatch / Tensorboard / EventManager(Kafka)              │ │
│ │   Profiler / MessageHub (cross-process error bus)            │ │
│ └──────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

---

## 17. 核心入口文件与行号速查表

| 关注点 | 文件:行 |
|---|---|
| CLI | [cli.py:23](torchpilot/cli.py#L23) |
| 启动器 | [runner/ddp_launcher_run.py:327](torchpilot/runner/ddp_launcher_run.py#L327) |
| 训练器初始化 | [runner/trainer/tp_trainer.py:146](torchpilot/runner/trainer/tp_trainer.py#L146) |
| 训练主循环 | [runner/trainer/tp_trainer.py:760](torchpilot/runner/trainer/tp_trainer.py#L760) |
| 单步训练 | [runner/trainer/tp_trainer.py:1204](torchpilot/runner/trainer/tp_trainer.py#L1204) |
| 前反向 | [runner/trainer/tp_trainer.py:1146](torchpilot/runner/trainer/tp_trainer.py#L1146) |
| DDP/FSDP 包装 | [runner/trainer/tp_trainer.py:443](torchpilot/runner/trainer/tp_trainer.py#L443) |
| 推理器主循环 | [runner/inferrer/tp_inferrer.py:390](torchpilot/runner/inferrer/tp_inferrer.py#L390) |
| Trace 导出 | [runner/inferrer/tp_inferrer.py:367](torchpilot/runner/inferrer/tp_inferrer.py#L367) |
| TaskFlow forward | [model/task/tp_task_flow.py:116](torchpilot/model/task/tp_task_flow.py#L116) |
| BaseModule | [model/module_interface.py:23](torchpilot/model/module_interface.py#L23) |
| TPDataLoader | [data/dataloader/tp_dataloader.py:108](torchpilot/data/dataloader/tp_dataloader.py#L108) |
| 解码 worker | [data/dataloader/decoder_worker.py:163](torchpilot/data/dataloader/decoder_worker.py#L163) |
| ArgusDataset getitem | [data/dataset/argus_dataset.py:999](torchpilot/data/dataset/argus_dataset.py#L999) |
| PyConfig | [utils/cfg_parser.py:48](torchpilot/utils/cfg_parser.py#L48) |
| Registry | [utils/cls_register.py:25](torchpilot/utils/cls_register.py#L25) |
| CheckpointManager | [utils/checkpoint_manager.py:85](torchpilot/utils/checkpoint_manager.py#L85) |
| FileManager init | [utils/file_manager.py:86](torchpilot/utils/file_manager.py#L86) |
| Stopwatch | [utils/stopwatch.py:69](torchpilot/utils/stopwatch.py#L69) |
| Plus / entry_points | [utils/plus_manager.py:56](torchpilot/utils/plus_manager.py#L56) |

---

> **结语**：TorchPilot 在"配置驱动的训练框架"这一通用骨架上，针对**多相机视频的高吞吐解码**与**量产级可观测性 / 复现性**做了深度优化。理解它的最快路径是顺着 `cli → ddp_launcher_run → TPTrainer → TPTaskFlow → TPDataLoader/decoder_worker → CheckpointManager` 这条链条把每一层"模板方法 + 注册表 + Manager 单例"看一遍，其余子模块都是从这条主干长出的可替换分支。
