import lz4.frame
import sys
import numpy as np
from collections import defaultdict
import glob
import pickle
import json
import base64
import csv
from pathlib import Path
import re
import argparse

def extract_uuid(text):
    """从文本中提取 UUID"""
    # 第一种格式：20231212T095500_LJ1EFAUU8NG000054_1702346280.000000_1702346339.000000
    pattern1 = r'(\d{8}T\d{6}_[A-Z0-9]+_\d+\.\d+_\d+\.\d+)'

    # 第二种格式：502e7db7-bffb-47ab-ad5e-ee33da829a50
    pattern2 = r'([a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12})'

    # 尝试匹配第一种格式
    match1 = re.findall(pattern1, text or "")
    if match1:
        return match1[-1]

    # 尝试匹配第二种格式：取最后一个 UUID
    matches2 = re.findall(pattern2, text or "")
    if matches2:
        return matches2[-1]
    return None

def _to_json_serializable(obj):
        # bytes -> utf-8 (fallback: base64)
        if isinstance(obj, (bytes, bytearray)):
                try:
                        return obj.decode("utf-8")
                except Exception:
                        return base64.b64encode(bytes(obj)).decode("ascii")
        # objects with tolist (e.g., numpy arrays)
        tolist = getattr(obj, "tolist", None)
        if callable(tolist):
                try:
                        return tolist()
                except Exception:
                        pass
        # dataclass-like / custom objects -> str
        try:
                json.dumps(obj)
                return obj
        except Exception:
                return str(obj)

def load_csv_data(csv_path):
    """加载CSV文件，按提取的 UUID 建立索引（支持Tab分隔）"""
    csv_map = {}  # uuid -> 行数据
    with open(csv_path, "r", encoding="utf-8") as f:
        # 尝试检测分隔符
        first_line = f.readline()
        delimiter = '\t' if '\t' in first_line else ','
        f.seek(0)  # 重置文件指针

        reader = csv.DictReader(f, delimiter=delimiter)
        for _idx, row in enumerate(reader):
            item = {
                "生效时间": row.get("生效时刻", "").strip(),
                "核心reward": row.get("核心reward", "").strip(),
                "pkl解析地址": row.get("pkl解析地址", "").strip(),
                "结束时间": row.get("接管时刻", "").strip(),
                "正向场景": row.get("case类型", "").strip()
            }
            key_src = item["pkl解析地址"]
            if key_src:
                uuid = extract_uuid(key_src)
                if uuid:
                    csv_map[uuid] = item
    return csv_map

import glob, pickle

def merge_rank_pkls(pkl_files):
    all_data = []
    for pkl_path in pkl_files:
        with open(pkl_path, "rb") as f:
            rank_data = pickle.load(f)
        all_data.extend(rank_data)  # 合并所有rank的结果
    return all_data

class AnalyzeResult:
    def __init__(self):
        self.reward_cfg_list =[
            dict(
                type="collision_reward",
                property="penalty",  # "bonus"：奖励类， "penalty"：惩罚类
            ),
            dict(
                type="ttc_reward",
                property="penalty",
            ),
            dict(
                type="min_distance_reward",
                property="penalty",
            ),
        ]
        self.reward_eval_infos = ["sum", "mean", "std", "sparsity", "max", "min"]
        # unified comprehensive results
        self.comprehensive_result = None

        # pred vs gt comparison results 
        self.pred_gt_comparison = None

    def _create_all_dataset_type(self, eval_results):
        """Create 'ALL' dataset type by combining expert and failure data

        Args:
            eval_results: Evaluation results dictionary
            reward_types: List of reward types
        """
        for scenario in eval_results.keys():
            reward_list = self.reward_cfg_list
            # Check if both expert and failure exist for this scenario
            available_dataset_types = list(eval_results[scenario].keys())
            if "expert" in available_dataset_types and "failure" in available_dataset_types:
                # Initialize ALL dataset type structure
                if "ALL" not in eval_results[scenario]:
                    eval_results[scenario]["ALL"] = defaultdict(
                        lambda: defaultdict(
                            lambda: {
                                "ids": [],
                                "clip_ids": [],
                                "pred": [],
                                "gt": [],
                                "raw_env": [],
                                "reward_logs_pred": [],
                                "reward_logs_gt": [],
                                **{info_type: {"pred": [], "gt": []} for info_type in self.reward_eval_infos},
                            }
                        )
                    )

                # Combine data from expert and failure
                process_reward_types = ["reward"] + [reward_cfg["type"] for reward_cfg in reward_list]
                for reward_type in process_reward_types:
                    # Get all reward properties from both expert and failure

                    combined_data = {
                        "ids": [],
                        "clip_ids": [],
                        "pred": [],
                        "gt": [],
                        "raw_env": [],
                        "reward_logs_pred": [],
                        "reward_logs_gt": [],
                        **{info_type: {"pred": [], "gt": []} for info_type in self.reward_eval_infos},
                    }

                    # Add expert data if exists
                    if reward_type in eval_results[scenario]["expert"]:
                        expert_data = eval_results[scenario]["expert"][reward_type]
                        for key in combined_data.keys():
                            if key in expert_data and expert_data[key]:
                                if key in self.reward_eval_infos:
                                    # Handle pred and gt data separately
                                    if "pred" in expert_data[key]:
                                        combined_data[key]["pred"].extend(expert_data[key]["pred"])
                                    if "gt" in expert_data[key]:
                                        combined_data[key]["gt"].extend(expert_data[key]["gt"])
                                else:
                                    combined_data[key].extend(expert_data[key])

                    # Add failure data if exists
                    if reward_type in eval_results[scenario]["failure"]:
                        failure_data = eval_results[scenario]["failure"][reward_type]
                        for key in combined_data.keys():
                            if key in failure_data and failure_data[key]:
                                if key in self.reward_eval_infos:
                                    # Handle pred and gt data separately
                                    if "pred" in failure_data[key]:
                                        combined_data[key]["pred"].extend(failure_data[key]["pred"])
                                    if "gt" in failure_data[key]:
                                        combined_data[key]["gt"].extend(failure_data[key]["gt"])
                                else:
                                    combined_data[key].extend(failure_data[key])

                    eval_results[scenario]["ALL"][reward_type] = combined_data
                    # Calculate statistics for combined data
                    for eval_type in ["pred", "gt"]:
                        for info_type in self.reward_eval_infos:
                            values = combined_data[info_type].get(eval_type, [])
                            if values:
                                if info_type == "min":
                                    summary_value = min(values)
                                elif info_type == "max":
                                    summary_value = max(values)
                                else:
                                    summary_value = np.nanmean(values)
                                eval_results[scenario]["ALL"][reward_type][info_type][eval_type] = values
                                eval_results[scenario]["ALL"][reward_type][
                                    f"{info_type}_{eval_type}_mean"
                                ] = summary_value

                        # Calculate rewards statistics for combined data
                        rewards_sum = combined_data["sum"].get(eval_type, [])
                        rewards_mean = combined_data["mean"].get(eval_type, [])
                        if rewards_sum and rewards_mean:
                            eval_results[scenario]["ALL"][reward_type][f"rewards_argsort_{eval_type}"] = np.argsort(
                                rewards_sum
                            )
                            valid_rewards_count = np.count_nonzero(rewards_sum)
                            valid_rewards_sum = sum(rewards_sum) / (valid_rewards_count + 1e-8)
                            valid_rewards_mean = sum(rewards_mean) / (valid_rewards_count + 1e-8)
                            eval_results[scenario]["ALL"][reward_type][
                                f"valid_rewards_count_{eval_type}"
                            ] = valid_rewards_count
                            eval_results[scenario]["ALL"][reward_type][
                                f"valid_rewards_sum_{eval_type}"
                            ] = valid_rewards_sum
                            eval_results[scenario]["ALL"][reward_type][
                                f"valid_rewards_mean_{eval_type}"
                            ] = valid_rewards_mean
                            eval_results[scenario]["ALL"][reward_type][f"all_rewards_count_{eval_type}"] = len(
                                rewards_sum
                            )

                for dataset_type in eval_results[scenario].keys():
                    all_rewards_count_pred = None
                    all_rewards_count_gt = None
                    if "ALL" not in eval_results[scenario][dataset_type]:
                        eval_results[scenario][dataset_type]["ALL"] = defaultdict()
                    # Get all reward count from reward_types for both pred and gt
                    final_valid_rewards_count_pred = None
                    final_valid_rewards_count_gt = None

                    for reward_type in eval_results[scenario][dataset_type].keys():

                        if reward_type == "ALL":
                            continue

                        # Process pred data
                        rewards_sum_pred = eval_results[scenario][dataset_type][reward_type]["sum"].get("pred", [])
                        if rewards_sum_pred:
                            rewards_sum_pred = np.array(rewards_sum_pred)
                            if final_valid_rewards_count_pred is None:
                                final_valid_rewards_count_pred = rewards_sum_pred != 0
                                all_rewards_count_pred = eval_results[scenario][dataset_type][reward_type].get(
                                    "all_rewards_count_pred", 0
                                )
                            else:
                                final_valid_rewards_count_pred = np.bitwise_or(
                                    final_valid_rewards_count_pred != 0, rewards_sum_pred != 0
                                )

                        # Process gt data
                        rewards_sum_gt = eval_results[scenario][dataset_type][reward_type]["sum"].get("gt", [])
                        if rewards_sum_gt:
                            rewards_sum_gt = np.array(rewards_sum_gt)
                            if final_valid_rewards_count_gt is None:
                                final_valid_rewards_count_gt = rewards_sum_gt != 0
                                all_rewards_count_gt = eval_results[scenario][dataset_type][reward_type].get(
                                    "all_rewards_count_gt", 0
                                )
                            else:
                                final_valid_rewards_count_gt = np.bitwise_or(
                                    final_valid_rewards_count_gt != 0, rewards_sum_gt != 0
                                )

                    # Set combined statistics for pred
                    if all_rewards_count_pred is not None:
                        eval_results[scenario][dataset_type]["ALL"]["all_rewards_count_pred"] = all_rewards_count_pred
                    if final_valid_rewards_count_pred is not None:
                        eval_results[scenario][dataset_type]["ALL"][
                            "valid_rewards_count_pred"
                        ] = final_valid_rewards_count_pred.sum()

                    # Set combined statistics for gt
                    if all_rewards_count_gt is not None:
                        eval_results[scenario][dataset_type]["ALL"]["all_rewards_count_gt"] = all_rewards_count_gt
                    if final_valid_rewards_count_gt is not None:
                        eval_results[scenario][dataset_type]["ALL"][
                            "valid_rewards_count_gt"
                        ] = final_valid_rewards_count_gt.sum()

                    # Identify IDs whose penalty-type rewards all have sum == 0 when all reward_types are penalties
                    # 1) Determine reward types present for this dataset_type and their properties
                    present_reward_types = [
                        rt for rt in eval_results[scenario][dataset_type].keys() if rt not in ["ALL", "reward"]
                    ]
                    if dataset_type == "ALL" and len(present_reward_types) > 0:
                        # Build a mapping from reward type -> property from reward_list
                        reward_type_to_property = {}
                        for rinfo in reward_list:
                            reward_type_to_property[rinfo["type"]] = rinfo.get("property", None)

                        all_penalty = all(
                            reward_type_to_property.get(rt, None) == "penalty" for rt in present_reward_types
                        )
                        if all_penalty:
                            # 2) Find positions where all penalty reward_type sums are in failure data
                            zero_mask_all = None
                            for rt in present_reward_types:
                                sums = eval_results[scenario]["failure"][rt].get("sum", [])
                                sums_np = np.array(sums)
                                cur_zero_mask = sums_np == 0
                                if zero_mask_all is None:
                                    zero_mask_all = cur_zero_mask
                                else:
                                    zero_mask_all = np.logical_and(zero_mask_all, cur_zero_mask)
                            if zero_mask_all is not None and zero_mask_all.size > 0:
                                zero_indices = np.where(zero_mask_all)[0].tolist()
                                eval_results[scenario][dataset_type]["penalty_all_zero_indices"] = zero_indices

    def _calculate_reward_statistics(self, eval_results):
        """Calculate reward statistics and aggregate results

        Args:
            eval_results: Evaluation results dict with structure eval_results[scenario][dataset_type][reward_type][data_type]
            reward_types: List of reward types
        """
        for scenario in eval_results.keys():
            reward_list = self.reward_cfg_list
            for dataset_type in eval_results[scenario].keys():
                process_reward_types = ["reward"] + [reward_cfg["type"] for reward_cfg in reward_list]
                for reward_type in process_reward_types:
                    # reward_property = reward_info["property"]

                    # Process both pred and gt data types
                    for eval_type in ["pred", "gt"]:
                        for info_type in self.reward_eval_infos:
                            if info_type in eval_results[scenario][dataset_type][reward_type]:
                                values = eval_results[scenario][dataset_type][reward_type][info_type].get(eval_type, [])
                                if values:
                                    if info_type == "min":
                                        summary_value = min(values)
                                    elif info_type == "max":
                                        summary_value = max(values)
                                    else:
                                        summary_value = np.nanmean(values)
                                    eval_results[scenario][dataset_type][reward_type][
                                        f"{info_type}_{eval_type}_mean"
                                    ] = summary_value

                        # Calculate rewards statistics for each data type
                        rewards_mean = (
                            eval_results[scenario][dataset_type][reward_type].get("mean", {}).get(eval_type, [])
                        )
                        rewards_sum = (
                            eval_results[scenario][dataset_type][reward_type].get("sum", {}).get(eval_type, [])
                        )
                        eval_results[scenario][dataset_type][reward_type][f"all_rewards_count_{eval_type}"] = len(
                            rewards_sum
                        )
                        if rewards_sum and rewards_mean:
                            eval_results[scenario][dataset_type][reward_type][f"argsort_{eval_type}"] = np.argsort(
                                rewards_sum
                            )
                            valid_rewards_count = np.count_nonzero(rewards_sum)
                            valid_rewards_sum = sum(rewards_sum) / (valid_rewards_count + 1e-8)
                            valid_rewards_mean = sum(rewards_mean) / (valid_rewards_count + 1e-8)
                            eval_results[scenario][dataset_type][reward_type][
                                f"valid_rewards_count_{eval_type}"
                            ] = valid_rewards_count
                            eval_results[scenario][dataset_type][reward_type][
                                f"valid_rewards_sum_{eval_type}"
                            ] = valid_rewards_sum
                            eval_results[scenario][dataset_type][reward_type][
                                f"valid_rewards_mean_{eval_type}"
                            ] = valid_rewards_mean

        # Add "ALL" dataset type that combines expert and failure data
        self._create_all_dataset_type(eval_results)


    def _get_eval_results(self, eval_results):
        """Get multi-level evaluation results

        Args:
            eval_results: Evaluation results dictionary
            reward_types: List of reward types
        """
        # Get unified comprehensive results
        self.comprehensive_result = self._get_comprehensive_results(eval_results)

        # Get pred vs gt comparison results 
        self.pred_gt_comparison = self._get_pred_gt_comparison_res(eval_results)

    def _get_comprehensive_results(self, eval_results):
        """Get comprehensive results with global, scenario, and detailed levels"""
        # Create unified result with all dimensions as columns
        res = []

        # 1. Add global aggregated results
        global_data = defaultdict(lambda: defaultdict(list))
        for scenario in eval_results.keys():
            reward_list = self.reward_cfg_list
            for dataset_type in eval_results[scenario].keys():
                for reward_info in reward_list:
                    reward_type = reward_info["type"]
                    reward_property = reward_info["property"]
                    for info_type in self.reward_eval_infos:
                        # 只使用gt数据，pred仅作为记录
                        mean_key = f"{info_type}_gt_mean"
                        if mean_key in eval_results[scenario][dataset_type][reward_type]:
                            global_data[dataset_type][info_type].append(
                                eval_results[scenario][dataset_type][reward_type][mean_key]
                            )

        # Add global rows for each dataset type
        all_dataset_types = set()
        for scenario in eval_results.keys():
            all_dataset_types.update(eval_results[scenario].keys())

        for dataset_type in sorted(all_dataset_types):
            res_item = {
                "Level": "GLOBAL",
                "Scenario": "ALL",
                "Reward Type": "ALL",
                "Dataset Type": dataset_type,
                "Reward Property": "ALL",
            }
            for info_type in self.reward_eval_infos:
                if info_type in global_data[dataset_type] and global_data[dataset_type][info_type]:
                    values = global_data[dataset_type][info_type]
                    if info_type == "min":
                        summary_value = min(values)
                    elif info_type == "max":
                        summary_value = max(values)
                    else:
                        summary_value = np.nanmean(values)
                    res_item[info_type] = f"{summary_value:.6f}"
                else:
                    res_item[info_type] = "N/A"

            # Add placeholder for rewards statistics (not meaningful at global level)
            res_item["Clip_Count"] = "N/A"
            res_item["Valid_Count"] = "N/A"
            res_item["Valid_Percent"] = "N/A"
            res_item["Valid_Sum"] = "N/A"
            res_item["Valid_Mean"] = "N/A"
            res.append(res_item)

        # 2. Add scenario-level aggregated results
        scenario_data = {}
        for scenario in eval_results.keys():
            scenario_data[scenario] = defaultdict(lambda: defaultdict(list))
            reward_list = self.reward_cfg_list
            for dataset_type in eval_results[scenario].keys():
                for reward_info in reward_list:
                    reward_type = reward_info["type"]
                    reward_property = reward_info["property"]
                    for info_type in self.reward_eval_infos:
                        # 只使用gt数据，pred仅作为记录
                        mean_key = f"{info_type}_gt_mean"
                        if mean_key in eval_results[scenario][dataset_type][reward_type]:
                            scenario_data[scenario][dataset_type][info_type].append(
                                eval_results[scenario][dataset_type][reward_type][mean_key]
                            )
                scenario_data[scenario][dataset_type]["ALL"] = defaultdict()
                for key in eval_results[scenario][dataset_type]["ALL"].keys():
                    scenario_data[scenario][dataset_type]["ALL"][key] = eval_results[scenario][dataset_type]["ALL"][key]

        # Add scenario-level rows
        for scenario in sorted(scenario_data.keys()):
            for dataset_type in sorted(all_dataset_types):
                if dataset_type in scenario_data[scenario]:
                    res_item = {
                        "Level": "SCENARIO",
                        "Scenario": scenario,
                        "Reward Type": "ALL",
                        "Dataset Type": dataset_type,
                        "Reward Property": "ALL",
                    }
                    for info_type in self.reward_eval_infos:
                        if (
                            info_type in scenario_data[scenario][dataset_type]
                            and scenario_data[scenario][dataset_type][info_type]
                        ):
                            value = np.nanmean(scenario_data[scenario][dataset_type][info_type])
                            res_item[info_type] = f"{value:.6f}"
                        else:
                            res_item[info_type] = "N/A"

                    # Add placeholder for rewards statistics (not meaningful at scenario level)
                    # Add count (只使用gt数据，pred仅作为记录)
                    if (
                        "all_rewards_count_gt" in scenario_data[scenario][dataset_type]["ALL"]
                        and "valid_rewards_count_gt" in scenario_data[scenario][dataset_type]["ALL"]
                    ):
 
                        count_all = scenario_data[scenario][dataset_type]["ALL"]["all_rewards_count_gt"]
                        res_item["Clip_Count"] = str(count_all)
                        count_valid = scenario_data[scenario][dataset_type]["ALL"]["valid_rewards_count_gt"]
                        res_item["Valid_Count"] = str(count_valid)
                        count_percent = count_valid / count_all
                        res_item["Valid_Percent"] = str(count_percent)
                        res_item["Valid_Sum"] = "N/A"
                        res_item["Valid_Mean"] = "N/A"
                    else:
                        res_item["Clip_Count"] = "N/A"
                        res_item["Valid_Count"] = "N/A"
                        res_item["Valid_Percent"] = "N/A"
                        res_item["Valid_Sum"] = "N/A"
                        res_item["Valid_Mean"] = "N/A"

                    res.append(res_item)

        # 3. Add detailed results (original detailed level)
        for scenario in sorted(eval_results.keys()):
            reward_list = self.reward_cfg_list
            for reward_info in reward_list:
                reward_type = reward_info["type"]
                reward_property = reward_info["property"]
                for dataset_type in sorted(eval_results[scenario].keys()):
                    if reward_type in eval_results[scenario][dataset_type]:

                        res_item = {
                            "Level": "DETEAILED",
                            "Scenario": scenario,
                            "Reward Type": reward_type,
                            "Dataset Type": dataset_type,
                            "Reward Property": reward_property,
                        }

                        # Add basic statistics (只使用gt数据，pred仅作为记录)
                        for info_type in self.reward_eval_infos:
                            mean_key = f"{info_type}_gt_mean"
                            if mean_key in eval_results[scenario][dataset_type][reward_type]:
                                value = eval_results[scenario][dataset_type][reward_type][mean_key]
                                res_item[info_type] = f"{value:.6f}"
                            else:
                                res_item[info_type] = "N/A"

                        # Add count (只使用gt数据，pred仅作为记录)
                        if (
                            "all_rewards_count_gt" in eval_results[scenario][dataset_type][reward_type]
                            and "valid_rewards_count_gt" in eval_results[scenario][dataset_type][reward_type]
                        ):
                            count_all = eval_results[scenario][dataset_type][reward_type]["all_rewards_count_gt"]
                            res_item["Clip_Count"] = f"{count_all:.6f}"
                            count_valid = eval_results[scenario][dataset_type][reward_type]["valid_rewards_count_gt"]
                            res_item["Valid_Count"] = f"{count_valid:.6f}"
                            count_percent = count_valid / count_all
                            res_item["Valid_Percent"] = f"{count_percent:.6f}"
                            valid_rewards_sum = eval_results[scenario][dataset_type][reward_type][
                                "valid_rewards_sum_gt"
                            ]
                            res_item["Valid_Sum"] = f"{valid_rewards_sum:.6f}"
                            valid_rewards_mean = eval_results[scenario][dataset_type][reward_type][
                                "valid_rewards_mean_gt"
                            ]
                            res_item["Valid_Mean"] = f"{valid_rewards_mean:.6f}"
                        else:
                            res_item["Clip_Count"] = "N/A"
                            res_item["Valid_Count"] = "N/A"
                            res_item["Valid_Percent"] = "N/A"
                            res_item["Valid_Sum"] = "N/A"
                            res_item["Valid_Mean"] = "N/A"

                    res.append(res_item)
        return res

    def _get_pred_gt_comparison_res(self, eval_results):
        """get pred vs gt comparison result for reward_type='reward'"""
        pred_vs_gt_res = []

        # Initialize overall statistics collection
        overall_stats = {}  # key: dataset_type, value: {stat_name: [values]}

        # Process each scenario and dataset_type
        for scenario in sorted(eval_results.keys()):
            for dataset_type in sorted(eval_results[scenario].keys()):
                if "reward" not in eval_results[scenario][dataset_type]:
                    continue

                reward_data = eval_results[scenario][dataset_type]["reward"]
                gt_rewards_sum = reward_data.get("sum", {}).get("gt", [])
                gt_rewards_mean = reward_data.get("mean", {}).get("gt", [])
                pred_rewards_sum = reward_data.get("sum", {}).get("pred", [])
                pred_rewards_mean = reward_data.get("mean", {}).get("pred", [])

                # Initialize overall_stats for this dataset_type if not exists
                if dataset_type not in overall_stats:
                    overall_stats[dataset_type] = {
                        "gt_sums": [],
                        "gt_means": [],
                        "pred_sums": [],
                        "pred_means": [],
                        "gt_total_clip_counts": [],
                        "gt_higher_counts": [],
                        "gt_lower_counts": [],
                    }

                # Get gt statistics
                gt_avg_reward_sum = np.nanmean(gt_rewards_sum) if len(gt_rewards_sum) > 0 else "N/A"
                gt_avg_reward_mean = np.nanmean(gt_rewards_mean) if len(gt_rewards_mean) > 0 else "N/A"
                gt_total_clip_count = reward_data.get("all_rewards_count_gt", "N/A")

                # Get pred statistics
                pred_avg_reward_sum = np.nanmean(pred_rewards_sum) if len(pred_rewards_sum) > 0 else "N/A"
                pred_avg_reward_mean = np.nanmean(pred_rewards_mean) if len(pred_rewards_mean) > 0 else "N/A"

                # Calculate comparison counts and record indices
                gt_higher_count = 0
                gt_lower_count = 0
                gt_lower_indices = []  # 记录gt < pred的样本索引

                # Get individual reward sums for comparison
                if gt_rewards_sum and pred_rewards_sum and len(gt_rewards_sum) == len(pred_rewards_sum):
                    for idx, (gt_sum, pred_sum) in enumerate(zip(gt_rewards_sum, pred_rewards_sum)):
                        if gt_sum >= pred_sum:
                            gt_higher_count += 1
                        else:
                            gt_lower_count += 1
                            gt_lower_indices.append(idx)

                # 记录gt_lower_indices到reward_data中，供可视化使用
                if gt_lower_indices:
                    reward_data["gt_lower_indices"] = gt_lower_indices

                # Collect data for overall statistics
                overall_stats[dataset_type]["gt_sums"].extend(gt_rewards_sum)
                overall_stats[dataset_type]["gt_means"].extend(gt_rewards_mean)
                overall_stats[dataset_type]["pred_sums"].extend(pred_rewards_sum)
                overall_stats[dataset_type]["pred_means"].extend(pred_rewards_mean)
                overall_stats[dataset_type]["gt_total_clip_counts"].append(
                    gt_total_clip_count if gt_total_clip_count != "N/A" else 0
                )
                overall_stats[dataset_type]["gt_higher_counts"].append(gt_higher_count)
                overall_stats[dataset_type]["gt_lower_counts"].append(gt_lower_count)

                # Format values for display
                def format_value(value):
                    if value == "N/A":
                        return "N/A"
                    elif isinstance(value, (int, float)):
                        return f"{value:.6f}"
                    else:
                        return str(value)

                res_item = {
                    "Scenario": scenario,
                    "Dataset Type": dataset_type,
                    "GT_Sum": format_value(gt_avg_reward_sum),
                    "GT_Mean": format_value(gt_avg_reward_mean),
                    "Pred_Sum": format_value(pred_avg_reward_sum),
                    "Pred_Mean": format_value(pred_avg_reward_mean),
                    "Clip_Count": format_value(gt_total_clip_count),
                    "GT >= Pred Count": str(gt_higher_count),
                    "GT < Pred Count": str(gt_lower_count)
                }
                pred_vs_gt_res.append(res_item)

        # Calculate and add overall statistics at the end
        if overall_stats:
            # Calculate overall statistics for each dataset type
            for dataset_type, data in overall_stats.items():
                # Calculate averages (only for numeric values)
                gt_avg_sum = np.nanmean(data["gt_sums"]) if data["gt_sums"] else "N/A"
                gt_avg_mean = np.nanmean(data["gt_means"]) if data["gt_means"] else "N/A"
                pred_avg_sum = np.nanmean(data["pred_sums"]) if data["pred_sums"] else "N/A"
                pred_avg_mean = np.nanmean(data["pred_means"]) if data["pred_means"] else "N/A"
                total_clip_count = sum(data["gt_total_clip_counts"])
                total_gt_higher = sum(data["gt_higher_counts"])
                total_gt_lower = sum(data["gt_lower_counts"])

                # Format values for display
                def format_value(value):
                    if value == "N/A":
                        return "N/A"
                    elif isinstance(value, (int, float)):
                        return f"{value:.6f}"
                    else:
                        return str(value)

                # Add overall statistics row
                res_item = {
                    "Scenario": "ALL",
                    "Dataset Type": dataset_type,
                    "GT_Sum": format_value(gt_avg_sum),
                    "GT_Mean": format_value(gt_avg_mean),
                    "Pred_Sum": format_value(pred_avg_sum),
                    "Pred_Mean": format_value(pred_avg_mean),
                    "Clip_Count": format_value(total_clip_count),
                    "GT >= Pred Count": str(total_gt_higher),
                    "GT < Pred Count": str(total_gt_lower)
                }
                pred_vs_gt_res.append(res_item)

        return pred_vs_gt_res

    def process2(self, gather_all_data_all, root_path):
        ego_state_polygons = [data[0] for data in gather_all_data_all]
        ego_gt_state_polygons = [data[1] for data in gather_all_data_all]
        reward_results_pred = [data[2] for data in gather_all_data_all]
        reward_results_gt = [data[3] for data in gather_all_data_all]
        raw_env = [data[4] for data in gather_all_data_all]
        raw_env_gt = [data[5] for data in gather_all_data_all]
        data_idx_list = [data[6] for data in gather_all_data_all]
        eval_rewards_info_list = [data[7] for data in gather_all_data_all]
        clip_id_list = [data[8] for data in gather_all_data_all]
        reward_details = []
        # 结构: eval_results[scenario][dataset_type][reward_type][data_type]
    
        eval_results = defaultdict(
            lambda: defaultdict(
                lambda: defaultdict(
                    lambda: {
                        "ids": [],
                        "clip_ids": [],
                        "pred": [],
                        "gt": [],
                        "raw_env": [],
                        "raw_env_gt": [],
                        "reward_logs_pred": [],
                        "reward_logs_gt": [],
                        "property": [],
                        **{info_type: {"pred": [], "gt": []} for info_type in self.reward_eval_infos},
                    }
                )
            )
        )
        for idx, eval_rewards_info in enumerate(eval_rewards_info_list):
            reward_result_pred = reward_results_pred[idx]
            reward_result_gt = reward_results_gt[idx]
            scenario = eval_rewards_info["scenario"]
            reward_list = self.reward_cfg_list
            dataset_type = eval_rewards_info.get("dataset_type", "unknown")  # Get dataset_type
            if reward_list is None or len(reward_list) == 0:
                reward_list = [
                    dict(type=i[: -len("_mean")], property="bonus")
                    for i in reward_result_pred.keys()
                    if i.endswith("_mean")
                ]
    
            detail = {}
            detail['clip_id'] = clip_id_list[idx]
            detail['scenario' ] = scenario
            detail['dataset_type'] = dataset_type
            process_reward_types = ["reward"] + [reward_cfg["type"] for reward_cfg in reward_list]
            for reward_type in process_reward_types:
                # New data structure: eval_results[scenario][dataset_type][reward_type][data_type]
                eval_results[scenario][dataset_type][reward_type]["ids"].append(data_idx_list[idx])
                eval_results[scenario][dataset_type][reward_type]["clip_ids"].append(clip_id_list[idx])
                eval_results[scenario][dataset_type][reward_type]["raw_env"].append(raw_env[idx])
                eval_results[scenario][dataset_type][reward_type]["raw_env_gt"].append(raw_env_gt[idx])
                eval_results[scenario][dataset_type][reward_type]["pred"].append(ego_state_polygons[idx])
                eval_results[scenario][dataset_type][reward_type]["gt"].append(ego_gt_state_polygons[idx])
                eval_results[scenario][dataset_type][reward_type]["reward_logs_pred"].append(reward_result_pred)
                eval_results[scenario][dataset_type][reward_type]["reward_logs_gt"].append(reward_result_gt)
                # General results without distinguishing good/bad cases
                detail[reward_type] = {
                    **{info_type: {"pred": 0.0, "gt": 0.0} for info_type in self.reward_eval_infos},
                }
                for info_type in self.reward_eval_infos:
                    eval_results[scenario][dataset_type][reward_type][info_type]["pred"].append(
                        reward_result_pred[f"{reward_type}_{info_type}"]
                    )
                    eval_results[scenario][dataset_type][reward_type][info_type]["gt"].append(
                        reward_result_gt[f"{reward_type}_{info_type}"]
                    )
                    detail[reward_type][info_type]['pred'] = reward_result_pred[f"{reward_type}_{info_type}"]
                    detail[reward_type][info_type]['gt'] = reward_result_gt[f"{reward_type}_{info_type}"]
            reward_details.append(detail)
        with open(root_path + "melange/scripts/reward_statistics_detail.json", "w", encoding="utf-8") as f:
            json.dump(reward_details, f, ensure_ascii=False, indent=4)
        return

        # Calculate statistics and aggregate
        self._calculate_reward_statistics(eval_results)

        self._get_eval_results(eval_results)
    
        with open(root_path + "melange/scripts/reward_res_statistics.json", "w", encoding="utf-8") as f:
            json.dump({"comprehensive_result": self.comprehensive_result, "pred_gt_comparison": self.pred_gt_comparison}, f, ensure_ascii=False, indent=4)
        
def process(lz4_path,root_path):
    # 加载CSV数据
    csv_path = root_path + "melange/scripts/NOP+Sample.csv"
    csv_data = load_csv_data(csv_path)  # 映射：uuid -> 行数据
    print(f"已加载 CSV 数据，共 {len(csv_data)} 条记录")
    with lz4.frame.open(lz4_path, mode="rb") as f:
        compressed_data = f.read()
    original_data_dict_list = pickle.loads(compressed_data)
    with open(root_path + "melange/scripts/original_data_dict_list.json", "w", encoding="utf-8") as f:
        for record_idx, record in enumerate(original_data_dict_list):
            # 获取当前record对应的CSV数据：使用 extra_info 提取 UUID 进行匹配
            csv_info = {}
            extra_info = record.get("extra_info", {})
            # 解析 extra_info 中的 pkl 路径
            def _extract_pkl_from_extra(info):
                if isinstance(info, str):
                    return info.strip()
                if isinstance(info, dict):
                    for k in ["pkl解析地址", "pkl_path", "pkl", "path"]:
                        v = info.get(k)
                        if isinstance(v, str) and v.strip():
                            return v.strip()
                return ""
            extra_pkl_path = _extract_pkl_from_extra(extra_info)
            # 从 extra_info 文本中提取 UUID
            extra_uuid = extract_uuid(extra_pkl_path) if extra_pkl_path else None
            print(extra_uuid)
            if extra_uuid and extra_uuid in csv_data:
                csv_info = csv_data[extra_uuid]
            # 若未匹配到则保持空字典，后续字段默认空字符串
            effective_time_str = csv_info.get("生效时间", "")
            final_time_str = csv_info.get("结束时间", "")
            core_reward = csv_info.get("核心reward", "")
            pkl_path = csv_info.get("pkl解析地址", "")
            is_positive_scenario = csv_info.get("正向场景", "")
            # 转换生效时间为浮点数，如果为空字符串则设为None
            if effective_time_str:
                try:
                    effective_time = float(effective_time_str)
                except (ValueError, TypeError):
                    effective_time = None
            else:
                effective_time = None
            if final_time_str:
                try:
                    final_time = float(final_time_str)
                except (ValueError, TypeError):
                    final_time = None
            else:
                final_time = None
            if effective_time is not None and final_time is None:
                final_time = effective_time + 5
            use_timestamps = []
            if "raw_env" in record.keys():
                if len(record["raw_env"]) == 1:
                    use_timestamps = record["raw_env"][0][0]["use_timestamps"]
                else:
                    use_timestamps = record["raw_env"][record_idx][0]["use_timestamps"]
            elif "raw_env_list" in record.keys():
                use_timestamps = record["raw_env_list"][0]["use_timestamps"]
            if "metric_results_gt" in record:
                metric_results_gt = record["metric_results_gt"]
                log_info = metric_results_gt["log_infos"]
                # 计算所有用到的 key 的最小长度，避免后续索引越界
                _keys_used = [
                    "reward","cross_solid_line_reward","collision_reward","sta_collision_reward",
                    "dyn_collision_reward","dis","sta_min_distance_list","dyn_min_distance_list",
                    "traffic_light_reward","ttc_thw_reward_2d", "ttc_reward","dange_lc_reward",
                    "lc_status","thw","ttc","navi_lane_reward","nav_dis","aggressive_lc_reward",
                    "speed_limit_reward","overspeed","overspeed_penalty","spd_limit_list_preview_min",
                    "spd_limit_by_kappa_list","acc_reward","ax","ax_penalty","ay_penalty","ay",
                    "dec_upbound","min_distance_reward","sta_min_distance_reward","dyn_min_distance_reward",
                    "navi_roadsign","navi_link","navi_reward","progress_reward","progress_reward_spd",
                    "progress_reward_sub_path","progress_lane_change_reward","centerline_reward","centerline",
                    "dx","wrong_way_reward","cumr"
                ]
                _lengths = []
                for _k in _keys_used:
                    try:
                        _lengths.append(len(log_info[_k]))
                    except Exception:
                        pass
                _min_log_len = min(_lengths) if _lengths else 0
            timestamp_list = []
            for idx,timestamp in enumerate(use_timestamps):
                if idx < 15 or idx >= 15 + _min_log_len:
                    continue
                dict_timestamp = {}
                dict_timestamp["timestamp"] = timestamp
                timestamp_list.append(dict_timestamp)
            for idx, dict_timestamp in enumerate(timestamp_list):
                # 检查timestamp是否在生效时间范围内，只有在一定范围内才标记为核心reward
                if effective_time is not None and final_time is not None:
                    timestamp_value = float(dict_timestamp["timestamp"])
                    if timestamp_value > effective_time and timestamp_value < final_time:
                        dict_timestamp["core_reward"] = core_reward
                        dict_timestamp["is_core_reward_moment"] = True
                    else:
                        dict_timestamp["is_core_reward_moment"] = False
                else:
                    dict_timestamp["is_core_reward_moment"] = False
                dict_timestamp["is_positive_scenario"] = is_positive_scenario
                dict_timestamp["pkl_path"] = pkl_path
                dict_timestamp["rewards"] = log_info["reward"][idx]
                dict_timestamp["cross_solid_line_reward"] = log_info["cross_solid_line_reward"][idx]
                dict_timestamp["collision_reward"] = log_info["collision_reward"][idx]
                dict_timestamp["sta_collision_reward"] = log_info["sta_collision_reward"][idx]
                dict_timestamp["dyn_collision_reward"] = log_info["dyn_collision_reward"][idx]
                dict_timestamp["dis"] = log_info["dis"][idx]
                dict_timestamp["sta_min_distance_list"] = log_info["sta_min_distance_list"][idx]
                dict_timestamp["dyn_min_distance_list"] = log_info["dyn_min_distance_list"][idx]
                dict_timestamp["traffic_light_reward"] = log_info["traffic_light_reward"][idx]
                dict_timestamp["ttc_thw_reward_2d"] = log_info["ttc_thw_reward_2d"][idx]
                dict_timestamp["ttc_reward"] = log_info["ttc_reward"][idx]
                dict_timestamp["dange_lc_reward"] = log_info["dange_lc_reward"][idx]
                dict_timestamp["lc_status"] = log_info["lc_status"][idx]
                dict_timestamp["thw"] = log_info["thw"][idx]
                dict_timestamp["ttc"] = log_info["ttc"][idx]
                dict_timestamp["navi_lane_reward"] = log_info["navi_lane_reward"][idx]
                dict_timestamp["nav_dis"] = log_info["nav_dis"][idx]
                dict_timestamp["aggressive_lc_reward"] = log_info["aggressive_lc_reward"][idx]
                dict_timestamp["speed_limit_reward"] = log_info["speed_limit_reward"][idx]
                dict_timestamp["overspeed"] = log_info["overspeed"][idx]
                dict_timestamp["overspeed_penalty"] = log_info["overspeed_penalty"][idx]
                dict_timestamp["spd_limit_list_preview_min"] = log_info["spd_limit_list_preview_min"][idx]
                dict_timestamp["spd_limit_by_kappa_list"] = log_info["spd_limit_by_kappa_list"][idx]
                dict_timestamp["acc_reward"] = log_info["acc_reward"][idx]
                dict_timestamp["ax"] = log_info["ax"][idx]
                dict_timestamp["ax_penalty"] = log_info["ax_penalty"][idx]
                dict_timestamp["ay_penalty"] = log_info["ay_penalty"][idx]
                dict_timestamp["ay"] = log_info["ay"][idx]
                dict_timestamp["dec_upbound"] = log_info["dec_upbound"][idx]
                dict_timestamp["min_distance_reward"] = log_info["min_distance_reward"][idx]
                dict_timestamp["sta_min_distance_reward"] = log_info["sta_min_distance_reward"][idx]
                dict_timestamp["dyn_min_distance_reward"] = log_info["dyn_min_distance_reward"][idx]
                dict_timestamp["navi_roadsign"] = log_info["navi_roadsign"][idx]
                dict_timestamp["navi_link"] = log_info["navi_link"][idx]
                dict_timestamp["navi_reward"] = log_info["navi_reward"][idx]
                dict_timestamp["progress_reward"] = log_info["progress_reward"][idx]
                dict_timestamp["progress_reward_spd"] = log_info["progress_reward_spd"][idx]
                dict_timestamp["progress_reward_sub_path"] = log_info["progress_reward_sub_path"][idx]
                dict_timestamp["progress_lane_change_reward"] = log_info["progress_lane_change_reward"][idx]
                dict_timestamp["centerline_reward"] = log_info["centerline_reward"][idx]
                dict_timestamp["centerline"] = log_info["centerline"][idx]
                dict_timestamp["dx"] = log_info["dx"][idx]
                dict_timestamp["wrong_way_reward"] = log_info["wrong_way_reward"][idx]
                dict_timestamp["cumr"] = log_info["cumr"][idx]
            item = {
                    "id": extra_uuid,
                    "timestamp_list": timestamp_list}
            f.write(json.dumps(item, ensure_ascii=False, default=_to_json_serializable) + "\n")
            # if "log_infos" in record:
            #     log_infos = record["log_infos"]
            #     log_infos["use_timestamps"] = use_timestamps
            #     f.write(json.dumps(log_infos, ensure_ascii=False, default=_to_json_serializable) + "\n")


def main():
    parser = argparse.ArgumentParser(description="分析reward报告")
    parser.add_argument("--pkl_path", type=str, help="推理结果pkl的绝对路径")
    parser.add_argument("--root_path", type=str, help="当前代码的路径")
    args, _ = parser.parse_known_args(sys.argv[1::])
    pkl_list = []
    with open(args.pkl_path) as f:
        lines = f.readlines()
        pkl_list = [line.strip() for line in lines]
    data_all = merge_rank_pkls(pkl_list)
    analyze = AnalyzeResult()
    parsed = analyze.process2(data_all, args.root_path)

if __name__ == "__main__":
    main()

