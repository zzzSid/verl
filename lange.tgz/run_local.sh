export CUDA_VISIBLE_DEVICES=$OMPI_COMM_WORLD_LOCAL_RANK
echo $CUDA_VISIBLE_DEVICES

if [ "$TORCHPILOT_IMAGE_VERSION" == "v6.0.3.0" ]; then
  echo torchpilot run ${@:1}
  torchpilot run ${@:1}
else
  echo pipenv run torchpilot run ${@:1}
  pipenv run torchpilot run ${@:1}
fi
