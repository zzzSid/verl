#!/bin/bash

CFG_PATH=
RUN_NAME=
RESUME=
INFER_TYPE_OPTION=
INFER_TYPE_VALUE=
EXPORT_TYPE_OPTION=
EXPORT_TYPE_VALUE=
CKPT_OPTION=
CKPT_VALUE=
DATASET_MODE_OPTION=
DATASET_MODE_VALUE=
PRIORITY_OPTION=
PRIORITY_VALUE=
NODE_NUM=2
GPU_TYPE=a100
GPU_NUM=8

while [[ $# -gt 0 ]]; do
  case $1 in
    -n|--run-name)
      RUN_NAME="$2"
      shift # past argument
      shift # past value
      ;;
    -r|--resume)
      RESUME="$1"
      shift # past argument
      ;;
    -it|--infer-type)
      INFER_TYPE_OPTION="$1"
      INFER_TYPE_VALUE="$2"
      shift # past argument
      shift # past value
      ;;
    -et|--export-type)
      EXPORT_TYPE_OPTION="$1"
      EXPORT_TYPE_VALUE="$2"
      shift # past argument
      shift # past value
      ;;
    -c|--ckpt)
      CKPT_OPTION="$1"
      CKPT_VALUE="$2"
      shift # past argument
      shift # past value
      ;;
    -dm|--dataset-mode)
      DATASET_MODE_OPTION="$1"
      DATASET_MODE_VALUE="$2"
      shift # past argument
      shift # past value
      ;;
    -pr|--priority)
      PRIORITY_OPTION="$1"
      PRIORITY_VALUE="$2"
      shift # past argument
      shift # past value
      ;;
    -N|--node-num)
      NODE_NUM="$2"
      shift # past argument
      shift # past value
      ;;
    -GT|--gpu-type)
      GPU_TYPE="$2"
      shift # past argument
      shift # past value
      ;;
    -GN|--gpu-num)
      GPU_NUM="$2"
      shift # past argument
      shift # past value
      ;;
    -*|--*)
      echo "Unknown option $1"
      exit 1
      ;;
    *)
      CFG_PATH="$1" # save positional arg
      shift # past argument
      ;;
  esac
done

DEVICE_NUM=$(($GPU_NUM * $NODE_NUM))

echo nioflow run \
  -P device_num=$DEVICE_NUM \
  -P resume=$RESUME \
  -P infer_type_option=$INFER_TYPE_OPTION \
  -P infer_type_value=$INFER_TYPE_VALUE \
  -P export_type_option=$EXPORT_TYPE_OPTION \
  -P export_type_value=$EXPORT_TYPE_VALUE \
  -P ckpt_option=$CKPT_OPTION \
  -P ckpt_value=$CKPT_VALUE \
  -P dataset_mode_option=$DATASET_MODE_OPTION \
  -P dataset_mode_value=$DATASET_MODE_VALUE \
  -G $GPU_TYPE=$GPU_NUM \
  -N $NODE_NUM \
  $PRIORITY_OPTION $PRIORITY_VALUE \
  -cfg ${CFG_PATH} \
  -n $RUN_NAME
nioflow run \
  -P device_num=$DEVICE_NUM \
  -P resume=$RESUME \
  -P infer_type_option=$INFER_TYPE_OPTION \
  -P infer_type_value=$INFER_TYPE_VALUE \
  -P export_type_option=$EXPORT_TYPE_OPTION \
  -P export_type_value=$EXPORT_TYPE_VALUE \
  -P ckpt_option=$CKPT_OPTION \
  -P ckpt_value=$CKPT_VALUE \
  -P dataset_mode_option=$DATASET_MODE_OPTION \
  -P dataset_mode_value=$DATASET_MODE_VALUE \
  -G $GPU_TYPE=$GPU_NUM \
  -N $NODE_NUM \
  $PRIORITY_OPTION $PRIORITY_VALUE \
  -cfg ${CFG_PATH} \
  -n $RUN_NAME
