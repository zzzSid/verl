# TTCReward 完整梳理

> 源码位置：`tpp_onemodel/model/loss/reward_loss.py` 第 537–1568 行（`class TTCReward(BaseLoss)`）
>
> 调用位置：`tpp_onemodel/model/module/rl_planner_reward_model.py` 中 `RewardModel.compute_ttc_reward`（第 272–328 行）

`TTCReward`（Time-To-Collision Reward）用于评估规划轨迹在未来一段时间内与**道路边界 / 静态目标 / 动态目标**发生碰撞（或危险接近）的风险，并据此产生一个 **惩罚值（penalty）**。惩罚越大代表越危险。它是 RL planner 奖励体系中的安全类奖励之一。

该类除了标准的"轨迹—障碍物距离衰减"TTC 之外，还专门处理了 4 类高风险交互场景：

1. **横穿机动车（cross）**：路口内左转 / 直行时被横向来车或对向来车切断路径。
2. **横穿 VRU（cross vru）**：行人 / 非机动车横穿自车前方。
3. **会车（encounter）**：窄路上对向来车。
4. **加塞（cut-in）**：前方车辆从左右侧切入自车车道（仅作 flag 标记，不直接改分）。

---

## 1. 整体输入 / 输出

### 1.1 调用侧上下文（`compute_ttc_reward`）

在 `RewardModel.compute_ttc_reward` 中，对预测时域内的每一帧 `pred_ts` 依次调用 `TTCReward.forward`：

```303:319:tpp_onemodel/model/module/rl_planner_reward_model.py
            ttc_penalty, velocity_scale, traj_ttc_saturated, max_encounter_penalty, max_distance_mindist_sta, cross_flag, vru_caution = self.reward_funcs["ttc_reward"](
                gt_polygon,
                ego_polygon,
                raw_env,
                pred_ts + self._history_t_num,
                reward_results["rear_collision_tids"][pred_ts],
                ignore_rear_obj=True,
                bypass_flag=bypass_flag,
                vru_preds=vru_preds,
                vru_preds_plg=vru_preds_plg,
            )
            reward_results["ttc_reward"][pred_ts + 1] = -ttc_penalty
            reward_results["velocity_scale"][pred_ts + 1] = velocity_scale
            reward_results["traj_ttc_saturated"][pred_ts + 1] = traj_ttc_saturated
            reward_results["encounter_ttc_reward"][pred_ts + 1] = -max_encounter_penalty
            reward_results["sta_ttc_max_distance_list"][pred_ts + 1] = max_distance_mindist_sta
            reward_results["vru_caution"][pred_ts + 1] = vru_caution
```

要点：
- `forward` 返回的是**正的惩罚值**，写入 `reward_results` 时取负号 `-ttc_penalty`，成为负的奖励。
- `vru_preds` / `vru_preds_plg` 两个字典在整个预测循环外部创建、跨帧复用（缓存 VRU 历史轨迹，见 `_preprocess_cross_vru`）。
- `bypass_flag` 来自场景标识（死车绕行 `kDeadCarBypass` 或跟慢车 `kFollowSlow`），命中时跳过 VRU 横穿检查。
- 只要任意一帧 `ttc_reward < 0` 或 `collision_reward < 0`，会把红绿灯奖励中大于 -10 的部分清零（避免安全与信控奖励叠加冲突）。

### 1.2 `forward` 签名与返回

```python
def forward(
    self,
    gt_polygon,            # (T, 4, 2) GT 自车多边形序列（真值轨迹）
    ego_polygon,           # (T, 4, 2) 规划自车多边形序列（含历史+预测）
    raw_env,               # 环境信息列表，raw_env[ts] 为第 ts 帧环境
    ts,                    # 当前评估帧索引（= pred_ts + history_t_num）
    rear_collision_tids,   # 后向碰撞目标 id 集合（需忽略）
    max_penalty=5.0,       # 惩罚上限
    min_distance=0.3,      # （内部会被覆盖）
    max_distance=0.8,      # （内部会被覆盖）
    ego_max_velocity=-1.0,
    ego_check_seconds=1.2, # 自车轨迹检查时长（秒）
    agt_check_seconds=1.2, # 动态目标检查时长（秒）
    ignore_rear_obj=False, # 是否忽略后方目标
    bypass_flag=False,     # 是否跳过 VRU 横穿检查
    vru_preds=None,        # 跨帧缓存：VRU 中心点历史
    vru_preds_plg=None,    # 跨帧缓存：VRU 多边形历史
):
    ...
    return (
        ttc_penalty,               # float  最终 TTC 惩罚
        velocity_scale,            # float  速度缩放系数（供下游 min_dist reward 用）
        has_cutin_car_flag,        # bool   是否检测到加塞车
        max_encounter_penalty,     # float  会车惩罚
        max_distance_mindist_sta,  # float  静态最小距离阈值（供下游用）
        cross_flag,                # (bool, bool) (左转横穿, 直行横穿)
        vru_caution,               # bool   VRU 谨慎标记
    )
```

### 1.3 关键数据结构约定

| 名称 | 形状 / 类型 | 含义 |
|------|-------------|------|
| `ego_polygon[i]` | `(4, 2)` | 第 i 帧自车矩形 4 个角点。约定顺序：`0`=右后, `1`=右前, `2`=左前, `3`=左后（右手前向 x，左向 y）。 |
| `raw_env[0]["dobjs_full"]` | `list[(_, dobjs)]` | 每帧动态目标属性数组；`dobjs` 形状 `(N, ≥12)`。 |
| `raw_env[0]["dobjs_polygon"]` | `list[(N,4,2)]` | 每帧动态目标多边形。 |
| `raw_env[ts]["road_edge"]` / `nomap_road_edge` | 线段列表 | 道路边界（curb）。 |
| `raw_env[ts]["sobjs_polygon"]` | `(M,4,2)` | 当前帧静态目标多边形。 |
| `raw_env[ts]["god_polygon"]` | 线段列表 | GOD（占据）边界。 |
| `raw_env[ts]["lane_lines"]` | `list[(pts, idx)]` | 车道线。 |
| `raw_env[ts]["manner_scene_info"]` | list | 场景信息（含 `scene_type` / `distance_to_entry` / `distance_to_exit`）。 |
| `raw_env[ts]["link_info"]` | list | link 信息（含 `road_class`）。 |

`dobjs` 列的约定（按代码用法反推）：

| 列索引 | 含义 |
|--------|------|
| 0,1 | 中心点 x, y |
| 3 | 车长（>6m 视为卡车） |
| 6 | yaw 航向角 |
| 7 | 类别 cid（`<300` 车辆，`>=300` VRU） |
| 9 | track id |
| 10 | vx（纵向速度） |
| 11 | vy（横向速度） |

---

## 2. 逐函数详解

### 2.1 `__init__(self, fps=5)`

```537:541:tpp_onemodel/model/loss/reward_loss.py
class TTCReward(BaseLoss):
    def __init__(self, fps=5) -> None:
        """Init."""
        super().__init__()
        self.fps = fps
```

仅保存帧率 `fps`（默认 5Hz）。`fps` 在全类中用于**由相邻帧位移换算速度**（`位移 * fps = 速度 m/s`）以及**由秒数换算帧数**（`秒 * fps = 帧数`）。

---

### 2.2 `_calc_rela_vel_dict(self, raw_env, ego_polygon, ts)`

**作用**：计算当前帧每个动态目标相对自车的**纵向相对速度（x 方向）**，返回 `{track_id: rel_v_x}`。用于后续 VRU 判断中过滤"比自车更快、正在离开的前方目标"。

**逻辑步骤**：
1. 取当前帧 `ts` 与上一帧 `ts-1` 的目标 id（第 9 列）与多边形中心点（4 角点均值）。
2. 用 `np.intersect1d` 求两帧的公共 id，并拿到对齐索引 `idx_ts` / `idx_pre`。
3. 若无公共 id，返回空字典 `{}`。
4. 目标速度 `agent_v = (ts_centers - pre_centers) * fps`（差分×帧率）。
5. 自车速度 `ego_v = (ego_center[ts] - ego_center[ts-1]) * fps`。
6. 相对纵向速度 `rel_v_x = agent_v[:,0] - ego_v[0]`。
7. 打包 `dict(zip(common_ids, rel_v_x))` 返回。

```559:565:tpp_onemodel/model/loss/reward_loss.py
        agent_v = (ts_centers[idx_ts] - pre_centers[idx_pre]) * self.fps  # (K, 2)
        ego_v = (np.mean(ego_polygon[ts], axis=0) - np.mean(ego_polygon[ts - 1], axis=0)) * self.fps  # (2,)

        rel_v_x = agent_v[:, 0] - ego_v[0]  # (K,)

        id2rela_vel = dict(zip(common_ids, rel_v_x))
        return id2rela_vel
```

> 注：这里的坐标是自车系（x 纵向 / y 横向），`rel_v_x > 0` 表示目标相对自车正在向前拉开。

---

### 2.3 `_preprocess_cross_vru(...)`

**作用**：检测**前方横穿的 VRU（行人/非机动车，cid≥300）**风险，返回 `(max_vru_penalty, target_vru_id, vru_caution)`。核心思想是**用未来若干帧的自车轨迹与 VRU 轨迹分别 buffer 成带状 LineString，判断是否相交并比较双方到达交点的时间差**。

签名：
```python
def _preprocess_cross_vru(self, raw_env, ts, ignore_track_ids, ego_polygon,
                          id2rela_vel, max_penalty, direct_light,
                          bypass_flag=False, vru_preds=None, vru_preds_plg=None):
```

**步骤 1 — 提前退出**：`bypass_flag=True`（死车绕行/跟慢车场景）直接返回 `(0, None, False)`。

**步骤 2 — 参数按是否在路口区分**：
- `ego_in_junction`：`direct_light` 非 NaN 或 ≥0 时为 True。
- 路口内 buffer 更宽、检查窗口略短、需要更长的抢行阈值：

| 参数 | 路口内 | 非路口 | 含义 |
|------|--------|--------|------|
| `ego_width_buffer` | 1.5 | 1.2 | 自车轨迹带宽 |
| `vru_width_buffer` | 0.3 | 0.3 | VRU 轨迹带宽 |
| `min_check_size` | 18 | 20 | 检查帧数上限 |
| `min_preempt_frame_threshold` | 10 | 5 | 判定"自车明显抢先"的帧差阈值 |
| `velocity_threshold` | -2.0 | -2.0 | 相对速度阈值 |
| `lateral_threshold` | 2.5 | 2.5 | 前方横向范围 |
| `ego_straight_threshold` | 1.0 | 1.0 | 直行判定阈值 |

**步骤 3 — 选取 VRU 候选**：
- 用 `ignore_track_ids` 屏蔽需忽略目标。
- `vru_track_mask = (cid >= 300) & ~ignore_mask` 选出 VRU。若无 VRU，直接返回 0。
- `ego_straight_mask`：以当前帧自车横向坐标 y 与未来 `min_check_size` 帧 y 均值之差是否 < 阈值，判断自车是否直行。

**步骤 4 — 过滤"前方更快离开的 VRU"**：遍历候选 VRU，若同时满足
- 自车直行（`ego_straight_mask`），且
- VRU 在自车前方且横向 |Δy|<2.5（`vru_at_ego_front`），且
- 相对速度 > `velocity_threshold`（`vru_is_faster`，即 VRU 已经在往前离开），
则将其从候选中移除。清完后若无候选，返回 0。

**步骤 5 — 构造轨迹**：
- 自车预测轨迹 `ego_pred`：从 `ts` 到 `ts+min_check_size` 的中心点及多边形。
- VRU 预测轨迹缓存 `vru_preds` / `vru_preds_plg`（跨帧复用）：
  - **首次初始化**（缓存为空）：从 `start_idx = ts - vru_history_frame_save_num(=1)` 到 `end_idx` 收集所有候选 VRU 的中心点/多边形。
  - **增量更新**（缓存已有数据）：先按 `start_idx` 裁掉过期历史，找到已缓存的最大帧索引 `max_t_idx`，只补充 `max_t_idx+1 → end_idx` 的新帧（此时按 cid≥300 收集所有 VRU，去重同帧）。
  - 最后从缓存中筛出属于当前候选 `vru_ids`、落在 `[start_idx, end_idx)` 的数据，得到 `vru_preds_calc` / `vru_preds_plg_calc`。

**步骤 6 — 逐 VRU 计算 TTC 惩罚**（核心）：
对每个候选 VRU：
1. `check_size = min(len(vru_pred), len(ego_pred), min_check_size)`，`<2` 则跳过。
2. 把自车、VRU 轨迹分别 `LineString(...).buffer(width)` 得到带状多边形，若**不相交**则跳过。
3. 求**自车到达交点帧** `ego_collision_index`：逐段 `LineString([ego[i],ego[i+1]]).buffer` 与 VRU 带相交的第一段。
4. 求**VRU 到达交点帧** `vru_collision_index`：同理。
5. 归一化 `ego_collision_index_norm = idx/check_size`，`delta_index_norm = |ego_norm - vru_norm|`，裁剪到 [0,1]。
6. **时间衰减系数** `collision_time_coef`：若任一方未在窗口内到达交点则为 0，否则 `1 - ego_collision_index/len(ego_polygon)`（碰撞越晚发生惩罚越小）。
7. **相对时间差系数 `delta_time_coef` 与惩罚 `cur_vru_penalty`** 分场景计算：
   - **路口内（`ego_in_junction`）**：
     - 若自车明显抢先（`ego_norm ≤ vru_norm - min_preempt_frame_threshold/check_size`）：进一步用碰撞帧处的**自车多边形与 VRU 多边形实际距离** `distance` 判断；`distance < min_distance(2.5)` 时 `delta_time_coef = 1 - delta/2`（更重），否则 `(1 - delta)/2`。
     - 若 `ego_norm ≤ vru_norm`（略抢先）：`delta_time_coef = 1 - delta/2`。
     - 否则（自车更晚）：`delta_time_coef = 1 - delta`。
     - 该 VRU 加入 `caution_vru_ids`；`cur_vru_penalty = delta_time_coef * collision_time_coef * max_penalty`。
   - **非路口**：
     - 自车直行：`cur_vru_penalty = (1 - delta) * collision_time_coef * max_penalty / 1.5`。
     - 自车非直行：抢先时 `delta_time_coef=(1-delta)/2`，否则 `1-delta`；`cur_vru_penalty = delta_time_coef * collision_time_coef * max_penalty / 1.5`。
8. 取所有 VRU 中 `cur_vru_penalty` 最大者作为 `max_vru_penalty` / `target_vru_id`。

**步骤 7 — 输出 `vru_caution`**：若 `target_vru_id` 落在路口内的 `caution_vru_ids` 中，则 `vru_caution=True`。

> 直觉：**双方几乎同时到达交点（`delta_index_norm` 小）且碰撞发生得早（`collision_time_coef` 大）→ 惩罚大**。路口内自车抢行的情形惩罚被特别加重。

---

### 2.4 `preprocess_cross(...)`

**作用**：检测**路口场景下横穿 / 对向的机动车（cid<300）**风险，返回 `(max_cross_penalty, target_cross_id, (turn_left_cross_flag, straight_cross_flag), direct_light)`。

签名：
```python
def preprocess_cross(self, raw_env, ts, ignore_track_ids, ego_polygon,
                     max_penalty, min_check_size, gt_polygon):
```

**步骤 1 — 判断路口机动类型**：
- `direct_light = judge_intersection_and_maneuver(...)`：传入近 40 帧自车轨迹，若在有灯路口内返回机动类型（`1`=左转灯? / `2`=直行? 由 `infer_maneuver_from_lane_infos` 决定），否则 `np.nan`。
- `path_turn_type = determine_path_turn_type(gt_polygon[::5]...)`：按 GT 轨迹累计转角判断整体是 `LEFT/RIGHT/STRAIGHT/UTURN`（阈值 50°，模糊阈值 30°）。

**步骤 2 — 根据组合决定 buffer 与检查窗口**（否则直接返回全 0）：
- 左转灯 + 路径左转（`direct_light==1 & LEFT`）：`ego_buf=1.2, cross_buf=1.0, min_check_size*=3.5`（下限 35）。
- 直行灯 + 路径直行（`direct_light==2 & STRAIGHT`）：`ego_buf=1.2, cross_buf=0.5, min_check_size*=2.5`。
- 纯直行（`path_turn_type == {STRAIGHT}`）：`ego_buf=1.2, cross_buf=0.5, min_check_size*=2.5`。
- 其它：`return 0, None, False, direct_light`。

**步骤 3 — 目标筛选（多重 mask）**：对当前帧目标（去掉 ignore）：
- `front_mask`：用自车前沿边法向量投影，判断目标是否有角点在自车前方。
- `cross_mask` / `oncome_mask`：用目标航向法向量与自车前向夹角 `ang_deg` 判断——`30°<ang<150°` 为横穿；`ang≥150°` 为对向。
- `dyn_mask`：目标速度 `sqrt(vx²+vy²)>0.05`（动态）。
- `vehicle_mask`：`cid<300`（车辆）。
- 组合 `valid_mask`：左转/直行灯场景取 `vehicle & dyn & (cross|oncome) & front`；纯直行场景取 `vehicle & dyn & cross & front`。无有效目标则返回 0。

**步骤 4 — 构造轨迹**：
- 自车预测轨迹用**前沿中点**（角点 1、2 均值）。
- **慢速模式补点**：当自车速度 `ego_v_ts` 在 `(0.01, 5km/h)` 之间（`slow_mode`），在轨迹末端按末帧朝向和速度**外插若干个点**（`n_extra` 随速度越低越多，最多 10 个），同时相应加大 `min_check_size`。目的：低速时轨迹太短会漏检碰撞，补点延伸检查范围。
- cross 目标轨迹：从 `ts-1` 到 `ts+min_check_size` 收集中心点，首帧用后沿中点、末帧用前沿中点（细化端点）。

**步骤 5 — 逐目标计算 TTC 惩罚**（与 VRU 类似）：
1. 轨迹 buffer 相交筛选。
2. 求自车、cross 到达交点帧 `ego_collision_index` / `cross_collision_index`。
3. **时间衰减**：任一方未到达则 `collision_time_coef=1`，否则 `ego_collision_index/check_size`。
4. `delta_index_norm = |ego_norm - cross_norm|`。
5. 惩罚：`cur_cross_penalty = (1 - delta_index_norm) * (1 - collision_time_coef) * max_penalty / 1.5`。

   > 注意：这里用的是 `(1 - collision_time_coef)`，即 `collision_time_coef` 越小（越早到达）惩罚越大，与 VRU 的方向定义相反但语义一致（都是"越早碰撞越危险"）。
6. 取最大者。

**步骤 6 — 输出 flag**：`direct_light==1 & penalty>0 → turn_left_cross_flag`；`direct_light==2` 或纯直行且 `penalty>0 → straight_cross_flag`。

---

### 2.5 `has_cutin_car(...)`

**作用**：检测**前方车辆从左 / 右侧加塞（cut-in）进入自车车道**，返回 `bool`。仅作标记（`has_cutin_car_flag`），不参与惩罚数值计算。

签名：
```python
def has_cutin_car(self, polygons, dobjs_full, check_size_agt, ignore_track_ids,
                  ts, dobjs_polygon, ego_polygon, raw_env, vxvy, truck_max_penalty):
```

**步骤 1 — 速度门限**：自车速度 `vxvy < 8.33 m/s（≈30km/h）` 直接返回 `False`（低速不判加塞）。

**步骤 2 — 自车直行判定**：遍历车道线，若当前帧自车多边形与任一车道线相交，则 `ego_straight_mask=False`（视为正在换道/压线，不判加塞）。

**步骤 3 — 多帧窗口遍历** `[ts, ts+check_size_agt)`，对每帧目标：
- `keep`：去掉 `ignore_track_ids`。
- 速度 `obs_speed = sqrt(vx²+vy²)`；`is_truck = 车长>6m`。
- `agent_at_ego_front`：目标在自车前方 0–40m。
- `front_truck` / `front_car`：前方且横向 |Δy| 分别 <4.5 / <3。
- 用前沿法向量求目标 4 角点的横向相对量 `hori_rel`，判定目标 4 点是否整体在自车左侧/右侧且有角点贴近车道（角点约束）。
- **航向切入判定**：
  - 从右侧切入左侧 `heading_cut_in_right`：`0.174<yaw<0.785`（约 10°~45°）且在右侧且角点约束且 `obs_speed>4` 且速度不超过自车+2。
  - 从左侧切入右侧 `heading_cut_in_left`：`-0.785<yaw<-0.174` 且在左侧且相应约束。
- `cid_mask = cid<300`（只管车辆）。
- 组合 `cut_in_obs_right/left_mask = (front_truck|front_car) * heading_cut_in_* * cid_mask * ego_straight_mask`。
- 若命中任意加塞目标，`has_cutin_car_flag=True`。

返回是否存在加塞车。

---

### 2.6 `_is_ego_straight(self, ego_polygon, raw_env, min_check_size, ts)`

**作用**：综合多种方法判断**自车未来一段是否直行**，返回 `bool`。用于 `forward` 中忽略前方比自车快的直行目标（前车不构成 TTC 风险）。

**三条判据（任一满足即认为直行，最终取"或"）**：
1. **是否压线**（`ego_not_crossing_line`）：未来 `min_check_size` 帧自车多边形若不与任何车道线相交 → 直行。
2. **航向角变化**（`overall_straight`）：由未来轨迹中心点相邻差分得到 yaw 序列，计算相邻 yaw 变化 `dyaw`；单点 `|dyaw|<π/18(10°)` 记为直行点；当直行点比例 > 0.85 且平均变化 < 10° → 直行。
3. **老方法**（`ego_straight_mask`）：当前帧 y 与未来轨迹 y 均值之差 `< 1.0` → 直行。

```1178:1180:tpp_onemodel/model/loss/reward_loss.py
        # 4.如果没压线或航向角变化在阈值内，则为直行
        is_ego_straight = ego_straight_mask or overall_straight or ego_not_crossing_line
        return is_ego_straight
```

> 若未来帧数 `< 3` 或 yaw 序列 `< 2` 会提前返回 `False`。

---

### 2.7 `preprocess_encounter(...)`

**作用**：**窄路会车**检测——检测左前方**对向逆行来车**风险，返回 `(max_encounter_penalty, target_encounter_id)`。仅在窄路场景（`is_narrow_road_scenario`）被调用。

签名：
```python
def preprocess_encounter(self, raw_env, ts, ignore_track_ids, ego_polygon,
                         max_penalty, min_check_size):
```

**参数**：`ego_width_buffer=1.2`，`encounter_width_buffer=1.4`，历史保存 `4*fps` 帧（会车需要更长历史）。

**步骤 1 — 目标筛选（多 mask 求交）**：
- `front_mask`：目标有角点在自车前方（前沿法向量投影）。
- `encounter_mask`：目标航向与自车前向夹角 `ang_deg ≥ 150°`（近似正对向）。
- `velocity_mask`：目标纵向 `vx < -1.0`（朝自车方向运动）。
- `vehicle_mask`：`cid<300`。
- `obs_in_left`：目标 4 角点中 ≥3 个在自车左侧（`hori_rel>0`）。
- `valid_mask = vehicle & velocity & encounter & front & obs_in_left`。无有效目标返回 0。

**步骤 2 — 构造轨迹**：自车用前沿中点；会车目标从 `ts - 4*fps` 到 `ts+min_check_size` 收集中心，首帧用前沿中点、末帧用后沿中点。

**步骤 3 — 逐目标计算惩罚**（结构同 cross）：
1. buffer 相交筛选。
2. 求 `ego_collision_index` / `encounter_collision_index`。
3. `collision_time_coef`：任一未到达则 1，否则 `ego_collision_index/check_size`。
4. `delta_index_norm = |ego_norm - encounter_norm|`。
5. `cur_encounter_penalty = (1 - delta_index_norm) * (1 - collision_time_coef) * max_penalty`（注意窄路会车**不除以 1.5**，惩罚相对更重）。
6. 取最大者返回。

---

### 2.8 `forward(...)` — 主流程

`forward` 把上述所有子模块整合，产出最终 `ttc_penalty` 等 7 个返回值。

**阶段 A — 速度相关的自适应参数**：
1. 自车速度 `vxvy = |ego_center[ts]-ego_center[ts-1]| * fps`。
2. **速度缩放** `velocity_scale = 0.5 + 0.5 * clip((vxvy-3)/(5.55-3), 0, 1)`：车越慢缩放越小（下游 min_dist reward 用）。
3. **速度自适应检查时长** `ego_check_seconds_speed_aware = clip((vxvy-3)/(20-3),0,1)*2.0 + ego_check_seconds`：车越快，向前检查的时间越长（最多多 2 秒）。
4. **速度自适应距离阈值**：`min_distance=0.2`，`max_distance = clip(vxvy/20,0,1)*0.3 + 0.3`（车越快，触发 TTC 惩罚的距离阈值越大）。

**阶段 B — 收集几何要素**：
- 道路边界 `shape_lines`（road_edge + nomap_road_edge）。
- 当前帧静态目标 `sobjs_polygon`。
- GOD 边界 `god_shape_lines`。

**阶段 C — 计算需忽略的目标 `ignore_track_ids`**（当 `ignore_rear_obj=True`）：
1. **后向 60° 内 / 距离<0.8m 的目标**：用自车后向向量与目标向量夹角 `cos>0.5` 或中心距 `<0.8m`（已碰撞）判定并忽略。
2. **自车直行时前方更快的目标**：满足
   - `ego_straight_mask`（`_is_ego_straight`），且
   - 目标在前方 0–40m、横向 |Δy|<3（`agent_at_ego_front`），且
   - 目标朝向与自车基本平行（`cos>0.9397 ≈ 20°`），且
   - 目标纵向速度 > 自车+1 且自车速度 >10.55m/s（`dobjs_speed_mask`），且
   - 不在路口（`~intersection_mask`）

   → 这些"前方同向且更快"的目标不构成追尾风险，加入忽略集合。
- 最后并入 `rear_collision_tids`。

**阶段 D — 场景判定**：
- 计算 `id2rela_vel`（供 VRU 用）。
- 从 `manner_scene_info` 判断 `is_junction_scenario`（type==2）/ `is_main_to_aux_scenario`（type==5）。
- 从 `link_info` 的 `road_class>=7` 判断 `is_narrow_road_scenario`。
- 窄路时静态最小距离阈值 `max_distance_mindist_sta=0.05`，否则 `0.8`。

**阶段 E — 调用四个子检查**：
1. `preprocess_cross` → `max_cross_penalty, cross_id, cross_flag, direct_light`（检查窗口用 speed-aware 帧数）。
2. `_preprocess_cross_vru` → `max_vru_penalty, vru_id, vru_caution`（传入 `direct_light`、跨帧缓存）。
3. 仅窄路时 `preprocess_encounter` → `max_encounter_penalty, encounter_id`（检查窗口 ×2）。

**阶段 F — 基础 TTC（轨迹—障碍物最近距离）**：
1. 收集时间窗口 `[ts, ts+agt_check_seconds*fps)` 内所有动态目标多边形 + 静态目标，合并成 `shape_polygons`。
2. 在 `[ts, ts+check_size)`（`check_size = ego_check_seconds_speed_aware*fps`）逐帧计算自车多边形到：
   - 道路边界 `line_distance`
   - 障碍物 `polygon_distance`
   - GOD 边界 `god_polygon_distance`

   取三者最小值 `dist`；记录全局最小 `min_dist` 及对应帧 `min_ts`；若与道路边界更近则置 `ttc_sta_flag=True`；`min_dist < min_distance` 时提前 break。
3. **惩罚计算**：
   - `min_dist > max_distance`：`ttc_penalty = 0`（足够远，安全）。
   - 否则：
     - 距离缩放 `distance_scale = clip((max_distance - min_dist)/(max_distance - min_distance), 0, 1)`（越近越大）。
     - 时间缩放 `time_scale = clip(1 - (min_ts - ts)/check_size, 0, 1)`（越早越大）。
     - `ttc_penalty = max_penalty * distance_scale * time_scale`。
   - 若碰的是静态道路边界（`ttc_sta_flag`），`ttc_penalty *= 0.05`（大幅削弱，静态边界不像动态目标那么危险/避免过度保守）。

**阶段 G — 惩罚融合（取更大者覆盖）**：
```1559:1568:tpp_onemodel/model/loss/reward_loss.py
        if max_vru_penalty > ttc_penalty and vru_id is not None:
            ttc_penalty = max_vru_penalty
        if max_cross_penalty > ttc_penalty and cross_id is not None:
            ttc_penalty = max_cross_penalty

        has_cutin_car_flag = self.has_cutin_car(polygons, dobjs_full, check_size, ignore_track_ids ,ts ,dobjs_polygon, ego_polygon, raw_env, vxvy ,max_penalty)

        if max_encounter_penalty > ttc_penalty and encounter_id is not None:
            ttc_penalty = max_encounter_penalty
        return ttc_penalty, velocity_scale, has_cutin_car_flag, max_encounter_penalty, max_distance_mindist_sta, cross_flag, vru_caution
```
- VRU / cross / encounter 惩罚若比基础 TTC 更大则覆盖（取最危险）。
- 计算 `has_cutin_car_flag`。
- 返回 7 元组。

**返回字段汇总**（`max_penalty` 默认 `5.0`）：

| # | 返回字段 | 类型 | 取值 / 奖励范围 | 含义 | 写回 `reward_results` 后 |
|---|----------|------|-----------------|------|--------------------------|
| 1 | `ttc_penalty` | float | `[0, max_penalty]`；仅静态边界命中时子区间为 `[0, 0.05*max_penalty]` | 最终 TTC 惩罚（基础 TTC 与 cross/vru/encounter 取最大） | `ttc_reward = -ttc_penalty`，范围 `[-max_penalty, 0]` |
| 2 | `velocity_scale` | float | `[0.5, 1.0]` | 速度缩放系数，`0.5 + 0.5*clip((v-3)/(5.55-3),0,1)`，车越慢越小 | `velocity_scale`（原样保存，供 min_dist reward 用） |
| 3 | `has_cutin_car_flag` | bool | `{False, True}` | 是否检测到前方左右侧加塞车（仅标记） | `traj_ttc_saturated`（布尔标记） |
| 4 | `max_encounter_penalty` | float | `[0, max_penalty]`（仅窄路场景可能 >0，否则恒为 0） | 窄路会车惩罚 | `encounter_ttc_reward = -max_encounter_penalty`，范围 `[-max_penalty, 0]` |
| 5 | `max_distance_mindist_sta` | float | `{0.05, 0.8}` | 静态最小距离阈值（窄路 0.05 / 其它 0.8） | `sta_ttc_max_distance_list`（阈值，非奖励） |
| 6 | `cross_flag` | tuple/bool | `(左转横穿, 直行横穿)`，两布尔；无横穿时为 `False` | 路口横穿类型标记 | 拆分写入 `turn_left_cross_flag` / `straight_cross_flag` |
| 7 | `vru_caution` | bool | `{False, True}`（保存为 `0.0/1.0`） | 路口内 VRU 谨慎标记 | `vru_caution`（0/1 数值） |

说明：
- **真正进入奖励求和的只有第 1、4 项**（`ttc_reward`、`encounter_ttc_reward`），均为 **≤0 的惩罚型奖励**，绝对值上限为 `max_penalty`（默认 5.0）。
- 第 2 项 `velocity_scale` 是**中间缩放系数**，本身不作奖励，供下游 `MinDistReward` 使用。
- 第 3、5、6、7 项是**标记 / 阈值类**输出，不直接构成奖励数值，用于下游逻辑判断（如信控奖励清零、min_dist 阈值选择等）。

---

## 3. 惩罚公式速查

| 场景 | 惩罚公式 | 备注 |
|------|----------|------|
| 基础 TTC（动/静障碍） | `max_penalty * distance_scale * time_scale` | 静态边界再 `×0.05` |
| 横穿 VRU（路口内抢行） | `delta_time_coef * collision_time_coef * max_penalty` | `collision_time_coef = 1 - ego_idx/len` |
| 横穿 VRU（非路口） | `delta_time_coef * collision_time_coef * max_penalty / 1.5` | |
| 横穿机动车 cross | `(1-delta_norm) * (1-collision_time_coef) * max_penalty / 1.5` | `collision_time_coef = ego_idx/check_size` |
| 窄路会车 encounter | `(1-delta_norm) * (1-collision_time_coef) * max_penalty` | 不除 1.5 |

其中：
- `delta_index_norm`：自车与目标到达交点的**归一化帧差**，越小说明越同步到达 → 越危险。
- `collision_time_coef`：碰撞发生的相对时刻，公式方向因场景而异，但语义统一为"越早碰撞惩罚越大"。
- `distance_scale`：`(max_distance - min_dist)/(max_distance - min_distance)`，越近越大。
- `time_scale`：`1 - (min_ts - ts)/check_size`，越早越大。

---

## 4. 函数调用关系图

### 4.1 整体调用链（从 RL 奖励计算入口到 TTCReward）

```mermaid
flowchart TD
    A["RewardModel.compute_ttc_reward<br/>(rl_planner_reward_model.py)"] -->|"逐 pred_ts 循环调用"| B["TTCReward.forward"]
    A -.->|"跨帧复用缓存"| C["vru_preds / vru_preds_plg<br/>(dict, 循环外创建)"]
    C -.-> B
    B -->|"返回 7 元组"| A
    A -->|"-ttc_penalty 等写回"| D["reward_results<br/>(ttc_reward / velocity_scale / ...)"]
```

### 4.2 `TTCReward.forward` 内部调用关系

```mermaid
flowchart TD
    F["TTCReward.forward"]

    F --> G1["_calc_rela_vel_dict<br/>算相对纵向速度 id2rela_vel"]
    F --> G2["_is_ego_straight<br/>判断自车直行(用于忽略前方更快目标)"]
    F --> G3["preprocess_cross<br/>路口横穿/对向机动车"]
    F --> G4["_preprocess_cross_vru<br/>横穿 VRU"]
    F --> G5["preprocess_encounter<br/>窄路会车(仅窄路场景)"]
    F --> G6["has_cutin_car<br/>加塞检测(仅出 flag)"]

    %% forward 直接调用的外部工具函数
    F --> H1["judge_intersection_and_maneuver()"]
    F --> H2["get_distance()<br/>(道路边界/障碍物/GOD 最近距离)"]

    %% 子模块内部再调用的外部工具函数
    G1 -.->|"id2rela_vel 作为入参"| G4
    G3 --> H1
    G3 --> H3["determine_path_turn_type()"]

    subgraph ext ["外部工具函数 (reward_utils.py)"]
        H1
        H2
        H3
        H4["Turntype (Enum)"]
    end
    G3 -.-> H4
```

说明：
- `forward` 是唯一对外入口，其余方法均为其内部工序。
- `_calc_rela_vel_dict` 的输出 `id2rela_vel` 作为参数传入 `_preprocess_cross_vru`。
- `forward` 先算出 `direct_light`（来自 `preprocess_cross` 返回），再把它传给 `_preprocess_cross_vru` 用于区分路口内外。
- `preprocess_encounter` 只在 `is_narrow_road_scenario`（`link_info.road_class>=7`）时被调用。
- `has_cutin_car` 在阶段 G 结尾调用，结果仅作为 `has_cutin_car_flag` 返回，不影响 `ttc_penalty` 数值。

### 4.3 各子模块的"轨迹相交—TTC"通用模式

`preprocess_cross` / `_preprocess_cross_vru` / `preprocess_encounter` 三者共用同一套骨架：

```mermaid
flowchart LR
    S1["目标多重 mask 筛选<br/>(front/角度/速度/类别)"] --> S2["构造 ego 与目标<br/>未来轨迹点序列"]
    S2 --> S3["LineString.buffer 成带状多边形"]
    S3 --> S4{"两带是否相交?"}
    S4 -->|"否"| S5["跳过该目标"]
    S4 -->|"是"| S6["逐段求 ego / 目标<br/>到达交点帧 index"]
    S6 --> S7["算 delta_index_norm<br/>+ collision_time_coef"]
    S7 --> S8["按场景公式算 penalty<br/>取最大者"]
```

---

## 5. 核心设计思想总结

1. **TTC 的本质**是"未来轨迹的时空交汇"：不仅看距离，还看**双方是否会在同一时刻到达同一位置**（用 `delta_index_norm` 衡量），以及**碰撞发生得多早**（用 `collision_time_coef` / `time_scale` 衡量）。
2. **速度自适应**：车越快，向前看得越远（`ego_check_seconds_speed_aware`）、距离阈值越大（`max_distance`），符合"高速需要更早预警"的直觉；车越慢惩罚整体缩小（`velocity_scale`），并在慢速时对 cross 轨迹外插补点避免漏检。
3. **场景化处理**：路口（left/straight）、窄路会车、VRU 横穿分别用独立子模块和参数，最后**取最大惩罚**融合。
4. **误检抑制**：主动忽略后方目标、已碰撞目标、自车直行时前方同向更快的车、前方正在离开的 VRU，减少无意义惩罚。
5. **静态 vs 动态区分**：撞静态道路边界的惩罚 `×0.05`，因为动态目标碰撞风险更高。
6. **跨帧状态复用**：`vru_preds` / `vru_preds_plg` 缓存 VRU 轨迹历史，避免每帧重复扫描全序列。
