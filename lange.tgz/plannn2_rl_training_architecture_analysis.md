# Plannn2 GRPO 闭环 RL 训练架构全面分析

> 分析对象：[experiments/task_planner/exp_plannn2/cfg_plannn2_rl.py](experiments/task_planner/exp_plannn2/cfg_plannn2_rl.py)
> 参考基线：[plannn3_il_training_architecture_analysis.md](plannn3_il_training_architecture_analysis.md)（NN3-IL 端到端模仿学习）

---

## 1. 实验概述

**Plannn2-RL** 是在 Plannn2 IL 预训练模型基础上做的**闭环强化学习微调**（Reinforcement Fine-Tuning），采用 **GRPO（Group Relative Policy Optimization）** 算法：多次采样、组内标准化优势、带 clip 的策略梯度、辅以对参考策略的 KL 约束。

### 1.1 与 Plannn3-IL 的范式差异

| 维度 | Plannn3-IL | Plannn2-RL（本实验） |
|---|---|---|
| 训练范式 | 监督模仿学习（Teacher Forcing） | **GRPO 闭环 RL 微调** |
| 输入 | 视觉 + 导航 + 历史轨迹前缀 + ego | 矢量地图（env）+ 动态障碍物 + ego（无视觉） |
| 主损失 | 4 路 CE（轨迹 + navi + visual_aux + hist_traj） | **GRPO 策略梯度 + 参考策略 KL** |
| 是否需要奖励模型 | ❌ 不需要 | ✅ 需要（`RLPlannerRewardModel`，多组子奖励）|
| 是否需要参考策略 | ❌ 不需要 | ✅ 需要（冻结的 IL 预训练权重）|
| 数据流 | Dataloader → 前向 → CE loss | Dataloader → 闭环 rollout → reward → GRPO loss |
| 每 step forward 次数 | 1 | **1 次 rollout（多 sim_time × 多 rollout）+ 每 rl_update_epochs 次 policy 更新 forward** |
| n_embd | 1024 | 768（NN2 backbone） |
| GPU 数 | 128 | 32（8×4） |
| 学习率 | 1e-4 (per-batch peak) | **3e-6**（RL 微调步长要小得多）|

### 1.2 启动链路

```
run.sh 32 cfg_plannn2_rl.py
  └─ mpirun -np 32 torchpilot run ...
       └─ 构建 Plannn2SpeedTrainer + Plannn2TaskFlow(rl_training=True)
            ├─ policy 模型：从 INIT_MODEL 加载权重、参与训练
            ├─ pretrain 模型：从 INIT_MODEL_PRETRAIN 加载权重、冻结（作为 π_ref）
            ├─ 奖励模型：RLPlannerRewardModel（多进程 Pool，size=15）
            └─ 共享内存池：shmpool_name="rollout_closed", size=15
```

### 1.3 顶层数据流概览

```mermaid
%%{init: {'theme': 'base', 'themeVariables': { 'primaryColor': '#e1f5fe', 'primaryTextColor': '#01579b', 'primaryBorderColor': '#0288d1', 'lineColor': '#0288d1', 'secondaryColor': '#fff3e0', 'tertiaryColor': '#e8f5e9'}}}%%
flowchart TB
    subgraph DataLayer["📦 数据层"]
        A[Plannn2Dataset<br/>mode=rl] --> B[RL 数据 45 个 txt<br/>bingpai/hw/etc/rft_*]
        B --> C[Plannn2DataLoader<br/>batch=2, GPU=32]
    end

    subgraph RolloutLayer["🎲 闭环 Rollout 阶段（无梯度）"]
        C --> D[rollout_closed<br/>rollout_num=12 复制 batch]
        D --> E[split A/B<br/>双队列异步流水]
        E --> F1[planner_generate<br/>KV-Cache 自回归]
        E --> F2[env_step 异步<br/>proc_pool starmap]
        F1 --> G[累计 pred_polygon/logprob<br/>每 sim_time 步]
        F2 --> G
    end

    subgraph RewardLayer["🏆 奖励计算"]
        G --> H[RLPlannerRewardModel<br/>18+ 子奖励 · 多进程]
        H --> I[GRPO 组内标准化优势<br/>_calc_reward_advantage]
    end

    subgraph UpdateLayer["🔥 策略更新阶段（有梯度）"]
        I --> J[train_policy_step<br/>rl_update_epochs=2 次]
        J --> K[micro-batch × 梯度累积]
        K --> L1[policy forward<br/>取 newlogprob]
        L1 --> L2["GRPO CLIP loss<br/>+ EgoBC KL loss × 0.2"]
        L2 --> M[all_reduce grad → AdamW step]
    end

    subgraph EvalLayer["📊 评测（可选）"]
        N[Plannn2Inferrer<br/>rl_infer=True] --> O[forward_model_rl<br/>闭环推理不建 rollout_num]
        O --> P[Plannn2Evaluator<br/>close_loop=True 可视化]
    end
```

---

## 2. 关键配置常量对照表

| 常量 | 值 | 出处 | 含义 |
|---|---|---|---|
| `PLANNN2_DEBUG_MODE` | `False`（env 覆盖）| L32 | debug 模式关闭 |
| `MIN_HISTORY_SIZE` | 3 | L33 | 最小 ego 历史帧数（闭环滚动）|
| `MAX_LANE_NUM` | 13 | L34 | 导航车道最大数 |
| `PROPERTY_DIM` | 11 | L35 | property 特征维度 |
| `STATIC_SCENE` | False | L36 | 是否用静态场景（默认动态） |
| `ROLLOUT_BATCH_SIZE` | 32 | L37 | 单次 `planner_generate` 的 KV-cache batch |
| `UPDATE_BATCH_SIZE` | 32 | L38 | policy 更新 micro-batch |
| `ROLLOUT_NUM` | **12** | L39 | 每条样本采样 12 条轨迹（GRPO 组大小）|
| `ITEM_MINI_BATCH` | 1 | L40 | dataloader 内 mini-batch，RL 训练固定为 1 |
| `TIMESTAMP_SIZE` | 135 | L41 | RL 时间戳字典大小（远大于 IL 的 41）|
| `INFER_TIMESTAMP_SIZE` | 135 | L42 | 推理端时间戳表大小 |
| `SWAP_EGO_AND_AGENT` | True | L43 | 允许把动态障碍物当 ego 训练（数据增强）|
| `SHARED_MEMORY_POOL_SIZE` | 15 | L44 | 环境获取用的共享内存池 slots |
| `RL_MAX_ITERS` | 4610 | L46 | RL 训练总 iter（远短于 IL） |
| `GPU_NUM` | **32** | L47 | 8×4 卡（vs IL 128 卡）|
| `DATALOADER_BATCH_SIZE` | 2 | L48 | 每卡 dataloader batch |
| `INFER_DATALOADER_BATCH_SIZE` | 8 | L49 | 推理 dataloader batch |
| `TOTAL_LR` | **3e-6** | L50 | RL 峰值 LR（IL 是 1e-4）|
| `LR_PER_SAMPLE` | `3e-6 / 32 / 2` | L51 | per-sample 学习率 |
| `EVAL_GT_REWARDS` | env | L53 | 用 GT 轨迹算 reward 做数据挖矿 |
| `EVAL_GT_PRED_REWARDS` | env | L54 | 用聚类轨迹+GT rollout 做 openloop reward 评测 |
| `INFER_TOP1` | True（默认）/ False（EVAL_GT_PRED_REWARDS 时）| L55 | 推理是否走 greedy |
| `REPLAN_TIME` | 5 | L59 | 推理 replan 间隔（帧）|

**推导关系：**
- 全局 rollout 样本数 ≈ `DATALOADER_BATCH_SIZE × ROLLOUT_NUM × GPU_NUM` = 2 × 12 × 32 = **768**
- 每个样本会跨 `closedloop_simu_time = (max_time − 15) // replan_time` 步 rollout（replan_time ∈ {5,10,20} 轮转）
- 梯度累积步数 ≈ `dataloader_batch × item_mini_batch × rollout_num × closedloop_simu_time / UPDATE_BATCH_SIZE`

---

## 3. 与 IL baseline 的差量式配置构造（继承机制）

本 cfg **不重新定义完整 task_flow / trainer / dataloader**，而是 `deepcopy` [experiments/task_planner/exp_plannn2/cfg_plannn2.py](experiments/task_planner/exp_plannn2/cfg_plannn2.py) 的 7 个顶层字典再打补丁：

```python
ckpt = deepcopy(cfg_plannn2.ckpt)             # 参数加载
trainer = deepcopy(cfg_plannn2.trainer)       # 训练器
optimizer = deepcopy(cfg_plannn2.optimizer)   # 优化器
dataloader = deepcopy(cfg_plannn2.dataloader) # 训练数据
task_flow = deepcopy(cfg_plannn2.task_flow)   # 模型/流水线
infer_ckpt = deepcopy(cfg_plannn2.infer_ckpt)
inferrer = deepcopy(cfg_plannn2.inferrer)
evaluator = deepcopy(cfg_plannn2.evaluator)
```

这是「**IL 是母，RL 是补丁**」的写法：所有 NN2 主干（`Plannn2TaskModel` 6 层 Transformer、`Plannn2PointNetPolylineEncoder`、`AccKappaVehicleTokenizer` 1792 类码本、meta-action(2) + 轨迹(13) 布局）**完全复用 IL**；RL 部分只加/改：

| 改动大类 | 目标字典 | 关键 key | 作用 |
|---|---|---|---|
| **训练器切换 RL 模式** | `trainer` | `rl_training=True`, `rl_update_epochs=2`, `use_bf16=True`, `enable_eval=False`, `clip_gradient=1.0` | 触发 `Plannn2SpeedTrainer.train_one_step_rl` 分支 |
| **优化器变化** | `optimizer` + `lr_scheduler` | `weight_decay=1e-1`（比 IL 的 1e-3 强 100×）, `Plannn2CosineLrScheduler` peak `3e-6` warmup=100 | RL 微调防遗忘、小步长 |
| **数据集切换 RL 语料** | `dataloader.dataset_cfg` | `mode="rl"`, 45 个 RL/RFT txt 文件 | 用 curated RL 场景而不是 IL 的 800w 大表 |
| **task_flow 挂载 RL 组件** | `task_flow` | `rl_training=True`, `reward_model_cfg`, `loss_func_cfg=RLPlannerLoss`, `pretrain_model_cfg`（π_ref）, `dataset_kwargs`, `infer_cfg` | 打开 rollout/reward/GRPO 全部管线 |
| **KV Cache 打开** | `task_flow.task_model_cfg` | `use_kv_cache=True`, `kv_cache_batch_size=32`, `kv_cache_dtype=bfloat16` | rollout 阶段 15-token 自回归加速 |
| **推理器切换** | `inferrer` | `type=Plannn2Inferrer`, `rl_infer=True` | 走 `forward_model_rl` 闭环推理 |
| **评测器闭环** | `evaluator` | `close_loop=True`, `open_loop=False`, 挂载 `reward_model_cfg` | 用 rollout 结果做闭环评测 |

> **深意**：本 cfg **不训练新架构**。它测试的是：「同一份模型权重，用 GRPO 微调能否在数据挖出来的 hard case 上再涨一段」。所以 backbone、tokenizer、序列长度全都严格锁死 IL 版。

---

## 4. 核心 RL 组件详解

### 4.1 双模型架构：Policy π 与参考策略 π_ref

```mermaid
%%{init: {'theme': 'base', 'themeVariables': { 'primaryColor': '#e8f5e9', 'primaryTextColor': '#388e3c'}}}%%
flowchart LR
    A[INIT_MODEL<br/>ckpt_epoch014_step8001] --> B[Policy π<br/>可训练<br/>use_kv_cache=True]
    A --> C[π_ref<br/>strict load<br/>eval 冻结<br/>use_kv_cache=False]
    B --> D["rollout: log π(a｜s)"]
    C --> E["ref  : log π_ref(a｜s)"]
    D --> F[GRPO loss]
    E --> F
    D --> G["EgoBC KL: DKL(π_ref ‖ π)"]
    E --> G
```

- 二者 **架构完全一致**（`pretrain_model_cfg = deepcopy(task_model_cfg)`），仅 `use_kv_cache` 差异：
  - policy 使用 KV-cache 快速 rollout；
  - π_ref 每次 forward 全序列重算（一次性拿 logprob，不做自回归），无需 cache。
- **ckpt 加载分两条通道**：`ckpt["pretrain_model"]` 走标准 Runner 加载 policy；`task_flow["pretrain_model_ckpt"]` 由 `Plannn2TaskFlow.__init__` 自己 `torch.load` 后 `_pretrain_model.load_state_dict(strict=True)`（[plannn2_task_flow.py L113–120](tpp_onemodel/model/task/plannn2_task_flow.py#L113-L120)）。
- 二者初值相同 → 训练早期 KL≈0，随策略更新逐步分歧，KL 项才起作用（软锚定）。

### 4.2 Rollout 闭环流水线（无梯度）

代码入口：`Plannn2TaskFlow.rollout_closed`（[L1412](tpp_onemodel/model/task/plannn2_task_flow.py#L1412)）→ `rollout_async`（[L1187](tpp_onemodel/model/task/plannn2_task_flow.py#L1187)）→ `rollout`（[L1086](tpp_onemodel/model/task/plannn2_task_flow.py#L1086)）。

#### 4.2.1 replan_time 轮转策略（L1452–1454）

```python
replan_times = [5, 10, 20]
select_replan_time = replan_times[(iter_num // 10) % 3]  # 每 10 iter 换一次
```

- 5/10/20 三个 replan 步长循环切换，等价于让策略在**短、中、长**三种时间尺度上都自我评估过。
- `closedloop_simu_time = (max_time − 15) // select_replan_time`：不同 replan_time 对应不同长度的闭环序列（例如 replan=5 时可能滚 6 步、replan=20 时只滚 1–2 步）。

#### 4.2.2 双队列 A/B 异步流水（L1474–1550）

```
batch 复制 rollout_num=12 倍 → B = batch × 12
将 B 均切成 A(前一半) / B(后一半)
for sim_time in range(closedloop_simu_time):
    A_pred_results, A_sim_envs = rollout_async(A, ...)   # step0: A GPU 前向 + step3: 异步启动 A 下一环境
    B_pred_results, B_sim_envs = rollout_async(B, ...)   # 与 A 交叉：GPU 算 B 时 CPU 已在读 A 的下一环境
```

关键：`get_env_closed`（读 v3_ceph + 复算 od/env polygon）是 CPU 重活；`planner_generate` 是 GPU 重活。**A/B 双通道让 CPU/GPU 不空等**（多进程池 `starmap_async` 派发 + shared memory 转数据）。共享内存池 slot 数 `SHARED_MEMORY_POOL_SIZE=15`，进程池大小 = 同一常量，避免 slot 拥塞。

#### 4.2.3 单步 rollout 三阶段（`rollout` L1086）

```mermaid
%%{init: {'theme': 'base', 'themeVariables': { 'primaryColor': '#e3f2fd', 'primaryTextColor': '#1976d2'}}}%%
flowchart TB
    A["输入 batch × rollout_num<br/>（env/od/ego 全套 tensor）"] --> B["policy.eval<br/>with amp.autocast(bf16)"]
    B --> C["for num_batch:<br/>  planner_generate(rollout_batch_size=32)"]
    C --> D["得 pred_action [B,15]<br/>pred_polygons [B,T,4,2]<br/>（15 = 2 meta_action + 13 traj）"]
    D --> E["再次分批 forward：<br/>policy(inputs, action=pred_action) → pred_logprob<br/>π_ref(inputs, action=pred_action) → ref_logprob"]
    E --> F["三返回：<br/>pred_action, pred_polygons, pred_logprob, ref_logprob"]
```

- **rollout_batch_size=32 vs B=24**：单次 generate 一次跑不下 12 组 rollout 的时候会分批（此处 B ≤ 32 一次能过完）。
- `pred_action[:, :-1]` 作为下一次 forward 的 `ego_actions`，`pred_action` 作为 `action` 参数塞进 `train_forward` 的 **action 分支**（[plannn2_task_model.py](tpp_onemodel/model/task/plannn2_task_model.py) 里等价于 NN3 doc §4.2.3.6 的 action 分支），返回 `[B, action_len]` 的 log-prob。
- 精度：整个 rollout 都在 `torch.amp.autocast(bf16)` 下，`use_bf16=True` 是这条路径的核心加速。

#### 4.2.4 rollout 后的坐标系搬运（L1373–1379、L487–520）

- 每步 rollout 生成的 `pred_polygon` 是在**当前局部坐标系**下的；把它 `transform_to_new_origin_v2` 转到 **T0 全局坐标系**积累进 `pred_polygons` 列表，供 reward model 使用。
- 下一步 rollout 前的 ego 历史被替换：把 `pred_polygons`（模型自己走的历史）盖到 `ego_polygon` 的最后 `min(len, history_size=15)` 位——这是「**闭环**」的字面实现：策略吃的是自己走出来的过去，而不是 GT 过去。

### 4.3 GRPO 奖励与优势计算（`RLPlannerRewardModel`）

代码路径：[tpp_onemodel/model/module/rl_planner_reward_model.py](tpp_onemodel/model/module/rl_planner_reward_model.py) `forward`(L2570) → `_calc_rewards`(L1818) → `_post_process`(L2354) → `_calc_reward_advantage`(L2421)。奖励函数注册在 [tpp_onemodel/model/loss/reward_loss.py](tpp_onemodel/model/loss/reward_loss.py)。

#### 4.3.1 编排流水线：从 `forward` 到 `advantages`

```mermaid
%%{init: {'theme': 'base', 'themeVariables': { 'primaryColor': '#ffebee', 'primaryTextColor': '#c62828'}}}%%
flowchart TB
    A["forward(inputs_dict)<br/>输入: pred_polygon [B,rollout,T,4,2]<br/>gt_polygon, ref/pred logprob, raw_env"] --> B["_pre_process<br/>拼接 ego_state_polygon<br/>= concat(gt_history[:15], pred[:40])<br/>计算 speeds/dx/dy/dyaw/spd_limit<br/>_calc_scenario_*  → scenario_id"]
    B --> C["_calc_rewards L1818<br/>按 reward_funcs 顺序<br/>依次调用 21 个 compute_XXX"]
    C --> D["_apply_reward_extra_cfg<br/>基于 scenario_id 做<br/>clamp / omit_junc_merge"]
    D --> E["reward_results[k] *= weight<br/>reward_results['reward'] += 该项"]
    E --> F["末尾修正：<br/>- 碰撞点前正奖清零(iter<2100)<br/>- humanoid_nudge 命中处清 slow_follow<br/>- lose_gt 帧 reward -= 10 (对齐 plannn2)"]
    F --> G["_post_process<br/>stack per-batch → [B,rollout,T]<br/>KL = k3(ref, pred)"]
    G --> H["_calc_reward_advantage<br/>组内标准化 + reverse cumsum"]
    H --> I["advantages [B*rollout, T]"]
```

**核心循环（[L1877–1880](tpp_onemodel/model/module/rl_planner_reward_model.py#L1877-L1880)）：**

```python
for reward_type in self.reward_funcs.items():
    reward_results = self.compute_XXX_reward(policy_update_output, raw_env, reward_results)
    self._apply_reward_extra_cfg(reward_type, scenario_id, reward_results)
    reward_weight = self.rewards_weights.get(reward_type, 1.0)     # 关键：fallback = 1.0
    reward_results[reward_type] *= reward_weight
    reward_results["reward"] += reward_results[reward_type]        # 累加进主 reward
```

> **关键澄清（更正前文）**：`rewards_weights_cfg` 显式给出的只有 5 个 key（`collision/ttc/min_distance/cross_solid_line = 1.0`，`junction_lane_select = 10.0`），但 `.get(reward_type, 1.0)` 让**所有其余 16 个奖励也以默认权重 1.0 直接进主 sum**。因此"secondary" 组并非"只监控"——它们的 penalty 量级（如 `navi_lane` 最深 −19、`traffic_light`/`navi`/`wrong_way` 各 −10、`continuous_lc` −8）在优势估计里权重不低。真想 monitor-only 必须在 cfg 里显式写 `xxx_reward=0.0`。

**编排顺序即依赖拓扑序**（[L1827–1874](tpp_onemodel/model/module/rl_planner_reward_model.py#L1827-L1874)）：
```
cross_solid_line → danger_lc → collision → navi_lane → virtual_wall → traffic_light
→ speed_limit → slow_follow → acc → jerk → ttc → min_distance → navi → progress
→ wrong_way → centralization → continuous_lc → toggle → humanoid → humanoid_nudge
→ junction_lane_select
```
- `collision` 依赖 `is_ego_intersect_solid_line`（来自 `cross_solid_line`）和 `lc_ahead_obj_id`（来自 `danger_lc`）；
- `min_distance` 消费 `collision` 累积的 `sta/dyn_min_distance_list` 和 `ttc` 输出的 `velocity_scale`；
- `ttc` 触发时会把 `>-10` 的 `traffic_light` 清零；
- 循环外还有**三处** post-hoc 修正：碰撞点前的正奖被清零（`iter<2100`）；`humanoid_nudge` 命中的帧清 `slow_follow`；`lose_gt` 帧（预测偏离 GT 过远）被 `reward -= 10`（[L1896-1899](tpp_onemodel/model/module/rl_planner_reward_model.py#L1896-L1899)，注释 "hard code for alignment to plannn2"）。

#### 4.3.2 提前终止 (`dones`) 与 mask 语义

`process_gt_mask`（[L1740-1764](tpp_onemodel/model/module/rl_planner_reward_model.py#L1740-L1764)）初始化 `dones = zeros(T+1)`，并在两种情况下置 done：
1. 预测超出 GT 范围（`pred_ts >= len(gt_polygon)`）→ `dones[t]=1, dones[t+1:]=-1`；
2. 预测与 GT 中心距离 > `critical_distance` 且 `gt_unreliable=False` → `dones[t]=1, dones[t+1:]=-1`，同时 `lose_gt[t]=1`（后续在 `_calc_rewards` 末尾触发 `reward -= 10`）。

此后，另外两个 reward 也会置 done：

| Reward | done 语义 | reward 后续帧 |
|---|---|---|
| `process_gt_mask` | GT 越界或 `lose_gt`（偏离 GT 太远）：`dones[t]=1, dones[t+1:]=-1` | 清零，且 `lose_gt` 帧在主循环末尾额外 `reward -= 10` |
| `CollisionReward` | 三分支：① `iter<=2100` 或含 `sta_dyn` 碰撞 → done；② `iter>2100` 且非 `sta_dyn` 且**在路口** → 不 done，仅 penalty 常量延续；③ `iter>2100` 且非 `sta_dyn` 且**不在路口** → done | 分支①③清零 reward 后续帧；分支②惩罚常量化但不 done |
| `NaviLaneReward` | 严重偏航（越过关键点 + 横向 >2.5m）：`dones[t]=1, dones[t+1:]=-1` | 清零 |

`_calc_reward_advantage` 的 `action_mask = action_dones >= 0`——`-1` 帧被完全排除（不参与 mean/std/cumsum），`1` 帧仍参与。所以「done」既是 episode 边界标记，也是"这条 rollout 已经报废、后续帧不算数"的信号。

#### 4.3.3 单个 Reward 详解（Priority 组：出现在配置 `rewards_weights_cfg` 中）

这 5 项是 cfg 作者显式挑出来当"训练主推手"的（其中 `junction_lane_select` weight=10.0 是全场最高），也是唯一**有显式默认权重**的组。

##### 4.3.3.1 `CollisionReward`（[reward_loss.py L303](tpp_onemodel/model/loss/reward_loss.py#L303)，weight=1.0）

- **输入**：`ego_polygon[T,4,2]`, `raw_env[ts]` 的 `sobjs_polygon / road_edge / nomap_road_edge / god_polygon / dobjs_full / dobjs_polygon`；累积状态 `rear_collision_tids`、`laneline_penalties`、`is_ego_touch_solid_line_now`、`lc_ahead_obj_id`。
- **触发**：ego polygon 与 (静态目标 ∪ 路沿 ∪ god_polygon ∪ 动态目标) 距离 = 0。追尾判定 `yaw_diff ≤ π/6` 或 pedestrian 且他车与 ego 后半 polygon 相交、不与前半相交，追尾 ID 累积到 `rear_collision_tids` 后剔除（不给主惩罚，只作 flag）。速度 < 0.5 m/s 的低速动态物划入 `sta_dyn`。
- **打分**：
  ```python
  if collision_with_static or collision_with_dyn_normal:
      collision_penalty = 30
  else:
      collision_penalty = 0
  ```
- **写入**：`collision_reward[t+1] = -collision_penalty`。碰撞后分三支（[L215-263](tpp_onemodel/model/module/rl_planner_reward_model.py#L215-L263)）：
  - **`iter_num > 2100` 且非 `collision_with_sta_dyn` 且路口**（`judge_intersection_and_maneuver` 非 NaN）：不触发 done，把 `collision_penalty` 常量写入后续所有帧（`[t+1:]`），**不 break**——允许后续帧继续算 reward；
  - **`iter_num > 2100` 且非 `collision_with_sta_dyn` 且不在路口**：`dones[t+1]=1, dones[t+2:]=-1, reward[t+1:]=0, break`；
  - **其他**（`iter_num <= 2100` 或含 `collision_with_sta_dyn`）：`dones[t+1]=1, dones[t+2:]=-1, reward[t+1:]=0, break`。
- **符号 / 幅值**：**penalty，最大 −30**。副产物 `dis / sta_min_distance_list / dyn_min_distance_list / rear_collision_tids` 供后续 reward 复用。

##### 4.3.3.2 `TTCReward`（[L537](tpp_onemodel/model/loss/reward_loss.py#L537)，weight=1.0）

- **输入**：`gt_polygon, ego_polygon, raw_env, ts, rear_collision_tids`；参数 `max_penalty=5.0, ego_check_seconds=1.2, agt_check_seconds=1.2`；VRU 预测 `vru_preds/vru_preds_plg`。
- **触发窗口**（速度感知）：
  ```python
  ego_check_seconds_speed_aware = clip((v-3)/(20-3), 0, 1) * 2.0 + 1.2     # 1.2 ~ 3.2 s
  max_distance                  = clip(v/20, 0, 1) * 0.3 + 0.3             # 0.3 ~ 0.6 m
  ```
  只有 `min_dist < max_distance` 才进入打分。
- **打分**（三个乘子）：
  ```python
  distance_scale = (max_distance - min_dist) / (max_distance - 0.2)
  time_scale     = 1 - (min_ts - ts) / check_size
  ttc_penalty    = 5.0 * distance_scale * time_scale
  if ttc_sta_flag:                                 # 路沿类
      ttc_penalty *= 0.05                          # 静态路沿只按 5% 惩罚
  ```
- **三条独立子分支**（各自算 penalty 后与主分支取 max）：
  1. `preprocess_cross`：左转/直行冲突车；
  2. `_preprocess_cross_vru`：横穿 VRU，路口 buffer=1.5 m、非路口 1.2 m，需要 preempt ≥10 或 5 帧才判罚；
  3. `preprocess_encounter`：窄路会车。
- **副产物**：`velocity_scale = 0.5 + 0.5·clip((v-3)/2.55, 0, 1)`（供 min_dist 使用）；`traj_ttc_saturated / vru_caution / turn_left_cross_flag / straight_cross_flag`。
- **交互**：TTC penalty < 0 时把 `>-10` 的 `traffic_light_reward` 清零（避免叠加）；`kFollowSlow / kDeadCarBypass` 场景跳过 VRU 分支。
- **符号 / 幅值**：**penalty，最大 −5**（静态路沿最大 −0.25）。

##### 4.3.3.3 `MinDistReward`（[L1570](tpp_onemodel/model/loss/reward_loss.py#L1570)，weight=1.0）

- **输入**：**完全来自 `CollisionReward` 和 `TTCReward` 的副产物**——`sta_min_distance_list / sta_min_distance_start_edge_flag_list / dyn_min_distance_list / sta_ttc_max_distance_list / velocity_scale`。本 reward 不重新算几何。
- **预处理**：`>= 0.8 m` 的距离全部拉到 1.5 m（视作安全），再 `find_local_minima` 找局部极小点；静态路沿"起点边"命中时整个平坦区间都当极小。
- **打分（分静态/动态两路，二选一）**：

| 分支 | 公式 | Clamp |
|---|---|---|
| 静态 (sta) | `max(0, 5 - 5/(sta_ttc_max_distance[i+1]+ε) · min_dis) · 0.5 · velocity_scale` | `min(., 2.5)` |
| 动态 (dyn) | `max(0, 5 - 6.25 · min_dis)` | 无上限 |

  ```python
  choose_dyn = dyn_reward < sta_reward           # 取更严格（值小）的一支
  min_distance_reward = where(choose_dyn, dyn, sta)
  # 另一支置 0，避免双记
  ```
- **符号 / 幅值**：**penalty，最大 −5（dyn）/ −2.5（sta）**。低速时因 `velocity_scale → 0.5` 惩罚被压半，鼓励模型停下靠近障碍。

##### 4.3.3.4 `CrossSolidLineReward`（[L1724](tpp_onemodel/model/loss/reward_loss.py#L1724)，weight=1.0）

- **输入**：单帧 `pred_polygon[4,2], cur_env["lane_lines"]`（含属性 `[t, c]`）、`lane_nr_remain_distance`、跨帧计数器 `continue_intersection_with_lines_frames`。
- **触发（三重）**：
  1. ego polygon 与 lane_line 相交（点云取 ego center 5m 内）；
  2. `continue_intersection_with_lines_frames >= 10` 帧持续压线；
  3. 线属性 `t ∈ {1, 5, 7, 8}`（1=实线、5=道路边界、7=双实、8=白实）。
- **公式**：
  ```python
  if continue_intersection_with_lines_frames >= 10:
      if t in [1, 5, 7, 8]:
          line_penalty += 1                     # 每种命中的线各 +1
  ```
- **副产物**：`is_ego_intersect_solid_line[t+1] = (counter 增长了)` 直接影响 collision 判定和 toggle 分支。
- **符号 / 幅值**：**penalty，最大 −1**（累加多种线可能更深，但每帧计数上限依赖 `lane_lines` 数目）。

##### 4.3.3.5 `JunctionLaneSelectReward`（[L4660](tpp_onemodel/model/loss/reward_loss.py#L4660)，**weight=10.0**）

- **输入**：`cur_env["centerlines"] / navi_path, pred_traj[T,2], next_lanenr_idx, passway, is_human_reward_valid, gt_traj`。
- **触发（仅路口帧）**：`next_lanenr_idx` 由 `_is_in_junction` 判定——`lane_nr_distance` 非单调递减 + 轨迹跨过停止线 + 前后车道数 ≥ 2。方向阈 `DIRECTION_THRE = 10°`，距离阈 `DISTANCE_THRE = 10 m`，非法车道类型 `[3, 5, 6]`（非机动/摩托/人行道）被剔除。
- **候选筛选**：在同方向、距离 <10m、合法类型的中心线里挑一条离 GT/ego 最近的。
- 打分（生效区间 `-10 < s < +15 m`）：
  ```
  reward_zone(d) = scale * (0.5 + 0.5 * tanh(-0.5 * (d - 0.5)))
  ```
  其中 `scale` 通过归一化保证 `d=0` 时 `reward_zone(0)=1.0`。`d=0.5` 时 ≈ 0.5；`d→∞` 时 → 0（非负）。
  ```
  junction_reward = reward_zone(min_dist) / (valid_mask.sum() + ε)
  ```
- **符号 / 幅值**：**bonus (+)，通常 0~1，是全场唯一有 weight=10.0 的信号**——cfg 作者把「路口选道对准」当作最重要的强化学习目标。

#### 4.3.4 单个 Reward 详解（Secondary 组：默认 weight=1.0，实际同样进主 sum）

##### 4.3.4.1 `DangerLaneChangeReward`（[L3040](tpp_onemodel/model/loss/reward_loss.py#L3040)）
- **逻辑**：`split_lc_intervals` 检测压车道线区间（`extend_len=5` 前后延伸、横向 <1.75m 归同一线）；在目标车道找侧后车（`target_lane_lat_thresh=2.5m`）。
- **公式**：
  ```python
  base_dist   = 2.5 + v_obs * 0.45
  ttc_adjust  = (v_obs - v_ego) * 1.5
  safe_dist   = max(5.0, base_dist + ttc_adjust)
  danger_lc_penalty = -10 * (1 - dist / safe_dist) ** 2
  ```
  `dist/safe_dist < 0.6` 时标 `is_danger_lc=True`；高速侧前车（>5m/s）ID 写入 `lc_ahead_obj_id` 供 collision 使用。
- **幅值**：penalty，最大 **−10**。

##### 4.3.4.2 `TrafficLightReward`（[L3612](tpp_onemodel/model/loss/reward_loss.py#L3612)）
- **触发**：`raw_env[ts]["tld"]` 非全 16（有信号灯）且 ego 距停止线 > −10 m。
- **公式**（三类）：
  - 闯红灯：`stop_dist = pred_dist/0.2 · action_time_thresh(1s) > 剩余距离` → `-10`；
  - 压过停止线：`-10`；
  - 直行绿灯低速：`speed_penalty(speed) ∈ [-1, 0]`。
- **交互**：TTC/Collision 触发时把 `>-10` 项 clamp 到 0。
- **幅值**：penalty，最大 **−10**。

##### 4.3.4.3 `NaviLaneReward`（[L3287](tpp_onemodel/model/loss/reward_loss.py#L3287)）
- **逻辑**：ego 下采样后逐点匹配最近 navi 中心线，两段分段函数用 `alpha = sigmoid(5·(remain_m/100 − 0.5))` 混合：
  ```python
  reward_zone(d)   # 远离最晚变道点，d≤0.5:+12, ≤2:+2→0, ≤4:0→-2, >4:-2
  penalty_zone(d)  # 临近关键点， d≤0.5:+12, ≤1:+4→+1, ≤2:+1→-5, >2:-19
  ```
- **附加 bonus**：`lane_change_success_total_reward = 100` 均分给 lane_change_interval 段。
- **稳定锁定**：`STABLE_THRESHOLD = 0.75`，OD/slow/dead-car 场景禁用锁定。
- **提前终止**：过关键点且横向 >2.5m 触发 `dones=1`（同 collision）。
- **幅值**：混合，**+12 ~ −19**（幅值最大的 penalty）。

##### 4.3.4.4 `VirtualWallReward`（[L3866](tpp_onemodel/model/loss/reward_loss.py#L3866)）
- **参数**：`penalty_score=-4.0, backtrace_dist=36 m, overleap_thresh=0.9`。
- **逻辑**：轨迹段与 `raw_env[t]["navi_infos"]["virtual_wall"]` 相交后所有帧 `-4.0`；穿墙前 36 m 回溯段按 `w = 0.7·stage_ratio + 0.3·geo_ratio` 逐步加权（`geo_ratio = 1 - GT扩展框对 ego 覆盖率`）。
- **幅值**：penalty，最大 **−4**。

##### 4.3.4.5 `SpeedLimitReward`（[L2520](tpp_onemodel/model/loss/reward_loss.py#L2520)）
- **公式**：
  ```python
  if speed > speed_limit:
      if fine_tune:
          penalty = 4.0 if ratio > 1.2 else (2.0 if ratio > 1.1 else 0.1)
      else:
          penalty = 0.1                              # 恒定微惩罚
  ```
- **幅值**：penalty，最大 **−4**（`fine_tune=True` 才达上限）。

##### 4.3.4.6 `AccelerationReward`（[L2723](tpp_onemodel/model/loss/reward_loss.py#L2723)）
- **舒适阈**：`ax_comfort=1.6, ax_emergency=6`；`ay` 按速度分档 `2.0 / 1.7 / 1.2 / 0.8`（40/60/90 kph 分界）。
- **公式**：
  ```python
  ax_penalty = ((|ax| - 1.6) / (6 - 1.6)) ** 2 * 5     # 超 emergency 直接 5
  ay_penalty = min(5, |ay| - comfort_ay)
  ```
- **幅值**：penalty，各分量 **≤ 5**。

##### 4.3.4.7 `JerkReward`（[L2825](tpp_onemodel/model/loss/reward_loss.py#L2825)）
- **阈值**：`jx_comfort=1, jx_emergency=3`；`jy_comfort=0.3, jy_emergency=1.0`。
- **公式**：`((|j| - comfort)/(emergency - comfort))² · 2`；`ax<0 且 jx<0` 时 weight ×1.5；最终 `min(., 5)`。
- **幅值**：penalty，**≤ 5**。

##### 4.3.4.8 `NaviReward`（[L2922](tpp_onemodel/model/loss/reward_loss.py#L2922)）
- **触发**：ego 距停止线 <10 m 且穿过或即将穿过。
- **逻辑**：`road_arrow_to_lane_direction_mapping` 得允许方向集合，`determine_path_turn_type` 判自车实际转向，不匹配 → **−10**。
- **幅值**：penalty，恒定 **−10**。

##### 4.3.4.9 `ProgressReward`（[L2486](tpp_onemodel/model/loss/reward_loss.py#L2486)）
- **函数**：`spd_func(x = speed/speed_limit)`，`x ∈ [0.9, 1.0]` 取峰值 `0.2`，`<0.9` 高斯下降，`>1.0` 三次多项式衰减到 `1.15` 归零。
- **特殊值**：`speed ≤ 0 → 0.01`；`0 < speed < 1 m/s → 0`。
- **幅值**：**bonus，最大 +0.2**（quantization：不能靠速度快抵消其他 penalty）。

##### 4.3.4.10 `WrongWayReward`（[L3512](tpp_onemodel/model/loss/reward_loss.py#L3512)）
- **逻辑**：`get_pedestrian_crossing_pos` 检测压人行道；`check_crossing_order` 判是否先压停止线再压 pc（15 帧 & 10 m 双阈内），反向 → **−10** 从 `t_stop` 起。
- **幅值**：penalty，**−10**。

##### 4.3.4.11 `CentralizationReward`（[L2364](tpp_onemodel/model/loss/reward_loss.py#L2364)）
- **参数**：`LANE_LINE_SEARCH_RADIUS=8, MAX_DISTANCE_THRESHOLD=3, MIN/MAX_LANE_WIDTH=0.8/2.0`。
- **公式**：取最近两条车道线距离 `d0, d1`（`d1 ≤ 3`），车道宽 `w = d0 + d1 ∈ [0.8, 2.0]`：
  ```python
  reward = ((w - |d1 - d0|) / w) ** 4 * weight
  ```
- **场景 override**：`reward_extra_cfg.centralization_reward.kFollowSlow.clamp_params = min=0, max=0` 在跟慢车场景**强制归零**（cfg 中唯一配置的 scenario clamp）。
- **幅值**：bonus，**0 ~ 1**。

##### 4.3.4.12 `ContinuousLaneChangeReward`（[L4542](tpp_onemodel/model/loss/reward_loss.py#L4542)）
- **参数**：`penalty_duration=8, penalty_mag=8.0, angle_threshold=30°, trigger_distance=100 m`。
- **触发**：25 帧内跨两条 >2.5 m 的车道线，且两次都在 ODD 内。
- **公式**：区间内每帧 `-8.0`。
- **幅值**：penalty，每帧 **−8**（连续 8 帧则整段 −64）。

##### 4.3.4.13 `ToggleReward`（[L1778](tpp_onemodel/model/loss/reward_loss.py#L1778)）
- **逻辑**：
  - 压线且 `np_plus_lcc_status=True` → `+4`（penalty）；
  - `turn_signal` 与 `turn_direction`（由 lateral_distance 差值推断）匹配 + 非实线 → `-2`（bonus）；
  - 匹配 + 实线 → `+1`（penalty）；
  - 折返 → `+1`；
  - 未压线但接近虚线一侧 → `±2`。
- **幅值**：混合，绝对值 **≤ 4**。

##### 4.3.4.14 `HumanoidReward`（[L4013](tpp_onemodel/model/loss/reward_loss.py#L4013)）
- **逻辑**：GT 轨迹在路口内构建 `RibbonModel`（`expand_width=0.2` 的通行走廊），逐帧算 `outside_area = ego_poly − (走廊 ∩ ego_poly)`：
  ```python
  penalty = -(outside_area / quad_area) * 4.0 * decay_ratio
  ```
  前 20% 时段做线性 decay 抑制起步惩罚；GT 速度不合理（路口 <40 kph 或整体 <60 kph）跳过。
- **幅值**：penalty，最大 **−4**。

##### 4.3.4.15 `HumanoidNudgeReward`（[L4458](tpp_onemodel/model/loss/reward_loss.py#L4458)）
- **参数**：`buffer_start=-2m, buffer_lat_threshold=2.0m, buffer_end=-40m, penalty=1.5`。
- **触发（严苛 gating）**：`ShouldToGo` 全绿——ttc/tld/mindist/speed_limit 均 `>-0.1`、logic 项 `>-0.1`、`progress<0.02`、`ax<0.2`、无 collision、未来 15 帧无 `ttc<-0.1`；仅直行场景。
- **公式**：满足以上时若 `ego_pos_s[t] < gt_pos_s[t] − 2` → `-1.2`；横向偏 >2m 再叠 `-1.2`。
- **交互**：循环外把 `humanoid_nudge` 命中的 slow_follow 帧清零。
- **幅值**：penalty，**−1.2 ~ −2.4**。

##### 4.3.4.16 `SlowFollowReward`（[L2545](tpp_onemodel/model/loss/reward_loss.py#L2545)）
- **触发**：`scenario_id ∈ {kFollowSlow, kFollowSlowByHuman}`；`min_active_speed_mps=1.0, ratio_thres=0.9`。
- **公式**（cfg 里 `linear_penalty_cfg` 参数化）：
  ```python
  ratio   = clip((0.9 - speed/speed_limit) / 0.9, 0, 1)
  penalty = min_p + ratio * (max_p - min_p)             # veh: 4~6; vru: 1~2
  # safe_drive_mask=False 时 penalty *= 2
  ```
  只在 `follow_slow_segs` 内按 `is_vru_block/is_vehicle_block` 分段生效；已有 collision 或 (wrong_way + 路口/汇入) 时整段清零；被 humanoid_nudge 覆盖的帧也清零。
- **幅值**：penalty，最大 **−12**（`safe_drive_mask=False` 时 penalty ×2，`veh_max_penalty=6.0` 配置下 `6.0 × 2 = 12`）。

#### 4.3.5 `reward_extra_cfg`：scenario-tag 级 override

由 [rl_planner.py L175](tpp_onemodel/model_configs/rl_planner.py#L175) 传入，本 cfg 只配了一条：
```python
reward_extra_cfg = dict(
    centralization_reward=dict(
        kFollowSlow=dict(clamp_params=dict(min=0, max=0)),   # 跟慢车时不奖励居中
    ),
)
```
`_apply_reward_extra_cfg`（[L1917](tpp_onemodel/model/module/rl_planner_reward_model.py#L1917)）在**权重乘之前**根据 `scenario_id` 对 reward 数组做 `np.clip`。API 支持三种 override：
- `clamp_params = dict(min=..., max=...)` → 逐帧 clamp；
- `omit_junc_merge` → 用 `scene_exclusion_flag`（[L1057](tpp_onemodel/model/module/rl_planner_reward_model.py#L1057)）把路口/汇入帧对应 reward 抹零；
- 其他自定义 tag 可扩展。

这个机制配合 dataloader 里的 `(path, scenario_tag)` 元组标注（如 `("...follow_slow_dlb...", "kFollowSlow")`）形成 **场景→reward 语义调节** 的双通道。

#### 4.3.6 全部 Reward 幅值 / 号 / clamp 速查表

| Reward | 号 | 最大幅值 | 关键阈值 / clamp | 可 done? |
|---|---|---|---|---|
| `collision` | − | 30 | `dis=0` 触发 | ✅ (碰撞) |
| `ttc` | − | 5 | `min_dist < clip(v/20,0,1)·0.3+0.3` | – |
| `min_distance` | − | 5(dyn)/2.5(sta) | dyn/sta 二选一 | – |
| `cross_solid_line` | − | 1/线 | 连续 ≥10 帧压线 | – |
| **`junction_lane_select`** | **+** | **1×10.0=10** | tanh zone | – |
| `danger_lc` | − | 10 | `(1 − dist/safe_dist)²` | – |
| `traffic_light` | − | 10 | 停止线 & tld | – |
| `navi_lane` | ± | +12/−19 | zone 分段 | ✅ (偏航) |
| `virtual_wall` | − | 4 | 穿墙 + 36m 回溯 | – |
| `speed_limit` | − | 4 | ratio 1.1/1.2 分档 | – |
| `acc` / `jerk` | − | 5 各 | comfort/emergency 双阈 | – |
| `navi` | − | 10 | roadsign 方向不符 | – |
| `progress` | + | 0.2 | 速度峰值 [0.9,1.0] | – |
| `wrong_way` | − | 10 | 15f + 10m 双阈 | – |
| `centralization` | + | 1 | (kFollowSlow → 0) | – |
| `continuous_lc` | − | 8/帧 | 25f + 2.5m | – |
| `toggle` | ± | 4 | np_lcc + 拨杆匹配 | – |
| `humanoid` | − | 4 | 路口通行走廊 | – |
| `humanoid_nudge` | − | 2.4 | ShouldToGo gating | – |
| `slow_follow` | − | 12 | 场景 + safe_mask ×2 | – |
| `process_gt_mask` | − | 10 | GT 越界 / lose_gt | ✅ (GT 对齐) |

**观察**：penalty 幅值梯度粗略是 `collision(30) > wrong_way/traffic_light/navi_lane/navi/danger_lc(10) > continuous_lc/slow_follow(12) > acc/jerk/min_dist/ttc(5) > virtual_wall/speed_limit/toggle/humanoid(4) > humanoid_nudge(2.4) > cross_solid_line(1)`；bonus 只有 `junction_lane_select(10.0 加权后)`、`navi_lane` 局部正段（+12）、`centralization`(+1)、`progress`(+0.2)、`toggle` 部分分支。

#### 4.3.7 GRPO 组内标准化优势

这是本训练最关键的算法细节，在 [rl_planner_reward_model.py L2421–2434](tpp_onemodel/model/module/rl_planner_reward_model.py#L2421):

```python
def _calc_reward_advantage(self, action_rewards, action_dones):
    # action_rewards: [batch, rollout_num, T]
    action_mask = action_dones >= 0                              # 有效 step
    action_rewards = action_rewards * action_mask
    action_valid_num = action_mask.sum(axis=(-1, -2), keepdims=True)
    action_reward_mean = action_rewards.sum(...) / (action_valid_num + 1e-8)
    action_reward_variance = (action_rewards - action_reward_mean) * action_mask
    action_reward_std = ( var_squared.sum() / (N-1) ).sqrt()     # 无偏估计
    norm_action_reward = action_reward_variance / (std + 1e-8)   # (r − r̄) / σ
    advantages = torch.cumsum(norm_action_reward.flip(-1), dim=-1).flip(-1)
    return advantages
```

**语义拆解：**

1. **组内 mean/std** 是在 `(rollout_num=12, T)` 维度联合求的——一条样本的 12 条 rollout 全部时间步一起标准化。这就是 GRPO 的 **G = Group**：不用 critic，直接用同一条 prompt 采样 12 次的样本组内相对差替代 advantage。
2. **cumsum reverse**：从末尾向前累加 → 相当于 undiscounted return-to-go（可以看成 γ=1 的价值函数近似）。搭配前面的 `weight_decay=0.92`（在 `GRPORLLoss.__init__` 传入但当前实现未使用，仅保留在 API 里），reward 侧不再显式做时间折扣，全靠 cumsum 提供远期信用。
3. **组内标准差归一** → 消除不同场景下奖励量纲差异，让 clip=0.1 的 policy ratio 阈值在所有场景保持等效意义。

#### 4.3.8 KL 项（EgoBCLoss，[plannn2_rl_loss.py L11–25](tpp_onemodel/model/loss/plannn2_rl_loss.py#L11-L25)）

```python
def calc_kl(self, ref_logprob, newlogprob):
    return torch.exp(ref_logprob) / torch.exp(newlogprob) + newlogprob - ref_logprob - 1
```

这是 **k3 KL 估计器**（Schulman 提出的低方差无偏 KL 估计）：`E_π[exp(r) − r − 1]`，`r = log π_ref − log π`。相比朴素 `E[r]` 或 `E[r²]/2`，k3 在小 KL 区间方差更小、始终非负。乘以权重 `0.2` 加入总 loss：

```
total = 1.0 · pg_loss + 0.2 · ego_kl_loss
```

（`tls_kl_loss` 在 loss_scales 中列出但 `TLSBCLoss` 已被注释掉，转向灯 KL 不参与——和 NN3 不输出转向灯的观察一致。）

### 4.4 GRPO 策略梯度 Loss（`GRPORLLoss`）

代码：[plannn2_rl_loss.py L28–56](tpp_onemodel/model/loss/plannn2_rl_loss.py#L28-L56)。

```python
logratio = newlogprob − old_logprb
ratio    = exp(logratio)             # 新旧策略 π_θ / π_θ_old
pg_loss1 = −advantages · ratio                                                     # 无 clip
pg_loss2 = −advantages · clamp(ratio, 1 − clip_sigma, 1 + clip_sigma)              # PPO-style clip, clip=0.1
pg_loss  = max(pg_loss1, pg_loss2)[action_mask].mean()
```

**语义解读：**
- 采用 **PPO 悲观 clip**（`max` 而非 `min`）：`max(l1, l2)` 意味着在 loss 空间取「更差」的一支——advantage 为正时 ratio 只在 `1+clip` 内奖励，advantage 为负时 ratio 只在 `1−clip` 内惩罚，防止一步跳太远。
- `clip_sigma=0.1` 相比 PPO 常见的 0.2 更保守，因为策略每次 rollout 只更新 `rl_update_epochs=2` 轮，且 LR 已经很小（3e-6）——需要 clip 保住严格 on-policy 假设。
- `newlogprob` 从 **重新过一遍 policy** 得到（policy 前向本身参与梯度）；`old_logprb`（= `pred_logprob` from rollout）没有梯度，只作为常数比率分母。

#### 4.4.1 policy update micro-batch 流程（[plannn2_task_flow.py L892–1009](tpp_onemodel/model/task/plannn2_task_flow.py#L892-L1009)）

```
gradient_accumulation_steps = ceil(
    dataloader_batch × item_mini_batch × rollout_num × closedloop_simu_time
    / update_batch_size
)
for micro_step in range(GA):
    取 update_batch_size=32 条 (env, ego, action) 样本
    with amp.autocast(bf16):
        newlogprob = policy(inputs, action=pred_action)     # 有梯度
    loss = RLPlannerLoss(newlogprob, old_logprb, ref_logprob, advantages, action_mask) / GA
    scaler.scale(loss).backward()
# 循环外：all_reduce grad, unscale, clip_grad_norm(1.0), optimizer.step()
```

同时注意 `train_one_step_rl` **外层还有** `for i in range(rl_update_epochs=2)`：**同一批 rollout 数据被 policy 复用 2 次**——典型的 PPO/GRPO on-policy → 近 on-policy 折中。

### 4.5 训练阶段汇总时序

```mermaid
sequenceDiagram
    autonumber
    participant DL as DataLoader
    participant TR as Plannn2SpeedTrainer<br/>(train_one_step_rl)
    participant TF as Plannn2TaskFlow
    participant PL as Policy π
    participant PR as π_ref (frozen)
    participant RM as RewardModel<br/>(multi-proc)
    participant OP as AdamW + Scaler

    DL->>TR: batch_data
    TR->>TF: rollout_forward(batch)
    Note over TF: replan_time 轮转选 5/10/20
    TF->>PL: repeat rollout_num=12 →<br/>planner_generate (KV-cache)
    PL-->>TF: pred_actions, pred_polygons
    TF->>PL: forward(action=pred) → pred_logprob
    TF->>PR: forward(action=pred) → ref_logprob
    TF->>RM: (pred_polygon, gt, ref/pred logprob, raw_env)
    RM-->>TF: advantages, dones, rewards, kl, extra_summary
    loop rl_update_epochs = 2
        TR->>TF: train_policy_step(rollout_res)
        loop micro-batch × GA
            TF->>PL: forward(action) → newlogprob
            TF->>TF: RLPlannerLoss<br/>= pg_loss + 0.2·ego_kl_loss
            TF->>OP: scaler.scale(loss).backward()
        end
        TR->>OP: all_reduce → unscale → clip → step
    end
```

---

## 5. 序列布局与 Attention（NN2 版）

Plannn2 主干序列布局（复用 NN2 IL 的 `env_block_size` 定义）：

```
┌────── env_block (双向可见) ───────┐  ┌── state_block (因果) ──┐
[ env polylines + od + ego 15 ]        [ meta_action 2 | traj 13 ]
      380         + 96 + 15 = 491            = 34
```

| 量 | 值 | 来源 |
|---|---|---|
| `env_block_size`(attn) | `380 + 96 + 15 = 491` | `cfg_plannn2.py::causal_self_attn_cfg` |
| `state_block_size` | `13 + 21 = 34` | `MAX_TOKEN_LEN + META_ACTION_LEN_LIMIT` |
| `history_size` | 15 | ego 历史 |
| `MAX_OBJ_TOKEN` | 96 | 动态障碍物 |
| Transformer 层数 | 6 | `N_LAYER=6, N_HEAD=12, N_EMBD=768` |
| lm_head 输出 | 1813 = 1792 acc_kappa + 21 meta | `output_num + n_meta_action` |

**关键 RL 补丁：**
- `kv_cache_batch_size = ROLLOUT_BATCH_SIZE = 32`：rollout 时一次生成 32 条并行轨迹的 KV cache。
- `kv_cache_dtype = torch.bfloat16`（policy）/ `torch.float32`（推理评测 infer_task_flow）：训练用 bf16 省显存，评测用 fp32 保精度。
- `use_modified_sdpa_backend = False`：**关掉 flash-attn 改进的 SDPA backend**——因为 KV-cache 路径可能与该 backend 不兼容，这是 RL 版特意关的（cfg L223–225）。

---

## 6. 数据链路

### 6.1 训练数据集（45 个 txt，L120–193）

RL 语料按主题聚合，与 IL 通用大表不同——**每一个 txt 都是精挑细选的场景**：

| 主题 | 数量级 | 用途 |
|---|---|---|
| dynamic collision / vru | ~10w | 碰撞硬样本 |
| roundabout / t_junction / turn_left | ~1–4w | 路口 |
| bingpai_15w × 3（1k/4k/500）| 5.5k | 拼派 |
| lc_selected / lc_dynamic / lc_insert | 数百 × repeat | 变道 hard case |
| nudge / slow_follow / dead_car | 数千 × 5–10 | 拟人 nudge |
| road_split / speed_limit | 数千–1w | 分岔/限速 |
| coapp v1213/1214/1215/1222 | 数千 | 高速协同 |
| **rft_hw_collision / cutin / aeb** | 300–2500 | 高速 RL 微调专用 |
| **rft_ultra_speed / erratic_steering** | 数千 | ultra speed 微调 |
| **rft_etc（收费站）** | 5k+ | ETC 通过 |

其中 3 条数据支持 `(path, scenario_tag)` 元组格式（如 `("...follow_slow_dlb...", "kFollowSlow")`），显式打场景标签用于 reward 分级（例如 `reward_extra_cfg.centralization_reward.kFollowSlow` 关掉居中奖励）。

### 6.2 dataloader RL 补丁（L95–217）

```python
dataloader["dataset_cfg"]["mode"] = "rl"                 # 触发 Plannn2Dataset 的 RL 分支：不预切轨迹
dataloader["dataset_cfg"]["item_mini_batch"] = 1         # RL 一条样本一条样本处理
dataloader["dataset_cfg"]["timestamp_size"] = 135        # 更大时间窗
dataloader["dataset_cfg"]["swap_ego_and_agent"] = True   # 数据增强：把附近车当自车训
dataloader["dataset_cfg"]["tp_mode"] = "train"           # 数据分片
dataloader["dataset_cfg"]["transforms"] = [dict(type="PadEmptyEgoActions")]  # 极简 transform
dataloader["batch_size"] = 2                             # per-GPU
```

**与 IL 的关键差别：**
- IL 是 `mode="pretrain"`, transform 里含 `Plannn2SeqOdIdShuffle`；RL 只有 `PadEmptyEgoActions` 保底。
- RL 关闭了 `use_aebhighrisk`（L212），不用高危挖矿标签，改用 `dones` 由 reward 自算。

### 6.3 推理/评测数据集（L194–211）

- `val` 集：6 个典型 issue（bypass_bigroad/smallroad, follow_slow_veh/vru, dead_car, aimless_lc）—— hard case 回归。
- `eval_rewards_gt_pred` 单独一条：用于 openloop reward-eval 时启用 `EVAL_GT_PRED_REWARDS=1` 走另一分支。

---

## 7. 训练器 / 推理器 / 评测器补丁

### 7.1 Trainer 补丁（L78–86）

```python
trainer["rl_training"]        = True         # 切换到 train_one_step_rl 分支
trainer["rl_update_epochs"]   = 2            # 一批 rollout 数据 policy 更新 2 轮
trainer["use_bf16"]           = True         # 关键加速开关
trainer["clip_gradient"]      = 1.0          # RL 更保守（IL 是 2.0）
trainer["print_freq_by_step"] = 1            # 每 step 都打 log（RL 每步都很贵）
trainer["save_ckpt_freq_by_step"] = 200      # 密集存盘（RL 容易崩）
trainer["lr_per_sample"]      = LR_PER_SAMPLE
trainer["max_iters"]          = RL_MAX_ITERS
trainer["enable_eval"]        = False        # 训练中不 eval（评测走独立入口）
```

### 7.2 Lr Scheduler 全新（L88–94）

用 `Plannn2CosineLrScheduler`（RL 版有自己的调度器，见类名前缀），peak `3e-6`，warmup=100 iter，min_lr=1e-6。

### 7.3 Inferrer / Evaluator 补丁（L286–288、L332–338）

```python
inferrer["type"]     = Plannn2Inferrer
inferrer["rl_infer"] = True                  # 触发 forward_model_rl（闭环推理）

evaluator["close_loop"]         = True
evaluator["open_loop"]          = False
evaluator["need_plot"]          = True
evaluator["reward_model_cfg"]   = task_flow["reward_model_cfg"]   # 评测器也拿同一份 reward 模型算指标
```

`Plannn2Inferrer.forward_model`（[plannn2_inferrer.py L24–59](tpp_onemodel/runner/inferer/plannn2_inferrer.py#L24-L59)）根据 `rl_infer=True` 走 `forward_model_rl`（闭环生成 rollout，逐 sim_time 替换 ego 历史，输出 pred_polygons 供评测）。

### 7.4 infer_task_flow：训练/推理配置差异（L289–309）

```python
infer_task_flow = deepcopy(task_flow)
infer_task_flow["train_mode"] = False                            # eval() 分支
infer_task_flow["task_model_cfg"]["train_mode"] = False
infer_task_flow["task_model_cfg"]["...kv_cache_dtype"] = torch.float32   # 精度提升
infer_task_flow["dataset_kwargs"]["mode"] = "infer"
infer_task_flow["dataset_kwargs"]["replan_time"] = 5             # 推理 replan=5（不轮转）
infer_task_flow["dataset_kwargs"]["traj_draw_time"] = 20         # 每次绘制 20 帧长轨
infer_task_flow["dataset_kwargs"]["post_padding"] = False
if INFER_TOP1:                                                    # 默认 greedy
    infer_task_flow["task_model_cfg"]["infer_cfg"]["topk"] = 1
    infer_task_flow["task_model_cfg"]["infer_cfg"]["top_p"] = None
else:                                                             # EVAL_GT_PRED_REWARDS 时用 32 top-p 0.9
    infer_task_flow["task_model_cfg"]["infer_cfg"]["topk"] = 32
    infer_task_flow["task_model_cfg"]["infer_cfg"]["top_p"] = 0.9
```

---

## 8. 评测三种模式

L311–363 用两个环境变量组合出三种评测：

| 模式 | 环境变量 | `infer_tp_mode` | `topk` | 说明 |
|---|---|---|---|---|
| **常规闭环评测**（默认）| 无 | `"val"` | 1 (greedy) | 用 6 个 issue 集做闭环 rollout + 可视化 pkl |
| **EVAL_GT_REWARDS** | `EVAL_GT_REWARDS=1` | `"eval_rewards"` | 1 | 挖矿模式：用 GT 轨迹跑 reward，找 bad case（`create_rl_planner_reward_eval_cfg` 只算 `agent_collision` 三项 penalty）|
| **EVAL_GT_PRED_REWARDS** | `EVAL_GT_PRED_REWARDS=1` | `"eval_rewards_gt_pred"` | 32, top_p=0.9 | 开环 reward 评测：加载 kmeans 聚类模板 (`20frame_10w_2048_kmeans_polygons.npy`)，每帧走 GT 走一步，rollout 多条评比 |

三种模式共享 `task_flow`，差异只在 `infer_task_flow["eval_rewards"]` / `eval_rewards_gt_pred` 标志位和 dataloader 的 `tp_mode` / `start_at_idx`。

---

## 9. 关键 Tensor Shape 汇总

| Tensor | Shape | 说明 |
|---|---|---|
| `polygon` (env) | `[B, 15, 380, 4, 2]` | env polyline batch，B=2 |
| `dyn_polygon` | `[B, 15, 96, 4, 2]` | 动态障碍物 |
| `ego_polygon` | `[B, 15, 4, 2]` | ego 15 帧 history |
| Rollout 复制后 | `× rollout_num=12` | 变成 `[24, ...]` |
| `pred_action` | `[24, 15]` | 2 meta + 13 traj token id |
| `pred_polygon` (单 sim) | `[24, replan_time, 4, 2]` | replan_time ∈ {5,10,20} |
| `pred_logprob` | `[24, 15]` | 每 token log-prob |
| Rollout 累积轨迹 | `[24, sim_time, replan_time, 4, 2]` | 沿 sim_time 堆叠 |
| `advantages` | `[24, sim_time · replan_time]` | 组内标准化 + cumsum reverse |
| `action_mask` | 同上 | done ≥ 0 |
| Policy update micro-batch | `[32, ...]` | `UPDATE_BATCH_SIZE=32` |
| `newlogprob` | `[32, 15]` | 参与梯度 |
| lm_head logits | 1813 类 | 1792 acc_kappa + 21 meta |

---

## 10. 与 NN3-IL 的一致性/差异对照速查

| 维度 | NN3-IL | NN2-RL |
|---|---|---|
| Backbone | 6 层 × n_embd 1024 × n_head 16 | 6 层 × n_embd 768 × n_head 12 |
| 前缀模态 | 视觉(1570) + 导航(63) + 历史轨迹(4) | env polylines(380) + od(96) |
| 序列总长 | 1637 + 15 ego + 15 action = 1667 | 491 + 34 = 525 |
| 双向 vs 因果 | prefix + ego 双向；action 因果 | env + ego 双向；action 因果 |
| 输出头 | lm_head + 3 aux (navi/visual/hist_traj) | lm_head 单头 |
| 主 loss | CE ×4 (1.0, 0.1×3) | GRPO clip + KL ×0.2 |
| Reward 模型 | 无 | 21 子 reward 全部按 weight=1.0 进主 sum（junction_lane_select 显式 10.0），多进程 |
| 参考策略 | 无 | 有（π_ref = INIT_MODEL 冻结） |
| KV cache | 否（IL 每步全序列重算） | 是（rollout 高频调用）|
| GPU 数 | 128 | 32 |
| 峰值 LR | 1e-4 | 3e-6 |
| 训练迭代 | 20 epoch, 4.4M sample | 4610 iter |
| 精度 | bf16 | bf16 |

---

## 11. 注意事项 / 潜在坑

1. **rollout_num 复制在 batch 维**：数据 `.repeat(rollout_num, 1, ...)` 后 B 变 12 倍，`rollout_batch_size=32` 必须 ≥ `dataloader_batch × rollout_num`（这里 24 ≤ 32 OK）；改 `DATALOADER_BATCH_SIZE > 2` 会炸 KV-cache 预分配。
2. **`use_modified_sdpa_backend = False`**：cfg 显式关闭（L223-225），配合 KV-cache 路径；改回 True 需要重新验证 KV-cache 兼容性。
3. **π_ref 权重路径与 π 相同**：`INIT_MODEL == INIT_MODEL_PRETRAIN`（L75-L76）。若手工替换其中之一但不同步另一个，训练早期 KL 会非零导致 policy 被强拉——通常不是本配置想要的初始化。
4. **`select_replan_time` 每 10 iter 轮转**：在小 `RL_MAX_ITERS` (4610) 下每种 replan_time 约走 15 轮，注意别把 `RL_MAX_ITERS` 改到很小（如 30），会导致有些 replan_time 训不到几次。
5. **`clip_gradient=1.0`**：比 IL 更严；如果发现 avg_ratio 频繁触发 clip 且 loss 抖动，检查 rollout 阶段是否已进 bf16 而 policy update 却在 fp32（cfg 应保证两段都 bf16）。
6. **`use_aebhighrisk=False`**（L212）：与 IL 的常规设置不同，RL 主要依靠 reward function 自识别高危样本。
7. **cfg L54 注释 "show cluster trajs in openloop"**：`EVAL_GT_PRED_REWARDS` 会把 INIT_MODEL 覆写成另一个 experiment 的 last ckpt（L355），仅用于评测挖矿——真正训练时不会走到这个分支。
8. **进程池 `SHARED_MEMORY_POOL_SIZE=15`**：这个值同时被 `shmpool_size` 和 `mp.Pool(processes=15)` 使用；调大会吃更多共享内存，调小会成为 rollout 的瓶颈（CPU 端 env 读取阻塞 GPU）。
9. **`rewards_weights_cfg` 只显式配 5 项，但其余 16 项默认 weight=1.0 也进 loss**：核心代码 `self.rewards_weights.get(reward_type, 1.0)`（[rl_planner_reward_model.py L1878](tpp_onemodel/model/module/rl_planner_reward_model.py#L1878)）的 fallback 让所有 reward 都以 1.0 加入主 sum。若要真正 monitor-only 需要显式设 `xxx_reward=0.0`。这是一个隐性坑——改 reward 函数一定会影响梯度。
10. **cumsum 优势没有显式 γ 折扣**：`weight_decay=0.92` 传给 `GRPORLLoss` 却被闲置（`__init__` 保留 API 未使用）。远期信用完全靠 reverse cumsum + 组内 σ 归一——如果换 reward 函数导致时间尺度大变，需要重新审视这个近似是否仍然 warm。

---

## 12. 模块依赖关系

```mermaid
%%{init: {'theme': 'base', 'themeVariables': { 'primaryColor': '#e8eaf6', 'primaryTextColor': '#3f51b5'}}}%%
flowchart TB
    subgraph Core["核心模型（继承 IL）"]
        A[Plannn2TaskModel<br/>共享 backbone]
        B[Plannn2Block × 6<br/>n_embd=768]
        C[Plannn2CausalSelfAttention<br/>+ KV Cache]
    end
    subgraph RL["RL 组件（新增）"]
        F[Plannn2TaskFlow<br/>rl_training=True]
        FL[GRPORLLoss + EgoBCLoss<br/>= RLPlannerLoss]
        R[RLPlannerRewardModel<br/>18 子奖励 · 5 项加权]
        Q[Plannn2SpeedTrainer<br/>train_one_step_rl]
        I[Plannn2Inferrer<br/>rl_infer=True]
    end
    subgraph Refs["参考策略"]
        P[π_ref<br/>Plannn2TaskModel 副本<br/>strict load frozen]
    end
    subgraph Data["数据"]
        DS[Plannn2Dataset<br/>mode=rl]
        TK[AccKappaVehicleTokenizer<br/>1792 类]
    end

    A --> B --> C
    F --> A
    F --> P
    F --> R
    F --> FL
    Q --> F
    I --> F
    F --> DS
    DS --> TK
```

---

## 13. 总结

### 13.1 架构亮点

1. **IL→RL 差量式构造**：只 patch 训练器/优化器/loss/数据，backbone、tokenizer、序列布局零改动，保证 warm-start 一致性。
2. **GRPO 无 critic**：用同一 prompt 采样 `rollout_num=12` 条 rollout 的组内标准化替代 advantage，省一个 value network。
3. **闭环 rollout**：策略每 replan_time 步用自己走出来的历史继续预测，训练分布与推理分布一致（缓解 IL 的 exposure bias）。
4. **replan_time 三态轮转**：`{5,10,20}` 每 10 iter 换一次，让策略在短中长三种时间尺度都被显式训练。
5. **双队列 A/B 异步流水**：CPU 读环境与 GPU 前向重叠，配 15 slot 共享内存池吃掉一半 wall-clock。
6. **KV Cache + bf16**：rollout 阶段 15-token 自回归生成开销大幅下降，是大 rollout_num 得以落地的关键。
7. **PPO 悲观 clip + k3 KL**：`max(pg1, pg2)` 保守 clip 结合非负 KL 估计器，稳态训练更稳。

### 13.2 关键设计决策

| 设计 | 说明 |
|---|---|
| 双模型副本（π/π_ref）| 参考策略只做 forward 拿 logprob，冻结防灾难性遗忘 |
| 优势 reverse cumsum | 无显式 γ 的 return-to-go，配合组内标准差归一保持等尺度 |
| 5 项显式加权 reward | cfg 挑 collision/ttc/min_dist/cross_solid/junction_lane_select 显式加权（junction=10.0，其余 1.0）；**其余 16 项默认 weight=1.0 一起进主 sum**（`.get(k, 1.0)` fallback），非 monitor-only |
| 学习率 3e-6 + wd 1e-1 | RL 微调强正则化 + 小步长防遗忘 |
| rl_update_epochs=2 | on-policy 到 near on-policy 折中，配 clip 0.1 保守 |
| swap_ego_and_agent=True | 数据侧增强，让模型见更多「主车角色」变换 |

---

*文档生成时间：2026-07-10*
*分析范围：`experiments/task_planner/exp_plannn2/cfg_plannn2_rl.py` 及其串联的 `Plannn2TaskFlow`（rollout/policy update）、`RLPlannerRewardModel`（GRPO 优势）、`plannn2_rl_loss`（GRPO CLIP + KL）、`Plannn2SpeedTrainer.train_one_step_rl` 与 `Plannn2Inferrer` 模块*
