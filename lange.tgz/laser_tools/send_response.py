# -*- coding: utf-8 -*-
# pylint: disable=C0103,E0401,W1514,C0209
# flake8: noqa
"""Send response to laser"""

import argparse
import json
import os
import subprocess

from msir_pipe import utils


parser = argparse.ArgumentParser(description="Send response to laser")
parser.add_argument("--target", type=str, help="the target device")
parser.add_argument("--output_dir", type=str, help="the dir to save logs and outputs")
parser.add_argument("--test_config", type=str, help="config for send back test results")
parser.add_argument("--test_id", type=str, default="", help="the test id for send results")
parser.add_argument("--infer_type", type=str, default="tvm", help="the infer_type")
parser.add_argument("--run_name", type=str, default="test", help="the name of the test case")
parser.add_argument("--model", type=str, default="unknown", help="the model path")
args = parser.parse_args()


if __name__ == "__main__":
    assert args.test_config and os.path.isfile(args.test_config), "Can not find test config " + str(args.test_config)
    with open(args.test_config, "r") as f:
        test_config = json.load(f)
    if "callback" in test_config:
        # get runtime version
        runtime_version = ""
        try:
            process = subprocess.run(
                ["pip", "show", "compiler_runtime"],
                capture_output=True,
                text=True,
                check=True,
            )
            res = process.stdout
            for line in res.split("\n"):
                if "Version" in line:
                    runtime_version = line.split("Version: ")[1]
                    break
        except subprocess.CalledProcessError:
            runtime_version = ""

        # get results, add necessary items to results
        results = {
            args.run_name: {
                "output_dir": args.output_dir,
                "runtime_version": runtime_version,
                "model": args.model,
                "infer_type": args.infer_type,
            }
        }
        # send response
        response = {
            "id": args.test_id,
            "task_name": test_config["name"],
            "info": {},
            "task_info": {},
            "artifacts": {},
        }
        if "report_config" in test_config:
            report = {"info": {"test.{}.results".format(args.target): results}}
            reports = {"task": report, "test": report}
            report_path = utils.update_report(reports, **test_config["report_config"])
            response["info"].update({"report": report_path})
            response["task_info"].update({"report": report_path})
        utils.send_remote_response(response, test_config["callback"])
