#!/bin/bash
export PS4='\t '
set -x

timeout=0
per=30

nuchome=$1
pid=$2

soc=""

get_avaliable_soc() {
    for i in $(ls ${nuchome}); do
        # do echo "$i";
        last_pid=$(cat ${nuchome}/$i)
        if [ -z $last_pid ]; then
            # echo "get empty pid of last job, hold it~"
            soc=$i
            echo $pid >${nuchome}/$i
            break
        else
            kill -s 0 $last_pid
            if [ $? -eq 0 ]; then
                soc=""
                # echo "the pid of last job is $last_pid, still alive!!!"
            else
                # echo "the pid of last job is $last_pid, not alive!!!"
                soc=$i
                echo $pid >${nuchome}/$i
                break
            fi
        fi
    done
}

get_avaliable_soc

while [ -z "$soc" ]; do
    sleep ${per}
    get_avaliable_soc
    timeout=$((timeout + 1))

    # echo -n "wait $((timeout*per)) sec:no avaliable soc"
    echo $'\n'
    if [ $((timeout * per)) -ge 1800 ]; then
        # echo "TIMEOUT (30 min):NO AVAILABLE SOC!"
        exit 0
    fi
done

# echo "finally get avaliable soc: $soc"

echo "${soc}"
